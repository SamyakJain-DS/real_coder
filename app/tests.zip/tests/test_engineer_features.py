
import os
import sys
import pytest
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _load(sample_data_dir):
    from pipeline import load_and_validate
    return load_and_validate(sample_data_dir)


def _features(sample_data_dir):
    from pipeline import engineer_features
    return engineer_features(_load(sample_data_dir))


class TestFeatureDataFrameStructure:
    """Tests the overall structure of the returned feature DataFrame."""

    def test_one_row_per_permit(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        result = _features(sample_data_dir)
        n_permits = len(loaded_datasets["permits"])
        assert len(result) == n_permits

    def test_has_failure_is_binary(self, sample_data_dir):
        result = _features(sample_data_dir)
        unique_vals = set(result["has_failure"].dropna().unique())
        assert unique_vals.issubset({0, 1, True, False})


class TestPermitLevelDerivedColumns:
    """Tests for permit-level derived columns from step 3."""

    def test_pavement_age_at_cut_days_formula(self, sample_data_dir):
        """pavement_age_at_cut_days must equal (issue_date - pavement_install_date).days
        for every permit whose segment has a non-null pavement_install_date."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        segments = datasets["street_segments"]
        assert "permit_id" in feature_df.columns and "street_segment_id" in feature_df.columns
        for _, row in feature_df.iterrows():
            seg = segments[segments["segment_id"] == row["street_segment_id"]]
            if len(seg) == 0:
                continue
            install_date = seg.iloc[0]["pavement_install_date"]
            if pd.isna(install_date):
                continue
            expected = (row["issue_date"] - install_date).days
            actual = row["pavement_age_at_cut_days"]
            assert actual == expected, (
                f"pavement_age_at_cut_days must be (issue_date - pavement_install_date).days "
                f"= {expected}, got {actual}"
            )

    def test_warranty_overlap_is_boolean(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["warranty_overlap"].dropna()
        assert set(vals.unique()).issubset({True, False, 0, 1})

    def test_warranty_remaining_days_nan_when_no_overlap(self, sample_data_dir, tmp_path):
        """warranty_remaining_days must be NaN when warranty_overlap is False.
        The standard fixture has warranty_overlap==True for all permits (warranty window
        always contains the issue_date), so we build a controlled case with one permit
        whose issue_date falls outside the warranty window."""
        data_dir = tmp_path / "warranty_data"
        data_dir.mkdir()

        # P_OUT: issue_date (2018-06-01) is AFTER warranty_end (2018-01-01) -> overlap=False
        pd.DataFrame({
            "permit_id": ["P_IN", "P_OUT"],
            "permittee_id": ["PT001", "PT001"],
            "street_segment_id": ["S001", "S001"],
            "issue_date": ["2017-06-01", "2018-06-01"],
            "excavation_purpose": ["utility_install", "utility_install"],
            "restoration_scope": ["full", "full"],
            "traffic_control_plan_adequate": [True, True],
            "warranty_start": ["2017-01-01", "2017-01-01"],
            "warranty_end": ["2018-01-01", "2018-01-01"],
        }).to_csv(data_dir / "permits.csv", index=False)
        pd.DataFrame({
            "permittee_id": ["PT001"], "name": ["TestCo"], "type": ["utility"],
        }).to_csv(data_dir / "permittees.csv", index=False)
        pd.DataFrame({
            "segment_id": ["S001"], "corridor_name": ["C"],
            "pavement_install_date": ["2010-01-01"], "overlay_date": [None],
            "moratorium_start": [None], "moratorium_end": [None],
        }).to_csv(data_dir / "street_segments.csv", index=False)
        pd.DataFrame({
            "inspection_id": ["I001", "I002"], "permit_id": ["P_IN", "P_OUT"],
            "inspection_date": ["2017-07-01", "2018-07-01"],
            "backfill_accepted": [True, True],
            "base_course_accepted": [True, True],
            "surface_restoration_accepted": [True, True],
        }).to_csv(data_dir / "inspections.csv", index=False)
        for fname, cols in [
            ("settlement_failures.csv", ["failure_id", "permit_id", "failure_date", "severity"]),
            ("fee_assessments.csv", ["assessment_id", "permittee_id", "permit_id", "amount", "date"]),
            ("bond_claims.csv", ["claim_id", "permittee_id", "permit_id", "claim_amount", "claim_date", "resolved"]),
            ("coordination_notices.csv", ["notice_id", "permittee_id", "permit_id", "notice_date", "project_start_date"]),
        ]:
            pd.DataFrame(columns=cols).to_csv(data_dir / fname, index=False)

        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(str(data_dir))
        result = engineer_features(datasets)

        assert "permit_id" in result.columns
        p_out = result[result["permit_id"] == "P_OUT"]
        assert len(p_out) > 0, "P_OUT must appear in the feature DataFrame"
        assert p_out.iloc[0]["warranty_overlap"] == False,             "P_OUT issue_date (2018-06-01) > warranty_end (2018-01-01) must give warranty_overlap=False"
        assert pd.isna(p_out.iloc[0]["warranty_remaining_days"]),             "warranty_remaining_days must be NaN when warranty_overlap is False"

    def test_moratorium_violated_is_boolean(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["moratorium_violated"].dropna()
        assert set(vals.unique()).issubset({True, False, 0, 1})

    def test_has_overlay_is_boolean(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["has_overlay"].dropna()
        assert set(vals.unique()).issubset({True, False, 0, 1})

    def test_days_since_overlay_nan_when_no_overlay(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        no_overlay = feature_df[feature_df["has_overlay"] == False]
        if len(no_overlay) > 0:
            assert no_overlay["days_since_overlay"].isna().all()

class TestPermitteeCraftsmanshipFeatures:
    """Tests for per-permittee aggregated craftsmanship features."""

    def test_craft_backfill_rate_range(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["craft_backfill_rate"].dropna()
        assert (vals >= 0.0).all() and (vals <= 1.0).all()

    def test_craft_base_course_rate_range(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["craft_base_course_rate"].dropna()
        assert (vals >= 0.0).all() and (vals <= 1.0).all()

    def test_craft_surface_rate_range(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["craft_surface_rate"].dropna()
        assert (vals >= 0.0).all() and (vals <= 1.0).all()

    def test_craft_overall_pass_rate_range(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["craft_overall_pass_rate"].dropna()
        assert (vals >= 0.0).all() and (vals <= 1.0).all()

    def test_total_fees_assessed_non_negative(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["total_fees_assessed"].dropna()
        assert (vals >= 0).all()

    def test_fee_to_bond_ratio_zero_for_no_claims(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        no_bond = feature_df[feature_df["bond_claim_count"] == 0]
        if len(no_bond) > 0:
            assert (no_bond["fee_to_bond_ratio"] == 0.0).all()

    def test_bond_claim_count_non_negative(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["bond_claim_count"].dropna()
        assert (vals >= 0).all()

    def test_craftsmanship_features_same_for_same_permittee(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        # All 10 per-permittee aggregated features must be uniform within a permittee
        all_permittee_cols = [
            "craft_backfill_rate", "craft_base_course_rate",
            "craft_surface_rate", "craft_overall_pass_rate",
            "total_fees_assessed", "avg_fee_per_permit",
            "fee_to_bond_ratio", "bond_claim_count",
            "bond_claim_rate", "avg_coordination_lead_days",
        ]
        if "permittee_id" in feature_df.columns:
            for col in all_permittee_cols:
                if col in feature_df.columns:
                    grouped = feature_df.groupby("permittee_id")[col].nunique()
                    assert (grouped <= 1).all(), f"{col} should be uniform per permittee"


class TestSegmentSubgradeFeatures:
    """Tests for per-street-segment subgrade features."""

    def test_cumulative_cut_density_formula(self, sample_data_dir):
        """cumulative_cut_density = total_permits_on_segment / length_factor (default 1.0)."""
        feature_df = _features(sample_data_dir)
        assert "street_segment_id" in feature_df.columns
        for seg_id in feature_df["street_segment_id"].unique():
            seg_rows = feature_df[feature_df["street_segment_id"] == seg_id]
            expected = len(seg_rows) / 1.0
            actual = seg_rows["cumulative_cut_density"].iloc[0]
            assert actual == expected, (
                f"Segment {seg_id}: cumulative_cut_density should be {expected} "
                f"(permit_count/1.0), got {actual}"
            )

    def test_segment_failure_rate_formula(self, sample_data_dir):
        """segment_failure_rate = total_failures_on_segment / total_permits_on_segment.
        Verifies both failure and zero-failure segments."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        failures = datasets["settlement_failures"]
        assert "street_segment_id" in feature_df.columns and "permit_id" in feature_df.columns
        for seg_id in feature_df["street_segment_id"].unique():
            seg_rows = feature_df[feature_df["street_segment_id"] == seg_id]
            permit_ids = set(seg_rows["permit_id"].tolist())
            n_fail = len(failures[failures["permit_id"].isin(permit_ids)])
            n_permits = len(seg_rows)
            expected = n_fail / n_permits if n_permits > 0 else 0.0
            actual = seg_rows["segment_failure_rate"].iloc[0]
            assert abs(actual - expected) < 1e-9, (
                f"Segment {seg_id}: segment_failure_rate should be {expected} "
                f"({n_fail} failures / {n_permits} permits), got {actual}"
            )

    def test_segment_temporal_features_formulas(self, tmp_path):
        """One controlled dataset verifies all segment temporal feature formulas:
        cut_density_trend_slope, failure_rate_trend_slope (OLS + 0.0 for single year),
        recent_overlay_flag (2-year window), recent_year_cut_density, recent_year_failure_rate
        (including the 0.0 edge case when no permits exist in the most recent year)."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "temporal"
        data_dir.mkdir()

        # SEG_M: 2 permits in 2020, 4 permits in 2021, 2 failures in 2021
        #        overlay_date=2021-01-01 -> within 2 years of max year 2021 -> recent=True
        # SEG_S: 3 permits in 2020 only (single year), no failures
        #        overlay_date=2010-01-01 -> NOT within 2 years -> recent=False
        pd.DataFrame({
            "segment_id": ["SEG_M", "SEG_S"],
            "corridor_name": ["CorM", "CorS"],
            "pavement_install_date": ["2010-01-01", "2010-01-01"],
            "overlay_date": ["2021-01-01", "2010-01-01"],
            "moratorium_start": [None, None], "moratorium_end": [None, None],
        }).to_csv(data_dir / "street_segments.csv", index=False)

        pd.DataFrame({
            "permit_id": ["PM1","PM2","PM3","PM4","PM5","PM6","PS1","PS2","PS3"],
            "permittee_id": ["PT1"] * 9,
            "street_segment_id": ["SEG_M"]*6 + ["SEG_S"]*3,
            "issue_date": [
                "2020-01-01","2020-06-01",                         # SEG_M 2020: 2 permits
                "2021-01-01","2021-04-01","2021-07-01","2021-10-01", # SEG_M 2021: 4 permits
                "2020-02-01","2020-05-01","2020-08-01",             # SEG_S 2020: 3 permits
            ],
            "excavation_purpose": ["utility_install"]*9,
            "restoration_scope": ["full"]*9,
            "traffic_control_plan_adequate": [True]*9,
            "warranty_start": ["2019-01-01"]*9,
            "warranty_end": ["2023-01-01"]*9,
        }).to_csv(data_dir / "permits.csv", index=False)

        pd.DataFrame({"permittee_id":["PT1"],"name":["Co"],"type":["utility"]}).to_csv(
            data_dir / "permittees.csv", index=False)
        insp = [{"inspection_id":f"I{i}","permit_id":p,"inspection_date":"2020-03-01",
                 "backfill_accepted":True,"base_course_accepted":True,
                 "surface_restoration_accepted":True}
                for i,p in enumerate(["PM1","PM2","PM3","PM4","PM5","PM6","PS1","PS2","PS3"],1)]
        pd.DataFrame(insp).to_csv(data_dir / "inspections.csv", index=False)
        # 2 failures in SEG_M year 2021
        pd.DataFrame({
            "failure_id":["F1","F2"], "permit_id":["PM3","PM4"],
            "failure_date":["2021-03-01","2021-06-01"], "severity":["minor","moderate"],
        }).to_csv(data_dir / "settlement_failures.csv", index=False)
        for fname, cols in [
            ("fee_assessments.csv", ["assessment_id","permittee_id","permit_id","amount","date"]),
            ("bond_claims.csv", ["claim_id","permittee_id","permit_id","claim_amount","claim_date","resolved"]),
            ("coordination_notices.csv", ["notice_id","permittee_id","permit_id","notice_date","project_start_date"]),
        ]:
            pd.DataFrame(columns=cols).to_csv(data_dir / fname, index=False)

        datasets = load_and_validate(str(data_dir))
        feature_df = engineer_features(datasets)

        m = feature_df[feature_df["street_segment_id"] == "SEG_M"].iloc[0]
        s = feature_df[feature_df["street_segment_id"] == "SEG_S"].iloc[0]

        # cut_density_trend_slope: OLS of [2,4] vs [0,1] -> slope = 2.0
        assert m["cut_density_trend_slope"] == pytest.approx(2.0), (
            f"SEG_M cut_density_trend_slope expected 2.0 (OLS of [2,4] vs [0,1]), "
            f"got {m['cut_density_trend_slope']}"
        )
        # Single-year segment -> 0.0
        assert s["cut_density_trend_slope"] == 0.0, (
            f"SEG_S (single year) cut_density_trend_slope must be 0.0, got {s['cut_density_trend_slope']}"
        )

        # failure_rate_trend_slope: year 2020 rate=0.0 (0/2), year 2021 rate=0.5 (2/4)
        # OLS of [0.0, 0.5] vs [0,1] -> slope = 0.5
        assert m["failure_rate_trend_slope"] == pytest.approx(0.5), (
            f"SEG_M failure_rate_trend_slope expected 0.5 (OLS of [0.0,0.5] vs [0,1]), "
            f"got {m['failure_rate_trend_slope']}"
        )
        assert s["failure_rate_trend_slope"] == 0.0, (
            f"SEG_S (single year) failure_rate_trend_slope must be 0.0, got {s['failure_rate_trend_slope']}"
        )

        # recent_overlay_flag: max dataset year = 2021; "most recent 2 years" = 2020-2021
        assert m["recent_overlay_flag"] == True, (
            "SEG_M overlay 2021-01-01 is within 2 years of max year 2021 -> recent_overlay_flag=True"
        )
        assert s["recent_overlay_flag"] == False, (
            "SEG_S overlay 2010-01-01 is NOT within 2 years of max year 2021 -> recent_overlay_flag=False"
        )

        # recent_year_cut_density: most recent year = 2021; SEG_M has 4 permits / 1.0 = 4.0
        assert m["recent_year_cut_density"] == pytest.approx(4.0), (
            f"SEG_M recent_year_cut_density expected 4.0 (4 permits in 2021 / 1.0), "
            f"got {m['recent_year_cut_density']}"
        )
        # SEG_S has 0 permits in 2021 -> 0.0
        assert s["recent_year_cut_density"] == pytest.approx(0.0), (
            f"SEG_S has no permits in max year 2021 -> recent_year_cut_density=0.0, "
            f"got {s['recent_year_cut_density']}"
        )

        # recent_year_failure_rate: SEG_M in 2021: 2/4 = 0.5; SEG_S in 2021: 0 permits -> 0.0
        assert m["recent_year_failure_rate"] == pytest.approx(0.5), (
            f"SEG_M recent_year_failure_rate expected 0.5 (2 failures / 4 permits in 2021), "
            f"got {m['recent_year_failure_rate']}"
        )
        assert s["recent_year_failure_rate"] == pytest.approx(0.0), (
            f"SEG_S has no permits in max year 2021 -> recent_year_failure_rate=0.0 (edge case), "
            f"got {s['recent_year_failure_rate']}"
        )

    def test_recent_year_cut_density_exists(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        assert "recent_year_cut_density" in feature_df.columns

    def test_recent_year_failure_rate_exists(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        assert "recent_year_failure_rate" in feature_df.columns


    def test_avg_pavement_age_at_cut_non_negative(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        vals = feature_df["avg_pavement_age_at_cut"].dropna()
        assert (vals >= 0).all()

    def test_recent_overlay_flag_exists(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        assert "recent_overlay_flag" in feature_df.columns


    def test_segment_features_same_for_same_segment(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        # All 8 per-segment features must be uniform within a segment
        all_segment_cols = [
            "cumulative_cut_density", "segment_failure_rate",
            "cut_density_trend_slope", "failure_rate_trend_slope",
            "recent_year_cut_density", "recent_year_failure_rate",
            "avg_pavement_age_at_cut", "recent_overlay_flag",
        ]
        if "street_segment_id" in feature_df.columns:
            for col in all_segment_cols:
                if col in feature_df.columns:
                    grouped = feature_df.groupby("street_segment_id")[col].nunique()
                    assert (grouped <= 1).all(), f"{col} should be uniform per segment"


class TestCoordinationLeadDays:
    """Tests for coordination_lead_days derived column."""

    def test_coordination_lead_days_formula_is_correct(self, sample_data_dir):
        """coordination_lead_days must equal (project_start_date - notice_date).days.
        Fixture P001: notice_date=2017-01-01, project_start_date=2017-01-15 -> 14 days."""
        feature_df = _features(sample_data_dir)
        vals = feature_df["coordination_lead_days"].dropna()
        assert len(vals) > 0, "Fixture must have coordinated permits with non-NaN coordination_lead_days"
        assert pd.api.types.is_numeric_dtype(vals), "coordination_lead_days must be numeric"
        # Verify the formula against a known fixture value
        assert "permit_id" in feature_df.columns, "permit_id must be preserved in feature_df"
        p001 = feature_df[feature_df["permit_id"] == "P001"]
        assert len(p001) > 0, "P001 must appear in the feature DataFrame"
        val = p001.iloc[0]["coordination_lead_days"]
        assert not pd.isna(val), "P001 has a coordination notice; coordination_lead_days must not be NaN"
        assert int(val) == 14, (
            f"P001: notice_date=2017-01-01, project_start_date=2017-01-15 "
            f"-> coordination_lead_days must be 14, got {val}"
        )


class TestDaysOverlayConsistency:
    """Tests for consistency between has_overlay and days_since_overlay."""

    def test_days_since_overlay_non_negative_when_has_overlay(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        has_overlay_rows = feature_df[feature_df["has_overlay"] == True]
        if len(has_overlay_rows) > 0:
            vals = has_overlay_rows["days_since_overlay"].dropna()
            assert (vals >= 0).all(), "days_since_overlay should be non-negative when has_overlay is True"


class TestOneHotEncoding:
    """Tests for one-hot encoding of categorical columns."""

    def test_excavation_purpose_one_hot_columns_present(self, sample_data_dir):
        import pandas as _pd, os as _os
        n_unique = _pd.read_csv(_os.path.join(sample_data_dir, "permits.csv"))["excavation_purpose"].nunique()
        feature_df = _features(sample_data_dir)
        ohe_cols = [c for c in feature_df.columns if c.startswith("excavation_purpose_")]
        assert len(ohe_cols) == n_unique - 1, (
            f"drop='first' with {n_unique} unique categories must produce {n_unique - 1} OHE columns, "
            f"got {len(ohe_cols)}"
        )

    def test_restoration_scope_one_hot_columns_present(self, sample_data_dir):
        import pandas as _pd, os as _os
        n_unique = _pd.read_csv(_os.path.join(sample_data_dir, "permits.csv"))["restoration_scope"].nunique()
        feature_df = _features(sample_data_dir)
        ohe_cols = [c for c in feature_df.columns if c.startswith("restoration_scope_")]
        assert len(ohe_cols) == n_unique - 1, (
            f"drop='first' with {n_unique} unique categories must produce {n_unique - 1} OHE columns, "
            f"got {len(ohe_cols)}"
        )

    def test_traffic_control_plan_adequate_included(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        assert "traffic_control_plan_adequate" in feature_df.columns

    def test_one_hot_columns_are_binary(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        ohe_cols = [c for c in feature_df.columns
                    if c.startswith("excavation_purpose")
                    or c.startswith("restoration_scope")
                    or c.startswith("permittee_type")]
        for col in ohe_cols:
            unique_vals = set(feature_df[col].dropna().unique())
            assert unique_vals.issubset({0, 1, 0.0, 1.0, True, False}), \
                f"Column {col} should be binary"


class TestHasFailureLabel:
    """Tests for the has_failure target label computation."""

    def test_has_failure_includes_failures_within_730_days(self, sample_data_dir):
        """Fixtures P005-P040 each have a failure at issue_date + 200 days (< 730).
        permit_id must be preserved (prompt requirement) and those permits labeled 1."""
        loaded_datasets = _load(sample_data_dir)
        from pipeline import engineer_features
        result = engineer_features(loaded_datasets)
        assert "permit_id" in result.columns,             "engineer_features must preserve permit_id (required by prompt)"
        # Known fixtures: failure_date = issue_date + 200 days (well within 730)
        known_within_window = ["P005", "P010", "P015", "P020"]
        for pid in known_within_window:
            row = result[result["permit_id"] == pid]
            assert len(row) > 0, f"Permit {pid} must appear in the feature DataFrame"
            assert int(row.iloc[0]["has_failure"]) == 1,                 f"Permit {pid} with failure at +200 days must be labeled has_failure=1"

    def test_has_failure_not_all_ones(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        from pipeline import engineer_features
        result = engineer_features(loaded_datasets)
        assert result["has_failure"].sum() < len(result), "Not every permit should have a failure"

    def test_has_failure_respects_730_day_window(self, sample_data_dir, tmp_path):
        data_dir = tmp_path / "data_730"
        data_dir.mkdir()

        permits_df = pd.DataFrame({
            "permit_id": ["P_EARLY", "P_LATE"],
            "permittee_id": ["PT001", "PT001"],
            "street_segment_id": ["S001", "S001"],
            "issue_date": ["2018-01-01", "2018-01-01"],
            "excavation_purpose": ["utility_install", "utility_install"],
            "restoration_scope": ["full", "full"],
            "traffic_control_plan_adequate": [True, True],
            "warranty_start": ["2018-01-01", "2018-01-01"],
            "warranty_end": ["2020-01-01", "2020-01-01"],
        })
        permits_df.to_csv(data_dir / "permits.csv", index=False)

        failures_df = pd.DataFrame({
            "failure_id": ["F_WITHIN", "F_OUTSIDE"],
            "permit_id": ["P_EARLY", "P_LATE"],
            "failure_date": ["2019-06-01", "2022-06-01"],
            "severity": ["minor", "minor"],
        })
        failures_df.to_csv(data_dir / "settlement_failures.csv", index=False)

        inspections_df = pd.DataFrame({
            "inspection_id": ["I001", "I002"],
            "permit_id": ["P_EARLY", "P_LATE"],
            "inspection_date": ["2018-02-01", "2018-02-01"],
            "backfill_accepted": [True, True],
            "base_course_accepted": [True, True],
            "surface_restoration_accepted": [True, True],
        })
        inspections_df.to_csv(data_dir / "inspections.csv", index=False)

        pd.DataFrame({
            "permittee_id": ["PT001"], "name": ["TestCo"], "type": ["utility"],
        }).to_csv(data_dir / "permittees.csv", index=False)

        pd.DataFrame({
            "segment_id": ["S001"], "corridor_name": ["TestCorridor"],
            "pavement_install_date": ["2010-01-01"], "overlay_date": [None],
            "moratorium_start": [None], "moratorium_end": [None],
        }).to_csv(data_dir / "street_segments.csv", index=False)

        pd.DataFrame({
            "assessment_id": ["FE001"], "permittee_id": ["PT001"],
            "permit_id": ["P_EARLY"], "amount": [100.0], "date": ["2018-03-01"],
        }).to_csv(data_dir / "fee_assessments.csv", index=False)

        pd.DataFrame(columns=["claim_id", "permittee_id", "permit_id",
                               "claim_amount", "claim_date", "resolved"]).to_csv(
            data_dir / "bond_claims.csv", index=False)

        pd.DataFrame(columns=["notice_id", "permittee_id", "permit_id",
                               "notice_date", "project_start_date"]).to_csv(
            data_dir / "coordination_notices.csv", index=False)

        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(str(data_dir))
        result = engineer_features(datasets)

        assert "permit_id" in result.columns,             "engineer_features must preserve permit_id"
        early = result[result["permit_id"] == "P_EARLY"]
        late = result[result["permit_id"] == "P_LATE"]
        assert len(early) > 0, "P_EARLY must appear in the feature DataFrame"
        assert len(late) > 0, "P_LATE must appear in the feature DataFrame"
        assert int(early.iloc[0]["has_failure"]) == 1,             "Failure within 730 days should be labeled 1"
        assert int(late.iloc[0]["has_failure"]) == 0,             "Failure beyond 730 days should be labeled 0"


class TestPermitteeTypeEncoding:
    """Tests for one-hot encoding of permittee_type (new in updated prompt)."""

    def test_permittee_type_one_hot_columns_present(self, sample_data_dir):
        import pandas as _pd, os as _os
        n_unique = _pd.read_csv(_os.path.join(sample_data_dir, "permittees.csv"))["type"].nunique()
        feature_df = _features(sample_data_dir)
        ohe_cols = [c for c in feature_df.columns if c.startswith("permittee_type_")]
        assert len(ohe_cols) == n_unique - 1, (
            f"drop='first' with {n_unique} unique types must produce {n_unique - 1} OHE columns, "
            f"got {len(ohe_cols)}"
        )

    def test_permittee_type_one_hot_columns_are_binary(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        ohe_cols = [c for c in feature_df.columns if c.startswith("permittee_type")]
        for col in ohe_cols:
            unique_vals = set(feature_df[col].dropna().unique())
            assert unique_vals.issubset({0, 1, 0.0, 1.0, True, False}), \
                f"Column {col} should be binary (0/1)"


class TestIdentifierColumnsPreserved:
    """Tests that engineer_features preserves the identifier and date columns
    required by all downstream functions."""

    def test_permit_id_preserved(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        assert "permit_id" in feature_df.columns, \
            "engineer_features must preserve permit_id for downstream report use"

    def test_permittee_id_preserved(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        assert "permittee_id" in feature_df.columns, \
            "engineer_features must preserve permittee_id for downstream grouping"

    def test_street_segment_id_preserved(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        assert "street_segment_id" in feature_df.columns, \
            "engineer_features must preserve street_segment_id for downstream joins"

    def test_issue_date_preserved(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        assert "issue_date" in feature_df.columns, \
            "engineer_features must preserve issue_date for downstream temporal filtering"


class TestLeakyFeaturesComputedButPresent:
    """Segment failure-rate features must be computed and present in the output
    DataFrame (for reporting) even though they must not be used for model training."""

    def test_recent_year_failure_rate_present_in_output(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        assert "recent_year_failure_rate" in feature_df.columns


class TestWarrantyRemainingDaysFormula:
    """Tests that warranty_remaining_days matches the required formula."""

    def test_warranty_remaining_days_formula_when_overlap(self, sample_data_dir):
        """When warranty_overlap is True, warranty_remaining_days must equal
        (warranty_end - issue_date).days per the prompt specification."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        permits = datasets["permits"]

        overlapping = feature_df[feature_df["warranty_overlap"] == True]
        assert len(overlapping) > 0, "Fixture must contain permits with warranty_overlap==True"
        assert "permit_id" in feature_df.columns, "permit_id must be preserved in feature_df"

        for _, row in overlapping.iterrows():
            pid = row["permit_id"]
            permit_raw = permits[permits["permit_id"] == pid]
            if len(permit_raw) == 0:
                continue
            warranty_end = permit_raw.iloc[0]["warranty_end"]
            issue_date = permit_raw.iloc[0]["issue_date"]
            if pd.isna(warranty_end) or pd.isna(issue_date):
                continue
            expected = (warranty_end - issue_date).days
            actual = row["warranty_remaining_days"]
            assert actual == expected, (
                f"Permit {pid}: warranty_remaining_days must be "
                f"(warranty_end - issue_date).days = {expected}, got {actual}"
            )


class TestMoratoriumViolatedNullDateHandling:
    """Tests the null moratorium date rule: moratorium_violated must be False
    when moratorium_start or moratorium_end is null."""

    def test_moratorium_violated_false_for_null_moratorium_segments(self, sample_data_dir):
        """Permits on segments with null moratorium dates must have moratorium_violated=False."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        segments = datasets["street_segments"]

        # Identify segments with at least one null moratorium date
        null_moratorium_segs = segments[
            segments["moratorium_start"].isna() | segments["moratorium_end"].isna()
        ]["segment_id"].tolist()

        assert len(null_moratorium_segs) > 0, "Fixture must have segments with null moratorium dates"
        assert "street_segment_id" in feature_df.columns, "street_segment_id must be preserved"

        null_moratorium_permits = feature_df[
            feature_df["street_segment_id"].isin(null_moratorium_segs)
        ]
        assert len(null_moratorium_permits) > 0, "Fixture must have permits on null-moratorium segments"
        assert (null_moratorium_permits["moratorium_violated"] == False).all(), (
            "Permits on segments with null moratorium_start or moratorium_end "
            "must have moratorium_violated=False"
        )


class TestHasOverlayPositiveCase:
    """Tests that has_overlay is correctly set to True when overlay_date <= issue_date,
    and that days_since_overlay matches the formula in those cases."""

    def test_has_overlay_true_when_overlay_precedes_issue_date(self, sample_data_dir):
        """has_overlay must be True for at least one permit in the fixture (segments S006–S015
        have overlay dates starting 2019-06-01; permits issued after those dates qualify).
        Also verifies: has_overlay==True ↔ overlay_date <= issue_date, and
        days_since_overlay == (issue_date - overlay_date).days."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        segments = datasets["street_segments"]

        # At least one permit must have has_overlay==True (fixture includes post-overlay permits)
        assert feature_df["has_overlay"].any(), (
            "Fixture must have at least one permit issued after a segment's overlay_date "
            "(has_overlay==True)"
        )

        # For all permits with has_overlay==True, verify:
        # (a) overlay_date was <= issue_date
        # (b) days_since_overlay == (issue_date - overlay_date).days
        assert "permit_id" in feature_df.columns and "street_segment_id" in feature_df.columns, \
            "Identifier columns must be preserved in feature_df"

        true_overlay_rows = feature_df[feature_df["has_overlay"] == True]
        for _, row in true_overlay_rows.iterrows():
            seg_id = row["street_segment_id"]
            seg = segments[segments["segment_id"] == seg_id]
            if len(seg) == 0:
                continue
            overlay_date = seg.iloc[0]["overlay_date"]
            issue_date = row["issue_date"]
            assert not pd.isna(overlay_date), (
                f"has_overlay is True for segment {seg_id} but overlay_date is NaN"
            )
            assert overlay_date <= issue_date, (
                f"has_overlay is True but overlay_date ({overlay_date}) > issue_date ({issue_date})"
            )
            expected_days = (issue_date - overlay_date).days
            actual_days = row["days_since_overlay"]
            assert actual_days == expected_days, (
                f"days_since_overlay should be {expected_days} "
                f"(issue_date - overlay_date), got {actual_days}"
            )


class TestMoratoriumViolatedPositiveCase:
    """Test that moratorium_violated is correctly set to True when issue_date
    falls inside the segment's moratorium window."""

    def test_moratorium_violated_true_when_in_window(self, sample_data_dir):
        """moratorium_violated must be True when issue_date ∈ [moratorium_start, moratorium_end].
        Fixture segments S009–S015 have active moratorium windows; some permits fall inside."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        segments = datasets["street_segments"]

        assert "permit_id" in feature_df.columns
        assert "street_segment_id" in feature_df.columns

        segs_with_window = segments[
            segments["moratorium_start"].notna() & segments["moratorium_end"].notna()
        ]
        found_true = False
        for _, seg in segs_with_window.iterrows():
            seg_permits = feature_df[feature_df["street_segment_id"] == seg["segment_id"]]
            for _, row in seg_permits.iterrows():
                if seg["moratorium_start"] <= row["issue_date"] <= seg["moratorium_end"]:
                    assert row["moratorium_violated"] == True, (
                        f"Permit {row['permit_id']} issue_date {row['issue_date']} falls inside "
                        f"moratorium [{seg['moratorium_start']}, {seg['moratorium_end']}] "
                        f"-> moratorium_violated must be True"
                    )
                    found_true = True

        assert found_true, (
            "Fixture must contain at least one permit whose issue_date falls inside "
            "a segment's moratorium window"
        )


class TestCoordinationLeadDaysNaN:
    """Test that coordination_lead_days is NaN for permits without a coordination notice."""

    def test_coordination_lead_days_nan_when_no_notice(self, sample_data_dir):
        """coordination_lead_days must be NaN when no coordination notice exists
        for the permit. Fixture has notices only for P001–P020; P021–P050 have none."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        notices = datasets["coordination_notices"]

        assert "permit_id" in feature_df.columns

        permits_with_notice = set(notices["permit_id"].unique())
        no_notice = feature_df[~feature_df["permit_id"].isin(permits_with_notice)]

        assert len(no_notice) > 0, "Fixture must include permits without coordination notices"
        assert no_notice["coordination_lead_days"].isna().all(), (
            "Permits with no coordination notice must have coordination_lead_days = NaN"
        )


class TestAvgPavementAgeAtCutFormula:
    """Formula test for avg_pavement_age_at_cut per segment."""

    def test_avg_pavement_age_at_cut_formula(self, sample_data_dir):
        """avg_pavement_age_at_cut = mean of (issue_date - pavement_install_date).days
        across all permits on the segment."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        segments = datasets["street_segments"]

        assert "street_segment_id" in feature_df.columns

        for seg_id in feature_df["street_segment_id"].unique():
            seg_rows = feature_df[feature_df["street_segment_id"] == seg_id]
            seg = segments[segments["segment_id"] == seg_id]
            if len(seg) == 0:
                continue
            install_date = seg.iloc[0]["pavement_install_date"]
            if pd.isna(install_date):
                continue
            ages = [(r["issue_date"] - install_date).days for _, r in seg_rows.iterrows()]
            expected_avg = sum(ages) / len(ages)
            actual = seg_rows["avg_pavement_age_at_cut"].iloc[0]
            assert abs(actual - expected_avg) < 1e-6, (
                f"Segment {seg_id}: avg_pavement_age_at_cut expected {expected_avg}, got {actual}"
            )


class TestCraftsmanshipFeatureFormulas:
    """Formula-level verification for all per-permittee aggregated features."""

    def test_craftsmanship_rates_formula(self, sample_data_dir):
        """craft_*_rate = fraction of inspections across all permittee permits where
        the acceptance field is True. Verified for all 4 rate features."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        permits = datasets["permits"]
        inspections = datasets["inspections"]

        assert "permittee_id" in feature_df.columns

        for permittee_id in feature_df["permittee_id"].unique():
            pid_list = permits[permits["permittee_id"] == permittee_id]["permit_id"].tolist()
            insp = inspections[inspections["permit_id"].isin(pid_list)]
            if len(insp) == 0:
                continue
            row = feature_df[feature_df["permittee_id"] == permittee_id].iloc[0]
            n = len(insp)

            for col, feat in [
                ("backfill_accepted", "craft_backfill_rate"),
                ("base_course_accepted", "craft_base_course_rate"),
                ("surface_restoration_accepted", "craft_surface_rate"),
            ]:
                expected = float(insp[col].sum()) / n
                assert abs(row[feat] - expected) < 1e-9, (
                    f"Permittee {permittee_id}: {feat} expected {expected}, got {row[feat]}"
                )

            # craft_overall_pass_rate: all three fields True simultaneously
            all_pass = (insp["backfill_accepted"] &
                        insp["base_course_accepted"] &
                        insp["surface_restoration_accepted"])
            expected_overall = float(all_pass.sum()) / n
            assert abs(row["craft_overall_pass_rate"] - expected_overall) < 1e-9, (
                f"Permittee {permittee_id}: craft_overall_pass_rate expected {expected_overall}"
            )

    def test_fee_bond_feature_formulas(self, sample_data_dir):
        """total_fees_assessed, avg_fee_per_permit, bond_claim_count, bond_claim_rate,
        fee_to_bond_ratio all verified against raw dataset values."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        permits = datasets["permits"]
        fees = datasets["fee_assessments"]
        bonds = datasets["bond_claims"]

        assert "permittee_id" in feature_df.columns

        for permittee_id in feature_df["permittee_id"].unique():
            row = feature_df[feature_df["permittee_id"] == permittee_id].iloc[0]
            n_permits = len(permits[permits["permittee_id"] == permittee_id])
            perm_fees = fees[fees["permittee_id"] == permittee_id]["amount"]
            perm_bonds = bonds[bonds["permittee_id"] == permittee_id]

            total_fees = float(perm_fees.sum()) if len(perm_fees) > 0 else 0.0
            assert abs(row["total_fees_assessed"] - total_fees) < 1e-6, (
                f"Permittee {permittee_id}: total_fees_assessed expected {total_fees}"
            )

            expected_avg = total_fees / n_permits if n_permits > 0 else 0.0
            assert abs(row["avg_fee_per_permit"] - expected_avg) < 1e-6, (
                f"Permittee {permittee_id}: avg_fee_per_permit expected {expected_avg}"
            )

            expected_count = len(perm_bonds)
            assert row["bond_claim_count"] == expected_count, (
                f"Permittee {permittee_id}: bond_claim_count expected {expected_count}"
            )

            expected_rate = expected_count / n_permits if n_permits > 0 else 0.0
            assert abs(row["bond_claim_rate"] - expected_rate) < 1e-6

            if expected_count == 0:
                assert row["fee_to_bond_ratio"] == 0.0, (
                    f"Permittee {permittee_id}: fee_to_bond_ratio must be 0.0 when no bond claims"
                )
            else:
                total_claim = float(perm_bonds["claim_amount"].sum())
                expected_ratio = total_fees / total_claim if total_claim > 0 else 0.0
                assert abs(row["fee_to_bond_ratio"] - expected_ratio) < 1e-6

    def test_avg_coordination_lead_days_formula(self, sample_data_dir):
        """avg_coordination_lead_days = mean of (project_start_date - notice_date).days
        for the permittee's notices; NaN when the permittee has zero notices."""
        from pipeline import load_and_validate, engineer_features
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        notices = datasets["coordination_notices"]

        assert "permittee_id" in feature_df.columns

        for permittee_id in feature_df["permittee_id"].unique():
            row = feature_df[feature_df["permittee_id"] == permittee_id].iloc[0]
            perm_notices = notices[notices["permittee_id"] == permittee_id]

            if len(perm_notices) == 0:
                assert pd.isna(row["avg_coordination_lead_days"]), (
                    f"Permittee {permittee_id} has no notices -> avg_coordination_lead_days must be NaN"
                )
            else:
                lead = (perm_notices["project_start_date"] - perm_notices["notice_date"]).dt.days
                expected = float(lead.mean())
                assert abs(row["avg_coordination_lead_days"] - expected) < 1e-6, (
                    f"Permittee {permittee_id}: avg_coordination_lead_days expected {expected}, "
                    f"got {row['avg_coordination_lead_days']}"
                )


class TestWarrantyOverlapNullDates:
    """warranty_overlap must be False when warranty_start or warranty_end is null.
    Prompt: 'True when warranty_start <= issue_date <= warranty_end, False otherwise
    (including when either warranty date is null).'
    """

    def _make_dataset(self, data_dir, warranty_start, warranty_end):
        """Minimal single-permit dataset for warranty null-date edge case testing."""
        pd.DataFrame({
            "segment_id": ["S1"], "corridor_name": ["CorA"],
            "pavement_install_date": ["2000-01-01"],
            "overlay_date": [None], "moratorium_start": [None], "moratorium_end": [None],
        }).to_csv(data_dir / "street_segments.csv", index=False)

        pd.DataFrame({
            "permit_id": ["P1"], "permittee_id": ["PT1"], "street_segment_id": ["S1"],
            "issue_date": ["2020-06-01"],   # falls inside window IF both dates present
            "excavation_purpose": ["utility_install"], "restoration_scope": ["full"],
            "traffic_control_plan_adequate": [True],
            "warranty_start": [warranty_start],
            "warranty_end": [warranty_end],
        }).to_csv(data_dir / "permits.csv", index=False)

        pd.DataFrame({"permittee_id": ["PT1"], "name": ["Co"], "type": ["utility"]}).to_csv(
            data_dir / "permittees.csv", index=False)
        pd.DataFrame({
            "inspection_id": ["I1"], "permit_id": ["P1"], "inspection_date": ["2020-07-01"],
            "backfill_accepted": [True], "base_course_accepted": [True],
            "surface_restoration_accepted": [True],
        }).to_csv(data_dir / "inspections.csv", index=False)

        for fname, cols in [
            ("settlement_failures.csv", ["failure_id", "permit_id", "failure_date", "severity"]),
            ("fee_assessments.csv", ["assessment_id", "permittee_id", "permit_id", "amount", "date"]),
            ("bond_claims.csv", ["claim_id", "permittee_id", "permit_id", "claim_amount", "claim_date", "resolved"]),
            ("coordination_notices.csv", ["notice_id", "permittee_id", "permit_id", "notice_date", "project_start_date"]),
        ]:
            pd.DataFrame(columns=cols).to_csv(data_dir / fname, index=False)

    def test_warranty_overlap_false_when_warranty_start_null(self, tmp_path):
        """warranty_overlap must be False when warranty_start is null even if
        issue_date would fall inside the window with a non-null warranty_start."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "null_start"
        data_dir.mkdir()
        # warranty_end is 2025-01-01 (after issue_date 2020-06-01), but start is null
        self._make_dataset(data_dir, warranty_start=None, warranty_end="2025-01-01")
        feature_df = engineer_features(load_and_validate(str(data_dir)))
        row = feature_df.iloc[0]
        assert row["warranty_overlap"] == False, \
            "warranty_overlap must be False when warranty_start is null"
        assert pd.isna(row["warranty_remaining_days"]), \
            "warranty_remaining_days must be NaN when warranty_overlap is False"

    def test_warranty_overlap_false_when_warranty_end_null(self, tmp_path):
        """warranty_overlap must be False when warranty_end is null even if
        issue_date would fall inside the window with a non-null warranty_end."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "null_end"
        data_dir.mkdir()
        # warranty_start is 2019-01-01 (before issue_date 2020-06-01), but end is null
        self._make_dataset(data_dir, warranty_start="2019-01-01", warranty_end=None)
        feature_df = engineer_features(load_and_validate(str(data_dir)))
        row = feature_df.iloc[0]
        assert row["warranty_overlap"] == False, \
            "warranty_overlap must be False when warranty_end is null"
        assert pd.isna(row["warranty_remaining_days"]), \
            "warranty_remaining_days must be NaN when warranty_overlap is False"


def _make_minimal_csv_scaffold(data_dir, *, overlay_date=None, moratorium_start=None,
                               moratorium_end=None, issue_date="2020-06-01",
                               warranty_start="2019-01-01", warranty_end="2025-01-01"):
    """Single-permit, single-segment scaffold for targeted edge-case tests."""
    pd.DataFrame({
        "segment_id": ["S1"], "corridor_name": ["CorA"],
        "pavement_install_date": ["2000-01-01"],
        "overlay_date": [overlay_date],
        "moratorium_start": [moratorium_start], "moratorium_end": [moratorium_end],
    }).to_csv(data_dir / "street_segments.csv", index=False)
    pd.DataFrame({
        "permit_id": ["P1"], "permittee_id": ["PT1"], "street_segment_id": ["S1"],
        "issue_date": [issue_date],
        "excavation_purpose": ["utility_install"], "restoration_scope": ["full"],
        "traffic_control_plan_adequate": [True],
        "warranty_start": [warranty_start], "warranty_end": [warranty_end],
    }).to_csv(data_dir / "permits.csv", index=False)
    pd.DataFrame({"permittee_id": ["PT1"], "name": ["Co"], "type": ["utility"]}).to_csv(
        data_dir / "permittees.csv", index=False)
    pd.DataFrame({
        "inspection_id": ["I1"], "permit_id": ["P1"], "inspection_date": ["2020-08-01"],
        "backfill_accepted": [True], "base_course_accepted": [True],
        "surface_restoration_accepted": [True],
    }).to_csv(data_dir / "inspections.csv", index=False)
    for fname, cols in [
        ("settlement_failures.csv", ["failure_id", "permit_id", "failure_date", "severity"]),
        ("fee_assessments.csv",     ["assessment_id", "permittee_id", "permit_id", "amount", "date"]),
        ("bond_claims.csv",         ["claim_id", "permittee_id", "permit_id", "claim_amount", "claim_date", "resolved"]),
        ("coordination_notices.csv",["notice_id", "permittee_id", "permit_id", "notice_date", "project_start_date"]),
    ]:
        pd.DataFrame(columns=cols).to_csv(data_dir / fname, index=False)


class TestSegmentFailureDateYearBucket:
    """Per-segment per-year failure counts must group failures by failure_date year,
    not by the associated permit's issue_date year.
    Prompt: 'Per-segment, per-year failure count (settlement failures whose failure_date year matches).'
    """

    def test_per_year_failure_count_uses_failure_date_year(self, tmp_path):
        """P2 is issued in 2020 but its failure F2 has failure_date in 2021.
        F2 must count in the 2021 per-year bucket.
        Correct slope (failure_date year):  OLS([0.5, 1.0] vs [0, 1]) = +0.5
        Wrong slope (issue_date year):      OLS([1.0, 0.0] vs [0, 1]) = -1.0
        """
        from pipeline import load_and_validate, engineer_features

        data_dir = tmp_path / "failure_date_year"
        data_dir.mkdir()

        pd.DataFrame({
            "segment_id": ["S1"], "corridor_name": ["CorA"],
            "pavement_install_date": ["2000-01-01"], "overlay_date": ["2015-01-01"],
            "moratorium_start": [None], "moratorium_end": [None],
        }).to_csv(data_dir / "street_segments.csv", index=False)

        # P1, P2 -> issue_date year 2020;  P3 -> issue_date year 2021
        pd.DataFrame({
            "permit_id": ["P1", "P2", "P3"],
            "permittee_id": ["PT1"] * 3,
            "street_segment_id": ["S1"] * 3,
            "issue_date": ["2020-01-01", "2020-12-15", "2021-01-01"],
            "excavation_purpose": ["utility_install"] * 3,
            "restoration_scope": ["full"] * 3,
            "traffic_control_plan_adequate": [True] * 3,
            "warranty_start": ["2019-01-01"] * 3,
            "warranty_end": ["2025-01-01"] * 3,
        }).to_csv(data_dir / "permits.csv", index=False)

        pd.DataFrame({"permittee_id": ["PT1"], "name": ["Co"], "type": ["utility"]}).to_csv(
            data_dir / "permittees.csv", index=False)
        pd.DataFrame({
            "inspection_id": ["I1", "I2", "I3"],
            "permit_id": ["P1", "P2", "P3"],
            "inspection_date": ["2020-03-01", "2021-01-20", "2021-03-01"],
            "backfill_accepted": [True] * 3,
            "base_course_accepted": [True] * 3,
            "surface_restoration_accepted": [True] * 3,
        }).to_csv(data_dir / "inspections.csv", index=False)

        # F1: failure_date 2020 for P1 — same year either way (unambiguous)
        # F2: failure_date 2021 for P2 — KEY discriminator:
        #     correct uses failure_date year (2021), wrong uses issue_date year (2020)
        pd.DataFrame({
            "failure_id": ["F1", "F2"],
            "permit_id": ["P1", "P2"],
            "failure_date": ["2020-06-01", "2021-01-10"],
            "severity": ["minor", "moderate"],
        }).to_csv(data_dir / "settlement_failures.csv", index=False)

        for fname, cols in [
            ("fee_assessments.csv",     ["assessment_id", "permittee_id", "permit_id", "amount", "date"]),
            ("bond_claims.csv",         ["claim_id", "permittee_id", "permit_id", "claim_amount", "claim_date", "resolved"]),
            ("coordination_notices.csv",["notice_id", "permittee_id", "permit_id", "notice_date", "project_start_date"]),
        ]:
            pd.DataFrame(columns=cols).to_csv(data_dir / fname, index=False)

        feature_df = engineer_features(load_and_validate(str(data_dir)))
        slope = feature_df[feature_df["street_segment_id"] == "S1"]["failure_rate_trend_slope"].iloc[0]

        assert abs(slope - 0.5) < 1e-6, (
            f"failure_rate_trend_slope must be 0.5 (F2 counted in 2021 by failure_date year; "
            f"year-0 rate=0.5, year-1 rate=1.0). "
            f"Got {slope:.4f} — a value near -1.0 indicates failure_date year is being "
            f"confused with issue_date year."
        )


class TestWarrantyOverlapBoundaryDates:
    """warranty_overlap must be True when issue_date == warranty_start or == warranty_end.
    Prompt: 'True when warranty_start <= issue_date <= warranty_end' (inclusive on both ends).
    """

    def test_warranty_overlap_true_when_issue_date_equals_warranty_start(self, tmp_path):
        """issue_date == warranty_start -> warranty_overlap must be True (inclusive lower bound)."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "ws_eq"
        data_dir.mkdir()
        _make_minimal_csv_scaffold(
            data_dir,
            issue_date="2020-01-01",
            warranty_start="2020-01-01",   # issue_date == warranty_start
            warranty_end="2025-01-01",
        )
        row = engineer_features(load_and_validate(str(data_dir))).iloc[0]
        assert row["warranty_overlap"] == True, \
            "warranty_overlap must be True when issue_date == warranty_start (inclusive lower bound)"
        expected_remaining = (pd.Timestamp("2025-01-01") - pd.Timestamp("2020-01-01")).days
        assert abs(row["warranty_remaining_days"] - expected_remaining) < 1e-6

    def test_warranty_overlap_true_when_issue_date_equals_warranty_end(self, tmp_path):
        """issue_date == warranty_end -> warranty_overlap must be True (inclusive upper bound);
        warranty_remaining_days must be 0."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "we_eq"
        data_dir.mkdir()
        _make_minimal_csv_scaffold(
            data_dir,
            issue_date="2025-01-01",
            warranty_start="2020-01-01",
            warranty_end="2025-01-01",     # issue_date == warranty_end
        )
        row = engineer_features(load_and_validate(str(data_dir))).iloc[0]
        assert row["warranty_overlap"] == True, \
            "warranty_overlap must be True when issue_date == warranty_end (inclusive upper bound)"
        assert row["warranty_remaining_days"] == 0, \
            "warranty_remaining_days must be 0 when issue_date == warranty_end"


class TestMoratoriumViolatedBoundaryDates:
    """moratorium_violated must be True when issue_date equals moratorium_start or moratorium_end.
    Prompt: 'boolean indicating whether the permit's issue_date falls between the segment's
    moratorium_start and moratorium_end' — interpreted as inclusive, consistent with
    test_moratorium_violated_true_when_in_window which uses <=.
    """

    def test_moratorium_violated_true_when_issue_date_equals_moratorium_start(self, tmp_path):
        """issue_date == moratorium_start -> moratorium_violated must be True."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "ms_eq"
        data_dir.mkdir()
        _make_minimal_csv_scaffold(
            data_dir,
            issue_date="2021-06-01",
            moratorium_start="2021-06-01",   # issue_date == moratorium_start
            moratorium_end="2023-06-01",
        )
        row = engineer_features(load_and_validate(str(data_dir))).iloc[0]
        assert row["moratorium_violated"] == True, \
            "moratorium_violated must be True when issue_date == moratorium_start (inclusive bound)"

    def test_moratorium_violated_true_when_issue_date_equals_moratorium_end(self, tmp_path):
        """issue_date == moratorium_end -> moratorium_violated must be True."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "me_eq"
        data_dir.mkdir()
        _make_minimal_csv_scaffold(
            data_dir,
            issue_date="2023-06-01",
            moratorium_start="2021-06-01",
            moratorium_end="2023-06-01",    # issue_date == moratorium_end
        )
        row = engineer_features(load_and_validate(str(data_dir))).iloc[0]
        assert row["moratorium_violated"] == True, \
            "moratorium_violated must be True when issue_date == moratorium_end (inclusive bound)"


class TestHasOverlayFutureDate:
    """has_overlay must be False (and days_since_overlay NaN) when the segment's
    overlay_date exists but is strictly after the permit's issue_date.
    Prompt: 'True when the segment has been overlaid before the permit was issued, False otherwise'
    and 'Set to NaN when has_overlay is False (i.e., when ... the overlay date is after the
    permit's issue_date).'
    """

    def test_has_overlay_false_when_overlay_date_is_after_issue_date(self, tmp_path):
        """Segment overlay on 2025-01-01 is in the future relative to permit issued 2020-01-01.
        has_overlay must be False; days_since_overlay must be NaN."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "future_overlay"
        data_dir.mkdir()
        _make_minimal_csv_scaffold(
            data_dir,
            overlay_date="2025-01-01",   # overlay AFTER issue_date
            issue_date="2020-01-01",
        )
        row = engineer_features(load_and_validate(str(data_dir))).iloc[0]
        assert row["has_overlay"] == False, \
            "has_overlay must be False when overlay_date is after issue_date"
        assert pd.isna(row["days_since_overlay"]), \
            "days_since_overlay must be NaN when has_overlay is False (overlay_date after issue_date)"


class TestHasOverlayEqualityBoundary:
    """has_overlay must be True when overlay_date == issue_date, and days_since_overlay must be 0.
    Prompt: 'True when the segment has a non-null overlay_date that is on or before the
    permit's issue_date.' — 'on or before' is inclusive.
    """

    def test_has_overlay_true_when_overlay_date_equals_issue_date(self, tmp_path):
        """overlay_date == issue_date -> has_overlay must be True; days_since_overlay must be 0."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "overlay_eq"
        data_dir.mkdir()
        _make_minimal_csv_scaffold(
            data_dir,
            overlay_date="2020-06-01",   # overlay_date == issue_date
            issue_date="2020-06-01",
        )
        row = engineer_features(load_and_validate(str(data_dir))).iloc[0]
        assert row["has_overlay"] == True, \
            "has_overlay must be True when overlay_date == issue_date (inclusive 'on or before' bound)"
        assert row["days_since_overlay"] == 0, \
            "days_since_overlay must be 0 when overlay_date == issue_date"


class TestMoratoriumViolatedFalseOutsideWindow:
    """moratorium_violated must be False when a segment has valid (non-null) moratorium dates
    but the permit's issue_date falls outside the window.
    Prompt: 'boolean indicating whether the permit's issue_date falls between the segment's
    moratorium_start and moratorium_end.'
    """

    def test_moratorium_violated_false_when_issue_date_before_moratorium_start(self, tmp_path):
        """issue_date clearly before moratorium_start with both moratorium dates non-null ->
        moratorium_violated must be False."""
        from pipeline import load_and_validate, engineer_features
        data_dir = tmp_path / "mvi_before"
        data_dir.mkdir()
        _make_minimal_csv_scaffold(
            data_dir,
            issue_date="2019-01-01",         # well before moratorium window
            moratorium_start="2021-06-01",
            moratorium_end="2023-06-01",
        )
        row = engineer_features(load_and_validate(str(data_dir))).iloc[0]
        assert row["moratorium_violated"] == False, (
            "moratorium_violated must be False when issue_date is before moratorium_start, "
            "even when both moratorium dates are non-null"
        )


class TestCoordinationLeadDaysDualKeyJoin:
    """coordination_lead_days must join coordination_notices on BOTH permittee_id AND permit_id.
    Prompt: 'days between the coordination notice date and the project start date for the
    same permittee and permit.'
    A notice sharing a permit_id but belonging to a different permittee must be excluded.
    """

    def test_coordination_lead_days_uses_both_permittee_and_permit_id(self, tmp_path):
        """N1 matches (PT1, P1): lead_days = 14.
        N2 has same permit_id=P1 but permittee_id=PT2: must be excluded from PT1/P1.
        Correct result: 14. Wrong result (permit_id join only): mean(14, 30) = 22."""
        from pipeline import load_and_validate, engineer_features

        data_dir = tmp_path / "dual_key"
        data_dir.mkdir()

        pd.DataFrame({
            "segment_id": ["S1"], "corridor_name": ["CorA"],
            "pavement_install_date": ["2010-01-01"],
            "overlay_date": [None], "moratorium_start": [None], "moratorium_end": [None],
        }).to_csv(data_dir / "street_segments.csv", index=False)

        pd.DataFrame({
            "permit_id": ["P1"], "permittee_id": ["PT1"], "street_segment_id": ["S1"],
            "issue_date": ["2020-03-01"],
            "excavation_purpose": ["utility_install"], "restoration_scope": ["full"],
            "traffic_control_plan_adequate": [True],
            "warranty_start": ["2019-01-01"], "warranty_end": ["2023-01-01"],
        }).to_csv(data_dir / "permits.csv", index=False)

        pd.DataFrame({
            "permittee_id": ["PT1", "PT2"],
            "name": ["Alpha Corp", "Beta Inc"],
            "type": ["utility", "contractor"],
        }).to_csv(data_dir / "permittees.csv", index=False)

        pd.DataFrame({
            "inspection_id": ["I1"], "permit_id": ["P1"], "inspection_date": ["2020-04-01"],
            "backfill_accepted": [True], "base_course_accepted": [True],
            "surface_restoration_accepted": [True],
        }).to_csv(data_dir / "inspections.csv", index=False)

        # N1: correct match — (PT1, P1) -> lead_days = 14
        # N2: mismatched permittee — (PT2, P1) -> must NOT contribute to PT1/P1 lead_days
        pd.DataFrame({
            "notice_id": ["N1", "N2"],
            "permittee_id": ["PT1", "PT2"],
            "permit_id": ["P1", "P1"],
            "notice_date": ["2020-01-01", "2020-01-01"],
            "project_start_date": ["2020-01-15", "2020-01-31"],  # 14 days vs 30 days
        }).to_csv(data_dir / "coordination_notices.csv", index=False)

        for fname, cols in [
            ("settlement_failures.csv", ["failure_id", "permit_id", "failure_date", "severity"]),
            ("fee_assessments.csv",     ["assessment_id", "permittee_id", "permit_id", "amount", "date"]),
            ("bond_claims.csv",         ["claim_id", "permittee_id", "permit_id", "claim_amount", "claim_date", "resolved"]),
        ]:
            pd.DataFrame(columns=cols).to_csv(data_dir / fname, index=False)

        feature_df = engineer_features(load_and_validate(str(data_dir)))
        row = feature_df[feature_df["permit_id"] == "P1"].iloc[0]

        assert abs(row["coordination_lead_days"] - 14) < 1e-6, (
            f"coordination_lead_days for PT1/P1 must be 14 days (only N1 matches both "
            f"permittee_id=PT1 AND permit_id=P1). Got {row['coordination_lead_days']:.1f} — "
            f"a value of 22 indicates the join was done on permit_id alone."
        )
