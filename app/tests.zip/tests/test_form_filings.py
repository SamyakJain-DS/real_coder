import uuid
import pytest
from conftest import create_insurer


ALL_REQUIRED_BENEFITS = {
    "mental_health_parity": True,
    "maternity_coverage": True,
    "preventive_care": True,
    "prescription_drug": True,
    "emergency_services": True,
    "pediatric_dental": True,
    "pediatric_vision": True,
    "rehabilitative_services": True,
    "laboratory_services": True,
    "chronic_disease_management": True,
}


def create_form_filing(client, insurer_id, checklist=None, **overrides):
    payload = {
        "insurer_id": insurer_id,
        "form_type": "policy",
        "product_type": "individual",
        "submission_date": "2024-06-01",
        "mandated_benefits_checklist": checklist if checklist is not None else dict(ALL_REQUIRED_BENEFITS),
    }
    payload.update(overrides)
    return client.post("/api/form-filings", json=payload)


class TestCreateFormFiling:
    def test_create_form_filing_success(self, client):
        insurer = create_insurer(client).json()
        resp = create_form_filing(client, insurer["insurer_id"])
        assert resp.status_code == 201

    def test_create_form_filing_returns_fields(self, client):
        insurer = create_insurer(client).json()
        resp = create_form_filing(client, insurer["insurer_id"])
        data = resp.json()
        assert "form_filing_id" in data
        assert isinstance(data["form_filing_id"], str)
        uuid.UUID(data["form_filing_id"])  # raises ValueError if not a valid UUID
        assert data["status"] == "received"
        assert data["insurer_id"] == insurer["insurer_id"]
        assert data["form_type"] == "policy"
        assert data["product_type"] == "individual"
        assert data["submission_date"] == "2024-06-01"
        assert "mandated_benefits_checklist" in data

    def test_create_form_filing_nonexistent_insurer(self, client):
        resp = create_form_filing(client, "nonexistent-id")
        assert resp.status_code == 404

    def test_create_form_filing_rejected_for_suspended_insurer(self, client):
        insurer = create_insurer(client, state_license_status="suspended").json()
        resp = create_form_filing(client, insurer["insurer_id"])
        assert resp.status_code == 400

    def test_create_form_filing_rejected_for_revoked_insurer(self, client):
        insurer = create_insurer(client, state_license_status="revoked").json()
        resp = create_form_filing(client, insurer["insurer_id"])
        assert resp.status_code == 400


class TestFormFilingComplianceReview:
    def test_review_all_compliant_approved(self, client):
        insurer = create_insurer(client).json()
        form = create_form_filing(client, insurer["insurer_id"]).json()
        resp = client.post(f"/api/form-filings/{form['form_filing_id']}/review")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "approved"

    def test_review_missing_benefit_rejected(self, client):
        insurer = create_insurer(client).json()
        checklist = dict(ALL_REQUIRED_BENEFITS)
        del checklist["pediatric_dental"]
        form = create_form_filing(client, insurer["insurer_id"], checklist=checklist).json()
        resp = client.post(f"/api/form-filings/{form['form_filing_id']}/review")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "rejected"
        assert "pediatric_dental" in data["missing_benefits"]

    def test_review_benefit_set_false_rejected(self, client):
        insurer = create_insurer(client).json()
        checklist = dict(ALL_REQUIRED_BENEFITS)
        checklist["mental_health_parity"] = False
        form = create_form_filing(client, insurer["insurer_id"], checklist=checklist).json()
        resp = client.post(f"/api/form-filings/{form['form_filing_id']}/review")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "rejected"
        assert "mental_health_parity" in data["missing_benefits"]

    def test_review_multiple_deficient_benefits(self, client):
        insurer = create_insurer(client).json()
        checklist = dict(ALL_REQUIRED_BENEFITS)
        del checklist["preventive_care"]
        checklist["laboratory_services"] = False
        form = create_form_filing(client, insurer["insurer_id"], checklist=checklist).json()
        resp = client.post(f"/api/form-filings/{form['form_filing_id']}/review")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "rejected"
        missing = data["missing_benefits"]
        assert "preventive_care" in missing
        assert "laboratory_services" in missing

    def test_review_form_filing_not_found(self, client):
        resp = client.post("/api/form-filings/nonexistent-id/review")
        assert resp.status_code == 404


class TestGetFormFilings:
    def test_get_all_form_filings_returns_list(self, client):
        resp = client.get("/api/form-filings")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_get_form_filings_by_insurer(self, client):
        ins1 = create_insurer(client).json()
        ins2 = create_insurer(client).json()
        create_form_filing(client, ins1["insurer_id"])
        create_form_filing(client, ins2["insurer_id"])
        resp = client.get(f"/api/form-filings?insurer_id={ins1['insurer_id']}")
        assert resp.status_code == 200
        forms = resp.json()
        assert len(forms) == 1
        assert forms[0]["insurer_id"] == ins1["insurer_id"]
