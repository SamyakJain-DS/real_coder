import csv
from pathlib import Path

import pandas as pd
import pytest


def _write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _minimal_valid_rows() -> list[dict[str, object]]:
    return [
        {
            "journey_id": "J1",
            "touchpoint_index": 0,
            "channel": "Email",
            "touchpoint_ts": "2026-01-01T00:00:00Z",
            "converted": 1,
        }
    ]


def test_load_requires_journey_id_column(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    for r in rows:
        r.pop("journey_id")
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_requires_touchpoint_index_column(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    for r in rows:
        r.pop("touchpoint_index")
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_requires_channel_column(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    for r in rows:
        r.pop("channel")
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_requires_touchpoint_ts_column(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    for r in rows:
        r.pop("touchpoint_ts")
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_requires_converted_column(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    for r in rows:
        r.pop("converted")
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_rejects_blank_channel_after_trimming(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    rows[0]["channel"] = "   "
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_rejects_touchpoint_index_that_is_not_integer(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    rows[0]["touchpoint_index"] = 0.5
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_rejects_negative_touchpoint_index(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    rows[0]["touchpoint_index"] = -1
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_rejects_duplicate_touchpoint_index_within_journey(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = [
        {
            "journey_id": "J1",
            "touchpoint_index": 0,
            "channel": "Email",
            "touchpoint_ts": "2026-01-01T00:00:00Z",
            "converted": 1,
        },
        {
            "journey_id": "J1",
            "touchpoint_index": 0,
            "channel": "Search",
            "touchpoint_ts": "2026-01-01T01:00:00Z",
            "converted": 1,
        },
    ]
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_rejects_non_contiguous_touchpoint_index_set(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = [
        {
            "journey_id": "J1",
            "touchpoint_index": 0,
            "channel": "Email",
            "touchpoint_ts": "2026-01-01T00:00:00Z",
            "converted": 1,
        },
        {
            "journey_id": "J1",
            "touchpoint_index": 2,
            "channel": "Search",
            "touchpoint_ts": "2026-01-01T01:00:00Z",
            "converted": 1,
        },
    ]
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_rejects_inconsistent_converted_within_journey(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = [
        {
            "journey_id": "J1",
            "touchpoint_index": 0,
            "channel": "Email",
            "touchpoint_ts": "2026-01-01T00:00:00Z",
            "converted": 0,
        },
        {
            "journey_id": "J1",
            "touchpoint_index": 1,
            "channel": "Search",
            "touchpoint_ts": "2026-01-01T01:00:00Z",
            "converted": 1,
        },
    ]
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_rejects_converted_value_outside_0_or_1(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    rows[0]["converted"] = 2
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_rejects_converted_value_that_is_not_integer(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    rows[0]["converted"] = 0.2
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_rejects_touchpoint_ts_without_timezone_offset(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    rows[0]["touchpoint_ts"] = "2026-01-01T00:00:00"
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))


def test_load_converts_offset_timestamp_to_utc(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    rows[0]["touchpoint_ts"] = "2026-01-01T05:30:00+05:30"
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    out = mod.load_journey_events_csv(str(p))
    assert out.loc[0, "touchpoint_ts"] == pd.Timestamp("2026-01-01T00:00:00Z")


def test_load_sorts_events_by_journey_id_and_touchpoint_index(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = [
        {
            "journey_id": "J2",
            "touchpoint_index": 1,
            "channel": "Email",
            "touchpoint_ts": "2026-01-01T01:00:00Z",
            "converted": 0,
        },
        {
            "journey_id": "J1",
            "touchpoint_index": 0,
            "channel": "Search",
            "touchpoint_ts": "2026-01-01T00:00:00Z",
            "converted": 1,
        },
        {
            "journey_id": "J2",
            "touchpoint_index": 0,
            "channel": "Direct",
            "touchpoint_ts": "2026-01-01T00:30:00Z",
            "converted": 0,
        },
    ]
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    out = mod.load_journey_events_csv(str(p))
    assert out.loc[:, ["journey_id", "touchpoint_index"]].to_dict("records") == [
        {"journey_id": "J1", "touchpoint_index": 0},
        {"journey_id": "J2", "touchpoint_index": 0},
        {"journey_id": "J2", "touchpoint_index": 1},
    ]


def test_load_wraps_unparseable_touchpoint_ts_as_valueerror(import_or_fail, tmp_path):
    mod = import_or_fail("app.io")
    rows = _minimal_valid_rows()
    rows[0]["touchpoint_ts"] = "not-a-date"
    p = tmp_path / "events.csv"
    _write_csv(p, rows)
    with pytest.raises(ValueError):
        mod.load_journey_events_csv(str(p))