"""Tests for the value-level guarantees of the ``rank_donors`` output."""

import numpy as np
import pandas as pd
import pytest


def test_prob_next_gift_is_clipped_to_unit_interval(ranked):
    """``prob_next_gift`` values lie within the closed interval [0, 1]."""

    assert (ranked["prob_next_gift"] >= 0.0).all()
    assert (ranked["prob_next_gift"] <= 1.0).all()


def test_expected_next_gift_amount_is_non_negative(ranked):
    """``expected_next_gift_amount`` is clipped to a minimum of 0.0."""

    assert (ranked["expected_next_gift_amount"] >= 0.0).all()


def test_expected_next_30_day_revenue_equals_product(ranked):
    """``expected_next_30_day_revenue`` equals the per-row product of
    ``prob_next_gift`` and ``expected_next_gift_amount``."""

    expected = ranked["prob_next_gift"] * ranked["expected_next_gift_amount"]
    pd.testing.assert_series_equal(
        ranked["expected_next_30_day_revenue"], expected, check_names=False
    )


@pytest.mark.parametrize("threshold", [0.0, 0.5, 1.5, 2.5, 5.0])
def test_is_over_solicited_uses_configured_threshold(
    DonorPipeline, sample_donations, threshold
):
    """``is_over_solicited`` respects the threshold actually passed to
    the constructor - not a hardcoded 1.5. Parametrising across
    thresholds rules out implementations that store the value but
    compare against a literal default."""

    pipeline = DonorPipeline(saturation_threshold=threshold).fit(sample_donations)
    out = pipeline.rank_donors(sample_donations)

    expected_flags = out["saturation_score"] > threshold
    pd.testing.assert_series_equal(
        out["is_over_solicited"], expected_flags, check_names=False
    )


def test_is_over_solicited_is_strict_greater_than_at_threshold_equality(
    DonorPipeline, sample_donations, make_donations
):
    """The comparison is **strict** ``>``, not ``>=``: a donor whose
    ``saturation_score`` is exactly equal to ``saturation_threshold``
    must yield ``is_over_solicited == False``.

    We engineer the equality by adding a same-day donor with three
    donations on a single date inside the recent 90-day window. The
    same-day rule sets ``saturation_score == recent_count == 3.0``, so
    constructing the pipeline with ``saturation_threshold == 3.0``
    produces an exact tie. A bumped threshold of ``2.999`` then
    confirms the flag flips to ``True`` once the score is strictly
    greater, ruling out implementations that always return ``False``.
    """

    same_day = pd.Timestamp("2024-10-22")
    extras = make_donations(
        [
            {
                "donor_id": "EQ_DONOR",
                "donation_amount": amount,
                "date": same_day,
                "campaign": "fall",
                "channel": "email",
            }
            for amount in (25.0, 50.0, 75.0)
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    eq_pipeline = DonorPipeline(saturation_threshold=3.0).fit(df)
    eq_out = eq_pipeline.rank_donors(df)
    eq_row = eq_out.loc[eq_out["donor_id"] == "EQ_DONOR"].iloc[0]
    assert eq_row["saturation_score"] == pytest.approx(3.0)
    assert bool(eq_row["is_over_solicited"]) is False, (
        "saturation_score == saturation_threshold must NOT be flagged "
        "(comparison is strict >, not >=)."
    )

    over_pipeline = DonorPipeline(saturation_threshold=2.999).fit(df)
    over_out = over_pipeline.rank_donors(df)
    over_row = over_out.loc[over_out["donor_id"] == "EQ_DONOR"].iloc[0]
    assert over_row["saturation_score"] == pytest.approx(3.0)
    assert bool(over_row["is_over_solicited"]) is True, (
        "saturation_score strictly greater than the threshold must be "
        "flagged True (this also rules out a constant-False bug)."
    )


def test_predictions_use_persisted_feature_matrix_not_rank_donors_data(
    DonorPipeline, sample_donations, make_donations
):
    """req 32: ``rank_donors`` uses the **persisted** feature matrix
    together with the persisted estimators - features are NOT
    recomputed from the donations passed at call time.

    Strategy: fit on ``sample_donations``, then call ``rank_donors``
    twice - once with the same DataFrame and once with an augmented
    DataFrame that adds a substantial extra historical donation for
    donor ``F001``. A donor's ``monetary_total``, ``frequency`` and
    channel-share features all change under the augmented data, so an
    implementation that recomputes features at rank-time would emit
    visibly different ``prob_next_gift`` and
    ``expected_next_gift_amount`` values for ``F001``. A conformant
    implementation reuses the persisted feature matrix and emits the
    identical baseline values.
    """

    pipeline = DonorPipeline().fit(sample_donations)
    out_baseline = pipeline.rank_donors(sample_donations)

    extras = make_donations(
        [
            {
                "donor_id": "F001",
                "donation_amount": 5000.0,
                "date": pd.Timestamp("2024-10-15"),
                "campaign": "fall",
                "channel": "email",
            }
        ]
    )
    augmented = pd.concat([sample_donations, extras], ignore_index=True)
    out_augmented = pipeline.rank_donors(augmented)

    base_row = out_baseline.loc[out_baseline["donor_id"] == "F001"].iloc[0]
    aug_row = out_augmented.loc[out_augmented["donor_id"] == "F001"].iloc[0]

    assert base_row["prob_next_gift"] == aug_row["prob_next_gift"], (
        "F001's prob_next_gift must be invariant to extra donations passed "
        "at rank-time: rank_donors must reuse the persisted feature matrix."
    )
    assert (
        base_row["expected_next_gift_amount"]
        == aug_row["expected_next_gift_amount"]
    ), (
        "F001's expected_next_gift_amount must be invariant to extra donations "
        "passed at rank-time for the same reason."
    )


def test_rank_donors_returns_only_donors_from_persisted_feature_matrix(
    DonorPipeline, sample_donations, make_donations
):
    """req 34: the ``donor_id`` output column carries the donors from
    the persisted feature matrix - donors that appear *only* in the
    DataFrame passed to ``rank_donors`` must NOT show up in the output,
    even when they would otherwise be eligible (first donation
    ``<= as_of_date``). This rules out implementations that derive the
    output donor set from the rank-time donations DataFrame.
    """

    pipeline = DonorPipeline().fit(sample_donations)
    new_donor = make_donations(
        [
            {
                "donor_id": "BRAND_NEW",
                "donation_amount": 100.0,
                "date": pd.Timestamp("2024-09-15"),
                "campaign": "fall",
                "channel": "email",
            }
        ]
    )
    augmented = pd.concat([sample_donations, new_donor], ignore_index=True)

    out = pipeline.rank_donors(augmented)
    assert "BRAND_NEW" not in out["donor_id"].values, (
        "BRAND_NEW was not seen at fit time and therefore must not appear in "
        "the ranking output, regardless of being present in the rank_donors "
        "donations DataFrame."
    )


def test_predictions_match_models_applied_to_persisted_feature_matrix(
    DonorPipeline,
    deterministic_donations,
    locate_feature_matrix,
    feature_donor_ids,
    feature_only,
):
    """``prob_next_gift`` equals ``probability_model.predict_proba(X)[:, 1]``
    clipped to ``[0, 1]`` on the persisted feature matrix, and
    ``expected_next_gift_amount`` equals ``amount_model.predict(X)``
    clipped to ``>= 0``.

    This pins three requirements at once:

    * 32 - ``rank_donors`` uses the *persisted* feature matrix
      together with the persisted estimators, not freshly recomputed
      features.
    * 35 - ``prob_next_gift`` selects the **positive** class column
      ``[:, 1]``. An implementation that selected ``[:, 0]`` would
      produce values ``1 - p`` which would not match the reference.
    * 36 - ``expected_next_gift_amount`` is exactly the (clipped)
      ``predict`` output on that same matrix.
    """

    pipeline = DonorPipeline().fit(deterministic_donations)
    fm = locate_feature_matrix(pipeline)
    X = feature_only(fm).to_numpy()
    donor_ids = feature_donor_ids(fm)

    expected_proba = np.clip(
        pipeline.probability_model.predict_proba(X)[:, 1], 0.0, 1.0
    )
    expected_amount = np.clip(pipeline.amount_model.predict(X), 0.0, None)

    out = pipeline.rank_donors(deterministic_donations)
    aligned = out.set_index("donor_id").reindex(donor_ids)

    np.testing.assert_allclose(
        aligned["prob_next_gift"].to_numpy(),
        expected_proba,
        rtol=1e-9,
        atol=1e-12,
    )
    np.testing.assert_allclose(
        aligned["expected_next_gift_amount"].to_numpy(),
        expected_amount,
        rtol=1e-9,
        atol=1e-12,
    )
