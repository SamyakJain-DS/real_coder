import pytest
import requests
from datetime import datetime


BASE_URL = "http://localhost:3000"


def _make_safe(original_fn):
    """Wrap a requests method so ConnectionError/Timeout raises AssertionError instead.
    
    AssertionError raised inside a test body produces FAILED status.
    ConnectionError raised inside a test body produces ERROR status.
    This wrapper ensures an unreachable server always yields FAILED.
    """
    def safe(*args, **kwargs):
        try:
            return original_fn(*args, **kwargs)
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            raise AssertionError("Server is not reachable on localhost:3000")
    return safe


@pytest.fixture(autouse=True)
def _patch_requests():
    """Patch requests methods for every test so network failures = FAILED not ERROR."""
    orig_get  = requests.get
    orig_post = requests.post
    orig_put  = requests.put
    requests.get  = _make_safe(orig_get)
    requests.post = _make_safe(orig_post)
    requests.put  = _make_safe(orig_put)
    yield
    requests.get  = orig_get
    requests.post = orig_post
    requests.put  = orig_put


@pytest.fixture(scope="module")
def server():
    """Return the base URL. Connectivity is handled by _patch_requests."""
    return BASE_URL


def test_get_trips_returns_200(server):
    """GET /api/trips returns HTTP 200 with an array of trip objects."""
    response = requests.get(f"{server}/api/trips")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)


def test_get_trips_includes_status_field(server):
    """Each trip object includes a status field with value 'upcoming' or 'completed'."""
    response = requests.get(f"{server}/api/trips")
    data = response.json()
    assert len(data) > 0, "Sample data must include at least one trip"
    for trip in data:
        assert "status" in trip
        assert trip["status"] in ["upcoming", "completed"]


def test_get_trips_includes_required_fields(server):
    """Each trip includes id, activityType, date, guideName, difficulty, groupSizeLimit, price, description."""
    response = requests.get(f"{server}/api/trips")
    data = response.json()
    assert len(data) > 0
    required_fields = ["id", "activityType", "date", "guideName", "difficulty",
                       "groupSizeLimit", "price", "description", "status"]
    for trip in data:
        for field in required_fields:
            assert field in trip, f"Trip must include {field}"


def test_sample_data_includes_upcoming_trip(server):
    """Sample data contains at least one upcoming trip (date >= current date)."""
    response = requests.get(f"{server}/api/trips")
    data = response.json()
    upcoming_trips = [t for t in data if t["status"] == "upcoming"]
    assert len(upcoming_trips) >= 1, "Sample data must include at least one upcoming trip"


def test_sample_data_includes_completed_trip(server):
    """Sample data contains at least one completed trip (date < current date)."""
    response = requests.get(f"{server}/api/trips")
    data = response.json()
    completed_trips = [t for t in data if t["status"] == "completed"]
    assert len(completed_trips) >= 1, "Sample data must include at least one completed trip"


def test_trip_status_classification_upcoming(server):
    """Trip with date >= current date has status 'upcoming'."""
    response = requests.get(f"{server}/api/trips")
    data = response.json()
    today = datetime.now().date()
    for trip in data:
        trip_date = datetime.strptime(trip["date"], "%Y-%m-%d").date()
        if trip_date >= today:
            assert trip["status"] == "upcoming", \
                f"Trip with date {trip['date']} must have status 'upcoming'"


def test_trip_status_classification_completed(server):
    """Trip with date < current date has status 'completed'."""
    response = requests.get(f"{server}/api/trips")
    data = response.json()
    today = datetime.now().date()
    for trip in data:
        trip_date = datetime.strptime(trip["date"], "%Y-%m-%d").date()
        if trip_date < today:
            assert trip["status"] == "completed", \
                f"Trip with date {trip['date']} must have status 'completed'"


def test_create_booking_for_upcoming_trip_succeeds(server):
    """POST /api/bookings creates a booking for an upcoming trip when all required fields are present and waiver is true."""
    response = requests.get(f"{server}/api/trips")
    trips = response.json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)
    assert upcoming_trip is not None, "Need at least one upcoming trip for this test"

    booking_data = {
        "tripId": upcoming_trip["id"],
        "customerName": "Test Customer",
        "email": "test@example.com",
        "groupSize": 2,
        "waiverAcknowledged": True
    }
    response = requests.post(f"{server}/api/bookings", json=booking_data)
    assert response.status_code == 201
    result = response.json()
    assert "bookingId" in result


def test_create_booking_with_optional_fields(server):
    """POST /api/bookings accepts optional dietaryNotes and medicalNotes."""
    response = requests.get(f"{server}/api/trips")
    trips = response.json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)
    assert upcoming_trip is not None

    booking_data = {
        "tripId": upcoming_trip["id"],
        "customerName": "Test Customer",
        "email": "test@example.com",
        "groupSize": 1,
        "dietaryNotes": "Vegetarian",
        "medicalNotes": "None",
        "waiverAcknowledged": True
    }
    response = requests.post(f"{server}/api/bookings", json=booking_data)
    assert response.status_code == 201
    result = response.json()
    assert "bookingId" in result


def test_create_booking_rejects_when_waiver_false(server):
    """POST /api/bookings returns HTTP 400 when waiverAcknowledged is false."""
    response = requests.get(f"{server}/api/trips")
    trips = response.json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)
    assert upcoming_trip is not None

    booking_data = {
        "tripId": upcoming_trip["id"],
        "customerName": "Test Customer",
        "email": "test@example.com",
        "groupSize": 2,
        "waiverAcknowledged": False
    }
    response = requests.post(f"{server}/api/bookings", json=booking_data)
    assert response.status_code == 400
    result = response.json()
    assert "error" in result


@pytest.mark.parametrize("missing_field", ["customerName", "email", "groupSize"])
def test_create_booking_rejects_missing_required_fields(server, missing_field):
    """POST /api/bookings returns HTTP 400 when any required field is missing."""
    trips = requests.get(f"{server}/api/trips").json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)
    assert upcoming_trip is not None

    booking_data = {
        "tripId": upcoming_trip["id"],
        "customerName": "Test Customer",
        "email": "test@example.com",
        "groupSize": 2,
        "waiverAcknowledged": True
    }
    del booking_data[missing_field]

    response = requests.post(f"{server}/api/bookings", json=booking_data)
    assert response.status_code == 400
    assert "error" in response.json()


def test_create_booking_rejects_completed_trip(server):
    """POST /api/bookings returns HTTP 400 when attempting to book a completed trip."""
    response = requests.get(f"{server}/api/trips")
    trips = response.json()
    completed_trip = next((t for t in trips if t["status"] == "completed"), None)
    assert completed_trip is not None, "Need at least one completed trip for this test"

    booking_data = {
        "tripId": completed_trip["id"],
        "customerName": "Test Customer",
        "email": "test@example.com",
        "groupSize": 2,
        "waiverAcknowledged": True
    }
    response = requests.post(f"{server}/api/bookings", json=booking_data)
    assert response.status_code == 400
    result = response.json()
    assert "error" in result


def test_get_pending_bookings_returns_200(server):
    """GET /api/bookings/pending returns HTTP 200 with an array of booking objects."""
    response = requests.get(f"{server}/api/bookings/pending")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)


def test_get_pending_bookings_includes_required_fields(server):
    """Each booking object includes id, tripId, customerName, email, groupSize, dietaryNotes, medicalNotes."""
    response = requests.get(f"{server}/api/trips")
    trips = response.json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)

    if upcoming_trip:
        booking_data = {
            "tripId": upcoming_trip["id"],
            "customerName": "Pending Test",
            "email": "pending@example.com",
            "groupSize": 1,
            "dietaryNotes": "None",
            "medicalNotes": "Asthma",
            "waiverAcknowledged": True
        }
        requests.post(f"{server}/api/bookings", json=booking_data)

    response = requests.get(f"{server}/api/bookings/pending")
    data = response.json()
    assert len(data) >= 1, "At least one pending booking must exist"
    required_fields = ["id", "tripId", "customerName", "email",
                       "groupSize", "dietaryNotes", "medicalNotes"]
    for booking in data:
        for field in required_fields:
            assert field in booking, f"Booking must include {field}"


def test_confirm_booking_returns_200(server):
    """PUT /api/bookings/:id/confirm returns HTTP 200 with success field."""
    response = requests.get(f"{server}/api/trips")
    trips = response.json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)
    assert upcoming_trip is not None, "Need at least one upcoming trip to test booking confirmation"

    booking_data = {
        "tripId": upcoming_trip["id"],
        "customerName": "Confirm Test",
        "email": "confirm@example.com",
        "groupSize": 2,
        "waiverAcknowledged": True
    }
    create_response = requests.post(f"{server}/api/bookings", json=booking_data)
    assert create_response.status_code == 201, "Booking creation must succeed before confirmation can be tested"

    booking_id = create_response.json()["bookingId"]
    confirm_response = requests.put(f"{server}/api/bookings/{booking_id}/confirm")
    assert confirm_response.status_code == 200
    assert "success" in confirm_response.json()


def test_create_review_rejects_upcoming_trip(server):
    """POST /api/reviews returns HTTP 400 when attempting to review an upcoming trip."""
    response = requests.get(f"{server}/api/trips")
    trips = response.json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)
    assert upcoming_trip is not None, "Need at least one upcoming trip for this test"

    review_data = {
        "tripId": upcoming_trip["id"],
        "rating": 5,
        "reviewText": "Cannot review future trip",
        "email": "anyone@example.com"
    }
    response = requests.post(f"{server}/api/reviews", json=review_data)
    assert response.status_code == 400
    result = response.json()
    assert "error" in result


def test_get_reviews_returns_200(server):
    """GET /api/reviews?tripId=X returns HTTP 200 with an array of review objects."""
    response = requests.get(f"{server}/api/trips")
    trips = response.json()
    completed_trip = next((t for t in trips if t["status"] == "completed"), None)
    assert completed_trip is not None, "Sample data must include at least one completed trip"

    response = requests.get(f"{server}/api/reviews?tripId={completed_trip['id']}")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)


def test_get_reviews_includes_required_fields(server):
    """Each review object includes id, tripId, rating, reviewText."""
    trips = {t["id"]: t for t in requests.get(f"{server}/api/trips").json()}
    confirmed = requests.get(f"{server}/api/bookings/confirmed").json()

    booking = next(
        (b for b in confirmed if trips.get(b["tripId"], {}).get("status") == "completed"),
        None
    )
    assert booking is not None, "Need at least one confirmed booking for a completed trip"

    review_data = {
        "tripId": booking["tripId"],
        "rating": 4,
        "reviewText": "Great trip",
        "email": booking["email"]
    }
    requests.post(f"{server}/api/reviews", json=review_data)

    response = requests.get(f"{server}/api/reviews?tripId={booking['tripId']}")
    data = response.json()
    assert len(data) > 0, "Review must have been persisted"

    required_fields = ["id", "tripId", "rating", "reviewText"]
    for review in data:
        for field in required_fields:
            assert field in review, f"Review must include {field}"


def test_get_analytics_returns_200(server):
    """GET /api/analytics/trips returns HTTP 200 with analytics object."""
    response = requests.get(f"{server}/api/analytics/trips")
    assert response.status_code == 200
    data = response.json()
    assert "analytics" in data
    assert isinstance(data["analytics"], list)


def test_analytics_includes_required_fields(server):
    """Each analytics entry includes activityType, attendance, revenue."""
    response = requests.get(f"{server}/api/analytics/trips")
    data = response.json()
    analytics = data["analytics"]
    assert len(analytics) >= 1, "Analytics must contain at least one activity type entry"
    required_fields = ["activityType", "attendance", "revenue"]
    for entry in analytics:
        for field in required_fields:
            assert field in entry, f"Analytics entry must include {field}"


def test_analytics_aggregates_by_activity_type(server):
    """Analytics groups attendance and revenue by activity type."""
    response = requests.get(f"{server}/api/analytics/trips")
    data = response.json()
    analytics = data["analytics"]

    activity_types = [entry["activityType"] for entry in analytics]
    assert len(activity_types) == len(set(activity_types)), \
        "Each activity type should appear once in analytics"


def test_analytics_attendance_is_numeric(server):
    """Analytics attendance values are numeric."""
    response = requests.get(f"{server}/api/analytics/trips")
    data = response.json()
    for entry in data["analytics"]:
        assert isinstance(entry["attendance"], (int, float))
        assert entry["attendance"] >= 0


def test_analytics_revenue_is_numeric(server):
    """Analytics revenue values are numeric."""
    response = requests.get(f"{server}/api/analytics/trips")
    data = response.json()
    for entry in data["analytics"]:
        assert isinstance(entry["revenue"], (int, float))
        assert entry["revenue"] >= 0


def test_trip_dates_in_yyyy_mm_dd_format(server):
    """Trip dates are stored and returned in YYYY-MM-DD format."""
    response = requests.get(f"{server}/api/trips")
    data = response.json()

    for trip in data:
        date_str = trip["date"]
        try:
            parsed_date = datetime.strptime(date_str, "%Y-%m-%d")
            assert parsed_date is not None
        except ValueError:
            pytest.fail(f"Trip date {date_str} is not in YYYY-MM-DD format")

def test_sample_data_includes_all_activity_types(server):
    """Sample data must contain at least one trip for each of hiking, kayaking, and climbing."""
    response = requests.get(f"{server}/api/trips")
    data = response.json()
    activity_types = {t["activityType"].lower() for t in data}
    for required in ("hiking", "kayaking", "climbing"):
        assert required in activity_types, \
            f"Sample data must include at least one {required} trip"

def test_get_confirmed_bookings_returns_200(server):
    """GET /api/bookings/confirmed returns HTTP 200 with an array."""
    response = requests.get(f"{server}/api/bookings/confirmed")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)


def test_get_confirmed_bookings_includes_required_fields(server):
    """Each confirmed booking includes id, tripId, customerName, email, groupSize, dietaryNotes, medicalNotes."""
    response = requests.get(f"{server}/api/bookings/confirmed")
    data = response.json()
    assert len(data) >= 1, "Sample data must include at least one confirmed booking"
    required_fields = ["id", "tripId", "customerName", "email",
                       "groupSize", "dietaryNotes", "medicalNotes"]
    for booking in data:
        for field in required_fields:
            assert field in booking, f"Confirmed booking must include {field}"


def test_sample_data_includes_confirmed_booking_for_completed_trip(server):
    """Sample data contains at least one confirmed booking for a completed trip."""
    trips_response = requests.get(f"{server}/api/trips")
    completed_ids = {t["id"] for t in trips_response.json() if t["status"] == "completed"}

    confirmed_response = requests.get(f"{server}/api/bookings/confirmed")
    confirmed_bookings = confirmed_response.json()

    confirmed_for_completed = [b for b in confirmed_bookings if b["tripId"] in completed_ids]
    assert len(confirmed_for_completed) >= 1, \
        "Sample data must include at least one confirmed booking for a completed trip"


def test_confirmed_booking_appears_in_confirmed_list(server):
    """A booking confirmed via PUT /api/bookings/:id/confirm appears in GET /api/bookings/confirmed."""
    trips = requests.get(f"{server}/api/trips").json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)
    assert upcoming_trip is not None

    create_response = requests.post(f"{server}/api/bookings", json={
        "tripId": upcoming_trip["id"],
        "customerName": "Status Test",
        "email": "status@example.com",
        "groupSize": 1,
        "waiverAcknowledged": True
    })
    assert create_response.status_code == 201
    booking_id = create_response.json()["bookingId"]

    # Before confirmation - must not appear in confirmed
    confirmed_before = requests.get(f"{server}/api/bookings/confirmed").json()
    confirmed_ids_before = {b["id"] for b in confirmed_before}
    assert booking_id not in confirmed_ids_before, \
        "Newly created booking must not appear in confirmed bookings"

    # Confirm it
    confirm_response = requests.put(f"{server}/api/bookings/{booking_id}/confirm")
    assert confirm_response.status_code == 200

    # After confirmation - must appear in confirmed
    confirmed_after = requests.get(f"{server}/api/bookings/confirmed").json()
    confirmed_ids_after = {b["id"] for b in confirmed_after}
    assert booking_id in confirmed_ids_after, \
        "Confirmed booking must appear in confirmed bookings list"

def test_analytics_correctness(server):
    """Analytics attendance and revenue match values independently computed from confirmed bookings."""
    trips = {t["id"]: t for t in requests.get(f"{server}/api/trips").json()}
    completed_trips = {tid: t for tid, t in trips.items() if t["status"] == "completed"}

    confirmed_bookings = requests.get(f"{server}/api/bookings/confirmed").json()
    relevant = [b for b in confirmed_bookings if b["tripId"] in completed_trips]
    assert len(relevant) >= 1, "Need at least one confirmed booking for a completed trip"

    expected = {}
    for booking in relevant:
        trip = completed_trips[booking["tripId"]]
        activity = trip["activityType"]
        if activity not in expected:
            expected[activity] = {"attendance": 0, "revenue": 0}
        expected[activity]["attendance"] += booking["groupSize"]
        expected[activity]["revenue"] += trip["price"] * booking["groupSize"]

    analytics = {
        e["activityType"]: e
        for e in requests.get(f"{server}/api/analytics/trips").json()["analytics"]
    }

    for activity, values in expected.items():
        assert activity in analytics, f"{activity} missing from analytics"
        assert analytics[activity]["attendance"] == values["attendance"], \
            f"Attendance mismatch for {activity}"
        assert analytics[activity]["revenue"] == values["revenue"], \
            f"Revenue mismatch for {activity}"

def test_create_review_rejects_unbooked_email(server):
    """POST /api/reviews returns HTTP 400 when email has no confirmed booking for that trip."""
    trips = requests.get(f"{server}/api/trips").json()
    completed_trip = next((t for t in trips if t["status"] == "completed"), None)
    assert completed_trip is not None

    review_data = {
        "tripId": completed_trip["id"],
        "rating": 4,
        "reviewText": "Great trip",
        "email": "notareal@customer.com"
    }
    response = requests.post(f"{server}/api/reviews", json=review_data)
    assert response.status_code == 400
    assert "error" in response.json()


def test_create_review_succeeds_with_confirmed_booking_email(server):
    """POST /api/reviews succeeds when email matches a confirmed booking for that completed trip."""
    confirmed = requests.get(f"{server}/api/bookings/confirmed").json()
    trips = {t["id"]: t for t in requests.get(f"{server}/api/trips").json()}

    booking = next(
        (b for b in confirmed if trips.get(b["tripId"], {}).get("status") == "completed"),
        None
    )
    assert booking is not None, "Need at least one confirmed booking for a completed trip"

    review_data = {
        "tripId": booking["tripId"],
        "rating": 5,
        "reviewText": "Verified review",
        "email": booking["email"]
    }
    response = requests.post(f"{server}/api/reviews", json=review_data)
    assert response.status_code == 201
    assert "reviewId" in response.json()

def test_create_booking_rejects_when_group_size_exceeds_limit(server):
    """POST /api/bookings returns HTTP 400 when groupSize exceeds trip's remaining confirmed capacity."""
    trips = requests.get(f"{server}/api/trips").json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)
    assert upcoming_trip is not None

    booking_data = {
        "tripId": upcoming_trip["id"],
        "customerName": "Overflow Test",
        "email": "overflow@example.com",
        "groupSize": upcoming_trip["groupSizeLimit"] + 1,
        "waiverAcknowledged": True
    }
    response = requests.post(f"{server}/api/bookings", json=booking_data)
    assert response.status_code == 400
    assert "error" in response.json()

def test_confirm_booking_rejects_when_capacity_exceeded(server):
    """PUT /api/bookings/:id/confirm returns HTTP 400 when confirming would exceed confirmed capacity."""
    trips = requests.get(f"{server}/api/trips").json()
    upcoming_trip = next((t for t in trips if t["status"] == "upcoming"), None)
    assert upcoming_trip is not None

    trip_id = upcoming_trip["id"]
    limit = upcoming_trip["groupSizeLimit"]

    # Compute remaining confirmed capacity dynamically to avoid cross-test state issues
    confirmed = requests.get(f"{server}/api/bookings/confirmed").json()
    already_confirmed = sum(b["groupSize"] for b in confirmed if b["tripId"] == trip_id)
    remaining = limit - already_confirmed
    assert remaining >= 1, "Need at least 1 remaining confirmed slot to run this test"

    # Create first booking (pending) that fills all remaining confirmed capacity
    fill_response = requests.post(f"{server}/api/bookings", json={
        "tripId": trip_id,
        "customerName": "Fill Customer",
        "email": "fill@example.com",
        "groupSize": remaining,
        "waiverAcknowledged": True
    })
    assert fill_response.status_code == 201
    fill_id = fill_response.json()["bookingId"]

    # Create second booking (pending) of size 1 - allowed since pending bookings
    # do not count toward confirmed capacity at creation time
    overflow_response = requests.post(f"{server}/api/bookings", json={
        "tripId": trip_id,
        "customerName": "Overflow Customer",
        "email": "overflow2@example.com",
        "groupSize": 1,
        "waiverAcknowledged": True
    })
    assert overflow_response.status_code == 201
    overflow_id = overflow_response.json()["bookingId"]

    # Confirm the fill booking - this consumes all remaining confirmed capacity
    confirm_fill = requests.put(f"{server}/api/bookings/{fill_id}/confirm")
    assert confirm_fill.status_code == 200

    # Confirming the overflow booking must now be rejected
    confirm_overflow = requests.put(f"{server}/api/bookings/{overflow_id}/confirm")
    assert confirm_overflow.status_code == 400
    assert "error" in confirm_overflow.json()