import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

# -- helpers -------------------------------------------------------------------

def _make_results(tests=None, passed=0, failed=0, skipped=0, duration=1.0):
    return {
        "summary": {
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
            "duration": duration,
        },
        "tests": tests or [],
    }


def _make_test(nodeid="test_foo", outcome="passed", duration=0.1,
               longrepr="", stdout="", stderr="", reruns=None):
    return {
        "nodeid": nodeid,
        "outcome": outcome,
        "duration": duration,
        "longrepr": longrepr,
        "stdout": stdout,
        "stderr": stderr,
        "reruns": reruns if reruns is not None else [],
    }


def _make_coverage(modules=None, total=85.0):
    modules = modules or {
        "module_a.py": 90.0,
        "module_b.py": 80.0,
        "module_c.py": 75.0,
    }
    return {
        "totals": {"percent_covered": total},
        "files": {
            mod: {"summary": {"percent_covered": pct}}
            for mod, pct in modules.items()
        },
    }


# -- fixture and guard --------------------------------

@pytest.fixture
def pr_module():
    """
    Yields the pytest_report module, or None when it cannot be imported.
    The fixture itself NEVER raises - only _require() raises inside test bodies.
    """
    try:
        import pytest_report as _pr
        yield _pr
    except ImportError:
        yield None


def _require(module):
    """
    Call as the FIRST LINE of every test body.
    Raises pytest.Failed (FAILED, not ERROR) when pytest_report is not found.
    """
    if module is None:
        pytest.fail("pytest_report module not found - empty repository")


# -- CLI runner ----------------------------------------------------------------

_SCRIPT = Path(__file__).parent.parent / "pytest_report.py"


def _run_cli(args, cwd=None):
    return subprocess.run(
        [sys.executable, str(_SCRIPT)] + args,
        capture_output=True,
        text=True,
        cwd=str(cwd or Path(__file__).parent.parent),
    )


# =============================================================================
# parse_pytest_json - structure and values
# =============================================================================

class TestParsePytestJsonStructure:

    def test_summary_passed_value(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 3, "failed": 2, "skipped": 1, "duration": 7.2},
            "tests": [],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        s = pr_module.parse_pytest_json(str(p))["summary"]
        assert s["passed"] == 3

    def test_summary_failed_value(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 3, "failed": 2, "skipped": 1, "duration": 7.2},
            "tests": [],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        s = pr_module.parse_pytest_json(str(p))["summary"]
        assert s["failed"] == 2

    def test_summary_skipped_value(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 3, "failed": 2, "skipped": 1, "duration": 7.2},
            "tests": [],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        s = pr_module.parse_pytest_json(str(p))["summary"]
        assert s["skipped"] == 1

    def test_summary_duration_value(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 3, "failed": 2, "skipped": 1, "duration": 7.2},
            "tests": [],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        s = pr_module.parse_pytest_json(str(p))["summary"]
        assert abs(s["duration"] - 7.2) < 0.001

    def test_test_entry_has_nodeid(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "tests/test_x.py::test_one", "outcome": "passed", "duration": 0.1}],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        t = pr_module.parse_pytest_json(str(p))["tests"][0]
        assert t["nodeid"] == "tests/test_x.py::test_one"

    def test_test_entry_has_outcome(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 0, "failed": 1, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "failed", "duration": 0.1}],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        t = pr_module.parse_pytest_json(str(p))["tests"][0]
        assert t["outcome"] == "failed"

    def test_test_entry_has_duration(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.3},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.3}],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        t = pr_module.parse_pytest_json(str(p))["tests"][0]
        assert abs(t["duration"] - 0.3) < 0.001


class TestParsePytestJsonMissingOptionalFields:

    def test_longrepr_defaults_to_empty_string(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.1}],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        t = pr_module.parse_pytest_json(str(p))["tests"][0]
        assert t["longrepr"] == ""

    def test_stdout_defaults_to_empty_string(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.1}],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        t = pr_module.parse_pytest_json(str(p))["tests"][0]
        assert t["stdout"] == ""

    def test_stderr_defaults_to_empty_string(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.1}],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        t = pr_module.parse_pytest_json(str(p))["tests"][0]
        assert t["stderr"] == ""

    def test_reruns_defaults_to_empty_list(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.1}],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        t = pr_module.parse_pytest_json(str(p))["tests"][0]
        assert t["reruns"] == []

    def test_reruns_list_preserved_when_present(self, pr_module, tmp_path):
        _require(pr_module)
        reruns = [{"outcome": "failed"}, {"outcome": "passed"}]
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.2},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.2, "reruns": reruns}],
        }
        p = tmp_path / "r.json"
        p.write_text(json.dumps(data))
        t = pr_module.parse_pytest_json(str(p))["tests"][0]
        assert len(t["reruns"]) == 2
        assert t["reruns"][0]["outcome"] == "failed"


class TestParsePytestJsonErrors:

    def test_raises_file_not_found(self, pr_module, tmp_path):
        _require(pr_module)
        with pytest.raises(FileNotFoundError):
            pr_module.parse_pytest_json(str(tmp_path / "missing.json"))


# =============================================================================
# generate_html_report - output file
# =============================================================================

class TestGenerateHtmlReportOutput:

    def test_creates_file_at_output_path(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        pr_module.generate_html_report(_make_results(), out, None, None)
        assert os.path.exists(out)

    def test_output_is_html(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        pr_module.generate_html_report(_make_results(), out, None, None)
        content = Path(out).read_text()
        assert "<html" in content.lower() or "<!doctype" in content.lower()


# =============================================================================
# generate_html_report - test list
# =============================================================================

class TestGenerateHtmlReportTestList:

    def test_passed_test_nodeid_in_output(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        tests = [_make_test("tests/test_a.py::test_passes", "passed")]
        pr_module.generate_html_report(
            _make_results(tests=tests, passed=1), out, None, None
        )
        assert "tests/test_a.py::test_passes" in Path(out).read_text()

    def test_failed_test_nodeid_in_output(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        tests = [_make_test("tests/test_b.py::test_fails", "failed")]
        pr_module.generate_html_report(
            _make_results(tests=tests, failed=1), out, None, None
        )
        assert "tests/test_b.py::test_fails" in Path(out).read_text()

    def test_skipped_test_nodeid_in_output(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        tests = [_make_test("tests/test_c.py::test_skipped", "skipped")]
        pr_module.generate_html_report(
            _make_results(tests=tests, skipped=1), out, None, None
        )
        assert "tests/test_c.py::test_skipped" in Path(out).read_text()


# =============================================================================
# generate_html_report - expandable failure details
# =============================================================================

class TestGenerateHtmlReportFailureDetails:

    def test_traceback_in_output_for_failed_test(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        tests = [_make_test("test_fail", "failed", longrepr="AssertionError: expected True got False")]
        pr_module.generate_html_report(
            _make_results(tests=tests, failed=1), out, None, None
        )
        assert "AssertionError: expected True got False" in Path(out).read_text()

    def test_captured_stdout_in_output_for_failed_test(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        tests = [_make_test("test_fail", "failed", stdout="printed from test stdout")]
        pr_module.generate_html_report(
            _make_results(tests=tests, failed=1), out, None, None
        )
        assert "printed from test stdout" in Path(out).read_text()

    def test_captured_stderr_in_output_for_failed_test(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        tests = [_make_test("test_fail", "failed", stderr="logged to test stderr")]
        pr_module.generate_html_report(
            _make_results(tests=tests, failed=1), out, None, None
        )
        assert "logged to test stderr" in Path(out).read_text()

# =============================================================================
# generate_html_report - flakiness indicator
# =============================================================================

class TestGenerateHtmlReportFlakiness:

    def test_flaky_test_indicator_present(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        reruns = [{"outcome": "failed"}]
        tests = [_make_test("test_flaky_candidate", "passed", reruns=reruns)]
        pr_module.generate_html_report(
            _make_results(tests=tests, passed=1), out, None, None
        )
        content = Path(out).read_text()
        assert "test_flaky_candidate" in content
        assert "flak" in content.lower()


# =============================================================================
# generate_html_report - coverage section
# =============================================================================

class TestGenerateHtmlReportCoverage:

    def test_per_module_name_in_output(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        cov = _make_coverage(modules={"mypackage/utils.py": 91.0})
        pr_module.generate_html_report(_make_results(), out, cov, None)
        assert "mypackage/utils.py" in Path(out).read_text()

    def test_unique_module_absent_when_coverage_is_none(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        pr_module.generate_html_report(_make_results(), out, None, None)
        assert "unique_coverage_module_xyz_987.py" not in Path(out).read_text()


# =============================================================================
# generate_html_report - trend section
# =============================================================================

class TestGenerateHtmlReportTrend:

    def test_newly_failing_test_shown(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        current = _make_results(
            tests=[_make_test("test_regressed", "failed")], failed=1
        )
        previous = _make_results(
            tests=[_make_test("test_regressed", "passed")], passed=1
        )
        pr_module.generate_html_report(current, out, None, previous)
        assert "test_regressed" in Path(out).read_text()

    def test_skipped_to_failed_shown_in_trend(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        current = _make_results(
            tests=[_make_test("test_was_skipped", "failed")], failed=1
        )
        previous = _make_results(
            tests=[_make_test("test_was_skipped", "skipped")], skipped=1
        )
        pr_module.generate_html_report(current, out, None, previous)
        assert "test_was_skipped" in Path(out).read_text()

    def test_brand_new_failed_test_shown_in_trend(self, pr_module, tmp_path):
        _require(pr_module)
        out = str(tmp_path / "report.html")
        current = _make_results(
            tests=[
                _make_test("test_existing", "passed"),
                _make_test("test_brand_new", "failed"),
            ],
            passed=1, failed=1,
        )
        previous = _make_results(
            tests=[_make_test("test_existing", "passed")],
            passed=1,
        )
        pr_module.generate_html_report(current, out, None, previous)
        assert "test_brand_new" in Path(out).read_text()


# =============================================================================
# CLI - exit codes and error handling
# =============================================================================

class TestCLIExitCodes:

    def test_exit_0_on_success_with_from_json(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.1}],
        }
        report = tmp_path / "r.json"
        report.write_text(json.dumps(data))
        out = tmp_path / "out.html"
        result = _run_cli(["--from-json", str(report), "--output", str(out)])
        assert result.returncode == 0

    def test_exit_1_on_missing_from_json(self, pr_module, tmp_path):
        _require(pr_module)
        result = _run_cli(["--from-json", str(tmp_path / "nonexistent.json")])
        assert result.returncode == 1

    def test_stderr_message_printed_on_missing_file(self, pr_module, tmp_path):
        _require(pr_module)
        result = _run_cli(["--from-json", str(tmp_path / "nonexistent.json")])
        assert len(result.stderr.strip()) > 0

    def test_exit_1_on_malformed_from_json(self, pr_module, tmp_path):
        _require(pr_module)
        bad = tmp_path / "bad.json"
        bad.write_text("{not valid json")
        result = _run_cli(["--from-json", str(bad)])
        assert result.returncode == 1

    def test_exit_1_on_malformed_previous(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [],
        }
        report = tmp_path / "r.json"
        report.write_text(json.dumps(data))
        bad = tmp_path / "bad_prev.json"
        bad.write_text("{not valid json")
        result = _run_cli(["--from-json", str(report), "--previous", str(bad)])
        assert result.returncode == 1

    def test_exit_1_on_malformed_coverage(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [],
        }
        report = tmp_path / "r.json"
        report.write_text(json.dumps(data))
        bad = tmp_path / "bad_cov.json"
        bad.write_text("{not valid json")
        result = _run_cli(["--from-json", str(report), "--coverage", str(bad)])
        assert result.returncode == 1

    def test_stderr_message_printed_on_malformed_json(self, pr_module, tmp_path):
        _require(pr_module)
        bad = tmp_path / "bad.json"
        bad.write_text("{not valid json")
        result = _run_cli(["--from-json", str(bad)])
        assert len(result.stderr.strip()) > 0


# =============================================================================
# CLI - output file and optional arguments
# =============================================================================

class TestCLIOutputAndOptions:

    def test_output_file_created_at_specified_path(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.1}],
        }
        report = tmp_path / "r.json"
        report.write_text(json.dumps(data))
        out = tmp_path / "custom_name.html"
        _run_cli(["--from-json", str(report), "--output", str(out)])
        assert out.exists()

    def test_default_output_path_is_report_html(self, pr_module, tmp_path):
        # Prompt: "optional --output argument...the default value is report.html"
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.1}],
        }
        report = tmp_path / "r.json"
        report.write_text(json.dumps(data))
        result = _run_cli(["--from-json", str(report)], cwd=tmp_path)
        assert result.returncode == 0
        assert (tmp_path / "report.html").exists()

    def test_coverage_data_rendered_in_output_via_cli(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.1}],
        }
        report = tmp_path / "r.json"
        report.write_text(json.dumps(data))
        cov_data = {
            "totals": {"percent_covered": 78.9},
            "files": {"cli_tested_mod.py": {"summary": {"percent_covered": 78.9}}},
        }
        cov = tmp_path / "cov.json"
        cov.write_text(json.dumps(cov_data))
        out = tmp_path / "out.html"
        _run_cli(["--from-json", str(report), "--output", str(out), "--coverage", str(cov)])
        assert "cli_tested_mod.py" in out.read_text()

    def test_trend_section_rendered_via_cli_previous_flag(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 0, "failed": 1, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "test_cli_broke", "outcome": "failed", "duration": 0.1}],
        }
        report = tmp_path / "r.json"
        report.write_text(json.dumps(data))
        prev_data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "test_cli_broke", "outcome": "passed", "duration": 0.1}],
        }
        prev = tmp_path / "prev.json"
        prev.write_text(json.dumps(prev_data))
        out = tmp_path / "out.html"
        _run_cli([
            "--from-json", str(report),
            "--output", str(out),
            "--previous", str(prev),
        ])
        assert "test_cli_broke" in out.read_text()

    def test_previous_run_json_saved_after_pytest_invocation(self, pr_module, tmp_path):
        _require(pr_module)
        test_file = tmp_path / "test_minimal.py"
        test_file.write_text("def test_trivial(): assert True\n")
        out = tmp_path / "out.html"
        result = _run_cli([str(test_file), "--output", str(out)], cwd=tmp_path)
        if result.returncode != 0:
            pytest.skip("pytest invocation unavailable in this environment")
        assert (tmp_path / "previous_run.json").exists()

    def test_previous_run_json_not_saved_when_from_json_used(self, pr_module, tmp_path):
        _require(pr_module)
        data = {
            "summary": {"passed": 1, "failed": 0, "skipped": 0, "duration": 0.1},
            "tests": [{"nodeid": "t", "outcome": "passed", "duration": 0.1}],
        }
        report = tmp_path / "r.json"
        report.write_text(json.dumps(data))
        out = tmp_path / "out.html"
        result = _run_cli(["--from-json", str(report), "--output", str(out)], cwd=tmp_path)
        assert result.returncode == 0
        assert not (tmp_path / "previous_run.json").exists()

    def test_reruns_flag_forwarded_to_pytest_subprocess(self, pr_module, tmp_path):
        """
        When --reruns N is provided, the value must be forwarded to pytest so
        that pytest-rerunfailures retries failing tests. The observable effect
        is that a test that fails once then passes on retry is marked flaky in
        the HTML output.
        """
        _require(pr_module)
        counter_file = tmp_path / "run_count.txt"
        counter_file.write_text("0")
        test_file = tmp_path / "test_retry.py"
        test_file.write_text(
            "def test_flaky_reruns():\n"
            f"    path = r'{counter_file}'\n"
            "    n = int(open(path).read()) + 1\n"
            "    open(path, 'w').write(str(n))\n"
            "    assert n > 1\n"
        )
        out = tmp_path / "out.html"
        result = _run_cli(
            [str(test_file), "--output", str(out), "--reruns", "1"],
            cwd=tmp_path,
        )
        if not out.exists():
            pytest.skip("pytest-rerunfailures not available or pytest invocation failed")
        assert "flak" in out.read_text().lower()