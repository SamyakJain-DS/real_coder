/**
 * Tests for imageLoader.js — loadImageFromFile
 * Covers: loadImageFromFile named export
 * Uses mocked FileReader and Image globals.
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';

const MODULE_PATH = new URL('../imageLoader.js', import.meta.url).href;

async function loadModule() {
  try {
    return await import(MODULE_PATH);
  } catch {
    return null;
  }
}

/**
 * Build a mock canvas that records drawImage calls and exposes width/height.
 */
function makeMockCanvas() {
  const canvas = {
    width: 0,
    height: 0,
    drawImageCalls: [],
    getContext: (_type) => ({
      drawImage: (...args) => canvas.drawImageCalls.push(args),
    }),
  };
  return canvas;
}

/**
 * Set up global FileReader and Image mocks for a successful load flow.
 * Returns { capturedImage } — capturedImage is set to the Image instance
 * constructed by the module under test.
 */
function setupSuccessMocks({ naturalWidth = 100, naturalHeight = 80 } = {}) {
  let capturedImage = null;

  global.FileReader = class {
    constructor() { this._listeners = {}; }
    addEventListener(evt, fn) {
      (this._listeners[evt] = this._listeners[evt] || []).push(fn);
    }
    _fire(evt, arg) {
      if (this[`on${evt}`]) this[`on${evt}`](arg);
      (this._listeners[evt] || []).forEach(fn => fn(arg));
    }
    readAsDataURL(_file) {
      setTimeout(() => {
        this.result = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
        this._fire('load', { target: this });
      }, 0);
    }
  };

  global.Image = class {
    constructor() {
      this.naturalWidth  = naturalWidth;
      this.naturalHeight = naturalHeight;
      this._listeners = {};
      capturedImage = this;
    }
    addEventListener(evt, fn) {
      (this._listeners[evt] = this._listeners[evt] || []).push(fn);
    }
    _fire(evt, arg) {
      if (this[`on${evt}`]) this[`on${evt}`](arg);
      (this._listeners[evt] || []).forEach(fn => fn(arg));
    }
    set src(_val) {
      setTimeout(() => { this._fire('load', {}); }, 0);
    }
  };

  return { getCapturedImage: () => capturedImage };
}

/**
 * Set up global FileReader that fires error event.
 * Returns { getReaderError } so tests can assert rejection === reader.error.
 */
function setupReaderErrorMocks() {
  let readerErrorInstance = null;

  global.FileReader = class {
    constructor() { this._listeners = {}; }
    addEventListener(evt, fn) {
      (this._listeners[evt] = this._listeners[evt] || []).push(fn);
    }
    _fire(evt, arg) {
      if (this[`on${evt}`]) this[`on${evt}`](arg);
      (this._listeners[evt] || []).forEach(fn => fn(arg));
    }
    readAsDataURL(_file) {
      this.error = new Error('read failed');
      readerErrorInstance = this.error;
      setTimeout(() => { this._fire('error', { target: this }); }, 0);
    }
  };
  global.Image = class {
    constructor() { this._listeners = {}; }
    addEventListener(evt, fn) {
      (this._listeners[evt] = this._listeners[evt] || []).push(fn);
    }
    set src(_val) {}
  };

  return { getReaderError: () => readerErrorInstance };
}

/**
 * Set up global FileReader that succeeds, but Image fires error.
 */
function setupImageErrorMocks() {
  global.FileReader = class {
    constructor() { this._listeners = {}; }
    addEventListener(evt, fn) {
      (this._listeners[evt] = this._listeners[evt] || []).push(fn);
    }
    _fire(evt, arg) {
      if (this[`on${evt}`]) this[`on${evt}`](arg);
      (this._listeners[evt] || []).forEach(fn => fn(arg));
    }
    readAsDataURL(_file) {
      setTimeout(() => {
        this.result = 'data:image/png;base64,abc';
        this._fire('load', { target: this });
      }, 0);
    }
  };

  global.Image = class {
    constructor() { this._listeners = {}; }
    addEventListener(evt, fn) {
      (this._listeners[evt] = this._listeners[evt] || []).push(fn);
    }
    _fire(evt, arg) {
      if (this[`on${evt}`]) this[`on${evt}`](arg);
      (this._listeners[evt] || []).forEach(fn => fn(arg));
    }
    set src(_val) {
      setTimeout(() => { this._fire('error', new Error('bad')); }, 0);
    }
  };
}

/** A minimal fake File object (only .type is checked by the spec). */
const FAKE_FILE = { type: 'image/png', name: 'test.png' };

// ─── Successful load ──────────────────────────────────────────────────────────

test('imageLoader: resolves with the exact Image instance constructed during load', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('imageLoader.js has not been implemented');
  const { getCapturedImage } = setupSuccessMocks({ naturalWidth: 120, naturalHeight: 90 });
  const canvas = makeMockCanvas();
  const img = await mod.loadImageFromFile(FAKE_FILE, canvas);
  const capturedImage = getCapturedImage();
  assert.ok(capturedImage !== null, 'Image constructor was not called');
  assert.strictEqual(img, capturedImage,
    'Resolved value should be the exact Image instance constructed');
});

test('imageLoader: sets canvas width and height to image natural dimensions', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('imageLoader.js has not been implemented');
  setupSuccessMocks({ naturalWidth: 120, naturalHeight: 90 });
  const canvas = makeMockCanvas();
  await mod.loadImageFromFile(FAKE_FILE, canvas);
  assert.equal(canvas.width,  120, `canvas.width should be 120, got ${canvas.width}`);
  assert.equal(canvas.height,  90, `canvas.height should be 90, got ${canvas.height}`);
});

test('imageLoader: calls drawImage on the canvas 2d context after loading', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('imageLoader.js has not been implemented');
  const { getCapturedImage } = setupSuccessMocks({ naturalWidth: 100, naturalHeight: 80 });
  const canvas = makeMockCanvas();
  await mod.loadImageFromFile(FAKE_FILE, canvas);
  assert.equal(canvas.drawImageCalls.length, 1, 'drawImage should be called exactly once');
  const args = canvas.drawImageCalls[0];
  assert.strictEqual(args[0], getCapturedImage(),
    'drawImage first argument should be the loaded Image instance');
  assert.equal(args[1], 0, 'drawImage second argument (dx) should be 0');
  assert.equal(args[2], 0, 'drawImage third argument (dy) should be 0');

});

// ─── Error: image fails to load ───────────────────────────────────────────────

test('imageLoader: rejects with Error whose message is "Image load failed" when image errors', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('imageLoader.js has not been implemented');
  setupImageErrorMocks();
  const canvas = makeMockCanvas();
  try {
    await mod.loadImageFromFile(FAKE_FILE, canvas);
    assert.fail('Expected rejection but promise resolved');
  } catch (err) {
    assert.ok(err instanceof Error, `Expected Error, got ${err}`);
    assert.equal(err.message, 'Image load failed');
  }
});

// ─── Error: FileReader fails ──────────────────────────────────────────────────

test('imageLoader: rejects with reader.error when the FileReader fires an error event', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('imageLoader.js has not been implemented');
  const { getReaderError } = setupReaderErrorMocks();
  const canvas = makeMockCanvas();
  try {
    await mod.loadImageFromFile(FAKE_FILE, canvas);
    assert.fail('Expected rejection but promise resolved');
  } catch (err) {
    const readerError = getReaderError();
    assert.ok(readerError !== null, 'reader.error was never set on the FileReader instance');
    assert.strictEqual(err, readerError,
      'Rejection value should be the exact reader.error instance');
  }
});
