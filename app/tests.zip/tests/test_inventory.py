"""
Tests for Inventory Management endpoints.
Covers: create_inventory_item, list_inventory,
        deduct_stock, get_stock_deductions.
"""


class TestCreateInventoryItem:
    def test_create_inventory_item_response_shape(self, client, sample_inventory_payload):
        resp = client.post("/inventory", json=sample_inventory_payload)
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["material_name"] == sample_inventory_payload["material_name"]
        assert data["material_type"] == sample_inventory_payload["material_type"]
        assert data["unit_of_measure"] == sample_inventory_payload["unit_of_measure"]
        assert data["quantity_on_hand"] == sample_inventory_payload["quantity_on_hand"]
        assert data["reorder_threshold"] == sample_inventory_payload["reorder_threshold"]

    def test_create_metal_inventory_item(self, client):
        payload = {
            "material_name": "Brass Sheet",
            "material_type": "metal",
            "unit_of_measure": "sheet_sq_in",
            "quantity_on_hand": 100.0,
            "reorder_threshold": 20.0,
        }
        resp = client.post("/inventory", json=payload)
        assert resp.status_code == 201
        data = resp.json()
        assert data["material_type"] == "metal"

    def test_create_inventory_item_invalid_material_type_returns_422(self, client, sample_inventory_payload):
        payload = {**sample_inventory_payload, "material_type": "plastic"}
        resp = client.post("/inventory", json=payload)
        assert resp.status_code == 422
        assert resp.json().get("detail")


class TestListInventory:
    def test_list_inventory_includes_created_item(self, client, created_inventory_item):
        resp = client.get("/inventory")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list), "Expected list response"
        match = next((i for i in data if i["id"] == created_inventory_item["id"]), None)
        assert match is not None, "Created inventory item not found in list"
        for field in ["id", "material_name", "material_type", "unit_of_measure",
                      "quantity_on_hand", "reorder_threshold"]:
            assert field in match, f"List item missing required field '{field}'"

    def test_list_inventory_filter_by_material_type(self, client):
        """Filtering by material_type includes matching items and excludes non-matching ones."""
        wood_resp = client.post("/inventory", json={
            "material_name": "Walnut", "material_type": "wood",
            "unit_of_measure": "board_foot", "quantity_on_hand": 10.0, "reorder_threshold": 1.0,
        })
        assert wood_resp.status_code == 201
        wood_id = wood_resp.json()["id"]

        # Filtering for wood must include our item and all results must be wood
        wood_data = client.get("/inventory", params={"material_type": "wood"}).json()
        assert isinstance(wood_data, list)
        assert any(item["id"] == wood_id for item in wood_data)
        assert all(item["material_type"] == "wood" for item in wood_data)

        # Filtering for metal must exclude our wood item
        metal_data = client.get("/inventory", params={"material_type": "metal"}).json()
        assert isinstance(metal_data, list)
        assert not any(item["id"] == wood_id for item in metal_data)


class TestDeductStock:
    def test_deduct_stock_returns_200(self, client, created_commission, created_inventory_item):
        resp = client.post(
            "/inventory/deduct",
            json={
                "inventory_item_id": created_inventory_item["id"],
                "quantity": 5.0,
                "commission_id": created_commission["id"],
            },
        )
        assert resp.status_code == 200

    def test_deduct_stock_updates_quantity(self, client, created_commission, created_inventory_item):
        original_qty = created_inventory_item["quantity_on_hand"]
        deduction = 10.0
        resp = client.post(
            "/inventory/deduct",
            json={
                "inventory_item_id": created_inventory_item["id"],
                "quantity": deduction,
                "commission_id": created_commission["id"],
            },
        )
        data = resp.json()
        assert data["quantity_on_hand"] == original_qty - deduction

    def test_deduct_stock_response_contains_all_inventory_fields(
        self, client, created_commission, created_inventory_item
    ):
        resp = client.post(
            "/inventory/deduct",
            json={
                "inventory_item_id": created_inventory_item["id"],
                "quantity": 1.0,
                "commission_id": created_commission["id"],
            },
        )
        data = resp.json()
        for field in ["id", "material_name", "material_type", "unit_of_measure",
                      "quantity_on_hand", "reorder_threshold"]:
            assert field in data

    def test_deduct_stock_nonexistent_inventory_returns_404(self, client, created_commission):
        resp = client.post(
            "/inventory/deduct",
            json={
                "inventory_item_id": 99999,
                "quantity": 1.0,
                "commission_id": created_commission["id"],
            },
        )
        assert resp.status_code == 404
        assert resp.json().get("detail")

    def test_deduct_stock_nonexistent_commission_returns_404(self, client, created_inventory_item):
        resp = client.post(
            "/inventory/deduct",
            json={
                "inventory_item_id": created_inventory_item["id"],
                "quantity": 1.0,
                "commission_id": 99999,
            },
        )
        assert resp.status_code == 404
        assert resp.json().get("detail")

    def test_deduct_stock_insufficient_returns_409(self, client, created_commission, created_inventory_item):
        resp = client.post(
            "/inventory/deduct",
            json={
                "inventory_item_id": created_inventory_item["id"],
                "quantity": 99999.0,
                "commission_id": created_commission["id"],
            },
        )
        assert resp.status_code == 409

    def test_deduct_stock_exact_quantity_allowed(self, client, created_commission):
        inv_payload = {
            "material_name": "Tin Rod",
            "material_type": "metal",
            "unit_of_measure": "rod_length_cm",
            "quantity_on_hand": 10.0,
            "reorder_threshold": 2.0,
        }
        inv_resp = client.post("/inventory", json=inv_payload)
        inv = inv_resp.json()

        resp = client.post(
            "/inventory/deduct",
            json={
                "inventory_item_id": inv["id"],
                "quantity": 10.0,
                "commission_id": created_commission["id"],
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["quantity_on_hand"] == 0.0


class TestGetStockDeductions:
    def test_get_deductions_records_deduction(self, client, created_commission, created_inventory_item):
        client.post(
            "/inventory/deduct",
            json={
                "inventory_item_id": created_inventory_item["id"],
                "quantity": 3.0,
                "commission_id": created_commission["id"],
            },
        )
        resp = client.get("/inventory/deductions")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list), "Expected deductions list response"
        assert len(data) >= 1
        deduction = data[0]
        assert "id" in deduction
        assert "inventory_item_id" in deduction
        assert "quantity" in deduction
        assert "commission_id" in deduction
        assert "deducted_at" in deduction

    def test_get_deductions_filter_by_commission(self, client, created_commission, created_inventory_item):
        client.post(
            "/inventory/deduct",
            json={
                "inventory_item_id": created_inventory_item["id"],
                "quantity": 2.0,
                "commission_id": created_commission["id"],
            },
        )
        resp = client.get(
            "/inventory/deductions",
            params={"commission_id": created_commission["id"]},
        )
        data = resp.json()
        assert isinstance(data, list), "Expected list response"
        assert len(data) >= 1
        for d in data:
            assert d["commission_id"] == created_commission["id"]

    def test_get_deductions_filter_no_match(self, client):
        resp = client.get("/inventory/deductions", params={"commission_id": 99999})
        data = resp.json()
        assert isinstance(data, list), "Expected list response"
        assert len(data) == 0
