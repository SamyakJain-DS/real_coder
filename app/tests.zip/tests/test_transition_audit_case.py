"""Tests for TaxAdministrationPlatform.transition_audit_case."""

from __future__ import annotations

import pytest

from _helpers import build_platform


# --------------------------------------------------------------------------- #
# Test ID: AUD-TR-01
# Requirement: Audit #9 (BEGIN_EXAM transitions SELECTED -> IN_EXAMINATION).
# --------------------------------------------------------------------------- #
def test_transition_begin_exam_from_selected():
    try:
        platform = build_platform()
        result = platform.transition_audit_case(
            {
                "filer_id": "F-1",
                "audit_status": "SELECTED",
                "examiner_id": "E-9",
                "findings_summary": "initial",
            },
            action="BEGIN_EXAM",
        )

        assert result["previous_status"] == "SELECTED"
        assert result["current_status"] == "IN_EXAMINATION"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"transition_audit_case raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-TR-02
# Requirement: Audit #9 (CLOSE_EXAM transitions IN_EXAMINATION -> CLOSED).
# --------------------------------------------------------------------------- #
def test_transition_close_exam_from_in_examination():
    try:
        platform = build_platform()
        result = platform.transition_audit_case(
            {
                "filer_id": "F-2",
                "audit_status": "IN_EXAMINATION",
                "examiner_id": "E-9",
                "findings_summary": "wrap up",
            },
            action="CLOSE_EXAM",
        )

        assert result["previous_status"] == "IN_EXAMINATION"
        assert result["current_status"] == "CLOSED"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"transition_audit_case raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-TR-03
# Requirement: Audit #10 (transition output keys + propagation).
# Test Description: Output contains filer_id, previous_status, current_status,
#   examiner_id, findings_summary, and the propagated fields equal the input.
# --------------------------------------------------------------------------- #
def test_transition_output_schema_and_propagation():
    try:
        platform = build_platform()
        result = platform.transition_audit_case(
            {
                "filer_id": "F-3",
                "audit_status": "SELECTED",
                "examiner_id": "EX-77",
                "findings_summary": "needs review",
            },
            action="BEGIN_EXAM",
        )

        for key in ("filer_id", "previous_status", "current_status", "examiner_id", "findings_summary"):
            assert key in result, f"missing key {key!r}"
        assert result["filer_id"] == "F-3"
        assert result["examiner_id"] == "EX-77"
        assert result["findings_summary"] == "needs review"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"transition_audit_case raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-TR-04
# Requirement: Audit #11 (action outside {BEGIN_EXAM, CLOSE_EXAM} -> ValueError).
# --------------------------------------------------------------------------- #
def test_transition_invalid_action_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError):
            platform.transition_audit_case(
                {
                    "filer_id": "F-4",
                    "audit_status": "SELECTED",
                    "examiner_id": "E-1",
                    "findings_summary": "n/a",
                },
                action="REOPEN",
            )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"transition_audit_case raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-TR-05
# Requirement: Audit #12 (audit_status differs from action's source ->
#   ValueError).  BEGIN_EXAM requires SELECTED; CLOSE_EXAM requires
#   IN_EXAMINATION.
# --------------------------------------------------------------------------- #
def test_transition_wrong_source_status_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError):
            platform.transition_audit_case(
                {
                    "filer_id": "F-5",
                    "audit_status": "IN_EXAMINATION",
                    "examiner_id": "E-1",
                    "findings_summary": "n/a",
                },
                action="BEGIN_EXAM",
            )
        with pytest.raises(ValueError):
            platform.transition_audit_case(
                {
                    "filer_id": "F-6",
                    "audit_status": "SELECTED",
                    "examiner_id": "E-1",
                    "findings_summary": "n/a",
                },
                action="CLOSE_EXAM",
            )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"transition_audit_case raised unexpected exception: {exc!r}")
