import pytest
import requests

# ---------------------------------------------------------------------------
# HTTP helper - converts connection failures into pytest.fail (never ERROR)
# ---------------------------------------------------------------------------

BASE_URL = "http://localhost:5000"

def call(method: str, path: str, **kwargs):
    url = f"{BASE_URL}{path}"
    try:
        return requests.request(method, url, timeout=5, **kwargs)
    except requests.exceptions.ConnectionError:
        pytest.fail(f"Server not reachable at {url}")
    except requests.exceptions.Timeout:
        pytest.fail(f"Request timed out: {method.upper()} {url}")


# ---------------------------------------------------------------------------
# Reusable factory helpers
# ---------------------------------------------------------------------------

_BOOKING_BODY = {
    "partner1Name": "Alice",
    "partner2Name": "Bob",
    "venueName": "Grand Hall",
    "weddingDate": "2025-06-15",
    "packageType": "Premium",
    "deliverables": ["Full gallery", "Highlight reel"],
}

_SESSION_BODY = {
    "location": "City Park",
    "scheduledStartTime": "2025-06-15T10:00:00",
    "label": "Ceremony",
}


def _booking():
    return call("POST", "/api/bookings", json=_BOOKING_BODY).json()


def _session(booking_id):
    return call("POST", f"/api/bookings/{booking_id}/sessions", json=_SESSION_BODY).json()


def _inventory_item(name="Sony A7 III"):
    return call("POST", "/api/inventory", json={"name": name}).json()


def _kit(session_id, item_ids, kit_name="Main Kit"):
    return call(
        "POST",
        f"/api/sessions/{session_id}/equipment-kits",
        json={"kitName": kit_name, "inventoryItemIds": item_ids},
    ).json()


def _proofing(booking_id, delivery_date="2025-09-01"):
    return call(
        "POST",
        f"/api/bookings/{booking_id}/proofing",
        json={"contractedDeliveryDate": delivery_date},
    ).json()


def _round(booking_id, submitted_date, images=50, notes="Pass"):
    return call(
        "POST",
        f"/api/bookings/{booking_id}/proofing/rounds",
        json={"submittedDate": submitted_date, "imagesSelected": images, "notes": notes},
    ).json()


# ===========================================================================
# BOOKINGS
# ===========================================================================


class TestCreateBooking:
    def test_returns_201(self):
        r = call("POST", "/api/bookings", json=_BOOKING_BODY)
        assert r.status_code == 201

    def test_response_contains_integer_id(self):
        data = call("POST", "/api/bookings", json=_BOOKING_BODY).json()
        assert "id" in data
        assert isinstance(data["id"], int)

    def test_response_contains_all_input_fields(self):
        data = call("POST", "/api/bookings", json=_BOOKING_BODY).json()
        assert data["partner1Name"] == _BOOKING_BODY["partner1Name"]
        assert data["partner2Name"] == _BOOKING_BODY["partner2Name"]
        assert data["venueName"] == _BOOKING_BODY["venueName"]
        assert data["weddingDate"] == _BOOKING_BODY["weddingDate"]
        assert data["packageType"] == _BOOKING_BODY["packageType"]
        assert data["deliverables"] == _BOOKING_BODY["deliverables"]

    def test_multiple_bookings_receive_distinct_ids(self):
        id1 = _booking()["id"]
        id2 = _booking()["id"]
        assert id1 != id2


class TestGetBookingById:
    def test_returns_200_for_existing_booking(self):
        bid = _booking()["id"]
        assert call("GET", f"/api/bookings/{bid}").status_code == 200

    def test_response_contains_full_shape(self):
        created = _booking()
        data = call("GET", f"/api/bookings/{created['id']}").json()
        assert data["id"] == created["id"]
        assert data["partner1Name"] == _BOOKING_BODY["partner1Name"]
        assert data["partner2Name"] == _BOOKING_BODY["partner2Name"]
        assert data["venueName"] == _BOOKING_BODY["venueName"]
        assert data["weddingDate"] == _BOOKING_BODY["weddingDate"]
        assert data["packageType"] == _BOOKING_BODY["packageType"]
        assert data["deliverables"] == _BOOKING_BODY["deliverables"]

    def test_returns_404_for_nonexistent_id(self):
        assert call("GET", "/api/bookings/999999").status_code == 404


# ===========================================================================
# SESSIONS
# ===========================================================================


class TestAddSession:
    def test_returns_201_when_booking_exists(self):
        bid = _booking()["id"]
        r = call("POST", f"/api/bookings/{bid}/sessions", json=_SESSION_BODY)
        assert r.status_code == 201

    def test_response_contains_id_and_booking_id(self):
        bid = _booking()["id"]
        data = call("POST", f"/api/bookings/{bid}/sessions", json=_SESSION_BODY).json()
        assert isinstance(data["id"], int)
        assert data["bookingId"] == bid

    def test_response_contains_all_input_fields(self):
        bid = _booking()["id"]
        data = call("POST", f"/api/bookings/{bid}/sessions", json=_SESSION_BODY).json()
        assert data["location"] == _SESSION_BODY["location"]
        assert data["scheduledStartTime"] == _SESSION_BODY["scheduledStartTime"]
        assert data["label"] == _SESSION_BODY["label"]

    def test_returns_404_when_booking_does_not_exist(self):
        r = call("POST", "/api/bookings/999999/sessions", json=_SESSION_BODY)
        assert r.status_code == 404


class TestGetSessions:
    def test_returns_200_with_list_when_booking_exists(self):
        bid = _booking()["id"]
        r = call("GET", f"/api/bookings/{bid}/sessions")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_returns_empty_list_when_no_sessions_added(self):
        bid = _booking()["id"]
        assert call("GET", f"/api/bookings/{bid}/sessions").json() == []

    def test_created_session_appears_with_correct_shape(self):
        bid = _booking()["id"]
        created = _session(bid)
        sessions = call("GET", f"/api/bookings/{bid}/sessions").json()
        found = next((s for s in sessions if s["id"] == created["id"]), None)
        assert found is not None
        assert found["bookingId"] == bid
        assert found["location"] == _SESSION_BODY["location"]
        assert found["scheduledStartTime"] == _SESSION_BODY["scheduledStartTime"]
        assert found["label"] == _SESSION_BODY["label"]

    def test_returns_404_when_booking_does_not_exist(self):
        assert call("GET", "/api/bookings/999999/sessions").status_code == 404

    def test_booking_can_have_multiple_sessions(self):
        bid = _booking()["id"]
        id1 = _session(bid)["id"]
        id2 = _session(bid)["id"]
        ids = [s["id"] for s in call("GET", f"/api/bookings/{bid}/sessions").json()]
        assert id1 in ids
        assert id2 in ids

    def test_sessions_are_isolated_to_their_booking(self):
        bid1 = _booking()["id"]
        bid2 = _booking()["id"]
        sid_for_bid2 = _session(bid2)["id"]
        ids_for_bid1 = [s["id"] for s in call("GET", f"/api/bookings/{bid1}/sessions").json()]
        assert sid_for_bid2 not in ids_for_bid1


# ===========================================================================
# INVENTORY
# ===========================================================================


class TestAddInventoryItem:
    def test_returns_201(self):
        assert call("POST", "/api/inventory", json={"name": "Tripod"}).status_code == 201

    def test_response_contains_integer_id_and_name(self):
        data = call("POST", "/api/inventory", json={"name": "Reflector"}).json()
        assert isinstance(data["id"], int)
        assert data["name"] == "Reflector"

    def test_multiple_inventory_items_receive_distinct_ids(self):
        id1 = _inventory_item("Lens A")["id"]
        id2 = _inventory_item("Lens B")["id"]
        assert id1 != id2


class TestGetInventoryItems:
    def test_returns_200_with_list(self):
        r = call("GET", "/api/inventory")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_created_item_appears_in_list_with_correct_shape(self):
        item = _inventory_item("Canon 50mm Lens")
        items = call("GET", "/api/inventory").json()
        found = next((i for i in items if i["id"] == item["id"]), None)
        assert found is not None
        assert found["name"] == "Canon 50mm Lens"
        assert isinstance(found["id"], int)


# ===========================================================================
# EQUIPMENT KITS
# ===========================================================================


class TestAddEquipmentKit:
    def test_returns_201_when_session_and_all_items_exist(self):
        bid = _booking()["id"]
        sid = _session(bid)["id"]
        iid = _inventory_item("Flash Unit")["id"]
        assert call(
            "POST",
            f"/api/sessions/{sid}/equipment-kits",
            json={"kitName": "Kit A", "inventoryItemIds": [iid]},
        ).status_code == 201

    def test_response_contains_full_shape(self):
        bid = _booking()["id"]
        sid = _session(bid)["id"]
        iid = _inventory_item("Battery Pack")["id"]
        data = call(
            "POST",
            f"/api/sessions/{sid}/equipment-kits",
            json={"kitName": "Kit B", "inventoryItemIds": [iid]},
        ).json()
        assert isinstance(data["id"], int)
        assert data["sessionId"] == sid
        assert data["kitName"] == "Kit B"
        assert data["inventoryItemIds"] == [iid]

    def test_returns_404_when_session_does_not_exist(self):
        iid = _inventory_item("Lens Cap")["id"]
        r = call(
            "POST",
            "/api/sessions/999999/equipment-kits",
            json={"kitName": "Kit", "inventoryItemIds": [iid]},
        )
        assert r.status_code == 404

    def test_returns_422_when_inventory_item_does_not_exist(self):
        bid = _booking()["id"]
        sid = _session(bid)["id"]
        r = call(
            "POST",
            f"/api/sessions/{sid}/equipment-kits",
            json={"kitName": "Kit", "inventoryItemIds": [999999]},
        )
        assert r.status_code == 422

    def test_returns_422_when_one_of_multiple_inventory_item_ids_does_not_exist(self):
        bid = _booking()["id"]
        sid = _session(bid)["id"]
        valid_iid = _inventory_item("Lens Cap")["id"]
        r = call(
            "POST",
            f"/api/sessions/{sid}/equipment-kits",
            json={"kitName": "Kit", "inventoryItemIds": [valid_iid, 999999]},
        )
        assert r.status_code == 422


class TestGetEquipmentKits:
    def test_returns_200_with_list_when_session_exists(self):
        bid = _booking()["id"]
        sid = _session(bid)["id"]
        r = call("GET", f"/api/sessions/{sid}/equipment-kits")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_returns_empty_list_when_no_kits_added(self):
        bid = _booking()["id"]
        sid = _session(bid)["id"]
        assert call("GET", f"/api/sessions/{sid}/equipment-kits").json() == []

    def test_created_kit_appears_with_correct_shape(self):
        bid = _booking()["id"]
        sid = _session(bid)["id"]
        iid = _inventory_item("Memory Card")["id"]
        created = _kit(sid, [iid], "Kit C")
        kits = call("GET", f"/api/sessions/{sid}/equipment-kits").json()
        found = next((k for k in kits if k["id"] == created["id"]), None)
        assert found is not None
        assert found["sessionId"] == sid
        assert found["kitName"] == "Kit C"
        assert found["inventoryItemIds"] == [iid]

    def test_returns_404_when_session_does_not_exist(self):
        assert call("GET", "/api/sessions/999999/equipment-kits").status_code == 404

    def test_session_can_have_multiple_kits(self):
        bid = _booking()["id"]
        sid = _session(bid)["id"]
        iid = _inventory_item("ND Filter")["id"]
        kid1 = _kit(sid, [iid], "Kit D")["id"]
        kid2 = _kit(sid, [iid], "Kit E")["id"]
        ids = [k["id"] for k in call("GET", f"/api/sessions/{sid}/equipment-kits").json()]
        assert kid1 in ids
        assert kid2 in ids

    def test_equipment_kits_are_isolated_to_their_session(self):
        bid = _booking()["id"]
        sid1 = _session(bid)["id"]
        sid2 = _session(bid)["id"]
        iid = _inventory_item("Filter")["id"]
        kid_for_sid2 = _kit(sid2, [iid], "Kit F")["id"]
        ids_for_sid1 = [k["id"] for k in call("GET", f"/api/sessions/{sid1}/equipment-kits").json()]
        assert kid_for_sid2 not in ids_for_sid1


# ===========================================================================
# PROOFING WORKFLOW
# ===========================================================================


class TestCreateProofingWorkflow:
    def test_returns_201_when_booking_exists(self):
        bid = _booking()["id"]
        r = call(
            "POST",
            f"/api/bookings/{bid}/proofing",
            json={"contractedDeliveryDate": "2025-09-01"},
        )
        assert r.status_code == 201

    def test_response_contains_full_shape_on_creation(self):
        bid = _booking()["id"]
        data = call(
            "POST",
            f"/api/bookings/{bid}/proofing",
            json={"contractedDeliveryDate": "2025-09-01"},
        ).json()
        assert isinstance(data["id"], int)
        assert data["bookingId"] == bid
        assert data["contractedDeliveryDate"] == "2025-09-01"
        assert data["rounds"] == []
        assert data["isWithinDeliveryWindow"] is None

    def test_returns_404_when_booking_does_not_exist(self):
        r = call(
            "POST",
            "/api/bookings/999999/proofing",
            json={"contractedDeliveryDate": "2025-09-01"},
        )
        assert r.status_code == 404

    def test_returns_409_when_workflow_already_exists_for_booking(self):
        bid = _booking()["id"]
        _proofing(bid)
        r = call(
            "POST",
            f"/api/bookings/{bid}/proofing",
            json={"contractedDeliveryDate": "2025-10-01"},
        )
        assert r.status_code == 409

    def test_multiple_workflows_for_different_bookings_receive_distinct_ids(self):
        bid1 = _booking()["id"]
        bid2 = _booking()["id"]
        wid1 = _proofing(bid1)["id"]
        wid2 = _proofing(bid2)["id"]
        assert wid1 != wid2


class TestAddProofingRound:
    def test_returns_201_when_workflow_exists(self):
        bid = _booking()["id"]
        _proofing(bid)
        r = call(
            "POST",
            f"/api/bookings/{bid}/proofing/rounds",
            json={"submittedDate": "2025-08-01", "imagesSelected": 50, "notes": "First pass"},
        )
        assert r.status_code == 201

    def test_response_contains_full_shape(self):
        bid = _booking()["id"]
        _proofing(bid)
        data = call(
            "POST",
            f"/api/bookings/{bid}/proofing/rounds",
            json={"submittedDate": "2025-08-01", "imagesSelected": 75, "notes": "Review"},
        ).json()
        assert isinstance(data["id"], int)
        assert isinstance(data["roundNumber"], int)
        assert data["submittedDate"] == "2025-08-01"
        assert data["imagesSelected"] == 75
        assert data["notes"] == "Review"

    def test_first_round_number_is_1(self):
        bid = _booking()["id"]
        _proofing(bid)
        data = _round(bid, "2025-08-01")
        assert data["roundNumber"] == 1

    def test_round_numbers_increment_by_one(self):
        bid = _booking()["id"]
        _proofing(bid)
        r1 = _round(bid, "2025-08-01")["roundNumber"]
        r2 = _round(bid, "2025-08-10")["roundNumber"]
        r3 = _round(bid, "2025-08-20")["roundNumber"]
        assert r2 == r1 + 1
        assert r3 == r2 + 1

    def test_returns_404_when_no_workflow_exists_for_booking(self):
        bid = _booking()["id"]
        r = call(
            "POST",
            f"/api/bookings/{bid}/proofing/rounds",
            json={"submittedDate": "2025-08-01", "imagesSelected": 50, "notes": "Pass"},
        )
        assert r.status_code == 404

    def test_multiple_rounds_receive_distinct_ids(self):
        bid = _booking()["id"]
        _proofing(bid)
        rid1 = _round(bid, "2025-08-01")["id"]
        rid2 = _round(bid, "2025-08-15")["id"]
        assert rid1 != rid2


class TestGetProofingWorkflow:
    def test_returns_200_when_workflow_exists(self):
        bid = _booking()["id"]
        _proofing(bid)
        assert call("GET", f"/api/bookings/{bid}/proofing").status_code == 200

    def test_response_shape_with_no_rounds(self):
        bid = _booking()["id"]
        _proofing(bid, "2025-09-01")
        data = call("GET", f"/api/bookings/{bid}/proofing").json()
        assert isinstance(data["id"], int)
        assert data["bookingId"] == bid
        assert data["contractedDeliveryDate"] == "2025-09-01"
        assert data["rounds"] == []
        assert data["isWithinDeliveryWindow"] is None

    def test_returns_404_when_no_workflow_exists(self):
        bid = _booking()["id"]
        assert call("GET", f"/api/bookings/{bid}/proofing").status_code == 404

    def test_rounds_appear_in_response_with_correct_shape(self):
        bid = _booking()["id"]
        _proofing(bid)
        _round(bid, "2025-08-01", 60, "Initial selects")
        rounds = call("GET", f"/api/bookings/{bid}/proofing").json()["rounds"]
        assert len(rounds) == 1
        rnd = rounds[0]
        assert isinstance(rnd["id"], int)
        assert isinstance(rnd["roundNumber"], int)
        assert rnd["submittedDate"] == "2025-08-01"
        assert rnd["imagesSelected"] == 60
        assert rnd["notes"] == "Initial selects"

    def test_is_within_delivery_window_null_when_no_rounds(self):
        bid = _booking()["id"]
        _proofing(bid)
        data = call("GET", f"/api/bookings/{bid}/proofing").json()
        assert data["isWithinDeliveryWindow"] is None

    def test_is_within_delivery_window_true_when_submitted_before_deadline(self):
        bid = _booking()["id"]
        _proofing(bid, "2025-09-01")
        _round(bid, "2025-08-15")
        data = call("GET", f"/api/bookings/{bid}/proofing").json()
        assert data["isWithinDeliveryWindow"] is True

    def test_is_within_delivery_window_true_when_submitted_on_deadline(self):
        bid = _booking()["id"]
        _proofing(bid, "2025-09-01")
        _round(bid, "2025-09-01")
        data = call("GET", f"/api/bookings/{bid}/proofing").json()
        assert data["isWithinDeliveryWindow"] is True

    def test_is_within_delivery_window_false_when_submitted_after_deadline(self):
        bid = _booking()["id"]
        _proofing(bid, "2025-09-01")
        _round(bid, "2025-09-15")
        data = call("GET", f"/api/bookings/{bid}/proofing").json()
        assert data["isWithinDeliveryWindow"] is False

    def test_is_within_delivery_window_reflects_highest_round_number(self):
        # Round 1 is within window; round 2 (highest roundNumber) is not.
        # isWithinDeliveryWindow must be False.
        bid = _booking()["id"]
        _proofing(bid, "2025-09-01")
        _round(bid, "2025-08-01")   # roundNumber 1 - within window
        _round(bid, "2025-09-15")   # roundNumber 2 - outside window
        data = call("GET", f"/api/bookings/{bid}/proofing").json()
        assert data["isWithinDeliveryWindow"] is False

    def test_rounds_ordered_by_round_number_ascending(self):
        bid = _booking()["id"]
        _proofing(bid)
        _round(bid, "2025-08-01")
        _round(bid, "2025-08-10")
        _round(bid, "2025-08-20")
        rounds = call("GET", f"/api/bookings/{bid}/proofing").json()["rounds"]
        assert len(rounds) == 3
        numbers = [r["roundNumber"] for r in rounds]
        assert numbers == sorted(numbers)