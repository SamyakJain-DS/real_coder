/**
 * Tests for gridOverlay.js — drawGridOverlay
 * Covers: drawGridOverlay named export
 * Uses a canvas mock (no DOM or browser required).
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';

const MODULE_PATH = new URL('../gridOverlay.js', import.meta.url).href;

async function loadModule() {
  try {
    return await import(MODULE_PATH);
  } catch {
    return null;
  }
}

/**
 * Build a mock canvas + 2d context that records calls and property assignments.
 * Returns { canvas, ctx, calls } where calls is an array of { method, args }.
 * Property assignments to strokeStyle, lineWidth, globalAlpha are captured on ctx directly.
 */
function makeMockCanvas(width, height) {
  const calls = [];

  const ctx = {
    clearRect:   (...args) => calls.push({ method: 'clearRect',   args }),
    beginPath:   (...args) => calls.push({ method: 'beginPath',   args }),
    moveTo:      (...args) => calls.push({ method: 'moveTo',      args }),
    lineTo:      (...args) => calls.push({ method: 'lineTo',      args }),
    stroke:      (...args) => calls.push({ method: 'stroke',      args }),
    strokeStyle: null,
    lineWidth:   null,
    globalAlpha: null,
  };

  const canvas = {
    width,
    height,
    getContext: (_type) => ctx,
  };

  return { canvas, ctx, calls };
}

/** Count how many times a given method appears in the recorded calls. */
function countCalls(calls, method) {
  return calls.filter(c => c.method === method).length;
}

// ─── clearRect always called ──────────────────────────────────────────────────

test('gridOverlay: drawGridOverlay calls clearRect on the context', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, calls } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);
  assert.ok(countCalls(calls, 'clearRect') >= 1, 'clearRect was not called');
});

test('gridOverlay: clearRect covers the full canvas dimensions', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, calls } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);
  const clearCall = calls.find(c => c.method === 'clearRect');
  assert.ok(clearCall, 'clearRect not found');
  assert.equal(clearCall.args[0], 0);
  assert.equal(clearCall.args[1], 0);
  assert.equal(clearCall.args[2], 300);
  assert.equal(clearCall.args[3], 400);
});

// ─── Early return on zero dimensions ─────────────────────────────────────────

test('gridOverlay: returns immediately (no stroke calls) when canvas width is 0', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, calls } = makeMockCanvas(0, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);
  assert.equal(countCalls(calls, 'stroke'), 0,
    'stroke was called despite canvas width === 0');
});

test('gridOverlay: returns immediately (no stroke calls) when canvas height is 0', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, calls } = makeMockCanvas(300, 0);
  mod.drawGridOverlay(canvas, 3, 4, 1);
  assert.equal(countCalls(calls, 'stroke'), 0,
    'stroke was called despite canvas height === 0');
});

// ─── Context property assignments ─────────────────────────────────────────────

test('gridOverlay: sets strokeStyle to "#00aaff"', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, ctx } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);
  assert.equal(ctx.strokeStyle, '#00aaff',
    `Expected ctx.strokeStyle "#00aaff", got "${ctx.strokeStyle}"`);
});

test('gridOverlay: sets lineWidth to 1', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, ctx } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);
  assert.equal(ctx.lineWidth, 1,
    `Expected ctx.lineWidth 1, got ${ctx.lineWidth}`);
});

test('gridOverlay: sets globalAlpha to 0.8', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, ctx } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);
  assert.equal(ctx.globalAlpha, 0.8,
    `Expected ctx.globalAlpha 0.8, got ${ctx.globalAlpha}`);
});

// ─── Line counts ─────────────────────────────────────────────────────────────

test('gridOverlay: draws the correct number of vertical lines', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  // realWidth=3, cellSize=1 → i from 0 to Math.floor(3/1)=3 → 4 vertical lines
  // realHeight=4, cellSize=1 → j from 0 to 4 → 5 horizontal lines
  const { canvas, calls } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);

  const expectedVertical   = Math.floor(3 / 1) + 1; // 4
  const expectedHorizontal = Math.floor(4 / 1) + 1; // 5
  const totalStrokes = countCalls(calls, 'stroke');
  assert.equal(totalStrokes, expectedVertical + expectedHorizontal,
    `Expected ${expectedVertical + expectedHorizontal} stroke calls, got ${totalStrokes}`);
});

test('gridOverlay: vertical line count equals Math.floor(realWidth / cellSize) + 1', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  // realWidth=5, cellSize=2 → Math.floor(5/2)=2 → i from 0..2 → 3 vertical lines
  // realHeight=4, cellSize=2 → Math.floor(4/2)=2 → j from 0..2 → 3 horizontal lines
  const { canvas, calls } = makeMockCanvas(500, 400);
  mod.drawGridOverlay(canvas, 5, 4, 2);

  const expectedVertical   = Math.floor(5 / 2) + 1; // 3
  const expectedHorizontal = Math.floor(4 / 2) + 1; // 3
  const totalStrokes = countCalls(calls, 'stroke');
  assert.equal(totalStrokes, expectedVertical + expectedHorizontal);
});

test('gridOverlay: each line is drawn with beginPath, moveTo, lineTo, stroke in sequence', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  // realWidth=1, cellSize=1: 2 vertical + 2 horizontal = 4 lines total
  const { canvas, calls } = makeMockCanvas(100, 100);
  mod.drawGridOverlay(canvas, 1, 1, 1);

  // Filter to only line-drawing method calls (excludes clearRect)
  const lineCalls = calls.filter(c =>
    ['beginPath', 'moveTo', 'lineTo', 'stroke'].includes(c.method)
  );

  // Must be divisible by 4 (each line = one group of 4)
  assert.equal(lineCalls.length % 4, 0,
    `Line drawing calls (${lineCalls.length}) not divisible by 4`);

  // Each group of 4 must be in exact order: beginPath → moveTo → lineTo → stroke
  for (let i = 0; i < lineCalls.length; i += 4) {
    assert.equal(lineCalls[i].method,     'beginPath', `Call ${i} should be beginPath`);
    assert.equal(lineCalls[i + 1].method, 'moveTo',    `Call ${i + 1} should be moveTo`);
    assert.equal(lineCalls[i + 2].method, 'lineTo',    `Call ${i + 2} should be lineTo`);
    assert.equal(lineCalls[i + 3].method, 'stroke',    `Call ${i + 3} should be stroke`);
  }
});

// ─── Line positions ───────────────────────────────────────────────────────────

test('gridOverlay: first vertical line is drawn at x=0', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, calls } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);

  // The very first moveTo should be the first vertical line at x=0
  const firstMoveTo = calls.find(c => c.method === 'moveTo');
  assert.ok(firstMoveTo, 'No moveTo recorded');
  assert.equal(firstMoveTo.args[0], 0, 'First vertical line should be at x=0');
});

test('gridOverlay: non-first vertical lines have exact x-coordinates', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  // canvas 300×400, realWidth=3, cellSize=1, pxPerUnitX = 300/3 = 100
  // i=1: Math.round(1*1*300/3) = 100
  // i=2: Math.round(2*1*300/3) = 200
  // i=3: Math.round(3*1*300/3) = 300
  const { canvas, calls } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);

  const expectedVertical = Math.floor(3 / 1) + 1; // 4
  const moveTos = calls.filter(c => c.method === 'moveTo');
  const vertMoveTos = moveTos.slice(0, expectedVertical);

  assert.equal(vertMoveTos[1].args[0], Math.round(1 * 1 * 300 / 3));
  assert.equal(vertMoveTos[2].args[0], Math.round(2 * 1 * 300 / 3));
  assert.equal(vertMoveTos[3].args[0], Math.round(3 * 1 * 300 / 3));
});

test('gridOverlay: vertical lines span from y=0 to y=canvas.height', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, calls } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);

  const expectedVertical = Math.floor(3 / 1) + 1; // 4
  const moveTos = calls.filter(c => c.method === 'moveTo');
  const lineTos = calls.filter(c => c.method === 'lineTo');

  // All vertical moveTos should have y=0
  for (let i = 0; i < expectedVertical; i++) {
    assert.equal(moveTos[i].args[1], 0,
      `Vertical line ${i} moveTo y should be 0, got ${moveTos[i].args[1]}`);
  }
  // All vertical lineTos should have y=canvas.height (400)
  for (let i = 0; i < expectedVertical; i++) {
    assert.equal(lineTos[i].args[1], 400,
      `Vertical line ${i} lineTo y should be 400, got ${lineTos[i].args[1]}`);
  }
});

test('gridOverlay: first horizontal line is drawn at y=0', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, calls } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);

  // Vertical lines are drawn first; skip those moveTos to reach the first horizontal one
  const expectedVertical = Math.floor(3 / 1) + 1; // 4
  const moveTos = calls.filter(c => c.method === 'moveTo');
  assert.ok(moveTos.length > expectedVertical, 'Not enough moveTo calls for horizontal lines');

  const firstHorizMoveTo = moveTos[expectedVertical];
  assert.equal(firstHorizMoveTo.args[0], 0,
    `First horizontal moveTo x should be 0, got ${firstHorizMoveTo.args[0]}`);
  assert.equal(firstHorizMoveTo.args[1], 0,
    `First horizontal line should be at y=0, got ${firstHorizMoveTo.args[1]}`);
});

test('gridOverlay: non-first horizontal lines have exact y-coordinates', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  // canvas 300×400, realHeight=4, cellSize=1, pxPerUnitY = 400/4 = 100
  // j=1: Math.round(1*1*400/4) = 100
  // j=2: Math.round(2*1*400/4) = 200
  const { canvas, calls } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);

  const expectedVertical = Math.floor(3 / 1) + 1; // 4
  const moveTos = calls.filter(c => c.method === 'moveTo');
  const horizMoveTos = moveTos.slice(expectedVertical);

  assert.equal(horizMoveTos[1].args[1], Math.round(1 * 1 * 400 / 4));
  assert.equal(horizMoveTos[2].args[1], Math.round(2 * 1 * 400 / 4));
});

test('gridOverlay: horizontal lines span from x=0 to x=canvas.width', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('gridOverlay.js has not been implemented');
  const { canvas, calls } = makeMockCanvas(300, 400);
  mod.drawGridOverlay(canvas, 3, 4, 1);

  const expectedVertical   = Math.floor(3 / 1) + 1; // 4
  const expectedHorizontal = Math.floor(4 / 1) + 1; // 5
  const moveTos = calls.filter(c => c.method === 'moveTo');
  const lineTos = calls.filter(c => c.method === 'lineTo');

  const horizMoveTos = moveTos.slice(expectedVertical);
  const horizLineTos = lineTos.slice(expectedVertical);

  // All horizontal moveTos should have x=0
  for (let j = 0; j < expectedHorizontal; j++) {
    assert.equal(horizMoveTos[j].args[0], 0,
      `Horizontal line ${j} moveTo x should be 0, got ${horizMoveTos[j].args[0]}`);
  }
  // All horizontal lineTos should have x=canvas.width (300)
  for (let j = 0; j < expectedHorizontal; j++) {
    assert.equal(horizLineTos[j].args[0], 300,
      `Horizontal line ${j} lineTo x should be 300, got ${horizLineTos[j].args[0]}`);
  }
});
