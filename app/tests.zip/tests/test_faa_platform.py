import re
import pytest

# ---------------------------------------------------------------------------
# Graceful import - produces FAILED (not ERROR) on an empty repository
# ---------------------------------------------------------------------------
try:
    from app import app as flask_app
    APP_AVAILABLE = True
except Exception:
    APP_AVAILABLE = False
    flask_app = None

# ---------------------------------------------------------------------------
# Carrier ID constants
# ---------------------------------------------------------------------------
SEEDED_CARRIER  = "AA001"        # one of the 5 carriers pre-seeded at startup
FRESH_CARRIER   = "ZZ_FRESH_001" # never receives any records in any test
TEST_CARRIER    = "ZZ_TEST_001"  # used for create-then-verify operations
PARTIAL_CARRIER = "ZZ_PART_001"  # receives surveillance+enforcement+disclosures but NEVER ad_compliance


# ---------------------------------------------------------------------------
# Sentinel - yielded by the fixture when app.py is absent.
# Every method call raises AssertionError inside the test body -> FAILED.
# ---------------------------------------------------------------------------

class _FailingClient:
    def __getattr__(self, name):
        def _fail(*args, **kwargs):
            assert False, (
                f"client.{name}() was called but app.py could not be imported. "
                "Is the application implemented?"
            )
        return _fail


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------

@pytest.fixture
def client():
    """Yield a Flask test client, or a _FailingClient when app.py is absent."""
    if not APP_AVAILABLE:
        yield _FailingClient()   # yields to test body; AssertionError there = FAILED
        return                   # teardown: nothing to clean up
    flask_app.config["TESTING"] = True
    with flask_app.test_client() as c:
        yield c


# ===========================================================================
# App import
# ===========================================================================

class TestAppImport:

    def test_app_is_flask_instance(self):
        assert APP_AVAILABLE, "app.py must expose a module-level 'app' object"
        from flask import Flask
        assert isinstance(flask_app, Flask)


# ===========================================================================
# Seed data - every module table must have >= 1 record for every seeded carrier
# ===========================================================================

class TestSeedData:
    def test_seed_ops_specs(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/ops-specs")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    def test_seed_inspector_assignments(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/inspector-assignments")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    def test_seed_surveillance_activities(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/surveillance")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    def test_seed_voluntary_disclosures(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/disclosures")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    def test_seed_enforcement_actions(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/enforcement-actions")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    def test_seed_emergency_actions(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/emergency-actions")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    def test_seed_ad_compliance(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/ad-compliance")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0


# ===========================================================================
# Seed data - remaining 4 carriers (UA002, DL003, SW004, FX005)
# Requirements 11-17: every module table must have >= 1 record for EACH of
# the 5 seeded carriers, not just AA001.
# ===========================================================================

_REMAINING_CARRIERS = ["UA002", "DL003", "SW004", "FX005"]

class TestSeedDataRemainingCarriers:
    @pytest.mark.parametrize("carrier_id", _REMAINING_CARRIERS)
    def test_seed_ops_specs(self, client, carrier_id):
        resp = client.get(f"/api/carriers/{carrier_id}/ops-specs")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    @pytest.mark.parametrize("carrier_id", _REMAINING_CARRIERS)
    def test_seed_inspector_assignments(self, client, carrier_id):
        resp = client.get(f"/api/carriers/{carrier_id}/inspector-assignments")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    @pytest.mark.parametrize("carrier_id", _REMAINING_CARRIERS)
    def test_seed_surveillance_activities(self, client, carrier_id):
        resp = client.get(f"/api/carriers/{carrier_id}/surveillance")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    @pytest.mark.parametrize("carrier_id", _REMAINING_CARRIERS)
    def test_seed_voluntary_disclosures(self, client, carrier_id):
        resp = client.get(f"/api/carriers/{carrier_id}/disclosures")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    @pytest.mark.parametrize("carrier_id", _REMAINING_CARRIERS)
    def test_seed_enforcement_actions(self, client, carrier_id):
        resp = client.get(f"/api/carriers/{carrier_id}/enforcement-actions")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    @pytest.mark.parametrize("carrier_id", _REMAINING_CARRIERS)
    def test_seed_emergency_actions(self, client, carrier_id):
        resp = client.get(f"/api/carriers/{carrier_id}/emergency-actions")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0

    @pytest.mark.parametrize("carrier_id", _REMAINING_CARRIERS)
    def test_seed_ad_compliance(self, client, carrier_id):
        resp = client.get(f"/api/carriers/{carrier_id}/ad-compliance")
        assert resp.status_code == 200
        assert len(resp.get_json()) > 0


# ===========================================================================
# Operations Specifications
# ===========================================================================

_OPS_PAYLOAD = {
    "authorized_operations": ["domestic", "international"],
    "aircraft_type_ratings": ["B737", "A320"],
    "effective_date": "2024-06-01",
    "status": "active",
}

class TestOpsSpecs:
    def test_create_returns_201(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        assert resp.status_code == 201

    def test_create_required_fields_present(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        data = resp.get_json()
        for key in ["id", "carrier_id", "authorized_operations",
                    "aircraft_type_ratings", "effective_date", "status"]:
            assert key in data, f"Missing field: {key}"

    def test_create_id_is_int(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        assert isinstance(resp.get_json()["id"], int)

    def test_create_carrier_id_matches_path(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        assert resp.get_json()["carrier_id"] == TEST_CARRIER

    def test_create_authorized_operations_is_list(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        assert isinstance(resp.get_json()["authorized_operations"], list)

    def test_create_aircraft_type_ratings_is_list(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        assert isinstance(resp.get_json()["aircraft_type_ratings"], list)

    def test_create_lists_round_trip(self, client):
        # Verifies JSON-to-list deserialization on the way out
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        data = resp.get_json()
        assert data["authorized_operations"] == _OPS_PAYLOAD["authorized_operations"]
        assert data["aircraft_type_ratings"]  == _OPS_PAYLOAD["aircraft_type_ratings"]

    def test_retrieve_returns_200(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/ops-specs")
        assert resp.status_code == 200

    def test_retrieve_returns_list(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/ops-specs")
        assert isinstance(resp.get_json(), list)

    def test_retrieve_record_fields(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/ops-specs").get_json()
        assert len(records) > 0
        rec = records[0]
        for key in ["id", "carrier_id", "authorized_operations",
                    "aircraft_type_ratings", "effective_date", "status"]:
            assert key in rec, f"Missing field: {key}"

    def test_retrieve_lists_are_deserialized(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/ops-specs").get_json()
        assert len(records) > 0
        assert isinstance(records[0]["authorized_operations"], list)
        assert isinstance(records[0]["aircraft_type_ratings"],  list)

    def test_retrieve_filtered_by_carrier(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=_OPS_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/ops-specs").get_json()
        for rec in records:
            assert rec["carrier_id"] == TEST_CARRIER

    def test_retrieve_empty_for_carrier_with_no_records(self, client):
        resp = client.get(f"/api/carriers/{FRESH_CARRIER}/ops-specs")
        assert resp.status_code == 200
        records = resp.get_json()
        assert isinstance(records, list)
        assert len(records) == 0

    @pytest.mark.parametrize("status", ["active", "inactive"])
    def test_create_status_values_round_trip(self, client, status):
        # Verifies both prompt-specified status enum values are accepted and stored
        payload = {**_OPS_PAYLOAD, "status": status}
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs", json=payload)
        assert resp.status_code == 201
        assert resp.get_json()["status"] == status


# ===========================================================================
# Inspector Assignments
# ===========================================================================

_INSPECTOR_PAYLOAD = {
    "inspector_id": "INS001",
    "cmo_id": "CMO_WEST",
    "assignment_date": "2024-06-01",
    "role": "principal_inspector",
}

class TestInspectorAssignments:
    def test_create_returns_201(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/inspector-assignments",
                           json=_INSPECTOR_PAYLOAD)
        assert resp.status_code == 201

    def test_create_required_fields_present(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/inspector-assignments",
                           json=_INSPECTOR_PAYLOAD)
        data = resp.get_json()
        for key in ["id", "carrier_id", "inspector_id", "cmo_id", "assignment_date", "role"]:
            assert key in data, f"Missing field: {key}"

    def test_create_id_is_int(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/inspector-assignments",
                           json=_INSPECTOR_PAYLOAD)
        assert isinstance(resp.get_json()["id"], int)

    def test_create_carrier_id_matches_path(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/inspector-assignments",
                           json=_INSPECTOR_PAYLOAD)
        assert resp.get_json()["carrier_id"] == TEST_CARRIER

    def test_retrieve_returns_200(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/inspector-assignments")
        assert resp.status_code == 200

    def test_retrieve_returns_list(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/inspector-assignments")
        assert isinstance(resp.get_json(), list)

    def test_retrieve_record_fields(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/inspector-assignments",
                    json=_INSPECTOR_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/inspector-assignments").get_json()
        assert len(records) > 0
        rec = records[0]
        for key in ["id", "carrier_id", "inspector_id", "cmo_id", "assignment_date", "role"]:
            assert key in rec, f"Missing field: {key}"

    def test_retrieve_filtered_by_carrier(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/inspector-assignments",
                    json=_INSPECTOR_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/inspector-assignments").get_json()
        for rec in records:
            assert rec["carrier_id"] == TEST_CARRIER


# ===========================================================================
# Surveillance Activities
# ===========================================================================

_SURVEILLANCE_PAYLOAD = {
    "activity_type": "en_route_inspection",
    "scheduled_date": "2024-07-15",
    "inspector_id": "INS001",
    "status": "scheduled",
}

class TestSurveillanceActivities:
    def test_create_returns_201(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/surveillance",
                           json=_SURVEILLANCE_PAYLOAD)
        assert resp.status_code == 201

    def test_create_required_fields_present(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/surveillance",
                           json=_SURVEILLANCE_PAYLOAD)
        data = resp.get_json()
        for key in ["id", "carrier_id", "activity_type",
                    "scheduled_date", "inspector_id", "status"]:
            assert key in data, f"Missing field: {key}"

    def test_create_id_is_int(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/surveillance",
                           json=_SURVEILLANCE_PAYLOAD)
        assert isinstance(resp.get_json()["id"], int)

    def test_create_carrier_id_matches_path(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/surveillance",
                           json=_SURVEILLANCE_PAYLOAD)
        assert resp.get_json()["carrier_id"] == TEST_CARRIER

    def test_retrieve_returns_200(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/surveillance")
        assert resp.status_code == 200

    def test_retrieve_returns_list(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/surveillance")
        assert isinstance(resp.get_json(), list)

    def test_retrieve_record_fields(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/surveillance",
                    json=_SURVEILLANCE_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/surveillance").get_json()
        assert len(records) > 0
        rec = records[0]
        for key in ["id", "carrier_id", "activity_type",
                    "scheduled_date", "inspector_id", "status"]:
            assert key in rec, f"Missing field: {key}"

    def test_retrieve_filtered_by_carrier(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/surveillance",
                    json=_SURVEILLANCE_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/surveillance").get_json()
        for rec in records:
            assert rec["carrier_id"] == TEST_CARRIER

    def test_update_status_returns_200(self, client):
        activity_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/surveillance",
            json=_SURVEILLANCE_PAYLOAD).get_json()["id"]
        resp = client.patch(f"/api/surveillance/{activity_id}",
                            json={"status": "completed"})
        assert resp.status_code == 200

    def test_update_status_reflected_in_response(self, client):
        activity_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/surveillance",
            json=_SURVEILLANCE_PAYLOAD).get_json()["id"]
        resp = client.patch(f"/api/surveillance/{activity_id}",
                            json={"status": "completed"})
        assert resp.get_json()["status"] == "completed"

    def test_update_returns_full_record(self, client):
        activity_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/surveillance",
            json=_SURVEILLANCE_PAYLOAD).get_json()["id"]
        data = client.patch(f"/api/surveillance/{activity_id}",
                            json={"status": "completed"}).get_json()
        for key in ["id", "carrier_id", "activity_type",
                    "scheduled_date", "inspector_id", "status"]:
            assert key in data, f"Missing field: {key}"

    def test_update_nonexistent_returns_404(self, client):
        resp = client.patch("/api/surveillance/2147483647",
                            json={"status": "completed"})
        assert resp.status_code == 404

    def test_patch_status_persists_to_database(self, client):
        # Verify the status update is stored, not just reflected in the PATCH response
        activity_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/surveillance",
            json=_SURVEILLANCE_PAYLOAD).get_json()["id"]
        client.patch(f"/api/surveillance/{activity_id}",
                     json={"status": "cancelled"})
        records = client.get(f"/api/carriers/{TEST_CARRIER}/surveillance").get_json()
        match = [r for r in records if r["id"] == activity_id]
        assert len(match) == 1
        assert match[0]["status"] == "cancelled"


# ===========================================================================
# Voluntary Disclosures
# ===========================================================================

_DISCLOSURE_PAYLOAD = {
    "disclosure_date": "2024-08-01",
    "description": "Inadvertent deviation from procedure",
    "submitted_by": "OPS_MANAGER",
}

class TestVoluntaryDisclosures:
    def test_create_returns_201(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/disclosures",
                           json=_DISCLOSURE_PAYLOAD)
        assert resp.status_code == 201

    def test_create_required_fields_present(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/disclosures",
                           json=_DISCLOSURE_PAYLOAD)
        data = resp.get_json()
        for key in ["id", "carrier_id", "disclosure_date",
                    "description", "submitted_by", "status"]:
            assert key in data, f"Missing field: {key}"

    def test_create_id_is_int(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/disclosures",
                           json=_DISCLOSURE_PAYLOAD)
        assert isinstance(resp.get_json()["id"], int)

    def test_create_carrier_id_matches_path(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/disclosures",
                           json=_DISCLOSURE_PAYLOAD)
        assert resp.get_json()["carrier_id"] == TEST_CARRIER

    def test_create_status_always_received(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/disclosures",
                           json=_DISCLOSURE_PAYLOAD)
        assert resp.get_json()["status"] == "received"

    def test_create_status_forced_received_when_body_supplies_other_value(self, client):
        # The prompt requires status be set to "received" regardless of body content
        payload = {**_DISCLOSURE_PAYLOAD, "status": "closed"}
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/disclosures", json=payload)
        assert resp.get_json()["status"] == "received"

    def test_retrieve_returns_200(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/disclosures")
        assert resp.status_code == 200

    def test_retrieve_returns_list(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/disclosures")
        assert isinstance(resp.get_json(), list)

    def test_retrieve_record_fields(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/disclosures",
                    json=_DISCLOSURE_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/disclosures").get_json()
        assert len(records) > 0
        rec = records[0]
        for key in ["id", "carrier_id", "disclosure_date",
                    "description", "submitted_by", "status"]:
            assert key in rec, f"Missing field: {key}"

    def test_retrieve_filtered_by_carrier(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/disclosures",
                    json=_DISCLOSURE_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/disclosures").get_json()
        for rec in records:
            assert rec["carrier_id"] == TEST_CARRIER


# ===========================================================================
# Enforcement Actions
# ===========================================================================

_ENFORCEMENT_PAYLOAD = {
    "inspector_id": "INS001",
    "finding_id": "FIND001",
    "action_type": "civil_penalty",
    "initiated_date": "2024-09-01",
    "status": "open",
}

class TestEnforcementActions:
    def test_create_returns_201(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
                           json=_ENFORCEMENT_PAYLOAD)
        assert resp.status_code == 201

    def test_create_required_fields_present(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
                           json=_ENFORCEMENT_PAYLOAD)
        data = resp.get_json()
        for key in ["id", "carrier_id", "inspector_id", "finding_id",
                    "action_type", "initiated_date", "status"]:
            assert key in data, f"Missing field: {key}"

    def test_create_id_is_int(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
                           json=_ENFORCEMENT_PAYLOAD)
        assert isinstance(resp.get_json()["id"], int)

    def test_create_carrier_id_matches_path(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
                           json=_ENFORCEMENT_PAYLOAD)
        assert resp.get_json()["carrier_id"] == TEST_CARRIER

    def test_retrieve_returns_200(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/enforcement-actions")
        assert resp.status_code == 200

    def test_retrieve_returns_list(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/enforcement-actions")
        assert isinstance(resp.get_json(), list)

    def test_retrieve_record_fields(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
                    json=_ENFORCEMENT_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/enforcement-actions").get_json()
        assert len(records) > 0
        rec = records[0]
        for key in ["id", "carrier_id", "inspector_id", "finding_id",
                    "action_type", "initiated_date", "status"]:
            assert key in rec, f"Missing field: {key}"

    def test_retrieve_filtered_by_carrier(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
                    json=_ENFORCEMENT_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/enforcement-actions").get_json()
        for rec in records:
            assert rec["carrier_id"] == TEST_CARRIER

    def test_update_status_returns_200(self, client):
        action_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
            json=_ENFORCEMENT_PAYLOAD).get_json()["id"]
        resp = client.patch(f"/api/enforcement-actions/{action_id}",
                            json={"status": "closed"})
        assert resp.status_code == 200

    def test_update_status_reflected_in_response(self, client):
        action_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
            json=_ENFORCEMENT_PAYLOAD).get_json()["id"]
        resp = client.patch(f"/api/enforcement-actions/{action_id}",
                            json={"status": "closed"})
        assert resp.get_json()["status"] == "closed"

    def test_update_returns_full_record(self, client):
        action_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
            json=_ENFORCEMENT_PAYLOAD).get_json()["id"]
        data = client.patch(f"/api/enforcement-actions/{action_id}",
                            json={"status": "closed"}).get_json()
        for key in ["id", "carrier_id", "inspector_id", "finding_id",
                    "action_type", "initiated_date", "status"]:
            assert key in data, f"Missing field: {key}"

    def test_update_nonexistent_returns_404(self, client):
        resp = client.patch("/api/enforcement-actions/2147483647",
                            json={"status": "closed"})
        assert resp.status_code == 404

    def test_patch_status_persists_to_database(self, client):
        # Verify the status update is stored, not just reflected in the PATCH response
        action_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
            json=_ENFORCEMENT_PAYLOAD).get_json()["id"]
        client.patch(f"/api/enforcement-actions/{action_id}",
                     json={"status": "pending"})
        records = client.get(f"/api/carriers/{TEST_CARRIER}/enforcement-actions").get_json()
        match = [r for r in records if r["id"] == action_id]
        assert len(match) == 1
        assert match[0]["status"] == "pending"


# ===========================================================================
# Emergency Actions
# ===========================================================================

_EMERGENCY_PAYLOAD = {
    "action_type": "revocation",
    "reason": "Repeated safety violations",
    "issued_date": "2024-10-01",
    "status": "issued",
}

class TestEmergencyActions:
    def test_create_returns_201(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/emergency-actions",
                           json=_EMERGENCY_PAYLOAD)
        assert resp.status_code == 201

    def test_create_required_fields_present(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/emergency-actions",
                           json=_EMERGENCY_PAYLOAD)
        data = resp.get_json()
        for key in ["id", "carrier_id", "action_type", "reason", "issued_date", "status"]:
            assert key in data, f"Missing field: {key}"

    def test_create_id_is_int(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/emergency-actions",
                           json=_EMERGENCY_PAYLOAD)
        assert isinstance(resp.get_json()["id"], int)

    def test_create_carrier_id_matches_path(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/emergency-actions",
                           json=_EMERGENCY_PAYLOAD)
        assert resp.get_json()["carrier_id"] == TEST_CARRIER

    def test_retrieve_returns_200(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/emergency-actions")
        assert resp.status_code == 200

    def test_retrieve_returns_list(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/emergency-actions")
        assert isinstance(resp.get_json(), list)

    def test_retrieve_record_fields(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/emergency-actions",
                    json=_EMERGENCY_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/emergency-actions").get_json()
        assert len(records) > 0
        rec = records[0]
        for key in ["id", "carrier_id", "action_type", "reason", "issued_date", "status"]:
            assert key in rec, f"Missing field: {key}"

    def test_retrieve_filtered_by_carrier(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/emergency-actions",
                    json=_EMERGENCY_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/emergency-actions").get_json()
        for rec in records:
            assert rec["carrier_id"] == TEST_CARRIER

    @pytest.mark.parametrize("action_type", ["revocation", "amendment"])
    def test_create_action_type_values_round_trip(self, client, action_type):
        # Verifies both prompt-specified action_type enum values are accepted and stored
        payload = {**_EMERGENCY_PAYLOAD, "action_type": action_type}
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/emergency-actions",
                           json=payload)
        assert resp.status_code == 201
        assert resp.get_json()["action_type"] == action_type

    @pytest.mark.parametrize("status", ["issued", "appealed", "final"])
    def test_create_status_values_round_trip(self, client, status):
        # Verifies all three prompt-specified status enum values are accepted and stored
        payload = {**_EMERGENCY_PAYLOAD, "status": status}
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/emergency-actions",
                           json=payload)
        assert resp.status_code == 201
        assert resp.get_json()["status"] == status


# ===========================================================================
# AD Compliance
# ===========================================================================

_AD_PAYLOAD = {
    "ad_id": "AD-2024-001",
    "compliance_status": "compliant",
    "due_date": "2024-12-31",
    "notes": "Completed per maintenance schedule",
}

class TestADCompliance:
    def test_create_returns_201(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ad-compliance",
                           json=_AD_PAYLOAD)
        assert resp.status_code == 201

    def test_create_required_fields_present(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ad-compliance",
                           json=_AD_PAYLOAD)
        data = resp.get_json()
        for key in ["id", "carrier_id", "ad_id", "compliance_status", "due_date", "notes"]:
            assert key in data, f"Missing field: {key}"

    def test_create_id_is_int(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ad-compliance",
                           json=_AD_PAYLOAD)
        assert isinstance(resp.get_json()["id"], int)

    def test_create_carrier_id_matches_path(self, client):
        resp = client.post(f"/api/carriers/{TEST_CARRIER}/ad-compliance",
                           json=_AD_PAYLOAD)
        assert resp.get_json()["carrier_id"] == TEST_CARRIER

    def test_retrieve_returns_200(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/ad-compliance")
        assert resp.status_code == 200

    def test_retrieve_returns_list(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/ad-compliance")
        assert isinstance(resp.get_json(), list)

    def test_retrieve_record_fields(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/ad-compliance", json=_AD_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/ad-compliance").get_json()
        assert len(records) > 0
        rec = records[0]
        for key in ["id", "carrier_id", "ad_id", "compliance_status", "due_date", "notes"]:
            assert key in rec, f"Missing field: {key}"

    def test_retrieve_filtered_by_carrier(self, client):
        client.post(f"/api/carriers/{TEST_CARRIER}/ad-compliance", json=_AD_PAYLOAD)
        records = client.get(f"/api/carriers/{TEST_CARRIER}/ad-compliance").get_json()
        for rec in records:
            assert rec["carrier_id"] == TEST_CARRIER

    def test_update_returns_200(self, client):
        record_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/ad-compliance",
            json=_AD_PAYLOAD).get_json()["id"]
        resp = client.patch(f"/api/ad-compliance/{record_id}",
                            json={"compliance_status": "non_compliant", "notes": "Overdue"})
        assert resp.status_code == 200

    def test_update_compliance_status_reflected(self, client):
        record_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/ad-compliance",
            json=_AD_PAYLOAD).get_json()["id"]
        resp = client.patch(f"/api/ad-compliance/{record_id}",
                            json={"compliance_status": "non_compliant", "notes": "Overdue"})
        assert resp.get_json()["compliance_status"] == "non_compliant"

    def test_update_notes_reflected(self, client):
        record_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/ad-compliance",
            json=_AD_PAYLOAD).get_json()["id"]
        resp = client.patch(f"/api/ad-compliance/{record_id}",
                            json={"compliance_status": "non_compliant", "notes": "Overdue"})
        assert resp.get_json()["notes"] == "Overdue"

    def test_update_returns_full_record(self, client):
        record_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/ad-compliance",
            json=_AD_PAYLOAD).get_json()["id"]
        data = client.patch(
            f"/api/ad-compliance/{record_id}",
            json={"compliance_status": "non_compliant", "notes": "Overdue"}).get_json()
        for key in ["id", "carrier_id", "ad_id", "compliance_status", "due_date", "notes"]:
            assert key in data, f"Missing field: {key}"

    def test_update_nonexistent_returns_404(self, client):
        resp = client.patch("/api/ad-compliance/2147483647",
                            json={"compliance_status": "pending", "notes": "test"})
        assert resp.status_code == 404

    def test_patch_fields_persist_to_database(self, client):
        # Verify both updated fields are stored, not just reflected in the PATCH response
        record_id = client.post(
            f"/api/carriers/{TEST_CARRIER}/ad-compliance",
            json=_AD_PAYLOAD).get_json()["id"]
        client.patch(f"/api/ad-compliance/{record_id}",
                     json={"compliance_status": "pending", "notes": "Updated note"})
        records = client.get(f"/api/carriers/{TEST_CARRIER}/ad-compliance").get_json()
        match = [r for r in records if r["id"] == record_id]
        assert len(match) == 1
        assert match[0]["compliance_status"] == "pending"
        assert match[0]["notes"] == "Updated note"


# ===========================================================================
# Date Formats - every date field must be returned in YYYY-MM-DD format
# ===========================================================================

class TestDateFormats:
    def test_ops_spec_effective_date_format(self, client):
        data = client.post(f"/api/carriers/{TEST_CARRIER}/ops-specs",
                           json=_OPS_PAYLOAD).get_json()
        assert re.match(r"^\d{4}-\d{2}-\d{2}$", str(data["effective_date"])), \
            f"effective_date not in YYYY-MM-DD format: {data['effective_date']}"

    def test_inspector_assignment_date_format(self, client):
        data = client.post(f"/api/carriers/{TEST_CARRIER}/inspector-assignments",
                           json=_INSPECTOR_PAYLOAD).get_json()
        assert re.match(r"^\d{4}-\d{2}-\d{2}$", str(data["assignment_date"])), \
            f"assignment_date not in YYYY-MM-DD format: {data['assignment_date']}"

    def test_surveillance_scheduled_date_format(self, client):
        data = client.post(f"/api/carriers/{TEST_CARRIER}/surveillance",
                           json=_SURVEILLANCE_PAYLOAD).get_json()
        assert re.match(r"^\d{4}-\d{2}-\d{2}$", str(data["scheduled_date"])), \
            f"scheduled_date not in YYYY-MM-DD format: {data['scheduled_date']}"

    def test_disclosure_date_format(self, client):
        data = client.post(f"/api/carriers/{TEST_CARRIER}/disclosures",
                           json=_DISCLOSURE_PAYLOAD).get_json()
        assert re.match(r"^\d{4}-\d{2}-\d{2}$", str(data["disclosure_date"])), \
            f"disclosure_date not in YYYY-MM-DD format: {data['disclosure_date']}"

    def test_enforcement_initiated_date_format(self, client):
        data = client.post(f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
                           json=_ENFORCEMENT_PAYLOAD).get_json()
        assert re.match(r"^\d{4}-\d{2}-\d{2}$", str(data["initiated_date"])), \
            f"initiated_date not in YYYY-MM-DD format: {data['initiated_date']}"

    def test_emergency_issued_date_format(self, client):
        data = client.post(f"/api/carriers/{TEST_CARRIER}/emergency-actions",
                           json=_EMERGENCY_PAYLOAD).get_json()
        assert re.match(r"^\d{4}-\d{2}-\d{2}$", str(data["issued_date"])), \
            f"issued_date not in YYYY-MM-DD format: {data['issued_date']}"

    def test_ad_compliance_due_date_format(self, client):
        data = client.post(f"/api/carriers/{TEST_CARRIER}/ad-compliance",
                           json=_AD_PAYLOAD).get_json()
        assert re.match(r"^\d{4}-\d{2}-\d{2}$", str(data["due_date"])), \
            f"due_date not in YYYY-MM-DD format: {data['due_date']}"


# ===========================================================================
# Regulatory Report
# ===========================================================================

class TestRegulatoryReport:
    def test_retrieve_returns_200(self, client):
        resp = client.get(f"/api/carriers/{SEEDED_CARRIER}/report")
        assert resp.status_code == 200

    def test_report_top_level_keys_present(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        for key in [
            "carrier_id", "total_surveillance", "surveillance_by_status",
            "total_enforcement_actions", "enforcement_by_status",
            "total_disclosures", "disclosures_by_status",
            "total_ad_compliance", "ad_by_status",
            "spas_submission_ready", "congressional_oversight_scope",
        ]:
            assert key in data, f"Missing top-level key: {key}"

    def test_report_carrier_id_matches(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        assert data["carrier_id"] == SEEDED_CARRIER

    def test_report_totals_are_int(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        for key in ["total_surveillance", "total_enforcement_actions",
                    "total_disclosures", "total_ad_compliance"]:
            assert isinstance(data[key], int), f"{key} must be int"

    def test_report_surveillance_by_status_keys(self, client):
        sbs = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()["surveillance_by_status"]
        for key in ["scheduled", "completed", "cancelled"]:
            assert key in sbs, f"Missing surveillance_by_status key: {key}"

    def test_report_enforcement_by_status_keys(self, client):
        ebs = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()["enforcement_by_status"]
        for key in ["open", "pending", "closed"]:
            assert key in ebs, f"Missing enforcement_by_status key: {key}"

    def test_report_disclosures_by_status_keys(self, client):
        dbs = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()["disclosures_by_status"]
        for key in ["received", "under_review", "closed"]:
            assert key in dbs, f"Missing disclosures_by_status key: {key}"

    def test_report_ad_by_status_keys(self, client):
        abs_ = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()["ad_by_status"]
        for key in ["compliant", "non_compliant", "pending"]:
            assert key in abs_, f"Missing ad_by_status key: {key}"

    def test_report_status_bucket_values_are_int(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        for bucket in ["surveillance_by_status", "enforcement_by_status",
                       "disclosures_by_status", "ad_by_status"]:
            for k, v in data[bucket].items():
                assert isinstance(v, int), f"{bucket}[{k}] must be int"

    def test_report_congressional_oversight_scope(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        assert data["congressional_oversight_scope"] == "FAA_PART_121"

    def test_report_spas_submission_ready_is_bool(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        assert isinstance(data["spas_submission_ready"], bool)

    def test_report_spas_true_when_all_modules_have_records(self, client):
        # SEEDED_CARRIER has >= 1 record in all 4 relevant module tables
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        assert data["spas_submission_ready"] is True

    def test_report_spas_false_when_no_records(self, client):
        # FRESH_CARRIER has no records in any module table
        data = client.get(f"/api/carriers/{FRESH_CARRIER}/report").get_json()
        assert data["spas_submission_ready"] is False

    def test_report_spas_false_when_one_module_has_no_records(self, client):
        client.post(f"/api/carriers/{PARTIAL_CARRIER}/surveillance",
                    json=_SURVEILLANCE_PAYLOAD)
        client.post(f"/api/carriers/{PARTIAL_CARRIER}/enforcement-actions",
                    json=_ENFORCEMENT_PAYLOAD)
        client.post(f"/api/carriers/{PARTIAL_CARRIER}/disclosures",
                    json=_DISCLOSURE_PAYLOAD)
        data = client.get(f"/api/carriers/{PARTIAL_CARRIER}/report").get_json()
        assert data["spas_submission_ready"] is False

    def test_report_all_status_buckets_present_with_zero_for_empty_carrier(self, client):
        # All status bucket keys must appear even when the carrier has no records
        data = client.get(f"/api/carriers/{FRESH_CARRIER}/report").get_json()
        expected = {
            "surveillance_by_status": ["scheduled", "completed", "cancelled"],
            "enforcement_by_status":  ["open", "pending", "closed"],
            "disclosures_by_status":  ["received", "under_review", "closed"],
            "ad_by_status":           ["compliant", "non_compliant", "pending"],
        }
        for bucket, keys in expected.items():
            for k in keys:
                assert k in data[bucket], f"{bucket}[{k}] must be present even when zero"
                assert data[bucket][k] == 0, f"{bucket}[{k}] must equal 0 for carrier with no records"

    def test_total_surveillance_equals_sum_of_status_counts(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        assert data["total_surveillance"] == sum(data["surveillance_by_status"].values())

    def test_total_enforcement_actions_equals_sum_of_status_counts(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        assert data["total_enforcement_actions"] == sum(data["enforcement_by_status"].values())

    def test_total_disclosures_equals_sum_of_status_counts(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        assert data["total_disclosures"] == sum(data["disclosures_by_status"].values())

    def test_total_ad_compliance_equals_sum_of_status_counts(self, client):
        data = client.get(f"/api/carriers/{SEEDED_CARRIER}/report").get_json()
        assert data["total_ad_compliance"] == sum(data["ad_by_status"].values())

    def test_report_surveillance_count_increments_on_create(self, client):
        # Verifies aggregation reflects API-created records, not just seed data
        before = client.get(f"/api/carriers/{TEST_CARRIER}/report").get_json()
        client.post(f"/api/carriers/{TEST_CARRIER}/surveillance",
                    json=_SURVEILLANCE_PAYLOAD)
        after = client.get(f"/api/carriers/{TEST_CARRIER}/report").get_json()
        assert after["total_surveillance"] == before["total_surveillance"] + 1

    def test_report_enforcement_count_increments_on_create(self, client):
        before = client.get(f"/api/carriers/{TEST_CARRIER}/report").get_json()
        client.post(f"/api/carriers/{TEST_CARRIER}/enforcement-actions",
                    json=_ENFORCEMENT_PAYLOAD)
        after = client.get(f"/api/carriers/{TEST_CARRIER}/report").get_json()
        assert after["total_enforcement_actions"] == before["total_enforcement_actions"] + 1

    def test_report_disclosure_count_increments_on_create(self, client):
        before = client.get(f"/api/carriers/{TEST_CARRIER}/report").get_json()
        client.post(f"/api/carriers/{TEST_CARRIER}/disclosures",
                    json=_DISCLOSURE_PAYLOAD)
        after = client.get(f"/api/carriers/{TEST_CARRIER}/report").get_json()
        assert after["total_disclosures"] == before["total_disclosures"] + 1

    def test_report_ad_compliance_count_increments_on_create(self, client):
        before = client.get(f"/api/carriers/{TEST_CARRIER}/report").get_json()
        client.post(f"/api/carriers/{TEST_CARRIER}/ad-compliance",
                    json=_AD_PAYLOAD)
        after = client.get(f"/api/carriers/{TEST_CARRIER}/report").get_json()
        assert after["total_ad_compliance"] == before["total_ad_compliance"] + 1