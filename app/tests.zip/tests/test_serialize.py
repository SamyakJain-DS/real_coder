import pytest

from nacha import parse_file, serialize_file

from tests.helpers import (
    build_file_text,
    simple_credit_entry,
    simple_debit_entry,
    make_iat_addenda,
)



def test_round_trip_multiple_batches_byte_identical():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
        {"sec_code": "CCD", "entries": [simple_debit_entry()]},
        {"sec_code": "WEB", "entries": [simple_credit_entry()]},
    ])
    assert serialize_file(parse_file(text)) == text


def test_round_trip_crlf_byte_identical():
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry()]}],
        line_terminator="\r\n",
    )
    assert serialize_file(parse_file(text)) == text


@pytest.mark.parametrize("sec_code", [
    "PPD", "CCD", "CTX", "WEB", "TEL", "IAT", "ARC", "BOC", "POP", "RCK",
])
def test_round_trip_all_sec_codes_byte_identical(sec_code):
    if sec_code == "IAT":
        entries = [{**simple_credit_entry(), "addenda": make_iat_addenda()}]
    elif sec_code == "CTX":
        entries = [{**simple_credit_entry(),
                    "addenda": [("05", "P1"), ("05", "P2")]}]
    elif sec_code in ("PPD", "CCD", "WEB", "TEL"):
        entries = [{**simple_credit_entry(),
                    "addenda_indicator": "1",
                    "addenda": [("05", "REMIT")]}]
    else:  # ARC, BOC, POP, RCK
        entries = [{**simple_debit_entry(), "addenda_indicator": "0"}]
    text = build_file_text([{"sec_code": sec_code, "entries": entries}])
    assert serialize_file(parse_file(text)) == text


def test_round_trip_preserves_mixed_case_and_whitespace():
    # Many ODFI partners emit MiXeD casing or unusual whitespace in
    # alphanumeric slots — round-trip must keep those exact bytes.
    text = build_file_text(
        [{"sec_code": "PPD",
          "entries": [simple_credit_entry()]}],
        file_header_overrides={
            "immediate_destination_name": "MiXeD CaSe BaNk        ",
            "immediate_origin_name":      "  pre-padded company   ",
            "reference_code":             "rEf1 23 ",
        },
    )
    out = serialize_file(parse_file(text))
    assert out == text


def test_round_trip_preserves_filler_characters_in_payload():
    odd_payload = ("X" * 20 + " " * 40 + "Z" * 20)  # 80 chars
    text = build_file_text([
        {"sec_code": "CTX",
         "entries": [{**simple_credit_entry(),
                      "addenda": [("05", odd_payload)]}]},
    ])
    assert serialize_file(parse_file(text)) == text


# ---------------------------------------------------------------------------
# Gap 2: mutated typed field appears at the correct NACHA-specified position
# ---------------------------------------------------------------------------

def test_serialize_mutated_typed_field_appears_at_correct_nacha_position():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    new_name = "CHANGED BANK NAME      "  # exactly 23 chars
    parsed.file_header.immediate_destination_name = new_name
    out = serialize_file(parsed)
    first_line = out.split(parsed.line_terminator)[0]
    assert len(first_line) == 94
    assert first_line[40:63] == new_name


def test_serialize_mutated_batch_header_field_appears_at_correct_nacha_position():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    new_company = "NEWCO           "  # exactly 16 chars
    parsed.batches[0].batch_header.company_name = new_company
    out = serialize_file(parsed)
    # Batch header is the second line (index 1).
    batch_line = out.split(parsed.line_terminator)[1]
    assert len(batch_line) == 94
    assert batch_line[4:20] == new_company


def test_serialize_mutated_entry_detail_field_appears_at_correct_nacha_position():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    new_individual = "CHANGED NAME          "  # exactly 22 chars
    parsed.batches[0].entries[0].entry_detail.individual_name = new_individual
    out = serialize_file(parsed)
    # Entry detail is the third line (index 2).
    entry_line = out.split(parsed.line_terminator)[2]
    assert len(entry_line) == 94
    assert entry_line[54:76] == new_individual


def test_serialize_mutated_addenda_field_appears_at_correct_nacha_position():
    text = build_file_text([
        {"sec_code": "CTX",
         "entries": [{**simple_credit_entry(),
                      "addenda": [("05", "ORIGINAL" + " " * 72)]}]},
    ])
    parsed = parse_file(text)
    new_payload = "CHANGED" + " " * 73  # exactly 80 chars
    parsed.batches[0].entries[0].addenda[0].payload = new_payload
    out = serialize_file(parsed)
    # File: header(0) batch_header(1) entry(2) addenda(3) batch_ctrl(4) file_ctrl(5) ...
    addenda_line = out.split(parsed.line_terminator)[3]
    assert len(addenda_line) == 94
    assert addenda_line[3:83] == new_payload


# ---------------------------------------------------------------------------
# Gap #4: mutated BatchControl and FileControl fields at correct NACHA positions
# ---------------------------------------------------------------------------

def test_serialize_mutated_batch_control_field_appears_at_correct_nacha_position():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    new_scc = "220"  # exactly 3 chars; non-control field
    parsed.batches[0].batch_control.service_class_code = new_scc
    out = serialize_file(parsed)
    # For a single-entry PPD file (padded): header(0) batch_header(1) entry(2)
    # batch_control(3) file_control(4) padding(5-9).
    batch_ctrl_line = out.split(parsed.line_terminator)[3]
    assert len(batch_ctrl_line) == 94
    assert batch_ctrl_line[1:4] == new_scc


def test_serialize_mutated_file_control_field_appears_at_correct_nacha_position():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    new_reserved = "R" * 39  # exactly 39 chars; non-control field
    parsed.file_control.reserved = new_reserved
    out = serialize_file(parsed)
    # For a single-entry PPD file (padded): file_control is at index 4.
    file_ctrl_line = out.split(parsed.line_terminator)[4]
    assert len(file_ctrl_line) == 94
    assert file_ctrl_line[55:94] == new_reserved