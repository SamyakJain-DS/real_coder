import sys
import io
import subprocess
import pytest
from pathlib import Path

sys.path.insert(0, '/app')


def run_main(argv):
    """Invoke main(), capturing stdout/stderr. Returns (exit_code, stdout, stderr)."""
    from gitignore_audit.__main__ import main
    stdout_cap = io.StringIO()
    stderr_cap = io.StringIO()
    old_out, old_err = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = stdout_cap, stderr_cap
    try:
        code = main(argv)
    finally:
        sys.stdout, sys.stderr = old_out, old_err
    return code, stdout_cap.getvalue(), stderr_cap.getvalue()


# -- Exit Codes ----------------------------------------------------------------

def test_invalid_root_returns_exit_2(tmp_path):
    code, _, _ = run_main([str(tmp_path / "nonexistent_path")])
    assert code == 2


def test_root_is_existing_file_returns_exit_2(tmp_path):
    # Req 1/2: exit 2 when ROOT resolves to something that exists but is NOT a directory.
    f = tmp_path / "not_a_dir.txt"
    f.write_text("x")
    code, _, _ = run_main([str(f)])
    assert code == 2


def test_invalid_root_stderr_message(tmp_path):
    root = tmp_path / "nonexistent_path"
    _, _, err = run_main([str(root)])
    resolved = Path(str(root)).resolve(strict=False)
    assert err == f"error: ROOT is not a directory: {resolved}\n"


def test_clean_stderr_empty(tmp_path):
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    code, _, err = run_main([str(tmp_path)])
    assert code == 0
    assert err == ""


def test_issues_stderr_empty(tmp_path):
    (tmp_path / ".gitignore").write_text("*.nomatches_xyz\n", encoding="utf-8")
    code, _, err = run_main([str(tmp_path)])
    assert code == 1
    assert err == ""


# -- Discovery -----------------------------------------------------------------

def test_relative_root_resolved(tmp_path, monkeypatch):
    # Req 10: when ROOT is not absolute the tool MUST resolve it against CWD.
    (tmp_path / ".gitignore").write_text("*.nomatches_xyz\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path.parent)
    code, out, _ = run_main([tmp_path.name])
    assert code == 1
    assert "*.nomatches_xyz" in out


def test_git_dir_excluded(tmp_path):
    git_dir = tmp_path / ".git"
    git_dir.mkdir()
    (git_dir / ".gitignore").write_text("*.secret\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "=== .git/.gitignore ===" not in out


def test_nested_git_dir_excluded(tmp_path):
    # Req 9: every directory named .git must be excluded at any depth, not only at ROOT level.
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    nested_git = pkg / ".git"
    nested_git.mkdir()
    (nested_git / ".gitignore").write_text("*.secret\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "pkg/.git/.gitignore" not in out


def test_gitignore_files_collected(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (tmp_path / ".gitignore").write_text("*.nomatches_root\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.nomatches_sub\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "=== .gitignore ===" in out
    assert "sub/.gitignore" in out


def test_discovery_shallowest_first(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (tmp_path / ".gitignore").write_text("*.dead1\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.dead2\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    pos_root = out.find("=== .gitignore ===")
    pos_sub = out.find("=== sub/.gitignore ===")
    assert pos_root < pos_sub


def test_directory_traversal_sorted_lexicographic(tmp_path):
    z_dir = tmp_path / "z_pkg"
    a_dir = tmp_path / "a_pkg"
    z_dir.mkdir()
    a_dir.mkdir()
    (z_dir / ".gitignore").write_text("*.dead_z\n", encoding="utf-8")
    (a_dir / ".gitignore").write_text("*.dead_a\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    pos_a = out.find("a_pkg/.gitignore")
    pos_z = out.find("z_pkg/.gitignore")
    assert pos_a < pos_z


def test_discovery_order_absolute_path_bytes_not_name_sort(tmp_path):
    a_dir = tmp_path / "a"
    a_dash_dir = tmp_path / "a-"
    a_dir.mkdir()
    a_dash_dir.mkdir()
    (a_dir / ".gitignore").write_text("*.dead_a\n", encoding="utf-8")
    (a_dash_dir / ".gitignore").write_text("*.dead_adash\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    pos_a = out.find("=== a/.gitignore ===")
    pos_a_dash = out.find("=== a-/.gitignore ===")
    # '-' (0x2D) < '/' (0x2F) → a-/ sorts before a/ in absolute-path byte order
    assert pos_a_dash < pos_a


# -- Pattern Parsing -----------------------------------------------------------

def test_cr_stripped_from_line(tmp_path):
    (tmp_path / ".gitignore").write_bytes(b"*.log\r\n*.tmp\r\n")
    (tmp_path / "file.log").write_text("x")
    (tmp_path / "file.tmp").write_text("x")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_single_cr_stripped_double_cr_retains_one(tmp_path):
    # Req 13: strip exactly ONE trailing \r - no more, no less.
    (tmp_path / ".gitignore").write_bytes(b"*.nomatches\r\r\n")
    _, out, _ = run_main([str(tmp_path)])
    assert "*.nomatches\r" in out       # at least one \r retained in raw
    assert "*.nomatches\r\r" not in out  # but not two


def test_blank_line_not_treated_as_pattern(tmp_path):
    (tmp_path / ".gitignore").write_text("\n\n*.log\n\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_comment_line_not_treated_as_pattern(tmp_path):
    (tmp_path / ".gitignore").write_text("# This is a comment\n*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_comment_with_leading_whitespace(tmp_path):
    # Req 15: "first non-whitespace character is #" - leading spaces before # must also be a comment
    (tmp_path / ".gitignore").write_text("  # indented comment\n*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_non_blank_non_comment_is_pattern(tmp_path):
    # Req 16: any line that is neither blank nor a comment is classified as a pattern.
    (tmp_path / ".gitignore").write_text("plaintext_nocomment\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "plaintext_nocomment" in out


def test_body_trailing_whitespace_stripped(tmp_path):
    (tmp_path / ".gitignore").write_text("*.log   \n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_body_backslash_preserves_trailing_space(tmp_path):
    (tmp_path / "hello ").write_text("x")
    (tmp_path / ".gitignore").write_text("hello\\ \n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_pattern_text_strips_leading_exclamation(tmp_path):
    # Req 20: pattern_text removes a single leading ! from body when negated is true.
    (tmp_path / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("!*.log\n", encoding="utf-8")
    code, out, _ = run_main([str(tmp_path)])
    assert code == 0
    assert "dead:" not in out


# -- Pattern Matching ----------------------------------------------------------

def test_star_matches_any_sequence_without_slash(tmp_path):
    (tmp_path / "foo.log").write_text("x")
    (tmp_path / "bar.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_question_matches_one_nonslash_character(tmp_path):
    (tmp_path / "ab").write_text("x")
    (tmp_path / ".gitignore").write_text("a?\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_leading_double_star_slash_matches_any_depth(tmp_path):
    deep = tmp_path / "a" / "b"
    deep.mkdir(parents=True)
    (deep / "target.txt").write_text("x")
    (tmp_path / "target.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("**/target.txt\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_trailing_double_star_matches_all_under_prefix(tmp_path):
    logs = tmp_path / "logs"
    logs.mkdir()
    (logs / "a.txt").write_text("x")
    deep = logs / "deep"
    deep.mkdir()
    (deep / "b.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("logs/**\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_leading_slash_anchors_to_owning_dir(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "README.md").write_text("x")
    (tmp_path / ".gitignore").write_text("/README.md\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 1


def test_trailing_slash_restricts_to_directories(tmp_path):
    (tmp_path / "dist2").mkdir()
    (tmp_path / ".gitignore").write_text("dist2/\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_dir_only_does_not_match_regular_file(tmp_path):
    # Req 26: trailing / restricts matches to directories; a regular file with the same name must not match
    (tmp_path / "build").write_text("x")  # regular file, not a directory
    (tmp_path / ".gitignore").write_text("build/\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 1


def test_zero_slash_pattern_matches_every_depth(tmp_path):
    deep = tmp_path / "a" / "b"
    deep.mkdir(parents=True)
    (deep / "log.txt").write_text("x")
    (tmp_path / "log.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("log.txt\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_single_trailing_slash_matches_every_depth(tmp_path):
    deep = tmp_path / "deep"
    deep.mkdir()
    inner = deep / "build"
    inner.mkdir()
    (tmp_path / ".gitignore").write_text("build/\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_mid_slash_pattern_anchored_to_owning_dir(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "src").mkdir()
    (sub / "src" / "main.py").write_text("x")
    (tmp_path / ".gitignore").write_text("src/main.py\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 1


def test_character_class_matching(tmp_path):
    (tmp_path / "file_a.txt").write_text("x")
    (tmp_path / "file_b.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("file_[ab].txt\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_character_class_negation_in_brackets(tmp_path):
    (tmp_path / "file_c.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("file_[!ab].txt\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_backslash_escapes_next_character(tmp_path):
    (tmp_path / "file#name.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("file\\#name.txt\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


# -- Classification ------------------------------------------------------------

def test_dead_nonnegated_empty_match_set(tmp_path):
    (tmp_path / ".gitignore").write_text("*.xyz_nomatches\n", encoding="utf-8")
    code, out, _ = run_main([str(tmp_path)])
    assert code == 1
    assert "dead:" in out


def test_dead_negated_empty_match_set(tmp_path):
    (tmp_path / ".gitignore").write_text("!*.xyz_nomatches\n", encoding="utf-8")
    code, out, _ = run_main([str(tmp_path)])
    assert code == 1
    assert "dead:" in out


def test_conflict_negated_intersects_excluded(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("!*.log\n", encoding="utf-8")
    code, out, _ = run_main([str(tmp_path)])
    assert code == 1
    assert "conflict:" in out


def test_shadowed_match_set_subset_of_excluded(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log\n", encoding="utf-8")
    code, out, _ = run_main([str(tmp_path)])
    assert code == 1
    assert "shadowed:" in out


def test_active_when_no_other_rule_matches(tmp_path):
    # Req 36: a pattern that fails all preceding rules (dead, conflict, shadowed) is active.
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (tmp_path / "app.log").write_text("x")
    _, out, _ = run_main([str(tmp_path)])
    assert "dead:" not in out
    assert "shadowed:" not in out
    assert "conflict:" not in out


def test_excluded_g_negated_ancestor_removes_paths(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (sub / "special.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n!special.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_ancestor_source_line_order(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n!*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_excluded_g_multi_level_ancestors_processed_in_depth_order(tmp_path):
    a_dir = tmp_path / "a"
    b_dir = a_dir / "b"
    b_dir.mkdir(parents=True)
    (b_dir / "file.log").write_text("x")
    (b_dir / "other.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (a_dir / ".gitignore").write_text("!file.log\n", encoding="utf-8")
    (b_dir / ".gitignore").write_text("*.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "=== a/b/.gitignore ===" not in out


def test_ancestor_reference_uses_greatest_depth(tmp_path):
    a_dir = tmp_path / "a"
    b_dir = a_dir / "b"
    c_dir = b_dir / "c"
    c_dir.mkdir(parents=True)
    (c_dir / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (a_dir / ".gitignore").write_text("*.txt\n*.log\n", encoding="utf-8")
    (b_dir / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (c_dir / ".gitignore").write_text("*.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "covered by a/b/.gitignore" in out


def test_ancestor_reference_nonmatching_pattern_excluded(tmp_path):
    # Req 40/41: ancestor_reference selection must only consider patterns whose match
    # set, restricted to the owning directory, overlaps the shadowed pattern's match set.
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.txt\n*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert ":L2" in out


def test_ancestor_reference_same_depth_two_candidates_greatest_line_wins(tmp_path):
    # Req 41: true tie-breaking - two ancestor patterns at the SAME depth both
    # covering the shadowed file; the one with the greatest line number must win.
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("file.log\n*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert ".gitignore:L2" in out


def test_conflict_ancestor_reference_greatest_depth(tmp_path):
    a_dir = tmp_path / "a"
    sub = a_dir / "sub"
    sub.mkdir(parents=True)
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")   # depth 0
    (a_dir / ".gitignore").write_text("*.log\n", encoding="utf-8")      # depth 1 (greatest)
    (sub / ".gitignore").write_text("!*.log\n", encoding="utf-8")       # conflict
    _, out, _ = run_main([str(tmp_path)])
    assert "contradicts a/.gitignore:L1" in out


def test_ancestor_reference_negated_pattern_excluded_as_candidate(tmp_path):
    # Req 40/41: only NON-NEGATED ancestor patterns are candidates for ancestor_reference.
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "f1.log").write_text("x")
    (sub / "f2.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n!f2.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("!*.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "contradicts .gitignore:L1" in out


def test_conflict_ancestor_reference_requires_match_set_intersection(tmp_path):
    # Req 40: for conflict, candidates are restricted to ancestors whose match set
    # INTERSECTS with the conflict pattern's match set - a deeper ancestor that covers
    # different files must not be selected.
    a_dir = tmp_path / "a"
    sub = a_dir / "sub"
    sub.mkdir(parents=True)
    (sub / "f1.log").write_text("x")
    (sub / "f2.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")   # depth 0
    (a_dir / ".gitignore").write_text("f1.log\n", encoding="utf-8")     # depth 1, only f1
    (sub / ".gitignore").write_text("!f2.log\n", encoding="utf-8")      # conflict on f2
    _, out, _ = run_main([str(tmp_path)])
    # a/f1.log does not intersect {f2.log} -> must NOT be selected despite greater depth
    assert "contradicts .gitignore:L1" in out


# -- Audit Report Format -------------------------------------------------------

def test_block_header_uses_forward_slash_separator(tmp_path):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / ".gitignore").write_text("*.nomatches_xyz\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "=== pkg/.gitignore ===" in out


def test_shadowed_entry_format(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "shadowed: 1" in out
    # Prompt template shows no leading indentation on entry lines
    assert "L1: *.log -> covered by .gitignore:L1" in out


def test_dead_entry_format(tmp_path):
    (tmp_path / ".gitignore").write_text("*.nomatches_xyz\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "dead: 1" in out
    # Prompt template shows no leading indentation on entry lines
    assert "L1: *.nomatches_xyz" in out


def test_report_uses_raw_not_body(tmp_path):
    (tmp_path / ".gitignore").write_text("*.nomatches   \n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "*.nomatches   " in out


def test_conflict_entry_format(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("!*.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "conflict: 1" in out
    # Prompt template shows no leading indentation on entry lines
    assert "L1: !*.log -> contradicts .gitignore:L1" in out


def test_shadowed_entry_shows_raw_not_body(tmp_path):
    # Req 44: shadowed entry must print <raw>, not <body>.
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log   \n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "*.log   " in out


def test_conflict_entry_shows_raw_not_body(tmp_path):
    # Req 46: conflict entry must print <raw>, not <body>.
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("!*.log   \n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "!*.log   " in out


def test_block_section_order_shadowed_dead_conflict(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log\n*.nomatch\n!*.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    pos_shadowed = out.find("shadowed:")
    pos_dead = out.find("dead:")
    pos_conflict = out.find("conflict:")
    assert 0 <= pos_shadowed < pos_dead < pos_conflict


def test_entries_printed_ascending_line_order(tmp_path):
    (tmp_path / ".gitignore").write_text("*.dead1\n*.dead2\n*.dead3\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    p1 = out.find("L1:")
    p2 = out.find("L2:")
    p3 = out.find("L3:")
    assert p1 < p2 < p3


def test_zero_count_category_omitted(tmp_path):
    (tmp_path / ".gitignore").write_text("*.nomatches_xyz\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "dead:" in out
    assert "shadowed:" not in out
    assert "conflict:" not in out


def test_all_zero_block_omitted(tmp_path):
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    _, out, _ = run_main([str(tmp_path)])
    assert "=== .gitignore ===" not in out


def test_summary_line_always_printed(tmp_path):
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    _, out, _ = run_main([str(tmp_path)])
    assert "total: shadowed=0 dead=0 conflict=0" in out


def test_summary_line_nonzero_counts(tmp_path):
    (tmp_path / ".gitignore").write_text("*.nomatches_xyz\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "total: shadowed=0 dead=1 conflict=0" in out


def test_empty_discovery_exact_summary(tmp_path):
    _, out, _ = run_main([str(tmp_path)])
    assert out == "total: shadowed=0 dead=0 conflict=0\n"


def test_ancestor_reference_paths_use_forward_slash(tmp_path):
    sub = tmp_path / "pkg"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "\\" not in out


def test_summary_totals_aggregate_across_files(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (tmp_path / ".gitignore").write_text("*.dead_root\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.dead_sub\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert "total: shadowed=0 dead=2 conflict=0" in out


# -- Fix Mode ------------------------------------------------------------------

def test_fix_removes_shadowed_lines(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    gi = sub / ".gitignore"
    gi.write_text("*.log\n", encoding="utf-8")
    run_main([str(tmp_path), "--fix"])
    assert "*.log" not in gi.read_text(encoding="utf-8")


def test_fix_removes_dead_lines(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.nomatches_xyz\n*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    run_main([str(tmp_path), "--fix"])
    content = gi.read_text(encoding="utf-8")
    assert "*.nomatches_xyz" not in content
    assert "*.log" in content


def test_fix_retains_active_lines(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    run_main([str(tmp_path), "--fix"])
    assert "*.log" in gi.read_text(encoding="utf-8")


def test_fix_retains_conflict_lines(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    gi = sub / ".gitignore"
    gi.write_text("!*.log\n", encoding="utf-8")
    run_main([str(tmp_path), "--fix"])
    assert "!*.log" in gi.read_text(encoding="utf-8")


def test_fix_retains_comment_lines(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("# my comment\n*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    run_main([str(tmp_path), "--fix"])
    assert "# my comment" in gi.read_text(encoding="utf-8")


def test_fix_discards_blank_lines(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.log\n\n\n*.tmp\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    (tmp_path / "file.tmp").write_text("x")
    run_main([str(tmp_path), "--fix"])
    content = gi.read_text(encoding="utf-8")
    assert content == "*.log\n*.tmp\n"


def test_fix_sections_order_comments_nonneg_neg(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("!*.tmp\n# comment\n*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    (tmp_path / "file.tmp").write_text("x")
    run_main([str(tmp_path), "--fix"])
    content = gi.read_text(encoding="utf-8")
    pos_comment = content.find("# comment")
    pos_log = content.find("*.log")
    pos_tmp = content.find("!*.tmp")
    assert pos_comment < pos_log < pos_tmp


def test_fix_comment_relative_order_preserved(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("# first comment\n# second comment\n*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    run_main([str(tmp_path), "--fix"])
    content = gi.read_text(encoding="utf-8")
    assert content.index("# first comment") < content.index("# second comment")


def test_fix_nonnegated_sorted_ascending_lex(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.tmp\n*.log\n*.bak\n", encoding="utf-8")
    (tmp_path / "file.tmp").write_text("x")
    (tmp_path / "file.log").write_text("x")
    (tmp_path / "file.bak").write_text("x")
    run_main([str(tmp_path), "--fix"])
    content = gi.read_text(encoding="utf-8")
    lines = [l for l in content.splitlines() if l.startswith("*")]
    assert lines == sorted(lines)


def test_fix_negated_sorted_ascending_lex_of_body(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.tmp").write_text("x")
    (sub / "file.log").write_text("x")
    (sub / "file.bak").write_text("x")
    (tmp_path / ".gitignore").write_text("*.tmp\n*.log\n*.bak\n", encoding="utf-8")
    gi = sub / ".gitignore"
    gi.write_text("!*.tmp\n!*.log\n!*.bak\n", encoding="utf-8")
    run_main([str(tmp_path), "--fix"])
    content = gi.read_text(encoding="utf-8")
    lines = [l for l in content.splitlines() if l.startswith("!")]
    bodies = [l[1:] for l in lines]
    assert bodies == sorted(bodies)


def test_fix_single_blank_between_adjacent_nonempty_sections(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("!*.tmp\n# comment\n*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    (tmp_path / "file.tmp").write_text("x")
    run_main([str(tmp_path), "--fix"])
    content = gi.read_text(encoding="utf-8")
    assert content == "# comment\n\n*.log\n\n!*.tmp\n"


def test_fix_blank_between_nonempty_sections_skips_empty_middle(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    gi = sub / ".gitignore"
    gi.write_text("# kept comment\n!*.log\n", encoding="utf-8")
    run_main([str(tmp_path), "--fix"])
    content = gi.read_text(encoding="utf-8")
    assert content == "# kept comment\n\n!*.log\n"


def test_fix_no_blank_adjacent_to_empty_section(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("# comment\n*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    run_main([str(tmp_path), "--fix"])
    content = gi.read_text(encoding="utf-8")
    assert content == "# comment\n\n*.log\n"


def test_fix_trailing_newline_exactly_one(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    run_main([str(tmp_path), "--fix"])
    raw = gi.read_bytes()
    assert raw.endswith(b"\n")
    assert not raw.endswith(b"\n\n")


def test_fix_utf8_no_bom(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.log\n", encoding="utf-8")
    (tmp_path / "file.log").write_text("x")
    run_main([str(tmp_path), "--fix"])
    assert not gi.read_bytes().startswith(b"\xef\xbb\xbf")


def test_fix_all_sections_empty_writes_zero_bytes(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.nomatches_xyz\n", encoding="utf-8")
    run_main([str(tmp_path), "--fix"])
    assert gi.stat().st_size == 0


def test_fix_audit_printed_before_rewrites(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.nomatches_xyz\n", encoding="utf-8")
    code, out, _ = run_main([str(tmp_path), "--fix"])
    assert "dead:" in out
    assert "total:" in out
    assert gi.stat().st_size == 0


def test_no_fix_flag_does_not_modify_files(tmp_path):
    gi = tmp_path / ".gitignore"
    original = "*.nomatches_xyz\n"
    gi.write_text(original, encoding="utf-8")
    run_main([str(tmp_path)])          # audit only - no --fix
    assert gi.read_text(encoding="utf-8") == original


def test_fix_mode_empty_directory(tmp_path):
    code, out, err = run_main([str(tmp_path), "--fix"])
    assert code == 0
    assert out == "total: shadowed=0 dead=0 conflict=0\n"
    assert err == ""


def test_fix_mode_exit_code_reflects_audit_result(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.nomatches_xyz\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path), "--fix"])
    assert code == 1


# -- CLI & Interface -----------------------------------------------------------

def test_main_returns_int(tmp_path):
    code, _, _ = run_main([str(tmp_path)])
    assert isinstance(code, int)
    assert code == 0  # empty directory: zero issues -> spec requires exactly 0


def test_invokable_as_python_module(tmp_path):
    result = subprocess.run(
        [sys.executable, "-m", "gitignore_audit", str(tmp_path)],
        capture_output=True, text=True, cwd="/app"
    )
    assert result.returncode == 0
    assert result.stdout == "total: shadowed=0 dead=0 conflict=0\n"


def test_stdout_no_utf8_bom(tmp_path):
    result = subprocess.run(
        [sys.executable, "-m", "gitignore_audit", str(tmp_path)],
        capture_output=True, cwd="/app"
    )
    assert result.returncode == 0  # empty dir -> exit 0; fails if module is missing
    assert not result.stdout.startswith(b"\xef\xbb\xbf")


def test_stdout_utf8_encoding_non_ascii(tmp_path):
    # Req: audit report encoded as UTF-8 without BOM.
    (tmp_path / ".gitignore").write_bytes("*.nömatches\n".encode("utf-8"))
    result = subprocess.run(
        [sys.executable, "-m", "gitignore_audit", str(tmp_path)],
        capture_output=True, cwd="/app"
    )
    assert result.returncode == 1  # dead pattern -> issues found; fails if module missing
    decoded = result.stdout.decode("utf-8")
    assert "*.nömatches" in decoded  # non-ASCII content preserved correctly in output


def test_fix_mode_invokable_as_python_module(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_text("*.nomatches_xyz\n", encoding="utf-8")
    result = subprocess.run(
        [sys.executable, "-m", "gitignore_audit", str(tmp_path), "--fix"],
        capture_output=True, text=True, cwd="/app"
    )
    assert result.returncode == 1          # dead pattern -> audit found issues
    assert gi.stat().st_size == 0          # dead pattern removed by fix


def test_utf8_with_non_ascii_content(tmp_path):
    gi = tmp_path / ".gitignore"
    gi.write_bytes("# café\n*.log\n".encode("utf-8"))
    (tmp_path / "file.log").write_text("x")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_pattern_scope_limited_to_subtree(tmp_path):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "file.log").write_text("x")
    (tmp_path / "file.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (pkg / ".gitignore").write_text("*.log\n", encoding="utf-8")
    code, out, _ = run_main([str(tmp_path)])
    assert "shadowed:" in out


def test_active_when_some_matches_outside_excluded(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "file.log").write_text("x")
    (sub / "other.log").write_text("x")
    (tmp_path / ".gitignore").write_text("sub/file.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("*.log\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_backslash_escapes_glob_metachar(tmp_path):
    # Rule 10: a backslash escapes the next character, disabling its glob-special meaning.
    (tmp_path / "literalX.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("literal\\*.txt\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 1  # \* is literal; no file with a literal '*' in its name → dead


def test_body_strips_trailing_whitespace_with_internal_escaped_space(tmp_path):
    (tmp_path / "foo bar").write_text("x")
    (tmp_path / ".gitignore").write_text("foo\\ bar   \n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0


def test_shadowed_entries_printed_ascending_line_order(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "a.log").write_text("x")
    (sub / "b.log").write_text("x")
    (tmp_path / ".gitignore").write_text("*.log\n", encoding="utf-8")
    (sub / ".gitignore").write_text("a.log\nb.log\n", encoding="utf-8")
    _, out, _ = run_main([str(tmp_path)])
    assert out.index("L1: a.log") < out.index("L2: b.log")


def test_character_class_range(tmp_path):
    (tmp_path / "file_c.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("file_[b-d].txt\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 0  # 'c' is within range [b-d]


def test_backslash_escapes_question_mark(tmp_path):
    # Rule 10: a backslash escapes the next character.
    (tmp_path / "fileX.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("file\\?.txt\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 1  # \? is literal; "fileX.txt" does not match → dead


def test_backslash_escapes_bracket(tmp_path):
    # Rule 10: a backslash escapes the next character.
    (tmp_path / "filea.txt").write_text("x")
    (tmp_path / ".gitignore").write_text("file\\[a].txt\n", encoding="utf-8")
    code, _, _ = run_main([str(tmp_path)])
    assert code == 1  # \[ is literal; "filea.txt" does not match → dead