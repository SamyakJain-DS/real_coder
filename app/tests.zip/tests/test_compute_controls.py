import pytest

from nacha import parse_file, serialize_file, compute_controls
from nacha.model import NachaFile

from tests.helpers import (
    build_file_text,
    simple_credit_entry,
    simple_debit_entry,
    make_iat_addenda,
    entry_hash_for,
)


# ---------------------------------------------------------------------------
# Return shape and input immutability
# ---------------------------------------------------------------------------


def test_compute_controls_does_not_mutate_input_serialization():
    # Start from a file with deliberately wrong batch/file controls.
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry(amount=100)]}],
        file_control_overrides={"total_credit": 999999},
    )
    parsed = parse_file(text)
    before = serialize_file(parsed)
    compute_controls(parsed)
    after = serialize_file(parsed)
    assert before == after  # input unchanged


# ---------------------------------------------------------------------------
# Per-batch control recomputation
# ---------------------------------------------------------------------------

def test_compute_controls_recomputes_batch_entry_addenda_count():
    text = build_file_text([
        {"sec_code": "CTX",
         "entries": [{**simple_credit_entry(),
                      "addenda": [("05", "A"), ("05", "B"), ("05", "C")]}]},
    ])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    # 1 entry + 3 addenda = 4
    assert fixed.batches[0].batch_control.entry_addenda_count == 4


def test_compute_controls_recomputes_batch_entry_hash():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [
             simple_credit_entry(rdfi_routing="07100000"),
             simple_credit_entry(rdfi_routing="07200001"),
             simple_credit_entry(rdfi_routing="07300002"),
         ]},
    ])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    expected = entry_hash_for(["07100000", "07200001", "07300002"])
    actual = int(fixed.batches[0].batch_control.entry_hash)
    assert actual == expected


def test_compute_controls_recomputes_batch_total_debit_only_for_debit_codes():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [
             {**simple_debit_entry(), "transaction_code": "27", "amount": 1000},
             {**simple_debit_entry(), "transaction_code": "28", "amount": 2000},
             {**simple_debit_entry(), "transaction_code": "37", "amount": 3000},
             {**simple_debit_entry(), "transaction_code": "38", "amount": 4000},
             {**simple_credit_entry(), "transaction_code": "22", "amount": 5000},
         ]},
    ])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed.batches[0].batch_control.total_debit == 1000 + 2000 + 3000 + 4000


def test_compute_controls_recomputes_batch_total_credit_only_for_credit_codes():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [
             {**simple_credit_entry(), "transaction_code": "22", "amount": 1000},
             {**simple_credit_entry(), "transaction_code": "23", "amount": 2000},
             {**simple_credit_entry(), "transaction_code": "32", "amount": 3000},
             {**simple_credit_entry(), "transaction_code": "33", "amount": 4000},
             {**simple_debit_entry(), "transaction_code": "27", "amount": 5000},
         ]},
    ])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed.batches[0].batch_control.total_credit == 1000 + 2000 + 3000 + 4000


# ---------------------------------------------------------------------------
# Per-file control recomputation
# ---------------------------------------------------------------------------

def test_compute_controls_recomputes_file_batch_count():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
        {"sec_code": "CCD", "entries": [simple_credit_entry()]},
        {"sec_code": "WEB", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed.file_control.batch_count == 3


def test_compute_controls_recomputes_file_entry_addenda_count():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [
             {**simple_credit_entry(),
              "addenda_indicator": "1", "addenda": [("05", "R")]},
             simple_credit_entry(),
         ]},
        {"sec_code": "CTX",
         "entries": [
             {**simple_credit_entry(),
              "addenda": [("05", "A"), ("05", "B")]},
         ]},
    ])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    # Batch 1: 2 entries + 1 addenda = 3
    # Batch 2: 1 entry + 2 addenda = 3
    assert fixed.file_control.entry_addenda_count == 6


def test_compute_controls_recomputes_file_entry_hash():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [simple_credit_entry(rdfi_routing="07100000")]},
        {"sec_code": "CCD",
         "entries": [simple_credit_entry(rdfi_routing="07200001")]},
    ])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    expected = entry_hash_for(["07100000", "07200001"])
    assert int(fixed.file_control.entry_hash) == expected


def test_compute_controls_recomputes_file_total_debit_and_credit():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [
             {**simple_debit_entry(), "transaction_code": "27", "amount": 1500},
             {**simple_credit_entry(), "transaction_code": "22", "amount": 2500},
         ]},
        {"sec_code": "CCD",
         "entries": [
             {**simple_debit_entry(), "transaction_code": "37", "amount": 1000},
             {**simple_credit_entry(), "transaction_code": "32", "amount": 4000},
         ]},
    ])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed.file_control.total_debit == 1500 + 1000
    assert fixed.file_control.total_credit == 2500 + 4000


def test_compute_controls_recomputes_block_count():
    # 1 (file header) + 1 (batch header) + 1 (entry) + 1 (batch control) +
    # 1 (file control) = 5 records; padding fills to 10 = 1 block.
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ], pad_to_block=True)
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed.file_control.block_count == 1


def test_compute_controls_block_count_with_two_blocks():
    # 1 header + 1 batch header + 11 entries + 1 batch ctrl + 1 file ctrl = 15
    # → padding fills to 20 → 2 blocks.
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [simple_credit_entry() for _ in range(11)]},
    ], pad_to_block=True)
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed.file_control.block_count == 2


# ---------------------------------------------------------------------------
# Preservation of non-control fields
# ---------------------------------------------------------------------------

def test_compute_controls_preserves_file_header_verbatim():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [simple_credit_entry()]}],
        file_control_overrides={"total_credit": 12345},  # wrong on purpose
    )
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    # Same record_type_code and same priority/destination/origin etc.
    assert fixed.file_header.priority_code == parsed.file_header.priority_code
    assert fixed.file_header.immediate_destination == parsed.file_header.immediate_destination
    assert fixed.file_header.immediate_origin == parsed.file_header.immediate_origin
    assert fixed.file_header.immediate_destination_name == parsed.file_header.immediate_destination_name
    assert fixed.file_header.immediate_origin_name == parsed.file_header.immediate_origin_name


def test_compute_controls_preserves_block_padding_and_line_terminator():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ], pad_to_block=True, line_terminator="\r\n")
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed.block_padding == parsed.block_padding
    assert fixed.line_terminator == parsed.line_terminator


def test_compute_controls_then_serialize_only_changes_control_fields():
    # Build a file with deliberately wrong batch & file controls. After
    # compute_controls + serialize, the output must be identical to a
    # freshly built file with correct controls - i.e. all surrounding
    # padding, filler, casing, and field text outside the control slots
    # is preserved.
    good_text = build_file_text([
        {"sec_code": "PPD",
         "entries": [simple_credit_entry(amount=100),
                     simple_credit_entry(amount=200)]},
    ], pad_to_block=True)
    bad_text = build_file_text(
        [{"sec_code": "PPD",
          "entries": [simple_credit_entry(amount=100),
                      simple_credit_entry(amount=200)]}],
        pad_to_block=True,
        file_control_overrides={
            "entry_addenda_count": 99,
            "total_credit": 1,
            "total_debit": 1,
        },
    )
    assert bad_text != good_text
    parsed = parse_file(bad_text)
    fixed = compute_controls(parsed)
    out = serialize_file(fixed)
    assert out == good_text


# ---------------------------------------------------------------------------
# D7-3 / D8-9: compute_controls returns a NEW NachaFile instance
# ---------------------------------------------------------------------------

def test_compute_controls_returns_new_nacha_file_instance():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed is not parsed


def test_compute_controls_input_control_fields_unchanged_after_call():
    # Build a file with deliberately wrong file-control values so that
    # compute_controls has real corrections to make on the returned object.
    # The input's fields must survive the call unchanged.
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry(amount=100)]}],
        file_control_overrides={"total_credit": 999999, "batch_count": 99},
    )
    parsed = parse_file(text)
    original_batch_hash = parsed.batches[0].batch_control.entry_hash
    original_file_credit = parsed.file_control.total_credit
    original_file_batch_count = parsed.file_control.batch_count
    compute_controls(parsed)
    assert parsed.batches[0].batch_control.entry_hash == original_batch_hash
    assert parsed.file_control.total_credit == original_file_credit
    assert parsed.file_control.batch_count == original_file_batch_count


# ---------------------------------------------------------------------------
# D7-2: Entry hash truncates to the rightmost 10 digits (modulo 10^10)
# ---------------------------------------------------------------------------

def test_compute_controls_entry_hash_truncates_to_rightmost_10_digits():
    # 101 entries with RDFI routing "99999999":
    #   sum = 101 * 99999999 = 10,099,999,899  (exceeds 10^10)
    #   rightmost 10 digits = 10,099,999,899 % 10^10 = 99,999,899
    # Force the batch_control hash to 0 so compute_controls must recompute it.
    n = 101
    rdfi = "99999999"
    entries = [simple_credit_entry(rdfi_routing=rdfi) for _ in range(n)]
    text = build_file_text([{
        "sec_code": "PPD",
        "entries": entries,
        "control_overrides": {"entry_hash": 0},  # force wrong batch hash
    }])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    expected = (n * int(rdfi)) % (10 ** 10)
    assert int(fixed.batches[0].batch_control.entry_hash) == expected
    assert int(fixed.file_control.entry_hash) == expected
    assert len(fixed.batches[0].batch_control.entry_hash) == 10
    assert len(fixed.file_control.entry_hash) == 10


# ---------------------------------------------------------------------------
# D8-1: compute_controls preserves named non-control BatchControl slots
# ---------------------------------------------------------------------------

def test_compute_controls_preserves_batch_control_non_control_slots_verbatim():
    # Build with non-default values for the slots the prompt enumerates:
    # record_type_code, service_class_code, company_identification,
    # message_authentication_code, reserved, originating_dfi_identification,
    # batch_number.
    text = build_file_text([{
        "sec_code": "PPD",
        "entries": [simple_credit_entry()],
        "service_class_code": "220",
        "company_identification": "9876543210",
        "originating_dfi": "09900000",
        "control_overrides": {
            "message_authentication_code": "M" * 19,
            "reserved": "R" * 6,
        },
    }])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    bc_in = parsed.batches[0].batch_control
    bc_out = fixed.batches[0].batch_control
    assert bc_out.record_type_code == bc_in.record_type_code
    assert bc_out.service_class_code == bc_in.service_class_code
    assert bc_out.company_identification == bc_in.company_identification
    assert bc_out.message_authentication_code == bc_in.message_authentication_code
    assert bc_out.reserved == bc_in.reserved
    assert bc_out.originating_dfi_identification == bc_in.originating_dfi_identification
    assert bc_out.batch_number == bc_in.batch_number


# ---------------------------------------------------------------------------
# D8-2: compute_controls preserves FileControl.record_type_code and .reserved
# ---------------------------------------------------------------------------

def test_compute_controls_preserves_file_control_reserved_verbatim():
    # Build with a distinctive non-space reserved field; compute_controls
    # must copy it verbatim onto the returned file control.
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry()]}],
        file_control_overrides={"reserved": "X" * 39},
    )
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed.file_control.reserved == parsed.file_control.reserved
    assert fixed.file_control.record_type_code == parsed.file_control.record_type_code


# ---------------------------------------------------------------------------
# D8-3: compute_controls copies batch_header verbatim
# ---------------------------------------------------------------------------

def test_compute_controls_preserves_batch_header_verbatim():
    # Build with a non-default company_identification so the batch_header line
    # differs from the helper defaults; compute_controls must copy it unchanged.
    text = build_file_text([{
        "sec_code": "PPD",
        "entries": [simple_credit_entry()],
        "company_identification": "9876543210",
    }])
    parsed = parse_file(text)
    fixed = compute_controls(parsed)
    assert fixed.batches[0].batch_header.raw == parsed.batches[0].batch_header.raw
