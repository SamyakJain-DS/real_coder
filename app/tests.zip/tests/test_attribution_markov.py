import pandas as pd
import pytest


def _events(rows: list[dict[str, object]]) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    df["touchpoint_ts"] = pd.to_datetime(df["touchpoint_ts"], utc=True)
    df["touchpoint_index"] = df["touchpoint_index"].astype(int)
    df["converted"] = df["converted"].astype(int)
    return df


def _canon_credits(df: pd.DataFrame) -> pd.DataFrame:
    fixed = ["journey_id", "converted"]
    channel_cols = sorted([c for c in df.columns if c not in set(fixed)])
    return df.sort_values("journey_id").reset_index(drop=True).loc[:, fixed + channel_cols]


def test_markov_uses_train_events_only_for_global_channel_shares(import_or_fail):
    attr = import_or_fail("app.attribution")
    train_events = _events(
        [
            {
                "journey_id": "J_conv",
                "touchpoint_index": 0,
                "channel": "A",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J_null_b",
                "touchpoint_index": 0,
                "channel": "B",
                "touchpoint_ts": "2026-01-02T00:00:00Z",
                "converted": 0,
            },
            {
                "journey_id": "J_null_c",
                "touchpoint_index": 0,
                "channel": "C",
                "touchpoint_ts": "2026-01-03T00:00:00Z",
                "converted": 0,
            },
        ]
    )
    all_events = pd.concat(
        [
            train_events,
            _events(
                [
                    {
                        "journey_id": "J_mixed",
                        "touchpoint_index": 0,
                        "channel": "A",
                        "touchpoint_ts": "2026-01-04T00:00:00Z",
                        "converted": 1,
                    },
                    {
                        "journey_id": "J_mixed",
                        "touchpoint_index": 1,
                        "channel": "D",
                        "touchpoint_ts": "2026-01-04T01:00:00Z",
                        "converted": 1,
                    },
                ]
            ),
        ],
        ignore_index=True,
    )
    credits = attr.compute_journey_channel_credits(all_events, model="markov", train_events=train_events)
    row = credits.set_index("journey_id").loc["J_mixed"]
    assert row["A"] == pytest.approx(1.0)
    assert row["D"] == pytest.approx(0.0)


def test_markov_falls_back_to_uniform_when_journey_has_no_supported_channels(import_or_fail):
    attr = import_or_fail("app.attribution")
    train_events = _events(
        [
            {
                "journey_id": "J_conv",
                "touchpoint_index": 0,
                "channel": "A",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J_null_b",
                "touchpoint_index": 0,
                "channel": "B",
                "touchpoint_ts": "2026-01-02T00:00:00Z",
                "converted": 0,
            },
            {
                "journey_id": "J_null_c",
                "touchpoint_index": 0,
                "channel": "C",
                "touchpoint_ts": "2026-01-03T00:00:00Z",
                "converted": 0,
            },
        ]
    )
    all_events = pd.concat(
        [
            train_events,
            _events(
                [
                    {
                        "journey_id": "J_bc",
                        "touchpoint_index": 0,
                        "channel": "B",
                        "touchpoint_ts": "2026-01-04T00:00:00Z",
                        "converted": 0,
                    },
                    {
                        "journey_id": "J_bc",
                        "touchpoint_index": 1,
                        "channel": "C",
                        "touchpoint_ts": "2026-01-04T01:00:00Z",
                        "converted": 0,
                    },
                ]
            ),
        ],
        ignore_index=True,
    )
    credits = attr.compute_journey_channel_credits(all_events, model="markov", train_events=train_events)
    row = credits.set_index("journey_id").loc["J_bc"]
    assert row["B"] == pytest.approx(0.5)
    assert row["C"] == pytest.approx(0.5)


def test_markov_assigns_zero_credit_to_channels_not_in_journey(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "A",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J2",
                "touchpoint_index": 0,
                "channel": "B",
                "touchpoint_ts": "2026-01-02T00:00:00Z",
                "converted": 0,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="markov")
    row = credits.set_index("journey_id").loc["J1"]
    assert row["B"] == pytest.approx(0.0)


def test_markov_uses_events_as_global_share_source_when_train_events_is_none(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J_conv",
                "touchpoint_index": 0,
                "channel": "A",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J_null",
                "touchpoint_index": 0,
                "channel": "B",
                "touchpoint_ts": "2026-01-02T00:00:00Z",
                "converted": 0,
            },
        ]
    )
    c1 = attr.compute_journey_channel_credits(events, model="markov", train_events=None)
    c2 = attr.compute_journey_channel_credits(events, model="markov", train_events=events)
    assert _canon_credits(c1).to_dict(orient="list") == _canon_credits(c2).to_dict(orient="list")


def test_markov_uses_uniform_global_shares_when_all_removal_effects_are_zero(import_or_fail):
    attr = import_or_fail("app.attribution")
    # All journeys are null: p_base = 0, so all removal_effect = 0.0 -> uniform global shares
    events = pd.DataFrame(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "A",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 0,
            },
            {
                "journey_id": "J2",
                "touchpoint_index": 0,
                "channel": "B",
                "touchpoint_ts": "2026-01-02T00:00:00Z",
                "converted": 0,
            },
        ]
    )
    events["touchpoint_ts"] = pd.to_datetime(events["touchpoint_ts"], utc=True)
    credits = attr.compute_journey_channel_credits(events, model="markov")
    # J1 has only channel A; uniform global shares -> restricted to {A} -> A gets 1.0
    row_j1 = credits.set_index("journey_id").loc["J1"]
    assert row_j1["A"] == pytest.approx(1.0)
    assert row_j1["B"] == pytest.approx(0.0)


def test_markov_zero_outgoing_mass_assigned_to_null_and_removal_effect_clipped(import_or_fail):
    attr = import_or_fail("app.attribution")
    # Chain: J1 is START->A->B->CONVERSION; J2 is START->C->NULL
    # Removing B: A's only outgoing edge (A->B) is gone -> A gets assigned ->NULL (prob 1.0)
    #   -> p_removed(B) = 0 -> removal_effect(B) = max(0, (0.5-0)/0.5) = 1.0  [covers #44]
    # Removing C: START->A->B->CONVERSION entirely -> p_removed(C) = 1.0 > p_base = 0.5
    #   -> removal_effect(C) = max(0, (0.5-1.0)/0.5) = max(0, -1.0) = 0.0  [covers #46]
    # Global shares: re(A)=1.0, re(B)=1.0, re(C)=0.0 -> normalized: A=0.5, B=0.5, C=0.0
    # J1 credits (channels A,B): restricted to {A,B}, renormalized -> A=0.5, B=0.5
    # J2 credits (channel C): {C} ∩ support {A,B} = ∅ -> uniform fallback -> C=1.0
    events = pd.DataFrame([
        {
            "journey_id": "J1", "touchpoint_index": 0, "channel": "A",
            "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1,
        },
        {
            "journey_id": "J1", "touchpoint_index": 1, "channel": "B",
            "touchpoint_ts": "2026-01-01T01:00:00Z", "converted": 1,
        },
        {
            "journey_id": "J2", "touchpoint_index": 0, "channel": "C",
            "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 0,
        },
    ])
    events["touchpoint_ts"] = pd.to_datetime(events["touchpoint_ts"], utc=True)
    credits = attr.compute_journey_channel_credits(events, model="markov")

    row_j1 = credits.set_index("journey_id").loc["J1"]
    assert row_j1["A"] == pytest.approx(0.5)
    assert row_j1["B"] == pytest.approx(0.5)
    assert row_j1["C"] == pytest.approx(0.0)

    row_j2 = credits.set_index("journey_id").loc["J2"]
    assert row_j2["C"] == pytest.approx(1.0)
    assert row_j2["A"] == pytest.approx(0.0)
    assert row_j2["B"] == pytest.approx(0.0)

def test_markov_applies_proportional_distribution_to_null_journeys_with_nonuniform_global_shares(import_or_fail):
    attr = import_or_fail("app.attribution")
    # Two A-converted journeys, one B-converted, one C-null →
    # global shares: A=0.75, B=0.25, C=0.0
    # A null eval journey with channels A and B must receive A=0.75, B=0.25 (not uniform)
    train_events = _events([
        {"journey_id": "J1a", "touchpoint_index": 0, "channel": "A",
         "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
        {"journey_id": "J1b", "touchpoint_index": 0, "channel": "A",
         "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 1},
        {"journey_id": "J2",  "touchpoint_index": 0, "channel": "B",
         "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 1},
        {"journey_id": "J3",  "touchpoint_index": 0, "channel": "C",
         "touchpoint_ts": "2026-01-04T00:00:00Z", "converted": 0},
    ])
    null_journey = _events([
        {"journey_id": "J_null", "touchpoint_index": 0, "channel": "A",
         "touchpoint_ts": "2026-01-05T00:00:00Z", "converted": 0},
        {"journey_id": "J_null", "touchpoint_index": 1, "channel": "B",
         "touchpoint_ts": "2026-01-05T01:00:00Z", "converted": 0},
    ])
    all_events = pd.concat([train_events, null_journey], ignore_index=True)
    credits = attr.compute_journey_channel_credits(
        all_events, model="markov", train_events=train_events
    )
    row = credits.set_index("journey_id").loc["J_null"]
    assert row["A"] == pytest.approx(0.75)
    assert row["B"] == pytest.approx(0.25)