import dataclasses
import xml.etree.ElementTree as ET
 
import pytest
 
# ---------------------------------------------------------------------------
# Graceful imports - all tests FAIL (not ERROR/SKIP) on an empty repository.
# Wrapping each import in try/except ensures pytest can always collect the
# test file and report individual FAILED lines even when the package is absent.
# ---------------------------------------------------------------------------
try:
    from archival_system.accession import Accession, AccessionRegistry
except (ImportError, ModuleNotFoundError):
    Accession = None          # type: ignore[assignment,misc]
    AccessionRegistry = None  # type: ignore[assignment,misc]
 
try:
    from archival_system.collection import Collection, CollectionProcessor
except (ImportError, ModuleNotFoundError):
    Collection = None         # type: ignore[assignment,misc]
    CollectionProcessor = None  # type: ignore[assignment,misc]
 
try:
    from archival_system.digitization import DigitizationJob, DigitizationWorkflow
except (ImportError, ModuleNotFoundError):
    DigitizationJob = None       # type: ignore[assignment,misc]
    DigitizationWorkflow = None  # type: ignore[assignment,misc]
 
try:
    from archival_system.finding_aid import generate_ead
except (ImportError, ModuleNotFoundError):
    generate_ead = None  # type: ignore[assignment,misc]
 
try:
    from archival_system.reporting import generate_legislative_report, generate_transfer_schedule
except (ImportError, ModuleNotFoundError):
    generate_legislative_report = None   # type: ignore[assignment,misc]
    generate_transfer_schedule = None    # type: ignore[assignment,misc]
 
try:
    from archival_system.researcher import ReadingRoomCirculation, Researcher, Visit
except (ImportError, ModuleNotFoundError):
    ReadingRoomCirculation = None  # type: ignore[assignment,misc]
    Researcher = None              # type: ignore[assignment,misc]
    Visit = None                   # type: ignore[assignment,misc]
 
 
# -- XML helper ----------------------------------------

def _find_by_local_tag(root: ET.Element, tag: str) -> ET.Element | None:
    """Return first element whose local tag name matches, ignoring any XML namespace prefix."""
    for elem in root.iter():
        local = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
        if local == tag:
            return elem
    return None


# -- Fixtures ------------------------------------------

@pytest.fixture
def registry():
    return AccessionRegistry()


@pytest.fixture
def processor():
    return CollectionProcessor()


@pytest.fixture
def workflow(processor):
    return DigitizationWorkflow(processor)


@pytest.fixture
def sample_dacs_fields():
    return {
        "title": "Sample Collection Title",
        "date_range": "1920-1980",
        "extent_linear_feet": 4.5,
        "abstract": "A brief descriptive abstract.",
        "scope_and_content": "Documents relating to operational history.",
    }


@pytest.fixture
def sample_collection(processor, sample_dacs_fields):
    return processor.process_collection(
        accession_id="acc-fixture-001",
        arrangement_scheme="Alphabetical by series",
        dacs_fields=sample_dacs_fields,
    )


@pytest.fixture
def restricted_collection(processor):
    dacs = {
        "title": "Restricted Materials",
        "date_range": "1945-1975",
        "extent_linear_feet": 2.0,
        "abstract": "Restricted abstract.",
        "scope_and_content": "Scope for restricted collection.",
        "access_restriction": "Restricted pending deed review",
    }
    return processor.process_collection(
        accession_id="acc-fixture-002",
        arrangement_scheme="Chronological",
        dacs_fields=dacs,
    )


@pytest.fixture
def circulation(processor):
    return ReadingRoomCirculation(processor)


@pytest.fixture
def registered_researcher(circulation):
    return circulation.register_researcher(
        name="Jane Researcher",
        contact_info="jane@example.com",
        affiliation="State University",
    )


# ======================================================
# ACCESSION MANAGEMENT
# ======================================================

class TestAccessionDataclass:

    def test_accession_dataclass_fields(self):
        """Verifies Accession is a dataclass with required typed fields (Req-1, Req-2)."""
        acc = Accession(
            id="test-id-001",
            accession_type="purchase",
            title="A Test Collection",
            linear_feet=3.5,
            year=2019,
        )
        assert dataclasses.is_dataclass(acc)
        assert isinstance(acc.id, str)
        assert isinstance(acc.accession_type, str)
        assert isinstance(acc.title, str)
        assert isinstance(acc.linear_feet, float)
        assert isinstance(acc.year, int)

    def test_accession_donation_type_fields(self):
        """Verifies Accession stores donor_id and deed_of_gift_ref for donation type (Req-3)."""
        acc = Accession(
            id="test-id-002",
            accession_type="donation",
            title="Donor Gift Collection",
            linear_feet=1.0,
            year=2021,
            donor_id="DONOR-42",
            deed_of_gift_ref="DOG-2021-001",
        )
        assert isinstance(acc.donor_id, str)
        assert acc.donor_id == "DONOR-42"
        assert isinstance(acc.deed_of_gift_ref, str)
        assert acc.deed_of_gift_ref == "DOG-2021-001"

    def test_accession_transfer_type_fields(self):
        """Verifies Accession stores all four agency-transfer fields as strings (Req-4)."""
        acc = Accession(
            id="test-id-003",
            accession_type="transfer",
            title="Agency Transfer Collection",
            linear_feet=2.0,
            year=2022,
            agency_id="AG-001",
            public_records_authority="State Code § 44",
            scheduled_transfer_date="2022-03-01",
            actual_transfer_date="2022-03-05",
        )
        assert isinstance(acc.agency_id, str)
        assert acc.agency_id == "AG-001"
        assert isinstance(acc.public_records_authority, str)
        assert acc.public_records_authority == "State Code § 44"
        assert isinstance(acc.scheduled_transfer_date, str)
        assert acc.scheduled_transfer_date == "2022-03-01"
        assert isinstance(acc.actual_transfer_date, str)
        assert acc.actual_transfer_date == "2022-03-05"


class TestAccessionRegistryIdentifiers:

    def test_register_accession_assigns_unique_string_ids(self, registry):
        """Verifies register_accession assigns unique string id to each accession (Req-5)."""
        a1 = registry.register_accession("purchase", "Collection Alpha", 1.0, 2020)
        a2 = registry.register_accession("purchase", "Collection Beta", 2.0, 2020)
        a3 = registry.register_accession("purchase", "Collection Gamma", 3.0, 2020)
        ids = [a1.id, a2.id, a3.id]
        assert all(isinstance(i, str) for i in ids)
        assert len(set(ids)) == 3

    def test_register_accession_returns_accession_instance(self, registry):
        """Verifies register_accession returns an Accession instance (Req-6)."""
        result = registry.register_accession("purchase", "Test Title", 1.5, 2021)
        assert isinstance(result, Accession)

    def test_get_accession_returns_correct_instance(self, registry):
        """Verifies get_accession retrieves the registered accession by its id (Req-7)."""
        registered = registry.register_accession("purchase", "Retrievable Title", 2.0, 2022)
        retrieved = registry.get_accession(registered.id)
        assert retrieved.id == registered.id

    def test_get_accession_raises_keyerror_for_unknown_id(self, registry):
        """Verifies get_accession raises KeyError when identifier does not exist (Req-8)."""
        with pytest.raises(KeyError):
            registry.get_accession("definitely-not-registered-id-99999")

    def test_list_accessions_by_year_returns_matching(self, registry):
        """Verifies list_accessions_by_year returns all accessions for the given year (Req-9)."""
        target_year = 2023
        a1 = registry.register_accession("purchase", "Title 2023 A", 1.0, target_year)
        a2 = registry.register_accession("purchase", "Title 2023 B", 2.0, target_year)
        registry.register_accession("purchase", "Title 2024", 1.5, 2024)
        result = registry.list_accessions_by_year(target_year)
        assert isinstance(result, list)
        result_ids = {a.id for a in result}
        assert a1.id in result_ids
        assert a2.id in result_ids
        assert all(a.year == target_year for a in result)

    def test_list_accessions_by_year_returns_empty_when_none_match(self, registry):
        """Verifies list_accessions_by_year returns empty list when no accessions match (Req-10)."""
        registry.register_accession("purchase", "Some Title", 1.0, 2020)
        result = registry.list_accessions_by_year(1900)
        assert isinstance(result, list)
        assert len(result) == 0

    def test_list_all_accessions_returns_all_registered(self, registry):
        """Verifies list_all_accessions returns every registered accession regardless of year (Req-11)."""
        a1 = registry.register_accession("purchase", "Title Year A", 1.0, 2019)
        a2 = registry.register_accession("purchase", "Title Year B", 2.0, 2021)
        a3 = registry.register_accession("purchase", "Title Year C", 3.0, 2023)
        result = registry.list_all_accessions()
        assert isinstance(result, list)
        result_ids = {a.id for a in result}
        assert {a1.id, a2.id, a3.id}.issubset(result_ids)

    def test_list_all_accessions_returns_empty_before_any_registered(self):
        """Verifies list_all_accessions returns empty list when no accessions registered (Req-12)."""
        fresh_registry = AccessionRegistry()
        result = fresh_registry.list_all_accessions()
        assert isinstance(result, list)
        assert len(result) == 0



class TestAccessionRegistryValidation:

    def test_register_donation_missing_donor_id_raises_valueerror(self, registry):
        """Verifies ValueError when donation type is registered without donor_id (Req-13)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "donation", "Donor Title", 1.0, 2022,
                deed_of_gift_ref="DOG-001",
            )

    def test_register_donation_none_donor_id_raises_valueerror(self, registry):
        """Verifies ValueError when donation type has donor_id=None (Req-13)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "donation", "Donor Title", 1.0, 2022,
                donor_id=None,
                deed_of_gift_ref="DOG-001",
            )

    def test_register_donation_missing_deed_of_gift_ref_raises_valueerror(self, registry):
        """Verifies ValueError when donation type is registered without deed_of_gift_ref (Req-14)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "donation", "Donor Title", 1.0, 2022,
                donor_id="DONOR-001",
            )

    def test_register_donation_none_deed_of_gift_ref_raises_valueerror(self, registry):
        """Verifies ValueError when donation type has deed_of_gift_ref=None (Req-14)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "donation", "Donor Title", 1.0, 2022,
                donor_id="DONOR-001",
                deed_of_gift_ref=None,
            )

    def test_register_transfer_missing_agency_id_raises_valueerror(self, registry):
        """Verifies ValueError when transfer type is registered without agency_id (Req-15)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "transfer", "Transfer Title", 2.0, 2022,
                public_records_authority="§ 99",
                scheduled_transfer_date="2022-01-10",
                actual_transfer_date="2022-01-15",
            )

    def test_register_transfer_none_public_records_authority_raises_valueerror(self, registry):
        """Verifies ValueError when transfer type has public_records_authority=None (Req-16)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "transfer", "Transfer Title", 2.0, 2022,
                agency_id="AG-001",
                public_records_authority=None,
                scheduled_transfer_date="2022-01-10",
                actual_transfer_date="2022-01-15",
            )

    def test_register_transfer_missing_scheduled_transfer_date_raises_valueerror(self, registry):
        """Verifies ValueError when transfer type is registered without scheduled_transfer_date (Req-17)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "transfer", "Transfer Title", 2.0, 2022,
                agency_id="AG-001",
                public_records_authority="§ 99",
                actual_transfer_date="2022-01-15",
            )

    def test_register_transfer_none_actual_transfer_date_raises_valueerror(self, registry):
        """Verifies ValueError when transfer type has actual_transfer_date=None (Req-18)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "transfer", "Transfer Title", 2.0, 2022,
                agency_id="AG-001",
                public_records_authority="§ 99",
                scheduled_transfer_date="2022-01-10",
                actual_transfer_date=None,
            )

    def test_register_transfer_none_agency_id_raises_valueerror(self, registry):
        """Verifies ValueError when transfer type has agency_id=None (Req-15)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "transfer", "Transfer Title", 2.0, 2022,
                agency_id=None,
                public_records_authority="§ 99",
                scheduled_transfer_date="2022-01-10",
                actual_transfer_date="2022-01-15",
            )

    def test_register_transfer_missing_public_records_authority_raises_valueerror(self, registry):
        """Verifies ValueError when transfer type is registered without public_records_authority (Req-16)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "transfer", "Transfer Title", 2.0, 2022,
                agency_id="AG-001",
                scheduled_transfer_date="2022-01-10",
                actual_transfer_date="2022-01-15",
            )

    def test_register_transfer_none_scheduled_transfer_date_raises_valueerror(self, registry):
        """Verifies ValueError when transfer type has scheduled_transfer_date=None (Req-17)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "transfer", "Transfer Title", 2.0, 2022,
                agency_id="AG-001",
                public_records_authority="§ 99",
                scheduled_transfer_date=None,
                actual_transfer_date="2022-01-15",
            )

    def test_register_transfer_missing_actual_transfer_date_raises_valueerror(self, registry):
        """Verifies ValueError when transfer type is registered without actual_transfer_date (Req-18)."""
        with pytest.raises(ValueError):
            registry.register_accession(
                "transfer", "Transfer Title", 2.0, 2022,
                agency_id="AG-001",
                public_records_authority="§ 99",
                scheduled_transfer_date="2022-01-10",
            )

    def test_register_donation_with_all_required_fields_succeeds(self, registry):
        """Verifies register_accession returns an Accession when donation has both donor fields (Req-13, Req-14).

        Guards against an implementation that unconditionally raises ValueError for donation type.
        """
        acc = registry.register_accession(
            "donation", "Valid Donation Title", 1.5, 2021,
            donor_id="DONOR-VALID",
            deed_of_gift_ref="DOG-VALID-001",
        )
        assert isinstance(acc, Accession)
        assert acc.accession_type == "donation"
        assert isinstance(acc.id, str)

    def test_register_transfer_with_all_required_fields_succeeds(self, registry):
        """Verifies register_accession returns an Accession when transfer has all four agency fields (Req-15–18).

        Guards against an implementation that unconditionally raises ValueError for transfer type.
        """
        acc = registry.register_accession(
            "transfer", "Valid Transfer Title", 5.0, 2022,
            agency_id="AG-VALID",
            public_records_authority="State Code § 12",
            scheduled_transfer_date="2022-06-01",
            actual_transfer_date="2022-06-10",
        )
        assert isinstance(acc, Accession)
        assert acc.accession_type == "transfer"
        assert isinstance(acc.id, str)


# ======================================================
# COLLECTION PROCESSING
# ======================================================

class TestCollectionDataclass:

    def test_collection_dataclass_fields(self):
        """Verifies Collection is a dataclass with all required DACS fields (Req-19)."""
        col = Collection(
            id="col-001",
            accession_id="acc-001",
            title="Test Collection Title",
            date_range="1900-1950",
            extent_linear_feet=5.0,
            abstract="An abstract.",
            scope_and_content="Scope note.",
            arrangement_scheme="By series",
            processing_status="unprocessed",
            access_restriction=None,
        )
        assert dataclasses.is_dataclass(col)
        assert isinstance(col.id, str)
        assert isinstance(col.accession_id, str)
        assert isinstance(col.title, str)
        assert isinstance(col.date_range, str)
        assert isinstance(col.extent_linear_feet, float)
        assert isinstance(col.abstract, str)
        assert isinstance(col.scope_and_content, str)
        assert isinstance(col.arrangement_scheme, str)

    def test_collection_processing_status_stores_given_value(self):
        """Verifies Collection.processing_status stores valid status values (Req-20)."""
        for status in ("unprocessed", "in_progress", "processed"):
            col = Collection(
                id="col-s",
                accession_id="acc-s",
                title="T",
                date_range="2000-2010",
                extent_linear_feet=1.0,
                abstract="A",
                scope_and_content="S",
                arrangement_scheme="Sch",
                processing_status=status,
                access_restriction=None,
            )
            assert col.processing_status == status

    def test_collection_access_restriction_string(self):
        """Verifies Collection.access_restriction holds a restriction description string (Req-21)."""
        restriction = "Access restricted pending clearance"
        col = Collection(
            id="col-r",
            accession_id="acc-r",
            title="Restricted",
            date_range="1980-1990",
            extent_linear_feet=1.5,
            abstract="A",
            scope_and_content="S",
            arrangement_scheme="Sch",
            processing_status="unprocessed",
            access_restriction=restriction,
        )
        assert isinstance(col.access_restriction, str)
        assert col.access_restriction == restriction

    def test_collection_access_restriction_none(self):
        """Verifies Collection.access_restriction can hold None for unrestricted collections (Req-21)."""
        col = Collection(
            id="col-u",
            accession_id="acc-u",
            title="Unrestricted",
            date_range="1980-1990",
            extent_linear_feet=1.5,
            abstract="A",
            scope_and_content="S",
            arrangement_scheme="Sch",
            processing_status="unprocessed",
            access_restriction=None,
        )
        assert col.access_restriction is None


class TestCollectionProcessor:

    def test_process_collection_initial_status_is_unprocessed(self, processor, sample_dacs_fields):
        """Verifies process_collection sets initial processing_status to 'unprocessed' (Req-22)."""
        col = processor.process_collection(
            accession_id="acc-100",
            arrangement_scheme="Alphabetical",
            dacs_fields=sample_dacs_fields,
        )
        assert isinstance(col, Collection)
        assert col.processing_status == "unprocessed"

    def test_process_collection_assigns_unique_string_id(self, processor, sample_dacs_fields):
        """Verifies process_collection assigns a unique string identifier to each Collection (Req-23)."""
        col1 = processor.process_collection("acc-A", "Arrangement A", sample_dacs_fields)
        dacs2 = dict(sample_dacs_fields)
        dacs2["title"] = "Another Title"
        col2 = processor.process_collection("acc-B", "Arrangement B", dacs2)
        assert isinstance(col1.id, str)
        assert isinstance(col2.id, str)
        assert col1.id != col2.id

    def test_process_collection_access_restriction_defaults_to_none(self, processor):
        """Verifies access_restriction defaults to None when absent from dacs_fields (Req-24)."""
        dacs = {
            "title": "No Restriction Title",
            "date_range": "1910-1930",
            "extent_linear_feet": 3.0,
            "abstract": "Abstract text.",
            "scope_and_content": "Scope text.",
        }
        col = processor.process_collection("acc-200", "By type", dacs)
        assert col.access_restriction is None

    def test_process_collection_stores_accession_id_and_arrangement_scheme(
        self, processor, sample_dacs_fields
    ):
        """Verifies process_collection stores accession_id and arrangement_scheme on the Collection (Req-22).

        Guards against an implementation that ignores those arguments and stores empty strings.
        """
        acc_id = "acc-storage-check-777"
        scheme = "Arrangement by Record Group"
        col = processor.process_collection(acc_id, scheme, sample_dacs_fields)
        assert col.accession_id == acc_id
        assert col.arrangement_scheme == scheme

    def test_process_collection_stores_all_dacs_fields(self, processor):
        """Verifies process_collection correctly populates all DACS fields-including
        access_restriction when present-on the returned Collection from the dacs_fields dict (Req-22b)."""
        dacs = {
            "title": "Verified DACS Title",
            "date_range": "1905-1965",
            "extent_linear_feet": 6.75,
            "abstract": "Verified abstract text.",
            "scope_and_content": "Verified scope and content text.",
            "access_restriction": "Access requires written authorization",
        }
        col = processor.process_collection("acc-dacs-verify", "By subject", dacs)
        assert isinstance(col, Collection)
        assert col.title == dacs["title"]
        assert col.date_range == dacs["date_range"]
        assert isinstance(col.extent_linear_feet, float)
        assert col.extent_linear_feet == dacs["extent_linear_feet"]
        assert col.abstract == dacs["abstract"]
        assert col.scope_and_content == dacs["scope_and_content"]
        assert col.access_restriction == dacs["access_restriction"]

    def test_get_collection_returns_stored_instance(self, processor, sample_dacs_fields):
        """Verifies get_collection retrieves the stored Collection by identifier (Req-25)."""
        col = processor.process_collection("acc-300", "Series", sample_dacs_fields)
        retrieved = processor.get_collection(col.id)
        assert retrieved.id == col.id

    def test_get_collection_raises_keyerror_for_unknown_id(self, processor):
        """Verifies get_collection raises KeyError when identifier does not exist (Req-26)."""
        with pytest.raises(KeyError):
            processor.get_collection("no-such-collection-id-xyz")

    def test_update_processing_status_valid_value(self, processor, sample_dacs_fields):
        """Verifies update_processing_status updates status to a valid value and returns Collection (Req-27)."""
        col = processor.process_collection("acc-400", "Scheme", sample_dacs_fields)
        updated = processor.update_processing_status(col.id, "in_progress")
        assert isinstance(updated, Collection)
        assert updated.processing_status == "in_progress"
        updated2 = processor.update_processing_status(col.id, "processed")
        assert isinstance(updated2, Collection)
        assert updated2.processing_status == "processed"

    def test_update_processing_status_invalid_raises_valueerror(self, processor, sample_dacs_fields):
        """Verifies update_processing_status raises ValueError for an invalid status string (Req-28)."""
        col = processor.process_collection("acc-500", "Scheme", sample_dacs_fields)
        with pytest.raises(ValueError):
            processor.update_processing_status(col.id, "completed")

    def test_update_processing_status_missing_collection_raises_keyerror(self, processor):
        """Verifies update_processing_status raises KeyError when collection id does not exist (Req-29)."""
        with pytest.raises(KeyError):
            processor.update_processing_status("nonexistent-col-id", "processed")

    def test_update_processing_status_persists_to_storage(self, processor, sample_dacs_fields):
        """Verifies that after update_processing_status succeeds, a subsequent get_collection
        call returns the Collection with the updated processing_status value (persistence check)."""
        col = processor.process_collection("acc-persist-001", "Scheme", sample_dacs_fields)
        processor.update_processing_status(col.id, "in_progress")
        retrieved = processor.get_collection(col.id)
        assert retrieved.processing_status == "in_progress"

        processor.update_processing_status(col.id, "processed")
        retrieved2 = processor.get_collection(col.id)
        assert retrieved2.processing_status == "processed"

    def test_update_processing_status_to_unprocessed_is_valid(self, processor, sample_dacs_fields):
        """Verifies 'unprocessed' is accepted as a valid status by update_processing_status (Req-27).

        Guards against implementations that only accept the two non-initial statuses.
        """
        col = processor.process_collection("acc-unreset-001", "Scheme", sample_dacs_fields)
        processor.update_processing_status(col.id, "in_progress")
        updated = processor.update_processing_status(col.id, "unprocessed")
        assert isinstance(updated, Collection)
        assert updated.processing_status == "unprocessed"



# ======================================================
# FINDING AID GENERATION
# ======================================================

class TestGenerateEad:

    def test_generate_ead_returns_str(self, sample_collection):
        """Verifies generate_ead returns a str instance (Req-30)."""
        result = generate_ead(sample_collection)
        assert isinstance(result, str)

    def test_generate_ead_is_parseable_xml(self, sample_collection):
        """Verifies generate_ead returns a well-formed, parseable XML string (Req-31)."""
        result = generate_ead(sample_collection)
        root = ET.fromstring(result)
        assert root is not None

    def test_generate_ead_archdesc_did_elements(self, sample_collection):
        """Verifies EAD archdesc/did contains unittitle, unitdate, physdesc populated from
        collection's title, date_range, extent_linear_feet (Req-32)."""
        result = generate_ead(sample_collection)
        root = ET.fromstring(result)

        archdesc = _find_by_local_tag(root, "archdesc")
        assert archdesc is not None, "<archdesc> element not found"

        did = _find_by_local_tag(archdesc, "did")
        assert did is not None, "<did> element not found under <archdesc>"

        unittitle = _find_by_local_tag(did, "unittitle")
        assert unittitle is not None, "<unittitle> not found under <did>"
        assert sample_collection.title in "".join(unittitle.itertext())

        unitdate = _find_by_local_tag(did, "unitdate")
        assert unitdate is not None, "<unitdate> not found under <did>"
        assert sample_collection.date_range in "".join(unitdate.itertext())

        physdesc = _find_by_local_tag(did, "physdesc")
        assert physdesc is not None, "<physdesc> not found under <did>"
        assert str(sample_collection.extent_linear_feet) in "".join(physdesc.itertext())

    def test_generate_ead_scopecontent_element(self, sample_collection):
        """Verifies EAD scopecontent under archdesc is populated from scope_and_content (Req-33)."""
        result = generate_ead(sample_collection)
        root = ET.fromstring(result)

        archdesc = _find_by_local_tag(root, "archdesc")
        assert archdesc is not None

        scopecontent = _find_by_local_tag(archdesc, "scopecontent")
        assert scopecontent is not None, "<scopecontent> not found under <archdesc>"

        full_text = "".join(scopecontent.itertext())
        assert sample_collection.scope_and_content in full_text

    def test_generate_ead_accessrestrict_when_restricted(self, processor):
        """Verifies accessrestrict text equals access_restriction when it is not None (Req-34)."""
        restriction_text = "Restricted: requires written permission"
        dacs = {
            "title": "Restricted EAD Test",
            "date_range": "1960-1970",
            "extent_linear_feet": 1.0,
            "abstract": "Abstract.",
            "scope_and_content": "Scope.",
            "access_restriction": restriction_text,
        }
        col = processor.process_collection("acc-ead-r", "By date", dacs)
        result = generate_ead(col)
        root = ET.fromstring(result)

        archdesc = _find_by_local_tag(root, "archdesc")
        assert archdesc is not None

        accessrestrict = _find_by_local_tag(archdesc, "accessrestrict")
        assert accessrestrict is not None, "<accessrestrict> not found under <archdesc>"

        full_text = "".join(accessrestrict.itertext())
        assert full_text.strip() == restriction_text

    def test_generate_ead_accessrestrict_when_open(self, sample_collection):
        """Verifies accessrestrict text is 'Open for research' when access_restriction is None (Req-35)."""
        assert sample_collection.access_restriction is None
        result = generate_ead(sample_collection)
        root = ET.fromstring(result)

        archdesc = _find_by_local_tag(root, "archdesc")
        assert archdesc is not None

        accessrestrict = _find_by_local_tag(archdesc, "accessrestrict")
        assert accessrestrict is not None, "<accessrestrict> not found under <archdesc>"

        full_text = "".join(accessrestrict.itertext())
        assert full_text.strip() == "Open for research"

    def test_generate_ead_root_tag_is_ead(self, sample_collection):
        """Verifies the root element of the EAD document has the local tag name 'ead' (EAD 2002 structure)."""
        result = generate_ead(sample_collection)
        root = ET.fromstring(result)
        local_tag = root.tag.split("}")[-1] if "}" in root.tag else root.tag
        assert local_tag == "ead", f"Expected root tag 'ead', got '{local_tag}'"

    def test_generate_ead_archdesc_did_direct_child_nesting(self, sample_collection):
        """Verifies <did> is a direct child of <archdesc>, as explicitly stated in the
        prompt using the word 'child element'. The content and existence of the elements
        inside <did> is verified separately via _find_by_local_tag in
        test_generate_ead_archdesc_did_elements."""
        result = generate_ead(sample_collection)
        root = ET.fromstring(result)

        def _direct_child_local_tags(element):
            return {(c.tag.split("}")[-1] if "}" in c.tag else c.tag) for c in element}

        archdesc = _find_by_local_tag(root, "archdesc")
        assert archdesc is not None, "<archdesc> element not found"

        archdesc_child_tags = _direct_child_local_tags(archdesc)
        assert "did" in archdesc_child_tags, "<did> must be a direct child of <archdesc>"


# ======================================================
# RESEARCHER REGISTRATION AND READING ROOM CIRCULATION
# ======================================================

class TestResearcherDataclass:

    def test_researcher_dataclass_fields(self):
        """Verifies Researcher is a dataclass with id, name, contact_info, affiliation (Req-36)."""
        r = Researcher(
            id="res-001",
            name="Alice Scholar",
            contact_info="alice@example.edu",
            affiliation="Historical Society",
        )
        assert dataclasses.is_dataclass(r)
        assert isinstance(r.id, str)
        assert isinstance(r.name, str)
        assert isinstance(r.contact_info, str)
        assert isinstance(r.affiliation, str)


class TestVisitDataclass:

    def test_visit_dataclass_fields(self):
        """Verifies Visit is a dataclass with id, researcher_id, collection_id, visit_date,
        restriction_reason, and authorization_ref (defaults to None) fields (Req-37)."""
        v = Visit(
            id="visit-001",
            researcher_id="res-001",
            collection_id="col-001",
            visit_date="2023-05-15",
            restriction_reason=None,
        )
        assert dataclasses.is_dataclass(v)
        assert isinstance(v.id, str)
        assert isinstance(v.researcher_id, str)
        assert isinstance(v.collection_id, str)
        assert isinstance(v.visit_date, str)
        assert v.restriction_reason is None
        assert v.authorization_ref is None

    def test_visit_restriction_reason_holds_string(self):
        """Verifies Visit.restriction_reason holds a string when set (Req-37)."""
        v = Visit(
            id="visit-002",
            researcher_id="res-001",
            collection_id="col-001",
            visit_date="2023-06-01",
            restriction_reason="Restricted materials",
        )
        assert isinstance(v.restriction_reason, str)
        assert v.restriction_reason == "Restricted materials"

    def test_visit_authorization_ref_holds_string(self):
        """Verifies Visit.authorization_ref holds an authorization string when set (Req-37)."""
        v = Visit(
            id="visit-003",
            researcher_id="res-001",
            collection_id="col-001",
            visit_date="2023-07-01",
            restriction_reason="Restricted materials",
            authorization_ref="AUTH-2023-007",
        )
        assert isinstance(v.authorization_ref, str)
        assert v.authorization_ref == "AUTH-2023-007"


class TestReadingRoomCirculation:

    def test_reading_room_circulation_constructor_accepts_collection_processor(self, processor):
        """Verifies ReadingRoomCirculation can be constructed with a CollectionProcessor (Req-38)."""
        circ = ReadingRoomCirculation(processor)
        assert circ is not None

    def test_register_researcher_returns_researcher_instance(self, circulation):
        """Verifies register_researcher returns a Researcher instance with a string id (Req-39)."""
        result = circulation.register_researcher(
            name="Bob Archivist",
            contact_info="bob@archives.org",
            affiliation="State Library",
        )
        assert isinstance(result, Researcher)
        assert isinstance(result.id, str)

    def test_register_researcher_unique_ids(self, circulation):
        """Verifies register_researcher assigns distinct ids to different researchers (Req-39)."""
        r1 = circulation.register_researcher("Name One", "c1@x.com", "Org One")
        r2 = circulation.register_researcher("Name Two", "c2@x.com", "Org Two")
        assert isinstance(r1.id, str)
        assert isinstance(r2.id, str)
        assert r1.id != r2.id

    def test_record_visit_unregistered_researcher_raises_keyerror(
        self, circulation, sample_collection
    ):
        """Verifies record_visit raises KeyError for an unregistered researcher_id (Req-40)."""
        with pytest.raises(KeyError):
            circulation.record_visit(
                researcher_id="no-such-researcher-99",
                collection_id=sample_collection.id,
                visit_date="2024-01-10",
            )

    def test_record_visit_researcher_check_precedes_collection_check(
        self, circulation
    ):
        """Verifies researcher_id is validated before collection_id (sequential ordering, Req-40).

        When both researcher_id and collection_id reference unknown entities, the
        KeyError must identify the researcher - not the collection - proving that
        researcher is checked first. Relies on the keyword contracts established by
        test_record_visit_keyerror_researcher_message_identifies_researcher and
        test_record_visit_keyerror_collection_message_identifies_collection.
        """
        with pytest.raises(KeyError) as exc_info:
            circulation.record_visit(
                researcher_id="unknown-researcher-ordering-test",
                collection_id="unknown-collection-xyz",
                visit_date="2024-01-01",
            )
        assert "researcher" in str(exc_info.value).lower(), (
            "When both researcher_id and collection_id are unknown, the KeyError "
            "must identify the researcher, confirming researcher is checked first "
            "as required by the prompt's sequential ordering specification."
        )

    def test_record_visit_unrestricted_returns_visit_with_correct_fields(
        self, circulation, registered_researcher, sample_collection
    ):
        """Verifies record_visit returns Visit with correct fields, restriction_reason None,
        and authorization_ref None for unrestricted collections (Req-41, Req-43)."""
        assert sample_collection.access_restriction is None
        visit_date = "2024-02-20"
        visit = circulation.record_visit(
            researcher_id=registered_researcher.id,
            collection_id=sample_collection.id,
            visit_date=visit_date,
        )
        assert isinstance(visit, Visit)
        assert isinstance(visit.id, str)
        assert visit.researcher_id == registered_researcher.id
        assert visit.collection_id == sample_collection.id
        assert visit.visit_date == visit_date
        assert visit.restriction_reason is None
        assert visit.authorization_ref is None

    def test_record_visit_restricted_sets_restriction_reason(
        self, circulation, registered_researcher, restricted_collection
    ):
        """Verifies record_visit stores access_restriction as restriction_reason and stores
        authorization_ref on the Visit for restricted collections (Req-41, Req-43)."""
        assert restricted_collection.access_restriction is not None
        auth_ref = "AUTH-2024-001"
        visit = circulation.record_visit(
            researcher_id=registered_researcher.id,
            collection_id=restricted_collection.id,
            visit_date="2024-03-10",
            authorization_ref=auth_ref,
        )
        assert isinstance(visit, Visit)
        assert visit.restriction_reason == restricted_collection.access_restriction
        assert visit.authorization_ref == auth_ref

    def test_record_visit_assigns_unique_string_ids(
        self, circulation, registered_researcher, sample_collection
    ):
        """Verifies record_visit assigns unique string identifiers to each created Visit (Req-46)."""
        v1 = circulation.record_visit(
            researcher_id=registered_researcher.id,
            collection_id=sample_collection.id,
            visit_date="2024-04-01",
        )
        v2 = circulation.record_visit(
            researcher_id=registered_researcher.id,
            collection_id=sample_collection.id,
            visit_date="2024-04-02",
        )
        assert isinstance(v1.id, str)
        assert isinstance(v2.id, str)
        assert v1.id != v2.id

    def test_record_visit_restricted_absent_auth_ref_raises_valueerror(
        self, circulation, registered_researcher, restricted_collection
    ):
        """Verifies record_visit raises ValueError when collection is restricted and
        authorization_ref is not provided (Req-42)."""
        with pytest.raises(ValueError):
            circulation.record_visit(
                researcher_id=registered_researcher.id,
                collection_id=restricted_collection.id,
                visit_date="2024-04-05",
            )

    def test_record_visit_restricted_none_auth_ref_raises_valueerror(
        self, circulation, registered_researcher, restricted_collection
    ):
        """Verifies record_visit raises ValueError when collection is restricted and
        authorization_ref=None (Req-42)."""
        with pytest.raises(ValueError):
            circulation.record_visit(
                researcher_id=registered_researcher.id,
                collection_id=restricted_collection.id,
                visit_date="2024-04-06",
                authorization_ref=None,
            )

    def test_record_visit_unknown_collection_raises_keyerror(
        self, circulation, registered_researcher
    ):
        """Verifies record_visit raises KeyError when collection_id is not in CollectionProcessor (Req-44)."""
        with pytest.raises(KeyError):
            circulation.record_visit(
                researcher_id=registered_researcher.id,
                collection_id="nonexistent-collection-id-abc",
                visit_date="2024-05-01",
            )

    def test_record_visit_keyerror_messages_are_distinct(
        self, circulation, registered_researcher, sample_collection
    ):
        """Verifies researcher and collection KeyErrors carry distinct messages (Req-45)."""
        with pytest.raises(KeyError) as researcher_exc:
            circulation.record_visit(
                researcher_id="unknown-researcher-distinct",
                collection_id=sample_collection.id,
                visit_date="2024-01-01",
            )
        with pytest.raises(KeyError) as collection_exc:
            circulation.record_visit(
                researcher_id=registered_researcher.id,
                collection_id="unknown-collection-distinct",
                visit_date="2024-01-01",
            )
        assert str(researcher_exc.value) != str(collection_exc.value)

    def test_record_visit_keyerror_researcher_message_identifies_researcher(
        self, circulation, sample_collection
    ):
        """Verifies the KeyError raised when researcher_id is unregistered contains the word
        'researcher' (case-insensitive) so callers can identify the missing entity from the message."""
        with pytest.raises(KeyError) as exc_info:
            circulation.record_visit(
                researcher_id="no-such-researcher-semantic-test",
                collection_id=sample_collection.id,
                visit_date="2024-01-01",
            )
        assert "researcher" in str(exc_info.value).lower(), (
            "KeyError for missing researcher must contain 'researcher' in its message"
        )

    def test_record_visit_keyerror_collection_message_identifies_collection(
        self, circulation, registered_researcher
    ):
        """Verifies the KeyError raised when collection_id is not in the CollectionProcessor
        contains the word 'collection' (case-insensitive) so callers can identify the missing entity."""
        with pytest.raises(KeyError) as exc_info:
            circulation.record_visit(
                researcher_id=registered_researcher.id,
                collection_id="no-such-collection-semantic-test",
                visit_date="2024-01-01",
            )
        assert "collection" in str(exc_info.value).lower(), (
            "KeyError for missing collection must contain 'collection' in its message"
        )

    def test_get_visits_by_year_returns_matching(
        self, circulation, registered_researcher, sample_collection
    ):
        """Verifies get_visits_by_year returns only visits in the given calendar year (Req-47)."""
        v1 = circulation.record_visit(
            researcher_id=registered_researcher.id,
            collection_id=sample_collection.id,
            visit_date="2022-06-15",
        )
        v2 = circulation.record_visit(
            researcher_id=registered_researcher.id,
            collection_id=sample_collection.id,
            visit_date="2022-11-30",
        )
        circulation.record_visit(
            researcher_id=registered_researcher.id,
            collection_id=sample_collection.id,
            visit_date="2023-01-01",
        )
        result = circulation.get_visits_by_year(2022)
        assert isinstance(result, list)
        assert all(isinstance(v, Visit) for v in result)
        result_ids = {v.id for v in result}
        assert v1.id in result_ids
        assert v2.id in result_ids
        assert all(v.visit_date.startswith("2022") for v in result)

    def test_get_visits_by_year_returns_empty_when_none_match(
        self, circulation, registered_researcher, sample_collection
    ):
        """Verifies get_visits_by_year returns empty list when no visits fall in given year (Req-48)."""
        circulation.record_visit(
            researcher_id=registered_researcher.id,
            collection_id=sample_collection.id,
            visit_date="2021-07-04",
        )
        result = circulation.get_visits_by_year(1999)
        assert isinstance(result, list)
        assert len(result) == 0

    def test_record_visit_uses_current_access_restriction(
        self, circulation, registered_researcher, processor
    ):
        """Verifies record_visit resolves the collection's access_restriction from the
        CollectionProcessor at the time of the visit, not from a snapshot taken when
        ReadingRoomCirculation was constructed.

        A collection that is added to the CollectionProcessor *after* the circulation
        object was created must still be resolvable; and its current restriction must
        be honoured. If the circulation snapshotted the processor at init time, the
        collection would be unknown and a KeyError would be raised instead of the
        ValueError required by the restriction rule.
        """
        dacs = {
            "title": "Post-Init Restricted Collection",
            "date_range": "1965-1985",
            "extent_linear_feet": 2.5,
            "abstract": "Abstract.",
            "scope_and_content": "Scope.",
            "access_restriction": "Restricted - added after circulation was created",
        }
        late_collection = processor.process_collection(
            "acc-post-init-001", "By series", dacs
        )
        assert late_collection.access_restriction is not None

        with pytest.raises(ValueError):
            circulation.record_visit(
                researcher_id=registered_researcher.id,
                collection_id=late_collection.id,
                visit_date="2024-07-15",
            )

        visit = circulation.record_visit(
            researcher_id=registered_researcher.id,
            collection_id=late_collection.id,
            visit_date="2024-07-16",
            authorization_ref="AUTH-POST-INIT-001",
        )
        assert visit.restriction_reason == late_collection.access_restriction
        assert visit.authorization_ref == "AUTH-POST-INIT-001"



# ======================================================
# DIGITIZATION WORKFLOW
# ======================================================

class TestDigitizationJobDataclass:

    def test_digitization_job_dataclass_fields(self):
        """Verifies DigitizationJob is a dataclass with id, collection_id,
        preservation_standard, status fields (Req-49)."""
        job = DigitizationJob(
            id="job-001",
            collection_id="col-001",
            preservation_standard="FADGI 4-Star",
            status="queued",
        )
        assert dataclasses.is_dataclass(job)
        assert isinstance(job.id, str)
        assert isinstance(job.collection_id, str)
        assert isinstance(job.preservation_standard, str)
        assert isinstance(job.status, str)


class TestDigitizationWorkflow:

    def test_digitization_workflow_constructor_accepts_collection_processor(self, processor):
        """Verifies DigitizationWorkflow can be constructed with a CollectionProcessor (Req-50)."""
        wf = DigitizationWorkflow(processor)
        assert wf is not None

    def test_create_job_raises_keyerror_for_unknown_collection(self, workflow):
        """Verifies create_job raises KeyError when collection_id not in CollectionProcessor (Req-51)."""
        with pytest.raises(KeyError):
            workflow.create_job(
                collection_id="nonexistent-collection-id-dig",
                preservation_standard="TIFF",
            )

    def test_create_job_initial_status_and_fields(self, workflow, processor, sample_dacs_fields):
        """Verifies create_job creates a DigitizationJob with correct fields, initial status
        'queued', unique string id, and returns it (Req-52)."""
        col = processor.process_collection("acc-dig-001", "Alphabetical", sample_dacs_fields)
        std = "Archival TIFF"
        job = workflow.create_job(collection_id=col.id, preservation_standard=std)
        assert isinstance(job, DigitizationJob)
        assert isinstance(job.id, str)
        assert job.status == "queued"
        assert job.collection_id == col.id
        assert job.preservation_standard == std

    def test_create_job_assigns_unique_string_ids(self, workflow, processor, sample_dacs_fields):
        """Verifies create_job assigns a distinct string id to each created DigitizationJob (Req-52)."""
        dacs_a = dict(sample_dacs_fields)
        dacs_b = dict(sample_dacs_fields)
        dacs_b["title"] = "Another Title"
        col_a = processor.process_collection("acc-dig-A", "Scheme A", dacs_a)
        col_b = processor.process_collection("acc-dig-B", "Scheme B", dacs_b)
        job1 = workflow.create_job(col_a.id, "Standard A")
        job2 = workflow.create_job(col_b.id, "Standard B")
        assert isinstance(job1.id, str)
        assert isinstance(job2.id, str)
        assert job1.id != job2.id

    def test_update_job_status_valid(self, workflow, processor, sample_dacs_fields):
        """Verifies update_job_status updates status to a valid value and returns updated job (Req-53)."""
        col = processor.process_collection("acc-dig-002", "Scheme", sample_dacs_fields)
        job = workflow.create_job(col.id, "JPEG2000")
        updated = workflow.update_job_status(job.id, "in_progress")
        assert isinstance(updated, DigitizationJob)
        assert updated.status == "in_progress"
        updated2 = workflow.update_job_status(job.id, "complete")
        assert isinstance(updated2, DigitizationJob)
        assert updated2.status == "complete"

    def test_update_job_status_invalid_raises_valueerror(self, workflow, processor, sample_dacs_fields):
        """Verifies update_job_status raises ValueError for an invalid status string (Req-54)."""
        col = processor.process_collection("acc-dig-003", "Scheme", sample_dacs_fields)
        job = workflow.create_job(col.id, "Preservation standard")
        with pytest.raises(ValueError):
            workflow.update_job_status(job.id, "done")

    def test_update_job_status_missing_job_raises_keyerror(self, workflow):
        """Verifies update_job_status raises KeyError when job id does not exist (Req-55)."""
        with pytest.raises(KeyError):
            workflow.update_job_status("nonexistent-job-id-xyz", "in_progress")

    def test_update_job_status_queued_is_valid(self, workflow, processor, sample_dacs_fields):
        """Verifies 'queued' is accepted as a valid status by update_job_status (Req-53).

        Guards against implementations that only accept the two non-initial statuses.
        """
        col = processor.process_collection("acc-dig-004", "Scheme", sample_dacs_fields)
        job = workflow.create_job(col.id, "Preservation standard")
        workflow.update_job_status(job.id, "in_progress")
        updated = workflow.update_job_status(job.id, "queued")
        assert isinstance(updated, DigitizationJob)
        assert updated.status == "queued"



# ======================================================
# REGULATORY REPORTING
# ======================================================

class TestGenerateLegislativeReport:

    def _make_scenario(self, target_year, other_year):
        """Build a registry and circulation with known accessions and visits for year filtering."""
        reg = AccessionRegistry()
        proc = CollectionProcessor()
        circ = ReadingRoomCirculation(proc)

        a1 = reg.register_accession("purchase", "Accession In Year A", 3.0, target_year)
        a2 = reg.register_accession("purchase", "Accession In Year B", 5.0, target_year)
        reg.register_accession("purchase", "Accession Other Year", 2.0, other_year)

        dacs = {
            "title": "Report Test Collection",
            "date_range": "1950-1960",
            "extent_linear_feet": 3.0,
            "abstract": "Abstract.",
            "scope_and_content": "Scope.",
        }
        col = proc.process_collection("acc-report-001", "Alphabetical", dacs)
        researcher = circ.register_researcher("Tester", "t@e.com", "Lab")

        circ.record_visit(researcher.id, col.id, f"{target_year}-03-01")
        circ.record_visit(researcher.id, col.id, f"{target_year}-09-15")
        circ.record_visit(researcher.id, col.id, f"{other_year}-01-01")

        return reg, circ, a1, a2

    def test_generate_legislative_report_structure_and_types(self):
        """Verifies report dict has required keys with correct value types (Req-56)."""
        reg = AccessionRegistry()
        proc = CollectionProcessor()
        circ = ReadingRoomCirculation(proc)
        reg.register_accession("purchase", "Type Check Collection", 2.5, 2020)
        report = generate_legislative_report(reg, circ, 2020)
        assert isinstance(report, dict)
        assert "total_accessions" in report
        assert "total_linear_feet" in report
        assert "total_visits" in report
        assert isinstance(report["total_accessions"], int)
        assert isinstance(report["total_linear_feet"], float)
        assert isinstance(report["total_visits"], int)

    def test_generate_legislative_report_year_filtering(self):
        """Verifies report values reflect only records from the specified year (Req-57)."""
        target_year = 2025
        other_year = 2018
        reg, circ, a1, a2 = self._make_scenario(target_year, other_year)

        report = generate_legislative_report(reg, circ, target_year)

        assert report["total_accessions"] == 2
        assert report["total_linear_feet"] == a1.linear_feet + a2.linear_feet
        assert report["total_visits"] == 2

    def test_generate_legislative_report_empty_year_returns_zeros(self):
        """Verifies generate_legislative_report returns total_accessions=0, total_linear_feet=0.0,
        and total_visits=0 when no accessions and no visits fall in the requested calendar year."""
        reg = AccessionRegistry()
        proc = CollectionProcessor()
        circ = ReadingRoomCirculation(proc)
        reg.register_accession("purchase", "Some Title", 2.5, 2020)
        report = generate_legislative_report(reg, circ, 1900)
        assert report["total_accessions"] == 0
        assert isinstance(report["total_linear_feet"], float)
        assert report["total_linear_feet"] == 0.0
        assert report["total_visits"] == 0


class TestGenerateTransferSchedule:

    def _register_transfers(self, registry, agency_id, count=2):
        entries = []
        for i in range(count):
            acc = registry.register_accession(
                "transfer",
                f"Transfer Collection {i}",
                float(i + 1),
                2020 + i,
                agency_id=agency_id,
                public_records_authority=f"Auth § {i}",
                scheduled_transfer_date=f"202{i}-06-10",
                actual_transfer_date=f"202{i}-06-15",
            )
            entries.append(acc)
        return entries

    def test_generate_transfer_schedule_returns_matching_dicts(self):
        """Verifies transfer schedule returns list of dicts with correct keys for matching agency (Req-58)."""
        reg = AccessionRegistry()
        agency = "AGENCY-XYZ"
        transfers = self._register_transfers(reg, agency, count=2)
        reg.register_accession(
            "transfer", "Other Agency Transfer", 1.0, 2021,
            agency_id="OTHER-AGENCY",
            public_records_authority="Auth § 0",
            scheduled_transfer_date="2021-01-01",
            actual_transfer_date="2021-01-05",
        )
        reg.register_accession("purchase", "Purchase Title", 1.0, 2021)

        result = generate_transfer_schedule(reg, agency)

        assert isinstance(result, list)
        assert len(result) == 2
        for entry in result:
            assert isinstance(entry, dict)
            assert "accession_id" in entry
            assert "title" in entry
            assert "scheduled_transfer_date" in entry
            assert "actual_transfer_date" in entry

        result_ids = {e["accession_id"] for e in result}
        assert {t.id for t in transfers} == result_ids

    def test_generate_transfer_schedule_dict_values_match_accession(self):
        """Verifies transfer schedule dict values correspond to the matched accession record (Req-58)."""
        reg = AccessionRegistry()
        agency = "AGENCY-CHECK"
        acc = reg.register_accession(
            "transfer", "Specific Transfer Title", 3.0, 2022,
            agency_id=agency,
            public_records_authority="State Law § 12",
            scheduled_transfer_date="2022-05-01",
            actual_transfer_date="2022-05-10",
        )
        result = generate_transfer_schedule(reg, agency)
        assert isinstance(result, list)
        assert len(result) == 1
        entry = result[0]
        assert entry["accession_id"] == acc.id
        assert entry["title"] == acc.title
        assert entry["scheduled_transfer_date"] == acc.scheduled_transfer_date
        assert entry["actual_transfer_date"] == acc.actual_transfer_date

    def test_generate_transfer_schedule_returns_empty_list(self):
        """Verifies generate_transfer_schedule returns empty list when no matching transfers (Req-59)."""
        reg = AccessionRegistry()
        reg.register_accession("purchase", "Purchase Only", 1.0, 2021)
        result = generate_transfer_schedule(reg, "NO-MATCH-AGENCY")
        assert isinstance(result, list)
        assert len(result) == 0


# ======================================================
# DATACLASS TYPE ANNOTATIONS
# ======================================================

class TestDataclassTypeAnnotations:
    """Verifies all five dataclass types declare explicit type annotations for every required field."""

    def test_accession_has_all_annotated_fields(self):
        """Verifies Accession.__dataclass_fields__ contains all required typed field declarations."""
        field_names = set(Accession.__dataclass_fields__.keys())
        required = {
            "id", "accession_type", "title", "linear_feet", "year",
            "donor_id", "deed_of_gift_ref", "agency_id",
            "public_records_authority", "scheduled_transfer_date", "actual_transfer_date",
        }
        assert required.issubset(field_names), (
            f"Accession missing annotated fields: {required - field_names}"
        )

    def test_collection_has_all_annotated_fields(self):
        """Verifies Collection.__dataclass_fields__ contains all required typed field declarations."""
        field_names = set(Collection.__dataclass_fields__.keys())
        required = {
            "id", "accession_id", "title", "date_range", "extent_linear_feet",
            "abstract", "scope_and_content", "arrangement_scheme",
            "processing_status", "access_restriction",
        }
        assert required.issubset(field_names), (
            f"Collection missing annotated fields: {required - field_names}"
        )

    def test_researcher_has_all_annotated_fields(self):
        """Verifies Researcher.__dataclass_fields__ contains all required typed field declarations."""
        field_names = set(Researcher.__dataclass_fields__.keys())
        required = {"id", "name", "contact_info", "affiliation"}
        assert required.issubset(field_names), (
            f"Researcher missing annotated fields: {required - field_names}"
        )

    def test_visit_has_all_annotated_fields(self):
        """Verifies Visit.__dataclass_fields__ contains all required typed field declarations."""
        field_names = set(Visit.__dataclass_fields__.keys())
        required = {
            "id", "researcher_id", "collection_id", "visit_date",
            "restriction_reason", "authorization_ref",
        }
        assert required.issubset(field_names), (
            f"Visit missing annotated fields: {required - field_names}"
        )

    def test_digitization_job_has_all_annotated_fields(self):
        """Verifies DigitizationJob.__dataclass_fields__ contains all required typed field declarations."""
        field_names = set(DigitizationJob.__dataclass_fields__.keys())
        required = {"id", "collection_id", "preservation_standard", "status"}
        assert required.issubset(field_names), (
            f"DigitizationJob missing annotated fields: {required - field_names}"
        )