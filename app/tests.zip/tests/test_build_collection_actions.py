"""Tests for TaxAdministrationPlatform.build_collection_actions."""

from __future__ import annotations

from decimal import Decimal

import pytest

from _helpers import build_platform


def _liab(filer_id: str, liability: str, days: int) -> dict:
    return {
        "filer_id": filer_id,
        "unpaid_liability_usd": Decimal(liability),
        "days_past_due": days,
    }


# --------------------------------------------------------------------------- #
# Test ID: COL-01
# Requirement: Collections #2 (days_past_due < 0 -> ValueError).
# --------------------------------------------------------------------------- #
def test_build_collection_actions_negative_days_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError):
            platform.build_collection_actions([_liab("F-1", "100.00", -1)])
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"build_collection_actions raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: COL-02
# Requirement: Collections #3 (stage mapping 0..30 -> NOTICE, 31..90 ->
#   PAYMENT_PLAN, 91+ -> ENFORCEMENT) AND #5 (collection_action mapping
#   NOTICE->SEND_NOTICE, PAYMENT_PLAN->OFFER_PAYMENT_PLAN,
#   ENFORCEMENT->START_ENFORCEMENT).
# Test Description: One liability per stage -> verify stage and action.
# --------------------------------------------------------------------------- #
def test_build_collection_actions_stage_and_action_mapping():
    try:
        platform = build_platform()
        liabilities = [
            _liab("F-N", "10.00", 0),
            _liab("F-NN", "10.00", 30),
            _liab("F-P", "10.00", 31),
            _liab("F-PP", "10.00", 90),
            _liab("F-E", "10.00", 91),
            _liab("F-EE", "10.00", 365),
        ]
        result = platform.build_collection_actions(liabilities)
        by_id = {item["filer_id"]: item for item in result}

        assert by_id["F-N"]["collection_stage"] == "NOTICE"
        assert by_id["F-N"]["collection_action"] == "SEND_NOTICE"
        assert by_id["F-NN"]["collection_stage"] == "NOTICE"
        assert by_id["F-NN"]["collection_action"] == "SEND_NOTICE"

        assert by_id["F-P"]["collection_stage"] == "PAYMENT_PLAN"
        assert by_id["F-P"]["collection_action"] == "OFFER_PAYMENT_PLAN"
        assert by_id["F-PP"]["collection_stage"] == "PAYMENT_PLAN"
        assert by_id["F-PP"]["collection_action"] == "OFFER_PAYMENT_PLAN"

        assert by_id["F-E"]["collection_stage"] == "ENFORCEMENT"
        assert by_id["F-E"]["collection_action"] == "START_ENFORCEMENT"
        assert by_id["F-EE"]["collection_stage"] == "ENFORCEMENT"
        assert by_id["F-EE"]["collection_action"] == "START_ENFORCEMENT"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"build_collection_actions raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: COL-03
# Requirement: Collections #4 (output keys include filer_id, collection_stage,
#   collection_action, unpaid_liability_usd, days_past_due, all propagated).
# --------------------------------------------------------------------------- #
def test_build_collection_actions_output_schema():
    try:
        platform = build_platform()
        liabilities = [_liab("F-OUT", "55.00", 10)]
        result = platform.build_collection_actions(liabilities)
        item = result[0]
        for key in (
            "filer_id",
            "collection_stage",
            "collection_action",
            "unpaid_liability_usd",
            "days_past_due",
        ):
            assert key in item, f"missing key {key!r}"

        assert item["filer_id"] == "F-OUT"
        assert Decimal(item["unpaid_liability_usd"]) == Decimal("55.00")
        assert item["days_past_due"] == 10
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"build_collection_actions raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: COL-04
# Requirement: Collections #6 (ordering: days_past_due desc,
#   unpaid_liability_usd desc, filer_id asc).
# --------------------------------------------------------------------------- #
def test_build_collection_actions_ordering():
    try:
        platform = build_platform()
        liabilities = [
            _liab("F-3", "100.00", 30),
            _liab("F-1", "200.00", 60),
            _liab("F-2", "200.00", 60),
            _liab("F-0", "100.00", 60),
            _liab("F-9", "10.00", 91),
        ]
        result = platform.build_collection_actions(liabilities)
        order = [item["filer_id"] for item in result]

        assert order == ["F-9", "F-1", "F-2", "F-0", "F-3"]
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"build_collection_actions raised unexpected exception: {exc!r}")
