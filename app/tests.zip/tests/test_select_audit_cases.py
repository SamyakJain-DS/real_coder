"""Tests for TaxAdministrationPlatform.select_audit_cases."""

from __future__ import annotations

from decimal import Decimal

import pytest

from _helpers import build_platform


def _candidate(filer_id: str, risk: str, liability: str, period: str = "2024-01") -> dict:
    return {
        "filer_id": filer_id,
        "risk_score": Decimal(risk),
        "unpaid_liability_usd": Decimal(liability),
        "last_return_period": period,
    }


# --------------------------------------------------------------------------- #
# Test ID: AUD-SEL-01
# Requirement: Audit #2 (deterministic ranking: risk_score desc,
#   unpaid_liability_usd desc, filer_id asc).
# Test Description: Verify the order of selected cases obeys the documented
#   tie-break sequence.
# --------------------------------------------------------------------------- #
def test_select_audit_cases_deterministic_ranking_order():
    try:
        platform = build_platform()
        candidates = [
            _candidate("F-A", "0.50", "100.00"),
            _candidate("F-B", "0.90", "100.00"),
            _candidate("F-C", "0.90", "200.00"),
            _candidate("F-D", "0.90", "200.00"),  # ties with F-C; F-C comes first by filer_id asc
            _candidate("F-E", "0.50", "150.00"),
        ]
        selected = platform.select_audit_cases(candidates, target_case_count=5)

        order = [item["filer_id"] for item in selected]
        assert order == ["F-C", "F-D", "F-B", "F-E", "F-A"]
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"select_audit_cases raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-SEL-02
# Requirement: Audit #3 (target_case_count < 0 -> ValueError).
# --------------------------------------------------------------------------- #
def test_select_audit_cases_negative_target_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError):
            platform.select_audit_cases([], target_case_count=-1)
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"select_audit_cases raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-SEL-03
# Requirement: Audit #4 (selected count = MIN(target_case_count, len(candidates))).
# Test Description: With more candidates than target, only target items are returned.
# --------------------------------------------------------------------------- #
def test_select_audit_cases_count_min_target_or_candidates():
    try:
        platform = build_platform()
        candidates = [
            _candidate("F-1", "0.10", "1.00"),
            _candidate("F-2", "0.20", "2.00"),
            _candidate("F-3", "0.30", "3.00"),
        ]
        selected_two = platform.select_audit_cases(candidates, target_case_count=2)
        selected_ten = platform.select_audit_cases(candidates, target_case_count=10)

        assert len(selected_two) == 2
        assert len(selected_ten) == 3
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"select_audit_cases raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-SEL-04
# Requirement: Validation #4 (target_case_count == 0 -> empty list).
# --------------------------------------------------------------------------- #
def test_select_audit_cases_target_zero_returns_empty():
    try:
        platform = build_platform()
        candidates = [
            _candidate("F-1", "0.50", "10.00"),
            _candidate("F-2", "0.40", "5.00"),
        ]
        result = platform.select_audit_cases(candidates, target_case_count=0)

        assert result == []
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"select_audit_cases raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-SEL-05
# Requirement: Audit #5 (output keys) + #7 (status SELECTED).
# Test Description: Each selected case includes filer_id, rank, audit_status,
#   selection_reason, and audit_status equals "SELECTED".
# --------------------------------------------------------------------------- #
def test_select_audit_cases_output_schema_and_status():
    try:
        platform = build_platform()
        candidates = [_candidate("F-1", "0.5", "10")]
        selected = platform.select_audit_cases(candidates, target_case_count=1)

        item = selected[0]
        for key in ("filer_id", "rank", "audit_status", "selection_reason"):
            assert key in item, f"missing key {key!r}"
        assert item["audit_status"] == "SELECTED"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"select_audit_cases raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-SEL-06
# Requirement: Audit #6 (rank starts at 1, increments by 1).
# --------------------------------------------------------------------------- #
def test_select_audit_cases_rank_sequence():
    try:
        platform = build_platform()
        candidates = [
            _candidate("F-1", "0.10", "1"),
            _candidate("F-2", "0.20", "2"),
            _candidate("F-3", "0.30", "3"),
        ]
        selected = platform.select_audit_cases(candidates, target_case_count=3)
        ranks = [item["rank"] for item in selected]

        assert ranks == [1, 2, 3]
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"select_audit_cases raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-SEL-07
# Requirement: Audit #8 (selection_reason format
#   RISK=<risk_score>;LIABILITY=<unpaid_liability_usd> with input scale
#   preserved).
# Test Description: With risk_score=Decimal("0.50") and
#   unpaid_liability_usd=Decimal("1234.5600"), the rendered
#   selection_reason equals "RISK=0.50;LIABILITY=1234.5600".
# --------------------------------------------------------------------------- #
def test_select_audit_cases_selection_reason_preserves_scale():
    try:
        platform = build_platform()
        candidates = [
            {
                "filer_id": "F-RX",
                "risk_score": Decimal("0.50"),
                "unpaid_liability_usd": Decimal("1234.5600"),
                "last_return_period": "2024-01",
            }
        ]
        selected = platform.select_audit_cases(candidates, target_case_count=1)
        assert selected[0]["selection_reason"] == "RISK=0.50;LIABILITY=1234.5600"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"select_audit_cases raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: AUD-SEL-08
# Requirement: Audit #8 (selection_reason: no scientific notation).
# Test Description: Very small / very large Decimal values must render as
#   fixed-point text without exponent notation.
# --------------------------------------------------------------------------- #
def test_select_audit_cases_selection_reason_no_scientific_notation():
    try:
        platform = build_platform()
        candidates = [
            {
                "filer_id": "F-LG",
                "risk_score": Decimal("0.0001"),
                "unpaid_liability_usd": Decimal("1000000000.00"),
                "last_return_period": "2024-01",
            }
        ]
        reason = platform.select_audit_cases(candidates, target_case_count=1)[0]["selection_reason"]

        assert "E" not in reason and "e" not in reason
        assert reason == "RISK=0.0001;LIABILITY=1000000000.00"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"select_audit_cases raised unexpected exception: {exc!r}")


