import json
import os
import subprocess
import sys
from pathlib import Path

import pandas as pd
import pytest

# ---------------------------------------------------------------------------
# Graceful import handling - ImportError -> FAILED, not ERROR
# ---------------------------------------------------------------------------

_PARENT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PARENT_DIR))

try:
    from estimator import estimate_single_payment_amount
    _ESTIMATOR_OK = True
except ImportError:
    estimate_single_payment_amount = None
    _ESTIMATOR_OK = False

try:
    from access_analyzer import identify_access_reduction_patterns
    _ACCESS_OK = True
except ImportError:
    identify_access_reduction_patterns = None
    _ACCESS_OK = False

try:
    from equity_analyzer import attribute_health_equity_impact
    _EQUITY_OK = True
except ImportError:
    attribute_health_equity_impact = None
    _EQUITY_OK = False

try:
    from reporter import generate_performance_report, generate_recommendation_packet
    _REPORTER_OK = True
except ImportError:
    generate_performance_report = None
    generate_recommendation_packet = None
    _REPORTER_OK = False

try:
    from pipeline import run_pipeline
    _PIPELINE_OK = True
except ImportError:
    run_pipeline = None
    _PIPELINE_OK = False


# ---------------------------------------------------------------------------
# Module-level fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def output_dir(tmp_path, monkeypatch):
    """Provide a temp directory with outputs/ pre-created; change CWD to it."""
    (tmp_path / "outputs").mkdir()
    monkeypatch.chdir(tmp_path)
    return tmp_path


@pytest.fixture
def cba_pricing():
    return pd.DataFrame({
        "cba_id":         ["CBA1", "CBA1", "CBA1", "CBA2", "CBA2"],
        "hcpcs_code":     ["H001", "H001", "H002", "H001", "H002"],
        "round":          [1,      2,      2,      1,      1     ],
        "payment_amount": [100.0,  120.0,  90.0,   95.0,   85.0  ],
    })


@pytest.fixture
def supplier_bids():
    return pd.DataFrame({
        "supplier_id":         ["S1",  "S2",  "S1",  "S1",  "S2" ],
        "cba_id":              ["CBA1","CBA1","CBA2","CBA1","CBA2"],
        "hcpcs_code":          ["H001","H001","H001","H002","H002"],
        "product_category":    ["CatA","CatA","CatA","CatB","CatB"],
        "bid_amount":          [90.0,  110.0, 88.0,  80.0,  82.0 ],
        "capacity_units":      [10,    20,    15,    12,    8    ],
        "contract_status":     ["active"]*5,
        "bid_year":            [2020,  2020,  2020,  2020,  2020 ],
        "accreditation_status":["accredited"]*5,
        "surety_bond_status":  ["active"]*5,
    })


@pytest.fixture
def access_patterns_df():
    return pd.DataFrame({
        "cba_id":           ["CBA1", "CBA1", "CBA2"],
        "hcpcs_code":       ["H001", "H002", "H001"],
        "year":             [2021,   2022,   2021  ],
        "access_pattern":   ["contract_attrition", "utilization_shift", "utilization_shift"],
        "mean_oop_cost_share": [12.0, 9.0, 8.0],
    })


@pytest.fixture
def cba_classifications():
    return pd.DataFrame({
        "cba_id":       ["CBA1", "CBA2"],
        "rural_flag":   [1,      0     ],
        "frontier_flag":[0,      0     ],
    })


@pytest.fixture
def beneficiary_enrollment():
    return pd.DataFrame({
        "beneficiary_id":     ["B1",   "B2",   "B3",   "B4"  ],
        "cba_id":             ["CBA1", "CBA1", "CBA2", "CBA2"],
        "dual_eligible":      [1,      0,      1,      0     ],
        "rural_classification":["rural","urban","urban","urban"],
    })


@pytest.fixture
def gap_fill_pricing():
    return pd.DataFrame({
        "hcpcs_code":   ["H001",    "H002"    ],
        "cba_id":       ["CBA1",    "CBA1"    ],
        "gap_fill_amount":[95.0,    85.0      ],
        "methodology":  ["regional","national"],
    })


@pytest.fixture
def spa_estimates():
    return pd.DataFrame({
        "cba_id":          ["CBA1",  "CBA2" ],
        "hcpcs_code":      ["H001",  "H001" ],
        "product_category":["CatA",  "CatA" ],
        "round":           [2,       1      ],
        "estimated_spa":   [100.0,   90.0   ],
    })


@pytest.fixture
def equity_impacts():
    return pd.DataFrame({
        "cba_id":                  ["CBA1", "CBA2"],
        "year":                    [2021,   2021  ],
        "access_pattern":          ["contract_attrition","utilization_shift"],
        "dual_eligible_count":     [1,      1     ],
        "non_dual_eligible_count": [1,      1     ],
        "rural_frontier_proportion":[1.0,   0.0   ],
    })


@pytest.fixture
def lcd_data():
    return pd.DataFrame({
        "cba_id":           ["CBA1","CBA2"],
        "hcpcs_code":       ["H001","H001"],
        "determination_year":[2020, 2020  ],
        "coverage_status":  ["covered","covered"],
    })


@pytest.fixture
def contractor_inquiries():
    return pd.DataFrame({
        "cba_id":          ["CBA1"],
        "hcpcs_code":      ["H001"],
        "inquiry_year":    [2021  ],
        "inquiry_count":   [3     ],
        "resolution_status":["resolved"],
    })


@pytest.fixture
def pipeline_dir(tmp_path, monkeypatch):
    """
    Full eight-file data directory for run_pipeline / CLI integration tests.
    CWD is changed to tmp_path so run_pipeline('data/') resolves correctly.
    """
    data = tmp_path / "data"
    data.mkdir()
    (tmp_path / "outputs").mkdir()
    monkeypatch.chdir(tmp_path)

    # cba_pricing.csv - 10 rounds, 5 CBAs, 3 HCPCS
    rows = []
    for cba in ["CBA1","CBA2","CBA3","CBA4","CBA5"]:
        for hcpcs in ["H001","H002","H003"]:
            for r in range(1, 11):
                rows.append({"cba_id": cba, "hcpcs_code": hcpcs,
                             "round": r, "payment_amount": 100.0})
    pd.DataFrame(rows).to_csv(data / "cba_pricing.csv", index=False)

    # supplier_bids.csv - 4 suppliers, 10 bid_years, 5 CBAs, 3 HCPCS
    rows = []
    for cba in ["CBA1","CBA2","CBA3","CBA4","CBA5"]:
        for hcpcs in ["H001","H002","H003"]:
            for yr in range(2013, 2023):
                for sid in ["S1","S2","S3","S4"]:
                    rows.append({
                        "supplier_id": sid, "cba_id": cba, "hcpcs_code": hcpcs,
                        "product_category": f"Cat_{hcpcs}", "bid_amount": 90.0,
                        "capacity_units": 10, "contract_status": "active",
                        "bid_year": yr, "accreditation_status": "accredited",
                        "surety_bond_status": "active",
                    })
    pd.DataFrame(rows).to_csv(data / "supplier_bids.csv", index=False)

    # claims.csv - 10 claim_years; CBA1 has decreasing count to trigger patterns
    rows = []
    for cba in ["CBA1","CBA2","CBA3","CBA4","CBA5"]:
        for hcpcs in ["H001","H002","H003"]:
            for i, yr in enumerate(range(2013, 2023)):
                # CBA1 has decreasing claims (to generate contract_attrition)
                count = 100 - i * 3 if cba == "CBA1" else 100 + i
                rows.append({
                    "cba_id": cba, "beneficiary_id": f"B_{cba}_{hcpcs}",
                    "hcpcs_code": hcpcs, "claim_year": yr,
                    "claim_count": max(count, 1), "oop_cost_share": 10.0,
                })
    pd.DataFrame(rows).to_csv(data / "claims.csv", index=False)

    # beneficiary.csv
    rows = []
    for i, cba in enumerate(["CBA1","CBA2","CBA3","CBA4","CBA5"]):
        for j in range(4):
            rows.append({
                "beneficiary_id": f"B{i*4+j}", "cba_id": cba,
                "dual_eligible": j % 2,
                "rural_classification": "rural" if j < 2 else "urban",
            })
    pd.DataFrame(rows).to_csv(data / "beneficiary.csv", index=False)

    # cba_classification.csv
    pd.DataFrame({
        "cba_id":      ["CBA1","CBA2","CBA3","CBA4","CBA5"],
        "rural_flag":  [1,     0,     0,     1,     0    ],
        "frontier_flag":[0,    0,     1,     0,     0    ],
    }).to_csv(data / "cba_classification.csv", index=False)

    # gap_fill_pricing.csv
    rows = []
    for cba in ["CBA1","CBA2","CBA3","CBA4","CBA5"]:
        for hcpcs in ["H001","H002","H003"]:
            rows.append({"hcpcs_code": hcpcs, "cba_id": cba,
                         "gap_fill_amount": 85.0, "methodology": "regional"})
    pd.DataFrame(rows).to_csv(data / "gap_fill_pricing.csv", index=False)

    # lcd_data.csv
    rows = []
    for cba in ["CBA1","CBA2","CBA3","CBA4","CBA5"]:
        for hcpcs in ["H001","H002","H003"]:
            rows.append({"cba_id": cba, "hcpcs_code": hcpcs,
                         "determination_year": 2020, "coverage_status": "covered"})
    pd.DataFrame(rows).to_csv(data / "lcd_data.csv", index=False)

    # contractor_inquiries.csv
    rows = []
    for cba in ["CBA1","CBA2","CBA3","CBA4","CBA5"]:
        for hcpcs in ["H001","H002","H003"]:
            rows.append({"cba_id": cba, "hcpcs_code": hcpcs,
                         "inquiry_year": 2020, "inquiry_count": 2,
                         "resolution_status": "resolved"})
    pd.DataFrame(rows).to_csv(data / "contractor_inquiries.csv", index=False)

    return tmp_path


# ---------------------------------------------------------------------------
# Tests: estimate_single_payment_amount
# ---------------------------------------------------------------------------

class TestEstimateSinglePaymentAmount:

    def _req(self):
        if not _ESTIMATOR_OK:
            pytest.fail("estimator.py could not be imported")

    def test_output_is_dataframe_with_required_columns(self, cba_pricing, supplier_bids):
        self._req()
        result = estimate_single_payment_amount(cba_pricing, supplier_bids)
        assert isinstance(result, pd.DataFrame)
        required = {"cba_id", "hcpcs_code", "product_category", "round", "estimated_spa"}
        assert required.issubset(set(result.columns))

    def test_one_row_per_unique_cba_hcpcs(self, cba_pricing, supplier_bids):
        self._req()
        result = estimate_single_payment_amount(cba_pricing, supplier_bids)
        expected_combos = supplier_bids[["cba_id","hcpcs_code"]].drop_duplicates().shape[0]
        assert len(result) == expected_combos
        assert result[["cba_id","hcpcs_code"]].drop_duplicates().shape[0] == len(result)

    def test_filters_to_accredited_and_active_bond_only(self, cba_pricing):
        self._req()
        # S1 is accredited+active (bid=100); S2 not accredited; S3 inactive bond
        bids = pd.DataFrame({
            "supplier_id":         ["S1",          "S2",             "S3"          ],
            "cba_id":              ["CBA1",         "CBA1",           "CBA1"        ],
            "hcpcs_code":          ["H001",         "H001",           "H001"        ],
            "product_category":    ["CatA",         "CatA",           "CatA"        ],
            "bid_amount":          [100.0,          500.0,            500.0         ],
            "capacity_units":      [10,             10,               10            ],
            "contract_status":     ["active",       "active",         "active"      ],
            "bid_year":            [2020,           2020,             2020          ],
            "accreditation_status":["accredited",   "not_accredited", "accredited"  ],
            "surety_bond_status":  ["active",       "active",         "inactive"    ],
        })
        pricing = pd.DataFrame({
            "cba_id": ["CBA1"], "hcpcs_code": ["H001"],
            "round": [1], "payment_amount": [50.0],
        })
        result = estimate_single_payment_amount(pricing, bids)
        # Only S1 qualifies; capacity_weighted_avg=100, MAD=0, raw=100, floor=50 -> spa=100
        spa = result.loc[result["cba_id"] == "CBA1", "estimated_spa"].iloc[0]
        assert abs(spa - 100.0) < 1e-6

    def test_capacity_weighted_average_and_mad_formula(self):
        self._req()
        bids = pd.DataFrame({
            "supplier_id":         ["S1",       "S2"      ],
            "cba_id":              ["CBA1",     "CBA1"    ],
            "hcpcs_code":          ["H001",     "H001"    ],
            "product_category":    ["CatA",     "CatA"    ],
            "bid_amount":          [90.0,       110.0     ],
            "capacity_units":      [10,         10        ],
            "contract_status":     ["active",   "active"  ],
            "bid_year":            [2020,       2020      ],
            "accreditation_status":["accredited","accredited"],
            "surety_bond_status":  ["active",   "active"  ],
        })
        pricing = pd.DataFrame({
            "cba_id": ["CBA1"], "hcpcs_code": ["H001"],
            "round": [1], "payment_amount": [80.0],
        })
        result = estimate_single_payment_amount(pricing, bids)
        spa = result.loc[result["cba_id"] == "CBA1", "estimated_spa"].iloc[0]
        assert abs(spa - 90.0) < 1e-6

    def test_historical_mean_spa_is_applied_as_floor(self):
        self._req()
        # Low bids produce raw estimate below historical mean -> floor kicks in
        bids = pd.DataFrame({
            "supplier_id":         ["S1",       "S2"      ],
            "cba_id":              ["CBA1",     "CBA1"    ],
            "hcpcs_code":          ["H001",     "H001"    ],
            "product_category":    ["CatA",     "CatA"    ],
            "bid_amount":          [50.0,       70.0      ],
            "capacity_units":      [10,         10        ],
            "contract_status":     ["active",   "active"  ],
            "bid_year":            [2020,       2020      ],
            "accreditation_status":["accredited","accredited"],
            "surety_bond_status":  ["active",   "active"  ],
        })
        pricing = pd.DataFrame({
            "cba_id": ["CBA1"], "hcpcs_code": ["H001"],
            "round": [1], "payment_amount": [200.0],
        })
        result = estimate_single_payment_amount(pricing, bids)
        # weighted_avg=60, MAD=10, raw=50, floor=200 -> spa=200
        spa = result.loc[result["cba_id"] == "CBA1", "estimated_spa"].iloc[0]
        assert abs(spa - 200.0) < 1e-6

    def test_empty_filtered_group_falls_back_to_historical_mean(self):
        self._req()
        # No suppliers pass the accreditation filter
        bids = pd.DataFrame({
            "supplier_id":         ["S1"           ],
            "cba_id":              ["CBA1"         ],
            "hcpcs_code":          ["H001"         ],
            "product_category":    ["CatA"         ],
            "bid_amount":          [90.0           ],
            "capacity_units":      [10             ],
            "contract_status":     ["active"       ],
            "bid_year":            [2020           ],
            "accreditation_status":["not_accredited"],
            "surety_bond_status":  ["active"       ],
        })
        pricing = pd.DataFrame({
            "cba_id": ["CBA1"], "hcpcs_code": ["H001"],
            "round": [1], "payment_amount": [150.0],
        })
        result = estimate_single_payment_amount(pricing, bids)
        assert len(result) == 1
        assert abs(result["estimated_spa"].iloc[0] - 150.0) < 1e-6

    def test_round_column_is_max_round_from_cba_pricing(self):
        self._req()
        bids = pd.DataFrame({
            "supplier_id":         ["S1"       ],
            "cba_id":              ["CBA1"     ],
            "hcpcs_code":          ["H001"     ],
            "product_category":    ["CatA"     ],
            "bid_amount":          [100.0      ],
            "capacity_units":      [10         ],
            "contract_status":     ["active"   ],
            "bid_year":            [2020       ],
            "accreditation_status":["accredited"],
            "surety_bond_status":  ["active"   ],
        })
        pricing = pd.DataFrame({
            "cba_id":         ["CBA1","CBA1","CBA1"],
            "hcpcs_code":     ["H001","H001","H001"],
            "round":          [1,     5,     3     ],
            "payment_amount": [100.0, 110.0, 105.0],
        })
        result = estimate_single_payment_amount(pricing, bids)
        assert result.loc[result["cba_id"] == "CBA1", "round"].iloc[0] == 5

    def test_product_category_sourced_from_supplier_bids(self, cba_pricing, supplier_bids):
        self._req()
        result = estimate_single_payment_amount(cba_pricing, supplier_bids)
        row = result[(result["cba_id"] == "CBA1") & (result["hcpcs_code"] == "H001")]
        assert len(row) == 1
        assert row["product_category"].iloc[0] == "CatA"

    def test_historical_mean_spa_is_mean_of_multiple_payment_amounts(self):
        self._req()
        # Three rounds: 90, 120, 150 -> mean = 120. No accredited suppliers -> fallback to mean.
        bids = pd.DataFrame({
            "supplier_id":         ["S1"           ],
            "cba_id":              ["CBA1"         ],
            "hcpcs_code":          ["H001"         ],
            "product_category":    ["CatA"         ],
            "bid_amount":          [90.0           ],
            "capacity_units":      [10             ],
            "contract_status":     ["active"       ],
            "bid_year":            [2020           ],
            "accreditation_status":["not_accredited"],
            "surety_bond_status":  ["active"       ],
        })
        pricing = pd.DataFrame({
            "cba_id":         ["CBA1", "CBA1", "CBA1"],
            "hcpcs_code":     ["H001", "H001", "H001"],
            "round":          [1,      2,      3     ],
            "payment_amount": [90.0,   120.0,  150.0 ],
        })
        result = estimate_single_payment_amount(pricing, bids)
        # Empty filtered group -> estimated_spa = historical_mean_spa = mean(90, 120, 150) = 120
        assert abs(result["estimated_spa"].iloc[0] - 120.0) < 1e-6

    def test_estimated_spa_is_at_least_historical_mean_spa_for_all_rows(self, cba_pricing, supplier_bids):
        self._req()
        result = estimate_single_payment_amount(cba_pricing, supplier_bids)
        historical_means = (
            cba_pricing.groupby(["cba_id", "hcpcs_code"])["payment_amount"].mean()
        )
        for _, row in result.iterrows():
            key = (row["cba_id"], row["hcpcs_code"])
            hist_mean = historical_means.loc[key]
            assert row["estimated_spa"] >= hist_mean - 1e-9, (
                f"estimated_spa {row['estimated_spa']} < historical_mean_spa "
                f"{hist_mean} for {key}"
            )


# ---------------------------------------------------------------------------
# Tests: identify_access_reduction_patterns
# ---------------------------------------------------------------------------

class TestIdentifyAccessReductionPatterns:

    def _req(self):
        if not _ACCESS_OK:
            pytest.fail("access_analyzer.py could not be imported")

    @staticmethod
    def _make_data():
        claims = pd.DataFrame({
            "cba_id":      ["CBA1","CBA1","CBA1","CBA1","CBA1","CBA2","CBA2"],
            "beneficiary_id":["B1","B1","B1","B1","B1","B2","B2"],
            "hcpcs_code":  ["H001","H001","H001","H002","H002","H001","H001"],
            "claim_year":  [2020,  2021,  2022,  2020,  2021,  2020,  2021 ],
            "claim_count": [100,   80,    90,    50,    60,    40,    30   ],
            "oop_cost_share":[10.0,12.0,  11.0,  8.0,   9.0,   7.0,   8.5 ],
        })
        bids = pd.DataFrame({
            "supplier_id":        ["S1","S2","S1","S1","S1"],
            "cba_id":             ["CBA1","CBA1","CBA1","CBA2","CBA2"],
            "hcpcs_code":         ["H001","H001","H001","H001","H001"],
            "product_category":   ["CatA","CatA","CatA","CatA","CatA"],
            "bid_amount":         [90.0,  100.0, 95.0,  88.0,  92.0 ],
            "capacity_units":     [10,    20,    15,    12,    10   ],
            "contract_status":    ["active"]*5,
            "bid_year":           [2020,  2020,  2021,  2020,  2021 ],
            "accreditation_status":["accredited"]*5,
            "surety_bond_status": ["active"]*5,
        })
        return claims, bids

    def test_output_is_dataframe_with_required_columns(self):
        self._req()
        claims, bids = self._make_data()
        result = identify_access_reduction_patterns(claims, bids)
        assert isinstance(result, pd.DataFrame)
        required = {"cba_id", "hcpcs_code", "year", "access_pattern", "mean_oop_cost_share"}
        assert required.issubset(set(result.columns))

    def test_positive_yoy_claim_change_not_flagged(self):
        self._req()
        claims, bids = self._make_data()
        result = identify_access_reduction_patterns(claims, bids)
        # CBA1/H002 2021: claims went up (60 > 50) - must not appear
        not_present = result[(result["cba_id"] == "CBA1") & (result["hcpcs_code"] == "H002")]
        assert len(not_present) == 0

    def test_increase_year_after_decrease_not_flagged(self):
        self._req()
        claims, bids = self._make_data()
        result = identify_access_reduction_patterns(claims, bids)
        # CBA1/H001 2022: claims went up from 80 to 90 - must not appear
        cba1_h001 = result[(result["cba_id"] == "CBA1") & (result["hcpcs_code"] == "H001")]
        assert 2022 not in cba1_h001["year"].tolist()

    def test_contract_attrition_when_active_supplier_count_decreases(self):
        self._req()
        claims, bids = self._make_data()
        result = identify_access_reduction_patterns(claims, bids)
        # CBA1/H001 2021: claims drop AND active suppliers drop 2->1
        row = result[(result["cba_id"] == "CBA1") & (result["hcpcs_code"] == "H001") & (result["year"] == 2021)]
        assert len(row) == 1
        assert row["access_pattern"].iloc[0] == "contract_attrition"

    def test_utilization_shift_when_active_supplier_count_unchanged(self):
        self._req()
        claims, bids = self._make_data()
        result = identify_access_reduction_patterns(claims, bids)
        # CBA2/H001 2021: claims drop but suppliers stay at 1
        row = result[(result["cba_id"] == "CBA2") & (result["hcpcs_code"] == "H001") & (result["year"] == 2021)]
        assert len(row) == 1
        assert row["access_pattern"].iloc[0] == "utilization_shift"

    def test_first_year_per_group_is_excluded(self):
        self._req()
        claims, bids = self._make_data()
        result = identify_access_reduction_patterns(claims, bids)
        # 2020 is the earliest year for every group - no YoY change defined, never flagged
        assert (result["year"] == 2020).sum() == 0

    def test_mean_oop_cost_share_is_mean_per_group_year(self):
        self._req()
        # B1 and B2 both have claims in 2021 with different oop values
        claims = pd.DataFrame({
            "cba_id":       ["CBA1","CBA1","CBA1","CBA1"],
            "beneficiary_id":["B1",  "B2",  "B1",  "B2" ],
            "hcpcs_code":   ["H001","H001","H001","H001"],
            "claim_year":   [2020,  2020,  2021,  2021  ],
            "claim_count":  [50,    50,    30,    30    ],
            "oop_cost_share":[10.0, 20.0,  15.0,  25.0  ],
        })
        bids = pd.DataFrame({
            "supplier_id":        ["S1"       ],
            "cba_id":             ["CBA1"     ],
            "hcpcs_code":         ["H001"     ],
            "product_category":   ["CatA"     ],
            "bid_amount":         [90.0       ],
            "capacity_units":     [10         ],
            "contract_status":    ["active"   ],
            "bid_year":           [2021       ],
            "accreditation_status":["accredited"],
            "surety_bond_status": ["active"   ],
        })
        result = identify_access_reduction_patterns(claims, bids)
        row = result[(result["cba_id"] == "CBA1") & (result["year"] == 2021)]
        assert len(row) == 1
        assert abs(row["mean_oop_cost_share"].iloc[0] - 20.0) < 1e-6

    def test_missing_bid_year_defaults_to_zero_supplier_change(self):
        self._req()
        # Claims decrease but no supplier data at all -> active_supplier_count change = 0
        claims = pd.DataFrame({
            "cba_id":       ["CBA1","CBA1"],
            "beneficiary_id":["B1",  "B1" ],
            "hcpcs_code":   ["H001","H001"],
            "claim_year":   [2020,  2021  ],
            "claim_count":  [100,   70    ],
            "oop_cost_share":[10.0, 12.0  ],
        })
        bids = pd.DataFrame({c: pd.Series(dtype=str if c not in ("bid_amount","capacity_units","bid_year") else (float if c == "bid_amount" else int))
                             for c in ["supplier_id","cba_id","hcpcs_code","product_category",
                                       "bid_amount","capacity_units","contract_status","bid_year",
                                       "accreditation_status","surety_bond_status"]})
        result = identify_access_reduction_patterns(claims, bids)
        assert len(result) == 1
        assert result["access_pattern"].iloc[0] == "utilization_shift"

    def test_inactive_suppliers_excluded_from_active_supplier_count(self):
        self._req()
        claims = pd.DataFrame({
            "cba_id":       ["CBA1","CBA1"],
            "beneficiary_id":["B1",  "B1" ],
            "hcpcs_code":   ["H001","H001"],
            "claim_year":   [2020,  2021  ],
            "claim_count":  [100,   80    ],  # decrease -> access reduction flagged
            "oop_cost_share":[10.0, 12.0  ],
        })
        bids = pd.DataFrame({
            "supplier_id":         ["S1",      "S1",      "S2"      ],
            "cba_id":              ["CBA1",    "CBA1",    "CBA1"    ],
            "hcpcs_code":          ["H001",    "H001",    "H001"    ],
            "product_category":    ["CatA",    "CatA",    "CatA"    ],
            "bid_amount":          [90.0,      95.0,      50.0      ],
            "capacity_units":      [10,        10,        5         ],
            "contract_status":     ["active",  "active",  "inactive"],
            "bid_year":            [2020,      2021,      2021      ],
            "accreditation_status":["accredited"]*3,
            "surety_bond_status":  ["active"]*3,
        })
        result = identify_access_reduction_patterns(claims, bids)
        row = result[(result["cba_id"] == "CBA1") & (result["year"] == 2021)]
        assert len(row) == 1
        # Active count 2020=1, 2021=1 (S2 excluded) -> no decrease -> utilization_shift
        assert row["access_pattern"].iloc[0] == "utilization_shift"

    def test_year_column_contains_only_claim_years_from_input(self):
        self._req()
        claims, bids = self._make_data()
        result = identify_access_reduction_patterns(claims, bids)
        valid_years = set(claims["claim_year"].tolist())
        for yr in result["year"]:
            assert yr in valid_years


# ---------------------------------------------------------------------------
# Tests: attribute_health_equity_impact
# ---------------------------------------------------------------------------

class TestAttributeHealthEquityImpact:

    def _req(self):
        if not _EQUITY_OK:
            pytest.fail("equity_analyzer.py could not be imported")

    def test_output_is_dataframe_with_required_columns(self, access_patterns_df, cba_classifications, beneficiary_enrollment):
        self._req()
        result = attribute_health_equity_impact(access_patterns_df, cba_classifications, beneficiary_enrollment)
        assert isinstance(result, pd.DataFrame)
        required = {"cba_id","year","access_pattern","dual_eligible_count","non_dual_eligible_count","rural_frontier_proportion"}
        assert required.issubset(set(result.columns))

    def test_one_row_per_cba_year(self, access_patterns_df, cba_classifications, beneficiary_enrollment):
        self._req()
        result = attribute_health_equity_impact(access_patterns_df, cba_classifications, beneficiary_enrollment)
        assert result[["cba_id","year"]].drop_duplicates().shape[0] == len(result)

    def test_dual_eligible_count_uses_unique_beneficiaries_not_join_records(self, cba_classifications, beneficiary_enrollment):
        self._req()
        # Two hcpcs_codes for the same (CBA1, 2021) -> beneficiaries B1/B2 would appear twice without dedup
        aps = pd.DataFrame({
            "cba_id":         ["CBA1","CBA1"],
            "hcpcs_code":     ["H001","H002"],
            "year":           [2021,  2021  ],
            "access_pattern": ["contract_attrition","contract_attrition"],
            "mean_oop_cost_share":[10.0,10.0],
        })
        result = attribute_health_equity_impact(aps, cba_classifications, beneficiary_enrollment)
        row = result[result["cba_id"] == "CBA1"]
        assert len(row) == 1
        # CBA1 has B1 (dual=1) and B2 (dual=0) - unique counts must be 1 each
        assert row["dual_eligible_count"].iloc[0] == 1
        assert row["non_dual_eligible_count"].iloc[0] == 1

    def test_non_dual_eligible_count_uses_unique_beneficiaries(self, cba_classifications, beneficiary_enrollment):
        self._req()
        aps = pd.DataFrame({
            "cba_id": ["CBA2"], "hcpcs_code": ["H001"],
            "year": [2021], "access_pattern": ["utilization_shift"],
            "mean_oop_cost_share": [8.0],
        })
        result = attribute_health_equity_impact(aps, cba_classifications, beneficiary_enrollment)
        row = result[result["cba_id"] == "CBA2"]
        assert row["non_dual_eligible_count"].iloc[0] == 1  # only B4 is non-dual in CBA2

    def test_rural_frontier_proportion_is_in_range_zero_to_one(self, access_patterns_df, cba_classifications, beneficiary_enrollment):
        self._req()
        result = attribute_health_equity_impact(access_patterns_df, cba_classifications, beneficiary_enrollment)
        assert (result["rural_frontier_proportion"] >= 0).all()
        assert (result["rural_frontier_proportion"] <= 1).all()

    def test_rural_flag_cba_yields_proportion_of_one(self, access_patterns_df, cba_classifications, beneficiary_enrollment):
        self._req()
        result = attribute_health_equity_impact(access_patterns_df, cba_classifications, beneficiary_enrollment)
        cba1_rows = result[result["cba_id"] == "CBA1"]
        assert len(cba1_rows) >= 1
        assert (cba1_rows["rural_frontier_proportion"] == 1.0).all()

    def test_non_rural_cba_uses_beneficiary_classification(self, access_patterns_df, cba_classifications, beneficiary_enrollment):
        self._req()
        result = attribute_health_equity_impact(access_patterns_df, cba_classifications, beneficiary_enrollment)
        # CBA2: rural_flag=0, frontier_flag=0; B3 and B4 are both urban -> proportion = 0.0 for all CBA2 rows
        cba2_rows = result[result["cba_id"] == "CBA2"]
        assert len(cba2_rows) >= 1
        assert (cba2_rows["rural_frontier_proportion"] == 0.0).all()

    def test_rural_beneficiary_counted_in_non_rural_cba(self, cba_classifications):
        self._req()
        # Non-rural CBA but with some individually rural beneficiaries
        bene = pd.DataFrame({
            "beneficiary_id":      ["B3","B4","B5"],
            "cba_id":              ["CBA2","CBA2","CBA2"],
            "dual_eligible":       [1,    0,    0    ],
            "rural_classification":["rural","rural","urban"],
        })
        aps = pd.DataFrame({
            "cba_id": ["CBA2"], "hcpcs_code": ["H001"],
            "year": [2021], "access_pattern": ["utilization_shift"],
            "mean_oop_cost_share": [8.0],
        })
        result = attribute_health_equity_impact(aps, cba_classifications, bene)
        row = result[result["cba_id"] == "CBA2"]
        assert len(row) == 1
        # 2 rural out of 3 total beneficiaries in CBA2
        assert abs(row["rural_frontier_proportion"].iloc[0] - 2/3) < 1e-6

    def test_frontier_flag_cba_yields_proportion_of_one(self):
        self._req()
        cba_class = pd.DataFrame({
            "cba_id":       ["CBA3"],
            "rural_flag":   [0     ],
            "frontier_flag":[1     ],
        })
        bene = pd.DataFrame({
            "beneficiary_id":      ["B10",   "B11"  ],
            "cba_id":              ["CBA3",  "CBA3" ],
            "dual_eligible":       [1,       0      ],
            "rural_classification":["urban", "urban"],
        })
        aps = pd.DataFrame({
            "cba_id":         ["CBA3"],
            "hcpcs_code":     ["H001"],
            "year":           [2021  ],
            "access_pattern": ["utilization_shift"],
            "mean_oop_cost_share": [8.0],
        })
        result = attribute_health_equity_impact(aps, cba_class, bene)
        row = result[result["cba_id"] == "CBA3"]
        assert len(row) == 1
        # frontier_flag=1 -> both urban beneficiaries count -> proportion = 2/2 = 1.0
        assert row["rural_frontier_proportion"].iloc[0] == 1.0

    def test_access_pattern_contract_attrition_takes_priority(self, cba_classifications, beneficiary_enrollment):
        self._req()
        # Mixed patterns in same (cba_id, year) -> contract_attrition wins
        aps = pd.DataFrame({
            "cba_id":         ["CBA1","CBA1"],
            "hcpcs_code":     ["H001","H002"],
            "year":           [2021,  2021  ],
            "access_pattern": ["contract_attrition","utilization_shift"],
            "mean_oop_cost_share":[10.0,8.0],
        })
        result = attribute_health_equity_impact(aps, cba_classifications, beneficiary_enrollment)
        row = result[result["cba_id"] == "CBA1"]
        assert len(row) == 1
        assert row["access_pattern"].iloc[0] == "contract_attrition"

    def test_access_pattern_utilization_shift_when_no_attrition(self, cba_classifications, beneficiary_enrollment):
        self._req()
        aps = pd.DataFrame({
            "cba_id":         ["CBA1","CBA1"],
            "hcpcs_code":     ["H001","H002"],
            "year":           [2021,  2021  ],
            "access_pattern": ["utilization_shift","utilization_shift"],
            "mean_oop_cost_share":[10.0,8.0],
        })
        result = attribute_health_equity_impact(aps, cba_classifications, beneficiary_enrollment)
        row = result[result["cba_id"] == "CBA1"]
        assert len(row) == 1
        assert row["access_pattern"].iloc[0] == "utilization_shift"


# ---------------------------------------------------------------------------
# Tests: generate_performance_report
# ---------------------------------------------------------------------------

class TestGeneratePerformanceReport:

    def _req(self):
        if not _REPORTER_OK:
            pytest.fail("reporter.py could not be imported")

    def test_returns_dict(self, output_dir, spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries):
        self._req()
        result = generate_performance_report(spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries)
        assert isinstance(result, dict)

    def test_dict_has_exactly_five_required_keys(self, output_dir, spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries):
        self._req()
        result = generate_performance_report(spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries)
        expected = {"single_payment_amounts","access_patterns","equity_impacts","lcd_determinations","contractor_inquiries"}
        assert set(result.keys()) == expected

    def test_all_values_are_list_of_dicts(self, output_dir, spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries):
        self._req()
        result = generate_performance_report(spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries)
        for key, val in result.items():
            assert isinstance(val, list), f"Key '{key}' value is not a list"
            for item in val:
                assert isinstance(item, dict), f"Item in '{key}' is not a dict"

    def test_each_section_row_count_matches_input_dataframe(self, output_dir, spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries):
        self._req()
        result = generate_performance_report(spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries)
        assert len(result["single_payment_amounts"]) == len(spa_estimates)
        assert len(result["access_patterns"]) == len(access_patterns_df)
        assert len(result["equity_impacts"]) == len(equity_impacts)
        assert len(result["lcd_determinations"]) == len(lcd_data)
        assert len(result["contractor_inquiries"]) == len(contractor_inquiries)

    def test_writes_performance_report_json(self, output_dir, spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries):
        self._req()
        generate_performance_report(spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries)
        assert (output_dir / "outputs" / "performance_report.json").exists()

    def test_performance_report_dict_values_contain_input_dataframe_columns_as_keys(self, output_dir, spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries):
        self._req()
        result = generate_performance_report(spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries)
        # Each section's dicts must expose the columns of the corresponding input DataFrame as dict keys
        assert all(set(spa_estimates.columns).issubset(set(d.keys())) for d in result["single_payment_amounts"])
        assert all(set(access_patterns_df.columns).issubset(set(d.keys())) for d in result["access_patterns"])
        assert all(set(equity_impacts.columns).issubset(set(d.keys())) for d in result["equity_impacts"])
        assert all(set(lcd_data.columns).issubset(set(d.keys())) for d in result["lcd_determinations"])
        assert all(set(contractor_inquiries.columns).issubset(set(d.keys())) for d in result["contractor_inquiries"])

    def test_performance_report_json_is_valid_json(self, output_dir, spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries):
        self._req()
        generate_performance_report(spa_estimates, access_patterns_df, equity_impacts, lcd_data, contractor_inquiries)
        with open(output_dir / "outputs" / "performance_report.json") as f:
            data = json.load(f)
        assert isinstance(data, dict)
        assert set(data.keys()) == {"single_payment_amounts","access_patterns","equity_impacts","lcd_determinations","contractor_inquiries"}


# ---------------------------------------------------------------------------
# Tests: generate_recommendation_packet
# ---------------------------------------------------------------------------

class TestGenerateRecommendationPacket:

    def _req(self):
        if not _REPORTER_OK:
            pytest.fail("reporter.py could not be imported")

    def test_returns_dict_with_required_keys(self, output_dir, spa_estimates, access_patterns_df, gap_fill_pricing):
        self._req()
        result = generate_recommendation_packet(spa_estimates, access_patterns_df, gap_fill_pricing)
        assert isinstance(result, dict)
        assert set(result.keys()) == {"bid_limits","gap_fill_recommendations"}

    def test_bid_limits_dicts_have_required_keys(self, output_dir, spa_estimates, access_patterns_df, gap_fill_pricing):
        self._req()
        result = generate_recommendation_packet(spa_estimates, access_patterns_df, gap_fill_pricing)
        required = {"cba_id","hcpcs_code","product_category","round","recommended_bid_limit"}
        for item in result["bid_limits"]:
            assert required.issubset(set(item.keys()))

    def test_contract_attrition_applies_1_15_multiplier(self, output_dir, gap_fill_pricing):
        self._req()
        spa = pd.DataFrame({
            "cba_id": ["CBA1"], "hcpcs_code": ["H001"],
            "product_category": ["CatA"], "round": [2], "estimated_spa": [100.0],
        })
        aps = pd.DataFrame({
            "cba_id": ["CBA1"], "hcpcs_code": ["H001"], "year": [2021],
            "access_pattern": ["contract_attrition"], "mean_oop_cost_share": [10.0],
        })
        result = generate_recommendation_packet(spa, aps, gap_fill_pricing)
        assert result["bid_limits"][0]["recommended_bid_limit"] == round(100.0 * 1.15, 2)

    def test_non_attrition_applies_1_10_multiplier(self, output_dir, gap_fill_pricing):
        self._req()
        spa = pd.DataFrame({
            "cba_id": ["CBA2"], "hcpcs_code": ["H001"],
            "product_category": ["CatA"], "round": [1], "estimated_spa": [100.0],
        })
        aps = pd.DataFrame({
            "cba_id": ["CBA2"], "hcpcs_code": ["H001"], "year": [2021],
            "access_pattern": ["utilization_shift"], "mean_oop_cost_share": [8.0],
        })
        result = generate_recommendation_packet(spa, aps, gap_fill_pricing)
        assert result["bid_limits"][0]["recommended_bid_limit"] == round(100.0 * 1.10, 2)

    def test_no_access_pattern_match_applies_1_10_multiplier(self, output_dir, gap_fill_pricing):
        self._req()
        # (CBA3, H001) not present in access_patterns at all -> 1.10
        spa = pd.DataFrame({
            "cba_id": ["CBA3"], "hcpcs_code": ["H001"],
            "product_category": ["CatA"], "round": [1], "estimated_spa": [100.0],
        })
        aps = pd.DataFrame({
            "cba_id": ["CBA1"], "hcpcs_code": ["H001"], "year": [2021],
            "access_pattern": ["contract_attrition"], "mean_oop_cost_share": [10.0],
        })
        result = generate_recommendation_packet(spa, aps, gap_fill_pricing)
        assert result["bid_limits"][0]["recommended_bid_limit"] == round(100.0 * 1.10, 2)

    def test_recommended_bid_limit_is_rounded_to_two_decimal_places(self, output_dir, gap_fill_pricing):
        self._req()
        spa = pd.DataFrame({
            "cba_id": ["CBA1"], "hcpcs_code": ["H001"],
            "product_category": ["CatA"], "round": [1], "estimated_spa": [99.999],
        })
        aps = pd.DataFrame({
            "cba_id": ["CBA1"], "hcpcs_code": ["H001"], "year": [2021],
            "access_pattern": ["utilization_shift"], "mean_oop_cost_share": [10.0],
        })
        result = generate_recommendation_packet(spa, aps, gap_fill_pricing)
        val = result["bid_limits"][0]["recommended_bid_limit"]
        assert val == round(val, 2)

    def test_all_spa_rows_produce_a_bid_limit_entry(self, output_dir, spa_estimates, access_patterns_df, gap_fill_pricing):
        self._req()
        result = generate_recommendation_packet(spa_estimates, access_patterns_df, gap_fill_pricing)
        assert len(result["bid_limits"]) == len(spa_estimates)

    def test_gap_fill_recommendations_dicts_have_required_keys(self, output_dir, spa_estimates, access_patterns_df, gap_fill_pricing):
        self._req()
        result = generate_recommendation_packet(spa_estimates, access_patterns_df, gap_fill_pricing)
        required = {"hcpcs_code","cba_id","gap_fill_amount","methodology"}
        for item in result["gap_fill_recommendations"]:
            assert required.issubset(set(item.keys()))

    def test_gap_fill_recommendations_row_count_matches_input(self, output_dir, spa_estimates, access_patterns_df, gap_fill_pricing):
        self._req()
        result = generate_recommendation_packet(spa_estimates, access_patterns_df, gap_fill_pricing)
        assert len(result["gap_fill_recommendations"]) == len(gap_fill_pricing)

    def test_writes_recommendation_packet_json(self, output_dir, spa_estimates, access_patterns_df, gap_fill_pricing):
        self._req()
        generate_recommendation_packet(spa_estimates, access_patterns_df, gap_fill_pricing)
        assert (output_dir / "outputs" / "recommendation_packet.json").exists()

    def test_recommendation_packet_json_is_valid_json(self, output_dir, spa_estimates, access_patterns_df, gap_fill_pricing):
        self._req()
        generate_recommendation_packet(spa_estimates, access_patterns_df, gap_fill_pricing)
        with open(output_dir / "outputs" / "recommendation_packet.json") as f:
            data = json.load(f)
        assert isinstance(data, dict)
        assert set(data.keys()) == {"bid_limits","gap_fill_recommendations"}


# ---------------------------------------------------------------------------
# Tests: run_pipeline
# ---------------------------------------------------------------------------

class TestRunPipeline:

    def _req(self):
        if not _PIPELINE_OK:
            pytest.fail("pipeline.py could not be imported")

    def test_returns_dict(self, pipeline_dir):
        self._req()
        result = run_pipeline("data/")
        assert isinstance(result, dict)

    def test_returns_all_six_required_keys(self, pipeline_dir):
        self._req()
        result = run_pipeline("data/")
        expected = {
            "single_payment_amounts","access_patterns","equity_impacts",
            "lcd_determinations","contractor_inquiries","recommendations",
        }
        assert set(result.keys()) == expected

    def test_first_five_values_are_list_of_dicts(self, pipeline_dir):
        self._req()
        result = run_pipeline("data/")
        for key in ["single_payment_amounts","access_patterns","equity_impacts","lcd_determinations","contractor_inquiries"]:
            assert isinstance(result[key], list), f"result['{key}'] is not a list"
            for item in result[key]:
                assert isinstance(item, dict), f"item in result['{key}'] is not a dict"

    def test_recommendations_is_dict_with_bid_limits_and_gap_fill(self, pipeline_dir):
        self._req()
        result = run_pipeline("data/")
        assert isinstance(result["recommendations"], dict)
        assert set(result["recommendations"].keys()) == {"bid_limits","gap_fill_recommendations"}

    def test_performance_report_json_written(self, pipeline_dir):
        self._req()
        run_pipeline("data/")
        assert (pipeline_dir / "outputs" / "performance_report.json").exists()

    def test_recommendation_packet_json_written(self, pipeline_dir):
        self._req()
        run_pipeline("data/")
        assert (pipeline_dir / "outputs" / "recommendation_packet.json").exists()

    def test_single_payment_amounts_is_non_empty(self, pipeline_dir):
        self._req()
        result = run_pipeline("data/")
        assert len(result["single_payment_amounts"]) > 0

    def test_bid_limits_contain_required_keys(self, pipeline_dir):
        self._req()
        result = run_pipeline("data/")
        required = {"cba_id","hcpcs_code","product_category","round","recommended_bid_limit"}
        for item in result["recommendations"]["bid_limits"]:
            assert required.issubset(set(item.keys()))


# ---------------------------------------------------------------------------
# Tests: bundled data files (functional schema and cardinality checks)
# ---------------------------------------------------------------------------

def _load_bundled(filename):
    """Load a bundled CSV from data/; pytest.fail gracefully if absent."""
    path = _PARENT_DIR / "data" / filename
    try:
        return pd.read_csv(path)
    except FileNotFoundError:
        pytest.fail(f"data/{filename} not found")


class TestBundledDataFiles:
    """
    Functional tests that load the actual bundled CSV files and assert their
    data contracts. On an empty repository every test fails via pytest.fail,
    not via an unhandled exception.
    """

    # --- cba_pricing.csv ---

    def test_cba_pricing_has_required_columns(self):
        df = _load_bundled("cba_pricing.csv")
        assert {"cba_id", "hcpcs_code", "round", "payment_amount"}.issubset(set(df.columns))

    def test_cba_pricing_has_10_distinct_round_values(self):
        df = _load_bundled("cba_pricing.csv")
        assert df["round"].nunique() == 10

    def test_cba_pricing_has_5_distinct_cba_id_values(self):
        df = _load_bundled("cba_pricing.csv")
        assert df["cba_id"].nunique() == 5

    def test_cba_pricing_covers_every_supplier_bids_combination(self):
        pricing = _load_bundled("cba_pricing.csv")
        bids = _load_bundled("supplier_bids.csv")
        bid_combos = set(zip(bids["cba_id"], bids["hcpcs_code"]))
        pricing_combos = set(zip(pricing["cba_id"], pricing["hcpcs_code"]))
        assert bid_combos.issubset(pricing_combos)

    # --- supplier_bids.csv ---

    def test_supplier_bids_has_required_columns(self):
        df = _load_bundled("supplier_bids.csv")
        required = {"supplier_id","cba_id","hcpcs_code","product_category","bid_amount",
                    "capacity_units","contract_status","bid_year","accreditation_status","surety_bond_status"}
        assert required.issubset(set(df.columns))

    def test_supplier_bids_has_10_distinct_bid_year_values(self):
        df = _load_bundled("supplier_bids.csv")
        assert df["bid_year"].nunique() == 10

    def test_supplier_bids_has_5_distinct_cba_id_values(self):
        df = _load_bundled("supplier_bids.csv")
        assert df["cba_id"].nunique() == 5

    def test_supplier_bids_has_3_distinct_hcpcs_code_values(self):
        df = _load_bundled("supplier_bids.csv")
        assert df["hcpcs_code"].nunique() == 3

    def test_supplier_bids_has_4_distinct_supplier_id_values(self):
        df = _load_bundled("supplier_bids.csv")
        assert df["supplier_id"].nunique() == 4

    def test_supplier_bids_contains_active_contract_status_rows(self):
        df = _load_bundled("supplier_bids.csv")
        assert (df["contract_status"] == "active").any()

    def test_supplier_bids_contains_accredited_rows(self):
        df = _load_bundled("supplier_bids.csv")
        assert (df["accreditation_status"] == "accredited").any()

    def test_supplier_bids_contains_active_surety_bond_rows(self):
        df = _load_bundled("supplier_bids.csv")
        assert (df["surety_bond_status"] == "active").any()

    def test_supplier_bids_product_category_invariant_within_cba_hcpcs(self):
        df = _load_bundled("supplier_bids.csv")
        counts = df.groupby(["cba_id", "hcpcs_code"])["product_category"].nunique()
        assert (counts == 1).all()

    # --- claims.csv ---

    def test_claims_has_required_columns(self):
        df = _load_bundled("claims.csv")
        assert {"cba_id","beneficiary_id","hcpcs_code","claim_year","claim_count","oop_cost_share"}.issubset(set(df.columns))

    def test_claims_has_10_distinct_claim_year_values(self):
        df = _load_bundled("claims.csv")
        assert df["claim_year"].nunique() == 10

    def test_claims_has_5_distinct_cba_id_values(self):
        df = _load_bundled("claims.csv")
        assert df["cba_id"].nunique() == 5

    def test_bundled_data_produces_contract_attrition_rows(self):
        if not _ACCESS_OK:
            pytest.fail("access_analyzer.py could not be imported")
        claims = _load_bundled("claims.csv")
        bids = _load_bundled("supplier_bids.csv")
        result = identify_access_reduction_patterns(claims, bids)
        assert (result["access_pattern"] == "contract_attrition").any()

    def test_bundled_data_produces_utilization_shift_rows(self):
        if not _ACCESS_OK:
            pytest.fail("access_analyzer.py could not be imported")
        claims = _load_bundled("claims.csv")
        bids = _load_bundled("supplier_bids.csv")
        result = identify_access_reduction_patterns(claims, bids)
        assert (result["access_pattern"] == "utilization_shift").any()

    # --- beneficiary.csv ---

    def test_beneficiary_has_required_columns(self):
        df = _load_bundled("beneficiary.csv")
        assert {"beneficiary_id","cba_id","dual_eligible","rural_classification"}.issubset(set(df.columns))

    def test_beneficiary_contains_both_dual_eligible_values(self):
        df = _load_bundled("beneficiary.csv")
        assert set(df["dual_eligible"].unique()).issuperset({0, 1})

    def test_beneficiary_contains_rural_classification_rows(self):
        df = _load_bundled("beneficiary.csv")
        assert (df["rural_classification"] == "rural").any()

    # --- cba_classification.csv ---

    def test_cba_classification_has_required_columns(self):
        df = _load_bundled("cba_classification.csv")
        assert {"cba_id","rural_flag","frontier_flag"}.issubset(set(df.columns))

    def test_cba_classification_has_one_row_per_cba_id(self):
        df = _load_bundled("cba_classification.csv")
        assert df["cba_id"].nunique() == len(df)

    def test_cba_classification_rural_flag_is_binary(self):
        df = _load_bundled("cba_classification.csv")
        assert set(df["rural_flag"].unique()).issuperset({0, 1})

    def test_cba_classification_frontier_flag_is_binary(self):
        df = _load_bundled("cba_classification.csv")
        assert set(df["frontier_flag"].unique()).issuperset({0, 1})

    # --- gap_fill_pricing.csv ---

    def test_gap_fill_pricing_has_required_columns(self):
        df = _load_bundled("gap_fill_pricing.csv")
        assert {"hcpcs_code","cba_id","gap_fill_amount","methodology"}.issubset(set(df.columns))

    def test_gap_fill_pricing_covers_same_hcpcs_codes_as_supplier_bids(self):
        gf = _load_bundled("gap_fill_pricing.csv")
        bids = _load_bundled("supplier_bids.csv")
        assert set(bids["hcpcs_code"].unique()).issubset(set(gf["hcpcs_code"].unique()))

    def test_gap_fill_pricing_covers_same_cba_ids_as_supplier_bids(self):
        gf = _load_bundled("gap_fill_pricing.csv")
        bids = _load_bundled("supplier_bids.csv")
        assert set(bids["cba_id"].unique()).issubset(set(gf["cba_id"].unique()))

    # --- lcd_data.csv ---

    def test_lcd_data_has_required_columns(self):
        df = _load_bundled("lcd_data.csv")
        assert {"cba_id","hcpcs_code","determination_year","coverage_status"}.issubset(set(df.columns))

    def test_lcd_data_covers_same_hcpcs_codes_as_supplier_bids(self):
        lcd = _load_bundled("lcd_data.csv")
        bids = _load_bundled("supplier_bids.csv")
        assert set(bids["hcpcs_code"].unique()).issubset(set(lcd["hcpcs_code"].unique()))

    def test_lcd_data_covers_same_cba_ids_as_supplier_bids(self):
        lcd = _load_bundled("lcd_data.csv")
        bids = _load_bundled("supplier_bids.csv")
        assert set(bids["cba_id"].unique()).issubset(set(lcd["cba_id"].unique()))

    # --- contractor_inquiries.csv ---

    def test_contractor_inquiries_has_required_columns(self):
        df = _load_bundled("contractor_inquiries.csv")
        assert {"cba_id","hcpcs_code","inquiry_year","inquiry_count","resolution_status"}.issubset(set(df.columns))

    def test_contractor_inquiries_covers_same_hcpcs_codes_as_supplier_bids(self):
        inq = _load_bundled("contractor_inquiries.csv")
        bids = _load_bundled("supplier_bids.csv")
        assert set(bids["hcpcs_code"].unique()).issubset(set(inq["hcpcs_code"].unique()))

    def test_contractor_inquiries_covers_same_cba_ids_as_supplier_bids(self):
        inq = _load_bundled("contractor_inquiries.csv")
        bids = _load_bundled("supplier_bids.csv")
        assert set(bids["cba_id"].unique()).issubset(set(inq["cba_id"].unique()))

    # --- numeric column dtype checks (one test per file) ---

    def test_cba_pricing_numeric_column_dtypes(self):
        df = _load_bundled("cba_pricing.csv")
        assert pd.api.types.is_integer_dtype(df["round"]), "round must be int"
        assert pd.api.types.is_float_dtype(df["payment_amount"]), "payment_amount must be float"

    def test_supplier_bids_numeric_column_dtypes(self):
        df = _load_bundled("supplier_bids.csv")
        assert pd.api.types.is_float_dtype(df["bid_amount"]), "bid_amount must be float"
        assert pd.api.types.is_integer_dtype(df["capacity_units"]), "capacity_units must be int"
        assert pd.api.types.is_integer_dtype(df["bid_year"]), "bid_year must be int"

    def test_claims_numeric_column_dtypes(self):
        df = _load_bundled("claims.csv")
        assert pd.api.types.is_integer_dtype(df["claim_year"]), "claim_year must be int"
        assert pd.api.types.is_integer_dtype(df["claim_count"]), "claim_count must be int"
        assert pd.api.types.is_float_dtype(df["oop_cost_share"]), "oop_cost_share must be float"

    def test_beneficiary_numeric_column_dtypes(self):
        df = _load_bundled("beneficiary.csv")
        assert pd.api.types.is_integer_dtype(df["dual_eligible"]), "dual_eligible must be int"

    def test_cba_classification_numeric_column_dtypes(self):
        df = _load_bundled("cba_classification.csv")
        assert pd.api.types.is_integer_dtype(df["rural_flag"]), "rural_flag must be int"
        assert pd.api.types.is_integer_dtype(df["frontier_flag"]), "frontier_flag must be int"

    def test_gap_fill_pricing_numeric_column_dtypes(self):
        df = _load_bundled("gap_fill_pricing.csv")
        assert pd.api.types.is_float_dtype(df["gap_fill_amount"]), "gap_fill_amount must be float"

    def test_lcd_data_numeric_column_dtypes(self):
        df = _load_bundled("lcd_data.csv")
        assert pd.api.types.is_integer_dtype(df["determination_year"]), "determination_year must be int"

    def test_contractor_inquiries_numeric_column_dtypes(self):
        df = _load_bundled("contractor_inquiries.csv")
        assert pd.api.types.is_integer_dtype(df["inquiry_year"]), "inquiry_year must be int"
        assert pd.api.types.is_integer_dtype(df["inquiry_count"]), "inquiry_count must be int"

    # --- string column dtype checks (one test per file) ---

    def test_cba_pricing_string_column_dtypes(self):
        df = _load_bundled("cba_pricing.csv")
        for col in ["cba_id", "hcpcs_code"]:
            assert df[col].apply(lambda x: isinstance(x, str)).all(), f"{col} must contain str values"

    def test_supplier_bids_string_column_dtypes(self):
        df = _load_bundled("supplier_bids.csv")
        for col in ["supplier_id", "cba_id", "hcpcs_code", "product_category",
                    "contract_status", "accreditation_status", "surety_bond_status"]:
            assert df[col].apply(lambda x: isinstance(x, str)).all(), f"{col} must contain str values"

    def test_claims_string_column_dtypes(self):
        df = _load_bundled("claims.csv")
        for col in ["cba_id", "beneficiary_id", "hcpcs_code"]:
            assert df[col].apply(lambda x: isinstance(x, str)).all(), f"{col} must contain str values"

    def test_beneficiary_string_column_dtypes(self):
        df = _load_bundled("beneficiary.csv")
        for col in ["beneficiary_id", "cba_id", "rural_classification"]:
            assert df[col].apply(lambda x: isinstance(x, str)).all(), f"{col} must contain str values"

    def test_cba_classification_string_column_dtypes(self):
        df = _load_bundled("cba_classification.csv")
        assert df["cba_id"].apply(lambda x: isinstance(x, str)).all(), "cba_id must contain str values"

    def test_gap_fill_pricing_string_column_dtypes(self):
        df = _load_bundled("gap_fill_pricing.csv")
        for col in ["hcpcs_code", "cba_id", "methodology"]:
            assert df[col].apply(lambda x: isinstance(x, str)).all(), f"{col} must contain str values"

    def test_lcd_data_string_column_dtypes(self):
        df = _load_bundled("lcd_data.csv")
        for col in ["cba_id", "hcpcs_code", "coverage_status"]:
            assert df[col].apply(lambda x: isinstance(x, str)).all(), f"{col} must contain str values"

    def test_contractor_inquiries_string_column_dtypes(self):
        df = _load_bundled("contractor_inquiries.csv")
        for col in ["cba_id", "hcpcs_code", "resolution_status"]:
            assert df[col].apply(lambda x: isinstance(x, str)).all(), f"{col} must contain str values"


# ---------------------------------------------------------------------------
# Tests: CLI entry point (pipeline.py module-level execution)
# ---------------------------------------------------------------------------

class TestCLIEntryPoint:

    def test_cli_exits_cleanly_with_valid_data(self, pipeline_dir):
        if not _PIPELINE_OK:
            pytest.fail("pipeline.py could not be imported")
        pipeline_script = _PARENT_DIR / "pipeline.py"
        if not pipeline_script.exists():
            pytest.fail("pipeline.py does not exist at expected location")
        result = subprocess.run(
            [sys.executable, str(pipeline_script)],
            capture_output=True, timeout=120,
        )
        assert result.returncode == 0, (
            f"pipeline.py exited with code {result.returncode}.\n"
            f"stderr: {result.stderr.decode()}"
        )

    def test_cli_creates_both_output_files(self, pipeline_dir):
        if not _PIPELINE_OK:
            pytest.fail("pipeline.py could not be imported")
        pipeline_script = _PARENT_DIR / "pipeline.py"
        if not pipeline_script.exists():
            pytest.fail("pipeline.py does not exist at expected location")
        subprocess.run([sys.executable, str(pipeline_script)], capture_output=True, timeout=120)
        assert (pipeline_dir / "outputs" / "performance_report.json").exists()
        assert (pipeline_dir / "outputs" / "recommendation_packet.json").exists()