import pytest
import math
import pandas as pd
from math import prod


def _check(*vals):
    for v in vals:
        if v is None:
            pytest.fail("Required function not importable from pipeline module")


def test_load_receipts_columns(loaded_receipts):
    _check(loaded_receipts)
    expected = {"isbn", "store", "price", "arrival_date", "sell_date"}
    assert set(loaded_receipts.columns) == expected


def test_load_receipts_column_dtypes(loaded_receipts):
    _check(loaded_receipts)
    assert pd.api.types.is_string_dtype(loaded_receipts["isbn"]) or \
           loaded_receipts["isbn"].dtype == object, "isbn must be string dtype"
    assert pd.api.types.is_string_dtype(loaded_receipts["store"]) or \
           loaded_receipts["store"].dtype == object, "store must be string dtype"
    assert pd.api.types.is_float_dtype(loaded_receipts["price"]), \
        "price must be float dtype"


def test_load_receipts_datetime_types(loaded_receipts):
    _check(loaded_receipts)
    assert pd.api.types.is_datetime64_any_dtype(loaded_receipts["arrival_date"])
    assert pd.api.types.is_datetime64_any_dtype(loaded_receipts["sell_date"])


def test_load_receipts_nat_for_unsold(loaded_receipts, receipts_path):
    _check(loaded_receipts)
    raw = pd.read_csv(receipts_path, keep_default_na=False)
    expected_nat_count = (raw["sell_date"].str.strip() == "").sum()
    actual_nat_count = loaded_receipts["sell_date"].isna().sum()
    assert actual_nat_count > 0, "There should be on-hand items with NaT sell_date"
    assert actual_nat_count == expected_nat_count, (
        f"Expected {expected_nat_count} NaT sell_date rows (empty strings in CSV), "
        f"got {actual_nat_count}"
    )


@pytest.mark.parametrize("missing_col,remaining_cols,row", [
    ("sell_date",    "isbn,store,price,arrival_date",           "A,B,10.0,2023-01-01"),
    ("isbn",         "store,price,arrival_date,sell_date",      "B,10.0,2023-01-01,2023-06-01"),
    ("store",        "isbn,price,arrival_date,sell_date",       "A,10.0,2023-01-01,2023-06-01"),
    ("price",        "isbn,store,arrival_date,sell_date",       "A,B,2023-01-01,2023-06-01"),
    ("arrival_date", "isbn,store,price,sell_date",              "A,B,10.0,2023-06-01"),
])
def test_load_receipts_missing_column_raises_valueerror(fn_load, tmp_path, missing_col, remaining_cols, row):
    _check(fn_load)
    csv_path = tmp_path / f"bad_receipts_no_{missing_col}.csv"
    csv_path.write_text(f"{remaining_cols}\n{row}\n")
    with pytest.raises(ValueError):
        fn_load(str(csv_path))


def test_fit_curves_params_columns(curve_params):
    _check(curve_params)
    expected = {"isbn", "store", "weibull_shape", "weibull_scale", "store_factor"}
    assert set(curve_params.columns) == expected


def test_fit_curves_params_str_dtypes(curve_params):
    _check(curve_params)
    assert pd.api.types.is_string_dtype(curve_params["isbn"]) or \
           curve_params["isbn"].dtype == object, "isbn must be string dtype"
    assert pd.api.types.is_string_dtype(curve_params["store"]) or \
           curve_params["store"].dtype == object, "store must be string dtype"


def test_fit_curves_seasonal_columns(seasonal_multipliers):
    _check(seasonal_multipliers)
    expected = {"month", "multiplier"}
    assert set(seasonal_multipliers.columns) == expected


def test_fit_curves_one_row_per_isbn_store(loaded_receipts, curve_params):
    _check(loaded_receipts, curve_params)
    expected_combos = loaded_receipts.groupby(["isbn", "store"]).ngroups
    assert len(curve_params) == expected_combos


def test_fit_curves_shape_scale_same_per_isbn(curve_params):
    _check(curve_params)
    for isbn, group in curve_params.groupby("isbn"):
        assert group["weibull_shape"].nunique() == 1, f"weibull_shape must be identical for isbn {isbn}"
        assert group["weibull_scale"].nunique() == 1, f"weibull_scale must be identical for isbn {isbn}"


def test_fit_curves_store_factor_same_per_store(curve_params):
    _check(curve_params)
    for store, group in curve_params.groupby("store"):
        assert group["store_factor"].nunique() == 1, (
            f"store_factor must be identical for all rows of store {store!r}; "
            f"store_factor is a per-store property, not per-(isbn, store)"
        )


def test_fit_curves_seasonal_structure(seasonal_multipliers):
    _check(seasonal_multipliers)
    assert len(seasonal_multipliers) == 12
    assert set(seasonal_multipliers["month"]) == set(range(1, 13))


def test_fit_curves_seasonal_dtypes(seasonal_multipliers):
    _check(seasonal_multipliers)
    assert pd.api.types.is_integer_dtype(seasonal_multipliers["month"]), \
        "month column must be integer dtype"
    assert pd.api.types.is_float_dtype(seasonal_multipliers["multiplier"]), \
        "multiplier column must be float dtype"


def test_fit_curves_seasonal_multiplier_computation(loaded_receipts, seasonal_multipliers):
    _check(loaded_receipts, seasonal_multipliers)
    sold = loaded_receipts[loaded_receipts["sell_date"].notna()]
    monthly_counts = sold["sell_date"].dt.month.value_counts().reindex(range(1, 13), fill_value=0)
    mean_count = monthly_counts.mean()
    for _, row in seasonal_multipliers.iterrows():
        month = int(row["month"])
        expected = monthly_counts[month] / mean_count
        assert row["multiplier"] == pytest.approx(expected, rel=1e-6), (
            f"Seasonal multiplier for month {month} does not match expected value"
        )


def test_fit_curves_weibull_params_positive(curve_params):
    _check(curve_params)
    assert (curve_params["weibull_shape"] > 0).all()
    assert (curve_params["weibull_scale"] > 0).all()


def test_fit_curves_store_factor_computation(loaded_receipts, curve_params):
    _check(loaded_receipts, curve_params)
    sold = loaded_receipts[loaded_receipts["sell_date"].notna()].copy()
    sold["sell_through"] = (sold["sell_date"] - sold["arrival_date"]).dt.days
    global_median = sold["sell_through"].median()
    for store in sold["store"].unique():
        store_median = sold[sold["store"] == store]["sell_through"].median()
        expected_factor = store_median / global_median
        actual_factor = curve_params[curve_params["store"] == store]["store_factor"].iloc[0]
        assert actual_factor == pytest.approx(expected_factor, rel=1e-6), (
            f"store_factor for {store} does not match expected ratio"
        )


def test_fit_curves_per_title_fit_for_sufficient_isbn(fn_fit):
    _check(fn_fit)
    rows = []
    for k in range(5):
        arrival = pd.Timestamp("2023-01-01") + pd.Timedelta(days=k * 30)
        rows.append({
            "isbn": "FAST_ISBN", "store": "StoreA", "price": 10.0,
            "arrival_date": arrival, "sell_date": arrival + pd.Timedelta(days=10 + k),
        })
    for k in range(5):
        arrival = pd.Timestamp("2022-06-01") + pd.Timedelta(days=k * 30)
        rows.append({
            "isbn": "SLOW_ISBN", "store": "StoreA", "price": 10.0,
            "arrival_date": arrival, "sell_date": arrival + pd.Timedelta(days=200 + k * 10),
        })
    df = pd.DataFrame(rows)
    cp, _ = fn_fit(df)
    fast_row = cp[cp["isbn"] == "FAST_ISBN"].iloc[0]
    slow_row = cp[cp["isbn"] == "SLOW_ISBN"].iloc[0]
    assert fast_row["weibull_shape"] > 0
    assert fast_row["weibull_scale"] > 0
    assert slow_row["weibull_shape"] > 0
    assert slow_row["weibull_scale"] > 0
    # Compare implied medians: scale * (ln2)^(1/shape)
    # This is parameterization-agnostic and directly measures sell-through speed
    fast_median = fast_row["weibull_scale"] * (math.log(2) ** (1 / fast_row["weibull_shape"]))
    slow_median = slow_row["weibull_scale"] * (math.log(2) ** (1 / slow_row["weibull_shape"]))
    assert fast_median < slow_median, (
        "FAST_ISBN (10-day sell-through) must have a smaller implied Weibull median "
        "than SLOW_ISBN (200+ day sell-through), regardless of parameterization"
    )


def test_fit_curves_fallback_for_sparse_isbn(fn_fit):
    _check(fn_fit)
    rows = []
    for k in range(7):
        arrival = pd.Timestamp("2022-06-01") + pd.Timedelta(days=k * 30)
        rows.append({
            "isbn": "DENSE_ISBN", "store": "StoreA", "price": 20.0,
            "arrival_date": arrival,
            "sell_date": arrival + pd.Timedelta(days=300 + k * 20),
        })
    for isbn_idx in range(3):
        isbn = f"SPARSE_ISBN_{isbn_idx}"
        for store in ["StoreA", "StoreB"]:
            for k in range(2):
                arrival = pd.Timestamp("2023-01-15") + pd.Timedelta(days=isbn_idx * 30 + k * 15)
                sell = arrival + pd.Timedelta(days=30 + k * 20 + isbn_idx * 10)
                rows.append({
                    "isbn": isbn, "store": store, "price": 15.0,
                    "arrival_date": arrival, "sell_date": sell,
                })
            rows.append({
                "isbn": isbn, "store": store, "price": 15.0,
                "arrival_date": pd.Timestamp("2023-06-01"), "sell_date": pd.NaT,
            })
    df = pd.DataFrame(rows)
    cp, _ = fn_fit(df)
    # All sparse ISBNs have < 5 sold observations and must share the same
    # global fallback parameters - implementation-agnostic assertion
    sparse_params = []
    for isbn_idx in range(3):
        isbn = f"SPARSE_ISBN_{isbn_idx}"
        row = cp[cp["isbn"] == isbn].iloc[0]
        assert row["weibull_shape"] > 0
        assert row["weibull_scale"] > 0
        sparse_params.append((row["weibull_shape"], row["weibull_scale"]))
    ref_shape, ref_scale = sparse_params[0]
    for shape, scale in sparse_params[1:]:
        assert shape == pytest.approx(ref_shape, rel=1e-9), (
            "All sparse ISBNs must share the same global fallback weibull_shape"
        )
        assert scale == pytest.approx(ref_scale, rel=1e-9), (
            "All sparse ISBNs must share the same global fallback weibull_scale"
        )


def test_predict_clearance_columns(clearance_predictions):
    _check(clearance_predictions)
    expected = {"isbn", "store", "days_on_hand", "predicted_days_to_clear"}
    assert set(clearance_predictions.columns) == expected
    assert pd.api.types.is_integer_dtype(clearance_predictions["days_on_hand"]), (
        "days_on_hand column must have an integer dtype"
    )
    assert pd.api.types.is_float_dtype(clearance_predictions["predicted_days_to_clear"]), \
    "predicted_days_to_clear must be float dtype"


def test_predict_clearance_str_dtypes(clearance_predictions):
    _check(clearance_predictions)
    assert pd.api.types.is_string_dtype(clearance_predictions["isbn"]) or \
           clearance_predictions["isbn"].dtype == object, "isbn must be string dtype"
    assert pd.api.types.is_string_dtype(clearance_predictions["store"]) or \
           clearance_predictions["store"].dtype == object, "store must be string dtype"


def test_predict_clearance_predicted_days_positive(clearance_predictions):
    _check(clearance_predictions)
    assert (clearance_predictions["predicted_days_to_clear"] > 0).all()


def test_predict_clearance_days_on_hand_correct(loaded_receipts, clearance_predictions):
    _check(loaded_receipts, clearance_predictions)
    onhand = loaded_receipts[loaded_receipts["sell_date"].isna()].copy()
    today = pd.Timestamp.now().normalize()
    expected_days = sorted((today - onhand["arrival_date"]).dt.days.astype(int).tolist())
    actual_days = sorted(clearance_predictions["days_on_hand"].astype(int).tolist())
    assert len(actual_days) == len(expected_days), "One row per on-hand item expected"
    for a, e in zip(actual_days, expected_days):
        assert abs(a - e) <= 1, (
            f"days_on_hand value {a} does not match expected {e} (tolerance ±1 day)"
        )


def test_predict_clearance_computation(fn_predict):
    _check(fn_predict)
    today = pd.Timestamp.now().normalize()
    arrival = today - pd.Timedelta(days=50)
    receipts = pd.DataFrame([{
        "isbn": "COMP_ISBN", "store": "COMP_STORE", "price": 20.0,
        "arrival_date": arrival, "sell_date": pd.NaT,
    }])
    shape, scale, sf = 2.0, 100.0, 1.5
    cp = pd.DataFrame([{
        "isbn": "COMP_ISBN", "store": "COMP_STORE",
        "weibull_shape": shape, "weibull_scale": scale, "store_factor": sf,
    }])
    current_month = today.month
    m = 1.5
    multipliers = [1.0] * 12
    multipliers[current_month - 1] = m
    sm = pd.DataFrame({"month": list(range(1, 13)), "multiplier": multipliers})
    result = fn_predict(receipts, cp, sm)
    assert len(result) == 1
    row = result.iloc[0]
    d = row["days_on_hand"]
    k = shape
    lam = scale * sf
    expected_r = (d ** k + lam ** k * math.log(2) / m) ** (1 / k) - d
    assert row["predicted_days_to_clear"] == pytest.approx(expected_r, rel=0.01)


def test_markdown_schedule_columns(markdown_schedule):
    _check(markdown_schedule)
    expected = {"isbn", "store", "week", "markdown_percentage", "new_price", "expected_revenue"}
    assert set(markdown_schedule.columns) == expected


def test_markdown_schedule_str_dtypes(markdown_schedule):
    _check(markdown_schedule)
    if markdown_schedule.empty:
        return
    assert pd.api.types.is_string_dtype(markdown_schedule["isbn"]) or \
           markdown_schedule["isbn"].dtype == object, "isbn must be string dtype"
    assert pd.api.types.is_string_dtype(markdown_schedule["store"]) or \
           markdown_schedule["store"].dtype == object, "store must be string dtype"


def test_markdown_schedule_float_dtypes(markdown_schedule):
    _check(markdown_schedule)
    if markdown_schedule.empty:
        return
    assert pd.api.types.is_float_dtype(markdown_schedule["new_price"]), \
        "new_price must be float dtype"
    assert pd.api.types.is_float_dtype(markdown_schedule["expected_revenue"]), \
        "expected_revenue must be float dtype"


def test_markdown_schedule_percentage_values(markdown_schedule):
    _check(markdown_schedule)
    if markdown_schedule.empty:
        return
    assert pd.api.types.is_integer_dtype(markdown_schedule["markdown_percentage"]), (
        "markdown_percentage column must have an integer dtype"
    )
    assert set(markdown_schedule["markdown_percentage"].unique()).issubset({10, 25, 50})


def test_markdown_schedule_week_range(markdown_schedule):
    _check(markdown_schedule)
    if markdown_schedule.empty:
        return
    assert pd.api.types.is_integer_dtype(markdown_schedule["week"]), (
        "week column must have an integer dtype"
    )
    assert (markdown_schedule["week"] >= 1).all()
    assert (markdown_schedule["week"] <= 52).all()


def test_markdown_schedule_max_three_per_combo(markdown_schedule):
    _check(markdown_schedule)
    if markdown_schedule.empty:
        return
    counts = markdown_schedule.groupby(["isbn", "store"]).size()
    assert (counts <= 3).all()


def test_markdown_schedule_unique_week_per_combo(markdown_schedule):
    _check(markdown_schedule)
    if markdown_schedule.empty:
        return
    dupes = markdown_schedule.groupby(["isbn", "store", "week"]).size()
    assert (dupes <= 1).all(), (
        "Each (isbn, store, week) combination must appear at most once; "
        "each output row represents one scheduled markdown action"
    )


def test_markdown_schedule_revenue_consistent_per_combo(markdown_schedule):
    _check(markdown_schedule)
    if markdown_schedule.empty:
        return
    for (isbn, store), group in markdown_schedule.groupby(["isbn", "store"]):
        assert group["expected_revenue"].nunique() == 1, (
            f"expected_revenue must be identical for all rows of ({isbn}, {store})"
        )


def test_markdown_schedule_compounding_prices(markdown_schedule):
    _check(markdown_schedule)
    if markdown_schedule.empty:
        return
    for (isbn, store), group in markdown_schedule.groupby(["isbn", "store"]):
        group = group.sort_values("week").reset_index(drop=True)
        if len(group) < 2:
            continue
        for i in range(1, len(group)):
            prev_price = group.loc[i - 1, "new_price"]
            pct = group.loc[i, "markdown_percentage"]
            expected_new = prev_price * (1 - pct / 100)
            assert group.loc[i, "new_price"] == pytest.approx(expected_new, rel=1e-4), (
                f"new_price for ({isbn}, {store}) at index {i} does not compound from previous new_price"
            )


def test_markdown_schedule_empty_for_no_onhand(fn_fit, fn_markdown):
    _check(fn_fit, fn_markdown)
    rows = []
    for isbn_idx in range(3):
        isbn = f"ALLSOLD_ISBN_{isbn_idx}"
        for store in ["StoreX", "StoreY"]:
            for k in range(10):
                arrival = pd.Timestamp("2023-01-15") + pd.Timedelta(days=k * 10)
                sell = arrival + pd.Timedelta(days=20 + k * 5)
                rows.append({
                    "isbn": isbn, "store": store, "price": 15.0,
                    "arrival_date": arrival, "sell_date": sell,
                })
    df = pd.DataFrame(rows)
    cp, sm = fn_fit(df)
    result = fn_markdown(df, cp, sm, 0.05, {"StoreX": 100, "StoreY": 100})
    assert isinstance(result, pd.DataFrame)
    assert len(result) == 0
    expected_cols = {"isbn", "store", "week", "markdown_percentage", "new_price", "expected_revenue"}
    assert set(result.columns) == expected_cols


def test_markdown_schedule_nonempty_when_holding_cost_dominates(fn_fit, fn_markdown):
    _check(fn_fit, fn_markdown)
    today = pd.Timestamp.now().normalize()
    rows = []
    for k in range(10):
        arrival = pd.Timestamp("2022-01-01") + pd.Timedelta(days=k * 30)
        rows.append({
            "isbn": "ANCHOR_ISBN", "store": "ANCHOR_STORE", "price": 20.0,
            "arrival_date": arrival,
            "sell_date": arrival + pd.Timedelta(days=250 + k * 10),
        })
    rows.append({
        "isbn": "ANCHOR_ISBN", "store": "ANCHOR_STORE", "price": 20.0,
        "arrival_date": today - pd.Timedelta(days=30), "sell_date": pd.NaT,
    })
    df = pd.DataFrame(rows)
    cp, sm = fn_fit(df)
    result = fn_markdown(df, cp, sm, 100.0, {"ANCHOR_STORE": 1000})
    assert not result.empty, (
        "With holding_cost_per_day=100.0 on a $20 book with 250+ day expected "
        "sell-through, the DP must recommend at least one markdown - holding cost "
        "dominates book value by an order of magnitude"
    )


def test_markdown_schedule_only_for_onhand_combos(loaded_receipts, markdown_schedule):
    _check(loaded_receipts, markdown_schedule)
    if markdown_schedule.empty:
        return
    onhand = loaded_receipts[loaded_receipts["sell_date"].isna()]
    onhand_combos = set(zip(onhand["isbn"], onhand["store"]))
    schedule_combos = set(zip(markdown_schedule["isbn"], markdown_schedule["store"]))
    assert schedule_combos.issubset(onhand_combos), (
        "Markdown schedule must only contain (isbn, store) pairs that have on-hand inventory"
    )


def test_markdown_schedule_first_price_from_original(fn_fit, fn_markdown):
    _check(fn_fit, fn_markdown)
    price = 40.0
    rows = []
    for k in range(10):
        arrival = pd.Timestamp("2023-01-15") + pd.Timedelta(days=k * 10)
        sell = arrival + pd.Timedelta(days=20 + k * 5)
        rows.append({
            "isbn": "FIRSTPRICE_ISBN", "store": "FIRSTPRICE_STORE", "price": price,
            "arrival_date": arrival, "sell_date": sell,
        })
    rows.append({
        "isbn": "FIRSTPRICE_ISBN", "store": "FIRSTPRICE_STORE", "price": price,
        "arrival_date": pd.Timestamp("2023-06-01"), "sell_date": pd.NaT,
    })
    df = pd.DataFrame(rows)
    cp, sm = fn_fit(df)
    result = fn_markdown(df, cp, sm, 0.05, {"FIRSTPRICE_STORE": 100})
    if result.empty:
        return
    group = result[(result["isbn"] == "FIRSTPRICE_ISBN") & (result["store"] == "FIRSTPRICE_STORE")]
    first_row = group.sort_values("week").iloc[0]
    pct = first_row["markdown_percentage"]
    expected_new_price = price * (1 - pct / 100)
    assert first_row["new_price"] == pytest.approx(expected_new_price, rel=1e-4), (
        "First markdown new_price must equal the original cover price reduced by markdown_percentage"
    )


def test_markdown_schedule_shelf_capacity_no_exception_on_tight_capacity(fn_fit, fn_markdown):
    _check(fn_fit, fn_markdown)
    today = pd.Timestamp.now().normalize()
    rows = []
    for isbn_idx in range(3):
        isbn = f"CAP_ISBN_{isbn_idx}"
        for k in range(10):
            arrival = pd.Timestamp("2023-01-15") + pd.Timedelta(days=k * 10)
            sell = arrival + pd.Timedelta(days=300 + k * 30)
            rows.append({
                "isbn": isbn, "store": "CAP_STORE", "price": 20.0,
                "arrival_date": arrival, "sell_date": sell,
            })
        rows.append({
            "isbn": isbn, "store": "CAP_STORE", "price": 20.0,
            "arrival_date": today - pd.Timedelta(days=14),
            "sell_date": pd.NaT,
        })
    df = pd.DataFrame(rows)
    cp, sm = fn_fit(df)
    result_tight = fn_markdown(df, cp, sm, 0.05, {"CAP_STORE": 1})
    result_loose = fn_markdown(df, cp, sm, 0.05, {"CAP_STORE": 10000})
    assert isinstance(result_tight, pd.DataFrame)
    assert isinstance(result_loose, pd.DataFrame)

    if not result_tight.empty and not result_loose.empty:
        tight_first = result_tight.groupby(["isbn", "store"])["week"].min()
        loose_first = result_loose.groupby(["isbn", "store"])["week"].min()
        common_combos = tight_first.index.intersection(loose_first.index)
        for combo in common_combos:
            assert tight_first[combo] <= loose_first[combo], (
                f"Tight shelf capacity caused markdown for {combo} to be scheduled at week "
                f"{tight_first[combo]}, later than the loose-capacity week {loose_first[combo]}; "
                "the greedy pass must only move markdowns earlier, never later"
            )

    onhand = df[df["sell_date"].isna()].copy()
    sm_lookup = sm.set_index("month")["multiplier"].to_dict()

    def compute_expected_onhand(schedule):
        store_week: dict = {}
        for _, item in onhand.iterrows():
            isbn, store = item["isbn"], item["store"]
            d = int((today - item["arrival_date"]).days)
            r = cp[(cp["isbn"] == isbn) & (cp["store"] == store)]
            if r.empty:
                continue
            shape = float(r["weibull_shape"].iloc[0])
            eff_scale = float(r["weibull_scale"].iloc[0]) * float(r["store_factor"].iloc[0])
            markdowns: list = []
            if not schedule.empty:
                crows = schedule[(schedule["isbn"] == isbn) & (schedule["store"] == store)]
                markdowns = sorted(zip(crows["week"].tolist(), crows["markdown_percentage"].tolist()))
            cum_hazard = 0.0
            for w in range(1, 53):
                t0 = d + (w - 1) * 7
                t1 = d + w * 7
                dH0 = (t1 / eff_scale) ** shape - (t0 / eff_scale) ** shape
                week_start = today + pd.Timedelta(days=(w - 1) * 7)
                s_mult = sm_lookup.get(week_start.month, 1.0)
                md_mult = prod(
                    1.0 / (1.0 - pct / 100.0) for (mw, pct) in markdowns if mw <= w
                )
                cum_hazard += dH0 * s_mult * md_mult
                key = (store, w)
                store_week[key] = store_week.get(key, 0.0) + math.exp(-cum_hazard)
        return store_week

    for schedule, capacity, label in [
        (result_tight, 1, "tight"),
        (result_loose, 10000, "loose"),
    ]:
        onhand_map = compute_expected_onhand(schedule)
        for (store, week), exp_count in onhand_map.items():
            if exp_count > capacity + 1e-6:
                store_sched = (
                    schedule[schedule["store"] == store]
                    if not schedule.empty
                    else pd.DataFrame()
                )
                qualifying = (
                    store_sched[
                        (store_sched["week"] >= 2) & (store_sched["week"] >= week)
                    ]
                    if not store_sched.empty
                    else pd.DataFrame()
                )
                assert len(qualifying) == 0, (
                    f"[{label}] Store '{store}' week {week}: expected on-hand "
                    f"{exp_count:.3f} exceeds capacity {capacity}, but candidate "
                    f"markdowns still eligible to be moved earlier exist:\n{qualifying}"
                )


def test_markdown_schedule_week0_exempt_from_shelf_constraint(fn_fit, fn_markdown):
    _check(fn_fit, fn_markdown)
    today = pd.Timestamp.now().normalize()
    rows = []
    for k in range(10):
        arrival = pd.Timestamp("2022-01-01") + pd.Timedelta(days=k * 30)
        rows.append({
            "isbn": "W0_ISBN", "store": "W0_STORE", "price": 20.0,
            "arrival_date": arrival,
            "sell_date": arrival + pd.Timedelta(days=300 + k * 10),
        })
    # Add 5 on-hand units - far exceeds shelf_capacity of 1
    for k in range(5):
        rows.append({
            "isbn": "W0_ISBN", "store": "W0_STORE", "price": 20.0,
            "arrival_date": today - pd.Timedelta(days=10 + k),
            "sell_date": pd.NaT,
        })
    df = pd.DataFrame(rows)
    cp, sm = fn_fit(df)
    # shelf_capacity=1 but 5 on-hand units exist at week 0 - must not raise
    result = fn_markdown(df, cp, sm, 0.05, {"W0_STORE": 1})
    assert isinstance(result, pd.DataFrame), \
        "recommend_markdown_schedule must return a DataFrame even when week-0 on-hand exceeds shelf_capacity"
    expected_cols = {"isbn", "store", "week", "markdown_percentage", "new_price", "expected_revenue"}
    assert set(result.columns) == expected_cols


def test_run_pipeline_returns_dict_with_keys(pipeline_result):
    _check(pipeline_result)
    assert isinstance(pipeline_result, dict)
    expected_keys = {"curve_params", "seasonal_multipliers", "clearance_predictions", "markdown_schedule"}
    assert set(pipeline_result.keys()) == expected_keys


def test_run_pipeline_dataframes_have_correct_columns(pipeline_result):
    _check(pipeline_result)
    assert isinstance(pipeline_result["curve_params"], pd.DataFrame)
    assert set(pipeline_result["curve_params"].columns) == {
        "isbn", "store", "weibull_shape", "weibull_scale", "store_factor"
    }
    assert isinstance(pipeline_result["seasonal_multipliers"], pd.DataFrame)
    assert set(pipeline_result["seasonal_multipliers"].columns) == {"month", "multiplier"}
    assert isinstance(pipeline_result["clearance_predictions"], pd.DataFrame)
    assert set(pipeline_result["clearance_predictions"].columns) == {
        "isbn", "store", "days_on_hand", "predicted_days_to_clear"
    }
    assert isinstance(pipeline_result["markdown_schedule"], pd.DataFrame)
    assert set(pipeline_result["markdown_schedule"].columns) == {
        "isbn", "store", "week", "markdown_percentage", "new_price", "expected_revenue"
    }


def test_markdown_schedule_expected_revenue_consistent_with_formula(fn_fit, fn_markdown):
    _check(fn_fit, fn_markdown)
    today = pd.Timestamp.now().normalize()
    rows = []
    for month in range(1, 13):
        sell_dt = pd.Timestamp(f"2022-{month:02d}-15")
        arrival = sell_dt - pd.Timedelta(days=250 + month * 5)
        rows.append({
            "isbn": "FORM_ISBN", "store": "FORM_STORE", "price": 50.0,
            "arrival_date": arrival, "sell_date": sell_dt,
        })
    rows.append({
        "isbn": "FORM_ISBN", "store": "FORM_STORE", "price": 50.0,
        "arrival_date": today - pd.Timedelta(days=30), "sell_date": pd.NaT,
    })
    df = pd.DataFrame(rows)
    cp, sm = fn_fit(df)
    hcpd = 5.0
    result = fn_markdown(df, cp, sm, hcpd, {"FORM_STORE": 1000})
    group = result[(result["isbn"] == "FORM_ISBN") & (result["store"] == "FORM_STORE")]
    if group.empty:
        return
    r = cp[(cp["isbn"] == "FORM_ISBN") & (cp["store"] == "FORM_STORE")].iloc[0]
    shape = float(r["weibull_shape"])
    eff_scale = float(r["weibull_scale"]) * float(r["store_factor"])
    sm_lookup = sm.set_index("month")["multiplier"].to_dict()
    onhand = df[df["sell_date"].isna()].iloc[0]
    d = int((today - onhand["arrival_date"]).days)
    schedule = sorted(zip(group["week"].tolist(), group["markdown_percentage"].tolist()))
    total_rev = 0.0
    total_hc = 0.0
    cum_hazard = 0.0
    S_prev = 1.0
    price_base = 50.0
    for w in range(1, 53):
        t0 = d + (w - 1) * 7
        t1 = d + w * 7
        dH0 = (t1 / eff_scale) ** shape - (t0 / eff_scale) ** shape
        week_start = today + pd.Timedelta(days=(w - 1) * 7)
        s_mult = sm_lookup.get(week_start.month, 1.0)
        md_mult = prod(1.0 / (1.0 - pct / 100.0) for (mw, pct) in schedule if mw <= w)
        dh = dH0 * s_mult * md_mult
        P_w = 1.0 - math.exp(-dh)
        price_w = price_base * prod((1.0 - pct / 100.0) for (mw, pct) in schedule if mw <= w)
        total_rev += price_w * P_w * S_prev
        total_hc += hcpd * 7 * S_prev
        cum_hazard += dh
        S_prev = math.exp(-cum_hazard)
    expected_net = total_rev - total_hc
    reported_net = float(group["expected_revenue"].iloc[0])
    assert reported_net == pytest.approx(expected_net, rel=1e-6), (
        f"expected_revenue {reported_net:.4f} does not match formula result {expected_net:.4f}"
    )


@pytest.mark.parametrize("low_hcpd,high_hcpd,isbn,store,price,sell_through_base", [
    # Extreme contrast: near-zero vs very high holding cost
    (0.001, 100.0, "HC_ISBN",  "HC_STORE",  20.0, 250),
    # Moderate contrast: low vs high holding cost on higher-value book
    (2.0,   20.0,  "HC2_ISBN", "HC2_STORE", 50.0, 250),
])
def test_markdown_schedule_holding_cost_monotonicity(
    fn_fit, fn_markdown,
    low_hcpd, high_hcpd, isbn, store, price, sell_through_base,
):
    _check(fn_fit, fn_markdown)
    today = pd.Timestamp.now().normalize()
    rows = []
    for month in range(1, 13):
        sell_dt = pd.Timestamp(f"2022-{month:02d}-15")
        arrival = sell_dt - pd.Timedelta(days=sell_through_base + month * 5)
        rows.append({
            "isbn": isbn, "store": store, "price": price,
            "arrival_date": arrival, "sell_date": sell_dt,
        })
    rows.append({
        "isbn": isbn, "store": store, "price": price,
        "arrival_date": today - pd.Timedelta(days=30), "sell_date": pd.NaT,
    })
    df = pd.DataFrame(rows)
    cp, sm = fn_fit(df)
    result_low  = fn_markdown(df, cp, sm, low_hcpd,  {store: 1000})
    result_high = fn_markdown(df, cp, sm, high_hcpd, {store: 1000})
    low_grp  = result_low[result_low["isbn"]   == isbn]
    high_grp = result_high[result_high["isbn"] == isbn]
    # Direct consequence of the objective formula: for any fixed schedule,
    # increasing holding_cost_per_day can only decrease or leave unchanged
    # the optimal net expected revenue. Both schedules must be non-empty
    # or the test is inconclusive (DP may legitimately choose no markdowns).
    if not low_grp.empty and not high_grp.empty:
        assert high_grp["expected_revenue"].iloc[0] <= low_grp["expected_revenue"].iloc[0], (
            f"[hcpd={low_hcpd} vs {high_hcpd}] Optimal net revenue must not increase "
            f"as holding_cost_per_day increases for isbn={isbn} store={store}"
        )


def test_markdown_schedule_expected_revenue_sums_multiple_onhand_units(fn_fit, fn_markdown):
    _check(fn_fit, fn_markdown)
    today = pd.Timestamp.now().normalize()
    rows = []
    for month in range(1, 13):
        sell_dt = pd.Timestamp(f"2022-{month:02d}-15")
        arrival = sell_dt - pd.Timedelta(days=250 + month * 5)
        rows.append({
            "isbn": "MULTI_ISBN", "store": "MULTI_STORE", "price": 50.0,
            "arrival_date": arrival, "sell_date": sell_dt,
        })
    arrival_onhand = today - pd.Timedelta(days=30)
    df_single = pd.DataFrame(rows + [{
        "isbn": "MULTI_ISBN", "store": "MULTI_STORE", "price": 50.0,
        "arrival_date": arrival_onhand, "sell_date": pd.NaT,
    }])
    df_multi = pd.DataFrame(rows + [
        {"isbn": "MULTI_ISBN", "store": "MULTI_STORE", "price": 50.0,
         "arrival_date": arrival_onhand, "sell_date": pd.NaT},
        {"isbn": "MULTI_ISBN", "store": "MULTI_STORE", "price": 50.0,
         "arrival_date": arrival_onhand, "sell_date": pd.NaT},
    ])
    cp, sm = fn_fit(df_single)
    result_single = fn_markdown(df_single, cp, sm, 0.0, {"MULTI_STORE": 1000})
    result_multi  = fn_markdown(df_multi,  cp, sm, 0.0, {"MULTI_STORE": 1000})
    grp_single = result_single[result_single["isbn"] == "MULTI_ISBN"]
    grp_multi  = result_multi[result_multi["isbn"]  == "MULTI_ISBN"]
    if grp_single.empty or grp_multi.empty:
        return
    single_rev = grp_single["expected_revenue"].iloc[0]
    multi_rev  = grp_multi["expected_revenue"].iloc[0]
    assert multi_rev == pytest.approx(2 * single_rev, rel=1e-4), (
        "expected_revenue for 2 identical on-hand units must equal 2x the single-unit value; "
        "the column must aggregate additively across all on-hand units of the same (isbn, store)"
    )