import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

try:
    from pipeline import (
        attribute_maintenance_costs,
        compute_replacement_scores,
        generate_fleet_report,
        load_fleet_data,
        model_fuel_consumption,
        run_pipeline,
    )
except ImportError:
    attribute_maintenance_costs = None
    compute_replacement_scores = None
    generate_fleet_report = None
    load_fleet_data = None
    model_fuel_consumption = None
    run_pipeline = None


# ---------------------------------------------------------------------------
# Shared utilities
# ---------------------------------------------------------------------------

def _require(fn, name):
    """Produce FAILED (not ERROR) when a symbol was not importable."""
    if fn is None:
        pytest.fail(f"'{name}' could not be imported from pipeline.py")


def _load_bundled():
    """Load bundled data/ files; fail gracefully if pipeline or files are absent."""
    _require(load_fleet_data, "load_fleet_data")
    try:
        return load_fleet_data("data/")
    except FileNotFoundError:
        pytest.fail("Required CSV files not found under data/")


def _primary_op(series):
    """Mode of a Series; alphabetical tiebreak -- mirrors the prompt specification."""
    counts = series.value_counts()
    return sorted(counts[counts == counts.max()].index)[0]


_YYYY_MM_DD = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _all_str(series):
    """True iff every non-null value in `series` is a Python str.

    Works for both object dtype and pandas' extension 'string' dtype, and
    rejects integer, float, or categorical-wrapped numeric columns.
    """
    return series.dropna().map(type).eq(str).all()


def _get_sections(path):
    """Split the report file into its three section bodies."""
    content = Path(path).read_text()
    m1 = re.search(r"REPLACEMENT CANDIDATES(.*?)MAINTENANCE COST ATTRIBUTION", content, re.DOTALL)
    m2 = re.search(r"MAINTENANCE COST ATTRIBUTION(.*?)FUEL CONSUMPTION MODEL", content, re.DOTALL)
    m3 = re.search(r"FUEL CONSUMPTION MODEL(.*?)$", content, re.DOTALL)
    return (
        m1.group(1) if m1 else "",
        m2.group(1) if m2 else "",
        m3.group(1) if m3 else "",
    )


# ---------------------------------------------------------------------------
# Synthetic fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def vehicles_df():
    """20 vehicles (5 per type) with distinct years so age_years vary across all vehicles."""
    types = ["light_truck", "heavy_truck", "equipment", "snow_plow"]
    rows = []
    for i, vtype in enumerate(types):
        for j in range(5):
            k = i * 5 + j + 1
            rows.append({
                "vehicle_id": f"V{k:03d}",
                "vehicle_type": vtype,
                "year": 2020 - k,
                "make": "Generic",
                "model": "Model",
            })
    return pd.DataFrame(rows)


@pytest.fixture
def maintenance_df(vehicles_df):
    """
    100 records (5 per vehicle), 7 distinct operators.
    Each vehicle has a clear primary operator (3/5 records), and groups of 4
    vehicles share the same primary operator -- required by operator_cost tests.
    Every vehicle has records from 2+ distinct operators.
    """
    vehicle_ids = vehicles_df["vehicle_id"].tolist()
    operators = [f"OP{n:02d}" for n in range(1, 8)]
    rows = []
    wid = 1
    for k, vid in enumerate(vehicle_ids):
        primary = operators[k // 4]
        for j in range(5):
            year = 2019 + (j % 5)
            month = (j * 3 + 1) % 12 + 1
            if j < 3:
                op = primary
            else:
                candidate = operators[(k + j + 1) % len(operators)]
                op = candidate if candidate != primary else operators[(k + j + 2) % len(operators)]
            rows.append({
                "vehicle_id": vid,
                "work_order_id": f"WO{wid:05d}",
                "date": f"{year}-{month:02d}-15",
                "labor_cost": round(150.0 + k * 25.0 + j * 12.0, 2),
                "parts_cost": round(75.0 + k * 12.0 + j * 6.0, 2),
                "maintenance_type": "preventive",
                "operator_id": op,
            })
            wid += 1
    return pd.DataFrame(rows)


@pytest.fixture
def utilization_df(vehicles_df):
    """100 records (5 per vehicle), all four seasons present, spanning 2019-2023."""
    seasons = ["spring", "summer", "fall", "winter"]
    routes = ["ROUTE_A", "ROUTE_B", "ROUTE_C"]
    rows = []
    for k, vid in enumerate(vehicles_df["vehicle_id"]):
        for j in range(5):
            rows.append({
                "vehicle_id": vid,
                "date": f"{2019 + j}-{(j * 3 % 12) + 1:02d}-10",
                "miles_driven": round(120.0 + k * 15.0 + j * 8.0, 2),
                "hours_operated": round(6.0 + k * 0.8 + j * 0.4, 2),
                "route": routes[j % 3],
                "season": seasons[j % 4],
            })
    return pd.DataFrame(rows)


@pytest.fixture
def fuel_df(vehicles_df):
    """60 records: 3 routes x 4 seasons x 5 records each -- meets all prompt constraints."""
    seasons = ["spring", "summer", "fall", "winter"]
    routes = ["ROUTE_A", "ROUTE_B", "ROUTE_C"]
    vehicle_ids = vehicles_df["vehicle_id"].tolist()
    rows = []
    idx = 0
    for route in routes:
        for season in seasons:
            for rep in range(5):
                vid = vehicle_ids[idx % len(vehicle_ids)]
                rows.append({
                    "vehicle_id": vid,
                    "date": f"{2019 + (idx % 5)}-{(idx % 12) + 1:02d}-{rep + 1:02d}",
                    "fuel_gallons": round(9.0 + routes.index(route) * 1.2
                                         + seasons.index(season) * 0.6 + rep * 0.2, 4),
                    "miles_driven": round(45.0 + routes.index(route) * 4.0 + rep * 1.5, 4),
                    "route": route,
                    "season": season,
                })
                idx += 1
    return pd.DataFrame(rows)


@pytest.fixture
def data_dir(tmp_path, vehicles_df, maintenance_df, utilization_df, fuel_df):
    """Write all four CSVs to a temporary directory."""
    d = tmp_path / "data"
    d.mkdir()
    vehicles_df.to_csv(d / "vehicles.csv", index=False)
    maintenance_df.to_csv(d / "maintenance.csv", index=False)
    utilization_df.to_csv(d / "utilization.csv", index=False)
    fuel_df.to_csv(d / "fuel.csv", index=False)
    return str(d)


@pytest.fixture
def tmp_output(tmp_path):
    return str(tmp_path / "reports" / "fleet.txt")


@pytest.fixture
def replacement_df():
    return pd.DataFrame({
        "vehicle_id": ["V001", "V002", "V003", "V004", "V005"],
        "replacement_score": [2.75, 2.30, 1.80, 1.20, 0.75],
        "flagged": [True, True, False, False, False],
    })


@pytest.fixture
def attribution_df():
    return pd.DataFrame({
        "vehicle_id": ["V001", "V002", "V003", "V004", "V005"],
        "vehicle_type": ["equipment", "heavy_truck", "light_truck", "light_truck", "snow_plow"],
        "aging_cost": [1800.0, 2400.0, 960.0, 1080.0, 720.0],
        "operator_cost": [150.0, -80.0, 200.0, 220.0, 60.0],
    })


@pytest.fixture
def fuel_model_df():
    seasons = ["fall", "spring", "summer", "winter"]
    routes = ["ROUTE_A", "ROUTE_B"]
    rows = []
    for route in routes:
        for season in seasons:
            rows.append({
                "route": route,
                "season": season,
                "predicted_gallons_per_mile": round(
                    0.18 + routes.index(route) * 0.01 + seasons.index(season) * 0.005, 4
                ),
            })
    return pd.DataFrame(rows)


# ===========================================================================
# 1. load_fleet_data
# ===========================================================================

class TestLoadFleetData:

    def test_returns_dict_with_four_keys(self, data_dir):
        _require(load_fleet_data, "load_fleet_data")
        result = load_fleet_data(data_dir)
        assert set(result.keys()) == {"vehicles", "maintenance", "utilization", "fuel"}

    def test_all_values_are_dataframes(self, data_dir):
        _require(load_fleet_data, "load_fleet_data")
        result = load_fleet_data(data_dir)
        for key in ("vehicles", "maintenance", "utilization", "fuel"):
            assert isinstance(result[key], pd.DataFrame), \
                f"result['{key}'] is not a DataFrame"

    def test_vehicles_has_required_columns(self, data_dir):
        _require(load_fleet_data, "load_fleet_data")
        df = load_fleet_data(data_dir)["vehicles"]
        assert {"vehicle_id", "vehicle_type", "year", "make", "model"}.issubset(df.columns)

    def test_maintenance_has_required_columns(self, data_dir):
        _require(load_fleet_data, "load_fleet_data")
        df = load_fleet_data(data_dir)["maintenance"]
        assert {"vehicle_id", "work_order_id", "date", "labor_cost",
                "parts_cost", "maintenance_type", "operator_id"}.issubset(df.columns)

    def test_utilization_has_required_columns(self, data_dir):
        _require(load_fleet_data, "load_fleet_data")
        df = load_fleet_data(data_dir)["utilization"]
        assert {"vehicle_id", "date", "miles_driven", "hours_operated",
                "route", "season"}.issubset(df.columns)

    def test_fuel_has_required_columns(self, data_dir):
        _require(load_fleet_data, "load_fleet_data")
        df = load_fleet_data(data_dir)["fuel"]
        assert {"vehicle_id", "date", "fuel_gallons", "miles_driven",
                "route", "season"}.issubset(df.columns)

    def test_raises_file_not_found_when_csv_absent(self, tmp_path):
        _require(load_fleet_data, "load_fleet_data")
        empty = tmp_path / "empty_dir"
        empty.mkdir()
        with pytest.raises(FileNotFoundError):
            load_fleet_data(str(empty))

    @pytest.mark.parametrize("missing_file", [
        "vehicles.csv", "maintenance.csv", "utilization.csv", "fuel.csv",
    ])
    def test_raises_file_not_found_per_individual_csv(self, data_dir, tmp_path, missing_file):
        """Prompt: 'Raises FileNotFoundError if any required CSV file is absent
        from data_dir.' Each of the four required files must be individually
        checked -- not just whichever one happens to be read first.
        """
        _require(load_fleet_data, "load_fleet_data")
        partial = tmp_path / f"partial_{missing_file.replace('.', '_')}"
        partial.mkdir()
        for fname in os.listdir(data_dir):
            if fname != missing_file:
                shutil.copy(os.path.join(data_dir, fname), partial / fname)
        with pytest.raises(FileNotFoundError):
            load_fleet_data(str(partial))


# ===========================================================================
# 2. Bundled data validation
# ===========================================================================

class TestBundledData:

    def test_vehicles_minimum_count(self):
        data = _load_bundled()
        assert len(data["vehicles"]) >= 20

    def test_vehicles_all_four_types_present(self):
        data = _load_bundled()
        assert {"light_truck", "heavy_truck", "equipment", "snow_plow"}.issubset(
            set(data["vehicles"]["vehicle_type"])
        )

    def test_vehicles_at_least_five_per_type(self):
        data = _load_bundled()
        counts = data["vehicles"]["vehicle_type"].value_counts()
        for vtype in ("light_truck", "heavy_truck", "equipment", "snow_plow"):
            assert counts.get(vtype, 0) >= 5, \
                f"vehicle_type '{vtype}' has fewer than 5 records"

    def test_vehicles_only_valid_types(self):
        data = _load_bundled()
        assert set(data["vehicles"]["vehicle_type"]).issubset(
            {"light_truck", "heavy_truck", "equipment", "snow_plow"}
        ), "vehicles.csv contains a vehicle_type outside the allowed set"

    def test_vehicles_vehicle_id_is_unique(self):
        """vehicle_id is the primary key used in merges across the pipeline."""
        data = _load_bundled()
        assert data["vehicles"]["vehicle_id"].is_unique, \
            "vehicles.csv contains duplicate vehicle_id values"

    def test_vehicles_year_is_integer_dtype(self):
        """Prompt: vehicles.csv column 'year (int)'."""
        data = _load_bundled()
        assert pd.api.types.is_integer_dtype(data["vehicles"]["year"]), \
            "vehicles.csv 'year' column is not an integer type"

    def test_vehicles_string_columns_dtype(self):
        """Prompt: vehicles.csv columns 'vehicle_id (str), vehicle_type (str),
        ..., make (str), model (str)'."""
        data = _load_bundled()
        df = data["vehicles"]
        for col in ("vehicle_id", "vehicle_type", "make", "model"):
            assert _all_str(df[col]), \
                f"vehicles.csv '{col}' column does not contain str values"

    def test_maintenance_string_columns_dtype(self):
        """Prompt: maintenance.csv columns 'vehicle_id (str), work_order_id (str),
        ..., maintenance_type (str), operator_id (str)'."""
        data = _load_bundled()
        df = data["maintenance"]
        for col in ("vehicle_id", "work_order_id", "maintenance_type", "operator_id"):
            assert _all_str(df[col]), \
                f"maintenance.csv '{col}' column does not contain str values"

    def test_maintenance_numeric_columns_float_dtype(self):
        """Prompt: maintenance.csv columns 'labor_cost (float), parts_cost (float)'."""
        data = _load_bundled()
        df = data["maintenance"]
        for col in ("labor_cost", "parts_cost"):
            assert pd.api.types.is_float_dtype(df[col]), \
                f"maintenance.csv '{col}' is not a float dtype"

    def test_utilization_string_columns_dtype(self):
        """Prompt: utilization.csv columns 'vehicle_id (str), ..., route (str),
        season (str, ...)'."""
        data = _load_bundled()
        df = data["utilization"]
        for col in ("vehicle_id", "route", "season"):
            assert _all_str(df[col]), \
                f"utilization.csv '{col}' column does not contain str values"

    def test_utilization_numeric_columns_float_dtype(self):
        """Prompt: utilization.csv columns 'miles_driven (float), hours_operated (float)'."""
        data = _load_bundled()
        df = data["utilization"]
        for col in ("miles_driven", "hours_operated"):
            assert pd.api.types.is_float_dtype(df[col]), \
                f"utilization.csv '{col}' is not a float dtype"

    def test_fuel_string_columns_dtype(self):
        """Prompt: fuel.csv columns 'vehicle_id (str), ..., route (str),
        season (str, ...)'."""
        data = _load_bundled()
        df = data["fuel"]
        for col in ("vehicle_id", "route", "season"):
            assert _all_str(df[col]), \
                f"fuel.csv '{col}' column does not contain str values"

    def test_fuel_numeric_columns_float_dtype(self):
        """Prompt: fuel.csv columns 'fuel_gallons (float), miles_driven (float)'."""
        data = _load_bundled()
        df = data["fuel"]
        for col in ("fuel_gallons", "miles_driven"):
            assert pd.api.types.is_float_dtype(df[col]), \
                f"fuel.csv '{col}' is not a float dtype"

    def test_maintenance_minimum_count(self):
        data = _load_bundled()
        assert len(data["maintenance"]) >= 100

    def test_maintenance_covers_all_vehicles(self):
        data = _load_bundled()
        assert set(data["vehicles"]["vehicle_id"]).issubset(
            set(data["maintenance"]["vehicle_id"])
        )

    def test_maintenance_date_spans_2019_to_2023(self):
        """Prompt: 'spanning 2019 through 2023' (maintenance.csv).

        Requires both endpoint years (2019 and 2023) to actually be present in
        the data; min/max-only checks would spuriously accept datasets with no
        records inside the 2019-2023 window (e.g. dates [2018, 2024]).
        """
        data = _load_bundled()
        years = set(pd.to_datetime(data["maintenance"]["date"]).dt.year)
        assert 2019 in years, "maintenance.csv has no records from 2019"
        assert 2023 in years, "maintenance.csv has no records from 2023"

    def test_maintenance_date_format_yyyy_mm_dd(self):
        """Prompt: maintenance.csv column 'date (str, YYYY-MM-DD)'."""
        data = _load_bundled()
        bad = [d for d in data["maintenance"]["date"].astype(str)
               if not _YYYY_MM_DD.match(d)]
        assert not bad, \
            f"maintenance.csv has {len(bad)} date(s) not in YYYY-MM-DD format, e.g. {bad[:3]}"

    def test_maintenance_date_is_string_dtype(self):
        """Prompt: maintenance.csv column 'date (str, ...)'."""
        data = _load_bundled()
        assert _all_str(data["maintenance"]["date"]), \
            "maintenance.csv 'date' column does not contain str values"

    def test_maintenance_at_least_five_distinct_operators(self):
        data = _load_bundled()
        assert data["maintenance"]["operator_id"].nunique() >= 5

    def test_maintenance_at_least_ten_multi_operator_vehicles(self):
        data = _load_bundled()
        multi = (data["maintenance"]
                 .groupby("vehicle_id")["operator_id"]
                 .nunique() > 1).sum()
        assert multi >= 10

    def test_utilization_minimum_count(self):
        data = _load_bundled()
        assert len(data["utilization"]) >= 100

    def test_utilization_covers_all_vehicles(self):
        data = _load_bundled()
        assert set(data["vehicles"]["vehicle_id"]).issubset(
            set(data["utilization"]["vehicle_id"])
        )

    def test_utilization_date_spans_2019_to_2023(self):
        """Prompt: 'spanning 2019 through 2023' (utilization.csv).

        Requires both endpoint years (2019 and 2023) to actually be present in
        the data; min/max-only checks would spuriously accept datasets with no
        records inside the 2019-2023 window.
        """
        data = _load_bundled()
        years = set(pd.to_datetime(data["utilization"]["date"]).dt.year)
        assert 2019 in years, "utilization.csv has no records from 2019"
        assert 2023 in years, "utilization.csv has no records from 2023"

    def test_utilization_date_format_yyyy_mm_dd(self):
        """Prompt: utilization.csv column 'date (str, YYYY-MM-DD)'."""
        data = _load_bundled()
        bad = [d for d in data["utilization"]["date"].astype(str)
               if not _YYYY_MM_DD.match(d)]
        assert not bad, \
            f"utilization.csv has {len(bad)} date(s) not in YYYY-MM-DD format, e.g. {bad[:3]}"

    def test_utilization_date_is_string_dtype(self):
        """Prompt: utilization.csv column 'date (str, ...)'."""
        data = _load_bundled()
        assert _all_str(data["utilization"]["date"]), \
            "utilization.csv 'date' column does not contain str values"

    def test_utilization_valid_season_values(self):
        data = _load_bundled()
        assert set(data["utilization"]["season"]).issubset(
            {"spring", "summer", "fall", "winter"}
        )

    def test_snow_plow_utilization_concentrated_in_winter(self):
        """Prompt: 'Records for snow_plow vehicles are concentrated in the winter
        season to represent their seasonal deployment pattern.' (utilization.csv)

        'Concentrated' is qualitative; the weakest defensible behavioral
        interpretation is that winter is the most-frequent season among
        snow_plow utilization records (i.e. argmax over the four-season
        distribution is 'winter'). Stronger qualitative interpretations
        ('majority', 'supermajority', etc.) are intentionally captured by a
        rubric item rather than baked in as a numeric threshold here.
        """
        data = _load_bundled()
        snow_ids = data["vehicles"].loc[
            data["vehicles"]["vehicle_type"] == "snow_plow", "vehicle_id"
        ]
        snow_records = data["utilization"][
            data["utilization"]["vehicle_id"].isin(snow_ids)
        ]
        assert len(snow_records) > 0, "No utilization records for snow_plow vehicles"
        season_counts = snow_records["season"].value_counts()
        top_season = season_counts.idxmax()
        assert top_season == "winter", (
            f"snow_plow utilization is most frequent in '{top_season}', not "
            f"'winter'; observed counts: {season_counts.to_dict()}"
        )

    def test_fuel_minimum_count(self):
        data = _load_bundled()
        assert len(data["fuel"]) >= 60

    def test_fuel_all_four_seasons_present(self):
        data = _load_bundled()
        assert {"spring", "summer", "fall", "winter"}.issubset(
            set(data["fuel"]["season"])
        )

    def test_fuel_at_least_three_distinct_routes(self):
        data = _load_bundled()
        assert data["fuel"]["route"].nunique() >= 3

    def test_fuel_date_spans_2019_to_2023(self):
        """Prompt: 'spanning 2019 through 2023' (fuel.csv).

        Requires both endpoint years (2019 and 2023) to actually be present in
        the data; min/max-only checks would spuriously accept datasets with no
        records inside the 2019-2023 window.
        """
        data = _load_bundled()
        years = set(pd.to_datetime(data["fuel"]["date"]).dt.year)
        assert 2019 in years, "fuel.csv has no records from 2019"
        assert 2023 in years, "fuel.csv has no records from 2023"

    def test_fuel_date_format_yyyy_mm_dd(self):
        """Prompt: fuel.csv column 'date (str, YYYY-MM-DD)'."""
        data = _load_bundled()
        bad = [d for d in data["fuel"]["date"].astype(str)
               if not _YYYY_MM_DD.match(d)]
        assert not bad, \
            f"fuel.csv has {len(bad)} date(s) not in YYYY-MM-DD format, e.g. {bad[:3]}"

    def test_fuel_date_is_string_dtype(self):
        """Prompt: fuel.csv column 'date (str, ...)'."""
        data = _load_bundled()
        assert _all_str(data["fuel"]["date"]), \
            "fuel.csv 'date' column does not contain str values"

    def test_fuel_valid_season_values(self):
        data = _load_bundled()
        assert set(data["fuel"]["season"]).issubset(
            {"spring", "summer", "fall", "winter"}
        ), "fuel.csv contains a season value outside the allowed set"

    def test_fuel_at_least_five_records_per_route_season(self):
        data = _load_bundled()
        counts = data["fuel"].groupby(["route", "season"]).size()
        assert (counts >= 5).all(), \
            "Some (route, season) combinations have fewer than 5 records"


# ===========================================================================
# 3. compute_replacement_scores
# ===========================================================================

class TestComputeReplacementScores:

    def test_output_has_exactly_three_columns(self, vehicles_df, maintenance_df, utilization_df):
        _require(compute_replacement_scores, "compute_replacement_scores")
        result = compute_replacement_scores(vehicles_df, maintenance_df, utilization_df)
        assert set(result.columns) == {"vehicle_id", "replacement_score", "flagged"}

    def test_one_row_per_vehicle(self, vehicles_df, maintenance_df, utilization_df):
        _require(compute_replacement_scores, "compute_replacement_scores")
        result = compute_replacement_scores(vehicles_df, maintenance_df, utilization_df)
        assert len(result) == len(vehicles_df)

    def test_all_vehicle_ids_present(self, vehicles_df, maintenance_df, utilization_df):
        _require(compute_replacement_scores, "compute_replacement_scores")
        result = compute_replacement_scores(vehicles_df, maintenance_df, utilization_df)
        assert set(result["vehicle_id"]) == set(vehicles_df["vehicle_id"])

    def test_replacement_score_in_valid_range(self, vehicles_df, maintenance_df, utilization_df):
        """Sum of three values each in [0, 1] must be in [0, 3]."""
        _require(compute_replacement_scores, "compute_replacement_scores")
        result = compute_replacement_scores(vehicles_df, maintenance_df, utilization_df)
        assert (result["replacement_score"] >= 0.0).all()
        assert (result["replacement_score"] <= 3.0 + 1e-9).all()

    def test_flagged_column_is_boolean(self, vehicles_df, maintenance_df, utilization_df):
        _require(compute_replacement_scores, "compute_replacement_scores")
        result = compute_replacement_scores(vehicles_df, maintenance_df, utilization_df)
        assert result["flagged"].dtype == bool

    def test_replacement_score_is_float_dtype(self, vehicles_df, maintenance_df, utilization_df):
        _require(compute_replacement_scores, "compute_replacement_scores")
        result = compute_replacement_scores(vehicles_df, maintenance_df, utilization_df)
        assert pd.api.types.is_float_dtype(result["replacement_score"])

    def test_vehicle_id_is_string_dtype(self, vehicles_df, maintenance_df, utilization_df):
        """Prompt: 'vehicle_id (str)' in compute_replacement_scores output."""
        _require(compute_replacement_scores, "compute_replacement_scores")
        result = compute_replacement_scores(vehicles_df, maintenance_df, utilization_df)
        assert _all_str(result["vehicle_id"]), \
            "compute_replacement_scores output 'vehicle_id' is not str-typed"

    def test_flagged_iff_score_at_or_above_75th_percentile(self, vehicles_df, maintenance_df, utilization_df):
        _require(compute_replacement_scores, "compute_replacement_scores")
        result = compute_replacement_scores(vehicles_df, maintenance_df, utilization_df)
        threshold = result["replacement_score"].quantile(0.75)
        expected = result["replacement_score"] >= threshold
        assert (result["flagged"] == expected).all()

    def test_degenerate_metric_contributes_zero(self):
        """When max == min for a metric, its normalized value is 0.0 for all vehicles."""
        _require(compute_replacement_scores, "compute_replacement_scores")
        vehicles = pd.DataFrame({
            "vehicle_id": [f"D{i}" for i in range(1, 6)],
            "vehicle_type": ["light_truck"] * 5,
            "year": [2015] * 5,
            "make": ["X"] * 5,
            "model": ["Y"] * 5,
        })
        maintenance = pd.DataFrame({
            "vehicle_id": [f"D{i}" for i in range(1, 6)],
            "work_order_id": [f"W{i}" for i in range(1, 6)],
            "date": ["2021-06-01"] * 5,
            "labor_cost": [i * 100.0 for i in range(1, 6)],
            "parts_cost": [i * 50.0 for i in range(1, 6)],
            "maintenance_type": ["routine"] * 5,
            "operator_id": ["OP01"] * 5,
        })
        utilization = pd.DataFrame({
            "vehicle_id": [f"D{i}" for i in range(1, 6)],
            "date": ["2021-06-01"] * 5,
            "miles_driven": [100.0] * 5,
            "hours_operated": [8.0] * 5,
            "route": ["R"] * 5,
            "season": ["spring"] * 5,
        })
        result = compute_replacement_scores(vehicles, maintenance, utilization)
        assert (result["replacement_score"] <= 1.0 + 1e-9).all()

    def test_total_maintenance_cost_uses_labor_plus_parts(self):
        """Prompt: 'total_maintenance_cost: sum of (labor_cost + parts_cost)'.

        V_labor (labor=200, parts=0) and V_parts (labor=0, parts=200) have the
        same total_maintenance_cost = 200, so they must produce the same
        replacement_score. Catches implementations that use only labor_cost or
        only parts_cost (which would rank them differently). Year and hours
        are degenerate so the score is fully driven by the cost contribution.
        """
        _require(compute_replacement_scores, "compute_replacement_scores")
        vehicles = pd.DataFrame({
            "vehicle_id": ["V_labor", "V_parts", "V_high"],
            "vehicle_type": ["light_truck"] * 3,
            "year": [2020] * 3,
            "make": ["X"] * 3,
            "model": ["Y"] * 3,
        })
        maintenance = pd.DataFrame({
            "vehicle_id": ["V_labor", "V_parts", "V_high"],
            "work_order_id": [f"W{i}" for i in range(1, 4)],
            "date": ["2021-01-01"] * 3,
            "labor_cost":  [200.0,   0.0, 400.0],
            "parts_cost":  [  0.0, 200.0, 400.0],
            "maintenance_type": ["routine"] * 3,
            "operator_id": ["OP01"] * 3,
        })
        utilization = pd.DataFrame({
            "vehicle_id": ["V_labor", "V_parts", "V_high"],
            "date": ["2021-01-01"] * 3,
            "miles_driven": [100.0] * 3,
            "hours_operated": [10.0] * 3,
            "route": ["R"] * 3,
            "season": ["spring"] * 3,
        })
        result = compute_replacement_scores(vehicles, maintenance, utilization)
        scores = result.set_index("vehicle_id")["replacement_score"]
        assert np.isclose(scores["V_labor"], scores["V_parts"], atol=1e-6), (
            f"V_labor score ({scores['V_labor']:.6f}) and V_parts score "
            f"({scores['V_parts']:.6f}) differ even though both have "
            f"labor_cost + parts_cost = 200; total_maintenance_cost is not "
            f"the prompt-required sum of labor_cost and parts_cost"
        )

    def test_flagged_inclusive_at_75th_percentile_boundary(self):
        """Prompt: 'flagged ... is greater than or equal to the 75th percentile'.
        The boundary is INCLUSIVE -- a vehicle whose score equals the threshold
        must be flagged. With years [2020, 2015, 2010, 2010] and degenerate
        cost/hours, age normalization yields scores [0.0, 0.5, 1.0, 1.0]. For
        these duplicated maxima, pandas' quantile(0.75) interpolates to 1.0,
        so V3 and V4 sit exactly at the threshold. An implementation using
        strict > would leave both unflagged.
        """
        _require(compute_replacement_scores, "compute_replacement_scores")
        vehicles = pd.DataFrame({
            "vehicle_id": ["V1", "V2", "V3", "V4"],
            "vehicle_type": ["light_truck"] * 4,
            "year": [2020, 2015, 2010, 2010],
            "make": ["X"] * 4,
            "model": ["Y"] * 4,
        })
        maintenance = pd.DataFrame({
            "vehicle_id": ["V1", "V2", "V3", "V4"],
            "work_order_id": [f"W{i}" for i in range(1, 5)],
            "date": ["2021-01-01"] * 4,
            "labor_cost": [100.0] * 4,
            "parts_cost": [50.0] * 4,
            "maintenance_type": ["routine"] * 4,
            "operator_id": ["OP01"] * 4,
        })
        utilization = pd.DataFrame({
            "vehicle_id": ["V1", "V2", "V3", "V4"],
            "date": ["2021-01-01"] * 4,
            "miles_driven": [100.0] * 4,
            "hours_operated": [10.0] * 4,
            "route": ["R"] * 4,
            "season": ["spring"] * 4,
        })
        result = compute_replacement_scores(vehicles, maintenance, utilization)
        threshold = result["replacement_score"].quantile(0.75)
        at_threshold = result[
            np.isclose(result["replacement_score"], threshold, atol=1e-9)
        ]
        assert len(at_threshold) >= 1, (
            "fixture setup failed to produce a vehicle exactly at the 75th "
            "percentile; rerun with adjusted years"
        )
        for _, row in at_threshold.iterrows():
            assert row["flagged"], (
                f"vehicle '{row['vehicle_id']}' has replacement_score equal "
                f"to the 75th percentile threshold but flagged is False; "
                f"the prompt requires inclusive (>=) flagging"
            )

    def test_normalization_is_global_not_per_vehicle_type(self):
        """Prompt: 'Apply min-max scaling across all vehicles independently to
        each of the three values'. Normalization scope is GLOBAL (all vehicles
        together), not per vehicle_type.

        Fixture: two light_trucks with low hours (10, 20) and two heavy_trucks
        with high hours (50, 100); year and maintenance cost are degenerate, so
        replacement_score is fully driven by normalized cumulative_hours.
          - Under GLOBAL normalization (correct): hours range is [10, 100],
            so scores are L1=0, L2≈0.111, H1≈0.444, H2=1.0 -> L2 < H1.
          - Under PER-TYPE normalization (incorrect): each type saturates at
            its local max, so scores become L1=0, L2=1.0, H1=0, H2=1.0
            -> L2 > H1.
        """
        _require(compute_replacement_scores, "compute_replacement_scores")
        vehicles = pd.DataFrame({
            "vehicle_id": ["L1", "L2", "H1", "H2"],
            "vehicle_type": ["light_truck", "light_truck",
                             "heavy_truck", "heavy_truck"],
            "year": [2020] * 4,
            "make": ["X"] * 4,
            "model": ["Y"] * 4,
        })
        maintenance = pd.DataFrame({
            "vehicle_id": ["L1", "L2", "H1", "H2"],
            "work_order_id": [f"W{i}" for i in range(1, 5)],
            "date": ["2021-01-01"] * 4,
            "labor_cost": [100.0] * 4,
            "parts_cost": [50.0] * 4,
            "maintenance_type": ["routine"] * 4,
            "operator_id": ["OP01"] * 4,
        })
        utilization = pd.DataFrame({
            "vehicle_id": ["L1", "L2", "H1", "H2"],
            "date": ["2021-01-01"] * 4,
            "miles_driven": [100.0] * 4,
            "hours_operated": [10.0, 20.0, 50.0, 100.0],
            "route": ["R"] * 4,
            "season": ["spring"] * 4,
        })
        result = compute_replacement_scores(vehicles, maintenance, utilization)
        scores = result.set_index("vehicle_id")["replacement_score"]
        assert scores["L2"] < scores["H1"], (
            f"L2 score ({scores['L2']:.4f}) >= H1 score ({scores['H1']:.4f}); "
            f"this implies per-vehicle_type normalization rather than the "
            f"global ('across all vehicles') normalization required by the prompt"
        )

    def test_higher_cumulative_hours_yields_higher_score(self):
        """Holding all else equal, the vehicle with strictly more hours scores higher."""
        _require(compute_replacement_scores, "compute_replacement_scores")
        vehicles = pd.DataFrame({
            "vehicle_id": ["VA", "VB"],
            "vehicle_type": ["light_truck", "light_truck"],
            "year": [2015, 2015],
            "make": ["X", "X"],
            "model": ["Y", "Y"],
        })
        maintenance = pd.DataFrame({
            "vehicle_id": ["VA", "VB"],
            "work_order_id": ["W1", "W2"],
            "date": ["2021-01-01", "2021-01-01"],
            "labor_cost": [100.0, 100.0],
            "parts_cost": [50.0, 50.0],
            "maintenance_type": ["routine", "routine"],
            "operator_id": ["OP01", "OP01"],
        })
        utilization = pd.DataFrame({
            "vehicle_id": ["VA", "VA", "VB", "VB"],
            "date": ["2021-01-01", "2022-01-01", "2021-01-01", "2022-01-01"],
            "miles_driven": [100.0] * 4,
            "hours_operated": [5.0, 5.0, 20.0, 20.0],
            "route": ["R"] * 4,
            "season": ["spring"] * 4,
        })
        result = compute_replacement_scores(vehicles, maintenance, utilization)
        score_a = result.loc[result["vehicle_id"] == "VA", "replacement_score"].iloc[0]
        score_b = result.loc[result["vehicle_id"] == "VB", "replacement_score"].iloc[0]
        assert score_b > score_a

    def test_higher_total_maintenance_cost_yields_higher_score(self):
        """Holding age and hours equal, the vehicle with higher labor+parts sum scores higher."""
        _require(compute_replacement_scores, "compute_replacement_scores")
        vehicles = pd.DataFrame({
            "vehicle_id": ["VA", "VB"],
            "vehicle_type": ["light_truck", "light_truck"],
            "year": [2015, 2015],
            "make": ["X", "X"],
            "model": ["Y", "Y"],
        })
        maintenance = pd.DataFrame({
            "vehicle_id": ["VA", "VB"],
            "work_order_id": ["W1", "W2"],
            "date": ["2021-01-01", "2021-01-01"],
            "labor_cost": [50.0, 500.0],
            "parts_cost": [25.0, 250.0],
            "maintenance_type": ["routine", "routine"],
            "operator_id": ["OP01", "OP01"],
        })
        utilization = pd.DataFrame({
            "vehicle_id": ["VA", "VB"],
            "date": ["2021-01-01", "2021-01-01"],
            "miles_driven": [100.0, 100.0],
            "hours_operated": [8.0, 8.0],
            "route": ["R", "R"],
            "season": ["spring", "spring"],
        })
        result = compute_replacement_scores(vehicles, maintenance, utilization)
        score_a = result.loc[result["vehicle_id"] == "VA", "replacement_score"].iloc[0]
        score_b = result.loc[result["vehicle_id"] == "VB", "replacement_score"].iloc[0]
        assert score_b > score_a

    def test_older_vehicle_yields_higher_score(self):
        """Holding maintenance and hours equal, the older vehicle scores higher (age_years = 2024 - year)."""
        _require(compute_replacement_scores, "compute_replacement_scores")
        vehicles = pd.DataFrame({
            "vehicle_id": ["VA", "VB"],
            "vehicle_type": ["light_truck", "light_truck"],
            "year": [2020, 2010],
            "make": ["X", "X"],
            "model": ["Y", "Y"],
        })
        maintenance = pd.DataFrame({
            "vehicle_id": ["VA", "VB"],
            "work_order_id": ["W1", "W2"],
            "date": ["2021-01-01", "2021-01-01"],
            "labor_cost": [100.0, 100.0],
            "parts_cost": [50.0, 50.0],
            "maintenance_type": ["routine", "routine"],
            "operator_id": ["OP01", "OP01"],
        })
        utilization = pd.DataFrame({
            "vehicle_id": ["VA", "VB"],
            "date": ["2021-01-01", "2021-01-01"],
            "miles_driven": [100.0, 100.0],
            "hours_operated": [8.0, 8.0],
            "route": ["R", "R"],
            "season": ["spring", "spring"],
        })
        result = compute_replacement_scores(vehicles, maintenance, utilization)
        score_a = result.loc[result["vehicle_id"] == "VA", "replacement_score"].iloc[0]
        score_b = result.loc[result["vehicle_id"] == "VB", "replacement_score"].iloc[0]
        assert score_b > score_a


# ===========================================================================
# 4. attribute_maintenance_costs
# ===========================================================================

class TestAttributeMaintenanceCosts:

    def test_output_has_exactly_four_columns(self, vehicles_df, maintenance_df):
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        result = attribute_maintenance_costs(vehicles_df, maintenance_df)
        assert set(result.columns) == {"vehicle_id", "vehicle_type", "aging_cost", "operator_cost"}

    def test_one_row_per_vehicle(self, vehicles_df, maintenance_df):
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        result = attribute_maintenance_costs(vehicles_df, maintenance_df)
        assert len(result) == len(vehicles_df)

    def test_all_vehicle_ids_present(self, vehicles_df, maintenance_df):
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        result = attribute_maintenance_costs(vehicles_df, maintenance_df)
        assert set(result["vehicle_id"]) == set(vehicles_df["vehicle_id"])

    def test_vehicle_type_matches_vehicles_df(self, vehicles_df, maintenance_df):
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        result = attribute_maintenance_costs(vehicles_df, maintenance_df)
        ref = vehicles_df.set_index("vehicle_id")["vehicle_type"].to_dict()
        for _, row in result.iterrows():
            assert row["vehicle_type"] == ref[row["vehicle_id"]]

    def test_aging_cost_is_float_dtype(self, vehicles_df, maintenance_df):
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        result = attribute_maintenance_costs(vehicles_df, maintenance_df)
        assert pd.api.types.is_float_dtype(result["aging_cost"])

    def test_operator_cost_is_float_dtype(self, vehicles_df, maintenance_df):
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        result = attribute_maintenance_costs(vehicles_df, maintenance_df)
        assert pd.api.types.is_float_dtype(result["operator_cost"])

    def test_vehicle_id_and_type_are_string_dtype(self, vehicles_df, maintenance_df):
        """Prompt: 'vehicle_id (str), vehicle_type (str)' in
        attribute_maintenance_costs output."""
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        result = attribute_maintenance_costs(vehicles_df, maintenance_df)
        assert _all_str(result["vehicle_id"]), \
            "attribute_maintenance_costs output 'vehicle_id' is not str-typed"
        assert _all_str(result["vehicle_type"]), \
            "attribute_maintenance_costs output 'vehicle_type' is not str-typed"

    def test_regression_target_is_labor_plus_parts(self):
        """Prompt: 'For each vehicle compute total_maintenance_cost as the sum
        of (labor_cost + parts_cost)' (Maintenance Cost Attribution).

        Comparing equal-total / different-decomposition vehicles does NOT
        distinguish labor+parts from labor-only here, because the regression
        gives identical predictions to vehicles with identical features. We
        instead engineer the GLOBAL age_coef by constructing data where, per
        vehicle, labor = 25*age and parts = 75*age (so total = 100*age). With a
        single vehicle_type and single primary_operator (dummies vanish under
        drop_first=True), the regression reduces to y = age_coef * age_years.
        - Under labor + parts (correct):  y = 100*age -> age_coef = 100,
          aging_cost(V1) = 100 * 4 = 400.
        - Under labor only (incorrect):   y =  25*age -> age_coef =  25,
          aging_cost(V1) =  25 * 4 = 100.
        - Under parts only (incorrect):   y =  75*age -> age_coef =  75,
          aging_cost(V1) =  75 * 4 = 300.
        Asserting aging_cost(V1) ~ 400 with rtol 5% rejects all three
        single-column variants while accepting any correct implementation.
        """
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        ages = [4, 6, 8, 10]
        vehicles = pd.DataFrame({
            "vehicle_id": ["V1", "V2", "V3", "V4"],
            "vehicle_type": ["light_truck"] * 4,
            "year": [2024 - a for a in ages],
            "make": ["X"] * 4,
            "model": ["Y"] * 4,
        })
        rows = []
        for vid, age in zip(["V1", "V2", "V3", "V4"], ages):
            rows.append({
                "vehicle_id": vid,
                "work_order_id": f"W_{vid}",
                "date": "2021-01-01",
                "labor_cost": 25.0 * age,
                "parts_cost": 75.0 * age,
                "maintenance_type": "routine",
                "operator_id": "OP01",
            })
        maintenance = pd.DataFrame(rows)
        result = attribute_maintenance_costs(vehicles, maintenance)
        aging = result.set_index("vehicle_id")["aging_cost"]
        assert np.isclose(aging["V1"], 400.0, rtol=0.05), (
            f"V1 aging_cost = {aging['V1']:.2f}, expected ~400 under "
            f"total_maintenance_cost = labor_cost + parts_cost. The fitted "
            f"age coefficient implies the regression target was not the "
            f"prompt-required labor+parts sum"
        )

    def test_aging_cost_proportional_to_age_years(self, vehicles_df, maintenance_df):
        """aging_cost = age_coef * age_years => aging_cost / age_years is constant for all vehicles."""
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        result = attribute_maintenance_costs(vehicles_df, maintenance_df)
        merged = result.merge(vehicles_df[["vehicle_id", "year"]], on="vehicle_id")
        merged["age_years"] = 2024 - merged["year"]
        ratios = merged["aging_cost"] / merged["age_years"]
        assert np.allclose(ratios, ratios.iloc[0], rtol=1e-4), \
            "aging_cost is not proportional to age_years -- age_coef is not constant"

    def test_base_category_primary_yields_zero_operator_cost(self):
        """With drop_first=True, the alphabetically-first operator category
        ('OP_A' in this fixture) is dropped. Vehicles whose primary_operator_id
        equals that dropped category have an all-zeros one-hot vector, so
        operator_cost = dot(coefs, zero_vector) = 0.0 by definition. An
        implementation that uses drop_first=False -- or that adds the model
        intercept into operator_cost -- would produce a non-zero but
        internally-consistent value (and thus pass the same-primary-equal-cost
        and alphabetical-tiebreak tests) while violating this constraint.
        """
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        vehicles = pd.DataFrame({
            "vehicle_id": ["VA", "VB", "VC", "VD", "VE", "VF"],
            "vehicle_type": ["light_truck"] * 6,
            "year": [2010, 2012, 2014, 2016, 2018, 2020],
            "make": ["X"] * 6,
            "model": ["Y"] * 6,
        })
        per_record_cost = {
            "VA": 50.0, "VB": 50.0,
            "VC": 200.0, "VD": 200.0,
            "VE": 120.0, "VF": 120.0,
        }
        op_assignments = {
            "VA": ["OP_A"] * 4, "VB": ["OP_A"] * 4,
            "VC": ["OP_B"] * 4, "VD": ["OP_B"] * 4,
            "VE": ["OP_C"] * 4, "VF": ["OP_C"] * 4,
        }
        rows = []
        wid = 1
        for vid, ops in op_assignments.items():
            for op in ops:
                rows.append({
                    "vehicle_id": vid,
                    "work_order_id": f"W{wid:03d}",
                    "date": "2021-01-01",
                    "labor_cost": per_record_cost[vid] / 2,
                    "parts_cost": per_record_cost[vid] / 2,
                    "maintenance_type": "routine",
                    "operator_id": op,
                })
                wid += 1
        maintenance = pd.DataFrame(rows)
        result = attribute_maintenance_costs(vehicles, maintenance)
        cost = result.set_index("vehicle_id")["operator_cost"]
        for vid in ("VA", "VB"):
            assert np.isclose(cost[vid], 0.0, atol=1e-3), (
                f"{vid}'s operator_cost is {cost[vid]:.4f}, expected 0.0 since "
                f"primary='OP_A' is the dropped base category under drop_first=True"
            )

    def test_primary_operator_id_uses_alphabetical_tiebreak(self):
        """
        VC's maintenance has a tied count between OP_A and OP_B; the spec breaks ties
        alphabetically, so VC's primary_operator_id must be OP_A. With drop_first=True
        and totals consistent across each primary group, vehicles whose primary is the
        dropped category share the same operator_cost. If the implementation broke ties
        differently, VC would land in a different category and its operator_cost would
        diverge from VA/VB.
        """
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        vehicles = pd.DataFrame({
            "vehicle_id": ["VA", "VB", "VC", "VD", "VE", "VF"],
            "vehicle_type": ["light_truck"] * 6,
            "year": [2010, 2012, 2014, 2016, 2018, 2020],
            "make": ["X"] * 6,
            "model": ["Y"] * 6,
        })
        per_record_cost = {
            "VA": 50.0, "VB": 50.0, "VC": 50.0,
            "VD": 200.0, "VE": 200.0, 
            "VF": 120.0,
        }
        op_assignments = {
            "VA": ["OP_A", "OP_A", "OP_A", "OP_C"],
            "VB": ["OP_A", "OP_A", "OP_A", "OP_B"],
            "VC": ["OP_A", "OP_A", "OP_B", "OP_B"],
            "VD": ["OP_B", "OP_B", "OP_B", "OP_A"],
            "VE": ["OP_B", "OP_B", "OP_B", "OP_C"],
            "VF": ["OP_C", "OP_C", "OP_C", "OP_A"],
        }
        rows = []
        wid = 1
        for vid, ops in op_assignments.items():
            for op in ops:
                rows.append({
                    "vehicle_id": vid,
                    "work_order_id": f"W{wid:03d}",
                    "date": "2021-01-01",
                    "labor_cost": per_record_cost[vid] / 2,
                    "parts_cost": per_record_cost[vid] / 2,
                    "maintenance_type": "routine",
                    "operator_id": op,
                })
                wid += 1
        maintenance = pd.DataFrame(rows)
        result = attribute_maintenance_costs(vehicles, maintenance)
        cost = result.set_index("vehicle_id")["operator_cost"]
        assert np.isclose(cost["VC"], cost["VA"], rtol=1e-3, atol=1e-3), \
            "VC's operator_cost differs from VA's -- alphabetical tiebreak likely not applied"
        assert np.isclose(cost["VC"], cost["VB"], rtol=1e-3, atol=1e-3), \
            "VC's operator_cost differs from VB's -- alphabetical tiebreak likely not applied"

    def test_same_primary_operator_yields_same_operator_cost(self, vehicles_df, maintenance_df):
        """
        operator_cost = dot(operator_dummy_coefs, primary_operator_id_one_hot).
        All vehicles whose primary_operator_id is identical get the same one-hot vector,
        hence the same operator_cost.
        """
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        result = attribute_maintenance_costs(vehicles_df, maintenance_df)
        primary = (maintenance_df
                   .groupby("vehicle_id")["operator_id"]
                   .apply(_primary_op)
                   .rename("primary_op")
                   .reset_index())
        merged = result.merge(primary, on="vehicle_id")
        for op, grp in merged.groupby("primary_op"):
            costs = grp["operator_cost"].values
            assert np.allclose(costs, costs[0], rtol=1e-4), \
                f"Vehicles with primary_operator_id='{op}' have differing operator_cost values"


# ===========================================================================
# 5. model_fuel_consumption
# ===========================================================================

class TestModelFuelConsumption:

    def test_output_has_exactly_three_columns(self, fuel_df):
        _require(model_fuel_consumption, "model_fuel_consumption")
        result = model_fuel_consumption(fuel_df)
        assert set(result.columns) == {"route", "season", "predicted_gallons_per_mile"}

    def test_one_row_per_unique_route_season_combination(self, fuel_df):
        _require(model_fuel_consumption, "model_fuel_consumption")
        result = model_fuel_consumption(fuel_df)
        n_expected = fuel_df[["route", "season"]].drop_duplicates().shape[0]
        assert len(result) == n_expected

    def test_all_route_season_combinations_present(self, fuel_df):
        _require(model_fuel_consumption, "model_fuel_consumption")
        result = model_fuel_consumption(fuel_df)
        expected = set(map(tuple, fuel_df[["route", "season"]].drop_duplicates().values))
        actual = set(zip(result["route"], result["season"]))
        assert expected == actual

    def test_predicted_gallons_per_mile_is_float_dtype(self, fuel_df):
        _require(model_fuel_consumption, "model_fuel_consumption")
        result = model_fuel_consumption(fuel_df)
        assert pd.api.types.is_float_dtype(result["predicted_gallons_per_mile"])

    def test_route_and_season_are_string_dtype(self, fuel_df):
        """Prompt: 'route (str), season (str)' in model_fuel_consumption output."""
        _require(model_fuel_consumption, "model_fuel_consumption")
        result = model_fuel_consumption(fuel_df)
        assert _all_str(result["route"]), \
            "model_fuel_consumption output 'route' is not str-typed"
        assert _all_str(result["season"]), \
            "model_fuel_consumption output 'season' is not str-typed"

    def test_route_specific_consumption_rates_are_differentiated(self):
        """When ROUTE_A records consistently have ratio R_A and ROUTE_B records
        consistently have R_B (with R_A != R_B), the fitted model must
        differentiate: predictions for ROUTE_A pairs should be near R_A and for
        ROUTE_B pairs near R_B. An implementation that returns the global mean
        (or any single number) for every pair would land at (R_A + R_B) / 2 and
        fail this test.
        """
        _require(model_fuel_consumption, "model_fuel_consumption")
        R_A, R_B = 0.10, 0.25
        rows = []
        for route, rate in [("ROUTE_A", R_A), ("ROUTE_B", R_B)]:
            for season in ["spring", "summer", "fall", "winter"]:
                for rep in range(5):
                    rows.append({
                        "vehicle_id": "V001",
                        "date": f"2021-01-{rep + 1:02d}",
                        "fuel_gallons": rate * 100.0,
                        "miles_driven": 100.0,
                        "route": route,
                        "season": season,
                    })
        df = pd.DataFrame(rows)
        result = model_fuel_consumption(df)
        for _, row in result.iterrows():
            expected = R_A if row["route"] == "ROUTE_A" else R_B
            assert abs(row["predicted_gallons_per_mile"] - expected) < 0.02, (
                f"({row['route']}, {row['season']}) predicted "
                f"{row['predicted_gallons_per_mile']:.4f}, expected ~{expected}; "
                f"the fitted model is not differentiating across routes"
            )

    def test_constant_consumption_rate_yields_constant_predictions(self):
        """consumption_rate = fuel_gallons / miles_driven.

        When every fuel record has the identical ratio R, the regression must
        learn y == R and predict R for every (route, season). An implementation
        that mistakenly uses miles/fuel, fuel alone, or any other definition of
        consumption_rate yields predictions far from R.
        """
        _require(model_fuel_consumption, "model_fuel_consumption")
        rows = []
        for route in ["ROUTE_A", "ROUTE_B"]:
            for season in ["spring", "summer", "fall", "winter"]:
                for rep in range(5):
                    rows.append({
                        "vehicle_id": "V001",
                        "date": f"2021-01-{rep + 1:02d}",
                        "fuel_gallons": 5.0,
                        "miles_driven": 50.0,
                        "route": route,
                        "season": season,
                    })
        df = pd.DataFrame(rows)
        result = model_fuel_consumption(df)
        assert np.allclose(result["predicted_gallons_per_mile"], 0.1, atol=1e-3), \
            "predicted_gallons_per_mile is not ~0.1 for constant fuel/miles ratio of 0.1"


# ===========================================================================
# 6. generate_fleet_report
# ===========================================================================

class TestGenerateFleetReport:

    def test_creates_parent_directory_if_absent(self, replacement_df, attribution_df, fuel_model_df, tmp_path):
        _require(generate_fleet_report, "generate_fleet_report")
        deep = str(tmp_path / "a" / "b" / "c" / "report.txt")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, deep)
        assert os.path.exists(deep)

    def test_flagged_vehicle_ids_appear_in_section1(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        sec1, _, _ = _get_sections(tmp_output)
        assert sec1, "Section 1 body is empty or the header was not found"
        for vid in replacement_df.loc[replacement_df["flagged"], "vehicle_id"]:
            assert vid in sec1, f"Flagged vehicle '{vid}' not found in REPLACEMENT CANDIDATES"

    def test_unflagged_vehicle_ids_absent_from_section1(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        sec1, _, _ = _get_sections(tmp_output)
        for vid in replacement_df.loc[~replacement_df["flagged"], "vehicle_id"]:
            assert vid not in sec1, \
                f"Unflagged vehicle '{vid}' must not appear in REPLACEMENT CANDIDATES"

    def test_section1_lines_in_descending_score_order(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        sec1, _, _ = _get_sections(tmp_output)
        scores = []
        for line in sec1.splitlines():
            line = line.strip()
            if not line:
                continue
            nums = re.findall(r"-?\d+\.\d+", line)
            if nums:
                scores.append(float(nums[-1]))
        assert len(scores) > 0, "No numeric scores found in section 1"
        assert scores == sorted(scores, reverse=True), \
            "Section 1 lines are not in descending replacement_score order"

    def test_all_vehicle_types_appear_in_section2(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        _, sec2, _ = _get_sections(tmp_output)
        assert sec2, "Section 2 body is empty or the header was not found"
        for vtype in attribution_df["vehicle_type"].unique():
            assert vtype in sec2, \
                f"vehicle_type '{vtype}' not found in MAINTENANCE COST ATTRIBUTION"

    def test_section2_vehicle_types_in_alphabetical_order(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        _, sec2, _ = _get_sections(tmp_output)
        valid = set(attribution_df["vehicle_type"].unique())
        found = []
        for line in sec2.splitlines():
            first = line.strip().split()[0] if line.strip() else ""
            if first in valid:
                found.append(first)
        assert found == sorted(found), \
            "Section 2 vehicle_types are not in alphabetical order"

    def test_all_route_season_pairs_appear_in_section3(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        """Prompt: 'One line per unique (route, season) combination in the
        format: route season: predicted_gallons_per_mile ...' (Section 3).

        Verifies route and season co-occur on the same line, not merely that
        each substring appears somewhere in the section (which would pass
        spuriously when both tokens happen to appear in OTHER pairs' lines).
        """
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        _, _, sec3 = _get_sections(tmp_output)
        assert sec3, "Section 3 body is empty or the header was not found"
        for _, row in fuel_model_df.iterrows():
            pattern = re.compile(
                rf"{re.escape(str(row['route']))}\s+{re.escape(str(row['season']))}\b"
            )
            assert pattern.search(sec3), (
                f"({row['route']}, {row['season']}) not found as a co-occurring "
                f"pair on any line in FUEL CONSUMPTION MODEL"
            )

    def test_section3_route_season_pairs_in_correct_order(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        _, _, sec3 = _get_sections(tmp_output)
        all_routes = set(fuel_model_df["route"])
        all_seasons = set(fuel_model_df["season"])
        extracted = []
        for line in sec3.splitlines():
            line = line.strip()
            if not line:
                continue
            colon_idx = line.find(":")
            if colon_idx > 0:
                left_parts = line[:colon_idx].strip().split()
                if len(left_parts) >= 2:
                    r, s = left_parts[0], left_parts[1]
                    if r in all_routes and s in all_seasons:
                        extracted.append((r, s))
        expected = sorted(
            set(zip(fuel_model_df["route"], fuel_model_df["season"])),
            key=lambda x: (x[0], x[1]),
        )
        assert extracted == expected, \
            "Section 3 (route, season) pairs are not in alphabetical route-then-season order"

    def test_section1_no_duplicate_flagged_vehicle_lines(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        """Prompt: 'One line per vehicle where flagged is True'. Each flagged
        vehicle_id must appear exactly once in section 1; duplicate emission
        violates the cardinality constraint.
        """
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        sec1, _, _ = _get_sections(tmp_output)
        for vid in replacement_df.loc[replacement_df["flagged"], "vehicle_id"]:
            count = len(re.findall(rf"\b{re.escape(vid)}\b", sec1))
            assert count == 1, \
                f"vehicle_id '{vid}' appears {count} times in section 1, expected exactly 1"

    def test_section2_no_duplicate_vehicle_type_lines(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        """Prompt: 'One line per vehicle_type'. Each unique vehicle_type must
        appear exactly once in section 2; duplicate emission violates the
        cardinality constraint.
        """
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        _, sec2, _ = _get_sections(tmp_output)
        for vtype in attribution_df["vehicle_type"].unique():
            count = len(re.findall(rf"\b{re.escape(vtype)}\b", sec2))
            assert count == 1, \
                f"vehicle_type '{vtype}' appears {count} times in section 2, expected exactly 1"

    def test_section3_no_duplicate_route_season_lines(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        """Prompt: 'One line per unique (route, season) combination'. Each
        unique pair must appear exactly once in section 3; duplicate emission
        violates the cardinality constraint.
        """
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        _, _, sec3 = _get_sections(tmp_output)
        for _, row in fuel_model_df.iterrows():
            pattern = rf"\b{re.escape(row['route'])}\s+{re.escape(row['season'])}\b"
            count = len(re.findall(pattern, sec3))
            assert count == 1, (
                f"({row['route']}, {row['season']}) appears {count} times "
                f"in section 3, expected exactly 1"
            )

    def test_section1_format_and_value_correctness(self, replacement_df, attribution_df, fuel_model_df, tmp_output):
        """Section 1 lines must follow 'vehicle_id: replacement_score' with the
        score rounded to exactly 2 decimal places and equal to the input score
        from replacement_df. Catches:
          - implementations that omit the colon-separated format,
          - implementations that emit arbitrary descending numbers,
          - implementations that round to 0/1/3+ decimal places.
        """
        _require(generate_fleet_report, "generate_fleet_report")
        generate_fleet_report(replacement_df, attribution_df, fuel_model_df, tmp_output)
        sec1, _, _ = _get_sections(tmp_output)
        for _, row in replacement_df[replacement_df["flagged"]].iterrows():
            m = re.search(
                rf"{re.escape(row['vehicle_id'])}\s*:\s*(-?\d+\.\d{{2}})(?!\d)",
                sec1,
            )
            assert m is not None, (
                f"Section 1 line for '{row['vehicle_id']}' does not match the prompt's "
                f"format 'vehicle_id: <score with exactly 2 decimal places>'"
            )
            assert abs(float(m.group(1)) - row["replacement_score"]) < 5e-3, (
                f"Section 1 score for '{row['vehicle_id']}' is "
                f"{m.group(1)} but the input replacement_score is {row['replacement_score']}"
            )

    def test_section2_aggregates_costs_per_vehicle_type(self, replacement_df, fuel_model_df, tmp_output):
        """X and Y in section 2 must be the SUM of aging_cost and operator_cost
        across all vehicles of that vehicle_type, per the prompt's stated format.
        """
        _require(generate_fleet_report, "generate_fleet_report")
        attribution = pd.DataFrame({
            "vehicle_id": ["V1", "V2", "V3", "V4", "V5"],
            "vehicle_type": ["light_truck", "light_truck",
                             "heavy_truck", "heavy_truck", "snow_plow"],
            "aging_cost":   [100.0, 200.0,  50.0, 150.0,  80.0],
            "operator_cost": [10.0,  20.0,  -5.0,  15.0,   7.0],
        })
        expected = {
            "light_truck": (300.00, 30.00),
            "heavy_truck": (200.00, 10.00),
            "snow_plow":   ( 80.00,  7.00),
        }
        generate_fleet_report(replacement_df, attribution, fuel_model_df, tmp_output)
        _, sec2, _ = _get_sections(tmp_output)
        for vtype, (sum_aging, sum_op) in expected.items():
            m = re.search(
                rf"{re.escape(vtype)}\b[^\n]*?aging_cost:\s*(-?\d+\.\d{{2}})(?!\d)"
                rf"[^\n]*?operator_cost:\s*(-?\d+\.\d{{2}})(?!\d)",
                sec2,
            )
            assert m is not None, (
                f"Section 2 line for '{vtype}' does not match the prompt's format "
                f"'vehicle_type aging_cost: X operator_cost: Y' with X and Y "
                f"rounded to exactly 2 decimal places"
            )
            assert abs(float(m.group(1)) - sum_aging) < 5e-3, \
                f"{vtype}: aging_cost shown is not the sum across that vehicle_type"
            assert abs(float(m.group(2)) - sum_op) < 5e-3, \
                f"{vtype}: operator_cost shown is not the sum across that vehicle_type"

    def test_section3_contains_predicted_values_per_pair(self, replacement_df, attribution_df, tmp_output):
        """Each (route, season) line in section 3 must report that pair's
        predicted_gallons_per_mile rounded to exactly 4 decimal places, equal
        to the input value. The strict 4-decimal regex + 5e-5 tolerance rejects
        implementations that round to 2 or 3 decimals.
        """
        _require(generate_fleet_report, "generate_fleet_report")
        fuel_model = pd.DataFrame({
            "route":  ["ROUTE_A", "ROUTE_A", "ROUTE_B", "ROUTE_B"],
            "season": ["spring",  "winter",  "summer",  "fall"],
            "predicted_gallons_per_mile": [0.1234, 0.2345, 0.3456, 0.4567],
        })
        generate_fleet_report(replacement_df, attribution_df, fuel_model, tmp_output)
        _, _, sec3 = _get_sections(tmp_output)
        for _, row in fuel_model.iterrows():
            m = re.search(
                rf"{re.escape(row['route'])}\s+{re.escape(row['season'])}[^\n]*?"
                rf"(-?\d+\.\d{{4}})(?!\d)",
                sec3,
            )
            assert m is not None, (
                f"({row['route']}, {row['season']}) line not found in section 3 with "
                f"a value formatted to exactly 4 decimal places"
            )
            assert abs(float(m.group(1)) - row["predicted_gallons_per_mile"]) < 5e-5, (
                f"({row['route']}, {row['season']}): predicted value "
                f"{m.group(1)} differs from input {row['predicted_gallons_per_mile']}"
            )


# ===========================================================================
# 7. run_pipeline
# ===========================================================================

class TestRunPipeline:

    def test_run_pipeline_equivalent_to_manual_composition(self, data_dir, tmp_path):
        """Prompt: 'Produces a report at output_path whose contents are
        equivalent to invoking generate_fleet_report on the outputs of
        compute_replacement_scores, attribute_maintenance_costs, and
        model_fuel_consumption applied to the data loaded from data_dir.'

        Every numeric token in run_pipeline's output -- including its decimal
        precision -- must match the corresponding token produced by the manual
        composition. Catches implementations that emit truncated, mis-rounded,
        or otherwise garbled numeric strings even when individual sections
        appear structurally well-formed.
        """
        _require(run_pipeline, "run_pipeline")
        _require(load_fleet_data, "load_fleet_data")
        _require(compute_replacement_scores, "compute_replacement_scores")
        _require(attribute_maintenance_costs, "attribute_maintenance_costs")
        _require(model_fuel_consumption, "model_fuel_consumption")
        _require(generate_fleet_report, "generate_fleet_report")

        auto = tmp_path / "auto" / "report.txt"
        manual = tmp_path / "manual" / "report.txt"

        run_pipeline(data_dir, str(auto))

        data = load_fleet_data(data_dir)
        rep = compute_replacement_scores(
            data["vehicles"], data["maintenance"], data["utilization"]
        )
        attr = attribute_maintenance_costs(data["vehicles"], data["maintenance"])
        fuel = model_fuel_consumption(data["fuel"])
        generate_fleet_report(rep, attr, fuel, str(manual))

        token = re.compile(r"-?\d+\.\d+")
        auto_nums = token.findall(Path(auto).read_text())
        manual_nums = token.findall(Path(manual).read_text())
        assert auto_nums == manual_nums, (
            f"run_pipeline numeric output differs from the manual composition "
            f"of the four pipeline functions.\n"
            f"  run_pipeline produced {len(auto_nums)} numeric tokens; "
            f"manual produced {len(manual_nums)}.\n"
            f"  first divergence: auto={auto_nums[:8]} vs manual={manual_nums[:8]}"
        )

    def test_section_contents_reflect_loaded_data(
        self, data_dir, tmp_output, vehicles_df, fuel_df,
    ):
        """run_pipeline must produce a report whose section bodies actually
        reflect the data in data_dir, not just the static section headers.
        Catches degenerate implementations that write only the three headers
        without invoking the pipeline functions.
        """
        _require(run_pipeline, "run_pipeline")
        run_pipeline(data_dir, tmp_output)
        sec1, sec2, sec3 = _get_sections(tmp_output)

        for vtype in vehicles_df["vehicle_type"].unique():
            assert vtype in sec2, (
                f"vehicle_type '{vtype}' missing from MAINTENANCE COST ATTRIBUTION; "
                f"run_pipeline likely did not invoke attribute_maintenance_costs"
            )

        for _, row in fuel_df[["route", "season"]].drop_duplicates().iterrows():
            assert re.search(
                rf"{re.escape(row['route'])}\s+{re.escape(row['season'])}",
                sec3,
            ), (
                f"({row['route']}, {row['season']}) missing from FUEL CONSUMPTION "
                f"MODEL; run_pipeline likely did not invoke model_fuel_consumption"
            )

        vehicle_ids = list(vehicles_df["vehicle_id"])
        assert any(vid in sec1 for vid in vehicle_ids), (
            "REPLACEMENT CANDIDATES contains no vehicle_id from the loaded "
            "data; run_pipeline likely did not invoke compute_replacement_scores"
        )


# ===========================================================================
# 8. CLI entry point
# ===========================================================================

class TestCLI:

    def test_cli_exits_with_zero_return_code(self, data_dir, tmp_path):
        output = str(tmp_path / "cli_out" / "report.txt")
        result = subprocess.run(
            [sys.executable, "pipeline.py", data_dir, output],
            capture_output=True,
        )
        assert result.returncode == 0, \
            f"CLI exited with code {result.returncode}. stderr: {result.stderr.decode()}"

    def test_cli_creates_output_file(self, data_dir, tmp_path):
        output = str(tmp_path / "cli_out2" / "report.txt")
        subprocess.run(
            [sys.executable, "pipeline.py", data_dir, output],
            capture_output=True,
        )
        assert os.path.exists(output), "CLI did not create the output file"