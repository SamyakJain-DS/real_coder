"""
F2P test suite for the clustering analysis pipeline.

Imports of the clustering package are deferred inside a session-scoped
fixture so that on an empty repository pytest reports individual tests as
FAILED (not ERROR). Only standard library and third-party packages that
are always available are imported at module level.
"""

import importlib
import math
import os
import re
import sys

import numpy as np
import pandas as pd
import pytest

_TEST_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.join(_TEST_DIR, "..")
sys.path.insert(0, _PARENT_DIR)


# ---------------------------------------------------------------------------
# Lazy-import fixture
# Converts ImportError into pytest.fail() so every dependent test is
# reported as FAILED (not ERROR) when the codebase is empty.
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def fn():
    """
    Session-scoped namespace of all public pipeline callables.
    On an empty repository pytest.fail() is called, which marks every
    dependent test as FAILED rather than raising a collection ERROR.
    """
    try:
        preprocessing  = importlib.import_module("clustering.preprocessing")
        clustering_mod = importlib.import_module("clustering.clustering")
        selection_mod  = importlib.import_module("clustering.selection")
        evaluation_mod = importlib.import_module("clustering.evaluation")
        profiling_mod  = importlib.import_module("clustering.profiling")
        pipeline_mod   = importlib.import_module("clustering.pipeline")
    except ImportError as exc:
        return None

    class _Fn:
        preprocess_data     = staticmethod(preprocessing.preprocess_data)
        run_kmeans          = staticmethod(clustering_mod.run_kmeans)
        run_dbscan          = staticmethod(clustering_mod.run_dbscan)
        run_agglomerative   = staticmethod(clustering_mod.run_agglomerative)
        run_gmm             = staticmethod(clustering_mod.run_gmm)
        select_k            = staticmethod(selection_mod.select_k)
        evaluate_clustering = staticmethod(evaluation_mod.evaluate_clustering)
        profile_clusters    = staticmethod(profiling_mod.profile_clusters)
        run_pipeline        = staticmethod(pipeline_mod.run_pipeline)

    return _Fn()


# ---------------------------------------------------------------------------
# Data fixtures  (no clustering imports — always loadable)
# ---------------------------------------------------------------------------

@pytest.fixture
def simple_numeric_csv(tmp_path):
    df = pd.DataFrame({
        "a": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0],
        "b": [10.0, 9.0, 8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0],
        "c": [1.0, 1.0, 2.0, 2.0, 3.0, 3.0, 4.0, 4.0, 5.0, 5.0],
    })
    path = tmp_path / "numeric.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def mixed_csv(tmp_path):
    df = pd.DataFrame({
        "num1": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0],
        "num2": [8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0],
        "cat1": ["A", "B", "A", "B", "A", "B", "A", "B"],
    })
    path = tmp_path / "mixed.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def missing_values_csv(tmp_path):
    df = pd.DataFrame({
        "num1": [1.0, None, 3.0, 4.0, None, 6.0, 7.0, 8.0, 9.0, 10.0],
        "num2": [None, 2.0, 3.0, None, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0],
        "cat1": ["A", "B", None, "A", "B", None, "A", "B", "A", "B"],
    })
    path = tmp_path / "missing.csv"
    df.to_csv(path, index=False)
    return str(path)


@pytest.fixture
def clustered_X():
    """Well-separated 2D data with 3 natural clusters (60 points)."""
    rng = np.random.default_rng(42)
    c1 = rng.normal(loc=[0, 0], scale=0.3, size=(20, 2))
    c2 = rng.normal(loc=[5, 5], scale=0.3, size=(20, 2))
    c3 = rng.normal(loc=[0, 5], scale=0.3, size=(20, 2))
    return np.vstack([c1, c2, c3])


@pytest.fixture
def sample_data_csv_path():
    return os.path.join(_PARENT_DIR, "data", "sample_data.csv")


@pytest.fixture
def pipeline_config(tmp_path):
    return {
        "pca_variance_threshold": 0.95,
        "dbscan_min_samples": 3,
        "agglomerative_n_clusters": 3,
        "agglomerative_linkage": "ward",
        "agglomerative_truncate_level": 5,
        "gmm_covariance_type": "full",
        "k_range": [2, 3, 4],
        "output_dir": str(tmp_path),
    }


# ---------------------------------------------------------------------------
# Bundled Dataset
# ---------------------------------------------------------------------------

class TestBundledDataset:

    def test_sample_data_csv_exists(self, sample_data_csv_path):
        assert os.path.isfile(sample_data_csv_path)

    def test_sample_data_csv_is_readable_and_nonempty(self, sample_data_csv_path):
        if not os.path.isfile(sample_data_csv_path):
            pytest.fail("sample_data.csv does not exist")
        df = pd.read_csv(sample_data_csv_path)
        assert len(df) > 0
        assert len(df.columns) > 0


# ---------------------------------------------------------------------------
# preprocess_data
# ---------------------------------------------------------------------------

class TestPreprocessData:

    def test_returns_numpy_ndarray(self, fn, simple_numeric_csv):
        assert isinstance(fn.preprocess_data(simple_numeric_csv, 0.95), np.ndarray)

    def test_output_is_2d(self, fn, simple_numeric_csv):
        assert fn.preprocess_data(simple_numeric_csv, 0.95).ndim == 2

    def test_row_count_matches_input(self, fn, simple_numeric_csv):
        n_rows = len(pd.read_csv(simple_numeric_csv))
        assert fn.preprocess_data(simple_numeric_csv, 0.95).shape[0] == n_rows

    def test_pca_reduces_or_preserves_dimensionality(self, fn, simple_numeric_csv):
        n_cols = len(pd.read_csv(simple_numeric_csv).columns)
        assert fn.preprocess_data(simple_numeric_csv, 0.95).shape[1] <= n_cols

    def test_higher_variance_threshold_retains_at_least_as_many_components(self, fn, simple_numeric_csv):
        low  = fn.preprocess_data(simple_numeric_csv, 0.50)
        high = fn.preprocess_data(simple_numeric_csv, 0.99)
        assert high.shape[1] >= low.shape[1]

    def test_missing_values_imputed_no_nan_in_output(self, fn, missing_values_csv):
        result = fn.preprocess_data(missing_values_csv, 0.95)
        assert not np.any(np.isnan(result))

    def test_categorical_columns_row_count_preserved(self, fn, mixed_csv):
        n_rows = len(pd.read_csv(mixed_csv))
        assert fn.preprocess_data(mixed_csv, 0.95).shape[0] == n_rows

    def test_z_score_normalization_yields_near_zero_column_means(self, fn, simple_numeric_csv):
        """
        Z-score normalization sets each numeric feature mean to 0 before PCA.
        Since PCA is a linear map applied to zero-mean data, each output
        component also has mean 0 to within floating-point tolerance.
        """
        result = fn.preprocess_data(simple_numeric_csv, 0.99)
        assert np.allclose(result.mean(axis=0), 0, atol=1e-7)

    def test_one_hot_encoding_expands_feature_space(self, fn, tmp_path):
        """
        OHE must add binary indicator columns for categorical levels.
        A CSV with 1 numeric + 1 categorical column (2 levels) must
        produce strictly more PCA components than a numeric-only CSV
        with the same single numeric column (threshold=1.0 keeps all).
        """
        df_num = pd.DataFrame({"x": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0]})
        path_num = str(tmp_path / "num_only.csv")
        df_num.to_csv(path_num, index=False)

        df_mix = pd.DataFrame({
            "x":   [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0],
            "cat": ["A", "B", "A", "B", "A", "B", "A", "B"],
        })
        path_mix = str(tmp_path / "mix_ohe.csv")
        df_mix.to_csv(path_mix, index=False)

        result_num = fn.preprocess_data(path_num, 1.0)
        result_mix = fn.preprocess_data(path_mix, 1.0)

        assert result_mix.shape[1] > result_num.shape[1]
    
    def test_numeric_imputation_uses_median_not_mean(self, fn, tmp_path):
        """
        Mean imputation produces z-score = 0.0 at the imputed position because
        z-scoring normalizes each column mean to 0. Median imputation produces
        a non-zero z-score when median != mean (skewed distribution).
        Values [5, NaN, 15, 15, 100]: median=15, mean=33.75 — clearly distinct.
        """
        df = pd.DataFrame({"val": [5.0, np.nan, 15.0, 15.0, 100.0]})
        path = str(tmp_path / "median_check.csv")
        df.to_csv(path, index=False)
        result = fn.preprocess_data(path, 1.0)
        # With median (15.0): z-scored imputed value ≈ ±0.39 (non-zero)
        # With mean (33.75): z-scored imputed value = 0.0
        assert abs(result[1, 0]) > 0.01

    def test_categorical_imputation_uses_mode(self, fn, tmp_path):
        """
        Mode imputation fills a missing categorical value with the most frequent
        category. With column ["A","A","A",NaN,"B"] the mode is "A".
        After OHE+PCA the imputed row (index 3) must project to the same side
        of the principal axis as the majority "A" rows, not the minority "B" row.
        Any non-mode strategy (e.g. least-frequent, forward-fill) would place
        row 3 on the "B" side, causing the assertion to fail.
        """
        df = pd.DataFrame({"cat": ["A", "A", "A", None, "B"]})
        path = str(tmp_path / "cat_mode.csv")
        df.to_csv(path, index=False)
        result = fn.preprocess_data(path, 1.0)
        majority_centroid = result[[0, 1, 2], 0].mean()
        minority_val = result[4, 0]
        imputed_val = result[3, 0]
        assert abs(imputed_val - majority_centroid) < abs(imputed_val - minority_val)


# ---------------------------------------------------------------------------
# run_kmeans
# ---------------------------------------------------------------------------

class TestRunKmeans:

    def test_returns_numpy_ndarray(self, fn, clustered_X):
        assert isinstance(fn.run_kmeans(clustered_X, k=3), np.ndarray)

    def test_output_is_1d(self, fn, clustered_X):
        assert fn.run_kmeans(clustered_X, k=3).ndim == 1

    def test_output_length_matches_input_rows(self, fn, clustered_X):
        assert len(fn.run_kmeans(clustered_X, k=3)) == clustered_X.shape[0]

    def test_labels_are_integer_dtype(self, fn, clustered_X):
        assert np.issubdtype(fn.run_kmeans(clustered_X, k=3).dtype, np.integer)

    def test_label_values_in_valid_range(self, fn, clustered_X):
        k = 3
        labels = fn.run_kmeans(clustered_X, k=k)
        assert labels.min() >= 0
        assert labels.max() < k

    def test_produces_exactly_k_unique_labels(self, fn, clustered_X):
        k = 3
        assert len(np.unique(fn.run_kmeans(clustered_X, k=k))) == k


# ---------------------------------------------------------------------------
# run_dbscan
# ---------------------------------------------------------------------------

class TestRunDbscan:

    def test_returns_numpy_ndarray(self, fn, clustered_X):
        assert isinstance(fn.run_dbscan(clustered_X, min_samples=3), np.ndarray)

    def test_output_is_1d(self, fn, clustered_X):
        assert fn.run_dbscan(clustered_X, min_samples=3).ndim == 1

    def test_output_length_matches_input_rows(self, fn, clustered_X):
        assert len(fn.run_dbscan(clustered_X, min_samples=3)) == clustered_X.shape[0]

    def test_labels_are_integer_dtype(self, fn, clustered_X):
        assert np.issubdtype(fn.run_dbscan(clustered_X, min_samples=3).dtype, np.integer)

    def test_all_labels_are_minus_one_or_non_negative(self, fn, clustered_X):
        assert np.all(fn.run_dbscan(clustered_X, min_samples=3) >= -1)

    def test_well_separated_data_yields_at_least_one_cluster(self, fn, clustered_X):
        labels = fn.run_dbscan(clustered_X, min_samples=3)
        assert len(np.unique(labels[labels != -1])) >= 1


# ---------------------------------------------------------------------------
# run_agglomerative
# ---------------------------------------------------------------------------

class TestRunAgglomerative:

    def test_returns_dict(self, fn, clustered_X):
        assert isinstance(fn.run_agglomerative(clustered_X, n_clusters=3, linkage="ward"), dict)

    def test_dict_has_labels_key(self, fn, clustered_X):
        assert "labels" in fn.run_agglomerative(clustered_X, n_clusters=3, linkage="ward")

    def test_dict_has_linkage_matrix_key(self, fn, clustered_X):
        assert "linkage_matrix" in fn.run_agglomerative(clustered_X, n_clusters=3, linkage="ward")

    def test_labels_is_1d_integer_array(self, fn, clustered_X):
        result = fn.run_agglomerative(clustered_X, n_clusters=3, linkage="ward")
        assert isinstance(result["labels"], np.ndarray)
        assert result["labels"].ndim == 1
        assert np.issubdtype(result["labels"].dtype, np.integer)

    def test_labels_length_matches_input_rows(self, fn, clustered_X):
        result = fn.run_agglomerative(clustered_X, n_clusters=3, linkage="ward")
        assert len(result["labels"]) == clustered_X.shape[0]

    def test_produces_correct_number_of_clusters(self, fn, clustered_X):
        n_clusters = 3
        result = fn.run_agglomerative(clustered_X, n_clusters=n_clusters, linkage="ward")
        assert len(np.unique(result["labels"])) == n_clusters

    def test_linkage_matrix_is_2d_numpy_array(self, fn, clustered_X):
        result = fn.run_agglomerative(clustered_X, n_clusters=3, linkage="ward")
        assert isinstance(result["linkage_matrix"], np.ndarray)
        assert result["linkage_matrix"].ndim == 2

    def test_linkage_matrix_has_correct_shape(self, fn, clustered_X):
        n = clustered_X.shape[0]
        result = fn.run_agglomerative(clustered_X, n_clusters=3, linkage="ward")
        assert result["linkage_matrix"].shape == (n - 1, 4)

    def test_accepts_multiple_linkage_methods(self, fn, clustered_X):
        for linkage in ["ward", "complete", "average", "single"]:
            result = fn.run_agglomerative(clustered_X, n_clusters=3, linkage=linkage)
            assert "labels" in result and "linkage_matrix" in result


# ---------------------------------------------------------------------------
# run_gmm
# ---------------------------------------------------------------------------

class TestRunGmm:

    def test_returns_numpy_ndarray(self, fn, clustered_X):
        assert isinstance(fn.run_gmm(clustered_X, n_components=3, covariance_type="full"), np.ndarray)

    def test_output_is_1d(self, fn, clustered_X):
        assert fn.run_gmm(clustered_X, n_components=3, covariance_type="full").ndim == 1

    def test_output_length_matches_input_rows(self, fn, clustered_X):
        assert len(fn.run_gmm(clustered_X, n_components=3, covariance_type="full")) == clustered_X.shape[0]

    def test_labels_are_integer_dtype(self, fn, clustered_X):
        assert np.issubdtype(
            fn.run_gmm(clustered_X, n_components=3, covariance_type="full").dtype, np.integer
        )

    def test_label_values_in_valid_range(self, fn, clustered_X):
        n = 3
        labels = fn.run_gmm(clustered_X, n_components=n, covariance_type="full")
        assert labels.min() >= 0
        assert labels.max() < n

    def test_accepts_all_covariance_types(self, fn, clustered_X):
        for cov in ["full", "tied", "diag", "spherical"]:
            labels = fn.run_gmm(clustered_X, n_components=3, covariance_type=cov)
            assert isinstance(labels, np.ndarray) and len(labels) == clustered_X.shape[0]


# ---------------------------------------------------------------------------
# select_k
# ---------------------------------------------------------------------------

class TestSelectK:

    @pytest.fixture
    def k_range(self):
        return [2, 3, 4]

    @pytest.fixture
    def selection(self, fn, clustered_X, k_range):
        if fn is None:
            return None
        return fn.select_k(clustered_X, k_range)

    def test_returns_dict(self, selection):
        assert isinstance(selection, dict)

    def test_has_all_required_keys(self, selection):
        for key in ["inertias", "silhouette_scores", "gap_statistics",
                    "optimal_k", "silhouette_samples_per_k"]:
            assert key in selection

    def test_inertias_length_matches_k_range(self, selection, k_range):
        assert len(selection["inertias"]) == len(k_range)

    def test_silhouette_scores_length_matches_k_range(self, selection, k_range):
        assert len(selection["silhouette_scores"]) == len(k_range)

    def test_gap_statistics_length_matches_k_range(self, selection, k_range):
        assert len(selection["gap_statistics"]) == len(k_range)

    def test_silhouette_samples_per_k_length_matches_k_range(self, selection, k_range):
        assert len(selection["silhouette_samples_per_k"]) == len(k_range)

    def test_silhouette_samples_arrays_have_n_samples_entries(self, clustered_X, selection):
        for arr in selection["silhouette_samples_per_k"]:
            assert len(arr) == clustered_X.shape[0]

    def test_optimal_k_is_in_k_range(self, selection, k_range):
        assert selection["optimal_k"] in k_range

    def test_optimal_k_corresponds_to_highest_mean_silhouette(self, selection, k_range):
        best_idx = int(np.argmax(selection["silhouette_scores"]))
        assert selection["optimal_k"] == k_range[best_idx]

    def test_inertias_are_positive(self, selection):
        assert all(v > 0 for v in selection["inertias"])

    def test_silhouette_samples_are_numpy_arrays(self, selection):
        for arr in selection["silhouette_samples_per_k"]:
            assert isinstance(arr, np.ndarray)

    def test_optimal_k_is_integer(self, selection):
        assert isinstance(selection["optimal_k"], (int, np.integer))


# ---------------------------------------------------------------------------
# evaluate_clustering
# ---------------------------------------------------------------------------

class TestEvaluateClustering:

    def test_returns_dict(self, fn, clustered_X):
        labels = fn.run_kmeans(clustered_X, k=3)
        assert isinstance(fn.evaluate_clustering(clustered_X, labels), dict)

    def test_has_all_required_keys(self, fn, clustered_X):
        labels = fn.run_kmeans(clustered_X, k=3)
        result = fn.evaluate_clustering(clustered_X, labels)
        for key in ["silhouette_score", "calinski_harabasz_index", "davies_bouldin_index"]:
            assert key in result

    def test_metrics_are_float_type(self, fn, clustered_X):
        labels = fn.run_kmeans(clustered_X, k=3)
        result = fn.evaluate_clustering(clustered_X, labels)
        for key in ["silhouette_score", "calinski_harabasz_index", "davies_bouldin_index"]:
            assert isinstance(result[key], float)

    def test_all_noise_labels_returns_nan_for_all_metrics(self, fn, clustered_X):
        labels = np.full(clustered_X.shape[0], -1, dtype=int)
        result = fn.evaluate_clustering(clustered_X, labels)
        for key in ["silhouette_score", "calinski_harabasz_index", "davies_bouldin_index"]:
            assert math.isnan(result[key])

    def test_single_cluster_returns_nan_for_all_metrics(self, fn, clustered_X):
        labels = np.zeros(clustered_X.shape[0], dtype=int)
        result = fn.evaluate_clustering(clustered_X, labels)
        for key in ["silhouette_score", "calinski_harabasz_index", "davies_bouldin_index"]:
            assert math.isnan(result[key])

    def test_noise_points_excluded_valid_clusters_still_evaluated(self, fn, clustered_X):
        labels = fn.run_kmeans(clustered_X, k=3)
        labels_with_noise = labels.copy()
        labels_with_noise[:5] = -1
        result = fn.evaluate_clustering(clustered_X, labels_with_noise)
        assert isinstance(result["silhouette_score"], float)
        assert not math.isnan(result["silhouette_score"])


# ---------------------------------------------------------------------------
# profile_clusters
# ---------------------------------------------------------------------------

class TestProfileClusters:

    def test_returns_dataframe(self, fn, clustered_X):
        df = pd.DataFrame(clustered_X, columns=["f1", "f2"])
        labels = fn.run_kmeans(clustered_X, k=3)
        assert isinstance(fn.profile_clusters(df, labels), pd.DataFrame)

    def test_output_has_required_columns(self, fn, clustered_X):
        df = pd.DataFrame(clustered_X, columns=["f1", "f2"])
        labels = fn.run_kmeans(clustered_X, k=3)
        result = fn.profile_clusters(df, labels)
        for col in ["cluster", "feature", "mean", "median", "std", "significant_deviation"]:
            assert col in result.columns

    def test_cluster_column_covers_all_unique_labels(self, fn, clustered_X):
        df = pd.DataFrame(clustered_X, columns=["f1", "f2"])
        labels = fn.run_kmeans(clustered_X, k=3)
        result = fn.profile_clusters(df, labels)
        assert set(result["cluster"].unique()) == set(np.unique(labels).tolist())

    def test_feature_column_covers_all_numeric_columns(self, fn, clustered_X):
        df = pd.DataFrame(clustered_X, columns=["f1", "f2"])
        labels = fn.run_kmeans(clustered_X, k=3)
        result = fn.profile_clusters(df, labels)
        assert set(result["feature"].unique()) == {"f1", "f2"}

    def test_significant_deviation_is_boolean_dtype(self, fn, clustered_X):
        df = pd.DataFrame(clustered_X, columns=["f1", "f2"])
        labels = fn.run_kmeans(clustered_X, k=3)
        result = fn.profile_clusters(df, labels)
        assert result["significant_deviation"].dtype == bool

    def test_mean_median_std_are_numeric(self, fn, clustered_X):
        df = pd.DataFrame(clustered_X, columns=["f1", "f2"])
        labels = fn.run_kmeans(clustered_X, k=3)
        result = fn.profile_clusters(df, labels)
        for col in ["mean", "median", "std"]:
            assert pd.api.types.is_numeric_dtype(result[col])

    def test_significant_deviation_flags_extreme_cluster(self, fn):
        """Cluster mean > 1.5 population std from population mean must be flagged."""
        rng = np.random.default_rng(0)
        normal_vals  = rng.normal(0, 0.1, (50, 1))
        extreme_vals = rng.normal(20, 0.1, (10, 1))
        X = np.vstack([normal_vals, extreme_vals])
        df = pd.DataFrame(X, columns=["val"])
        labels = np.array([0] * 50 + [1] * 10)
        result = fn.profile_clusters(df, labels)
        extreme_row = result[(result["cluster"] == 1) & (result["feature"] == "val")]
        assert extreme_row["significant_deviation"].values[0] == True

    def test_non_extreme_cluster_not_flagged(self, fn):
        """Cluster mean within 1.5 population stds must not be flagged."""
        rng = np.random.default_rng(1)
        X = np.vstack([rng.normal(0.0, 0.1, (30, 1)), rng.normal(0.1, 0.1, (30, 1))])
        df = pd.DataFrame(X, columns=["val"])
        labels = np.array([0] * 30 + [1] * 30)
        result = fn.profile_clusters(df, labels)
        assert not result["significant_deviation"].any()


# ---------------------------------------------------------------------------
# run_pipeline
# ---------------------------------------------------------------------------

class TestRunPipeline:

    def test_returns_tuple_of_two_strings(self, fn, sample_data_csv_path, pipeline_config):
        result = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        assert isinstance(result, tuple) and len(result) == 2
        assert all(isinstance(p, str) for p in result)

    def test_output_csv_file_exists(self, fn, sample_data_csv_path, pipeline_config):
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        assert os.path.isfile(csv_path)

    def test_output_html_file_exists(self, fn, sample_data_csv_path, pipeline_config):
        _, html_path = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        assert os.path.isfile(html_path)

    def test_output_files_are_inside_output_dir(self, fn, sample_data_csv_path, pipeline_config):
        csv_path, html_path = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        output_dir = pipeline_config["output_dir"]
        assert os.path.commonpath([csv_path, output_dir]) == output_dir
        assert os.path.commonpath([html_path, output_dir]) == output_dir

    def test_output_csv_preserves_original_columns(self, fn, sample_data_csv_path, pipeline_config):
        original_cols = set(pd.read_csv(sample_data_csv_path).columns)
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        assert original_cols.issubset(set(pd.read_csv(csv_path).columns))

    def test_output_csv_has_four_cluster_columns(self, fn, sample_data_csv_path, pipeline_config):
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        df = pd.read_csv(csv_path)
        for col in ["cluster_kmeans", "cluster_dbscan", "cluster_agglomerative", "cluster_gmm"]:
            assert col in df.columns

    def test_output_csv_row_count_matches_input(self, fn, sample_data_csv_path, pipeline_config):
        n_input = len(pd.read_csv(sample_data_csv_path))
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        assert len(pd.read_csv(csv_path)) == n_input

    def test_cluster_kmeans_labels_are_integers(self, fn, sample_data_csv_path, pipeline_config):
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        assert pd.api.types.is_integer_dtype(pd.read_csv(csv_path)["cluster_kmeans"])

    def test_cluster_dbscan_labels_are_integers(self, fn, sample_data_csv_path, pipeline_config):
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        assert pd.api.types.is_integer_dtype(pd.read_csv(csv_path)["cluster_dbscan"])

    def test_cluster_agglomerative_labels_are_integers(self, fn, sample_data_csv_path, pipeline_config):
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        assert pd.api.types.is_integer_dtype(pd.read_csv(csv_path)["cluster_agglomerative"])

    def test_cluster_gmm_labels_are_integers(self, fn, sample_data_csv_path, pipeline_config):
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        assert pd.api.types.is_integer_dtype(pd.read_csv(csv_path)["cluster_gmm"])

    def test_kmeans_cluster_count_within_k_range(self, fn, sample_data_csv_path, pipeline_config):
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        n_clusters = len(pd.read_csv(csv_path)["cluster_kmeans"].unique())
        assert n_clusters in pipeline_config["k_range"]

    def test_gmm_cluster_count_within_k_range(self, fn, sample_data_csv_path, pipeline_config):
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        n_clusters = len(pd.read_csv(csv_path)["cluster_gmm"].unique())
        assert n_clusters in pipeline_config["k_range"]

    def test_kmeans_and_gmm_use_same_k(self, fn, sample_data_csv_path, pipeline_config):
        """Both K-Means and GMM use optimal_k so their unique cluster counts must match."""
        csv_path, _ = fn.run_pipeline(sample_data_csv_path, pipeline_config)
        df = pd.read_csv(csv_path)
        assert len(df["cluster_kmeans"].unique()) == len(df["cluster_gmm"].unique())