#!/usr/bin/env python3

import csv
import os
import sys
import tempfile

import pytest

# -- sys.path setup -------------------------------------------------------------
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_APP_ROOT = os.path.dirname(_THIS_DIR)
for _candidate in [_APP_ROOT, "/app"]:
    if os.path.isdir(_candidate) and _candidate not in sys.path:
        sys.path.insert(0, _candidate)

# -- deferred imports -----------------------------------------------------------
# All set to None so collection succeeds on an empty repo. Each test asserts
# the relevant symbol is not None, producing FAILED (not ERROR) when absent.
generate_dataset = None
load_data = None
classify_landlord_compliance = None
attribute_neighborhood_decline = None
model_enforcement_effectiveness = None
generate_report = None
main_func = None


def _try_import():
    global generate_dataset, load_data, classify_landlord_compliance
    global attribute_neighborhood_decline, model_enforcement_effectiveness
    global generate_report, main_func

    try:
        from scripts.generate_data import generate_dataset as _f
        generate_dataset = _f
    except Exception:
        pass
    try:
        from src.data_loader import load_data as _f
        load_data = _f
    except Exception:
        pass
    try:
        from src.landlord_analyzer import classify_landlord_compliance as _f
        classify_landlord_compliance = _f
    except Exception:
        pass
    try:
        from src.neighborhood_analyzer import attribute_neighborhood_decline as _f
        attribute_neighborhood_decline = _f
    except Exception:
        pass
    try:
        from src.enforcement_model import model_enforcement_effectiveness as _f
        model_enforcement_effectiveness = _f
    except Exception:
        pass
    try:
        from src.report_generator import generate_report as _f
        generate_report = _f
    except Exception:
        pass
    try:
        from main import main as _f
        main_func = _f
    except Exception:
        pass


_try_import()

# -- session-scoped fixtures ----------------------------------------------------

@pytest.fixture(scope="session")
def data_dir(tmp_path_factory):
    """Shared CSV directory -- populated only if generate_dataset is importable."""
    d = str(tmp_path_factory.mktemp("csvdata"))
    if generate_dataset is not None:
        try:
            generate_dataset(d, seed=42)
        except Exception:
            pass
    return d


@pytest.fixture(scope="session")
def loaded_data(data_dir):
    if load_data is None:
        return None
    try:
        return load_data(data_dir)
    except Exception:
        return None


@pytest.fixture(scope="session")
def landlord_df(loaded_data):
    if classify_landlord_compliance is None or loaded_data is None:
        return None
    try:
        return classify_landlord_compliance(loaded_data)
    except Exception:
        return None


@pytest.fixture(scope="session")
def neighborhood_df(loaded_data, landlord_df):
    if attribute_neighborhood_decline is None or loaded_data is None or landlord_df is None:
        return None
    try:
        return attribute_neighborhood_decline(loaded_data, landlord_df)
    except Exception:
        return None


@pytest.fixture(scope="session")
def enforcement_results(loaded_data):
    if model_enforcement_effectiveness is None or loaded_data is None:
        return None
    try:
        return model_enforcement_effectiveness(loaded_data)
    except Exception:
        return None



# -- helpers --------------------------------------------------------------------

def _csv_header(dirpath, filename):
    """Return header row or None if the file is absent."""
    path = os.path.join(dirpath, filename)
    if not os.path.exists(path):
        return None
    with open(path) as f:
        return next(csv.reader(f))


def _csv_row_count(dirpath, filename):
    """Return data row count, or -1 if file is absent."""
    path = os.path.join(dirpath, filename)
    if not os.path.exists(path):
        return -1
    with open(path) as f:
        return sum(1 for _ in f) - 1


def _col_set(dirpath, filename, col):
    """Collect distinct values in one column. Caller must verify file exists."""
    values = set()
    with open(os.path.join(dirpath, filename)) as f:
        for row in csv.DictReader(f):
            values.add(row[col])
    return values


def _col_values(dirpath, filename, col):
    """Return a list of all values in one column."""
    values = []
    with open(os.path.join(dirpath, filename)) as f:
        for row in csv.DictReader(f):
            values.append(row[col])
    return values

# =============================================================================
# DATASET GENERATION
# =============================================================================

def test_generate_dataset_callable_with_output_dir_and_seed_params():
    import inspect
    assert generate_dataset is not None
    sig = inspect.signature(generate_dataset)
    assert "output_dir" in sig.parameters
    assert "seed" in sig.parameters
    assert sig.parameters["seed"].default == 42, \
        f"seed default expected 42, got {sig.parameters['seed'].default}"


def test_generate_dataset_returns_none():
    assert generate_dataset is not None
    with tempfile.TemporaryDirectory() as d:
        result = generate_dataset(d, seed=42)
    assert result is None


def test_generate_dataset_writes_exactly_five_csv_files():
    assert generate_dataset is not None
    with tempfile.TemporaryDirectory() as d:
        generate_dataset(d, seed=42)
        files = set(os.listdir(d))
    expected = {"properties.csv", "inspections.csv", "violations.csv",
                "landlords.csv", "neighborhoods.csv"}
    assert files == expected


def test_all_five_generated_csv_files_are_non_empty():
    assert generate_dataset is not None
    with tempfile.TemporaryDirectory() as d:
        generate_dataset(d, seed=42)
        for fname in ["properties.csv", "inspections.csv", "violations.csv",
                      "landlords.csv", "neighborhoods.csv"]:
            path = os.path.join(d, fname)
            assert os.path.exists(path) and os.path.getsize(path) > 0, \
                f"{fname} is missing or empty"


def test_generate_dataset_is_deterministic_with_same_seed():
    assert generate_dataset is not None
    with tempfile.TemporaryDirectory() as d1, tempfile.TemporaryDirectory() as d2:
        generate_dataset(d1, seed=42)
        generate_dataset(d2, seed=42)
        for fname in ["properties.csv", "inspections.csv", "violations.csv",
                      "landlords.csv", "neighborhoods.csv"]:
            with open(os.path.join(d1, fname), "rb") as f1, \
                 open(os.path.join(d2, fname), "rb") as f2:
                assert f1.read() == f2.read(), f"{fname} differs between identical seeds"

# =============================================================================
# DATASET SCHEMAS -- column checks
# =============================================================================

def test_properties_csv_has_exactly_required_columns(data_dir):
    header = _csv_header(data_dir, "properties.csv")
    assert header is not None
    assert set(header) == {"property_id", "landlord_id", "neighborhood_id",
                           "absentee_owner", "year_built"}
    assert len(header) == 5


def test_landlords_csv_has_exactly_required_columns(data_dir):
    header = _csv_header(data_dir, "landlords.csv")
    assert header is not None
    assert set(header) == {"landlord_id", "landlord_name"}
    assert len(header) == 2


def test_neighborhoods_csv_has_exactly_required_columns(data_dir):
    header = _csv_header(data_dir, "neighborhoods.csv")
    assert header is not None
    assert set(header) == {"neighborhood_id", "neighborhood_name", "year", "condition_score"}
    assert len(header) == 4


def test_inspections_csv_has_exactly_required_columns(data_dir):
    header = _csv_header(data_dir, "inspections.csv")
    assert header is not None
    assert set(header) == {"inspection_id", "property_id", "inspection_date",
                           "inspector_id", "outcome"}
    assert len(header) == 5


def test_violations_csv_has_exactly_required_columns(data_dir):
    header = _csv_header(data_dir, "violations.csv")
    assert header is not None
    expected = {
        "violation_id", "inspection_id", "property_id", "landlord_id",
        "violation_category", "enforcement_tool", "violation_date",
        "enforcement_action_date", "resolution_date", "resolution_outcome", "is_repeat",
    }
    assert set(header) == expected
    assert len(header) == 11

# =============================================================================
# DATASET SCHEMAS -- row count checks
# =============================================================================

def test_properties_csv_contains_exactly_500_rows(data_dir):
    assert _csv_row_count(data_dir, "properties.csv") == 500


def test_landlords_csv_contains_exactly_120_rows(data_dir):
    assert _csv_row_count(data_dir, "landlords.csv") == 120


def test_neighborhoods_csv_contains_exactly_75_rows(data_dir):
    assert _csv_row_count(data_dir, "neighborhoods.csv") == 75


def test_each_neighborhood_has_exactly_5_rows_with_5_distinct_years(data_dir):
    """Each neighborhood_id must appear in exactly 5 rows with 5 distinct year values."""
    from collections import defaultdict
    path = os.path.join(data_dir, "neighborhoods.csv")
    assert os.path.exists(path)
    year_sets = defaultdict(set)
    row_counts = defaultdict(int)
    with open(path) as f:
        for row in csv.DictReader(f):
            nid = row["neighborhood_id"]
            year_sets[nid].add(row["year"])
            row_counts[nid] += 1
    for nid in row_counts:
        assert row_counts[nid] == 5, \
            f"neighborhood {nid}: expected 5 rows, got {row_counts[nid]}"
        assert len(year_sets[nid]) == 5, \
            f"neighborhood {nid}: expected 5 distinct years, got {len(year_sets[nid])}"

# =============================================================================
# DATASET SCHEMAS -- identifier uniqueness
# =============================================================================

def test_property_id_values_are_unique_in_properties_csv(data_dir):
    """property_id is described as a unique property identifier."""
    path = os.path.join(data_dir, "properties.csv")
    assert os.path.exists(path)
    ids = _col_values(data_dir, "properties.csv", "property_id")
    assert len(ids) == len(set(ids)), \
        f"Duplicate property_id values found: {len(ids)} rows, {len(set(ids))} distinct"


def test_landlord_id_values_are_unique_in_landlords_csv(data_dir):
    """landlord_id is described as a unique landlord identifier."""
    path = os.path.join(data_dir, "landlords.csv")
    assert os.path.exists(path)
    ids = _col_values(data_dir, "landlords.csv", "landlord_id")
    assert len(ids) == len(set(ids)), \
        f"Duplicate landlord_id values found: {len(ids)} rows, {len(set(ids))} distinct"


def test_inspection_id_values_are_unique_in_inspections_csv(data_dir):
    """inspection_id is described as a unique inspection identifier."""
    path = os.path.join(data_dir, "inspections.csv")
    assert os.path.exists(path)
    ids = _col_values(data_dir, "inspections.csv", "inspection_id")
    assert len(ids) == len(set(ids)), \
        f"Duplicate inspection_id values found: {len(ids)} rows, {len(set(ids))} distinct"


def test_violation_id_values_are_unique_in_violations_csv(data_dir):
    """violation_id is described as a unique violation identifier."""
    path = os.path.join(data_dir, "violations.csv")
    assert os.path.exists(path)
    ids = _col_values(data_dir, "violations.csv", "violation_id")
    assert len(ids) == len(set(ids)), \
        f"Duplicate violation_id values found: {len(ids)} rows, {len(set(ids))} distinct"

# =============================================================================
# DATASET SCHEMAS -- data validity
# =============================================================================

def test_violations_violation_category_contains_only_permitted_categories(data_dir):
    permitted = {
        "structural_deficiency", "plumbing_failure", "electrical_hazard",
        "pest_infestation", "heating_system_failure", "fire_safety_violation",
        "sanitation_violation", "exterior_maintenance",
    }
    path = os.path.join(data_dir, "violations.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            assert row["violation_category"] in permitted


def test_violations_enforcement_tool_contains_only_permitted_tools(data_dir):
    permitted = {"warning_notice", "civil_fine", "court_referral", "license_suspension"}
    path = os.path.join(data_dir, "violations.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            assert row["enforcement_tool"] in permitted


def test_each_enforcement_tool_appears_at_least_80_times(data_dir):
    counts = {"warning_notice": 0, "civil_fine": 0, "court_referral": 0, "license_suspension": 0}
    path = os.path.join(data_dir, "violations.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            if row["enforcement_tool"] in counts:
                counts[row["enforcement_tool"]] += 1
    for tool, count in counts.items():
        assert count >= 80, f"{tool} appears only {count} times (minimum 80 required)"


def test_each_enforcement_tool_has_both_resolved_and_unresolved_violations(data_dir):
    from datetime import datetime
    tools = {"warning_notice", "civil_fine", "court_referral", "license_suspension"}
    resolved = {t: False for t in tools}
    unresolved = {t: False for t in tools}
    path = os.path.join(data_dir, "violations.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            t = row["enforcement_tool"]
            if t not in tools:
                continue
            res = row.get("resolution_date", "").strip()
            enf = row.get("enforcement_action_date", "").strip()
            if res and enf:
                try:
                    delta = (datetime.strptime(res, "%Y-%m-%d") -
                             datetime.strptime(enf, "%Y-%m-%d")).days
                    if 0 <= delta <= 180:
                        resolved[t] = True
                except ValueError:
                    pass
            elif not res:
                unresolved[t] = True
    for t in tools:
        assert resolved[t], f"{t}: no resolved violations within 180 days"
        assert unresolved[t], f"{t}: no unresolved violations"


def test_inspections_outcome_contains_only_permitted_values(data_dir):
    permitted = {"pass", "fail", "conditional_pass"}
    path = os.path.join(data_dir, "inspections.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            assert row["outcome"] in permitted


def test_violations_resolution_outcome_contains_only_permitted_values(data_dir):
    permitted = {"resolved", "unresolved"}
    path = os.path.join(data_dir, "violations.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            assert row["resolution_outcome"] in permitted


def test_violations_is_repeat_contains_boolean_values(data_dir):
    permitted = {"True", "False", "true", "false", "1", "0"}
    path = os.path.join(data_dir, "violations.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            assert row["is_repeat"].strip() in permitted


def test_properties_absentee_owner_contains_boolean_values(data_dir):
    permitted = {"True", "False", "true", "false", "1", "0"}
    path = os.path.join(data_dir, "properties.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            assert row["absentee_owner"].strip() in permitted


def test_year_built_values_are_four_digit_integers(data_dir):
    """year_built must be a four-digit integer (1000-9999) as specified in the schema."""
    path = os.path.join(data_dir, "properties.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            year = int(row["year_built"])
            assert 1000 <= year <= 9999, \
                f"year_built={year} is not a four-digit year"


def test_is_repeat_true_rows_have_prior_violation_for_same_property_and_category(data_dir):
    """For every is_repeat=True violation, a prior violation must exist for the
    same property_id and violation_category with an earlier inspection_date."""
    from datetime import datetime
    from collections import defaultdict
    insp_path = os.path.join(data_dir, "inspections.csv")
    viol_path = os.path.join(data_dir, "violations.csv")
    assert os.path.exists(insp_path) and os.path.exists(viol_path)
    # Build: inspection_id -> inspection_date
    insp_dates = {}
    with open(insp_path) as f:
        for row in csv.DictReader(f):
            insp_dates[row["inspection_id"]] = datetime.strptime(
                row["inspection_date"], "%Y-%m-%d"
            )
    # Build: (property_id, violation_category) -> sorted list of all inspection_dates
    history = defaultdict(list)
    with open(viol_path) as f:
        for row in csv.DictReader(f):
            d = insp_dates.get(row["inspection_id"])
            if d is not None:
                history[(row["property_id"], row["violation_category"])].append(d)
    for dates in history.values():
        dates.sort()
    # Verify: every is_repeat=True row has at least one strictly earlier occurrence
    with open(viol_path) as f:
        for row in csv.DictReader(f):
            if row["is_repeat"].strip() not in ("True", "true", "1"):
                continue
            current_date = insp_dates.get(row["inspection_id"])
            if current_date is None:
                continue
            key = (row["property_id"], row["violation_category"])
            prior_dates = [d for d in history[key] if d < current_date]
            assert len(prior_dates) > 0, (
                f"is_repeat=True but no prior violation found for "
                f"property {row['property_id']}, category {row['violation_category']}"
            )

# =============================================================================
# DATASET SCHEMAS -- FK integrity
# =============================================================================

def test_property_id_in_inspections_is_valid_fk_to_properties(data_dir):
    assert os.path.exists(os.path.join(data_dir, "properties.csv"))
    assert os.path.exists(os.path.join(data_dir, "inspections.csv"))
    assert _col_set(data_dir, "inspections.csv", "property_id").issubset(
        _col_set(data_dir, "properties.csv", "property_id")
    )


def test_property_id_in_violations_is_valid_fk_to_properties(data_dir):
    assert os.path.exists(os.path.join(data_dir, "properties.csv"))
    assert os.path.exists(os.path.join(data_dir, "violations.csv"))
    assert _col_set(data_dir, "violations.csv", "property_id").issubset(
        _col_set(data_dir, "properties.csv", "property_id")
    )


def test_landlord_id_in_properties_is_valid_fk_to_landlords(data_dir):
    assert os.path.exists(os.path.join(data_dir, "landlords.csv"))
    assert os.path.exists(os.path.join(data_dir, "properties.csv"))
    assert _col_set(data_dir, "properties.csv", "landlord_id").issubset(
        _col_set(data_dir, "landlords.csv", "landlord_id")
    )


def test_landlord_id_in_violations_is_valid_fk_to_landlords(data_dir):
    assert os.path.exists(os.path.join(data_dir, "landlords.csv"))
    assert os.path.exists(os.path.join(data_dir, "violations.csv"))
    assert _col_set(data_dir, "violations.csv", "landlord_id").issubset(
        _col_set(data_dir, "landlords.csv", "landlord_id")
    )


def test_neighborhood_id_in_properties_is_valid_fk_to_neighborhoods(data_dir):
    assert os.path.exists(os.path.join(data_dir, "neighborhoods.csv"))
    assert os.path.exists(os.path.join(data_dir, "properties.csv"))
    assert _col_set(data_dir, "properties.csv", "neighborhood_id").issubset(
        _col_set(data_dir, "neighborhoods.csv", "neighborhood_id")
    )


def test_inspection_id_in_violations_is_valid_fk_to_inspections(data_dir):
    assert os.path.exists(os.path.join(data_dir, "inspections.csv"))
    assert os.path.exists(os.path.join(data_dir, "violations.csv"))
    assert _col_set(data_dir, "violations.csv", "inspection_id").issubset(
        _col_set(data_dir, "inspections.csv", "inspection_id")
    )

# =============================================================================
# DATASET SCHEMAS -- domain constraints
# =============================================================================

def test_neighborhoods_condition_score_values_are_in_0_100(data_dir):
    path = os.path.join(data_dir, "neighborhoods.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            assert 0 <= float(row["condition_score"]) <= 100


def test_violations_enforcement_action_date_gte_violation_date(data_dir):
    from datetime import datetime
    path = os.path.join(data_dir, "violations.csv")
    assert os.path.exists(path)
    with open(path) as f:
        for row in csv.DictReader(f):
            vd = datetime.strptime(row["violation_date"], "%Y-%m-%d")
            ed = datetime.strptime(row["enforcement_action_date"], "%Y-%m-%d")
            assert ed >= vd

# =============================================================================
# DATA LOADING
# =============================================================================

def test_load_data_callable_with_data_dir_parameter():
    import inspect
    assert load_data is not None
    assert "data_dir" in inspect.signature(load_data).parameters


def test_load_data_returns_dict_with_five_required_keys(loaded_data):
    assert loaded_data is not None
    assert isinstance(loaded_data, dict)
    assert set(loaded_data.keys()) == {
        "properties", "inspections", "violations", "landlords", "neighborhoods"
    }


def test_load_data_parses_date_columns_to_datetime64(loaded_data):
    assert loaded_data is not None
    for key, col in [
        ("inspections", "inspection_date"),
        ("violations", "violation_date"),
        ("violations", "enforcement_action_date"),
        ("violations", "resolution_date"),
    ]:
        assert col in loaded_data[key].columns, f"{key}.{col} column missing"
        assert "datetime" in str(loaded_data[key][col].dtype).lower(), \
            f"{key}.{col} is not datetime64"


def test_load_data_raises_file_not_found_for_missing_csv():
    assert load_data is not None
    with tempfile.TemporaryDirectory() as d:
        with pytest.raises(FileNotFoundError):
            load_data(d)


def test_load_data_raises_value_error_for_missing_column():
    assert load_data is not None
    assert generate_dataset is not None
    import pandas as pd
    with tempfile.TemporaryDirectory() as d:
        generate_dataset(d, seed=42)
        props = os.path.join(d, "properties.csv")
        pd.read_csv(props).drop(columns=["landlord_id"]).to_csv(props, index=False)
        with pytest.raises(ValueError):
            load_data(d)

# =============================================================================
# LANDLORD COMPLIANCE CLASSIFICATION
# =============================================================================

def test_classify_landlord_compliance_callable_with_data_parameter():
    import inspect
    assert classify_landlord_compliance is not None
    assert "data" in inspect.signature(classify_landlord_compliance).parameters


def test_classify_landlord_compliance_dataframe_indexed_by_landlord_id(landlord_df):
    assert landlord_df is not None
    assert landlord_df.index.name == "landlord_id"


def test_classify_landlord_compliance_dataframe_has_exactly_required_columns(landlord_df):
    assert landlord_df is not None
    assert set(landlord_df.columns) == {
        "portfolio_size", "total_violations", "repeat_violation_rate",
        "violation_density", "compliance_score", "compliance_classification",
    }


def test_repeat_violation_rate_values_are_in_0_1(landlord_df):
    assert landlord_df is not None
    assert landlord_df["repeat_violation_rate"].between(0, 1).all()


def test_repeat_violation_rate_formula_matches_is_repeat_count_over_total_violations(loaded_data, landlord_df):
    """repeat_violation_rate must equal count(is_repeat=True) / total_violations per landlord."""
    import math
    assert loaded_data is not None and landlord_df is not None
    violations = loaded_data["violations"].copy()
    ir = violations["is_repeat"]
    if ir.dtype == object:
        violations["_ir_bool"] = ir.str.strip().str.lower().map(
            {"true": True, "false": False, "1": True, "0": False}
        )
    else:
        violations["_ir_bool"] = ir.astype(bool)
    for landlord_id, row in landlord_df.iterrows():
        lv = violations[violations["landlord_id"] == landlord_id]
        if len(lv) == 0:
            continue
        expected = lv["_ir_bool"].sum() / len(lv)
        assert math.isclose(row["repeat_violation_rate"], float(expected), rel_tol=1e-6), (
            f"Landlord {landlord_id}: expected repeat_violation_rate={expected:.6f}, "
            f"got {row['repeat_violation_rate']:.6f}"
        )


def test_compliance_classification_contains_only_permitted_values(landlord_df):
    assert landlord_df is not None
    assert set(landlord_df["compliance_classification"].unique()).issubset(
        {"systematic_noncompliant", "incidental"}
    )


def test_landlords_at_or_above_75th_percentile_are_systematic_noncompliant(landlord_df):
    import numpy as np
    assert landlord_df is not None
    threshold = np.percentile(landlord_df["repeat_violation_rate"].values, 75)
    above = landlord_df[landlord_df["repeat_violation_rate"] >= threshold]
    assert (above["compliance_classification"] == "systematic_noncompliant").all()
    below = landlord_df[landlord_df["repeat_violation_rate"] < threshold]
    assert (below["compliance_classification"] == "incidental").all()


def test_portfolio_size_equals_distinct_property_count_per_landlord(loaded_data, landlord_df):
    """portfolio_size must equal the count of distinct properties owned by each landlord."""
    assert loaded_data is not None and landlord_df is not None
    properties = loaded_data["properties"]
    expected = properties.groupby("landlord_id")["property_id"].nunique()
    for landlord_id, row in landlord_df.iterrows():
        if landlord_id in expected.index:
            assert row["portfolio_size"] == expected[landlord_id], (
                f"Landlord {landlord_id}: portfolio_size={row['portfolio_size']} "
                f"but distinct properties={expected[landlord_id]}"
            )


def test_violation_density_equals_total_violations_per_portfolio_size_per_years(loaded_data, landlord_df):
    """violation_density must equal total_violations / portfolio_size / years_of_data."""
    import math
    assert loaded_data is not None and landlord_df is not None
    # Derive years_of_data from the violations date range (prompt mandates 5 years)
    violations = loaded_data["violations"]
    years_of_data = violations["violation_date"].dt.year.nunique()
    for landlord_id, row in landlord_df.iterrows():
        if row["portfolio_size"] == 0:
            continue
        expected = row["total_violations"] / row["portfolio_size"] / years_of_data
        assert math.isclose(row["violation_density"], expected, rel_tol=1e-6), (
            f"Landlord {landlord_id}: expected violation_density={expected:.6f}, "
            f"got {row['violation_density']:.6f}"
        )


def test_compliance_score_values_are_in_0_1(landlord_df):
    """compliance_score must be in [0, 1] for all landlords (result of min-max normalization)."""
    assert landlord_df is not None
    assert landlord_df["compliance_score"].between(0, 1).all()


def test_compliance_score_formula_matches_equally_weighted_minmax_normalized_average(landlord_df):
    """compliance_score must equal the average of min-max normalized repeat_violation_rate
    and min-max normalized violation_density, each independently normalized across all landlords."""
    import math
    assert landlord_df is not None
    rvr = landlord_df["repeat_violation_rate"]
    vd = landlord_df["violation_density"]
    rvr_min, rvr_max = float(rvr.min()), float(rvr.max())
    vd_min, vd_max = float(vd.min()), float(vd.max())
    for landlord_id, row in landlord_df.iterrows():
        norm_rvr = (row["repeat_violation_rate"] - rvr_min) / (rvr_max - rvr_min) \
            if rvr_max != rvr_min else 0.0
        norm_vd = (row["violation_density"] - vd_min) / (vd_max - vd_min) \
            if vd_max != vd_min else 0.0
        expected = (norm_rvr + norm_vd) / 2.0
        assert math.isclose(row["compliance_score"], expected, rel_tol=1e-6), (
            f"Landlord {landlord_id}: expected compliance_score={expected:.6f}, "
            f"got {row['compliance_score']:.6f}"
        )

# =============================================================================
# NEIGHBORHOOD DECLINE ATTRIBUTION
# =============================================================================

def test_attribute_neighborhood_decline_callable():
    import inspect
    assert attribute_neighborhood_decline is not None
    assert "data" in inspect.signature(attribute_neighborhood_decline).parameters


def test_attribute_neighborhood_decline_has_landlord_classifications_parameter():
    """attribute_neighborhood_decline must accept landlord_classifications as a parameter."""
    import inspect
    assert attribute_neighborhood_decline is not None
    assert "landlord_classifications" in inspect.signature(
        attribute_neighborhood_decline
    ).parameters


def test_attribute_neighborhood_decline_dataframe_indexed_by_neighborhood_id(neighborhood_df):
    """The returned DataFrame must be indexed by neighborhood_id."""
    assert neighborhood_df is not None
    assert neighborhood_df.index.name == "neighborhood_id"


def test_attribute_neighborhood_decline_dataframe_has_exactly_15_rows(neighborhood_df):
    assert neighborhood_df is not None
    assert len(neighborhood_df) == 15


def test_attribute_neighborhood_decline_dataframe_has_exactly_required_columns(neighborhood_df):
    assert neighborhood_df is not None
    assert set(neighborhood_df.columns) == {
        "decline_index", "noncompliant_ownership_share",
        "absentee_owner_ratio", "portfolio_concentration_hhi", "primary_decline_driver",
    }


def test_noncompliant_ownership_share_values_are_in_0_1(neighborhood_df):
    assert neighborhood_df is not None
    assert neighborhood_df["noncompliant_ownership_share"].between(0, 1).all()


def test_noncompliant_ownership_share_matches_share_of_properties_owned_by_noncompliant_landlords(
    loaded_data, landlord_df, neighborhood_df
):
    """noncompliant_ownership_share must equal the fraction of properties in each neighborhood
    owned by landlords classified as systematic_noncompliant."""
    import math
    assert loaded_data is not None and landlord_df is not None and neighborhood_df is not None
    properties = loaded_data["properties"]
    # Attach classification to each property via landlord_id
    props = properties.merge(
        landlord_df[["compliance_classification"]],
        left_on="landlord_id",
        right_index=True,
        how="left",
    )
    for nid, row in neighborhood_df.iterrows():
        nbhd = props[props["neighborhood_id"] == nid]
        if len(nbhd) == 0:
            continue
        expected = (nbhd["compliance_classification"] == "systematic_noncompliant").sum() / len(nbhd)
        assert math.isclose(
            row["noncompliant_ownership_share"], float(expected), rel_tol=1e-6
        ), (
            f"Neighborhood {nid}: expected noncompliant_ownership_share={expected:.6f}, "
            f"got {row['noncompliant_ownership_share']:.6f}"
        )


def test_absentee_owner_ratio_values_are_in_0_1(neighborhood_df):
    assert neighborhood_df is not None
    assert neighborhood_df["absentee_owner_ratio"].between(0, 1).all()


def test_absentee_owner_ratio_matches_fraction_of_absentee_properties_per_neighborhood(
    loaded_data, neighborhood_df
):
    """absentee_owner_ratio must equal the fraction of properties in each neighborhood
    where absentee_owner is True."""
    import math
    assert loaded_data is not None and neighborhood_df is not None
    properties = loaded_data["properties"].copy()
    # Normalize absentee_owner to boolean regardless of how load_data stored it
    ao = properties["absentee_owner"]
    if ao.dtype == object:
        properties["_absentee_bool"] = ao.str.strip().str.lower().map(
            {"true": True, "false": False, "1": True, "0": False}
        )
    else:
        properties["_absentee_bool"] = ao.astype(bool)
    for nid, row in neighborhood_df.iterrows():
        nbhd = properties[properties["neighborhood_id"] == nid]
        if len(nbhd) == 0:
            continue
        expected = nbhd["_absentee_bool"].sum() / len(nbhd)
        assert math.isclose(
            row["absentee_owner_ratio"], float(expected), rel_tol=1e-6
        ), (
            f"Neighborhood {nid}: expected absentee_owner_ratio={expected:.6f}, "
            f"got {row['absentee_owner_ratio']:.6f}"
        )


def test_portfolio_concentration_hhi_values_are_in_0_1(neighborhood_df):
    assert neighborhood_df is not None
    assert neighborhood_df["portfolio_concentration_hhi"].between(0, 1).all()


def test_portfolio_concentration_hhi_formula_matches_sum_of_squared_ownership_shares(
    loaded_data, neighborhood_df
):
    """portfolio_concentration_hhi must equal the sum of squared landlord ownership shares
    within each neighborhood (the Herfindahl-Hirschman Index formula)."""
    import math
    assert loaded_data is not None and neighborhood_df is not None
    properties = loaded_data["properties"]
    for nid, row in neighborhood_df.iterrows():
        nbhd = properties[properties["neighborhood_id"] == nid]
        if len(nbhd) == 0:
            continue
        landlord_counts = nbhd.groupby("landlord_id").size()
        total = len(nbhd)
        shares = landlord_counts / total
        expected_hhi = float((shares ** 2).sum())
        assert math.isclose(row["portfolio_concentration_hhi"], expected_hhi, rel_tol=1e-6), (
            f"Neighborhood {nid}: expected portfolio_concentration_hhi={expected_hhi:.6f}, "
            f"got {row['portfolio_concentration_hhi']:.6f}"
        )


def test_primary_decline_driver_contains_only_permitted_values(neighborhood_df):
    assert neighborhood_df is not None
    assert set(neighborhood_df["primary_decline_driver"].unique()).issubset(
        {"noncompliant_ownership", "absentee_ownership", "portfolio_concentration"}
    )


def test_decline_index_formula_matches_negated_slope_of_condition_score_over_year(
    loaded_data, neighborhood_df
):
    """decline_index must equal the negative of the OLS slope of condition_score on year."""
    import math
    from scipy import stats
    assert loaded_data is not None and neighborhood_df is not None
    neighborhoods_raw = loaded_data["neighborhoods"]
    for nid, row in neighborhood_df.iterrows():
        nbhd = neighborhoods_raw[neighborhoods_raw["neighborhood_id"] == nid]
        if len(nbhd) < 2:
            continue
        years = nbhd["year"].astype(float).values
        scores = nbhd["condition_score"].astype(float).values
        slope, _, _, _, _ = stats.linregress(years, scores)
        expected = -slope
        assert math.isclose(row["decline_index"], expected, rel_tol=1e-6), (
            f"Neighborhood {nid}: expected decline_index={expected:.6f}, "
            f"got {row['decline_index']:.6f}"
        )


def test_primary_decline_driver_matches_feature_with_highest_absolute_pearson_correlation(
    loaded_data, neighborhood_df
):
    """primary_decline_driver must be the feature with the highest absolute Pearson correlation
    with independently computed decline_index values, with alphabetical tie-breaking."""
    import math
    import numpy as np
    from scipy import stats
    assert loaded_data is not None and neighborhood_df is not None
    neighborhoods_raw = loaded_data["neighborhoods"]
    # Independently compute decline_index per neighborhood from raw data
    decline_indices = {}
    for nid in neighborhood_df.index:
        nbhd = neighborhoods_raw[neighborhoods_raw["neighborhood_id"] == nid]
        if len(nbhd) < 2:
            continue
        years = nbhd["year"].astype(float).values
        scores = nbhd["condition_score"].astype(float).values
        slope, _, _, _, _ = stats.linregress(years, scores)
        decline_indices[nid] = -slope
    nids = [nid for nid in neighborhood_df.index if nid in decline_indices]
    decline_arr = np.array([decline_indices[nid] for nid in nids])
    feature_map = {
        "noncompliant_ownership": neighborhood_df.loc[nids, "noncompliant_ownership_share"].values,
        "absentee_ownership": neighborhood_df.loc[nids, "absentee_owner_ratio"].values,
        "portfolio_concentration": neighborhood_df.loc[nids, "portfolio_concentration_hhi"].values,
    }
    correlations = {}
    for name, values in feature_map.items():
        r, _ = stats.pearsonr(values, decline_arr)
        correlations[name] = abs(r)
    max_corr = max(correlations.values())
    expected_driver = sorted(
        name for name, corr in correlations.items()
        if math.isclose(corr, max_corr, rel_tol=1e-9)
    )[0]
    assert (neighborhood_df["primary_decline_driver"] == expected_driver).all(), (
        f"Expected primary_decline_driver='{expected_driver}', "
        f"got {neighborhood_df['primary_decline_driver'].unique().tolist()}"
    )

# =============================================================================
# ENFORCEMENT EFFECTIVENESS MODEL
# =============================================================================

def test_model_enforcement_effectiveness_callable():
    import inspect
    assert model_enforcement_effectiveness is not None
    assert "data" in inspect.signature(model_enforcement_effectiveness).parameters


def test_model_enforcement_effectiveness_has_follow_up_days_parameter_with_default_180():
    """model_enforcement_effectiveness must have follow_up_days parameter defaulting to 180."""
    import inspect
    assert model_enforcement_effectiveness is not None
    sig = inspect.signature(model_enforcement_effectiveness)
    assert "follow_up_days" in sig.parameters, \
        "model_enforcement_effectiveness missing follow_up_days parameter"
    assert sig.parameters["follow_up_days"].default == 180, \
        f"follow_up_days default expected 180, got {sig.parameters['follow_up_days'].default}"


def test_model_type_is_logistic_regression(enforcement_results):
    assert enforcement_results is not None
    assert enforcement_results.get("model_type") == "logistic_regression"


def test_tool_effects_contains_exactly_four_enforcement_tool_keys(enforcement_results):
    assert enforcement_results is not None
    assert "tool_effects" in enforcement_results
    assert set(enforcement_results["tool_effects"].keys()) == {
        "warning_notice", "civil_fine", "court_referral", "license_suspension"
    }


def test_each_tool_effects_sub_dict_has_effect_size_confidence_interval_and_p_value(enforcement_results):
    import math
    assert enforcement_results is not None
    for tool, sub in enforcement_results["tool_effects"].items():
        effect_size = sub.get("effect_size")
        assert isinstance(effect_size, (int, float)), \
            f"{tool}: effect_size not numeric"
        assert math.isfinite(effect_size), \
            f"{tool}: effect_size must be a finite number"
        ci = sub.get("confidence_interval")
        assert isinstance(ci, (tuple, list)) and len(ci) == 2, \
            f"{tool}: confidence_interval must be a 2-element tuple/list"
        assert math.isfinite(ci[0]) and math.isfinite(ci[1]), \
            f"{tool}: confidence_interval bounds must be finite numbers"
        p_value = sub.get("p_value")
        assert isinstance(p_value, (int, float)), \
            f"{tool}: p_value not numeric"
        assert 0.0 <= p_value <= 1.0, \
            f"{tool}: p_value={p_value} is outside the valid range [0, 1]"


def test_warning_notice_has_effect_size_0_ci_0_0_and_p_value_1(enforcement_results):
    assert enforcement_results is not None
    wn = enforcement_results["tool_effects"].get("warning_notice", {})
    assert wn.get("effect_size") == 0.0
    assert tuple(wn.get("confidence_interval", ())) == (0.0, 0.0)
    assert wn.get("p_value") == 1.0


def test_confidence_interval_lower_le_upper_for_all_tools(enforcement_results):
    assert enforcement_results is not None
    for tool, sub in enforcement_results["tool_effects"].items():
        ci = sub.get("confidence_interval", (0, 0))
        assert ci[0] <= ci[1], f"{tool}: lower CI bound exceeds upper CI bound"

# =============================================================================
# REPORT GENERATION
# =============================================================================

def test_generate_report_returns_absolute_path_string(landlord_df, neighborhood_df, enforcement_results):
    assert generate_report is not None
    assert landlord_df is not None
    assert neighborhood_df is not None
    assert enforcement_results is not None
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "report.html")
        result = generate_report(landlord_df, neighborhood_df, enforcement_results, path)
        assert isinstance(result, str)
        assert os.path.isabs(result), "generate_report must return an absolute path"
        assert os.path.exists(path), "generate_report must write the HTML file to the specified output_path"

# =============================================================================
# PIPELINE ENTRY POINT
# =============================================================================

def test_main_creates_enforcement_report_html_in_output_dir():
    assert main_func is not None
    with tempfile.TemporaryDirectory() as data_dir, \
         tempfile.TemporaryDirectory() as output_dir:
        old_argv = sys.argv[:]
        try:
            sys.argv = ["main.py", "--data-dir", data_dir, "--output-dir", output_dir]
            exit_code = 0
            try:
                main_func()
            except SystemExit as e:
                exit_code = e.code if e.code is not None else 0
        finally:
            sys.argv = old_argv
        assert exit_code == 0, f"main() exited with code {exit_code}, expected 0"
        assert os.path.exists(os.path.join(output_dir, "enforcement_report.html"))


def test_main_creates_all_five_csv_files_in_data_dir():
    assert main_func is not None
    with tempfile.TemporaryDirectory() as data_dir, \
         tempfile.TemporaryDirectory() as output_dir:
        old_argv = sys.argv[:]
        try:
            sys.argv = ["main.py", "--data-dir", data_dir, "--output-dir", output_dir]
            exit_code = 0
            try:
                main_func()
            except SystemExit as e:
                exit_code = e.code if e.code is not None else 0
        finally:
            sys.argv = old_argv
        assert exit_code == 0, f"main() exited with code {exit_code}, expected 0"
        for fname in ["properties.csv", "inspections.csv", "violations.csv",
                      "landlords.csv", "neighborhoods.csv"]:
            assert os.path.exists(os.path.join(data_dir, fname)), \
                f"{fname} not created in data dir by main()"


def test_main_skips_dataset_generation_when_csvs_already_present():
    """When all five CSVs are already present, main() must not regenerate them."""
    assert main_func is not None
    assert generate_dataset is not None
    with tempfile.TemporaryDirectory() as data_dir, \
         tempfile.TemporaryDirectory() as output_dir:
        # Pre-populate with a different seed so any regeneration would change content
        generate_dataset(data_dir, seed=7)
        original = {}
        for fname in ["properties.csv", "inspections.csv", "violations.csv",
                      "landlords.csv", "neighborhoods.csv"]:
            with open(os.path.join(data_dir, fname), "rb") as f:
                original[fname] = f.read()
        old_argv = sys.argv[:]
        try:
            sys.argv = ["main.py", "--data-dir", data_dir, "--output-dir", output_dir]
            try:
                main_func()
            except SystemExit:
                pass
        finally:
            sys.argv = old_argv
        for fname, original_bytes in original.items():
            with open(os.path.join(data_dir, fname), "rb") as f:
                assert f.read() == original_bytes, \
                    f"{fname} was modified by main() despite CSVs already being present"