import os
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# In a sandbox the tests live under /eval_assets while the codebase is mounted
# at /app; in local dev both live next to each other inside the codebase folder.
# Resolve the root by trying each location and picking the one that actually
# contains pipeline.py (or the bundled dataset).
def _detect_codebase_root():
    here = Path(__file__).resolve().parent.parent
    candidates = [Path("/app"), Path.cwd(), here]
    for c in candidates:
        try:
            if (c / "pipeline.py").exists():
                return c
        except OSError:
            continue
    for c in candidates:
        try:
            if (c / "data" / "early_intervention.csv").exists():
                return c
        except OSError:
            continue
    return Path("/app") if Path("/app").is_dir() else here


REPO_ROOT = _detect_codebase_root()

for _root in (Path("/app"), Path.cwd(),
              Path(__file__).resolve().parent.parent, REPO_ROOT):
    _s = str(_root)
    if _s not in sys.path:
        sys.path.insert(0, _s)


REQUIRED_COLUMNS = [
    "child_id",
    "eligibility_pathway",
    "severity_at_intake",
    "developmental_therapy_hours",
    "speech_hours",
    "occupational_hours",
    "physical_hours",
    "social_work_hours",
    "developmental_therapy_setting",
    "speech_setting",
    "occupational_setting",
    "physical_setting",
    "social_work_setting",
    "provider_id",
    "c1_entry_score",
    "c1_exit_score",
    "c2_entry_score",
    "c2_exit_score",
    "c3_entry_score",
    "c3_exit_score",
    "transitioned_to_school_district",
    "transition_age_months",
    "enrollment_year",
    "functional_gain_score",
]

DISCIPLINES = [
    "developmental_therapy",
    "speech",
    "occupational",
    "physical",
    "social_work",
]
HOUR_COLS = [f"{d}_hours" for d in DISCIPLINES]
SETTING_COLS = [f"{d}_setting" for d in DISCIPLINES]


# ---------------------------------------------------------------------------
# Lazy / safe pipeline import
# ---------------------------------------------------------------------------

def _load_pipeline():
    """Import the pipeline module fresh, returning None on any failure."""
    try:
        if "pipeline" in sys.modules:
            del sys.modules["pipeline"]
        import pipeline  # noqa: WPS433
        return pipeline
    except Exception:
        return None


def _get(name):
    """Look up an attribute on the pipeline module, returning None if missing."""
    mod = _load_pipeline()
    if mod is None:
        return None
    attr = getattr(mod, name, None)
    if not callable(attr):
        return None
    return attr


def _missing_msg(name):
    return (
        "pipeline.{0} is not importable / not defined. "
        "Implement {0} in pipeline.py.".format(name)
    )


# ---------------------------------------------------------------------------
# Synthetic data builders
# ---------------------------------------------------------------------------

def _random_df(n=240, seed=11):
    """Build a synthetic dataset compatible with the prompt's column spec."""
    rng = np.random.default_rng(seed)
    providers = [f"PRV-{i}" for i in range(5)]
    years = list(range(2018, 2024))
    pathways = ["developmental_delay", "established_condition"]
    settings = ["home", "community"]

    severity = rng.uniform(0.01, 0.99, n)
    df = pd.DataFrame({
        "child_id": [f"C{i:05d}" for i in range(n)],
        "eligibility_pathway": rng.choice(pathways, n),
        "severity_at_intake": severity,
        "developmental_therapy_hours": rng.uniform(0.0, 5.0, n),
        "speech_hours": rng.uniform(0.0, 4.0, n),
        "occupational_hours": rng.uniform(0.0, 3.0, n),
        "physical_hours": rng.uniform(0.0, 3.0, n),
        "social_work_hours": rng.uniform(0.0, 2.0, n),
        "developmental_therapy_setting": rng.choice(settings, n),
        "speech_setting": rng.choice(settings, n),
        "occupational_setting": rng.choice(settings, n),
        "physical_setting": rng.choice(settings, n),
        "social_work_setting": rng.choice(settings, n),
        "provider_id": rng.choice(providers, n),
        "c1_entry_score": rng.uniform(1.0, 6.0, n),
        "c1_exit_score": rng.uniform(2.0, 7.0, n),
        "c2_entry_score": rng.uniform(1.0, 6.0, n),
        "c2_exit_score": rng.uniform(2.0, 7.0, n),
        "c3_entry_score": rng.uniform(1.0, 6.0, n),
        "c3_exit_score": rng.uniform(2.0, 7.0, n),
        "transitioned_to_school_district": rng.choice([True, False], n),
        "transition_age_months": rng.integers(33, 37, n),
        "enrollment_year": rng.choice(years, n),
        "functional_gain_score": (
            0.6 * rng.uniform(0.0, 5.0, n)        # dt_hours influence
            + 0.3 * rng.uniform(0.0, 4.0, n)      # speech_hours influence
            - 0.4 * severity
            + rng.normal(0, 0.5, n)
        ),
    })
    # Ensure both pathways and both settings actually appear
    df.loc[df.index[:2], "eligibility_pathway"] = ["developmental_delay",
                                                   "established_condition"]
    for col in SETTING_COLS:
        df.loc[df.index[0], col] = "home"
        df.loc[df.index[1], col] = "community"
    # Ensure at least one transition is True so mean_transition_age is defined
    df.loc[df.index[0], "transitioned_to_school_district"] = True
    return df


def _to_int_set(values):
    """Coerce an iterable to a sorted list of ints (handles Categorical)."""
    out = []
    for v in values:
        try:
            out.append(int(v))
        except (TypeError, ValueError):
            return None
    return sorted(set(out))


# ---------------------------------------------------------------------------
# load_data
# ---------------------------------------------------------------------------

def test_load_data_returns_dataframe_with_required_columns():
    """load_data reads a CSV and returns a DataFrame containing all 24 cols."""
    fn = _get("load_data")
    assert fn is not None, _missing_msg("load_data")

    df = _random_df(n=20, seed=1)
    with tempfile.TemporaryDirectory() as tmp:
        csv_path = os.path.join(tmp, "early_intervention.csv")
        df.to_csv(csv_path, index=False)

        result = fn(csv_path)

    assert isinstance(result, pd.DataFrame), "load_data must return a DataFrame"
    assert len(result) == len(df), \
        "load_data must return all rows from the input CSV"
    assert set(result.columns) == set(REQUIRED_COLUMNS), (
        "load_data must return exactly the 24 specified columns; "
        f"unexpected={set(result.columns) - set(REQUIRED_COLUMNS)}, "
        f"missing={set(REQUIRED_COLUMNS) - set(result.columns)}"
    )

    # Spot-check that cell values round-trip through load_data. We sort by
    # child_id to avoid asserting any particular row order, and we sample a
    # str column and a numeric column rather than the whole frame so the
    # check stays robust to CSV-induced dtype variations on other columns.
    sorted_in = df.sort_values("child_id").reset_index(drop=True)
    sorted_out = result.sort_values("child_id").reset_index(drop=True)
    assert sorted_out["child_id"].astype(str).tolist() == \
        sorted_in["child_id"].astype(str).tolist(), \
        "child_id values returned by load_data must match the input CSV"
    np.testing.assert_allclose(
        sorted_out["severity_at_intake"].astype(float).to_numpy(),
        sorted_in["severity_at_intake"].astype(float).to_numpy(),
        atol=1e-10,
        err_msg="severity_at_intake values must round-trip through load_data",
    )


def test_load_data_raises_file_not_found_on_missing_path():
    """load_data must raise FileNotFoundError when the path does not exist."""
    fn = _get("load_data")
    assert fn is not None, _missing_msg("load_data")

    with tempfile.TemporaryDirectory() as tmp:
        missing_path = os.path.join(tmp, "this_file_does_not_exist.csv")
        with pytest.raises(FileNotFoundError):
            fn(missing_path)


# ---------------------------------------------------------------------------
# Bundled dataset specification
# ---------------------------------------------------------------------------

def test_bundled_dataset_meets_specification():
    """The bundled data/early_intervention.csv satisfies the documented spec."""
    fn = _get("load_data")
    assert fn is not None, _missing_msg("load_data")

    csv_path = REPO_ROOT / "data" / "early_intervention.csv"
    assert csv_path.exists(), (
        f"bundled dataset missing at {csv_path} "
        "(prompt requires data/early_intervention.csv in the repo)"
    )

    df = fn(str(csv_path))
    assert isinstance(df, pd.DataFrame) and len(df) > 0, \
        "bundled dataset must load into a non-empty DataFrame"

    # The prompt mandates exactly the 24 listed columns with the exact names.
    assert set(df.columns) == set(REQUIRED_COLUMNS), (
        "bundled dataset columns must be exactly the 24 specified columns; "
        f"unexpected={set(df.columns) - set(REQUIRED_COLUMNS)}, "
        f"missing={set(REQUIRED_COLUMNS) - set(df.columns)}"
    )

    # child_id is a string-typed column (object or pandas StringDtype) and
    # values are unique (one row per child).
    assert pd.api.types.is_string_dtype(df["child_id"]), (
        f"child_id must have a string dtype (got {df['child_id'].dtype})"
    )
    assert df["child_id"].is_unique, "child_id values must be unique"

    # eligibility_pathway: only the two valid labels and both are represented
    assert set(df["eligibility_pathway"].unique()) == {
        "developmental_delay", "established_condition",
    }

    # severity_at_intake float dtype, values within [0.0, 1.0]
    assert pd.api.types.is_float_dtype(df["severity_at_intake"]), (
        "severity_at_intake must have a float dtype "
        f"(got {df['severity_at_intake'].dtype})"
    )
    assert df["severity_at_intake"].min() >= 0.0
    assert df["severity_at_intake"].max() <= 1.0

    # Hour columns: float dtype and non-negative
    for col in HOUR_COLS:
        assert pd.api.types.is_float_dtype(df[col]), (
            f"{col} must have a float dtype (got {df[col].dtype})"
        )
        assert df[col].min() >= 0.0, f"{col} must be >= 0"

    # Setting columns: only home/community, both present in every column
    for col in SETTING_COLS:
        vals = set(df[col].unique())
        assert vals == {"home", "community"}, (
            f"{col} must contain exactly home and community, got {vals}"
        )

    # provider_id is string-typed and contains exactly 5 distinct values.
    assert pd.api.types.is_string_dtype(df["provider_id"]), (
        f"provider_id must have a string dtype (got {df['provider_id'].dtype})"
    )
    assert df["provider_id"].nunique() == 5

    # The six Part C score columns: float dtype and within [1.0, 7.0]
    for col in ("c1_entry_score", "c1_exit_score",
                "c2_entry_score", "c2_exit_score",
                "c3_entry_score", "c3_exit_score"):
        assert pd.api.types.is_float_dtype(df[col]), (
            f"{col} must have a float dtype (got {df[col].dtype})"
        )
        assert df[col].min() >= 1.0, f"{col} min out of range"
        assert df[col].max() <= 7.0, f"{col} max out of range"

    # transitioned_to_school_district: present and contains only True / False
    # values (the prompt lists this column as bool with values True or False).
    # CSV roundtrip can yield either native bool, integer 0/1, or the strings
    # "True" / "False", so we accept any of those normalized encodings.
    assert "transitioned_to_school_district" in df.columns, \
        "transitioned_to_school_district column is missing from the bundled dataset"

    def _coerce_bool(v):
        if isinstance(v, (bool, np.bool_)):
            return bool(v)
        if isinstance(v, (int, np.integer)) and v in (0, 1):
            return bool(v)
        if isinstance(v, (float, np.floating)) and v in (0.0, 1.0):
            return bool(v)
        if isinstance(v, str):
            s = v.strip().lower()
            if s == "true":
                return True
            if s == "false":
                return False
        return None

    coerced = df["transitioned_to_school_district"].apply(_coerce_bool)
    assert not coerced.isna().any(), (
        "transitioned_to_school_district must contain only True or False values, "
        f"got {sorted(set(df['transitioned_to_school_district'].unique()), key=str)}"
    )

    # transition_age_months: integer dtype with values in [33, 36]
    assert pd.api.types.is_integer_dtype(df["transition_age_months"]), (
        "transition_age_months must have an integer dtype "
        f"(got {df['transition_age_months'].dtype})"
    )
    assert int(df["transition_age_months"].min()) >= 33
    assert int(df["transition_age_months"].max()) <= 36

    # enrollment_year: integer dtype with exactly 6 distinct consecutive values.
    assert pd.api.types.is_integer_dtype(df["enrollment_year"]), (
        "enrollment_year must have an integer dtype "
        f"(got {df['enrollment_year'].dtype})"
    )
    years = sorted(int(y) for y in df["enrollment_year"].unique())
    assert len(years) == 6, f"expected 6 distinct enrollment years, got {len(years)}"
    assert years == list(range(years[0], years[0] + 6)), (
        f"enrollment years must be 6 consecutive integers, got {years}"
    )

    # functional_gain_score: float dtype
    assert pd.api.types.is_float_dtype(df["functional_gain_score"]), (
        "functional_gain_score must have a float dtype "
        f"(got {df['functional_gain_score'].dtype})"
    )


# ---------------------------------------------------------------------------
# compute_eligibility_summary
# ---------------------------------------------------------------------------

def test_compute_eligibility_summary_structure_and_total():
    """Returns dict with the two required keys mapping to int counts summing to N."""
    fn = _get("compute_eligibility_summary")
    assert fn is not None, _missing_msg("compute_eligibility_summary")

    df = _random_df(n=100, seed=2)
    result = fn(df)

    assert isinstance(result, dict), "compute_eligibility_summary must return a dict"
    assert set(result.keys()) == {"developmental_delay", "established_condition"}, \
        "Dict must have exactly the two pathway keys"
    for key, value in result.items():
        assert isinstance(value, (int, np.integer)), \
            f"value for {key} must be an integer, got {type(value)}"
    assert result["developmental_delay"] + result["established_condition"] == len(df)


def test_compute_eligibility_summary_counts_match_input():
    """Per-pathway counts equal the number of rows with that pathway."""
    fn = _get("compute_eligibility_summary")
    assert fn is not None, _missing_msg("compute_eligibility_summary")

    df = _random_df(n=80, seed=3).copy()
    df.loc[df.index[:30], "eligibility_pathway"] = "developmental_delay"
    df.loc[df.index[30:], "eligibility_pathway"] = "established_condition"

    result = fn(df)
    assert int(result["developmental_delay"]) == 30
    assert int(result["established_condition"]) == 50


# ---------------------------------------------------------------------------
# estimate_service_intensity
# ---------------------------------------------------------------------------

def test_estimate_service_intensity_shape_and_categories():
    """Returns 20 rows with the expected quartile / discipline categories."""
    fn = _get("estimate_service_intensity")
    assert fn is not None, _missing_msg("estimate_service_intensity")

    df = _random_df(n=200, seed=4)
    result = fn(df)

    assert isinstance(result, pd.DataFrame)
    for col in ("severity_quartile", "discipline", "mean_hours"):
        assert col in result.columns, f"missing column {col}"
    assert len(result) == 20, "output must contain exactly 20 rows"

    assert pd.api.types.is_integer_dtype(result["severity_quartile"]), (
        "severity_quartile must have an integer dtype "
        f"(got {result['severity_quartile'].dtype})"
    )
    assert pd.api.types.is_float_dtype(result["mean_hours"]), (
        "mean_hours must have a float dtype "
        f"(got {result['mean_hours'].dtype})"
    )

    quartiles = _to_int_set(result["severity_quartile"].unique())
    assert quartiles == [1, 2, 3, 4], \
        f"severity_quartile values must be 1..4, got {quartiles}"

    assert set(result["discipline"].unique()) == set(DISCIPLINES), \
        "discipline values must be the five named disciplines"


def test_estimate_service_intensity_mean_hours_match_quartile_means():
    """The mean_hours per (quartile, discipline) cell equals the qcut-based mean."""
    fn = _get("estimate_service_intensity")
    assert fn is not None, _missing_msg("estimate_service_intensity")

    df = _random_df(n=200, seed=5)
    result = fn(df)

    expected_quartile = pd.qcut(df["severity_at_intake"], 4, labels=[1, 2, 3, 4])
    expected_quartile = expected_quartile.astype(int)

    for d in DISCIPLINES:
        col = f"{d}_hours"
        for q in (1, 2, 3, 4):
            mask = expected_quartile == q
            expected_mean = df.loc[mask, col].mean()
            row = result[(result["discipline"] == d)
                         & (result["severity_quartile"].astype(int) == q)]
            assert len(row) == 1, \
                f"expected exactly one row for q={q}, discipline={d}"
            actual = float(row["mean_hours"].iloc[0])
            assert np.isclose(actual, expected_mean, atol=1e-6), (
                f"mean_hours for q={q}, discipline={d}: "
                f"expected {expected_mean}, got {actual}"
            )


# ---------------------------------------------------------------------------
# identify_provider_patterns
# ---------------------------------------------------------------------------

def test_identify_provider_patterns_one_row_per_provider_and_count_sum():
    """One row per distinct provider; child_count sums to len(df)."""
    fn = _get("identify_provider_patterns")
    assert fn is not None, _missing_msg("identify_provider_patterns")

    df = _random_df(n=180, seed=6)
    result = fn(df)

    assert isinstance(result, pd.DataFrame)
    for col in ("provider_id", "mean_functional_gain",
                "mean_severity_at_intake", "child_count"):
        assert col in result.columns, f"missing column {col}"

    assert len(result) == df["provider_id"].nunique(), \
        "must have one row per distinct provider"
    assert pd.api.types.is_string_dtype(result["provider_id"]), (
        "provider_id must have a string dtype "
        f"(got {result['provider_id'].dtype})"
    )
    assert set(result["provider_id"]) == set(df["provider_id"].unique())
    for float_col in ("mean_functional_gain", "mean_severity_at_intake"):
        assert pd.api.types.is_float_dtype(result[float_col]), (
            f"{float_col} must have a float dtype "
            f"(got {result[float_col].dtype})"
        )
    assert pd.api.types.is_integer_dtype(result["child_count"]), (
        "child_count must have an integer dtype "
        f"(got {result['child_count'].dtype})"
    )
    assert int(result["child_count"].sum()) == len(df), \
        "sum of child_count must equal total rows in input"


def test_identify_provider_patterns_means_and_counts_correct():
    """Per-provider means and counts match a manual groupby."""
    fn = _get("identify_provider_patterns")
    assert fn is not None, _missing_msg("identify_provider_patterns")

    df = _random_df(n=120, seed=7)
    result = fn(df).set_index("provider_id")

    expected = df.groupby("provider_id").agg(
        mean_functional_gain=("functional_gain_score", "mean"),
        mean_severity_at_intake=("severity_at_intake", "mean"),
        child_count=("child_id", "count"),
    )

    for prov, exp_row in expected.iterrows():
        assert prov in result.index, f"provider {prov} missing from output"
        assert np.isclose(float(result.loc[prov, "mean_functional_gain"]),
                          exp_row["mean_functional_gain"], atol=1e-8)
        assert np.isclose(float(result.loc[prov, "mean_severity_at_intake"]),
                          exp_row["mean_severity_at_intake"], atol=1e-8)
        assert int(result.loc[prov, "child_count"]) == int(exp_row["child_count"])


# ---------------------------------------------------------------------------
# compute_part_c_indicators
# ---------------------------------------------------------------------------

def test_compute_part_c_indicators_keys_and_value_ranges():
    """Returns dict with the six required keys; rate keys are bounded in [0,1]."""
    fn = _get("compute_part_c_indicators")
    assert fn is not None, _missing_msg("compute_part_c_indicators")

    df = _random_df(n=200, seed=8)
    result = fn(df)

    assert isinstance(result, dict)
    expected_keys = {
        "c1_mean_gain", "c2_mean_gain", "c3_mean_gain",
        "transition_rate", "mean_transition_age_months", "home_setting_rate",
    }
    assert set(result.keys()) == expected_keys, \
        f"expected exactly {expected_keys}, got {set(result.keys())}"

    # Every value the prompt types as float must actually be a float.
    # np.floating subclasses of Python float are accepted.
    for key in expected_keys:
        assert isinstance(result[key], (float, np.floating)), (
            f"{key} must be a float (got {type(result[key]).__name__})"
        )

    assert 0.0 <= float(result["transition_rate"]) <= 1.0
    assert 0.0 <= float(result["home_setting_rate"]) <= 1.0


def test_compute_part_c_indicators_values_match_manual_computation():
    """Spot-check every indicator against a hand-computed expectation."""
    fn = _get("compute_part_c_indicators")
    assert fn is not None, _missing_msg("compute_part_c_indicators")

    rows = [
        # child 0: transitioned at 33; dt=2/home, sp=0/home, oc=1/community,
        #          ph=0/home, sw=1.5/home  -> active 3, home 2
        dict(child_id="A", eligibility_pathway="developmental_delay",
             severity_at_intake=0.2,
             developmental_therapy_hours=2.0, speech_hours=0.0,
             occupational_hours=1.0, physical_hours=0.0, social_work_hours=1.5,
             developmental_therapy_setting="home", speech_setting="home",
             occupational_setting="community", physical_setting="home",
             social_work_setting="home",
             provider_id="P0",
             c1_entry_score=3.0, c1_exit_score=5.0,
             c2_entry_score=2.0, c2_exit_score=4.0,
             c3_entry_score=1.0, c3_exit_score=2.0,
             transitioned_to_school_district=True,
             transition_age_months=33, enrollment_year=2020,
             functional_gain_score=1.5),
        # child 1: transitioned at 35; dt=0/community, sp=3/home,
        #          oc=0/home, ph=2/community, sw=0/home -> active 2, home 1
        dict(child_id="B", eligibility_pathway="established_condition",
             severity_at_intake=0.5,
             developmental_therapy_hours=0.0, speech_hours=3.0,
             occupational_hours=0.0, physical_hours=2.0, social_work_hours=0.0,
             developmental_therapy_setting="community", speech_setting="home",
             occupational_setting="home", physical_setting="community",
             social_work_setting="home",
             provider_id="P1",
             c1_entry_score=3.0, c1_exit_score=4.0,
             c2_entry_score=1.0, c2_exit_score=3.0,
             c3_entry_score=2.0, c3_exit_score=2.5,
             transitioned_to_school_district=True,
             transition_age_months=35, enrollment_year=2021,
             functional_gain_score=2.0),
        # child 2: did NOT transition; dt=1/home, sp=0.5/community,
        #          oc=0/community, ph=0/community, sw=2/home -> active 3, home 2
        # transition_age_months=36 is deliberately chosen so that the mean
        # over the transitioned children alone (34.0) differs from the mean
        # over all children (~34.67). This catches an implementation that
        # forgets to filter by transitioned_to_school_district == True.
        dict(child_id="C", eligibility_pathway="developmental_delay",
             severity_at_intake=0.7,
             developmental_therapy_hours=1.0, speech_hours=0.5,
             occupational_hours=0.0, physical_hours=0.0, social_work_hours=2.0,
             developmental_therapy_setting="home", speech_setting="community",
             occupational_setting="community", physical_setting="community",
             social_work_setting="home",
             provider_id="P2",
             c1_entry_score=5.0, c1_exit_score=6.0,
             c2_entry_score=4.0, c2_exit_score=4.5,
             c3_entry_score=3.0, c3_exit_score=4.0,
             transitioned_to_school_district=False,
             transition_age_months=36, enrollment_year=2022,
             functional_gain_score=0.8),
    ]
    df = pd.DataFrame(rows)
    result = fn(df)

    # c1 gains = 2, 1, 1 -> mean 4/3 ; c2 = 2, 2, 0.5 -> mean 1.5 ; c3 = 1, 0.5, 1 -> mean 5/6
    assert np.isclose(float(result["c1_mean_gain"]), 4.0 / 3.0, atol=1e-6)
    assert np.isclose(float(result["c2_mean_gain"]), 1.5, atol=1e-6)
    assert np.isclose(float(result["c3_mean_gain"]), 5.0 / 6.0, atol=1e-6)

    # 2 of 3 transitioned
    assert np.isclose(float(result["transition_rate"]), 2.0 / 3.0, atol=1e-6)
    # mean of [33, 35] for transitioned children
    assert np.isclose(float(result["mean_transition_age_months"]), 34.0, atol=1e-6)
    # active pairs total = 3 + 2 + 3 = 8 ; home pairs = 2 + 1 + 2 = 5
    assert np.isclose(float(result["home_setting_rate"]), 5.0 / 8.0, atol=1e-6)


# ---------------------------------------------------------------------------
# distinguish_quality_from_characteristics
# ---------------------------------------------------------------------------

def test_distinguish_quality_columns_and_residual_sum():
    """Output has the documented columns and residual_gain sums to ~0."""
    fn = _get("distinguish_quality_from_characteristics")
    assert fn is not None, _missing_msg("distinguish_quality_from_characteristics")

    df = _random_df(n=200, seed=9)
    result = fn(df)

    assert isinstance(result, pd.DataFrame)
    expected_cols = {"child_id", "provider_id", "severity_at_intake",
                     "functional_gain_score", "residual_gain"}
    missing = expected_cols - set(result.columns)
    assert not missing, f"missing columns: {missing}"

    assert len(result) == len(df), \
        "output must contain one row per input child"
    assert pd.api.types.is_string_dtype(result["child_id"]), (
        "child_id must have a string dtype "
        f"(got {result['child_id'].dtype})"
    )
    assert pd.api.types.is_string_dtype(result["provider_id"]), (
        "provider_id must have a string dtype "
        f"(got {result['provider_id'].dtype})"
    )
    for float_col in ("severity_at_intake", "functional_gain_score",
                      "residual_gain"):
        assert pd.api.types.is_float_dtype(result[float_col]), (
            f"{float_col} must have a float dtype "
            f"(got {result[float_col].dtype})"
        )
    # OLS with intercept => residuals sum to ~0
    assert abs(float(result["residual_gain"].sum())) < 1e-6


def test_distinguish_quality_residuals_match_ols_fit():
    """residual_gain equals y - prediction from OLS on severity + 5 hour cols."""
    fn = _get("distinguish_quality_from_characteristics")
    assert fn is not None, _missing_msg("distinguish_quality_from_characteristics")

    df = _random_df(n=300, seed=10)
    result = fn(df).set_index("child_id")

    try:
        from sklearn.linear_model import LinearRegression
    except Exception:
        pytest.fail("scikit-learn must be available to verify OLS residuals")

    feature_cols = ["severity_at_intake"] + HOUR_COLS
    X = df[feature_cols].to_numpy(dtype=float)
    y = df["functional_gain_score"].to_numpy(dtype=float)
    expected_residuals = y - LinearRegression().fit(X, y).predict(X)

    expected_series = pd.Series(expected_residuals, index=df["child_id"])
    aligned = result["residual_gain"].astype(float).reindex(expected_series.index)
    assert not aligned.isna().any(), \
        "every input child_id must appear in the output"
    diff = (aligned.to_numpy() - expected_series.to_numpy())
    assert np.max(np.abs(diff)) < 1e-6, \
        "residuals must match OLS(y ~ severity + 5 hour cols)"


def test_distinguish_quality_passthrough_columns_match_input():
    """provider_id, severity_at_intake and functional_gain_score in the output
    equal the corresponding per-child values from the input DataFrame."""
    fn = _get("distinguish_quality_from_characteristics")
    assert fn is not None, _missing_msg("distinguish_quality_from_characteristics")

    df = _random_df(n=160, seed=21)
    result = fn(df)
    assert len(result) == len(df), "must return one row per input child"

    inp = df.set_index("child_id")
    out = result.set_index("child_id").reindex(inp.index)

    assert not out["provider_id"].isna().any(), \
        "every input child_id must appear in the output"

    expected_providers = inp["provider_id"].astype(str).to_list()
    actual_providers = out["provider_id"].astype(str).to_list()
    assert actual_providers == expected_providers, (
        "provider_id values in the output must match the input row by row "
        "(downstream rank_providers_adjusted depends on this)"
    )

    for col in ("severity_at_intake", "functional_gain_score"):
        np.testing.assert_allclose(
            out[col].astype(float).to_numpy(),
            inp[col].astype(float).to_numpy(),
            atol=1e-10,
            err_msg=f"{col} values in the output must equal the input",
        )


# ---------------------------------------------------------------------------
# rank_providers_adjusted
# ---------------------------------------------------------------------------

def test_rank_providers_adjusted_shape_and_count_sum():
    """One row per provider; child_count sums to total rows in residuals_df."""
    fn = _get("rank_providers_adjusted")
    assert fn is not None, _missing_msg("rank_providers_adjusted")

    # Build a residuals-shaped DataFrame directly so this test does not
    # depend on distinguish_quality_from_characteristics being implemented.
    rng = np.random.default_rng(20)
    providers = [f"P{i}" for i in range(5)]
    n = 150
    residuals_df = pd.DataFrame({
        "child_id": [f"C{i:04d}" for i in range(n)],
        "provider_id": rng.choice(providers, n),
        "severity_at_intake": rng.uniform(0, 1, n),
        "functional_gain_score": rng.normal(0, 1, n),
        "residual_gain": rng.normal(0, 0.5, n),
    })

    result = fn(residuals_df)
    assert isinstance(result, pd.DataFrame)
    for col in ("provider_id", "mean_residual_gain", "child_count"):
        assert col in result.columns, f"missing column {col}"

    assert len(result) == residuals_df["provider_id"].nunique()
    assert pd.api.types.is_string_dtype(result["provider_id"]), (
        "provider_id must have a string dtype "
        f"(got {result['provider_id'].dtype})"
    )
    assert set(result["provider_id"]) == set(residuals_df["provider_id"].unique())
    assert pd.api.types.is_float_dtype(result["mean_residual_gain"]), (
        "mean_residual_gain must have a float dtype "
        f"(got {result['mean_residual_gain'].dtype})"
    )
    assert pd.api.types.is_integer_dtype(result["child_count"]), (
        "child_count must have an integer dtype "
        f"(got {result['child_count'].dtype})"
    )
    assert int(result["child_count"].sum()) == len(residuals_df)


def test_rank_providers_adjusted_means_correct():
    """Per-provider mean_residual_gain matches a manual groupby mean."""
    fn = _get("rank_providers_adjusted")
    assert fn is not None, _missing_msg("rank_providers_adjusted")

    residuals_df = pd.DataFrame({
        "child_id": list("ABCDEF"),
        "provider_id": ["P0", "P0", "P0", "P1", "P1", "P2"],
        "severity_at_intake": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6],
        "functional_gain_score": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0],
        "residual_gain": [0.5, -0.5, 1.0, 2.0, -2.0, 0.0],
    })
    result = fn(residuals_df).set_index("provider_id")

    assert np.isclose(float(result.loc["P0", "mean_residual_gain"]), (0.5 - 0.5 + 1.0) / 3.0)
    assert np.isclose(float(result.loc["P1", "mean_residual_gain"]), (2.0 - 2.0) / 2.0)
    assert np.isclose(float(result.loc["P2", "mean_residual_gain"]), 0.0)
    assert int(result.loc["P0", "child_count"]) == 3
    assert int(result.loc["P1", "child_count"]) == 2
    assert int(result.loc["P2", "child_count"]) == 1


# ---------------------------------------------------------------------------
# compute_annual_trends
# ---------------------------------------------------------------------------

def test_compute_annual_trends_shape_and_columns():
    """One row per enrollment_year with the documented columns."""
    fn = _get("compute_annual_trends")
    assert fn is not None, _missing_msg("compute_annual_trends")

    df = _random_df(n=240, seed=12)
    result = fn(df)

    assert isinstance(result, pd.DataFrame)
    expected_cols = {"enrollment_year", "child_count", "mean_functional_gain",
                     "transition_rate", "home_setting_rate",
                     "c1_mean_gain", "c2_mean_gain", "c3_mean_gain"}
    missing = expected_cols - set(result.columns)
    assert not missing, f"missing columns: {missing}"

    assert len(result) == df["enrollment_year"].nunique()
    assert pd.api.types.is_integer_dtype(result["enrollment_year"]), (
        "compute_annual_trends output enrollment_year must have an integer dtype "
        f"(got {result['enrollment_year'].dtype})"
    )
    assert set(result["enrollment_year"]) == set(df["enrollment_year"].unique())
    assert pd.api.types.is_integer_dtype(result["child_count"]), (
        "child_count must have an integer dtype "
        f"(got {result['child_count'].dtype})"
    )
    assert int(result["child_count"].sum()) == len(df)

    # All six prompt-typed-float aggregate columns must have a float dtype.
    for float_col in ("mean_functional_gain", "transition_rate",
                      "home_setting_rate", "c1_mean_gain",
                      "c2_mean_gain", "c3_mean_gain"):
        assert pd.api.types.is_float_dtype(result[float_col]), (
            f"{float_col} must have a float dtype "
            f"(got {result[float_col].dtype})"
        )

    # transition_rate and home_setting_rate are proportions, so each row's
    # value must lie within [0.0, 1.0] just as in compute_part_c_indicators.
    for rate_col in ("transition_rate", "home_setting_rate"):
        rates = result[rate_col].astype(float)
        assert (rates >= 0.0).all() and (rates <= 1.0).all(), (
            f"{rate_col} values must lie in [0.0, 1.0]; "
            f"got min={rates.min()}, max={rates.max()}"
        )


def test_compute_annual_trends_values_match_manual_year_aggregates():
    """For one synthetic year, trend metrics match a direct calculation."""
    fn = _get("compute_annual_trends")
    assert fn is not None, _missing_msg("compute_annual_trends")

    df = _random_df(n=240, seed=13)

    # Inject zero-hour cells so the strictly-positive-hours filter for
    # home_setting_rate is non-trivially exercised. rng.uniform produces a
    # continuous distribution so without this step every (child, discipline)
    # pair has hours > 0, which means an implementation that ignores the
    # "hours > 0" filter would yield the same number as a compliant one and
    # the test would not discriminate.
    for i, col in enumerate(HOUR_COLS):
        block_start = i * 25
        block_end = block_start + 25
        df.loc[df.index[block_start:block_end], col] = 0.0

    result = fn(df)
    result_by_year = result.set_index(result["enrollment_year"].astype(int))

    for year, sub in df.groupby("enrollment_year"):
        year_int = int(year)
        assert year_int in result_by_year.index, f"year {year_int} missing"
        row = result_by_year.loc[year_int]

        assert int(row["child_count"]) == len(sub)
        assert np.isclose(float(row["mean_functional_gain"]),
                          sub["functional_gain_score"].mean(), atol=1e-8)
        assert np.isclose(float(row["transition_rate"]),
                          sub["transitioned_to_school_district"].mean(), atol=1e-8)
        assert np.isclose(float(row["c1_mean_gain"]),
                          (sub["c1_exit_score"] - sub["c1_entry_score"]).mean(),
                          atol=1e-8)
        assert np.isclose(float(row["c2_mean_gain"]),
                          (sub["c2_exit_score"] - sub["c2_entry_score"]).mean(),
                          atol=1e-8)
        assert np.isclose(float(row["c3_mean_gain"]),
                          (sub["c3_exit_score"] - sub["c3_entry_score"]).mean(),
                          atol=1e-8)

        # home_setting_rate over (child, discipline) pairs with hours > 0
        active = 0
        home_active = 0
        for d in DISCIPLINES:
            mask = sub[f"{d}_hours"] > 0
            active += int(mask.sum())
            home_active += int((mask & (sub[f"{d}_setting"] == "home")).sum())
        if active > 0:
            assert np.isclose(float(row["home_setting_rate"]),
                              home_active / active, atol=1e-8)


# ---------------------------------------------------------------------------
# estimate_discipline_outcomes
# ---------------------------------------------------------------------------

def test_estimate_discipline_outcomes_shape_and_categories():
    """Output has 5 rows, one per discipline, with documented columns."""
    fn = _get("estimate_discipline_outcomes")
    assert fn is not None, _missing_msg("estimate_discipline_outcomes")

    df = _random_df(n=300, seed=14)
    result = fn(df)

    assert isinstance(result, pd.DataFrame)
    for col in ("discipline", "estimated_hours_coefficient"):
        assert col in result.columns, f"missing column {col}"
    assert len(result) == 5, "output must contain exactly 5 rows"
    assert set(result["discipline"]) == set(DISCIPLINES), \
        "discipline values must be the five named disciplines"
    assert pd.api.types.is_float_dtype(result["estimated_hours_coefficient"]), (
        "estimated_hours_coefficient must have a float dtype "
        f"(got {result['estimated_hours_coefficient'].dtype})"
    )


def test_estimate_discipline_outcomes_coefficients_match_partial_regression():
    """Coefficients equal the OLS partial coefficients (controlling for severity)."""
    fn = _get("estimate_discipline_outcomes")
    assert fn is not None, _missing_msg("estimate_discipline_outcomes")

    rng = np.random.default_rng(15)
    n = 400
    severity = rng.uniform(0.0, 1.0, n)
    hours = {f"{d}_hours": rng.uniform(0.0, 5.0, n) for d in DISCIPLINES}
    true_coefs = {
        "developmental_therapy_hours": 0.50,
        "speech_hours": 0.30,
        "occupational_hours": -0.20,
        "physical_hours": 0.10,
        "social_work_hours": 0.40,
    }
    y = -0.7 * severity + sum(true_coefs[c] * hours[c] for c in HOUR_COLS) \
        + rng.normal(0.0, 0.3, n)

    df = _random_df(n=n, seed=16).reset_index(drop=True)
    df["severity_at_intake"] = severity
    for c in HOUR_COLS:
        df[c] = hours[c]
    df["functional_gain_score"] = y

    try:
        from sklearn.linear_model import LinearRegression
    except Exception:
        pytest.fail("scikit-learn must be available to verify partial coefficients")

    X = df[["severity_at_intake"] + HOUR_COLS].to_numpy(dtype=float)
    expected = LinearRegression().fit(X, df["functional_gain_score"]).coef_
    expected_for_hours = dict(zip(HOUR_COLS, expected[1:]))

    result = fn(df).set_index("discipline")
    for d in DISCIPLINES:
        actual = float(result.loc[d, "estimated_hours_coefficient"])
        exp = float(expected_for_hours[f"{d}_hours"])
        assert np.isclose(actual, exp, atol=1e-4), (
            f"coefficient for {d}: expected ~{exp}, got {actual}"
        )
