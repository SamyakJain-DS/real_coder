import math
import os
import re
import pytest
import numpy as np
import pandas as pd
from pathlib import Path

# ---------------------------------------------------------------------------
# Graceful import: assign None when pipeline.py does not exist.
# ---------------------------------------------------------------------------
try:
    from pipeline import (
        load_district_data,
        load_school_data,
        compute_equity_metrics,
        decompose_fiscal_effects,
        identify_resource_outcome_patterns,
        generate_nces_ccd_submission,
        generate_legislative_report,
    )
except ImportError:
    load_district_data = None
    load_school_data = None
    compute_equity_metrics = None
    decompose_fiscal_effects = None
    identify_resource_outcome_patterns = None
    generate_nces_ccd_submission = None
    generate_legislative_report = None

# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------
DISTRICTS = ["D001", "D002", "D003"]
SCHOOLS = ["S001", "S002"]
YEARS = [2015, 2016, 2017, 2018, 2019, 2020, 2021]
NEED_WEIGHTS = {"poverty_weight": 0.25, "ell_weight": 0.10, "disability_weight": 0.15}


# ---------------------------------------------------------------------------
# CSV-writing helpers (pure I/O, never call pipeline code)
# ---------------------------------------------------------------------------

def _write_district_finance(path: Path) -> None:
    rows = []
    for i, d in enumerate(DISTRICTS):
        for j, y in enumerate(YEARS):
            rows.append({
                "district_id": d, "year": y,
                "state_foundation_pprev": 5000.0 + i * 500 + j * 10,
                "local_tax_pprev": 2000.0 + i * 200 + j * 5,
                "enrollment": 500 + i * 100 + j * 10,
            })
    pd.DataFrame(rows).to_csv(path / "district_finance.csv", index=False)


def _write_district_expenditure(path: Path) -> None:
    combos = [
        ("1000", "100", 2000.0), ("1000", "200", 500.0), ("1000", "300", 300.0),
        ("2000", "100", 1000.0), ("2000", "200", 250.0), ("2000", "300", 150.0),
    ]
    rows = []
    for i, d in enumerate(DISTRICTS):
        for j, y in enumerate(YEARS):
            for fc, oc, base in combos:
                rows.append({
                    "district_id": d, "year": y,
                    "function_code": fc, "object_code": oc,
                    "ppupil_expenditure": base + i * 50.0 + j * 2.0,
                })
    pd.DataFrame(rows).to_csv(path / "district_expenditure.csv", index=False)


def _write_demographics(path: Path) -> None:
    rows = []
    for i, d in enumerate(DISTRICTS):
        for j, y in enumerate(YEARS):
            rows.append({
                "district_id": d, "year": y,
                "pct_poverty": 0.10 + i * 0.05 + j * 0.005,
                "pct_ell": 0.05 + i * 0.02 + j * 0.002,
                "pct_disability": 0.08 + i * 0.01 + j * 0.001,
            })
    pd.DataFrame(rows).to_csv(path / "demographics.csv", index=False)


def _write_school_demographics(path: Path) -> None:
    rows = []
    for i, d in enumerate(DISTRICTS):
        for k, s in enumerate(SCHOOLS):
            for j, y in enumerate(YEARS):
                rows.append({
                    "district_id": d, "school_id": s, "year": y,
                    # pct_poverty linear, pct_ell quadratic, pct_disability cubic in j.
                    # Lower-triangular polynomial coefficient matrix -> full rank for any 4+ distinct j.
                    "pct_poverty":    0.10 + i * 0.05 + k * 0.03 + j * 0.005,
                    "pct_ell":        0.05 + i * 0.02 + k * 0.01 + j * 0.003 + j * j * 0.001,
                    "pct_disability": 0.08 + i * 0.01 + k * 0.005 + j * 0.002 + j * j * 0.0005 + (j ** 3) * 0.0001,
                })
    pd.DataFrame(rows).to_csv(path / "school_demographics.csv", index=False)


def _write_federal_grants(path: Path) -> None:
    rows = []
    for i, d in enumerate(DISTRICTS):
        for j, y in enumerate(YEARS):
            rows.append({
                "district_id": d, "year": y,
                "title1_expenditure": 50000.0 + i * 5000 + j * 500,
                "idea_expenditure":   30000.0 + i * 3000 + j * 300,
                "title3_expenditure": 10000.0 + i * 1000 + j * 100,
            })
    pd.DataFrame(rows).to_csv(path / "federal_grants.csv", index=False)


def _write_capital_debt(path: Path) -> None:
    rows = []
    for i, d in enumerate(DISTRICTS):
        for j, y in enumerate(YEARS):
            rows.append({
                "district_id": d, "year": y,
                "capital_expenditure": 200000.0 + i * 20000 + j * 2000,
                "bonded_indebtedness": 1000000.0 + i * 100000 + j * 10000,
            })
    pd.DataFrame(rows).to_csv(path / "capital_debt.csv", index=False)


def _write_property_wealth(path: Path) -> None:
    rows = []
    for i, d in enumerate(DISTRICTS):
        for j, y in enumerate(YEARS):
            rows.append({
                "district_id": d, "year": y,
                "assessed_value_per_pupil": 200000.0 + i * 50000 + j * 5000,
                "mill_rate": 20.0 + i * 3.0 + j * 0.5,
            })
    pd.DataFrame(rows).to_csv(path / "property_wealth.csv", index=False)


def _write_school_resources(path: Path) -> None:
    rows = []
    for i, d in enumerate(DISTRICTS):
        for k, s in enumerate(SCHOOLS):
            for j, y in enumerate(YEARS):
                rows.append({
                    "district_id": d, "school_id": s, "year": y,
                    "ppupil_expenditure": 8000.0 + i * 500 + k * 200 + j * 50,
                    "outcome_score":      70.0  + i * 5.0 + k * 3.0 + j * 2.0,
                })
    pd.DataFrame(rows).to_csv(path / "school_resources.csv", index=False)


# ---------------------------------------------------------------------------
# ONE fixture: data_dir - writes CSV files only, never calls pipeline code.
# Safe on an empty repo; only pandas (always installed) is needed.
# ---------------------------------------------------------------------------

@pytest.fixture
def data_dir(tmp_path: Path) -> str:
    _write_district_finance(tmp_path)
    _write_district_expenditure(tmp_path)
    _write_demographics(tmp_path)
    _write_school_demographics(tmp_path)
    _write_federal_grants(tmp_path)
    _write_capital_debt(tmp_path)
    _write_property_wealth(tmp_path)
    _write_school_resources(tmp_path)
    return str(tmp_path)


# ---------------------------------------------------------------------------
# Plain helper functions - called from test bodies so pytest.fail() produces
# FAILED (not ERROR) when a pipeline function is not yet implemented.
# ---------------------------------------------------------------------------

def _load_district(data_dir):
    if load_district_data is None:
        pytest.fail("load_district_data not importable from pipeline")
    return load_district_data(data_dir)


def _load_school(data_dir):
    if load_school_data is None:
        pytest.fail("load_school_data not importable from pipeline")
    return load_school_data(data_dir)


def _equity(district_df):
    if compute_equity_metrics is None:
        pytest.fail("compute_equity_metrics not importable from pipeline")
    return compute_equity_metrics(district_df, NEED_WEIGHTS)


def _fiscal(equity_df):
    if decompose_fiscal_effects is None:
        pytest.fail("decompose_fiscal_effects not importable from pipeline")
    return decompose_fiscal_effects(equity_df)


def _patterns(school_df):
    if identify_resource_outcome_patterns is None:
        pytest.fail("identify_resource_outcome_patterns not importable from pipeline")
    return identify_resource_outcome_patterns(school_df)


def _build_fiscal(data_dir):
    """Build fiscal_df through the full district chain."""
    return _fiscal(_equity(_load_district(data_dir)))


def _build_fiscal_and_pattern(data_dir):
    """Build both fiscal_df and pattern_df for legislative report tests."""
    fiscal = _build_fiscal(data_dir)
    pattern = _patterns(_load_school(data_dir))
    return fiscal, pattern


# ===========================================================================
# ID 75: all seven pipeline functions importable from pipeline.py
# ===========================================================================

def test_load_district_data_one_row_per_district_year(data_dir):
    df = _load_district(data_dir)
    assert not df.duplicated(subset=["district_id", "year"]).any()


def test_load_district_data_has_all_six_cross_classified_expenditure_columns(data_dir):
    df = _load_district(data_dir)
    for col in [
        "instruction_salaries_ppupil", "instruction_benefits_ppupil",
        "instruction_purchased_services_ppupil",
        "support_salaries_ppupil", "support_benefits_ppupil",
        "support_purchased_services_ppupil",
    ]:
        assert col in df.columns, f"Expected column missing: {col}"


def test_load_district_data_contains_source_columns_from_all_six_files(data_dir):
    df = _load_district(data_dir)
    for col in [
        "state_foundation_pprev", "local_tax_pprev", "enrollment",
        "pct_poverty", "pct_ell", "pct_disability",
        "title1_expenditure", "idea_expenditure", "title3_expenditure",
        "capital_expenditure", "bonded_indebtedness",
        "assessed_value_per_pupil", "mill_rate",
    ]:
        assert col in df.columns, f"Source column '{col}' missing from district_df"


def test_load_district_data_instruction_ppupil_is_sum_of_object_columns(data_dir):
    df = _load_district(data_dir)
    expected = (
        df["instruction_salaries_ppupil"]
        + df["instruction_benefits_ppupil"]
        + df["instruction_purchased_services_ppupil"]
    )
    np.testing.assert_allclose(df["instruction_ppupil"].values, expected.values, rtol=1e-9)


def test_load_district_data_support_ppupil_is_sum_of_object_columns(data_dir):
    df = _load_district(data_dir)
    expected = (
        df["support_salaries_ppupil"]
        + df["support_benefits_ppupil"]
        + df["support_purchased_services_ppupil"]
    )
    np.testing.assert_allclose(df["support_ppupil"].values, expected.values, rtol=1e-9)


def test_load_school_data_one_row_per_district_school_year(data_dir):
    df = _load_school(data_dir)
    assert not df.duplicated(subset=["district_id", "school_id", "year"]).any()


def test_load_school_data_has_all_required_columns(data_dir):
    df = _load_school(data_dir)
    for col in [
        "district_id", "school_id", "year",
        "ppupil_expenditure", "outcome_score",
        "pct_poverty", "pct_ell", "pct_disability",
    ]:
        assert col in df.columns, f"Expected column missing: {col}"


def test_compute_equity_metrics_adds_exactly_six_columns(data_dir):
    d_df = _load_district(data_dir)
    e_df = _equity(d_df)
    new_cols = set(e_df.columns) - set(d_df.columns)
    assert len(new_cols) == 6


def test_compute_equity_metrics_total_pprev_formula(data_dir):
    e_df = _equity(_load_district(data_dir))
    expected = e_df["state_foundation_pprev"] + e_df["local_tax_pprev"]
    np.testing.assert_allclose(e_df["total_pprev"].values, expected.values, rtol=1e-9)


def test_compute_equity_metrics_state_local_revenue_formula(data_dir):
    e_df = _equity(_load_district(data_dir))
    expected = e_df["total_pprev"] * e_df["enrollment"]
    np.testing.assert_allclose(e_df["state_local_revenue"].values, expected.values, rtol=1e-9)


def test_compute_equity_metrics_need_adjusted_enrollment_formula(data_dir):
    e_df = _equity(_load_district(data_dir))
    w = NEED_WEIGHTS
    expected = e_df["enrollment"] * (
        1
        + w["poverty_weight"] * e_df["pct_poverty"]
        + w["ell_weight"] * e_df["pct_ell"]
        + w["disability_weight"] * e_df["pct_disability"]
    )
    np.testing.assert_allclose(e_df["need_adjusted_enrollment"].values, expected.values, rtol=1e-9)


def test_compute_equity_metrics_need_weighted_pprev_formula(data_dir):
    e_df = _equity(_load_district(data_dir))
    expected = e_df["state_local_revenue"] / e_df["need_adjusted_enrollment"]
    np.testing.assert_allclose(e_df["need_weighted_pprev"].values, expected.values, rtol=1e-9)


def test_compute_equity_metrics_equity_cv_constant_within_each_year(data_dir):
    e_df = _equity(_load_district(data_dir))
    for year, grp in e_df.groupby("year"):
        vals = grp["equity_cv"].values
        assert np.allclose(vals, vals[0]), f"equity_cv not constant in year {year}"


def test_compute_equity_metrics_equity_cv_formula_uses_ddof1(data_dir):
    e_df = _equity(_load_district(data_dir))
    for year, grp in e_df.groupby("year"):
        nwp = grp["need_weighted_pprev"]
        expected_cv = nwp.std(ddof=1) / nwp.mean()
        assert math.isclose(grp["equity_cv"].iloc[0], expected_cv, rel_tol=1e-9)


def test_compute_equity_metrics_adequacy_gap_formula(data_dir):
    e_df = _equity(_load_district(data_dir))
    for year, grp in e_df.groupby("year"):
        expected = grp["need_weighted_pprev"] - grp["need_weighted_pprev"].median()
        np.testing.assert_allclose(grp["adequacy_gap"].values, expected.values, rtol=1e-9)


def test_decompose_fiscal_effects_adds_exactly_five_columns(data_dir):
    e_df = _equity(_load_district(data_dir))
    f_df = _fiscal(e_df)
    new_cols = set(f_df.columns) - set(e_df.columns)
    assert len(new_cols) == 5


def test_decompose_fiscal_effects_effort_residual_formula(data_dir):
    f_df = _build_fiscal(data_dir)
    expected = f_df["total_pprev"] - f_df["capacity_predicted_rev"]
    np.testing.assert_allclose(f_df["effort_residual"].values, expected.values, rtol=1e-9)


def test_decompose_fiscal_effects_debt_burden_ppupil_formula(data_dir):
    f_df = _build_fiscal(data_dir)
    expected = f_df["bonded_indebtedness"] / f_df["enrollment"]
    np.testing.assert_allclose(f_df["debt_burden_ppupil"].values, expected.values, rtol=1e-9)


def test_identify_resource_outcome_patterns_adds_exactly_three_columns(data_dir):
    s_df = _load_school(data_dir)
    p_df = _patterns(s_df)
    new_cols = set(p_df.columns) - set(s_df.columns)
    assert len(new_cols) == 3


def test_identify_resource_outcome_patterns_correlation_broadcast_within_group(data_dir):
    p_df = _patterns(_load_school(data_dir))
    for (d, s), grp in p_df.groupby(["district_id", "school_id"]):
        non_nan = grp["resource_outcome_correlation"].dropna()
        if len(non_nan) > 0:
            assert np.allclose(non_nan.values, non_nan.iloc[0])


def test_identify_resource_outcome_patterns_trajectory_broadcast_within_group(data_dir):
    p_df = _patterns(_load_school(data_dir))
    for (d, s), grp in p_df.groupby(["district_id", "school_id"]):
        non_nan = grp["outcome_trajectory"].dropna()
        if len(non_nan) > 0:
            assert np.allclose(non_nan.values, non_nan.iloc[0])


def test_identify_resource_outcome_patterns_need_adjusted_nan_when_fewer_than_5_points():
    if identify_resource_outcome_patterns is None:
        pytest.fail("identify_resource_outcome_patterns not importable from pipeline")
    rows = []
    for y in YEARS[:3]:
        rows.append({
            "district_id": "D001", "school_id": "S001", "year": y,
            "ppupil_expenditure": 8000.0, "outcome_score": 70.0,
            "pct_poverty": 0.10, "pct_ell": 0.05, "pct_disability": 0.08,
        })
    for j, y in enumerate(YEARS):
        rows.append({
            "district_id": "D001", "school_id": "S002", "year": y,
            "ppupil_expenditure": 8000.0 + j * 50, "outcome_score": 70.0 + j * 2.0,
            "pct_poverty": 0.10 + j * 0.005,
            "pct_ell": 0.05 + j * 0.003 + j * j * 0.001,
            "pct_disability": 0.08 + j * 0.002 + j * j * 0.0005 + (j ** 3) * 0.0001,
        })
    result = identify_resource_outcome_patterns(pd.DataFrame(rows))
    s1 = result[(result["district_id"] == "D001") & (result["school_id"] == "S001")]
    assert s1["need_adjusted_outcome_score"].isna().all()


def test_identify_resource_outcome_patterns_downstream_nan_when_need_adjusted_all_nan():
    if identify_resource_outcome_patterns is None:
        pytest.fail("identify_resource_outcome_patterns not importable from pipeline")
    rows = [
        {
            "district_id": "D001", "school_id": "S001", "year": y,
            "ppupil_expenditure": 8000.0, "outcome_score": 70.0,
            "pct_poverty": 0.10, "pct_ell": 0.05, "pct_disability": 0.08,
        }
        for y in YEARS[:4]
    ]
    result = identify_resource_outcome_patterns(pd.DataFrame(rows))
    assert result["resource_outcome_correlation"].isna().all()
    assert result["outcome_trajectory"].isna().all()


def test_identify_resource_outcome_patterns_correlation_equals_pearson_of_residuals(data_dir):
    p_df = _patterns(_load_school(data_dir))
    for (d, s), grp in p_df.groupby(["district_id", "school_id"]):
        valid = grp.dropna(subset=["need_adjusted_outcome_score"])
        if len(valid) >= 2:
            expected_corr = valid["ppupil_expenditure"].corr(valid["need_adjusted_outcome_score"])
            actual_corr = grp["resource_outcome_correlation"].dropna().iloc[0]
            assert math.isclose(actual_corr, expected_corr, rel_tol=1e-9)


def test_identify_resource_outcome_patterns_trajectory_equals_ols_slope(data_dir):
    p_df = _patterns(_load_school(data_dir))
    for (d, s), grp in p_df.groupby(["district_id", "school_id"]):
        valid = grp.dropna(subset=["need_adjusted_outcome_score"])
        if len(valid) >= 2:
            slope = np.polyfit(
                valid["year"].values.astype(float),
                valid["need_adjusted_outcome_score"].values,
                1,
            )[0]
            actual = grp["outcome_trajectory"].dropna().iloc[0]
            assert math.isclose(actual, slope, rel_tol=1e-9, abs_tol=1e-9)


# ===========================================================================
# generate_nces_ccd_submission
# ===========================================================================

def test_generate_nces_ccd_submission_one_row_per_district_year(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    f_df = _build_fiscal(data_dir)
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(f_df, out)
    result = pd.read_csv(out)
    assert not result.duplicated(subset=["district_id", "year"]).any()
    assert len(result) == len(f_df[["district_id", "year"]].drop_duplicates())


def test_generate_nces_ccd_submission_has_exactly_20_columns(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(_build_fiscal(data_dir), out)
    assert len(pd.read_csv(out).columns) == 20


def test_generate_nces_ccd_submission_state_revenue_formula(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    f_df = _build_fiscal(data_dir)
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(f_df, out)
    result = pd.read_csv(out)
    merged = result.merge(
        f_df[["district_id", "year", "state_foundation_pprev", "enrollment"]],
        on=["district_id", "year"],
    )
    np.testing.assert_allclose(
        merged["state_revenue"].values,
        (merged["state_foundation_pprev"] * merged["enrollment"]).values,
        rtol=1e-9,
    )


def test_generate_nces_ccd_submission_local_revenue_formula(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    f_df = _build_fiscal(data_dir)
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(f_df, out)
    result = pd.read_csv(out)
    merged = result.merge(
        f_df[["district_id", "year", "local_tax_pprev", "enrollment"]],
        on=["district_id", "year"],
    )
    np.testing.assert_allclose(
        merged["local_revenue"].values,
        (merged["local_tax_pprev"] * merged["enrollment"]).values,
        rtol=1e-9,
    )


def test_generate_nces_ccd_submission_federal_revenue_approx_formula(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(_build_fiscal(data_dir), out)
    result = pd.read_csv(out)
    expected = (
        result["title1_expenditure"]
        + result["idea_expenditure"]
        + result["title3_expenditure"]
    )
    np.testing.assert_allclose(result["federal_revenue_approx"].values, expected.values, rtol=1e-9)


def test_generate_nces_ccd_submission_total_revenue_formula(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(_build_fiscal(data_dir), out)
    result = pd.read_csv(out)
    expected = result["state_revenue"] + result["local_revenue"] + result["federal_revenue_approx"]
    np.testing.assert_allclose(result["total_revenue"].values, expected.values, rtol=1e-9)


def test_generate_nces_ccd_submission_instruction_expenditure_formula(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    f_df = _build_fiscal(data_dir)
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(f_df, out)
    result = pd.read_csv(out)
    merged = result.merge(
        f_df[["district_id", "year", "instruction_ppupil", "enrollment"]],
        on=["district_id", "year"],
    )
    np.testing.assert_allclose(
        merged["instruction_expenditure"].values,
        (merged["instruction_ppupil"] * merged["enrollment"]).values,
        rtol=1e-9,
    )


def test_generate_nces_ccd_submission_support_services_expenditure_formula(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    f_df = _build_fiscal(data_dir)
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(f_df, out)
    result = pd.read_csv(out)
    merged = result.merge(
        f_df[["district_id", "year", "support_ppupil", "enrollment"]],
        on=["district_id", "year"],
    )
    np.testing.assert_allclose(
        merged["support_services_expenditure"].values,
        (merged["support_ppupil"] * merged["enrollment"]).values,
        rtol=1e-9,
    )


def test_generate_nces_ccd_submission_capital_outlay_equals_capital_expenditure(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    f_df = _build_fiscal(data_dir)
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(f_df, out)
    result = pd.read_csv(out)
    merged = result.merge(
        f_df[["district_id", "year", "capital_expenditure"]],
        on=["district_id", "year"],
    )
    np.testing.assert_allclose(
        merged["capital_outlay_expenditure"].values,
        merged["capital_expenditure"].values,
        rtol=1e-9,
    )


def test_generate_nces_ccd_submission_total_expenditure_formula(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(_build_fiscal(data_dir), out)
    result = pd.read_csv(out)
    expected = (
        result["instruction_expenditure"]
        + result["support_services_expenditure"]
        + result["capital_outlay_expenditure"]
    )
    np.testing.assert_allclose(result["total_expenditure"].values, expected.values, rtol=1e-9)


@pytest.mark.parametrize("output_col,source_col", [
    ("instruction_salaries",           "instruction_salaries_ppupil"),
    ("instruction_benefits",           "instruction_benefits_ppupil"),
    ("instruction_purchased_services", "instruction_purchased_services_ppupil"),
    ("support_salaries",               "support_salaries_ppupil"),
    ("support_benefits",               "support_benefits_ppupil"),
    ("support_purchased_services",     "support_purchased_services_ppupil"),
])
def test_generate_nces_ccd_submission_object_expenditure_formula(
    data_dir, tmp_path, output_col, source_col
):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    f_df = _build_fiscal(data_dir)
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(f_df, out)
    result = pd.read_csv(out)
    merged = result.merge(
        f_df[["district_id", "year", source_col, "enrollment"]],
        on=["district_id", "year"],
    )
    np.testing.assert_allclose(
        merged[output_col].values,
        (merged[source_col] * merged["enrollment"]).values,
        rtol=1e-9,
    )


def test_generate_nces_ccd_submission_long_term_debt_equals_bonded_indebtedness(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    f_df = _build_fiscal(data_dir)
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(f_df, out)
    result = pd.read_csv(out)
    merged = result.merge(
        f_df[["district_id", "year", "bonded_indebtedness"]],
        on=["district_id", "year"],
    )
    np.testing.assert_allclose(
        merged["long_term_debt"].values, merged["bonded_indebtedness"].values, rtol=1e-9
    )


def test_generate_nces_ccd_submission_federal_grant_columns_written_as_is(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    f_df = _build_fiscal(data_dir)
    out = str(tmp_path / "ccd.csv")
    generate_nces_ccd_submission(f_df, out)
    result = pd.read_csv(out)
    for col in ["title1_expenditure", "idea_expenditure", "title3_expenditure"]:
        ref = f_df[["district_id", "year", col]].rename(columns={col: "ref"})
        merged = result.merge(ref, on=["district_id", "year"])
        np.testing.assert_allclose(merged[col].values, merged["ref"].values, rtol=1e-9)


def test_generate_nces_ccd_submission_raises_value_error_for_empty_output_path(data_dir):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    with pytest.raises(ValueError):
        generate_nces_ccd_submission(_build_fiscal(data_dir), "")


# ===========================================================================
# generate_legislative_report
# ===========================================================================

def test_generate_legislative_report_one_row_per_year(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    assert not result.duplicated(subset=["year"]).any()
    assert len(result) == fiscal["year"].nunique()


def test_generate_legislative_report_has_exactly_16_columns(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    assert len(pd.read_csv(out).columns) == 16


def test_generate_legislative_report_num_districts_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["district_id"].nunique()
        .reset_index().rename(columns={"district_id": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_array_equal(merged["num_districts"].values, merged["exp"].values)


def test_generate_legislative_report_mean_pprev_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["total_pprev"].mean()
        .reset_index().rename(columns={"total_pprev": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["mean_pprev"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_median_pprev_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["total_pprev"].median()
        .reset_index().rename(columns={"total_pprev": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["median_pprev"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_cv_pprev_formula_with_ddof1(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["total_pprev"]
        .agg(lambda x: x.std(ddof=1) / x.mean())
        .reset_index().rename(columns={"total_pprev": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["cv_pprev"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_cv_need_weighted_pprev_equals_equity_cv(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    equity_cv = fiscal.groupby("year")["equity_cv"].first().reset_index()
    merged = result.merge(equity_cv, on="year")
    np.testing.assert_allclose(
        merged["cv_need_weighted_pprev"].values, merged["equity_cv"].values, rtol=1e-9
    )


def test_generate_legislative_report_mean_need_weighted_pprev_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["need_weighted_pprev"].mean()
        .reset_index().rename(columns={"need_weighted_pprev": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["mean_need_weighted_pprev"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_median_need_weighted_pprev_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["need_weighted_pprev"].median()
        .reset_index().rename(columns={"need_weighted_pprev": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["median_need_weighted_pprev"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_mean_adequacy_gap_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["adequacy_gap"].mean()
        .reset_index().rename(columns={"adequacy_gap": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["mean_adequacy_gap"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_pct_districts_below_adequacy_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["adequacy_gap"]
        .agg(lambda x: (x < 0).sum() / len(x))
        .reset_index().rename(columns={"adequacy_gap": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["pct_districts_below_adequacy"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_cv_fiscal_capacity_index_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["fiscal_capacity_index"]
        .agg(lambda x: x.std(ddof=1) / x.mean())
        .reset_index().rename(columns={"fiscal_capacity_index": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["cv_fiscal_capacity_index"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_cv_fiscal_effort_index_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["fiscal_effort_index"]
        .agg(lambda x: x.std(ddof=1) / x.mean())
        .reset_index().rename(columns={"fiscal_effort_index": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["cv_fiscal_effort_index"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_sd_effort_residual_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["effort_residual"]
        .agg(lambda x: x.std(ddof=1))
        .reset_index().rename(columns={"effort_residual": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["sd_effort_residual"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_mean_debt_burden_ppupil_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    expected = (
        fiscal.groupby("year")["debt_burden_ppupil"].mean()
        .reset_index().rename(columns={"debt_burden_ppupil": "exp"})
    )
    merged = result.merge(expected, on="year")
    np.testing.assert_allclose(merged["mean_debt_burden_ppupil"].values, merged["exp"].values, rtol=1e-9)


def test_generate_legislative_report_raises_value_error_for_empty_output_path(data_dir):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    with pytest.raises(ValueError):
        generate_legislative_report(fiscal, pattern, "")


# ===========================================================================
# Additional tests for requirements identified in the coverage audit
# ===========================================================================

def test_load_district_data_pivot_values_correct_for_each_function_object_combination(tmp_path):
    if load_district_data is None:
        pytest.fail("load_district_data not importable from pipeline")

    pd.DataFrame([{"district_id": "X", "year": 2020,
                   "state_foundation_pprev": 5000.0, "local_tax_pprev": 2000.0,
                   "enrollment": 500}]
    ).to_csv(tmp_path / "district_finance.csv", index=False)

    # Each (function_code, object_code) pair gets a deliberately distinct value
    pd.DataFrame([
        {"district_id": "X", "year": 2020, "function_code": "1000", "object_code": "100", "ppupil_expenditure": 100.0},
        {"district_id": "X", "year": 2020, "function_code": "1000", "object_code": "200", "ppupil_expenditure": 200.0},
        {"district_id": "X", "year": 2020, "function_code": "1000", "object_code": "300", "ppupil_expenditure": 300.0},
        {"district_id": "X", "year": 2020, "function_code": "2000", "object_code": "100", "ppupil_expenditure": 400.0},
        {"district_id": "X", "year": 2020, "function_code": "2000", "object_code": "200", "ppupil_expenditure": 500.0},
        {"district_id": "X", "year": 2020, "function_code": "2000", "object_code": "300", "ppupil_expenditure": 600.0},
    ]).to_csv(tmp_path / "district_expenditure.csv", index=False)

    pd.DataFrame([{"district_id": "X", "year": 2020,
                   "pct_poverty": 0.1, "pct_ell": 0.05, "pct_disability": 0.08}]
    ).to_csv(tmp_path / "demographics.csv", index=False)
    pd.DataFrame([{"district_id": "X", "year": 2020,
                   "title1_expenditure": 1000.0, "idea_expenditure": 500.0, "title3_expenditure": 200.0}]
    ).to_csv(tmp_path / "federal_grants.csv", index=False)
    pd.DataFrame([{"district_id": "X", "year": 2020,
                   "capital_expenditure": 10000.0, "bonded_indebtedness": 50000.0}]
    ).to_csv(tmp_path / "capital_debt.csv", index=False)
    pd.DataFrame([{"district_id": "X", "year": 2020,
                   "assessed_value_per_pupil": 200000.0, "mill_rate": 20.0}]
    ).to_csv(tmp_path / "property_wealth.csv", index=False)

    df = load_district_data(str(tmp_path))
    row = df.iloc[0]

    assert math.isclose(row["instruction_salaries_ppupil"],           100.0)
    assert math.isclose(row["instruction_benefits_ppupil"],            200.0)
    assert math.isclose(row["instruction_purchased_services_ppupil"],  300.0)
    assert math.isclose(row["support_salaries_ppupil"],               400.0)
    assert math.isclose(row["support_benefits_ppupil"],               500.0)
    assert math.isclose(row["support_purchased_services_ppupil"],      600.0)


def test_load_school_data_has_exactly_eight_columns(data_dir):
    df = _load_school(data_dir)
    assert len(df.columns) == 8, (
        f"Expected exactly 8 columns, got {len(df.columns)}: {list(df.columns)}"
    )


def test_generate_legislative_report_mean_school_resource_outcome_correlation_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal = _build_fiscal(data_dir)
    pattern = _patterns(_load_school(data_dir))
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)

    # One value per (district_id, school_id) pair; pandas .mean() skips NaN
    unique_pairs = pattern.drop_duplicates(subset=["district_id", "school_id"])
    expected = unique_pairs["resource_outcome_correlation"].mean()

    # Verify EVERY year row carries the expected constant value (not just row 0)
    col = result["mean_school_resource_outcome_correlation"]
    if pd.isna(expected):
        assert col.isna().all()
    else:
        assert col.apply(lambda v: math.isclose(v, expected, rel_tol=1e-9)).all()


def test_generate_legislative_report_pct_schools_positive_outcome_trajectory_formula(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal = _build_fiscal(data_dir)
    pattern = _patterns(_load_school(data_dir))
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)

    unique_pairs = pattern.drop_duplicates(subset=["district_id", "school_id"])
    n_total = len(unique_pairs)
    n_positive = (unique_pairs["outcome_trajectory"] > 0).sum()
    expected = n_positive / n_total if n_total > 0 else 0.0

    # Verify EVERY year row carries the expected constant value (not just row 0)
    col = result["pct_schools_positive_outcome_trajectory"]
    assert col.apply(lambda v: math.isclose(v, expected, rel_tol=1e-9)).all()


def test_bundled_data_covers_10_districts_3_schools_7_years():
    if load_district_data is None or load_school_data is None:
        pytest.fail("load_district_data or load_school_data not importable from pipeline")
    import pipeline as _pm
    data_path = os.path.join(os.path.dirname(os.path.abspath(_pm.__file__)), "data")
    try:
        d_df = load_district_data(data_path)
        s_df = load_school_data(data_path)
    except FileNotFoundError as exc:
        pytest.fail(f"Bundled data/ directory or a required CSV file is missing: {exc}")

    assert d_df["district_id"].nunique() == 10, (
        f"Expected 10 districts in bundled data, got {d_df['district_id'].nunique()}"
    )
    assert d_df["year"].nunique() == 7, (
        f"Expected 7 years in bundled data, got {d_df['year'].nunique()}"
    )
    # Verify the complete cartesian product: every district has every year
    # (nunique alone allows a district to be missing some years)
    assert len(d_df) == 70, (
        f"Expected 70 rows (10 districts × 7 years) in bundled district data, got {len(d_df)}"
    )
    assert not d_df.duplicated(subset=["district_id", "year"]).any(), (
        "Bundled district data has duplicate (district_id, year) rows"
    )
    # Verify school-level cartesian product: every district × school × year
    schools_per_district = s_df.groupby("district_id")["school_id"].nunique()
    assert (schools_per_district == 3).all(), (
        "Expected exactly 3 schools per district in bundled data; "
        f"got: {schools_per_district.to_dict()}"
    )
    assert len(s_df) == 210, (
        f"Expected 210 rows (10 districts × 3 schools × 7 years) in bundled school data, got {len(s_df)}"
    )
    assert not s_df.duplicated(subset=["district_id", "school_id", "year"]).any(), (
        "Bundled school data has duplicate (district_id, school_id, year) rows"
    )

def test_decompose_fiscal_effects_fiscal_capacity_index_formula(data_dir):
    f_df = _build_fiscal(data_dir)
    expected = (
        f_df["assessed_value_per_pupil"]
        / f_df.groupby("year")["assessed_value_per_pupil"].transform("mean")
    )
    np.testing.assert_allclose(f_df["fiscal_capacity_index"].values, expected.values, rtol=1e-9)


def test_decompose_fiscal_effects_fiscal_effort_index_formula(data_dir):
    f_df = _build_fiscal(data_dir)
    expected = (
        f_df["mill_rate"]
        / f_df.groupby("year")["mill_rate"].transform("mean")
    )
    np.testing.assert_allclose(f_df["fiscal_effort_index"].values, expected.values, rtol=1e-9)


def test_decompose_fiscal_effects_capacity_predicted_rev_formula(data_dir):
    f_df = _build_fiscal(data_dir).reset_index(drop=True)
    expected = pd.Series(np.nan, index=f_df.index)
    for year, grp in f_df.groupby("year"):
        slope, intercept = np.polyfit(
            grp["fiscal_capacity_index"].values,
            grp["total_pprev"].values,
            1,
        )
        expected.loc[grp.index] = slope * grp["fiscal_capacity_index"].values + intercept
    np.testing.assert_allclose(f_df["capacity_predicted_rev"].values, expected.values, rtol=1e-9)


def test_identify_resource_outcome_patterns_need_adjusted_outcome_score_formula(data_dir):
    s_df = _load_school(data_dir)
    p_df = _patterns(s_df)
    for (d, s), grp in p_df.groupby(["district_id", "school_id"]):
        if grp["need_adjusted_outcome_score"].isna().any():
            continue  # skip groups where NaN is expected (< 5 pts or rank-deficient)
        X = np.column_stack([
            np.ones(len(grp)),
            grp["pct_poverty"].values,
            grp["pct_ell"].values,
            grp["pct_disability"].values,
        ])
        y = grp["outcome_score"].values
        coeffs, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
        expected_residuals = y - X @ coeffs
        np.testing.assert_allclose(
            grp["need_adjusted_outcome_score"].values,
            expected_residuals,
            rtol=1e-9,
            err_msg=f"need_adjusted_outcome_score mismatch for ({d}, {s})",
        )

def test_identify_resource_outcome_patterns_nan_for_rank_deficient_design_matrix():
    if identify_resource_outcome_patterns is None:
        pytest.fail("identify_resource_outcome_patterns not importable from pipeline")
    rows = []
    # S001: 6 rows with identical demographics -> design matrix rank-deficient
    for y in YEARS[:6]:
        rows.append({
            "district_id": "D001", "school_id": "S001", "year": y,
            "ppupil_expenditure": 8000.0 + (y - 2015) * 50,
            "outcome_score": 70.0 + (y - 2015) * 2.0,
            "pct_poverty": 0.10, "pct_ell": 0.05, "pct_disability": 0.08,
        })
    # S002: 7 rows with varying, non-collinear demographics -> valid residuals
    for j, y in enumerate(YEARS):
        rows.append({
            "district_id": "D001", "school_id": "S002", "year": y,
            "ppupil_expenditure": 8000.0 + j * 50,
            "outcome_score": 70.0 + j * 2.0,
            "pct_poverty": 0.10 + j * 0.005,
            "pct_ell": 0.05 + j * 0.003 + j * j * 0.001,
            "pct_disability": 0.08 + j * 0.002 + j * j * 0.0005 + (j ** 3) * 0.0001,
        })
    result = identify_resource_outcome_patterns(pd.DataFrame(rows))
    s1 = (result["district_id"] == "D001") & (result["school_id"] == "S001")
    s2 = (result["district_id"] == "D001") & (result["school_id"] == "S002")
    assert result.loc[s1, "need_adjusted_outcome_score"].isna().all(), \
        "Expected NaN for rank-deficient design matrix (S001)"
    assert not result.loc[s2, "need_adjusted_outcome_score"].isna().all(), \
        "S002 with valid demographics should produce non-NaN values"

def test_compute_equity_metrics_new_columns_are_float_dtype(data_dir):
    e_df = _equity(_load_district(data_dir))
    for col in ["total_pprev", "state_local_revenue", "need_adjusted_enrollment",
                "need_weighted_pprev", "equity_cv", "adequacy_gap"]:
        assert pd.api.types.is_float_dtype(e_df[col]), f"Column '{col}' is not float dtype"


def test_decompose_fiscal_effects_new_columns_are_float_dtype(data_dir):
    f_df = _build_fiscal(data_dir)
    for col in ["fiscal_capacity_index", "fiscal_effort_index",
                "capacity_predicted_rev", "effort_residual", "debt_burden_ppupil"]:
        assert pd.api.types.is_float_dtype(f_df[col]), f"Column '{col}' is not float dtype"


def test_identify_resource_outcome_patterns_new_columns_are_float_dtype(data_dir):
    p_df = _patterns(_load_school(data_dir))
    for col in ["need_adjusted_outcome_score", "resource_outcome_correlation", "outcome_trajectory"]:
        assert pd.api.types.is_float_dtype(p_df[col]), f"Column '{col}' is not float dtype"


@pytest.mark.parametrize("missing_key", ["poverty_weight", "ell_weight", "disability_weight"])
def test_compute_equity_metrics_raises_key_error_for_each_individual_missing_weight(data_dir, missing_key):
    if compute_equity_metrics is None:
        pytest.fail("compute_equity_metrics not importable from pipeline")
    d_df = _load_district(data_dir)
    incomplete = {k: v for k, v in NEED_WEIGHTS.items() if k != missing_key}
    with pytest.raises(KeyError):
        compute_equity_metrics(d_df, incomplete)


@pytest.mark.parametrize("missing_file", [
    "district_finance.csv",
    "district_expenditure.csv",
    "demographics.csv",
    "federal_grants.csv",
    "capital_debt.csv",
    "property_wealth.csv",
])
def test_load_district_data_raises_file_not_found_for_each_individual_missing_file(
    tmp_path, missing_file
):
    if load_district_data is None:
        pytest.fail("load_district_data not importable from pipeline")
    _write_district_finance(tmp_path)
    _write_district_expenditure(tmp_path)
    _write_demographics(tmp_path)
    _write_federal_grants(tmp_path)
    _write_capital_debt(tmp_path)
    _write_property_wealth(tmp_path)
    (tmp_path / missing_file).unlink()
    with pytest.raises(FileNotFoundError):
        load_district_data(str(tmp_path))


@pytest.mark.parametrize("missing_file", ["school_resources.csv", "school_demographics.csv"])
def test_load_school_data_raises_file_not_found_for_each_individual_missing_file(
    tmp_path, missing_file
):
    if load_school_data is None:
        pytest.fail("load_school_data not importable from pipeline")
    _write_school_resources(tmp_path)
    _write_school_demographics(tmp_path)
    (tmp_path / missing_file).unlink()
    with pytest.raises(FileNotFoundError):
        load_school_data(str(tmp_path))


def test_bundled_district_expenditure_function_codes_are_exactly_1000_and_2000():
    if load_district_data is None:
        pytest.fail("pipeline not importable from pipeline")
    import pipeline as _pm
    data_path = os.path.join(os.path.dirname(os.path.abspath(_pm.__file__)), "data")
    csv_path = os.path.join(data_path, "district_expenditure.csv")
    try:
        df = pd.read_csv(csv_path, dtype={"function_code": str, "object_code": str})
    except FileNotFoundError:
        pytest.fail(f"Bundled district_expenditure.csv not found at {csv_path}")
    assert set(df["function_code"].unique()) == {"1000", "2000"}, (
        f"Expected function_code == {{'1000','2000'}}, got {set(df['function_code'].unique())}"
    )


def test_bundled_district_expenditure_object_codes_are_exactly_100_200_300():
    if load_district_data is None:
        pytest.fail("pipeline not importable from pipeline")
    import pipeline as _pm
    data_path = os.path.join(os.path.dirname(os.path.abspath(_pm.__file__)), "data")
    csv_path = os.path.join(data_path, "district_expenditure.csv")
    try:
        df = pd.read_csv(csv_path, dtype={"function_code": str, "object_code": str})
    except FileNotFoundError:
        pytest.fail(f"Bundled district_expenditure.csv not found at {csv_path}")
    assert set(df["object_code"].unique()) == {"100", "200", "300"}, (
        f"Expected object_code == {{'100','200','300'}}, got {set(df['object_code'].unique())}"
    )


def test_generate_legislative_report_year_column_is_integer_dtype(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    generate_legislative_report(fiscal, pattern, out)
    result = pd.read_csv(out)
    assert pd.api.types.is_integer_dtype(result["year"]), (
        f"Expected year column to be integer dtype, got {result['year'].dtype}"
    )


def test_identify_resource_outcome_patterns_valid_at_exactly_5_data_points():
    if identify_resource_outcome_patterns is None:
        pytest.fail("identify_resource_outcome_patterns not importable from pipeline")
    rows = []
    for j, y in enumerate(YEARS[:5]):   # exactly 5 rows
        rows.append({
            "district_id": "D001", "school_id": "S001", "year": y,
            "ppupil_expenditure": 8000.0 + j * 50,
            "outcome_score": 70.0 + j * 2.0,
            "pct_poverty": 0.10 + j * 0.005,   # linear; see pct_ell/pct_disability for higher-degree terms
            "pct_ell": 0.05 + j * 0.003 + j * j * 0.001,
            "pct_disability": 0.08 + j * 0.002 + j * j * 0.0005 + (j ** 3) * 0.0001,
        })
    result = identify_resource_outcome_patterns(pd.DataFrame(rows))
    assert not result["need_adjusted_outcome_score"].isna().all(), (
        "Expected non-NaN need_adjusted_outcome_score for exactly 5 data points"
    )


def test_generate_nces_ccd_submission_returns_none(data_dir, tmp_path):
    if generate_nces_ccd_submission is None:
        pytest.fail("generate_nces_ccd_submission not importable from pipeline")
    out = str(tmp_path / "ccd.csv")
    return_value = generate_nces_ccd_submission(_build_fiscal(data_dir), out)
    assert return_value is None


def test_generate_legislative_report_returns_none(data_dir, tmp_path):
    if generate_legislative_report is None:
        pytest.fail("generate_legislative_report not importable from pipeline")
    fiscal, pattern = _build_fiscal_and_pattern(data_dir)
    out = str(tmp_path / "report.csv")
    return_value = generate_legislative_report(fiscal, pattern, out)
    assert return_value is None


def test_identify_resource_outcome_patterns_nan_at_exactly_4_data_points():
    if identify_resource_outcome_patterns is None:
        pytest.fail("identify_resource_outcome_patterns not importable from pipeline")
    rows = []
    for j, y in enumerate(YEARS[:4]):   # exactly 4 rows - below the 5-point threshold
        rows.append({
            "district_id": "D001", "school_id": "S001", "year": y,
            "ppupil_expenditure": 8000.0 + j * 50,
            "outcome_score": 70.0 + j * 2.0,
            "pct_poverty": 0.10 + j * 0.005,
            "pct_ell": 0.05 + j * 0.003 + j * j * 0.001,
            "pct_disability": 0.08 + j * 0.002 + j * j * 0.0005 + (j ** 3) * 0.0001,
        })
    result = identify_resource_outcome_patterns(pd.DataFrame(rows))
    assert result["need_adjusted_outcome_score"].isna().all(), (
        "Expected NaN for all rows when group has exactly 4 data points"
    )


def test_bundled_data_column_dtypes_through_loaders():
    if load_district_data is None or load_school_data is None:
        pytest.fail("load_district_data or load_school_data not importable from pipeline")
    import pipeline as _pm
    data_path = os.path.join(os.path.dirname(os.path.abspath(_pm.__file__)), "data")
    try:
        d_df = load_district_data(data_path)
        s_df = load_school_data(data_path)
    except FileNotFoundError as exc:
        pytest.fail(f"Bundled data missing: {exc}")

    # district_id / school_id must be string-typed.
    # is_string_dtype accepts both classic object dtype and pandas StringDtype.
    assert pd.api.types.is_string_dtype(d_df["district_id"]), (
        f"district_id in district data should be string dtype, got {d_df['district_id'].dtype}"
    )
    assert pd.api.types.is_string_dtype(s_df["district_id"]), (
        f"district_id in school data should be string dtype, got {s_df['district_id'].dtype}"
    )
    assert pd.api.types.is_string_dtype(s_df["school_id"]), (
        f"school_id should be string dtype, got {s_df['school_id'].dtype}"
    )
    # year must be integer in both district and school data
    assert pd.api.types.is_integer_dtype(d_df["year"]), (
        f"year in district data should be integer, got {d_df['year'].dtype}"
    )
    assert pd.api.types.is_integer_dtype(s_df["year"]), (
        f"year in school data should be integer, got {s_df['year'].dtype}"
    )
    # enrollment must be integer
    assert pd.api.types.is_integer_dtype(d_df["enrollment"]), (
        f"enrollment should be integer, got {d_df['enrollment'].dtype}"
    )