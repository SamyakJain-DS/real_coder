"""
F2P test suite for the Menu Engineering Analysis Pipeline.

All tests gracefully produce FAILED (not ERROR or SKIPPED) on an empty
repository because:
  - Module-level try/except on pipeline imports assigns None on ImportError.
  - _run_once() captures any pipeline execution failure into _RUN_ERROR.
  - Every pipeline-output test asserts _RUN_ERROR is None first, so a
    missing import or runtime failure surfaces as FAILED, not ERROR.

No stubs, no hardcoded FAILED/ERROR/SKIPPED in parsing.py.
"""

import csv
import io
import os
import subprocess
import sys
import tempfile
from contextlib import redirect_stdout

# ---------------------------------------------------------------------------
# Locate repository root relative to this test file
# ---------------------------------------------------------------------------
_TEST_DIR = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_TEST_DIR, ".."))
sys.path.insert(0, _REPO_ROOT)

# ---------------------------------------------------------------------------
# F2P-safe imports: None on ImportError so tests FAIL, not ERROR
# ---------------------------------------------------------------------------
try:
    from pipeline import load_pos_data, run_pipeline
except ImportError:
    load_pos_data = None
    run_pipeline = None

# ---------------------------------------------------------------------------
# Constants derived directly from prompt requirements
# ---------------------------------------------------------------------------
_DATA_PATH = os.path.join(_REPO_ROOT, "data", "pos_data.csv")

_VALID_QUADRANTS = {"star", "plowhorse", "puzzle", "dog"}

_SUGGESTION_MAP = {
    "star":      "Maintain prominence and protect margins",
    "plowhorse": "Reduce portion cost or reposition to increase margin",
    "puzzle":    "Increase visibility and promotion to boost sales volume",
    "dog":       "Consider removing or repositioning this item",
}

# ---------------------------------------------------------------------------
# Brief parser
# ---------------------------------------------------------------------------

def _parse_brief(output_path):
    """
    Parse menu_brief.txt into a list of section dicts.
    Each dict contains '_lines' (raw list) plus extracted fields when the
    section has exactly five lines with the expected labels.
    """
    with open(output_path, "r") as fh:
        content = fh.read()

    sections = []
    raw_sections = [s.strip() for s in content.strip().split("\n\n") if s.strip()]
    for raw in raw_sections:
        lines = raw.splitlines()
        section = {"_lines": lines}
        if len(lines) == 5:
            def _strip_label(line, label):
                return line[len(label):] if line.startswith(label) else None

            section["item"]               = _strip_label(lines[0], "Item: ")
            section["full_year_quadrant"] = _strip_label(lines[1], "Full-year quadrant: ")
            section["last_13_quadrant"]   = _strip_label(lines[2], "Last-13-weeks quadrant: ")
            section["status"]             = _strip_label(lines[3], "Status: ")
            section["suggestion"]         = _strip_label(lines[4], "Suggestion: ")
        sections.append(section)
    return sections


# ---------------------------------------------------------------------------
# Module-level pipeline execution - runs once when the test module loads
# ---------------------------------------------------------------------------
_RUN_ERROR        = None
_OUTPUT_PATH      = None
_STDOUT_CAPTURED  = None
_SECTIONS         = None
_TMP_DIR          = tempfile.mkdtemp()


def _run_once():
    global _RUN_ERROR, _OUTPUT_PATH, _STDOUT_CAPTURED, _SECTIONS

    if run_pipeline is None:
        _RUN_ERROR = "run_pipeline could not be imported from pipeline.py"
        return

    if not os.path.exists(_DATA_PATH):
        _RUN_ERROR = f"Bundled dataset not found at {_DATA_PATH}"
        return

    output_path = os.path.join(_TMP_DIR, "output", "menu_brief.txt")

    try:
        captured = io.StringIO()
        with redirect_stdout(captured):
            run_pipeline(_DATA_PATH, output_path)
        _OUTPUT_PATH     = output_path
        _STDOUT_CAPTURED = captured.getvalue()

        if os.path.exists(output_path):
            _SECTIONS = _parse_brief(output_path)
        else:
            _RUN_ERROR = "run_pipeline completed but did not create the output file"
    except Exception as exc:  # noqa: BLE001
        _RUN_ERROR = f"{type(exc).__name__}: {exc}"


_run_once()


# ---------------------------------------------------------------------------
# Helper for load_pos_data unit tests
# ---------------------------------------------------------------------------

def _write_minimal_csv(path):
    """Write a two-row CSV with the required schema."""
    with open(path, "w", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["date", "item", "quantity", "sell_price", "food_cost"])
        writer.writerow(["2023-01-15", "Burger",  10, 12.00, 4.50])
        writer.writerow(["2023-06-20", "Pizza",    8, 15.00, 5.00])


# ===========================================================================
# Tests: load_pos_data
# ===========================================================================

class TestLoadPosData:

    def test_returns_dataframe(self, tmp_path):
        assert load_pos_data is not None, \
            "load_pos_data could not be imported from pipeline.py"
        import pandas as pd
        csv_path = str(tmp_path / "pos.csv")
        _write_minimal_csv(csv_path)
        result = load_pos_data(csv_path)
        assert isinstance(result, pd.DataFrame), \
            f"Expected pd.DataFrame, got {type(result)}"

    def test_date_column_is_datetime_dtype(self, tmp_path):
        assert load_pos_data is not None, \
            "load_pos_data could not be imported from pipeline.py"
        import pandas as pd
        csv_path = str(tmp_path / "pos.csv")
        _write_minimal_csv(csv_path)
        df = load_pos_data(csv_path)
        assert pd.api.types.is_datetime64_any_dtype(df["date"]), \
            "date column is not a pandas datetime dtype"

    def test_raises_file_not_found_for_missing_file(self, tmp_path):
        assert load_pos_data is not None, \
            "load_pos_data could not be imported from pipeline.py"
        import pytest
        missing = str(tmp_path / "does_not_exist.csv")
        with pytest.raises(FileNotFoundError):
            load_pos_data(missing)
    
    def test_quantity_column_contains_whole_number_values(self, tmp_path):
        assert load_pos_data is not None, \
            "load_pos_data could not be imported from pipeline.py"
        csv_path = str(tmp_path / "pos.csv")
        _write_minimal_csv(csv_path)
        df = load_pos_data(csv_path)
        assert df["quantity"].apply(lambda x: float(x) == int(float(x))).all(), \
            "quantity column contains non-whole-number values"

    def test_sell_price_column_is_numeric(self, tmp_path):
        assert load_pos_data is not None, \
            "load_pos_data could not be imported from pipeline.py"
        import pandas as pd
        csv_path = str(tmp_path / "pos.csv")
        _write_minimal_csv(csv_path)
        df = load_pos_data(csv_path)
        assert pd.api.types.is_numeric_dtype(df["sell_price"]), \
            "sell_price column is not a numeric dtype"

    def test_food_cost_column_is_numeric(self, tmp_path):
        assert load_pos_data is not None, \
            "load_pos_data could not be imported from pipeline.py"
        import pandas as pd
        csv_path = str(tmp_path / "pos.csv")
        _write_minimal_csv(csv_path)
        df = load_pos_data(csv_path)
        assert pd.api.types.is_numeric_dtype(df["food_cost"]), \
            "food_cost column is not a numeric dtype"

    def test_csv_contains_exactly_five_columns(self, tmp_path):
        assert load_pos_data is not None, \
            "load_pos_data could not be imported from pipeline.py"
        csv_path = str(tmp_path / "pos.csv")
        _write_minimal_csv(csv_path)
        df = load_pos_data(csv_path)
        assert set(df.columns) == {"date", "item", "quantity", "sell_price", "food_cost"}, (
            f"DataFrame columns should be exactly "
            f"{{'date', 'item', 'quantity', 'sell_price', 'food_cost'}}, "
            f"got: {set(df.columns)}"
        )
    
    def test_item_column_is_string_compatible_dtype(self, tmp_path):
        assert load_pos_data is not None, \
            "load_pos_data could not be imported from pipeline.py"
        import pandas as pd
        csv_path = str(tmp_path / "pos.csv")
        _write_minimal_csv(csv_path)
        df = load_pos_data(csv_path)
        assert pd.api.types.is_string_dtype(df["item"]), \
            "item column is not a string-compatible dtype"

# ===========================================================================
# Tests: run_pipeline - stdout confirmation message
# ===========================================================================

class TestStdoutMessage:

    def test_stdout_contains_brief_written_message(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        expected = f"Brief written to {_OUTPUT_PATH}"
        assert expected in _STDOUT_CAPTURED, (
            f"Expected stdout to contain '{expected}'\n"
            f"Actual stdout: {_STDOUT_CAPTURED!r}"
        )


# ===========================================================================
# Tests: brief section format
# ===========================================================================

class TestBriefSectionFormat:

    def test_each_section_has_exactly_five_lines(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            assert len(section["_lines"]) == 5, (
                f"Section {i} has {len(section['_lines'])} lines, expected 5.\n"
                f"Content: {section['_lines']}"
            )

    def test_first_line_has_item_label(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            assert section["_lines"][0].startswith("Item: "), (
                f"Section {i} line 1 should start with 'Item: ', "
                f"got: {section['_lines'][0]!r}"
            )

    def test_second_line_has_full_year_quadrant_label(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            assert section["_lines"][1].startswith("Full-year quadrant: "), (
                f"Section {i} line 2 should start with 'Full-year quadrant: ', "
                f"got: {section['_lines'][1]!r}"
            )

    def test_third_line_has_last_13_weeks_quadrant_label(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            assert section["_lines"][2].startswith("Last-13-weeks quadrant: "), (
                f"Section {i} line 3 should start with 'Last-13-weeks quadrant: ', "
                f"got: {section['_lines'][2]!r}"
            )

    def test_fourth_line_has_status_label(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            assert section["_lines"][3].startswith("Status: "), (
                f"Section {i} line 4 should start with 'Status: ', "
                f"got: {section['_lines'][3]!r}"
            )

    def test_fifth_line_has_suggestion_label(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            assert section["_lines"][4].startswith("Suggestion: "), (
                f"Section {i} line 5 should start with 'Suggestion: ', "
                f"got: {section['_lines'][4]!r}"
            )

    def test_consecutive_sections_separated_by_blank_line(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        with open(_OUTPUT_PATH) as fh:
            raw_lines = fh.read().splitlines()
        item_line_indices = [
            i for i, ln in enumerate(raw_lines) if ln.startswith("Item: ")
        ]
        for idx in item_line_indices[1:]:
            assert raw_lines[idx - 1] == "", (
                f"Expected a blank line before section at line {idx}, "
                f"got: {raw_lines[idx - 1]!r}"
            )
            assert raw_lines[idx - 2] != "", (
                f"Expected exactly one blank line before section at line {idx}, "
                f"but found two or more consecutive blank lines"
            )


# ===========================================================================
# Tests: quadrant and status values
# ===========================================================================

class TestQuadrantAndStatusValues:

    def test_full_year_quadrant_is_valid(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            q = section.get("full_year_quadrant")
            assert q in _VALID_QUADRANTS, \
                f"Section {i}: invalid full-year quadrant {q!r}"

    def test_last_13_weeks_quadrant_is_valid(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            q = section.get("last_13_quadrant")
            assert q in _VALID_QUADRANTS, \
                f"Section {i}: invalid last-13-weeks quadrant {q!r}"

    def test_status_value_is_shifted_or_stable(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            assert section.get("status") in {"shifted", "stable"}, \
                f"Section {i}: invalid status {section.get('status')!r}"

    def test_all_four_quadrants_appear_in_full_year_classification(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        found = {
            s["full_year_quadrant"]
            for s in _SECTIONS
            if s.get("full_year_quadrant")
        }
        assert found == _VALID_QUADRANTS, (
            f"Not all four quadrants present in full-year classification.\n"
            f"Found: {found}\nMissing: {_VALID_QUADRANTS - found}"
        )


# ===========================================================================
# Tests: one section per distinct menu item
# ===========================================================================

class TestSectionCount:

    def test_one_section_per_distinct_item_in_dataset(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        assert os.path.exists(_DATA_PATH), \
            f"Bundled dataset not found at {_DATA_PATH}"
        with open(_DATA_PATH, newline="") as fh:
            reader = csv.DictReader(fh)
            distinct_items = {row["item"] for row in reader}
        assert len(_SECTIONS) == len(distinct_items), (
            f"Expected one section per distinct item ({len(distinct_items)} items), "
            f"found {len(_SECTIONS)} sections"
        )


# ===========================================================================
# Tests: suggestion text correctness
# ===========================================================================

class TestSuggestionText:

    def test_suggestion_base_text_matches_full_year_quadrant(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            if section.get("status") == "stable":
                q          = section.get("full_year_quadrant")
                suggestion = section.get("suggestion", "")
                expected   = _SUGGESTION_MAP.get(q, "")
                assert suggestion == expected, (
                    f"Section {i} (quadrant='{q}', stable): suggestion should be "
                    f"exactly '{expected}', got: {suggestion!r}"
                )

    def test_shifted_item_suggestion_has_recent_quadrant_append(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            if section.get("status") == "shifted":
                fy_q       = section.get("full_year_quadrant")
                recent_q   = section.get("last_13_quadrant")
                suggestion = section.get("suggestion", "")
                base       = _SUGGESTION_MAP.get(fy_q, "")
                expected   = f"{base} (recently shifted to {recent_q})"
                assert suggestion == expected, (
                    f"Section {i}: shifted item suggestion should be exactly "
                    f"'{expected}', got: {suggestion!r}"
                )

# ===========================================================================
# Tests: shift detection correctness
# ===========================================================================

class TestShiftDetection:

    def test_at_least_two_items_are_shifted(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        shifted_count = sum(
            1 for s in _SECTIONS if s.get("status") == "shifted"
        )
        assert shifted_count >= 2, \
            f"Expected at least 2 shifted items, found {shifted_count}"

    def test_status_is_consistent_with_quadrant_comparison(self):
        assert _RUN_ERROR is None, f"Pipeline execution failed: {_RUN_ERROR}"
        for i, section in enumerate(_SECTIONS):
            fy_q   = section.get("full_year_quadrant")
            r_q    = section.get("last_13_quadrant")
            status = section.get("status")
            if fy_q != r_q:
                assert status == "shifted", (
                    f"Section {i}: quadrants differ ({fy_q} vs {r_q}) "
                    f"so status should be 'shifted', got '{status}'"
                )
            else:
                assert status == "stable", (
                    f"Section {i}: quadrants match ({fy_q}) "
                    f"so status should be 'stable', got '{status}'"
                )


# ===========================================================================
# Tests: CLI entry point
# ===========================================================================

class TestCLIEntryPoint:
    """
    Run `python pipeline.py` once via subprocess; reuse the result across
    both tests using a class-level cache so the script executes only once.
    """
    _result   = None
    _executed = False

    @classmethod
    def _ensure_cli_executed(cls):
        if not cls._executed:
            # Remove any stale output file so the existence check
            # reflects this run only, not a previous session.
            default_output = os.path.join(_REPO_ROOT, "output", "menu_brief.txt")
            if os.path.exists(default_output):
                os.remove(default_output)
            pipeline_script = os.path.join(_REPO_ROOT, "pipeline.py")
            cls._result = subprocess.run(
                [sys.executable, pipeline_script],
                capture_output=True,
                text=True,
                cwd=_REPO_ROOT,
            )
            cls._executed = True

    def test_cli_creates_output_at_default_path(self):
        self._ensure_cli_executed()
        default_output = os.path.join(_REPO_ROOT, "output", "menu_brief.txt")
        assert os.path.exists(default_output), (
            "Running `python pipeline.py` did not create output/menu_brief.txt "
            "at the default path"
        )

    def test_cli_stdout_contains_brief_written_message(self):
        self._ensure_cli_executed()
        assert "Brief written to output/menu_brief.txt" in self._result.stdout, (
            f"CLI stdout should contain 'Brief written to output/menu_brief.txt', "
            f"got: {self._result.stdout!r}"
        )

class TestBundledDataset:

    def test_date_values_are_yyyy_mm_dd_format(self):
        import re
        assert os.path.exists(_DATA_PATH), \
            f"Bundled dataset not found at {_DATA_PATH}"
        pattern = re.compile(r"^\d{4}-\d{2}-\d{2}$")
        with open(_DATA_PATH, newline="") as fh:
            reader = csv.DictReader(fh)
            for i, row in enumerate(reader):
                assert pattern.match(row["date"]), (
                    f"Row {i}: date value {row['date']!r} "
                    f"does not match YYYY-MM-DD format"
                )


class TestRunPipelineReturnValue:

    def test_run_pipeline_returns_none(self, tmp_path):
        assert run_pipeline is not None, \
            "run_pipeline could not be imported from pipeline.py"
        assert os.path.exists(_DATA_PATH), \
            f"Bundled dataset not found at {_DATA_PATH}"
        import io
        from contextlib import redirect_stdout
        output_path = str(tmp_path / "output" / "menu_brief.txt")
        with redirect_stdout(io.StringIO()):
            result = run_pipeline(_DATA_PATH, output_path)
        assert result is None, \
            f"run_pipeline should return None, got {result!r}"