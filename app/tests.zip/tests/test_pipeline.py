import os
import re
import subprocess
import sys
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Graceful imports - every test FAILS cleanly when modules are absent
# ---------------------------------------------------------------------------
try:
    import pandas as pd
    _PANDAS = True
except ImportError:
    pd = None  # type: ignore
    _PANDAS = False

try:
    from pipeline.data_loader import load_data
except (ImportError, ModuleNotFoundError):
    load_data = None  # type: ignore

try:
    from pipeline.activity_estimator import estimate_activity_rates
except (ImportError, ModuleNotFoundError):
    estimate_activity_rates = None  # type: ignore

try:
    from pipeline.migration_analyzer import identify_migration_timing
except (ImportError, ModuleNotFoundError):
    identify_migration_timing = None  # type: ignore

try:
    from pipeline.wns_modeler import model_wns_impact
except (ImportError, ModuleNotFoundError):
    model_wns_impact = None  # type: ignore

try:
    from pipeline.report_generator import generate_report
except (ImportError, ModuleNotFoundError):
    generate_report = None  # type: ignore


# ---------------------------------------------------------------------------
# Species constants
# ---------------------------------------------------------------------------
MIGRANT_SPECIES = frozenset({
    "Lasiurus borealis",
    "Lasiurus cinereus",
    "Lasionycteris noctivagans",
})
WNS_SPECIES = frozenset({
    "Myotis lucifugus",
    "Myotis septentrionalis",
    "Perimyotis subflavus",
})
TARGET_SPECIES = MIGRANT_SPECIES | WNS_SPECIES

def _find_repo_root() -> Path:
    for p in sys.path:
        candidate = Path(p) / "pipeline" / "run_pipeline.py"
        if candidate.is_file():
            return Path(p)
    return Path(__file__).parent.parent  # local dev fallback

_REPO_ROOT = _find_repo_root()


# ---------------------------------------------------------------------------
# Guard helper
# ---------------------------------------------------------------------------
def _require(*fns):
    """
    Call at the top of each test.  If pandas or any passed function is
    unavailable, the test is marked FAILED (not ERROR or SKIP).
    """
    if not _PANDAS:
        pytest.fail("pandas is not installed")
    for fn in fns:
        if fn is None:
            pytest.fail("A required pipeline function could not be imported")


# ---------------------------------------------------------------------------
# Shared data factories
# ---------------------------------------------------------------------------

def _basic_activity():
    """
    Two sites, two identical dry dates each.

    Site means:  S1=100, S2=50   Global mean=75
    sensitivity: S1=100/75=4/3   S2=50/75=2/3
    """
    return pd.DataFrame({
        "site_id":       ["S1", "S1", "S2", "S2"],
        "date":          ["2020-01-01", "2020-01-02",
                          "2020-01-01", "2020-01-02"],
        "nightly_count": [100, 100, 50, 50],
    })


def _basic_classifications():
    """
    One species (SpA) at both sites on the single dry night 2020-01-01.
    classified_count = 30 at each site.

    corrected_S1 = 30 / (4/3) = 22.5
    corrected_S2 = 30 / (2/3) = 45.0
    expected corrected_mean = (22.5 + 45.0) / 2 = 33.75
    (naïve unweighted mean of raw counts = 30.0 - deliberately different)
    """
    return pd.DataFrame({
        "site_id":          ["S1", "S2"],
        "date":             ["2020-01-01", "2020-01-01"],
        "species":          ["SpA", "SpA"],
        "classified_count": [30, 30],
    })


def _basic_habitat():
    return pd.DataFrame({
        "site_id": ["S1", "S2"],
        "habitat": ["Forest", "Forest"],
        "region":  ["North", "North"],
    })


def _weather_all_dry(dates=("2020-01-01", "2020-01-02")):
    n = len(dates)
    return pd.DataFrame({
        "date":          list(dates),
        "temperature":   [15.0] * n,
        "wind_speed":    [2.0] * n,
        "precipitation": [0.0] * n,
        "lunar_phase":   [0.2] * n,
    })


def _weather_with_rain(rainy_dates, all_dates):
    return pd.DataFrame({
        "date":          list(all_dates),
        "temperature":   [15.0] * len(all_dates),
        "wind_speed":    [2.0] * len(all_dates),
        "precipitation": [5.0 if d in rainy_dates else 0.0 for d in all_dates],
        "lunar_phase":   [0.2] * len(all_dates),
    })


def _weather_with_bright_moon(bright_dates, all_dates):
    return pd.DataFrame({
        "date":          list(all_dates),
        "temperature":   [15.0] * len(all_dates),
        "wind_speed":    [2.0] * len(all_dates),
        "precipitation": [0.0] * len(all_dates),
        "lunar_phase":   [0.8 if d in bright_dates else 0.2 for d in all_dates],
    })

_MIG_DATES  = ["2020-07-01", "2020-07-07", "2020-07-14",
               "2020-07-21", "2020-07-28", "2020-08-04", "2020-08-11"]
_MIG_COUNTS = [1, 2, 10, 20, 10, 2, 1]


def _migration_classifications():
    """All three migrant species share the same count pattern; a non-target
    species with an extreme count is included to verify it is excluded."""
    rows = []
    for date, count in zip(_MIG_DATES, _MIG_COUNTS):
        for sp in MIGRANT_SPECIES:
            rows.append({"site_id": "S1", "date": date,
                         "species": sp, "classified_count": count})
        rows.append({"site_id": "S1", "date": date,
                     "species": "NonTargetSp", "classified_count": 9999})
    return pd.DataFrame(rows)


def _migration_weather(rainy=(), bright=()):
    return pd.DataFrame({
        "date":          _MIG_DATES,
        "temperature":   [20.0] * len(_MIG_DATES),
        "wind_speed":    [2.0]  * len(_MIG_DATES),
        "precipitation": [5.0 if d in rainy else 0.0 for d in _MIG_DATES],
        "lunar_phase":   [0.8 if d in bright else 0.2 for d in _MIG_DATES],
    })

_WNS_MEANS = {
    "Myotis lucifugus":       [100, 90, 70, 60, 40],
    "Myotis septentrionalis": [100, 95, 85, 80, 70],
    "Perimyotis subflavus":   [100, 105, 110, 95, 90],
    "NonTargetSp":            [50, 50, 50, 50, 50],
}
_WNS_YEARS = list(range(2020, 2025))


def _wns_classifications(species_year_means=None):
    if species_year_means is None:
        species_year_means = _WNS_MEANS
    rows = []
    for sp, means in species_year_means.items():
        for year, count in zip(_WNS_YEARS, means):
            rows.append({"site_id": "S1", "date": f"{year}-06-01",
                         "species": sp, "classified_count": int(count)})
    return pd.DataFrame(rows)


def _wns_weather(extra_dates=()):
    dates = [f"{y}-06-01" for y in _WNS_YEARS] + list(extra_dates)
    return pd.DataFrame({
        "date":          dates,
        "temperature":   [20.0] * len(dates),
        "wind_speed":    [2.0]  * len(dates),
        "precipitation": [0.0]  * len(dates),
        "lunar_phase":   [0.2]  * len(dates),
    })


# ---------------------------------------------------------------------------
# Minimal DataFrames for generate_report tests
# ---------------------------------------------------------------------------

def _minimal_activity_rates():
    return pd.DataFrame({
        "species":                    ["SpA", "SpB"],
        "habitat":                    ["Forest", "Grassland"],
        "region":                     ["North", "South"],
        "corrected_mean_nightly_rate":[12.345, 7.891],
    })


def _minimal_migration_timing():
    return pd.DataFrame({
        "species":           list(MIGRANT_SPECIES),
        "peak_week":         [30, 31, 32],
        "season_start_week": [25, 26, 27],
        "season_end_week":   [38, 39, 40],
    })


def _minimal_wns_impact():
    rows = []
    for sp in WNS_SPECIES:
        for yr in _WNS_YEARS:
            rows.append({"species": sp, "year": yr, "mean_nightly_count": 80.0,
                         "pct_change_from_year1": 0.0,
                         "impact_classification": "None"})
    return pd.DataFrame(rows)


# ============================================================================
# TESTS
# ============================================================================

# ---------------------------------------------------------------------------
# load_data
# ---------------------------------------------------------------------------

class TestLoadData:

    def _write_csvs(self, tmp_path):
        (tmp_path / "activity.csv").write_text(
            "site_id,date,nightly_count\nS1,2020-01-01,100\n"
        )
        (tmp_path / "classifications.csv").write_text(
            "site_id,date,species,classified_count\nS1,2020-01-01,SpA,30\n"
        )
        (tmp_path / "habitat.csv").write_text(
            "site_id,habitat,region\nS1,Forest,North\n"
        )
        (tmp_path / "weather.csv").write_text(
            "date,temperature,wind_speed,precipitation,lunar_phase\n"
            "2020-01-01,15.0,2.0,0.0,0.2\n"
        )

    def test_returns_tuple_of_four_dataframes(self, tmp_path):
        _require(load_data)
        self._write_csvs(tmp_path)
        result = load_data(str(tmp_path))
        assert isinstance(result, tuple)
        assert len(result) == 4
        for df in result:
            assert isinstance(df, pd.DataFrame)

    def test_activity_df_has_correct_columns(self, tmp_path):
        _require(load_data)
        self._write_csvs(tmp_path)
        activity_df, _, _, _ = load_data(str(tmp_path))
        assert {"site_id", "date", "nightly_count"}.issubset(activity_df.columns)

    def test_classifications_df_has_correct_columns(self, tmp_path):
        _require(load_data)
        self._write_csvs(tmp_path)
        _, clf_df, _, _ = load_data(str(tmp_path))
        assert {"site_id", "date", "species", "classified_count"}.issubset(clf_df.columns)

    def test_habitat_df_has_correct_columns(self, tmp_path):
        _require(load_data)
        self._write_csvs(tmp_path)
        _, _, hab_df, _ = load_data(str(tmp_path))
        assert {"site_id", "habitat", "region"}.issubset(hab_df.columns)

    def test_weather_df_has_correct_columns(self, tmp_path):
        _require(load_data)
        self._write_csvs(tmp_path)
        _, _, _, wx_df = load_data(str(tmp_path))
        assert {"date", "temperature", "wind_speed",
                "precipitation", "lunar_phase"}.issubset(wx_df.columns)

    def test_all_dataframes_are_nonempty(self, tmp_path):
        _require(load_data)
        self._write_csvs(tmp_path)
        for df in load_data(str(tmp_path)):
            assert len(df) > 0

    def test_activity_df_nightly_count_is_integer_dtype(self, tmp_path):
        """Prompt specifies nightly_count as int."""
        _require(load_data)
        self._write_csvs(tmp_path)
        activity_df, _, _, _ = load_data(str(tmp_path))
        assert pd.api.types.is_integer_dtype(activity_df["nightly_count"]), \
            "nightly_count must be an integer dtype (specified as int in the prompt)"

    def test_classifications_df_classified_count_is_integer_dtype(self, tmp_path):
        """Prompt specifies classified_count as int."""
        _require(load_data)
        self._write_csvs(tmp_path)
        _, clf_df, _, _ = load_data(str(tmp_path))
        assert pd.api.types.is_integer_dtype(clf_df["classified_count"]), \
            "classified_count must be an integer dtype (specified as int in the prompt)"

    def test_weather_df_float_columns_are_float_dtype(self, tmp_path):
        """Prompt specifies temperature, wind_speed, precipitation, lunar_phase as float."""
        _require(load_data)
        self._write_csvs(tmp_path)
        _, _, _, wx_df = load_data(str(tmp_path))
        for col in ("temperature", "wind_speed", "precipitation", "lunar_phase"):
            assert pd.api.types.is_float_dtype(wx_df[col]), \
                f"weather column '{col}' must be float dtype (specified as float in the prompt)"

    def test_date_columns_are_strings_in_yyyy_mm_dd_format(self, tmp_path):
        """
        Prompt specifies date as (str, YYYY-MM-DD) in all three CSV files that
        carry a date column.  An implementation that passes parse_dates=['date']
        to pd.read_csv would store Timestamps instead of strings, violating both
        the type and the format requirement.
        """
        _require(load_data)
        self._write_csvs(tmp_path)
        activity_df, clf_df, _, wx_df = load_data(str(tmp_path))
        yyyy_mm_dd = re.compile(r"^\d{4}-\d{2}-\d{2}$")
        for df_name, df in [
            ("activity_df",        activity_df),
            ("classifications_df", clf_df),
            ("weather_df",         wx_df),
        ]:
            for v in df["date"]:
                assert isinstance(v, str) and bool(yyyy_mm_dd.match(v)), (
                    f"{df_name}.date values must be str in YYYY-MM-DD format; "
                    f"got {type(v).__name__}({v!r})"
                )

    def test_string_columns_are_object_or_string_dtype(self, tmp_path):
        """
        Prompt specifies site_id, species, habitat, and region as (str).
        Uses a numeric-looking site_id ('001') to make the assertion non-trivial:
        pandas might infer '001' as int64 if dtype detection is not handled,
        silently dropping the leading zero and changing the type.
        """
        _require(load_data)
        (tmp_path / "activity.csv").write_text(
            "site_id,date,nightly_count\n001,2020-01-01,100\n"
        )
        (tmp_path / "classifications.csv").write_text(
            "site_id,date,species,classified_count\n001,2020-01-01,SpA,30\n"
        )
        (tmp_path / "habitat.csv").write_text(
            "site_id,habitat,region\n001,Forest,North\n"
        )
        (tmp_path / "weather.csv").write_text(
            "date,temperature,wind_speed,precipitation,lunar_phase\n"
            "2020-01-01,15.0,2.0,0.0,0.2\n"
        )
        activity_df, clf_df, hab_df, _ = load_data(str(tmp_path))
        for df, col in [
            (activity_df, "site_id"),
            (clf_df,      "site_id"),
            (clf_df,      "species"),
            (hab_df,      "site_id"),
            (hab_df,      "habitat"),
            (hab_df,      "region"),
        ]:
            assert pd.api.types.is_string_dtype(df[col]) or df[col].dtype == object, (
                f"Column '{col}' must be string/object dtype as specified (str) in the prompt; "
                f"got {df[col].dtype}"
            )

class TestEstimateActivityRates:

    def _run(self, **kwargs):
        defaults = dict(
            activity_df=_basic_activity(),
            classifications_df=_basic_classifications(),
            habitat_df=_basic_habitat(),
            weather_df=_weather_all_dry(),
        )
        defaults.update(kwargs)
        return estimate_activity_rates(**defaults)

    def test_sensitivity_correction_applied(self):
        """
        S1 mean=100, S2 mean=50, global mean=75.
        sensitivity_S1=4/3  sensitivity_S2=2/3
        corrected_S1 = 30/(4/3) = 22.5
        corrected_S2 = 30/(2/3) = 45.0
        corrected mean = 33.75  ≠  naïve mean of raw counts (30.0)
        """
        _require(estimate_activity_rates)
        result = self._run()
        row = result[result["species"] == "SpA"]
        assert len(row) == 1
        assert abs(row.iloc[0]["corrected_mean_nightly_rate"] - 33.75) < 1e-6

    def test_per_site_mean_averaged_across_all_dates_for_that_site(self):
        """
        Verifies that the site mean nightly_count is the arithmetic mean across
        ALL dates for that site, not a single date's value or a sum.
        """
        _require(estimate_activity_rates)
        activity_df = pd.DataFrame({
            "site_id":       ["S1", "S1", "S2", "S2"],
            "date":          ["2020-01-01", "2020-01-02", "2020-01-01", "2020-01-02"],
            "nightly_count": [100, 60, 50, 50],
        })
        clf = pd.DataFrame({
            "site_id":          ["S1"],
            "date":             ["2020-01-01"],
            "species":          ["SpA"],
            "classified_count": [32],
        })
        hab = pd.DataFrame({
            "site_id": ["S1", "S2"],
            "habitat": ["Forest", "Forest"],
            "region":  ["North", "North"],
        })
        wx = _weather_all_dry(("2020-01-01", "2020-01-02"))
        result = estimate_activity_rates(activity_df, clf, hab, wx)
        row = result[result["species"] == "SpA"]
        assert len(row) == 1
        assert abs(row.iloc[0]["corrected_mean_nightly_rate"] - 26.0) < 1e-6, (
            f"Expected 26.0 (site mean=80, global mean=65). "
            f"Got {row.iloc[0]['corrected_mean_nightly_rate']}. "
            f"20.8 -> first-date only; 34.67 -> second-date only."
        )

    def test_precipitation_filter_excludes_rainy_nights(self):
        """
        Night 2020-01-02 has precipitation > 0 and inflated classified_count=60.
        Filtered result must differ from unfiltered result, proving the filter acts.
        """
        _require(estimate_activity_rates)
        clf = pd.DataFrame({
            "site_id":          ["S1", "S1", "S2", "S2"],
            "date":             ["2020-01-01", "2020-01-02",
                                 "2020-01-01", "2020-01-02"],
            "species":          ["SpA"] * 4,
            "classified_count": [30, 60, 30, 60],
        })
        all_dates = ("2020-01-01", "2020-01-02")
        rate_filtered = self._run(
            classifications_df=clf,
            weather_df=_weather_with_rain(["2020-01-02"], all_dates),
        )["corrected_mean_nightly_rate"].values[0]
        rate_unfiltered = self._run(
            classifications_df=clf,
            weather_df=_weather_all_dry(all_dates),
        )["corrected_mean_nightly_rate"].values[0]
        assert abs(rate_filtered - rate_unfiltered) > 1e-6

    def test_precipitation_boundary_is_strict_greater_than(self):
        """
        Verifies the precipitation filter is > 0.0 (strict), not >= 0.0.
        A night with precipitation == 0.0 exactly must be RETAINED.

        If the implementation uses >= 0.0, every night in the DataFrame is
        excluded (since all nights have precipitation >= 0.0), returning an
        empty DataFrame and failing the assertion.
        """
        _require(estimate_activity_rates)
        activity_df = pd.DataFrame([
            {"site_id": "S1", "date": "2020-01-01", "nightly_count": 100},
        ])
        clf = pd.DataFrame([
            {"site_id": "S1", "date": "2020-01-01", "species": "SpA", "classified_count": 30},
        ])
        hab = pd.DataFrame([
            {"site_id": "S1", "habitat": "Forest", "region": "North"},
        ])
        wx = pd.DataFrame([
            {"date": "2020-01-01", "temperature": 15.0, "wind_speed": 2.0,
             "precipitation": 0.0, "lunar_phase": 0.2},
        ])
        result = estimate_activity_rates(activity_df, clf, hab, wx)
        assert len(result) > 0, (
            "estimate_activity_rates returned no rows for precipitation=0.0; "
            "nights with precipitation==0.0 must be RETAINED (filter is > 0.0, not >= 0.0)"
        )

    def test_precipitation_filter_drops_all_sites_on_rainy_date(self):
        """
        The prompt specifies the filter joins on `date` and drops rows matching
        those dates, which means ALL sites' records on a rainy date must be
        excluded - not just the site whose row appears in a per-site check.
        """
        _require(estimate_activity_rates)
        activity_df = pd.DataFrame([
            {"site_id": "S1", "date": "2020-01-01", "nightly_count": 100},
            {"site_id": "S1", "date": "2020-01-02", "nightly_count": 100},
            {"site_id": "S2", "date": "2020-01-02", "nightly_count": 100},
        ])
        clf = pd.DataFrame([
            {"site_id": "S1", "date": "2020-01-01", "species": "SpA", "classified_count": 30},    # dry -> keep
            {"site_id": "S1", "date": "2020-01-02", "species": "SpA", "classified_count": 9999},  # rainy -> drop
            {"site_id": "S2", "date": "2020-01-02", "species": "SpA", "classified_count": 9999},  # rainy, different site -> ALSO drop
        ])
        hab = pd.DataFrame([
            {"site_id": "S1", "habitat": "Forest", "region": "North"},
            {"site_id": "S2", "habitat": "Forest", "region": "North"},
        ])
        wx = pd.DataFrame([
            {"date": "2020-01-01", "temperature": 15.0, "wind_speed": 2.0, "precipitation": 0.0, "lunar_phase": 0.2},
            {"date": "2020-01-02", "temperature": 15.0, "wind_speed": 2.0, "precipitation": 5.0, "lunar_phase": 0.2},
        ])
        result = estimate_activity_rates(activity_df, clf, hab, wx)
        row = result[result["species"] == "SpA"]
        assert len(row) == 1
        assert abs(row.iloc[0]["corrected_mean_nightly_rate"] - 30.0) < 1e-6, (
            f"Expected 30.0 (only S1's dry night contributes). "
            f"Got {row.iloc[0]['corrected_mean_nightly_rate']:.4f}. "
            f"A value near 5014.5 means S2's rainy-date row was not excluded "
            f"by the date-based precipitation filter."
        )

    def test_groups_by_species_habitat_and_region(self):
        """Two species x two habitat-region pairs -> four distinct output rows."""
        _require(estimate_activity_rates)
        activity_df = pd.DataFrame({
            "site_id":       ["S1", "S2", "S3", "S4"],
            "date":          ["2020-01-01"] * 4,
            "nightly_count": [100] * 4,
        })
        clf = pd.DataFrame({
            "site_id":          ["S1", "S2", "S3", "S4"],
            "date":             ["2020-01-01"] * 4,
            "species":          ["SpA", "SpB", "SpA", "SpB"],
            "classified_count": [10] * 4,
        })
        hab = pd.DataFrame({
            "site_id": ["S1", "S2", "S3", "S4"],
            "habitat": ["Forest", "Forest", "Grassland", "Grassland"],
            "region":  ["North", "North", "South", "South"],
        })
        wx = pd.DataFrame({
            "date": ["2020-01-01"], "temperature": [15.0],
            "wind_speed": [2.0], "precipitation": [0.0], "lunar_phase": [0.2],
        })
        result = estimate_activity_rates(activity_df, clf, hab, wx)
        assert len(result) == 4

    def test_output_carries_habitat_and_region_from_habitat_df(self):
        """
        Verifies that the output DataFrame includes habitat and region columns
        whose values are drawn from habitat_df.  With S1 mapped to Forest/North
        and S2 to Grassland/South, both values must appear in the output columns.
        An implementation that drops these columns or ignores habitat_df fails here.
        """
        _require(estimate_activity_rates)
        activity_df = pd.DataFrame({
            "site_id":       ["S1", "S2"],
            "date":          ["2020-01-01", "2020-01-01"],
            "nightly_count": [100, 100],
        })
        clf = pd.DataFrame({
            "site_id":          ["S1", "S2"],
            "date":             ["2020-01-01", "2020-01-01"],
            "species":          ["SpA", "SpA"],
            "classified_count": [30, 30],
        })
        hab = pd.DataFrame({
            "site_id": ["S1", "S2"],
            "habitat": ["Forest", "Grassland"],
            "region":  ["North", "South"],
        })
        wx = pd.DataFrame({
            "date": ["2020-01-01"], "temperature": [15.0],
            "wind_speed": [2.0], "precipitation": [0.0], "lunar_phase": [0.2],
        })
        result = estimate_activity_rates(activity_df, clf, hab, wx)
        assert "habitat" in result.columns, "habitat column missing from output"
        assert "region"  in result.columns, "region column missing from output"
        assert set(result["habitat"]) == {"Forest", "Grassland"}, (
            f"Expected habitat values {{'Forest','Grassland'}}; got {set(result['habitat'])}"
        )
        assert set(result["region"]) == {"North", "South"}, (
            f"Expected region values {{'North','South'}}; got {set(result['region'])}"
        )

    def test_lunar_phase_filter_is_not_applied(self):
        """
        The lunar-phase filter is scoped exclusively to identify_migration_timing.
        Bright-moon nights (lunar_phase > 0.5, precipitation = 0.0) must NOT be
        excluded in estimate_activity_rates.

        We call estimate_activity_rates twice with identical data except that in
        one call the single night has lunar_phase=0.9 and in the other 0.2.
        The results must be identical - if a spurious lunar filter were applied,
        the bright-moon call would return an empty DataFrame or a zero rate.
        """
        _require(estimate_activity_rates)
        activity_df = pd.DataFrame([
            {"site_id": "S1", "date": "2020-06-01", "nightly_count": 100},
        ])
        clf = pd.DataFrame([
            {"site_id": "S1", "date": "2020-06-01", "species": "SpA", "classified_count": 30},
        ])
        hab = pd.DataFrame([
            {"site_id": "S1", "habitat": "Forest", "region": "North"},
        ])
        _base_wx = dict(
            date=["2020-06-01"], temperature=[20.0], wind_speed=[2.0], precipitation=[0.0]
        )
        wx_bright = pd.DataFrame({**_base_wx, "lunar_phase": [0.9]})  # > 0.5, dry
        wx_dim    = pd.DataFrame({**_base_wx, "lunar_phase": [0.2]})  # clearly dim

        res_bright = estimate_activity_rates(activity_df, clf, hab, wx_bright)
        res_dim    = estimate_activity_rates(activity_df, clf, hab, wx_dim)

        assert len(res_bright) == len(res_dim), (
            "estimate_activity_rates returned fewer rows for bright-moon data; "
            "the lunar-phase filter must not be applied in this function"
        )
        rate_b = res_bright[res_bright["species"] == "SpA"].iloc[0]["corrected_mean_nightly_rate"]
        rate_d = res_dim   [res_dim   ["species"] == "SpA"].iloc[0]["corrected_mean_nightly_rate"]
        assert abs(rate_b - rate_d) < 1e-6, (
            f"estimate_activity_rates produced different rates for bright-moon ({rate_b}) "
            f"vs dim-moon ({rate_d}) nights; the lunar-phase filter must not be applied here"
        )


# ---------------------------------------------------------------------------
# identify_migration_timing
# ---------------------------------------------------------------------------

class TestIdentifyMigrationTiming:

    def _run(self, rainy=(), bright=()):
        _require(identify_migration_timing)
        return identify_migration_timing(
            _migration_classifications(),
            _migration_weather(rainy, bright),
        )

    def test_returns_exactly_three_rows(self):
        _require(identify_migration_timing)
        assert len(self._run()) == 3

    def test_species_are_exactly_the_three_obligate_migrants(self):
        """NonTargetSp (count=9999) in input must not appear in output."""
        _require(identify_migration_timing)
        assert set(self._run()["species"]) == set(MIGRANT_SPECIES)

    def test_peak_week_is_week_of_highest_mean_count(self):
        """Week 30 has classified_count=20, the maximum across all weeks."""
        _require(identify_migration_timing)
        result = self._run()
        lb = result[result["species"] == "Lasiurus borealis"].iloc[0]
        assert lb["peak_week"] == 30

    def test_season_start_is_lowest_week_at_or_above_threshold(self):
        """10% of peak(20) = 2.0; week 28 is the first week with mean ≥ 2."""
        _require(identify_migration_timing)
        result = self._run()
        lb = result[result["species"] == "Lasiurus borealis"].iloc[0]
        assert lb["season_start_week"] == 28

    def test_season_end_is_highest_week_at_or_above_threshold(self):
        """Week 32 is the last week with mean ≥ 10% of peak."""
        _require(identify_migration_timing)
        result = self._run()
        lb = result[result["species"] == "Lasiurus borealis"].iloc[0]
        assert lb["season_end_week"] == 32

    def test_week_values_are_in_iso_range_1_to_53(self):
        """
        Prompt specifies ISO calendar week numbers in the range 1 through 53.
        An implementation using dt.dayofyear // 7 would yield 0-indexed values
        (e.g., 0 for early January, 51 for late December) that pass the integer
        check but fall outside the ISO range.
        """
        _require(identify_migration_timing)
        result = self._run()
        for col in ("peak_week", "season_start_week", "season_end_week"):
            vals = result[col]
            assert (vals >= 1).all() and (vals <= 53).all(), (
                f"Column '{col}' has values outside ISO range [1, 53]: {vals.tolist()}"
            )

    def test_week_columns_are_integer_dtype(self):
        """Prompt specifies 'Week values are ISO calendar week integers.'
        A float dtype (e.g., 30.0) passes value-equality checks but violates
        the contract; parallel to test_year_column_is_integer_dtype in TestModelWnsImpact."""
        _require(identify_migration_timing)
        result = self._run()
        for col in ("peak_week", "season_start_week", "season_end_week"):
            assert pd.api.types.is_integer_dtype(result[col]), (
                f"Column '{col}' must be integer dtype as specified in the prompt; "
                f"got {result[col].dtype}"
            )

    def test_season_start_leq_peak_leq_season_end(self):
        _require(identify_migration_timing)
        result = self._run()
        for _, row in result.iterrows():
            assert row["season_start_week"] <= row["peak_week"] <= row["season_end_week"]

    def test_precipitation_filter_applied(self):
        """Marking the peak date (2020-07-21, week 30) as rainy must shift the peak."""
        _require(identify_migration_timing)
        result = self._run(rainy=["2020-07-21"])
        lb = result[result["species"] == "Lasiurus borealis"].iloc[0]
        assert lb["peak_week"] != 30

    def test_lunar_phase_filter_applied(self):
        """Marking the peak date (week 30) as lunar_phase=0.8 must shift the peak."""
        _require(identify_migration_timing)
        result = self._run(bright=["2020-07-21"])
        lb = result[result["species"] == "Lasiurus borealis"].iloc[0]
        assert lb["peak_week"] != 30

    def test_lunar_phase_boundary_is_strict_greater_than(self):
        """
        Verifies the filter is > 0.5 (strict), not >= 0.5.
        A record with lunar_phase = 0.5 exactly must be RETAINED.

        Week 30 (2020-07-21): lunar_phase=0.5, classified_count=40.
        Week 29 (2020-07-14): lunar_phase=0.0, classified_count=10.
        """
        _require(identify_migration_timing)
        clf = pd.DataFrame([
            {"site_id": "S1", "date": "2020-07-21", "species": "Lasiurus borealis",         "classified_count": 40},
            {"site_id": "S1", "date": "2020-07-14", "species": "Lasiurus borealis",         "classified_count": 10},
            {"site_id": "S1", "date": "2020-07-14", "species": "Lasiurus cinereus",         "classified_count": 5},
            {"site_id": "S1", "date": "2020-07-14", "species": "Lasionycteris noctivagans", "classified_count": 5},
        ])
        wx = pd.DataFrame({
            "date":          ["2020-07-14", "2020-07-21"],
            "temperature":   [20.0, 20.0],
            "wind_speed":    [2.0,  2.0],
            "precipitation": [0.0,  0.0],
            "lunar_phase":   [0.0,  0.5],   # 0.5 exactly on the boundary
        })
        result = identify_migration_timing(clf, wx)
        lb = result[result["species"] == "Lasiurus borealis"].iloc[0]
        assert lb["peak_week"] == 30, (
            f"Expected peak_week=30 (lunar_phase=0.5 must NOT be excluded by strict > 0.5 filter), "
            f"got {lb['peak_week']}. A result of 29 indicates an incorrect >= 0.5 boundary."
        )

    def test_weekly_means_aggregated_across_all_years_and_sites(self):
        """
        Verifies that weekly means are computed by averaging across ALL site-year
        combinations, not by using a single site or year.

        Design: S1 (year 2020) and S2 (year 2021) each have data on week 30,
        but with different counts (10 vs 30).  The ISO weeks are identical
        across years (verified: 2020-07-21 and 2021-07-26 both = week 30;
        2020-07-07 and 2021-07-12 both = week 28; 2020-07-01 and 2021-07-05
        both = week 27).
        """
        _require(identify_migration_timing)

        clf = pd.DataFrame([
            {"site_id": "S1", "date": "2020-07-21", "species": "Lasiurus borealis",         "classified_count": 10},
            {"site_id": "S1", "date": "2020-07-07", "species": "Lasiurus borealis",         "classified_count": 2},
            {"site_id": "S1", "date": "2020-07-01", "species": "Lasiurus borealis",         "classified_count": 1},
            {"site_id": "S2", "date": "2021-07-26", "species": "Lasiurus borealis",         "classified_count": 30},
            {"site_id": "S2", "date": "2021-07-12", "species": "Lasiurus borealis",         "classified_count": 2},
            {"site_id": "S2", "date": "2021-07-05", "species": "Lasiurus borealis",         "classified_count": 1},
            {"site_id": "S1", "date": "2020-07-21", "species": "Lasiurus cinereus",         "classified_count": 10},
            {"site_id": "S1", "date": "2020-07-21", "species": "Lasionycteris noctivagans", "classified_count": 10},
        ])
        all_dates = [
            "2020-07-01", "2020-07-07", "2020-07-21",
            "2021-07-05", "2021-07-12", "2021-07-26",
        ]
        wx = pd.DataFrame({
            "date":          all_dates,
            "temperature":   [20.0] * 6,
            "wind_speed":    [2.0]  * 6,
            "precipitation": [0.0]  * 6,
            "lunar_phase":   [0.2]  * 6,
        })

        result = identify_migration_timing(clf, wx)
        lb = result[result["species"] == "Lasiurus borealis"].iloc[0]
        assert lb["peak_week"] == 30, f"Expected peak_week=30, got {lb['peak_week']}"
        assert lb["season_start_week"] == 28, (
            f"Expected season_start_week=28 (requires cross-site/year aggregation), "
            f"got {lb['season_start_week']}"
        )

    def test_weekly_means_use_classified_count_field(self):
        """
        Verifies that weekly means are computed from the classified_count column,
        not from row counts or any other field.

        Weeks 29 and 31 each have TWO records for Lasiurus borealis (counts 4 and 4)
        -> mean(classified_count) = 4, but row count = 2.
        Week 30 has ONE record (count = 30) -> mean = 30, row count = 1.
        """
        _require(identify_migration_timing)
        clf = pd.DataFrame([
            {"site_id": "S1", "date": "2020-07-07", "species": "Lasiurus borealis", "classified_count": 3},   # wk 28 - season start (10% of 30)
            {"site_id": "S1", "date": "2020-07-14", "species": "Lasiurus borealis", "classified_count": 4},   # wk 29 - row 1
            {"site_id": "S1", "date": "2020-07-15", "species": "Lasiurus borealis", "classified_count": 4},   # wk 29 - row 2  -> mean=4
            {"site_id": "S1", "date": "2020-07-21", "species": "Lasiurus borealis", "classified_count": 30},  # wk 30 - peak mean=30
            {"site_id": "S1", "date": "2020-07-28", "species": "Lasiurus borealis", "classified_count": 4},   # wk 31 - row 1
            {"site_id": "S1", "date": "2020-07-29", "species": "Lasiurus borealis", "classified_count": 4},   # wk 31 - row 2  -> mean=4
            {"site_id": "S1", "date": "2020-08-04", "species": "Lasiurus borealis", "classified_count": 3},   # wk 32 - season end
            {"site_id": "S1", "date": "2020-07-21", "species": "Lasiurus cinereus",         "classified_count": 5},
            {"site_id": "S1", "date": "2020-07-21", "species": "Lasionycteris noctivagans", "classified_count": 5},
        ])
        all_dates = [
            "2020-07-07", "2020-07-14", "2020-07-15",
            "2020-07-21", "2020-07-28", "2020-07-29", "2020-08-04",
        ]
        wx = pd.DataFrame({
            "date":          all_dates,
            "temperature":   [20.0] * len(all_dates),
            "wind_speed":    [2.0]  * len(all_dates),
            "precipitation": [0.0]  * len(all_dates),
            "lunar_phase":   [0.2]  * len(all_dates),
        })
        result = identify_migration_timing(clf, wx)
        lb = result[result["species"] == "Lasiurus borealis"].iloc[0]
        assert lb["peak_week"] == 30, (
            f"Expected peak_week=30 (mean(classified_count) is highest at week 30). "
            f"Got {lb['peak_week']}. A value of 29 or 31 suggests row count was used "
            f"instead of mean(classified_count) - weeks 29 and 31 each have 2 rows vs 1 at week 30."
        )


# ---------------------------------------------------------------------------
# model_wns_impact
# ---------------------------------------------------------------------------

class TestModelWnsImpact:

    def _run(self, means=None):
        _require(model_wns_impact)
        return model_wns_impact(_wns_classifications(means), _wns_weather())

    def test_output_species_are_exactly_the_three_wns_species(self):
        """NonTargetSp in input must not appear in output."""
        _require(model_wns_impact)
        assert set(self._run()["species"]) == set(WNS_SPECIES)

    def test_fifteen_rows_total(self):
        """3 species x 5 years = 15 rows."""
        _require(model_wns_impact)
        assert len(self._run()) == 15

    def test_year_column_is_integer_dtype(self):
        """Prompt specifies year as (int); a float year (e.g., 2020.0) violates the contract."""
        _require(model_wns_impact)
        result = self._run()
        assert pd.api.types.is_integer_dtype(result["year"]), (
            f"year column must be integer dtype as specified (int) in the prompt; "
            f"got {result['year'].dtype}"
        )

    def test_year1_pct_change_is_zero(self):
        _require(model_wns_impact)
        result = self._run()
        y1 = result[result["year"] == result["year"].min()]
        assert (y1["pct_change_from_year1"].abs() < 1e-6).all()

    def test_year1_mean_nightly_count_is_correct(self):
        """Myotis lucifugus year1 classified_count=100 -> mean=100."""
        _require(model_wns_impact)
        result = self._run()
        ml_y1 = result[
            (result["species"] == "Myotis lucifugus") &
            (result["year"] == result["year"].min())
        ]
        assert abs(ml_y1.iloc[0]["mean_nightly_count"] - 100.0) < 1e-6

    def test_pct_change_formula_is_correct(self):
        """Myotis lucifugus: year1=100, year5=40 -> pct_change = -60.0."""
        _require(model_wns_impact)
        result = self._run()
        ml_y5 = result[
            (result["species"] == "Myotis lucifugus") &
            (result["year"] == result["year"].max())
        ]
        assert abs(ml_y5.iloc[0]["pct_change_from_year1"] - (-60.0)) < 1e-6

    def test_impact_classification_same_for_all_rows_of_a_species(self):
        _require(model_wns_impact)
        result = self._run()
        for sp in WNS_SPECIES:
            assert result[result["species"] == sp]["impact_classification"].nunique() == 1

    def test_classification_severe(self):
        """Myotis lucifugus year5 pct_change=-60 (<= -50) -> Severe."""
        _require(model_wns_impact)
        result = self._run()
        ml = result[result["species"] == "Myotis lucifugus"]
        assert (ml["impact_classification"] == "Severe").all()

    def test_classification_moderate(self):
        """Myotis septentrionalis year5 pct_change=-30 (<= -25 and > -50) -> Moderate."""
        _require(model_wns_impact)
        result = self._run()
        ms = result[result["species"] == "Myotis septentrionalis"]
        assert (ms["impact_classification"] == "Moderate").all()

    def test_classification_none(self):
        """Perimyotis subflavus year5 pct_change=-10 (> -25) -> None."""
        _require(model_wns_impact)
        result = self._run()
        ps = result[result["species"] == "Perimyotis subflavus"]
        assert (ps["impact_classification"] == "None").all()

    def test_severe_boundary_at_exactly_minus_50(self):
        """pct_change exactly -50.0 must classify as Severe (prompt: <= -50.0)."""
        _require(model_wns_impact)
        means = {
            "Myotis lucifugus":       [100, 100, 100, 100, 50],  # exactly -50 %
            "Myotis septentrionalis": [100] * 5,
            "Perimyotis subflavus":   [100] * 5,
        }
        result = self._run(means=means)
        ml = result[result["species"] == "Myotis lucifugus"]
        assert (ml["impact_classification"] == "Severe").all()

    def test_moderate_boundary_at_exactly_minus_25(self):
        """pct_change exactly -25.0 must classify as Moderate (prompt: <= -25.0 and > -50.0)."""
        _require(model_wns_impact)
        means = {
            "Myotis lucifugus":       [100] * 5,
            "Myotis septentrionalis": [100, 100, 100, 100, 75],  # exactly -25 %
            "Perimyotis subflavus":   [100] * 5,
        }
        result = self._run(means=means)
        ms = result[result["species"] == "Myotis septentrionalis"]
        assert (ms["impact_classification"] == "Moderate").all()

    def test_precipitation_filter_applied(self):
        """
        An extra rainy night in year1 carries classified_count=9999.
        Filtered year1 mean must differ from the unfiltered mean,
        proving the rainy night was excluded.
        """
        _require(model_wns_impact)
        clf = pd.DataFrame(
            [{"site_id": "S1", "date": f"{y}-06-01",
              "species": sp, "classified_count": 80}
             for y in _WNS_YEARS for sp in WNS_SPECIES] +
            [{"site_id": "S1", "date": "2020-06-15",
              "species": sp, "classified_count": 9999}
             for sp in WNS_SPECIES]  # rainy night with extreme count
        )
        all_dates = [f"{y}-06-01" for y in _WNS_YEARS] + ["2020-06-15"]
        wx_rainy = pd.DataFrame({
            "date":          all_dates,
            "temperature":   [20.0] * len(all_dates),
            "wind_speed":    [2.0]  * len(all_dates),
            "precipitation": [5.0 if d == "2020-06-15" else 0.0 for d in all_dates],
            "lunar_phase":   [0.2]  * len(all_dates),
        })
        wx_dry = pd.DataFrame({
            "date":          all_dates,
            "temperature":   [20.0] * len(all_dates),
            "wind_speed":    [2.0]  * len(all_dates),
            "precipitation": [0.0]  * len(all_dates),
            "lunar_phase":   [0.2]  * len(all_dates),
        })
        res_filtered   = model_wns_impact(clf, wx_rainy)
        res_unfiltered = model_wns_impact(clf, wx_dry)
        y1 = res_filtered["year"].min()
        mean_filtered   = res_filtered[
            (res_filtered["species"] == "Myotis lucifugus") &
            (res_filtered["year"] == y1)
        ]["mean_nightly_count"].values[0]
        mean_unfiltered = res_unfiltered[
            (res_unfiltered["species"] == "Myotis lucifugus") &
            (res_unfiltered["year"] == y1)
        ]["mean_nightly_count"].values[0]
        assert abs(mean_filtered - mean_unfiltered) > 1e-6

    def test_mean_per_year_aggregated_across_all_sites(self):
        """
        Verifies that mean_nightly_count for each year is computed as the mean
        across ALL records in that year (all sites, all dates), not a single
        site or record.

        Year 2020: S1 count=80, S2 count=120 -> correct mean = (80+120)/2 = 100.
        S1-only -> 80 (wrong).  S2-only -> 120 (wrong).
        Years 2021-2024: single record each, count=100.
        """
        _require(model_wns_impact)

        clf = pd.DataFrame([
            # Year 2020: two sites with different counts for Myotis lucifugus
            {"site_id": "S1", "date": "2020-06-01", "species": "Myotis lucifugus",       "classified_count": 80},
            {"site_id": "S2", "date": "2020-06-01", "species": "Myotis lucifugus",       "classified_count": 120},
            # Years 2021-2024: single site
            {"site_id": "S1", "date": "2021-06-01", "species": "Myotis lucifugus",       "classified_count": 100},
            {"site_id": "S1", "date": "2022-06-01", "species": "Myotis lucifugus",       "classified_count": 100},
            {"site_id": "S1", "date": "2023-06-01", "species": "Myotis lucifugus",       "classified_count": 100},
            {"site_id": "S1", "date": "2024-06-01", "species": "Myotis lucifugus",       "classified_count": 100},
            # Other WNS species (required for output to contain all three species)
            {"site_id": "S1", "date": "2020-06-01", "species": "Myotis septentrionalis", "classified_count": 50},
            {"site_id": "S1", "date": "2021-06-01", "species": "Myotis septentrionalis", "classified_count": 50},
            {"site_id": "S1", "date": "2022-06-01", "species": "Myotis septentrionalis", "classified_count": 50},
            {"site_id": "S1", "date": "2023-06-01", "species": "Myotis septentrionalis", "classified_count": 50},
            {"site_id": "S1", "date": "2024-06-01", "species": "Myotis septentrionalis", "classified_count": 50},
            {"site_id": "S1", "date": "2020-06-01", "species": "Perimyotis subflavus",   "classified_count": 50},
            {"site_id": "S1", "date": "2021-06-01", "species": "Perimyotis subflavus",   "classified_count": 50},
            {"site_id": "S1", "date": "2022-06-01", "species": "Perimyotis subflavus",   "classified_count": 50},
            {"site_id": "S1", "date": "2023-06-01", "species": "Perimyotis subflavus",   "classified_count": 50},
            {"site_id": "S1", "date": "2024-06-01", "species": "Perimyotis subflavus",   "classified_count": 50},
        ])
        all_dates = [f"{y}-06-01" for y in _WNS_YEARS]
        wx = pd.DataFrame({
            "date":          all_dates,
            "temperature":   [20.0] * 5,
            "wind_speed":    [2.0]  * 5,
            "precipitation": [0.0]  * 5,
            "lunar_phase":   [0.2]  * 5,
        })

        result = model_wns_impact(clf, wx)
        ml_y1 = result[
            (result["species"] == "Myotis lucifugus") &
            (result["year"] == result["year"].min())
        ]
        # Correct: (80 + 120) / 2 = 100.  S1-only: 80.  S2-only: 120.
        assert abs(ml_y1.iloc[0]["mean_nightly_count"] - 100.0) < 1e-6, (
            f"Expected mean=100.0 (average of 80 and 120 across both sites), "
            f"got {ml_y1.iloc[0]['mean_nightly_count']}"
        )

    def test_lunar_phase_filter_is_not_applied(self):
        """
        The lunar-phase filter is scoped exclusively to identify_migration_timing.
        Bright-moon nights (lunar_phase > 0.5, precipitation = 0.0) must NOT be
        excluded in model_wns_impact.

        We call model_wns_impact twice with identical classification data but with
        all nights set to lunar_phase=0.9 in one call and 0.2 in the other.
        mean_nightly_count must be identical in both results - if a spurious
        lunar filter were applied, the bright-moon call would return an empty
        DataFrame or zero means for each year.
        """
        _require(model_wns_impact)
        clf = pd.DataFrame(
            [{"site_id": "S1", "date": f"{y}-06-01", "species": sp, "classified_count": 80}
             for y in _WNS_YEARS for sp in WNS_SPECIES]
        )
        all_dates = [f"{y}-06-01" for y in _WNS_YEARS]
        _base = dict(
            date=all_dates, temperature=[20.0]*5, wind_speed=[2.0]*5, precipitation=[0.0]*5
        )
        wx_bright = pd.DataFrame({**_base, "lunar_phase": [0.9]*5})  # all bright, dry
        wx_dim    = pd.DataFrame({**_base, "lunar_phase": [0.2]*5})  # all dim

        res_bright = model_wns_impact(clf, wx_bright)
        res_dim    = model_wns_impact(clf, wx_dim)

        assert len(res_bright) == len(res_dim), (
            "model_wns_impact returned fewer rows for bright-moon data; "
            "the lunar-phase filter must not be applied in this function"
        )
        for sp in WNS_SPECIES:
            for yr in _WNS_YEARS:
                mean_b = res_bright[
                    (res_bright["species"] == sp) & (res_bright["year"] == yr)
                ].iloc[0]["mean_nightly_count"]
                mean_d = res_dim[
                    (res_dim["species"] == sp) & (res_dim["year"] == yr)
                ].iloc[0]["mean_nightly_count"]
                assert abs(mean_b - mean_d) < 1e-6, (
                    f"model_wns_impact: {sp} year {yr} differs between bright-moon "
                    f"({mean_b}) and dim-moon ({mean_d}); lunar filter must not apply here"
                )


# ---------------------------------------------------------------------------
# generate_report
# ---------------------------------------------------------------------------

class TestGenerateReport:

    def _run(self, tmp_path):
        _require(generate_report)
        out = str(tmp_path / "report.txt")
        generate_report(
            _minimal_activity_rates(),
            _minimal_migration_timing(),
            _minimal_wns_impact(),
            out,
        )
        return out

    def test_return_value_is_none(self, tmp_path):
        _require(generate_report)
        out = str(tmp_path / "report.txt")
        result = generate_report(
            _minimal_activity_rates(),
            _minimal_migration_timing(),
            _minimal_wns_impact(),
            out,
        )
        assert result is None

    def test_file_contains_four_required_sections_in_order(self, tmp_path):
        """
        The prompt specifies both the section names and their order.
        Verified by checking string positions are strictly ascending.
        """
        _require(generate_report)
        content = Path(self._run(tmp_path)).read_text()
        sections = [
            "Species Activity Summary",
            "Migration Timing Summary",
            "White-Nose Syndrome Impact Summary",
            "Per-Region Species Status",
        ]
        positions = [content.find(s) for s in sections]
        assert all(p >= 0 for p in positions), \
            f"Missing section(s). Positions: {dict(zip(sections, positions))}"
        assert positions == sorted(positions), \
            "Sections are not in the required order"

    def test_each_required_section_appears_exactly_once(self, tmp_path):
        """
        The prompt says 'exactly four labeled sections'.  This test verifies the
        'exactly' constraint by checking that each required header appears exactly
        once - an implementation that duplicates a section would fail here while
        still passing the positional ordering test.
        """
        _require(generate_report)
        content = Path(self._run(tmp_path)).read_text()
        for section in [
            "Species Activity Summary",
            "Migration Timing Summary",
            "White-Nose Syndrome Impact Summary",
            "Per-Region Species Status",
        ]:
            count = content.count(section)
            assert count == 1, \
                f"Section '{section}' appears {count} time(s), expected exactly 1"

    def test_species_activity_summary_contains_data(self, tmp_path):
        """
        Verifies that Species Activity Summary contains actual data, not just a
        header.  Species names from activity_rates and at least one numeric value
        must appear in the block between the first and second section headers.
        """
        _require(generate_report)
        content = Path(self._run(tmp_path)).read_text()
        h1 = content.find("Species Activity Summary")
        h2 = content.find("Migration Timing Summary")
        assert h1 >= 0 and h2 > h1
        block = content[h1:h2]
        for _, row in _minimal_activity_rates().iterrows():
            assert row["species"] in block, (
                f"Species '{row['species']}' not found in Species Activity Summary block"
            )
        assert re.search(r"\d+\.\d+", block), (
            "No numeric value found in Species Activity Summary block"
        )

    def test_migration_timing_summary_contains_data(self, tmp_path):
        """
        Verifies that Migration Timing Summary contains actual data.  Each
        migrant species name and at least one peak_week value must appear in
        the block between the second and third section headers.
        """
        _require(generate_report)
        content = Path(self._run(tmp_path)).read_text()
        h2 = content.find("Migration Timing Summary")
        h3 = content.find("White-Nose Syndrome Impact Summary")
        assert h2 >= 0 and h3 > h2
        block = content[h2:h3]
        timing = _minimal_migration_timing()
        for sp in timing["species"]:
            assert sp in block, (
                f"Migrant species '{sp}' not found in Migration Timing Summary block"
            )
        peak_weeks = timing["peak_week"].tolist()
        assert any(str(w) in block for w in peak_weeks), (
            f"No peak_week value from {peak_weeks} found in Migration Timing Summary block"
        )

    def test_wns_impact_summary_contains_data(self, tmp_path):
        """
        Verifies that White-Nose Syndrome Impact Summary contains actual data.
        Each WNS species name must appear in the block between the third and
        fourth section headers.
        """
        _require(generate_report)
        content = Path(self._run(tmp_path)).read_text()
        h3 = content.find("White-Nose Syndrome Impact Summary")
        h4 = content.find("Per-Region Species Status")
        assert h3 >= 0 and h4 > h3
        block = content[h3:h4]
        for sp in WNS_SPECIES:
            assert sp in block, (
                f"WNS species '{sp}' not found in White-Nose Syndrome Impact Summary block"
            )

    def test_overwrites_existing_file(self, tmp_path):
        """Calling generate_report on an existing path must replace its content."""
        _require(generate_report)
        out = str(tmp_path / "report.txt")
        Path(out).write_text("SENTINEL_OLD_CONTENT")
        generate_report(
            _minimal_activity_rates(),
            _minimal_migration_timing(),
            _minimal_wns_impact(),
            out,
        )
        assert "SENTINEL_OLD_CONTENT" not in Path(out).read_text()

    def test_per_region_rates_rounded_to_two_decimal_places(self, tmp_path):
        """
        Verifies the two-decimal-place rounding requirement from both directions
        in a single pass over the section:

        (a) Positive: the rounded value '7.89' (from input 7.891) is actually
            written - an implementation that omits the rate entirely would fail.
            7.891 rounds to 7.89 under every rounding convention (third digit
            is 1, always rounds down), so the assertion is unambiguous.

        (b) Negative: no number with three or more decimal digits appears -
            an implementation that writes rates at full precision would fail.
            This also subsumes the earlier specific check that '12.345' is absent.
        """
        _require(generate_report)
        content = Path(self._run(tmp_path)).read_text()
        section_start = content.find("Per-Region Species Status")
        assert section_start >= 0, "Per-Region Species Status section missing"
        section_content = content[section_start:]

        assert "7.89" in section_content, (
            "Rounded rate '7.89' (from input 7.891) not found in Per-Region "
            "Species Status - the rate may be omitted from the report entirely"
        )
        over_precise = re.findall(r"\d+\.\d{3,}", section_content)
        assert len(over_precise) == 0, (
            f"Found numbers with more than two decimal places in "
            f"Per-Region Species Status: {over_precise}"
        )

    def test_per_region_status_includes_each_region_value(self, tmp_path):
        """
        Req 38: Per-Region Species Status must include each distinct region
        value present in activity_rates.  We pass regions "North" and "South"
        and verify both appear in the section of the report that follows the
        Per-Region Species Status header.
        """
        _require(generate_report)
        content = Path(self._run(tmp_path)).read_text()
        section_start = content.find("Per-Region Species Status")
        assert section_start >= 0, "Per-Region Species Status section missing"
        section_content = content[section_start:]
        for region in _minimal_activity_rates()["region"].unique():
            assert region in section_content, \
                f"Region '{region}' not found in Per-Region Species Status"

    def test_per_region_status_groups_species_habitat_under_correct_region(self, tmp_path):
        """
        Verifies that each species-habitat combination is associated with its
        correct region in Per-Region Species Status, without prescribing layout.
        """
        _require(generate_report)
        content = Path(self._run(tmp_path)).read_text()
        section_start = content.find("Per-Region Species Status")
        assert section_start >= 0, "Per-Region Species Status section missing"
        s = content[section_start:]

        rates       = _minimal_activity_rates()
        all_regions = set(rates["region"])

        for _, row in rates.iterrows():
            sp     = row["species"]
            hab    = row["habitat"]
            region = row["region"]

            # Format A - tabular/inline: region label and content on the same line
            same_line = any(
                region in line and (sp in line or hab in line)
                for line in s.splitlines()
            )

            # Format B - block-headed: content follows region label before the
            # next region label appears
            region_pos    = s.find(region)
            next_boundary = len(s)
            for other in all_regions - {region}:
                other_pos = s.find(other, region_pos + len(region))
                if other_pos != -1 and other_pos < next_boundary:
                    next_boundary = other_pos
            block_match = sp in s[region_pos:next_boundary] and \
                          hab in s[region_pos:next_boundary]

            assert same_line or block_match, (
                f"'{sp}' and '{hab}' do not appear in association with "
                f"region '{region}' in Per-Region Species Status"
            )

_CLI_DATES   = [f"{y}-06-01" for y in _WNS_YEARS]
_CLI_SPECIES = list(MIGRANT_SPECIES) + list(WNS_SPECIES)


def _write_cli_data(data_dir: Path):
    data_dir.mkdir(parents=True, exist_ok=True)
    (data_dir / "activity.csv").write_text(
        "site_id,date,nightly_count\n" +
        "".join(f"S1,{d},100\n" for d in _CLI_DATES)
    )
    (data_dir / "classifications.csv").write_text(
        "site_id,date,species,classified_count\n" +
        "".join(f"S1,{d},{sp},50\n" for d in _CLI_DATES for sp in _CLI_SPECIES)
    )
    (data_dir / "habitat.csv").write_text(
        "site_id,habitat,region\nS1,Forest,North\n"
    )
    (data_dir / "weather.csv").write_text(
        "date,temperature,wind_speed,precipitation,lunar_phase\n" +
        "".join(f"{d},20.0,2.0,0.0,0.2\n" for d in _CLI_DATES)
    )


class TestCLIEntryPoint:

    def test_cli_exits_with_code_zero(self, tmp_path):
        """CLI must complete without error when given valid input."""
        _write_cli_data(tmp_path / "data")
        result = subprocess.run(
            [sys.executable, str(_REPO_ROOT / "pipeline" / "run_pipeline.py"),
             str(tmp_path / "data")],
            capture_output=True, text=True,
            cwd=str(_REPO_ROOT),
        )
        assert result.returncode == 0

    def test_cli_creates_report_file(self, tmp_path):
        """CLI must write the report to reports/wildlife_agency_report.txt."""
        _write_cli_data(tmp_path / "data")
        report_path = _REPO_ROOT / "reports" / "wildlife_agency_report.txt"
        if report_path.exists():
            report_path.unlink()
        subprocess.run(
            [sys.executable, str(_REPO_ROOT / "pipeline" / "run_pipeline.py"),
             str(tmp_path / "data")],
            capture_output=True, text=True,
            cwd=str(_REPO_ROOT),
        )
        assert report_path.is_file()


# ---------------------------------------------------------------------------
# Bundled sample dataset
# ---------------------------------------------------------------------------

def _load_bundled():
    """
    Load the four bundled CSVs via load_data("data/").
    Calls pytest.fail (FAILED, not ERROR) if the module or files are absent.
    """
    _require(load_data)
    try:
        return load_data("data/")
    except (FileNotFoundError, OSError) as exc:
        pytest.fail(f"Bundled data files could not be loaded: {exc}")


class TestBundledDataset:

    # --- Req 51 ---
    def test_activity_has_at_least_five_distinct_sites(self):
        activity_df, _, _, _ = _load_bundled()
        assert activity_df["site_id"].nunique() >= 5

    # --- Req 52 ---
    def test_activity_spans_five_consecutive_calendar_years(self):
        activity_df, _, _, _ = _load_bundled()
        years = sorted(
            pd.to_datetime(activity_df["date"]).dt.year.unique()
        )
        assert len(years) == 5, f"Expected 5 years, got {len(years)}: {years}"
        assert years[-1] - years[0] == 4, \
            f"Years are not consecutive: {years}"

    # --- Req 53 ---
    def test_classifications_share_dates_with_activity(self):
        """
        Classifications must cover the same survey nights as activity records.
        Checking year overlap is insufficient - two CSVs can share calendar
        years while having no overlapping dates at all.  We assert that at
        least one date appears in both DataFrames.
        """
        activity_df, clf_df, _, _ = _load_bundled()
        act_dates = set(activity_df["date"])
        clf_dates = set(clf_df["date"])
        assert bool(act_dates & clf_dates), (
            "No dates are shared between activity.csv and classifications.csv"
        )

    # --- Req 54 ---
    def test_habitat_has_at_least_three_distinct_habitat_values(self):
        _, _, hab_df, _ = _load_bundled()
        assert hab_df["habitat"].nunique() >= 3

    # --- Req 55 ---
    def test_habitat_has_at_least_two_distinct_region_values(self):
        _, _, hab_df, _ = _load_bundled()
        assert hab_df["region"].nunique() >= 2

    # --- Req 56 ---
    def test_habitat_provides_mapping_for_every_site_in_activity_and_classifications(self):
        activity_df, clf_df, hab_df, _ = _load_bundled()
        all_sites = set(activity_df["site_id"]) | set(clf_df["site_id"])
        mapped_sites = set(hab_df["site_id"])
        assert all_sites.issubset(mapped_sites), \
            f"Sites without habitat mapping: {all_sites - mapped_sites}"

    # --- Req 57 ---
    def test_classifications_contains_all_six_target_species(self):
        _, clf_df, _, _ = _load_bundled()
        present = set(clf_df["species"])
        missing = TARGET_SPECIES - present
        assert not missing, f"Target species missing from classifications: {missing}"

    # --- Req 58 ---
    def test_classifications_contains_at_least_two_nontarget_species(self):
        _, clf_df, _, _ = _load_bundled()
        nontarget = set(clf_df["species"]) - TARGET_SPECIES
        assert len(nontarget) >= 2, \
            f"Expected >=2 non-target species, found {len(nontarget)}: {nontarget}"

    # --- Req 59 ---
    def test_weather_has_at_least_one_rainy_date(self):
        _, _, _, wx_df = _load_bundled()
        assert (wx_df["precipitation"] > 0.0).any(), \
            "weather.csv has no row with precipitation > 0.0"

    # --- Req 60 ---
    def test_weather_has_at_least_one_bright_moon_date(self):
        _, _, _, wx_df = _load_bundled()
        assert (wx_df["lunar_phase"] > 0.5).any(), \
            "weather.csv has no row with lunar_phase > 0.5"

    # --- Req 61 ---
    def test_classification_records_exist_on_rainy_dates(self):
        """
        The bundled data must have classification records on at least one
        rainy date so that the precipitation filter has an observable effect
        on downstream computations.
        """
        _, clf_df, _, wx_df = _load_bundled()
        rainy_dates = set(wx_df[wx_df["precipitation"] > 0.0]["date"])
        clf_dates = set(clf_df["date"])
        assert bool(rainy_dates & clf_dates), \
            "No classification records fall on rainy dates; " \
            "precipitation filter would have no effect"

    # --- Req 62 ---
    def test_migrant_classification_records_exist_on_bright_dry_dates(self):
        """
        The bundled data must have obligate migrant classification records on
        at least one date that has lunar_phase > 0.5 and precipitation == 0.0,
        so that the lunar phase filter has an observable effect on migration
        timing results.
        """
        _, clf_df, _, wx_df = _load_bundled()
        bright_dry_dates = set(
            wx_df[
                (wx_df["lunar_phase"] > 0.5) & (wx_df["precipitation"] == 0.0)
            ]["date"]
        )
        migrant_dates = set(
            clf_df[clf_df["species"].isin(MIGRANT_SPECIES)]["date"]
        )
        assert bool(bright_dry_dates & migrant_dates), \
            "No obligate migrant records fall on bright-moon dry dates; " \
            "lunar phase filter would have no effect on migration timing"