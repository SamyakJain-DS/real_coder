import csv
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest


_REQUIRED_MODELS = {"first_touch", "last_touch", "linear", "time_decay", "markov", "shapley"}


def _write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


_SAMPLE_WORKFLOW_CACHE: dict[str, object] = {}


def _get_sample_workflow(import_or_fail, project_root: Path) -> dict:
    cached = _SAMPLE_WORKFLOW_CACHE.get("out")
    if cached is not None:
        return cached  # type: ignore[return-value]

    runner = import_or_fail("app.runner")
    in_csv = project_root / "app" / "data" / "sample_journey_events.csv"
    parent_dir = Path(tempfile.mkdtemp(prefix="task157ay_out_"))
    out_dir = parent_dir / "out"
    out = runner.run_attribution_comparison(
        str(in_csv), str(out_dir), random_seed=0, n_bootstrap=4, num_permutations=20
    )
    _SAMPLE_WORKFLOW_CACHE["out"] = out
    _SAMPLE_WORKFLOW_CACHE["out_dir"] = out_dir
    return out


def test_runner_raises_valueerror_when_dataset_has_zero_converted_journeys(import_or_fail, tmp_path):
    runner = import_or_fail("app.runner")
    in_csv = tmp_path / "events.csv"
    _write_csv(
        in_csv,
        [
            {"journey_id": "J1", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 0},
            {"journey_id": "J2", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 0},
        ],
    )
    with pytest.raises(ValueError):
        runner.run_attribution_comparison(str(in_csv), str(tmp_path / "out"))


def test_runner_raises_valueerror_when_dataset_has_zero_null_journeys(import_or_fail, tmp_path):
    runner = import_or_fail("app.runner")
    in_csv = tmp_path / "events.csv"
    _write_csv(
        in_csv,
        [
            {"journey_id": "J1", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
            {"journey_id": "J2", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 1},
        ],
    )
    with pytest.raises(ValueError):
        runner.run_attribution_comparison(str(in_csv), str(tmp_path / "out"))


def test_runner_raises_valueerror_when_holdout_test_split_has_single_class(import_or_fail, tmp_path):
    runner = import_or_fail("app.runner")
    in_csv = tmp_path / "events.csv"
    _write_csv(
        in_csv,
        [
            {"journey_id": "J1", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
            {"journey_id": "J2", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 1},
            {"journey_id": "J3", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 0},
            {"journey_id": "J4", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-04T00:00:00Z", "converted": 0},
        ],
    )
    with pytest.raises(ValueError):
        runner.run_attribution_comparison(str(in_csv), str(tmp_path / "out"), holdout_fraction=0.25)


def test_runner_raises_valueerror_when_holdout_train_split_has_single_class(import_or_fail, tmp_path):
    runner = import_or_fail("app.runner")
    in_csv = tmp_path / "events.csv"
    _write_csv(
        in_csv,
        [
            {"journey_id": "J1", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
            {"journey_id": "J2", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 1},
            {"journey_id": "J3", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 0},
            {"journey_id": "J4", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-04T00:00:00Z", "converted": 0},
        ],
    )
    with pytest.raises(ValueError):
        runner.run_attribution_comparison(str(in_csv), str(tmp_path / "out"), holdout_fraction=0.75)


def test_written_files_mapping_contains_all_required_output_names(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    out_dir = _SAMPLE_WORKFLOW_CACHE.get("out_dir")
    assert isinstance(out_dir, Path)

    expected_files = {
        "attribution_channel_shares.csv",
        "holdout_metrics.csv",
        "bootstrap_stability.csv",
        "recommendation.md",
        "channel_share_by_model.png",
        "channel_share_heatmap.png",
        "bootstrap_stability.png",
        "holdout_performance.png",
    }
    assert expected_files.issubset(set(out["written_files"].keys()))
    for name in expected_files:
        p = Path(out["written_files"][name]).resolve()
        assert p.is_file()
        assert p.is_relative_to(out_dir.resolve())


def test_channel_shares_table_has_models_as_rows_and_channels_as_columns(import_or_fail, project_root):
    io = import_or_fail("app.io")
    events = io.load_journey_events_csv(str(project_root / "app" / "data" / "sample_journey_events.csv"))
    channels = set(events["channel"].unique().tolist())
    out = _get_sample_workflow(import_or_fail, project_root)
    df = out["channel_shares"]
    assert df.index.is_unique
    assert _REQUIRED_MODELS.issubset(set(df.index.astype(str).tolist()))
    assert set(df.columns.astype(str).tolist()) == channels


def test_attribution_channel_shares_csv_has_models_and_channels(import_or_fail, project_root):
    io = import_or_fail("app.io")
    events = io.load_journey_events_csv(str(project_root / "app" / "data" / "sample_journey_events.csv"))
    channels = set(events["channel"].unique().tolist())
    out = _get_sample_workflow(import_or_fail, project_root)
    path = Path(out["written_files"]["attribution_channel_shares.csv"])
    assert path.is_file()
    df = pd.read_csv(path)
    assert "model" in df.columns
    assert df["model"].is_unique
    assert _REQUIRED_MODELS.issubset(set(df["model"].astype(str).tolist()))
    channel_cols = set(c for c in df.columns if c != "model")
    assert channel_cols == channels
    assert df.columns.tolist()[0] == "model"


def test_channel_shares_rows_sum_to_one(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    sums = out["channel_shares"].sum(axis=1).to_numpy(dtype=float)
    assert np.allclose(sums, 1.0)


def test_holdout_metrics_table_has_exactly_roc_auc_and_log_loss_columns(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    assert set(out["holdout_metrics"].columns.tolist()) == {"roc_auc", "log_loss"}


def test_holdout_metrics_csv_has_models_and_metric_columns(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    path = Path(out["written_files"]["holdout_metrics.csv"])
    assert path.is_file()
    df = pd.read_csv(path)
    assert set(df.columns.tolist()) == {"model", "roc_auc", "log_loss"}
    assert df["model"].is_unique
    assert _REQUIRED_MODELS.issubset(set(df["model"].astype(str).tolist()))


def test_holdout_metrics_has_one_row_per_model(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    df = out["holdout_metrics"]
    assert df.index.is_unique
    assert _REQUIRED_MODELS.issubset(set(df.index.astype(str).tolist()))


def test_recommended_model_matches_prompt_selection_rule(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    metrics = out["holdout_metrics"].copy()
    metrics["stability_score"] = out["stability_scores"].astype(float)
    metrics["_model"] = metrics.index.astype(str)
    metrics = metrics.sort_values(by=["roc_auc", "stability_score", "_model"], ascending=[False, True, True])
    expected = str(metrics.iloc[0]["_model"])
    assert out["recommended_model"] == expected


def test_bootstrap_stability_csv_has_consecutive_bootstrap_ids(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    bootstrap_path = Path(out["written_files"]["bootstrap_stability.csv"])
    assert bootstrap_path.is_file()
    df = pd.read_csv(bootstrap_path)
    assert set(df["bootstrap_id"].astype(int).tolist()) == {0, 1, 2, 3}


def test_bootstrap_stability_csv_has_one_row_per_model_per_bootstrap_id(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    bootstrap_path = Path(out["written_files"]["bootstrap_stability.csv"])
    assert bootstrap_path.is_file()
    df = pd.read_csv(bootstrap_path)
    assert _REQUIRED_MODELS.issubset(set(df["model"].astype(str).unique().tolist()))
    expected_ids = {0, 1, 2, 3}
    for model_name in sorted(_REQUIRED_MODELS):
        sub = df.loc[df["model"].astype(str) == model_name]
        assert set(sub["bootstrap_id"].astype(int).tolist()) == expected_ids
        counts = sub.groupby("bootstrap_id").size()
        counts = {int(k): int(v) for k, v in counts.items()}
        assert counts == {0: 1, 1: 1, 2: 1, 3: 1}


def test_bootstrap_stability_is_deterministic_for_fixed_random_seed(import_or_fail, project_root, tmp_path):
    runner = import_or_fail("app.runner")
    in_csv = project_root / "app" / "data" / "sample_journey_events.csv"
    out1 = runner.run_attribution_comparison(
        str(in_csv), str(tmp_path / "out1"), random_seed=0, n_bootstrap=2, num_permutations=10
    )
    out2 = runner.run_attribution_comparison(
        str(in_csv), str(tmp_path / "out2"), random_seed=0, n_bootstrap=2, num_permutations=10
    )
    p1 = Path(out1["written_files"]["bootstrap_stability.csv"])
    p2 = Path(out2["written_files"]["bootstrap_stability.csv"])
    assert p1.is_file()
    assert p2.is_file()
    df1 = (
        pd.read_csv(p1)
        .sort_values(by=["model", "bootstrap_id"])
        .reset_index(drop=True)
    )
    df2 = (
        pd.read_csv(p2)
        .sort_values(by=["model", "bootstrap_id"])
        .reset_index(drop=True)
    )
    df1 = df1.reindex(sorted(df1.columns.tolist()), axis=1)
    df2 = df2.reindex(sorted(df2.columns.tolist()), axis=1)
    assert df1.to_dict(orient="list") == df2.to_dict(orient="list")


def test_stability_scores_equal_mean_of_per_channel_standard_deviations(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    bootstrap_path = Path(out["written_files"]["bootstrap_stability.csv"])
    assert bootstrap_path.is_file()
    df = pd.read_csv(bootstrap_path)
    channel_cols = [c for c in df.columns if c not in {"model", "bootstrap_id"}]

    observed = out["stability_scores"].astype(float).to_dict()
    for model_name, grp in df.groupby("model", sort=False):
        std_ddof0 = grp[channel_cols].std(axis=0, ddof=0).astype(float).mean()
        std_ddof1 = grp[channel_cols].std(axis=0, ddof=1).astype(float).mean()
        assert float(observed[str(model_name)]) == pytest.approx(float(std_ddof0)) or float(observed[str(model_name)]) == pytest.approx(float(std_ddof1))


def test_runner_is_deterministic_for_fixed_random_seed(import_or_fail, project_root, tmp_path):
    runner = import_or_fail("app.runner")
    in_csv = project_root / "app" / "data" / "sample_journey_events.csv"
    out1 = runner.run_attribution_comparison(
        str(in_csv), str(tmp_path / "out1"), random_seed=0, n_bootstrap=1, num_permutations=10
    )
    out2 = runner.run_attribution_comparison(
        str(in_csv), str(tmp_path / "out2"), random_seed=0, n_bootstrap=1, num_permutations=10
    )
    assert out1["recommended_model"] == out2["recommended_model"]
    df1 = out1["holdout_metrics"].sort_index().reindex(sorted(out1["holdout_metrics"].columns.tolist()), axis=1)
    df2 = out2["holdout_metrics"].sort_index().reindex(sorted(out2["holdout_metrics"].columns.tolist()), axis=1)
    assert df1.to_dict() == df2.to_dict()


def test_bootstrap_stability_csv_has_exactly_model_bootstrap_id_and_channel_columns(import_or_fail, project_root):
    io = import_or_fail("app.io")
    events = io.load_journey_events_csv(str(project_root / "app" / "data" / "sample_journey_events.csv"))
    expected_channels = set(events["channel"].str.strip().unique())
    out = _get_sample_workflow(import_or_fail, project_root)
    df = pd.read_csv(Path(out["written_files"]["bootstrap_stability.csv"]))
    assert set(df.columns) == {"model", "bootstrap_id"} | expected_channels

def test_stability_scores_is_pandas_series_indexed_by_model_names(import_or_fail, project_root):
    out = _get_sample_workflow(import_or_fail, project_root)
    stability = out["stability_scores"]
    assert isinstance(stability, pd.Series)
    assert _REQUIRED_MODELS.issubset(set(stability.index.astype(str).tolist()))