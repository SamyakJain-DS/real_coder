import subprocess
import os
import re
import sys
import pytest
from pathlib import Path
from datetime import date, timedelta

sys.path.insert(0, "/app")

APP_DIR = "/app"
JOURNAL_CLI = os.path.join(APP_DIR, "journal_cli.py")
SAMPLE_JOURNAL = os.path.join(APP_DIR, "journal")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}\.txt$")
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
CYAN, GREEN, YELLOW = 36, 32, 33


def strip_ansi(text):
    return ANSI_RE.sub("", text)


def has_ansi_color(text, color_num):
    pattern = r"\x1b\[(?:[0-9]+;)*" + str(color_num) + r"(?:;[0-9]+)*m"
    return bool(re.search(pattern, text))


def text_before_color(text, color_num, raw_output):
    """Return True if 'text' appears inside (after) an ANSI escape for color_num."""
    pattern = (
        r"\x1b\[(?:[0-9]+;)*"
        + str(color_num)
        + r"(?:;[0-9]+)*m[^\x1b\n]*"
        + re.escape(text)
    )
    return bool(re.search(pattern, raw_output))


def color_after_text(text, color_num, raw_output):
    """Return True if an ANSI escape for color_num appears after 'text' on the same line."""
    pattern = (
        re.escape(text)
        + r"[^\n]*\x1b\[(?:[0-9]+;)*"
        + str(color_num)
        + r"(?:;[0-9]+)*m"
    )
    return bool(re.search(pattern, raw_output))


def run_cli(*args):
    cmd = [sys.executable, JOURNAL_CLI] + list(args)
    return subprocess.run(cmd, capture_output=True, text=True, cwd=APP_DIR)


def make_entry(directory, dt, content):
    (directory / f"{dt.isoformat()}.txt").write_text(content)


def valid_journal_files(journal_dir=SAMPLE_JOURNAL):
    if not os.path.isdir(journal_dir):
        return []
    return [f for f in os.listdir(journal_dir) if DATE_RE.match(f)]


@pytest.fixture
def cli_color_invoke():
    try:
        from journal_cli import cli
        from click.testing import CliRunner
    except Exception:
        yield None
        return
    runner = CliRunner()

    def _invoke(*args):
        return runner.invoke(cli, list(args), color=True)

    yield _invoke


def test_journal_minimum_10_entries():
    files = valid_journal_files()
    assert len(files) >= 10


def test_journal_spans_three_months():
    files = valid_journal_files()
    assert len(files) > 0
    months = {f[:7] for f in files}
    assert len(months) >= 3


def test_journal_has_three_day_streak():
    files = valid_journal_files()
    assert len(files) > 0
    dates = sorted(date.fromisoformat(f.replace(".txt", "")) for f in files)
    max_streak = 1
    current = 1
    for i in range(1, len(dates)):
        if (dates[i] - dates[i - 1]).days == 1:
            current += 1
        else:
            max_streak = max(max_streak, current)
            current = 1
    max_streak = max(max_streak, current)
    assert max_streak >= 3


def test_cli_journal_dir_option_exists():
    result = run_cli("--help")
    assert "--journal-dir" in result.stdout


def test_default_journal_dir_is_used():
    result = run_cli("stats")
    output = strip_ansi(result.stdout)
    assert result.returncode == 0
    match = re.search(r"Total entries:\s*(\d+)", output)
    assert match is not None
    assert int(match.group(1)) >= 10


def test_custom_journal_dir_used_by_subcommand(tmp_path):
    dt = date.today() - timedelta(days=60)
    make_entry(tmp_path, dt, "Custom directory entry content.")
    result = run_cli("--journal-dir", str(tmp_path), "stats")
    output = strip_ansi(result.stdout)
    assert "Total entries: 1" in output


def test_today_shows_entry_when_file_exists(tmp_path):
    today = date.today()
    content = "Today I explored the forest near the lake."
    make_entry(tmp_path, today, content)
    result = run_cli("--journal-dir", str(tmp_path), "today")
    lines = strip_ansi(result.stdout).splitlines()
    assert any(line.strip() == today.isoformat() for line in lines)
    assert content in strip_ansi(result.stdout)


def test_today_shows_message_when_no_file(tmp_path):
    today = date.today()
    result = run_cli("--journal-dir", str(tmp_path), "today")
    output = strip_ansi(result.stdout)
    expected = f"No entry found for today ({today.isoformat()})."
    assert expected in output


def test_random_shows_past_entry(tmp_path):
    past = date.today() - timedelta(days=30)
    content = "Memorable day in the mountains."
    make_entry(tmp_path, past, content)
    result = run_cli("--journal-dir", str(tmp_path), "random")
    lines = strip_ansi(result.stdout).splitlines()
    assert any(line.strip() == past.isoformat() for line in lines)
    assert content in strip_ansi(result.stdout)


def test_random_message_when_no_past_entries(tmp_path):
    result = run_cli("--journal-dir", str(tmp_path), "random")
    output = strip_ansi(result.stdout)
    assert "No past entries found." in output


def test_random_excludes_todays_date(tmp_path):
    today = date.today()
    make_entry(tmp_path, today, "Only today entry exists.")
    result = run_cli("--journal-dir", str(tmp_path), "random")
    output = strip_ansi(result.stdout)
    assert "No past entries found." in output


def test_search_finds_keyword_in_entry(tmp_path):
    dt = date.today() - timedelta(days=15)
    line = "Visited the botanical garden with friends."
    make_entry(tmp_path, dt, line)
    result = run_cli("--journal-dir", str(tmp_path), "search", "botanical")
    output = strip_ansi(result.stdout)
    assert f"{dt.isoformat()}: {line}" in output


def test_search_case_insensitive_matching(tmp_path):
    dt = date.today() - timedelta(days=15)
    line = "Enjoyed WONDERFUL weather all day."
    make_entry(tmp_path, dt, line)
    result = run_cli("--journal-dir", str(tmp_path), "search", "wonderful")
    output = strip_ansi(result.stdout)
    assert dt.isoformat() in output
    assert line in output


def test_search_no_match_message(tmp_path):
    make_entry(tmp_path, date.today() - timedelta(days=5), "Nothing special happened.")
    result = run_cli("--journal-dir", str(tmp_path), "search", "PyThOnIsTa")
    output = strip_ansi(result.stdout)
    assert "No entries found containing 'PyThOnIsTa'." in output


def test_search_multiple_matches_in_one_file(tmp_path):
    dt = date.today() - timedelta(days=10)
    make_entry(
        tmp_path, dt, "Rain in the morning.\nRain in the evening.\nSunny afternoon."
    )
    result = run_cli("--journal-dir", str(tmp_path), "search", "rain")
    output = strip_ansi(result.stdout)
    lines = [l for l in output.strip().splitlines() if dt.isoformat() in l]
    assert len(lines) == 2
    assert "Rain in the morning." in output
    assert "Rain in the evening." in output
    assert output.index("Rain in the morning.") < output.index("Rain in the evening.")


def test_search_results_ordered_by_date_ascending(tmp_path):
    dt_early = date.today() - timedelta(days=40)
    dt_late = date.today() - timedelta(days=10)
    make_entry(tmp_path, dt_early, "Planning the adventure trip.")
    make_entry(tmp_path, dt_late, "Completed the adventure finally.")
    result = run_cli("--journal-dir", str(tmp_path), "search", "adventure")
    output = strip_ansi(result.stdout)
    assert dt_early.isoformat() in output
    assert dt_late.isoformat() in output
    assert output.index(dt_early.isoformat()) < output.index(dt_late.isoformat())


def test_search_requires_keyword_argument(tmp_path):
    make_entry(tmp_path, date.today() - timedelta(days=5), "Some test content here.")
    result_with = run_cli("--journal-dir", str(tmp_path), "search", "content")
    result_without = run_cli("--journal-dir", str(tmp_path), "search")
    assert result_with.returncode == 0
    assert result_without.returncode != 0


def test_search_includes_all_dated_files(tmp_path):
    past = date.today() - timedelta(days=10)
    today = date.today()
    future = date.today() + timedelta(days=10)
    for dt in [past, today, future]:
        make_entry(tmp_path, dt, "Universal topic discussed here.")
    result = run_cli("--journal-dir", str(tmp_path), "search", "universal")
    output = strip_ansi(result.stdout)
    for dt in [past, today, future]:
        assert dt.isoformat() in output


def test_search_excludes_non_matching_lines(tmp_path):
    dt = date.today() - timedelta(days=10)
    make_entry(tmp_path, dt, "Alpha line first.\nBeta line second.\nAlpha line third.")
    result = run_cli("--journal-dir", str(tmp_path), "search", "alpha")
    output = strip_ansi(result.stdout)
    result_lines = [l for l in output.strip().splitlines() if dt.isoformat() in l]
    assert len(result_lines) == 2
    for rl in result_lines:
        assert "alpha" in rl.lower()


def test_stats_total_entries_count(tmp_path):
    for i in range(5):
        make_entry(
            tmp_path, date.today() - timedelta(days=100 + i * 10), f"Entry number {i}."
        )
    result = run_cli("--journal-dir", str(tmp_path), "stats")
    output = strip_ansi(result.stdout)
    assert "Total entries: 5" in output


def test_stats_longest_streak_consecutive_days(tmp_path):
    base = date.today() - timedelta(days=200)
    base = base.replace(day=10)
    for i in range(4):
        make_entry(tmp_path, base + timedelta(days=i), f"Streak day {i}.")
    make_entry(tmp_path, base + timedelta(days=20), "Isolated entry.")
    result = run_cli("--journal-dir", str(tmp_path), "stats")
    output = strip_ansi(result.stdout)
    assert "Longest streak: 4" in output


def test_stats_single_isolated_entry_streak_is_one(tmp_path):
    make_entry(tmp_path, date.today() - timedelta(days=100), "Only one entry.")
    result = run_cli("--journal-dir", str(tmp_path), "stats")
    output = strip_ansi(result.stdout)
    assert "Longest streak: 1" in output


def test_stats_most_active_month_display(tmp_path):
    base = date.today() - timedelta(days=200)
    base = base.replace(day=5)
    for i in range(3):
        make_entry(tmp_path, base + timedelta(days=i), f"Active month entry {i}.")
    other_date = base + timedelta(days=60)
    make_entry(tmp_path, other_date, "Other month single entry.")
    expected_month = base.strftime("%Y-%m")
    result = run_cli("--journal-dir", str(tmp_path), "stats")
    output = strip_ansi(result.stdout)
    assert f"Most active month: {expected_month} (3 entries)" in output


def test_stats_tied_months_earliest_wins(tmp_path):
    yr = date.today().year - 2
    month_a = date(yr, 3, 10)
    month_b = date(yr, 8, 10)
    for i in range(2):
        make_entry(tmp_path, month_a + timedelta(days=i), f"Early month entry {i}.")
        make_entry(tmp_path, month_b + timedelta(days=i), f"Late month entry {i}.")
    expected_month = month_a.strftime("%Y-%m")
    result = run_cli("--journal-dir", str(tmp_path), "stats")
    output = strip_ansi(result.stdout)
    assert f"Most active month: {expected_month} (2 entries)" in output


def test_stats_empty_directory_output(tmp_path):
    result = run_cli("--journal-dir", str(tmp_path), "stats")
    output = strip_ansi(result.stdout)
    assert "Total entries: 0" in output
    assert "Longest streak: 0" in output
    assert "Most active month:" not in output


def test_invalid_filename_files_not_counted(tmp_path):
    make_entry(tmp_path, date.today() - timedelta(days=50), "Valid journal entry.")
    (tmp_path / "notes.txt").write_text("Not a journal.")
    (tmp_path / "todo.md").write_text("Not a journal either.")
    result = run_cli("--journal-dir", str(tmp_path), "stats")
    output = strip_ansi(result.stdout)
    assert "Total entries: 1" in output


def test_directory_with_only_invalid_files(tmp_path):
    (tmp_path / "notes.txt").write_text("Some notes.")
    (tmp_path / "readme.md").write_text("Readme content.")
    result = run_cli("--journal-dir", str(tmp_path), "stats")
    output = strip_ansi(result.stdout)
    assert "Total entries: 0" in output
    assert "Longest streak: 0" in output
    assert "Most active month:" not in output


def test_color_today_date_cyan(tmp_path, cli_color_invoke):
    assert cli_color_invoke is not None, "journal_cli or click not importable"
    today = date.today()
    make_entry(tmp_path, today, "Color check entry.")
    result = cli_color_invoke("--journal-dir", str(tmp_path), "today")
    assert text_before_color(today.isoformat(), CYAN, result.output)


def test_color_random_date_cyan(tmp_path, cli_color_invoke):
    assert cli_color_invoke is not None, "journal_cli or click not importable"
    past = date.today() - timedelta(days=30)
    make_entry(tmp_path, past, "Random color check entry.")
    result = cli_color_invoke("--journal-dir", str(tmp_path), "random")
    assert text_before_color(past.isoformat(), CYAN, result.output)


def test_color_search_date_cyan(tmp_path, cli_color_invoke):
    assert cli_color_invoke is not None, "journal_cli or click not importable"
    dt = date.today() - timedelta(days=15)
    make_entry(tmp_path, dt, "Color search match keyword here.")
    result = cli_color_invoke("--journal-dir", str(tmp_path), "search", "keyword")
    assert text_before_color(dt.isoformat(), CYAN, result.output)


def test_color_stats_labels_green_values_yellow(tmp_path, cli_color_invoke):
    assert cli_color_invoke is not None, "journal_cli or click not importable"
    make_entry(tmp_path, date.today() - timedelta(days=10), "Stats color entry.")
    result = cli_color_invoke("--journal-dir", str(tmp_path), "stats")
    output = result.output
    # Each stat label must be rendered in green
    assert text_before_color("Total entries:", GREEN, output)
    assert text_before_color("Longest streak:", GREEN, output)
    assert text_before_color("Most active month:", GREEN, output)
    # The numeric/value portion (after the label) on the same line must be in yellow
    assert color_after_text("Total entries:", YELLOW, output)
    assert color_after_text("Longest streak:", YELLOW, output)
    assert color_after_text("Most active month:", YELLOW, output)


def test_random_excludes_future_dates(tmp_path):
    future = date.today() + timedelta(days=10)
    make_entry(tmp_path, future, "A future entry that should be ignored.")
    result = run_cli("--journal-dir", str(tmp_path), "random")
    output = strip_ansi(result.stdout)
    assert "No past entries found." in output