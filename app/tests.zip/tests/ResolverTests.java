import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Reflection-based F2P test suite for the Dependency Version Resolver Library.
 * No resolver.* imports are used so this file compiles on an empty codebase.
 * Missing classes are caught via reflection and converted to assertion failures.
 */
class ResolverTests {

    // -- Reflection Infrastructure ---------------------------------------------

    private static Class<?> rClass(String simpleName) {
        try {
            return Class.forName("resolver." + simpleName);
        } catch (ClassNotFoundException e) {
            return fail("Missing class resolver." + simpleName);
        }
    }

    private static Method findMethod(Class<?> cls, String name, int arity) {
        for (Method m : cls.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == arity) return m;
        }
        return fail("No public method '" + name + "' with arity " + arity
                    + " on " + cls.getName());
    }

    private static Constructor<?> findConstructor(Class<?> cls, int arity) {
        for (Constructor<?> c : cls.getConstructors()) {
            if (c.getParameterCount() == arity) return c;
        }
        return fail("No public constructor with arity " + arity
                    + " on " + cls.getName());
    }

    @SuppressWarnings("unchecked")
    private static <T extends Throwable> void sneakyThrow(Throwable t) throws T {
        throw (T) (t != null ? t : new RuntimeException("null cause"));
    }

    @SuppressWarnings("unchecked")
    private static <T> T callStatic(String cls, String method, Object... args) {
        try {
            Class<?> c = rClass(cls);
            Method m = findMethod(c, method, args.length);
            return (T) m.invoke(null, args);
        } catch (InvocationTargetException e) {
            sneakyThrow(e.getCause() != null ? e.getCause() : e);
            return null;
        } catch (AssertionError e) {
            throw e;
        } catch (Exception e) {
            return fail("Static call failed: " + cls + "." + method + " - " + e);
        }
    }

    @SuppressWarnings("unchecked")
    private static <T> T callMethod(Object obj, String method, Object... args) {
        try {
            Method m = findMethod(obj.getClass(), method, args.length);
            return (T) m.invoke(obj, args);
        } catch (InvocationTargetException e) {
            sneakyThrow(e.getCause() != null ? e.getCause() : e);
            return null;
        } catch (AssertionError e) {
            throw e;
        } catch (Exception e) {
            return fail("Method call failed: " + obj.getClass().getSimpleName()
                        + "." + method + " - " + e);
        }
    }

    private static Object construct(String cls, Object... args) {
        try {
            Class<?> c = rClass(cls);
            Constructor<?> ctor = findConstructor(c, args.length);
            return ctor.newInstance(args);
        } catch (InvocationTargetException e) {
            sneakyThrow(e.getCause() != null ? e.getCause() : e);
            return null;
        } catch (AssertionError e) {
            throw e;
        } catch (Exception e) {
            return fail("Construction failed: resolver." + cls + " - " + e);
        }
    }

    // -- Test Lifecycle --------------------------------------------------------

    private Path tempDir;
    private int fileCounter = 0;

    @BeforeEach
    void setUp() throws IOException {
        tempDir = Files.createTempDirectory("resolver-test-");
        fileCounter = 0;
    }

    @AfterEach
    void tearDown() throws IOException {
        Files.walk(tempDir)
             .sorted(Comparator.reverseOrder())
             .map(Path::toFile)
             .forEach(File::delete);
    }

    // -- Domain Helpers --------------------------------------------------------

    private Path writeJson(String json) throws IOException {
        Path f = tempDir.resolve("reg" + fileCounter++ + ".json");
        Files.writeString(f, json);
        return f;
    }

    private Object registry(String json) throws IOException {
        return callStatic("PackageRegistry", "load", writeJson(json).toString());
    }

    private Object req(String name, String constraint) {
        return construct("Requirement", name, constraint);
    }

    private Object resolve(Object reg, Object... requirements) {
        Object resolver = construct("DependencyResolver", reg);
        return callMethod(resolver, "resolve", List.of(requirements));
    }

    // -- Shared Fixture JSON ---------------------------------------------------

    // root-pkg@1.0.0 depends on dep-pkg ^2.0.0; dep-pkg@2.0.0 has no deps
    private static final String SUCCESS_JSON = """
        {"packages":[
          {"name":"root-pkg","version":"1.0.0","dependencies":[
            {"name":"dep-pkg","constraint":"^2.0.0"}
          ]},
          {"name":"dep-pkg","version":"2.0.0","dependencies":[]}
        ]}
        """;

    // pkg-b needs pkg-x >=2.0.0; pkg-c needs pkg-x <2.0.0 - irreconcilable
    private static final String CONFLICT_JSON = """
        {"packages":[
          {"name":"pkg-x","version":"1.0.0","dependencies":[]},
          {"name":"pkg-x","version":"2.0.0","dependencies":[]},
          {"name":"pkg-b","version":"1.0.0","dependencies":[
            {"name":"pkg-x","constraint":">=2.0.0"}
          ]},
          {"name":"pkg-c","version":"1.0.0","dependencies":[
            {"name":"pkg-x","constraint":"<2.0.0"}
          ]}
        ]}
        """;

    // root-pkg -> dep-pkg -> sub-pkg (three levels)
    private static final String TREE_JSON = """
        {"packages":[
          {"name":"root-pkg","version":"1.0.0","dependencies":[
            {"name":"dep-pkg","constraint":"1.0.0"}
          ]},
          {"name":"dep-pkg","version":"1.0.0","dependencies":[
            {"name":"sub-pkg","constraint":"1.0.0"}
          ]},
          {"name":"sub-pkg","version":"1.0.0","dependencies":[]}
        ]}
        """;

    // =========================================================================
    // PackageRegistry Tests
    // =========================================================================

    @Test
    void registry_load_throws_ioexception_for_missing_file() {
        assertThrows(IOException.class, () ->
            callStatic("PackageRegistry", "load",
                       tempDir.resolve("missing.json").toString()));
    }

    @Test
    void registry_load_throws_illegalargumentexception_for_malformed_json()
            throws IOException {
        Path f = writeJson("not valid json at all");
        assertThrows(IllegalArgumentException.class, () ->
            callStatic("PackageRegistry", "load", f.toString()));
    }

    @Test
    void registry_getVersions_returns_versions_in_descending_order() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.0.0","dependencies":[]},
              {"name":"a","version":"3.0.0","dependencies":[]},
              {"name":"a","version":"2.0.0","dependencies":[]}
            ]}
            """);
        List<?> versions = callMethod(reg, "getVersions", "a");
        assertEquals(3, versions.size());
        assertEquals("3.0.0", callMethod(versions.get(0), "getVersion"));
        assertEquals("2.0.0", callMethod(versions.get(1), "getVersion"));
        assertEquals("1.0.0", callMethod(versions.get(2), "getVersion"));
    }

    @Test
    void registry_getVersions_returns_empty_list_for_unknown_package() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"1.0.0\",\"dependencies\":[]}]}"
        );
        List<?> result = callMethod(reg, "getVersions", "nonexistent");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void registry_getVersions_returns_only_versions_for_the_named_package()
            throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.0.0","dependencies":[]},
              {"name":"b","version":"2.0.0","dependencies":[]}
            ]}
            """);
        List<?> versions = callMethod(reg, "getVersions", "a");
        assertEquals(1, versions.size());
        assertEquals("a", callMethod(versions.get(0), "getName"));
    }

    // =========================================================================
    // Requirement Tests
    // =========================================================================

    @Test
    void requirement_getPackageName_returns_name_from_constructor() {
        Object r = req("my-pkg", "^1.0.0");
        assertEquals("my-pkg", callMethod(r, "getPackageName"));
    }

    @Test
    void requirement_getConstraint_returns_constraint_from_constructor() {
        Object r = req("pkg", "~2.3.4");
        assertEquals("~2.3.4", callMethod(r, "getConstraint"));
    }

    // =========================================================================
    // PackageVersion Tests
    // =========================================================================

    @Test
    void packageVersion_getName_returns_package_name() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"lib-xyz\",\"version\":\"1.2.3\",\"dependencies\":[]}]}"
        );
        List<?> versions = callMethod(reg, "getVersions", "lib-xyz");
        assertEquals("lib-xyz", callMethod(versions.get(0), "getName"));
    }

    @Test
    void packageVersion_getVersion_returns_version_string() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"1.2.3\",\"dependencies\":[]}]}"
        );
        List<?> versions = callMethod(reg, "getVersions", "a");
        assertEquals("1.2.3", callMethod(versions.get(0), "getVersion"));
    }

    @Test
    void packageVersion_getDependencies_returns_declared_dependencies() throws IOException {
        Object reg = registry("""
            {"packages":[{"name":"a","version":"1.0.0","dependencies":[
              {"name":"b","constraint":"^1.0.0"}
            ]}]}
            """);
        List<?> deps = callMethod(
            ((List<?>) callMethod(reg, "getVersions", "a")).get(0),
            "getDependencies");
        assertEquals(1, deps.size());
        assertEquals("b",      callMethod(deps.get(0), "getPackageName"));
        assertEquals("^1.0.0", callMethod(deps.get(0), "getConstraint"));
    }

    @Test
    void packageVersion_getDependencies_returns_empty_list_when_no_deps() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"1.0.0\",\"dependencies\":[]}]}"
        );
        List<?> deps = callMethod(
            ((List<?>) callMethod(reg, "getVersions", "a")).get(0),
            "getDependencies");
        assertTrue(deps.isEmpty());
    }

    // =========================================================================
    // DependencyResolver - Basic Resolution
    // =========================================================================

    @Test
    void resolve_single_package_no_deps_succeeds() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"1.0.0\",\"dependencies\":[]}]}"
        );
        Object result = resolve(reg, req("a", "1.0.0"));
        assertTrue(callMethod(result, "isSuccess"));
        assertEquals("1.0.0",
            ((Map<?, ?>) callMethod(result, "getResolvedVersions")).get("a"));
    }

    @Test
    void resolve_includes_transitive_dependencies_in_result() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.0.0","dependencies":[{"name":"b","constraint":"1.0.0"}]},
              {"name":"b","version":"1.0.0","dependencies":[]}
            ]}
            """);
        Object result = resolve(reg, req("a", "1.0.0"));
        assertTrue(callMethod(result, "isSuccess"));
        assertTrue(((Map<?, ?>) callMethod(result, "getResolvedVersions")).containsKey("b"));
    }

    @Test
    void resolve_selects_newest_valid_version_among_candidates() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.0.0","dependencies":[]},
              {"name":"a","version":"2.0.0","dependencies":[]},
              {"name":"a","version":"3.0.0","dependencies":[]}
            ]}
            """);
        Object result = resolve(reg, req("a", ">=1.0.0"));
        assertTrue(callMethod(result, "isSuccess"));
        assertEquals("3.0.0",
            ((Map<?, ?>) callMethod(result, "getResolvedVersions")).get("a"));
    }

    @Test
    void resolve_fails_when_required_package_absent_from_registry() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"1.0.0\",\"dependencies\":[]}]}"
        );
        assertFalse(callMethod(resolve(reg, req("nonexistent", "1.0.0")), "isSuccess"));
    }

    // =========================================================================
    // Version Constraint Types
    // =========================================================================

    @Test
    void exact_constraint_selects_only_matching_version() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.0.0","dependencies":[]},
              {"name":"a","version":"2.0.0","dependencies":[]}
            ]}
            """);
        Object result = resolve(reg, req("a", "1.0.0"));
        assertTrue(callMethod(result, "isSuccess"));
        assertEquals("1.0.0",
            ((Map<?, ?>) callMethod(result, "getResolvedVersions")).get("a"));
    }

    @Test
    void exact_constraint_fails_when_version_absent_from_registry() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"2.0.0\",\"dependencies\":[]}]}"
        );
        assertFalse(callMethod(resolve(reg, req("a", "1.0.0")), "isSuccess"));
    }

    @Test
    void gte_constraint_excludes_versions_below_minimum() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"0.9.0","dependencies":[]},
              {"name":"a","version":"1.2.0","dependencies":[]},
              {"name":"a","version":"2.0.0","dependencies":[]}
            ]}
            """);
        Object result = resolve(reg, req("a", ">=1.2.0"));
        assertTrue(callMethod(result, "isSuccess"));
        assertNotEquals("0.9.0",
            ((Map<?, ?>) callMethod(result, "getResolvedVersions")).get("a"));
    }

    @Test
    void lt_constraint_excludes_version_at_the_boundary() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.0.0","dependencies":[]},
              {"name":"a","version":"2.0.0","dependencies":[]}
            ]}
            """);
        Object result = resolve(reg, req("a", "<2.0.0"));
        assertTrue(callMethod(result, "isSuccess"));
        assertEquals("1.0.0",
            ((Map<?, ?>) callMethod(result, "getResolvedVersions")).get("a"));
    }

    @Test
    void lt_constraint_fails_when_only_available_version_is_at_boundary() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"2.0.0\",\"dependencies\":[]}]}"
        );
        assertFalse(callMethod(resolve(reg, req("a", "<2.0.0")), "isSuccess"));
    }

    @Test
    void caret_constraint_rejects_next_major_version() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.2.3","dependencies":[]},
              {"name":"a","version":"1.9.0","dependencies":[]},
              {"name":"a","version":"2.0.0","dependencies":[]}
            ]}
            """);
        Object result = resolve(reg, req("a", "^1.2.3"));
        assertTrue(callMethod(result, "isSuccess"));
        assertNotEquals("2.0.0",
            ((Map<?, ?>) callMethod(result, "getResolvedVersions")).get("a"));
    }

    @Test
    void caret_constraint_fails_when_only_version_is_below_minimum() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"1.2.2\",\"dependencies\":[]}]}"
        );
        assertFalse(callMethod(resolve(reg, req("a", "^1.2.3")), "isSuccess"));
    }

    @Test
    void tilde_constraint_rejects_next_minor_version() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.2.3","dependencies":[]},
              {"name":"a","version":"1.2.9","dependencies":[]},
              {"name":"a","version":"1.3.0","dependencies":[]}
            ]}
            """);
        Object result = resolve(reg, req("a", "~1.2.3"));
        assertTrue(callMethod(result, "isSuccess"));
        assertNotEquals("1.3.0",
            ((Map<?, ?>) callMethod(result, "getResolvedVersions")).get("a"));
    }

    @Test
    void tilde_constraint_fails_when_only_version_is_below_minimum() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"1.2.2\",\"dependencies\":[]}]}"
        );
        assertFalse(callMethod(resolve(reg, req("a", "~1.2.3")), "isSuccess"));
    }

    @Test
    void wildcard_constraint_selects_only_matching_major_minor() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.2.0","dependencies":[]},
              {"name":"a","version":"1.2.5","dependencies":[]},
              {"name":"a","version":"1.3.0","dependencies":[]}
            ]}
            """);
        Object result = resolve(reg, req("a", "1.2.*"));
        assertTrue(callMethod(result, "isSuccess"));
        String selected = (String)
            ((Map<?, ?>) callMethod(result, "getResolvedVersions")).get("a");
        assertTrue(selected.startsWith("1.2."),
            "Expected selected version to start with 1.2. but was: " + selected);
    }

    @Test
    void wildcard_constraint_fails_when_no_version_matches_major_minor() throws IOException {
        Object reg = registry(
            "{\"packages\":[{\"name\":\"a\",\"version\":\"1.3.0\",\"dependencies\":[]}]}"
        );
        assertFalse(callMethod(resolve(reg, req("a", "1.2.*")), "isSuccess"));
    }

    // =========================================================================
    // Conflict Detection and Backtracking
    // =========================================================================

    @Test
    void resolve_fails_when_two_packages_impose_incompatible_constraints_on_shared_dep()
            throws IOException {
        Object reg = registry(CONFLICT_JSON);
        Object result = resolve(reg, req("pkg-b", "1.0.0"), req("pkg-c", "1.0.0"));
        assertFalse(callMethod(result, "isSuccess"));
    }

    @Test
    void resolve_backtracks_to_find_compatible_assignment() throws IOException {
        // pkg-b@2.0.0 needs pkg-a >=2.0.0, but pkg-c needs pkg-a <2.0.0 AND pkg-b.
        // Resolver must backtrack from pkg-b@2.0.0 to pkg-b@1.0.0.
        Object reg = registry("""
            {"packages":[
              {"name":"pkg-a","version":"1.0.0","dependencies":[]},
              {"name":"pkg-a","version":"2.0.0","dependencies":[]},
              {"name":"pkg-b","version":"1.0.0","dependencies":[]},
              {"name":"pkg-b","version":"2.0.0","dependencies":[
                {"name":"pkg-a","constraint":">=2.0.0"}
              ]},
              {"name":"pkg-c","version":"1.0.0","dependencies":[
                {"name":"pkg-a","constraint":"<2.0.0"},
                {"name":"pkg-b","constraint":"^1.0.0"}
              ]}
            ]}
            """);
        Object result = resolve(reg, req("pkg-c", "1.0.0"));
        assertTrue(callMethod(result, "isSuccess"));
        Map<?, ?> resolved = callMethod(result, "getResolvedVersions");
        assertEquals("1.0.0", resolved.get("pkg-a"));
        assertEquals("1.0.0", resolved.get("pkg-b"));
    }

    // =========================================================================
    // ResolvedResult Tests
    // =========================================================================

    @Test
    void isSuccess_returns_true_when_compatible_assignment_found() throws IOException {
        assertTrue(callMethod(
            resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0")),
            "isSuccess"));
    }

    @Test
    void getResolvedVersions_contains_root_and_transitive_packages() throws IOException {
        Map<?, ?> versions = callMethod(
            resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0")),
            "getResolvedVersions");
        assertTrue(versions.containsKey("root-pkg"));
        assertTrue(versions.containsKey("dep-pkg"));
    }

    @Test
    void getResolvedVersions_maps_packages_to_correct_version_strings() throws IOException {
        Map<?, ?> versions = callMethod(
            resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0")),
            "getResolvedVersions");
        assertEquals("1.0.0", versions.get("root-pkg"));
        assertEquals("2.0.0", versions.get("dep-pkg"));
    }

    @Test
    void getErrorMessage_contains_the_name_of_the_conflicting_dependency() throws IOException {
        Object result = resolve(registry(CONFLICT_JSON),
            req("pkg-b", "1.0.0"), req("pkg-c", "1.0.0"));
        assertTrue(((String) callMethod(result, "getErrorMessage")).contains("pkg-x"));
    }

    @Test
    void getErrorMessage_contains_names_of_both_imposing_packages() throws IOException {
        Object result = resolve(registry(CONFLICT_JSON),
            req("pkg-b", "1.0.0"), req("pkg-c", "1.0.0"));
        String msg = callMethod(result, "getErrorMessage");
        assertTrue(msg.contains("pkg-b") && msg.contains("pkg-c"));
    }

    @Test
    void getErrorMessage_contains_both_conflicting_constraint_strings()
            throws IOException {
        Object result = resolve(registry(CONFLICT_JSON),
            req("pkg-b", "1.0.0"), req("pkg-c", "1.0.0"));
        String msg = callMethod(result, "getErrorMessage");
        assertTrue(msg.contains(">=2.0.0") && msg.contains("<2.0.0"));
    }

    @Test
    void getRootPackageNames_contains_root_packages_only() throws IOException {
        Object result = resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0"));
        List<?> roots = callMethod(result, "getRootPackageNames");
        assertTrue(roots.contains("root-pkg"));
        assertFalse(roots.contains("dep-pkg"));
    }

    @Test
    void getRootPackageNames_preserves_input_order() throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"z","version":"1.0.0","dependencies":[]},
              {"name":"a","version":"1.0.0","dependencies":[]},
              {"name":"m","version":"1.0.0","dependencies":[]}
            ]}
            """);
        Object result = resolve(reg, req("z", "1.0.0"), req("a", "1.0.0"), req("m", "1.0.0"));
        assertTrue(callMethod(result, "isSuccess"));
        List<?> roots = callMethod(result, "getRootPackageNames");
        assertEquals("z", roots.get(0));
        assertEquals("a", roots.get(1));
        assertEquals("m", roots.get(2));
    }

    private static final Pattern CHAIN_ELEMENT_PATTERN =
        Pattern.compile("^(.+@\\S+|root) requires \\S+ \\S+$");

    @Test
    void getConstraintChain_each_element_matches_the_specified_format() throws IOException {
        Object result = resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0"));
        List<?> chain = callMethod(result, "getConstraintChain", "dep-pkg");
        for (Object element : chain) {
            assertTrue(CHAIN_ELEMENT_PATTERN.matcher(element.toString()).matches(),
                "Element did not match required format: " + element);
        }
    }

    @Test
    void getConstraintChain_uses_root_prefix_for_a_root_required_package() throws IOException {
        Object result = resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0"));
        List<?> chain = callMethod(result, "getConstraintChain", "root-pkg");
        assertTrue(chain.stream().anyMatch(e -> e.toString().startsWith("root requires")));
    }

    @Test
    void getConstraintChain_uses_imposer_at_version_format_for_transitive_package()
            throws IOException {
        Object result = resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0"));
        List<?> chain = callMethod(result, "getConstraintChain", "dep-pkg");
        assertTrue(chain.stream()
            .anyMatch(e -> e.toString().startsWith("root-pkg@1.0.0 requires dep-pkg")));
    }

    @Test
    void getConstraintChain_throws_illegalargumentexception_for_unknown_package()
            throws IOException {
        Object result = resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0"));
        assertThrows(IllegalArgumentException.class, () ->
            callMethod(result, "getConstraintChain", "package-not-in-result"));
    }

    // =========================================================================
    // LockFile Tests
    // =========================================================================

    @Test
    void lockFile_write_creates_file_at_the_given_output_path() throws IOException {
        Path out = tempDir.resolve("lock.json");
        callStatic("LockFile", "write", Map.of("a", "1.0.0"), out.toString());
        assertTrue(Files.exists(out));
    }

    @Test
    void lockFile_write_creates_missing_parent_directories() throws IOException {
        Path out = tempDir.resolve("nested/deep/lock.json");
        callStatic("LockFile", "write", Map.of("a", "1.0.0"), out.toString());
        assertTrue(Files.exists(out));
    }

    @Test
    void lockFile_read_after_write_returns_identical_map() throws IOException {
        Path out = tempDir.resolve("lock.json");
        Map<String, String> original = new LinkedHashMap<>();
        original.put("pkg-a", "1.2.3");
        original.put("pkg-b", "4.5.6");
        callStatic("LockFile", "write", original, out.toString());
        assertEquals(original, callStatic("LockFile", "read", out.toString()));
    }

    @Test
    void lockFile_read_throws_ioexception_for_missing_file() {
        assertThrows(IOException.class, () ->
            callStatic("LockFile", "read",
                       tempDir.resolve("missing.json").toString()));
    }

    @Test
    void lockFile_read_throws_illegalargumentexception_for_malformed_json() throws IOException {
        Path f = tempDir.resolve("bad.json");
        Files.writeString(f, "not valid json");
        assertThrows(IllegalArgumentException.class, () ->
            callStatic("LockFile", "read", f.toString()));
    }

    @Test
    void lockFile_write_throws_ioexception_when_parent_path_is_not_a_directory()
            throws IOException {
        // A regular file occupying the slot where a parent directory must exist
        // causes createDirectories to throw NotDirectoryException (subclass of IOException)
        // regardless of whether the process runs as root
        Path blocker = tempDir.resolve("blocker");
        Files.writeString(blocker, "block");
        Path out = blocker.resolve("lock.json");
        assertThrows(IOException.class, () ->
            callStatic("LockFile", "write", Map.of("a", "1.0.0"), out.toString()));
    }

    // =========================================================================
    // DependencyTreePrinter Tests
    // =========================================================================

    @Test
    void treePrinter_output_contains_all_packages_in_name_at_version_format()
            throws IOException {
        Object reg = registry(TREE_JSON);
        Object result = resolve(reg, req("root-pkg", "1.0.0"));
        String output = callStatic("DependencyTreePrinter", "print", result, reg);
        assertTrue(output.contains("root-pkg@1.0.0"));
        assertTrue(output.contains("dep-pkg@1.0.0"));
        assertTrue(output.contains("sub-pkg@1.0.0"));
    }

    @Test
    void treePrinter_root_package_appears_with_zero_leading_spaces() throws IOException {
        Object reg = registry(TREE_JSON);
        Object result = resolve(reg, req("root-pkg", "1.0.0"));
        String output = callStatic("DependencyTreePrinter", "print", result, reg);
        List<String> lines = Arrays.asList(output.split("\\R"));
        assertTrue(lines.stream().anyMatch(l -> l.equals("root-pkg@1.0.0")));
    }

    @Test
    void treePrinter_direct_dependency_has_exactly_two_leading_spaces() throws IOException {
        Object reg = registry(TREE_JSON);
        Object result = resolve(reg, req("root-pkg", "1.0.0"));
        String output = callStatic("DependencyTreePrinter", "print", result, reg);
        List<String> lines = Arrays.asList(output.split("\\R"));
        assertTrue(lines.stream().anyMatch(l -> l.equals("  dep-pkg@1.0.0")));
    }

    @Test
    void treePrinter_transitive_dependency_has_exactly_four_leading_spaces()
            throws IOException {
        Object reg = registry(TREE_JSON);
        Object result = resolve(reg, req("root-pkg", "1.0.0"));
        String output = callStatic("DependencyTreePrinter", "print", result, reg);
        List<String> lines = Arrays.asList(output.split("\\R"));
        assertTrue(lines.stream().anyMatch(l -> l.equals("    sub-pkg@1.0.0")));
    }

    @Test
    void treePrinter_throws_illegalargumentexception_when_result_is_failure()
            throws IOException {
        Object reg = registry("""
            {"packages":[
              {"name":"a","version":"1.0.0","dependencies":[{"name":"b","constraint":">=2.0.0"}]},
              {"name":"b","version":"1.0.0","dependencies":[]}
            ]}
            """);
        Object failed = resolve(reg, req("a", "1.0.0"));
        assertFalse(callMethod(failed, "isSuccess"));
        assertThrows(IllegalArgumentException.class, () ->
            callStatic("DependencyTreePrinter", "print", failed, reg));
    }

    // =========================================================================
    // WhyExplainer Tests
    // =========================================================================

    private static final Pattern WHY_LINE_PATTERN =
        Pattern.compile("^(.+@\\S+|root) requires \\S+ \\S+$");

    @Test
    void whyExplainer_each_line_matches_the_specified_format() throws IOException {
        Object result = resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0"));
        String explanation = callStatic("WhyExplainer", "explain", "dep-pkg", result);
        for (String line : explanation.split("\\R")) {
            if (!line.isBlank()) {
                assertTrue(WHY_LINE_PATTERN.matcher(line).matches(),
                    "Line did not match required format: " + line);
            }
        }
    }

    @Test
    void whyExplainer_uses_root_prefix_for_a_directly_root_required_package()
            throws IOException {
        Object result = resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0"));
        String explanation = callStatic("WhyExplainer", "explain", "root-pkg", result);
        assertTrue(explanation.contains("root requires root-pkg"));
    }

    @Test
    void whyExplainer_uses_imposer_at_version_format_for_transitive_package()
            throws IOException {
        Object result = resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0"));
        String explanation = callStatic("WhyExplainer", "explain", "dep-pkg", result);
        assertTrue(explanation.contains("root-pkg@1.0.0 requires dep-pkg"));
    }

    @Test
    void whyExplainer_throws_illegalargumentexception_for_package_not_in_result()
            throws IOException {
        Object result = resolve(registry(SUCCESS_JSON), req("root-pkg", "1.0.0"));
        assertThrows(IllegalArgumentException.class, () ->
            callStatic("WhyExplainer", "explain", "not-resolved", result));
    }

    // =========================================================================
    // Performance Test
    // =========================================================================

    @Test
    @Timeout(10)
    void resolve_completes_within_5_seconds_for_200_packages_with_20_versions_each()
            throws IOException {
        StringBuilder sb = new StringBuilder("{\"packages\":[");
        boolean first = true;
        for (int pkg = 0; pkg < 200; pkg++) {
            for (int v = 1; v <= 20; v++) {
                if (!first) sb.append(",");
                sb.append(String.format(
                    "{\"name\":\"pkg-%d\",\"version\":\"%d.0.0\",\"dependencies\":[]}",
                    pkg, v));
                first = false;
            }
        }
        sb.append("]}");

        Object reg = registry(sb.toString());
        List<Object> roots = new ArrayList<>();
        for (int i = 0; i < 200; i++) roots.add(req("pkg-" + i, ">=1.0.0"));

        Object resolver = construct("DependencyResolver", reg);
        long start = System.currentTimeMillis();
        Object result = callMethod(resolver, "resolve", roots);
        long elapsed = System.currentTimeMillis() - start;

        assertTrue(callMethod(result, "isSuccess"));
        assertTrue(elapsed < 5000,
            "Resolution took " + elapsed + "ms, expected under 5000ms");
    }

    // =========================================================================
    // Bundled Registry Tests
    // =========================================================================

    @Test
    void bundled_registry_is_loadable_by_PackageRegistry_load() throws IOException {
        Object reg = callStatic("PackageRegistry", "load", "data/registry.json");
        assertNotNull(reg,
            "PackageRegistry.load must return a non-null instance for data/registry.json");
    }

    @Test
    void bundled_registry_contains_multiple_packages_each_with_multiple_versions()
            throws IOException {
        // Discover package names from the file without asserting on raw JSON counts
        JsonNode packages = new ObjectMapper()
            .readTree(Path.of("data/registry.json").toFile())
            .get("packages");
        assertNotNull(packages, "Registry JSON must contain a 'packages' array");

        Set<String> names = new LinkedHashSet<>();
        for (JsonNode entry : packages) {
            names.add(entry.get("name").asText());
        }

        // Now verify through the library - a broken load or getVersions fails here
        Object reg = callStatic("PackageRegistry", "load", "data/registry.json");
        assertNotNull(reg);

        int packagesWithMultipleVersions = 0;
        int packagesFound = 0;
        for (String name : names) {
            List<?> versions = callMethod(reg, "getVersions", name);
            if (versions != null && !versions.isEmpty()) {
                packagesFound++;
            }
            if (versions != null && versions.size() >= 2) {
                packagesWithMultipleVersions++;
            }
        }

        assertTrue(packagesFound >= 2,
            "PackageRegistry must expose at least 2 distinct packages from data/registry.json");
        assertTrue(packagesWithMultipleVersions >= 2,
            "At least 2 packages must each have 2 or more versions per PackageRegistry.getVersions");
    }

    @Test
    void bundled_registry_exercises_all_six_constraint_types() throws IOException {
        JsonNode packages = new ObjectMapper()
            .readTree(Path.of("data/registry.json").toFile())
            .get("packages");

        List<String> constraints = new ArrayList<>();
        for (JsonNode entry : packages) {
            JsonNode deps = entry.get("dependencies");
            if (deps != null && deps.isArray()) {
                for (JsonNode dep : deps) {
                    JsonNode c = dep.get("constraint");
                    if (c != null) constraints.add(c.asText());
                }
            }
        }

        assertTrue(constraints.stream().anyMatch(c -> c.matches("\\d+\\.\\d+\\.\\d+")),
            "Registry must contain at least one exact version constraint");
        assertTrue(constraints.stream().anyMatch(c -> c.startsWith(">=")),
            "Registry must contain at least one >= constraint");
        assertTrue(constraints.stream()
            .anyMatch(c -> c.startsWith("<") && !c.startsWith("<=")),
            "Registry must contain at least one < constraint");
        assertTrue(constraints.stream().anyMatch(c -> c.startsWith("^")),
            "Registry must contain at least one caret constraint");
        assertTrue(constraints.stream().anyMatch(c -> c.startsWith("~")),
            "Registry must contain at least one tilde constraint");
        assertTrue(constraints.stream().anyMatch(c -> c.contains(".*")),
            "Registry must contain at least one wildcard constraint");
    }
}