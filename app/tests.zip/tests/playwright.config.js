/** @type {import('@playwright/test').PlaywrightTestConfig} */
module.exports = {
  testDir: '.',
  timeout: 15000,
  workers: 4,
  use: {
    baseURL: 'http://localhost:4173',
  },
};