/** @type {import('@playwright/test').PlaywrightTestConfig} */
module.exports = {
  testDir: '.',
  timeout: 10000,
  workers: 4,
  use: {
    baseURL: 'http://localhost:4173',
    navigationTimeout: 5000,
    actionTimeout: 5000,
  },
};