"""
Tests for Billing & Reconciliation endpoints.
Covers: add_charge, add_credit, reconcile_commission.
"""


class TestAddCharge:
    def test_add_charge_response_fields(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.post(
            f"/commissions/{cid}/charges",
            json={"amount": 75.0, "reason": "Extra tuning session"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["commission_id"] == cid
        assert data["amount"] == 75.0
        assert data["reason"] == "Extra tuning session"

    def test_add_charge_nonexistent_commission_returns_404(self, client, created_commission):
        cid = created_commission["id"]
        valid_resp = client.post(
            f"/commissions/{cid}/charges",
            json={"amount": 50.0, "reason": "Some charge"},
        )
        assert valid_resp.status_code == 201, "Route must exist for valid IDs"
        resp = client.post(
            "/commissions/99999/charges",
            json={"amount": 50.0, "reason": "Some charge"},
        )
        assert resp.status_code == 404
        assert resp.json().get("detail")


class TestAddCredit:
    def test_add_credit_response_fields(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.post(
            f"/commissions/{cid}/credits",
            json={"amount": 40.0, "reason": "Referral bonus"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["commission_id"] == cid
        assert data["amount"] == 40.0
        assert data["reason"] == "Referral bonus"

    def test_add_credit_nonexistent_commission_returns_404(self, client, created_commission):
        cid = created_commission["id"]
        valid_resp = client.post(
            f"/commissions/{cid}/credits",
            json={"amount": 25.0, "reason": "Some credit"},
        )
        assert valid_resp.status_code == 201, "Route must exist for valid IDs"
        resp = client.post(
            "/commissions/99999/credits",
            json={"amount": 25.0, "reason": "Some credit"},
        )
        assert resp.status_code == 404
        assert resp.json().get("detail")


class TestReconcileCommission:
    def test_reconcile_response_fields(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.get(f"/commissions/{cid}/reconcile")
        assert resp.status_code == 200
        data = resp.json()
        assert "commission_id" in data
        assert "quoted_total" in data
        assert "deposit_paid" in data
        assert "total_additional_charges" in data
        assert "total_credits" in data
        assert "final_balance_owed" in data
        assert "status" in data

    def test_reconcile_underpaid_status(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.get(f"/commissions/{cid}/reconcile")
        data = resp.json()
        assert data["final_balance_owed"] > 0
        assert data["status"] == "underpaid"

    def test_reconcile_balanced_status(self, client):
        payload = {
            "customer_name": "Matt Molloy",
            "instrument_type": "flute",
            "material": "Boxwood",
            "pitch_reference": "A=440Hz",
            "target_key": "D",
            "bore_taper": "straight",
            "quoted_total": 500.0,
            "deposit_amount": 500.0,
        }
        comm_resp = client.post("/commissions", json=payload)
        cid = comm_resp.json().get("id", 0)
        resp = client.get(f"/commissions/{cid}/reconcile")
        data = resp.json()
        assert data["final_balance_owed"] == 0
        assert data["status"] == "balanced"

    def test_reconcile_overpaid_status(self, client):
        payload = {
            "customer_name": "Mary Bergin",
            "instrument_type": "whistle",
            "material": "tin",
            "pitch_reference": "A=440Hz",
            "target_key": "D",
            "bore_taper": "straight",
            "quoted_total": 200.0,
            "deposit_amount": 200.0,
        }
        comm_resp = client.post("/commissions", json=payload)
        cid = comm_resp.json().get("id", 0)
        client.post(
            f"/commissions/{cid}/credits",
            json={"amount": 30.0, "reason": "Goodwill credit"},
        )
        resp = client.get(f"/commissions/{cid}/reconcile")
        data = resp.json()
        assert data["final_balance_owed"] < 0
        assert data["status"] == "overpaid"

    def test_reconcile_formula_with_charges_and_credits(self, client):
        payload = {
            "customer_name": "Joanie Madden",
            "instrument_type": "flute",
            "material": "Grenadilla",
            "pitch_reference": "A=442Hz",
            "target_key": "C",
            "bore_taper": "conical-steep",
            "quoted_total": 1000.0,
            "deposit_amount": 200.0,
        }
        comm_resp = client.post("/commissions", json=payload)
        cid = comm_resp.json().get("id", 0)

        client.post(f"/commissions/{cid}/charges", json={"amount": 100.0, "reason": "Rush fee"})
        client.post(f"/commissions/{cid}/charges", json={"amount": 50.0, "reason": "Material upgrade"})
        client.post(f"/commissions/{cid}/credits", json={"amount": 75.0, "reason": "Early bird discount"})
        client.post(f"/commissions/{cid}/credits", json={"amount": 25.0, "reason": "Referral bonus"})

        resp = client.get(f"/commissions/{cid}/reconcile")
        data = resp.json()

        expected_balance = round(1000.0 + (100.0 + 50.0) - 200.0 - (75.0 + 25.0), 2)
        assert data["final_balance_owed"] == expected_balance
        assert data["total_additional_charges"] == 150.0
        assert data["total_credits"] == 100.0
        assert data["quoted_total"] == 1000.0
        assert data["deposit_paid"] == 200.0

    def test_reconcile_rounds_to_2_decimal_places(self, client):
        """
        Verify the formula rounds to 2 decimal places.
        100.10 + 0 - 50.05 - 50.05 produces a non-zero float due to IEEE 754
        but round(..., 2) gives 0.00 -> 'balanced'.
        """
        payload = {
            "customer_name": "Rounding Test",
            "instrument_type": "whistle",
            "material": "tin",
            "pitch_reference": "A=440Hz",
            "target_key": "D",
            "bore_taper": "straight",
            "quoted_total": 100.10,
            "deposit_amount": 50.05,
        }
        comm_resp = client.post("/commissions", json=payload)
        cid = comm_resp.json().get("id", 0)
        client.post(
            f"/commissions/{cid}/credits",
            json={"amount": 50.05, "reason": "Balance credit"},
        )
        resp = client.get(f"/commissions/{cid}/reconcile")
        data = resp.json()
        assert data["status"] == "balanced"
        assert data["final_balance_owed"] == 0.00

    def test_reconcile_nonexistent_commission_returns_404(self, client, created_commission):
        cid = created_commission["id"]
        valid_resp = client.get(f"/commissions/{cid}/reconcile")
        assert valid_resp.status_code == 200, "Route must exist for valid IDs"
        resp = client.get("/commissions/99999/reconcile")
        assert resp.status_code == 404
        assert resp.json().get("detail")

    def test_reconcile_no_charges_no_credits(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.get(f"/commissions/{cid}/reconcile")
        data = resp.json()
        assert data["total_additional_charges"] == 0
        assert data["total_credits"] == 0
        expected = round(data["quoted_total"] - data["deposit_paid"], 2)
        assert data["final_balance_owed"] == expected

    def test_stored_final_balance_not_updated_by_charges_or_credits(self, client):
        """
        The stored final_balance is frozen at creation as quoted_total - deposit_amount
        and must not be recalculated when either charges or credits are subsequently added.
        """
        payload = {
            "customer_name": "Balance Freeze Test",
            "instrument_type": "flute",
            "material": "Rosewood",
            "pitch_reference": "A=440Hz",
            "target_key": "D",
            "bore_taper": "straight",
            "quoted_total": 1000.0,
            "deposit_amount": 400.0,
        }
        comm_resp = client.post("/commissions", json=payload)
        comm_data = comm_resp.json()
        cid = comm_data.get("id", 0)
        initial_balance = comm_data["final_balance"]

        client.post(f"/commissions/{cid}/charges", json={"amount": 200.0, "reason": "Extra work"})
        client.post(f"/commissions/{cid}/credits", json={"amount": 150.0, "reason": "Loyalty discount"})

        get_resp = client.get(f"/commissions/{cid}")
        assert get_resp.json()["final_balance"] == initial_balance
