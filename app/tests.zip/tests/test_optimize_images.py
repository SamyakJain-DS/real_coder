"""
F2P test suite for the Image Optimization CLI Tool.
"""

import importlib
import json
import os
import sys
import pytest
from pathlib import Path
from PIL import Image

_TEST_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.join(_TEST_DIR, "..")
sys.path.insert(0, _PARENT_DIR)


# ------------------------------------------------------------------------------
# Lazy-import fixture
# Converts ImportError into a None return so every dependent test is
# reported as FAILED (not ERROR) when the codebase is empty.
# ------------------------------------------------------------------------------

@pytest.fixture(scope="session")
def main_fn():
    """
    Session-scoped fixture that lazily imports `main` from optimize_images.
    Returns None on ImportError so that dependent tests are reported as
    FAILED rather than ERROR when the codebase is empty.
    """
    try:
        mod = importlib.import_module("optimize_images")
        return mod.main
    except ImportError:
        return None


# ------------------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------------------

def make_image(path: Path, width: int, height: int, fmt: str = "JPEG") -> Path:
    """Create a plain RGB image and save it at the given path."""
    img = Image.new("RGB", (width, height), color=(100, 150, 200))
    img.save(str(path), fmt)
    return path


def make_gif(path: Path, width: int, height: int) -> Path:
    """Create a palette-mode GIF (Pillow requires palette mode for GIF)."""
    img = Image.new("RGB", (width, height), color=(80, 160, 80)).convert("P")
    img.save(str(path), "GIF")
    return path


def make_jpeg_with_exif(path: Path, width: int, height: int,
                         orientation: int, extra_tags: dict = None) -> Path:
    """Create a JPEG that carries EXIF data including an orientation tag."""
    img = Image.new("RGB", (width, height), color=(200, 100, 50))
    exif = img.getexif()
    exif[274] = orientation          # orientation tag (ID 274)
    if extra_tags:
        for tag_id, value in extra_tags.items():
            exif[tag_id] = value
    img.save(str(path), "JPEG", exif=exif.tobytes())
    return path


def read_manifest(output_dir: Path) -> dict:
    with open(output_dir / "manifest.json") as f:
        return json.load(f)


def run_main(main_fn, *args: str) -> int:
    """Invoke main_fn with the given argument strings; return the exit code.
    Explicitly fails (not errors) when main_fn is None so that every
    dependent test is reported as FAILED on an empty repository."""
    if main_fn is None:
        pytest.fail("optimize_images module could not be imported")
    with pytest.raises(SystemExit) as exc_info:
        main_fn(list(args))
    return exc_info.value.code


# ------------------------------------------------------------------------------
# CLI Exit Codes
# ------------------------------------------------------------------------------

class TestCLIExitCodes:

    def test_exit_0_on_successful_run(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        assert run_main(main_fn, str(input_dir), str(output_dir)) == 0

    def test_exit_1_when_input_dir_does_not_exist(self, main_fn, tmp_path):
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        assert run_main(main_fn, str(tmp_path / "nonexistent"), str(output_dir)) == 1

    def test_exit_1_when_quality_above_100(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()

        assert run_main(main_fn, str(input_dir), str(output_dir), "--quality", "101") == 1

    def test_exit_1_when_quality_below_0(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()

        assert run_main(main_fn, str(input_dir), str(output_dir), "--quality", "-1") == 1

    def test_exit_0_when_quality_is_0(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 200, 200)

        assert run_main(main_fn, str(input_dir), str(output_dir), "--quality", "0") == 0

    def test_exit_0_when_quality_is_100(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 200, 200)

        assert run_main(main_fn, str(input_dir), str(output_dir), "--quality", "100") == 0

    def test_exit_1_when_output_dir_cannot_be_created(self, main_fn, tmp_path):
        """Use a file path as output_dir - the tool cannot create a dir there."""
        input_dir = tmp_path / "input"
        input_dir.mkdir()
        blocking_file = tmp_path / "output"
        blocking_file.write_text("I am a file, not a directory")

        assert run_main(main_fn, str(input_dir), str(blocking_file)) == 1

    def test_output_dir_created_when_absent(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "new_output"
        input_dir.mkdir()
        make_image(input_dir / "photo.jpg", 200, 200)

        assert run_main(main_fn, str(input_dir), str(output_dir)) == 0
        assert output_dir.is_dir()


# ------------------------------------------------------------------------------
# CLI Defaults
# ------------------------------------------------------------------------------

class TestCLIDefaults:

    def test_default_max_dimension_is_1920(self, main_fn, tmp_path):
        """An image wider than 1920 px should be resized when using the default."""
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "wide.jpg", 3000, 1000)

        run_main(main_fn, str(input_dir), str(output_dir))

        out = Image.open(output_dir / "wide.webp")
        assert max(out.size) <= 1920

    def test_default_thumbnail_size_is_200(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 800, 600)

        run_main(main_fn, str(input_dir), str(output_dir))

        thumb = Image.open(output_dir / "photo_thumb.webp")
        assert max(thumb.size) <= 200


# ------------------------------------------------------------------------------
# main() Programmatic Interface
# ------------------------------------------------------------------------------

class TestMainInterface:

    def test_main_accepts_args_list(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 200, 200)

        if main_fn is None:
            pytest.fail("optimize_images module could not be imported")
        with pytest.raises(SystemExit) as exc_info:
            main_fn([str(input_dir), str(output_dir)])
        assert exc_info.value.code == 0

    def test_main_none_reads_from_sys_argv(self, main_fn, tmp_path, monkeypatch):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 200, 200)

        if main_fn is None:
            pytest.fail("optimize_images module could not be imported")
        monkeypatch.setattr(
            sys, "argv",
            ["optimize_images.py", str(input_dir), str(output_dir)]
        )
        with pytest.raises(SystemExit) as exc_info:
            main_fn(None)
        assert exc_info.value.code == 0

    def test_main_custom_max_dimension_via_args(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 2000, 1000)

        run_main(main_fn, str(input_dir), str(output_dir), "--max-dimension", "500")

        out = Image.open(output_dir / "photo.webp")
        assert max(out.size) <= 500

    def test_main_custom_thumbnail_size_via_args(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 800, 600)

        run_main(main_fn, str(input_dir), str(output_dir), "--thumbnail-size", "80")

        thumb = Image.open(output_dir / "photo_thumb.webp")
        assert max(thumb.size) <= 80


# ------------------------------------------------------------------------------
# Input Handling
# ------------------------------------------------------------------------------

class TestInputHandling:

    @pytest.mark.parametrize("filename,pil_format", [
        ("photo.jpg",  "JPEG"),
        ("photo.jpeg", "JPEG"),
        ("photo.png",  "PNG"),
        ("photo.tiff", "TIFF"),
        ("photo.tif",  "TIFF"),
        ("photo.bmp",  "BMP"),
        # Case-insensitive - all seven accepted formats must work uppercased
        ("photo.JPG",  "JPEG"),
        ("photo.JPEG", "JPEG"),
        ("photo.PNG",  "PNG"),
        ("photo.TIFF", "TIFF"),
        ("photo.TIF",  "TIFF"),
        ("photo.BMP",  "BMP"),
        ("photo.GIF",  "GIF"),
    ])
    def test_accepted_extension_is_processed(self, main_fn, tmp_path, filename, pil_format):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        if pil_format == "GIF":
            make_gif(input_dir / filename, 100, 100)
        else:
            make_image(input_dir / filename, 100, 100, pil_format)

        run_main(main_fn, str(input_dir), str(output_dir))

        manifest = read_manifest(output_dir)
        assert len(manifest["images"]) == 1

    def test_gif_accepted_and_processed(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_gif(input_dir / "photo.gif", 100, 100)

        run_main(main_fn, str(input_dir), str(output_dir))

        manifest = read_manifest(output_dir)
        assert len(manifest["images"]) == 1

    def test_unsupported_extension_skipped(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        (input_dir / "notes.txt").write_text("not an image")
        (input_dir / "archive.zip").write_bytes(b"PK\x03\x04")

        run_main(main_fn, str(input_dir), str(output_dir))

        manifest = read_manifest(output_dir)
        assert len(manifest["images"]) == 0

    def test_non_recursive_traversal(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        subdir = input_dir / "album"
        input_dir.mkdir()
        output_dir.mkdir()
        subdir.mkdir()
        make_image(input_dir / "top.jpg", 200, 200)
        make_image(subdir / "nested.jpg", 200, 200)

        run_main(main_fn, str(input_dir), str(output_dir))

        manifest = read_manifest(output_dir)
        filenames = {e["original_filename"] for e in manifest["images"]}
        assert "top.jpg" in filenames
        assert "nested.jpg" not in filenames

    def test_corrupt_file_skipped_processing_continues(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        (input_dir / "corrupt.jpg").write_bytes(b"not valid jpeg data at all")
        make_image(input_dir / "valid.jpg", 200, 200)

        code = run_main(main_fn, str(input_dir), str(output_dir))

        assert code == 0
        manifest = read_manifest(output_dir)
        filenames = {e["original_filename"] for e in manifest["images"]}
        assert "valid.jpg" in filenames
        assert "corrupt.jpg" not in filenames


# ------------------------------------------------------------------------------
# Resizing
# ------------------------------------------------------------------------------

class TestResizing:

    def test_landscape_image_resized_within_max_dimension(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "wide.jpg", 4000, 2000)

        run_main(main_fn, str(input_dir), str(output_dir), "--max-dimension", "1920")

        out = Image.open(output_dir / "wide.webp")
        assert out.width <= 1920
        assert out.height <= 1920

    def test_portrait_image_resized_within_max_dimension(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "tall.jpg", 1000, 3000)

        run_main(main_fn, str(input_dir), str(output_dir), "--max-dimension", "800")

        out = Image.open(output_dir / "tall.webp")
        assert out.width <= 800
        assert out.height <= 800

    def test_aspect_ratio_preserved_landscape(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 4000, 2000)   # 2.0 : 1

        run_main(main_fn, str(input_dir), str(output_dir), "--max-dimension", "1920")

        out = Image.open(output_dir / "photo.webp")
        assert abs((out.width / out.height) - (4000 / 2000)) < 0.01

    def test_aspect_ratio_preserved_portrait(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 1000, 3000)   # 1 : 3

        run_main(main_fn, str(input_dir), str(output_dir), "--max-dimension", "800")

        out = Image.open(output_dir / "photo.webp")
        assert abs((out.width / out.height) - (1000 / 3000)) < 0.01

    def test_small_image_not_upscaled(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        src = input_dir / "small.jpg"
        make_image(src, 400, 300)
        src_w, src_h = Image.open(src).size

        run_main(main_fn, str(input_dir), str(output_dir), "--max-dimension", "1920")

        out = Image.open(output_dir / "small.webp")
        assert out.width <= src_w
        assert out.height <= src_h


# ------------------------------------------------------------------------------
# Output Format
# ------------------------------------------------------------------------------

class TestOutputFormat:

    def test_output_file_is_webp(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        assert Image.open(output_dir / "photo.webp").format == "WEBP"

    def test_output_filename_uses_webp_extension(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "myphoto.png", 200, 200, "PNG")

        run_main(main_fn, str(input_dir), str(output_dir))

        assert (output_dir / "myphoto.webp").exists()

    def test_output_files_written_to_output_dir(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 300, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        assert (output_dir / "photo.webp").exists()
        assert not (input_dir / "photo.webp").exists()

    def test_filename_collision_second_alphabetically_skipped(self, main_fn, tmp_path):
        """Two files with the same stem - exactly one must survive and it must be the first alphabetically."""
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        candidates = ["photo.jpg", "photo.png"]
        make_image(input_dir / "photo.jpg", 200, 200)
        make_image(input_dir / "photo.png", 200, 200, "PNG")

        run_main(main_fn, str(input_dir), str(output_dir))

        manifest = read_manifest(output_dir)
        filenames = {e["original_filename"] for e in manifest["images"]}
        photo_entries = [f for f in filenames if f.startswith("photo.")]
        assert len(photo_entries) == 1
        assert sorted(candidates)[0] in filenames


# ------------------------------------------------------------------------------
# Thumbnail
# ------------------------------------------------------------------------------

class TestThumbnail:

    def test_thumbnail_is_webp_format(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        assert Image.open(output_dir / "photo_thumb.webp").format == "WEBP"

    def test_thumbnail_fits_within_thumbnail_size(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 800, 600)

        run_main(main_fn, str(input_dir), str(output_dir), "--thumbnail-size", "150")

        thumb = Image.open(output_dir / "photo_thumb.webp")
        assert thumb.width <= 150
        assert thumb.height <= 150

    def test_thumbnail_aspect_ratio_preserved(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 800, 400)   # 2.0 : 1

        run_main(main_fn, str(input_dir), str(output_dir), "--thumbnail-size", "200")

        thumb = Image.open(output_dir / "photo_thumb.webp")
        assert abs((thumb.width / thumb.height) - (800 / 400)) < 0.01

    def test_thumbnail_naming_convention(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "myphoto.png", 300, 300, "PNG")

        run_main(main_fn, str(input_dir), str(output_dir))

        assert (output_dir / "myphoto_thumb.webp").exists()




# ------------------------------------------------------------------------------
# EXIF Handling
# ------------------------------------------------------------------------------

class TestEXIFHandling:

    def test_non_orientation_exif_tags_stripped_from_output(self, main_fn, tmp_path):
        """All EXIF metadata except orientation (tag 274) must be removed."""
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        # Write a JPEG carrying extra EXIF tags alongside orientation
        make_jpeg_with_exif(
            input_dir / "photo.jpg", 400, 300,
            orientation=1,
            extra_tags={271: "TestCamera", 272: "ModelX"},  # Make, Model
        )

        run_main(main_fn, str(input_dir), str(output_dir))

        out = Image.open(output_dir / "photo.webp")
        exif = out.getexif()
        non_orientation = {k: v for k, v in exif.items() if k != 274}
        assert len(non_orientation) == 0, (
            f"Non-orientation EXIF tags found in output: {non_orientation}"
        )

    def test_exif_orientation_tag_preserved_in_output(self, main_fn, tmp_path):
        """Orientation tag (ID 274) must survive the conversion with its value intact."""
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_jpeg_with_exif(input_dir / "photo.jpg", 400, 300, orientation=6)

        run_main(main_fn, str(input_dir), str(output_dir))

        out = Image.open(output_dir / "photo.webp")
        exif = out.getexif()
        assert 274 in exif, "Orientation tag (274) is missing from the output WebP"
        assert exif[274] == 6, (
            f"Orientation value should be 6, got {exif[274]}"
        )

    def test_no_orientation_tag_in_source_produces_stripped_output(self, main_fn, tmp_path):
        """When source has no orientation tag, output must have no EXIF at all."""
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        # Plain image - no EXIF written
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        out = Image.open(output_dir / "photo.webp")
        exif = out.getexif()
        assert len(exif) == 0, (
            f"Expected no EXIF tags in output, found: {dict(exif)}"
        )


# ------------------------------------------------------------------------------
# Manifest
# ------------------------------------------------------------------------------

class TestManifest:

    def test_manifest_json_is_created(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        assert (output_dir / "manifest.json").exists()

    def test_manifest_entry_contains_all_required_fields(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        entry = read_manifest(output_dir)["images"][0]
        for field in ("original_filename", "output_filename", "thumbnail_filename",
                      "original_size", "optimized_size", "compression_ratio",
                      "last_modified"):
            assert field in entry, f"Missing field: {field}"

    def test_manifest_entry_field_types(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        entry = read_manifest(output_dir)["images"][0]
        assert isinstance(entry["original_filename"], str)
        assert isinstance(entry["output_filename"], str)
        assert isinstance(entry["thumbnail_filename"], str)
        assert isinstance(entry["original_size"], int)
        assert isinstance(entry["optimized_size"], int)
        assert isinstance(entry["compression_ratio"], float)
        assert isinstance(entry["last_modified"], float)

    def test_manifest_original_filename_is_basename(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        entry = read_manifest(output_dir)["images"][0]
        assert entry["original_filename"] == "photo.jpg"

    def test_manifest_output_filename_is_webp(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        entry = read_manifest(output_dir)["images"][0]
        assert entry["output_filename"] == "photo.webp"

    def test_manifest_thumbnail_filename_uses_thumb_suffix(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        entry = read_manifest(output_dir)["images"][0]
        assert entry["thumbnail_filename"] == "photo_thumb.webp"

    def test_manifest_original_size_matches_source_file(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        src = input_dir / "photo.jpg"
        make_image(src, 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        entry = read_manifest(output_dir)["images"][0]
        assert entry["original_size"] == src.stat().st_size

    def test_manifest_optimized_size_matches_output_file(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        entry = read_manifest(output_dir)["images"][0]
        assert entry["optimized_size"] == (output_dir / "photo.webp").stat().st_size

    def test_manifest_compression_ratio_formula(self, main_fn, tmp_path):
        """compression_ratio must equal original_size / optimized_size at 4 dp."""
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        entry = read_manifest(output_dir)["images"][0]
        expected = round(entry["original_size"] / entry["optimized_size"], 4)
        assert entry["compression_ratio"] == expected

    def test_manifest_last_modified_matches_source_mtime(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        src = input_dir / "photo.jpg"
        make_image(src, 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))

        entry = read_manifest(output_dir)["images"][0]
        assert entry["last_modified"] == src.stat().st_mtime

    def test_manifest_images_ordered_alphabetically(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        for name in ("zebra.jpg", "apple.jpg", "mango.jpg"):
            make_image(input_dir / name, 100, 100)

        run_main(main_fn, str(input_dir), str(output_dir))

        filenames = [e["original_filename"] for e in read_manifest(output_dir)["images"]]
        assert filenames == sorted(filenames)

    def test_manifest_stale_entry_removed_after_source_deleted(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "keep.jpg", 100, 100)
        make_image(input_dir / "delete.jpg", 100, 100)

        run_main(main_fn, str(input_dir), str(output_dir))
        (input_dir / "delete.jpg").unlink()
        run_main(main_fn, str(input_dir), str(output_dir))

        filenames = {e["original_filename"] for e in read_manifest(output_dir)["images"]}
        assert "keep.jpg" in filenames
        assert "delete.jpg" not in filenames

    def test_manifest_created_for_empty_input_dir(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()

        run_main(main_fn, str(input_dir), str(output_dir))

        manifest = read_manifest(output_dir)
        assert manifest["images"] == []


# ------------------------------------------------------------------------------
# Skip Logic
# ------------------------------------------------------------------------------

class TestSkipLogic:

    def test_skipped_file_retains_manifest_entry(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "photo.jpg", 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))
        first_entry = read_manifest(output_dir)["images"][0].copy()

        run_main(main_fn, str(input_dir), str(output_dir))
        second_entry = read_manifest(output_dir)["images"][0]

        assert first_entry == second_entry

    def test_modified_file_reprocessed_on_next_run(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        src = input_dir / "photo.jpg"
        make_image(src, 400, 300)

        run_main(main_fn, str(input_dir), str(output_dir))
        first_size = read_manifest(output_dir)["images"][0]["original_size"]

        # Overwrite source with a meaningfully larger image and bump mtime
        make_image(src, 1200, 900)
        os.utime(src, (src.stat().st_atime, src.stat().st_mtime + 2.0))

        run_main(main_fn, str(input_dir), str(output_dir))
        second_size = read_manifest(output_dir)["images"][0]["original_size"]

        assert second_size != first_size

    def test_new_file_added_between_runs_is_processed(self, main_fn, tmp_path):
        input_dir = tmp_path / "input"
        output_dir = tmp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        make_image(input_dir / "first.jpg", 200, 200)

        run_main(main_fn, str(input_dir), str(output_dir))

        make_image(input_dir / "second.jpg", 200, 200)
        run_main(main_fn, str(input_dir), str(output_dir))

        filenames = {e["original_filename"] for e in read_manifest(output_dir)["images"]}
        assert "first.jpg" in filenames
        assert "second.jpg" in filenames