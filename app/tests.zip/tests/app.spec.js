import { test, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';

const BASE_URL = 'http://localhost:4173';

// --- Helpers ------------------------------------------------------------------

async function clearAndReload(page) {
  await page.goto(BASE_URL);
  await page.evaluate(() => localStorage.clear());
  await page.reload();
}

async function addBook(page, title, author, totalPages) {
  await page.getByTestId('field-title').fill(title);
  await page.getByTestId('field-author').fill(author);
  await page.getByTestId('field-total-pages').fill(String(totalPages));
  await page.getByTestId('submit-add-book').click();
}

async function getLibrary(page) {
  return page.evaluate(() => {
    const raw = localStorage.getItem('reading-journal');
    return raw ? JSON.parse(raw) : { books: [], activity: [] };
  });
}

async function getFirstBookId(page) {
  const lib = await getLibrary(page);
  return lib.books[0]?.id;
}

async function finishBook(page, id, rating, review) {
  await page.getByTestId(`mark-finished-${id}`).click();
  await page.getByTestId(`finish-rating-${id}`).fill(String(rating));
  await page.getByTestId(`finish-review-${id}`).fill(review);
  await page.getByTestId(`finish-submit-${id}`).click();
}

// --- package.json interface ---------------------------------------------------

test('package.json has required dependencies and scripts', () => {
  const pkgPath = path.resolve('package.json');
  expect(fs.existsSync(pkgPath)).toBe(true);
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
  expect(pkg.private).toBe(true);
  expect(pkg.dependencies?.react).toMatch(/^\^18/);
  expect(pkg.dependencies?.['react-dom']).toMatch(/^\^18/);
  expect(pkg.dependencies?.recharts).toBeTruthy();
  expect(pkg.devDependencies?.vite).toBeTruthy();
  expect(pkg.devDependencies?.['@vitejs/plugin-react']).toBeTruthy();
  expect(pkg.scripts?.dev).toBe('vite');
  expect(pkg.scripts?.build).toBe('vite build');
});

// --- App loads - stable testids -----------------------------------------------

test('app renders with all required global testids', async ({ page }) => {
  await clearAndReload(page);

  // All always-visible global testids
  const visibleIds = [
    'add-book-form', 'field-title', 'field-author', 'field-total-pages',
    'submit-add-book', 'shelf-currently-reading', 'shelf-finished',
    'search-input', 'filter-author', 'filter-rating', 'filter-year',
    'stats-books-finished-this-year', 'stats-total-pages-this-year',
    'stats-total-pages-all', 'stats-average-length-this-year',
    'stats-pages-per-week-chart', 'reset-library',
  ];
  for (const id of visibleIds) {
    await expect(page.getByTestId(id)).toBeVisible();
  }

});

// --- KR 1, 2 - Add book -------------------------------------------------------

test.describe('KR 1, 2 - Add book', () => {
  test.beforeEach(({ page }) => clearAndReload(page));

  test('valid book is stored with correct initial values in localStorage', async ({ page }) => {
    await addBook(page, 'Dune', 'Frank Herbert', 412);
    const lib = await getLibrary(page);
    const book = lib.books[0];
    expect(lib.books).toHaveLength(1);
    expect(book.title).toBe('Dune');
    expect(book.author).toBe('Frank Herbert');
    expect(book.totalPages).toBe(412);
    expect(book.currentPage).toBe(0);
    expect(book.status).toBe('currently_reading');
    expect(book.rating).toBeNull();
    expect(book.review).toBeNull();
    expect(book.finishedAt).toBeNull();
    expect(typeof book.id).toBe('string');
    expect(book.id.length).toBeGreaterThan(0);
    expect(typeof book.createdAt).toBe('string');
    expect(isNaN(Date.parse(book.createdAt))).toBe(false);
  });

  test('new book appears on Currently Reading shelf with per-book testids', async ({ page }) => {
    await addBook(page, 'Dune', 'Frank Herbert', 412);
    const id = await getFirstBookId(page);
    await expect(page.getByTestId('shelf-currently-reading').getByTestId(`book-card-${id}`)).toBeVisible();
    await expect(page.getByTestId(`progress-bar-${id}`)).toBeVisible();
    await expect(page.getByTestId(`progress-percent-${id}`)).toBeVisible();
    await expect(page.getByTestId(`update-progress-input-${id}`)).toBeVisible();
    await expect(page.getByTestId(`update-progress-submit-${id}`)).toBeVisible();
    await expect(page.getByTestId(`mark-finished-${id}`)).toBeVisible();
  });

  test('new book does not appear on Finished shelf and return-to-reading is absent', async ({ page }) => {
    await addBook(page, 'Dune', 'Frank Herbert', 412);
    const id = await getFirstBookId(page);
    await expect(page.getByTestId('shelf-finished').getByTestId(`book-card-${id}`)).not.toBeVisible();
    await expect(page.getByTestId(`return-to-reading-${id}`)).not.toBeVisible();
  });
});

// --- KR 3, 4 - Progress -------------------------------------------------------

test.describe('KR 3, 4 - Progress tracking', () => {
  let bookId;
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Dune', 'Frank Herbert', 400);
    bookId = await getFirstBookId(page);
  });

  test('progress percent is 0 before any update', async ({ page }) => {
    await expect(page.getByTestId(`progress-percent-${bookId}`)).toBeVisible();
    const text = await page.getByTestId(`progress-percent-${bookId}`).textContent();
    expect(parseInt(text, 10)).toBe(0);
  });

  test('progress percent reflects Math.round formula after update', async ({ page }) => {
    // 200 / 300 * 100 = 66.666... -> Math.round = 67, Math.floor = 66
    // totalPages is 400 from beforeEach - use a separate book with totalPages=300
    await clearAndReload(page);
    await addBook(page, 'RoundTest', 'Author', 300);
    bookId = await getFirstBookId(page);
    await page.getByTestId(`update-progress-input-${bookId}`).fill('200');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const text = await page.getByTestId(`progress-percent-${bookId}`).textContent();
    expect(parseInt(text, 10)).toBe(67);
  });

  test('currentPage is persisted in localStorage after update', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('150');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib = await getLibrary(page);
    expect(lib.books[0].currentPage).toBe(150);
  });

  test('increasing currentPage appends exactly one ActivityEntry with correct shape', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib = await getLibrary(page);
    const entries = lib.activity.filter(e => e.bookId === bookId);
    expect(entries).toHaveLength(1);
    expect(entries[0].pagesAdded).toBe(100);
    expect(typeof entries[0].id).toBe('string');
    expect(entries[0].id.length).toBeGreaterThan(0);
    expect(typeof entries[0].timestamp).toBe('string');
    expect(isNaN(Date.parse(entries[0].timestamp))).toBe(false);
  });

  test('pagesAdded is the delta from previous currentPage', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    await page.getByTestId(`update-progress-input-${bookId}`).fill('160');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib = await getLibrary(page);
    const entries = lib.activity.filter(e => e.bookId === bookId);
    expect(entries[0].pagesAdded).toBe(100);
    expect(entries[1].pagesAdded).toBe(60);
  });

  test('decreasing currentPage does not append a new ActivityEntry', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('200');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib1 = await getLibrary(page);
    const countBefore = lib1.activity.length;

    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib2 = await getLibrary(page);
    expect(lib2.activity.length).toBe(countBefore);
  });
});

// --- KR 5, 6, 7 - Shelves and finish flow ------------------------------------

test.describe('KR 5, 6, 7 - Shelf and finish flow', () => {
  let bookId;
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Dune', 'Frank Herbert', 400);
    bookId = await getFirstBookId(page);
  });

  test('finishing a book moves it to Finished shelf', async ({ page }) => {
    await finishBook(page, bookId, 5, 'Loved it');
    await expect(page.getByTestId('shelf-finished').getByTestId(`book-card-${bookId}`)).toBeVisible();
    await expect(page.getByTestId('shelf-currently-reading').getByTestId(`book-card-${bookId}`)).not.toBeVisible();
  });

  test('finishing sets correct fields in localStorage', async ({ page }) => {
    await finishBook(page, bookId, 4, 'Very good');
    const lib = await getLibrary(page);
    const book = lib.books.find(b => b.id === bookId);
    expect(book.status).toBe('finished');
    expect(book.rating).toBe(4);
    expect(book.review).toBe('Very good');
    expect(book.currentPage).toBe(book.totalPages);
    expect(typeof book.finishedAt).toBe('string');
    expect(isNaN(Date.parse(book.finishedAt))).toBe(false);
    // KR 6: currentPage started at 0 so it increases when finishing ->
    // ActivityEntry with timestamp === finishedAt (KR 6 mandates same timestamp)
    const entry = lib.activity.find(e => e.bookId === bookId && e.timestamp === book.finishedAt);
    expect(entry).toBeDefined();
    // pagesAdded = totalPages − 0 (previous currentPage was 0)
    expect(entry.pagesAdded).toBe(book.totalPages);
  });

  test('currently_reading controls are absent on a finished book', async ({ page }) => {
    await finishBook(page, bookId, 5, 'Great');
    await expect(page.getByTestId(`progress-bar-${bookId}`)).not.toBeVisible();
    await expect(page.getByTestId(`progress-percent-${bookId}`)).not.toBeVisible();
    await expect(page.getByTestId(`update-progress-input-${bookId}`)).not.toBeVisible();
    await expect(page.getByTestId(`update-progress-submit-${bookId}`)).not.toBeVisible();
    await expect(page.getByTestId(`mark-finished-${bookId}`)).not.toBeVisible();
    await expect(page.getByTestId(`finish-rating-${bookId}`)).not.toBeVisible();
    await expect(page.getByTestId(`finish-review-${bookId}`)).not.toBeVisible();
    await expect(page.getByTestId(`finish-submit-${bookId}`)).not.toBeVisible();
  });

  test('return-to-reading is present only after finishing', async ({ page }) => {
    await expect(page.getByTestId(`return-to-reading-${bookId}`)).not.toBeVisible();
    await finishBook(page, bookId, 5, 'Great');
    await expect(page.getByTestId(`return-to-reading-${bookId}`)).toBeVisible();
  });

  test('return-to-reading clears finish fields and moves book to Currently Reading', async ({ page }) => {
    await finishBook(page, bookId, 3, 'OK');
    await page.getByTestId(`return-to-reading-${bookId}`).click();
    const lib = await getLibrary(page);
    const book = lib.books.find(b => b.id === bookId);
    expect(book.status).toBe('currently_reading');
    expect(book.rating).toBeNull();
    expect(book.review).toBeNull();
    expect(book.finishedAt).toBeNull();
    await expect(page.getByTestId('shelf-currently-reading').getByTestId(`book-card-${bookId}`)).toBeVisible();
  });

  test('return-to-reading does not change the ActivityEntry list', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    await finishBook(page, bookId, 5, 'Great');
    const lib1 = await getLibrary(page);
    const activityCount = lib1.activity.length;

    await page.getByTestId(`return-to-reading-${bookId}`).click();
    const lib2 = await getLibrary(page);
    expect(lib2.activity.length).toBe(activityCount);
  });
});

// --- KR 18 - Inline validation: update-progress ------------------------------

test.describe('KR 18 - Update-progress boundary validation', () => {
  let bookId;
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Book', 'Author', 100);
    bookId = await getFirstBookId(page);
  });

  test('value equal to totalPages is accepted (boundary)', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    expect((await getLibrary(page)).books[0].currentPage).toBe(100);
  });

  test('value of 0 is accepted as valid input (boundary)', async ({ page }) => {
    // First increase to 50 (creates one ActivityEntry)
    await page.getByTestId(`update-progress-input-${bookId}`).fill('50');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    // Now submit 0 - a decrease, so no new ActivityEntry, but value must update
    // (KR 3: 0 is a valid value to "set"; KR 18: 0 is in valid range, no error)
    await page.getByTestId(`update-progress-input-${bookId}`).fill('0');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib = await getLibrary(page);
    expect(lib.books[0].currentPage).toBe(0);
    // Only the first entry (50 pages) exists - no entry for the decrease
    expect(lib.activity.filter(e => e.bookId === bookId)).toHaveLength(1);
  });
});

// --- KR 8, 9 - Search and filtering ------------------------------------------

/**
 * Tag-aware filter helper (T23/T24/T25 fix).
 *
 * The prompt specifies discrete filter controls (rating 1-5, year, author
 * "selectable list") but does not mandate a <select> element. This helper
 * works for both <select> and other controls (radio groups, button groups,
 * custom listboxes) so valid alternative implementations are not penalised.
 *
 * Strategy:
 *   - <select>  → use Playwright's selectOption()
 *   - anything else → locate the first descendant or sibling whose visible
 *     text / value / aria-label matches `value` and click it
 */
async function setFilterOption(page, testId, value) {
  const control = page.getByTestId(testId);
  const tagName = await control.evaluate(el => el.tagName.toLowerCase());
  if (tagName === 'select') {
    await control.selectOption(String(value));
  } else {
    // Handles radio groups, button groups, ARIA listboxes, etc.
    // Prefer an exact text/value match among direct children; fall back to
    // any descendant whose visible text equals the value.
    const child = control.locator(`[value="${value}"], [data-value="${value}"]`).first();
    const childCount = await child.count();
    if (childCount > 0) {
      await child.click();
    } else {
      await control.locator(`text="${value}"`).first().click();
    }
  }
}

test.describe('KR 8, 9 - Search and filtering', () => {
  let herbertId, orwellId;
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Dune', 'Frank Herbert', 400);
    await addBook(page, '1984', 'George Orwell', 300);
    const lib = await getLibrary(page);
    herbertId = lib.books.find(b => b.author === 'Frank Herbert').id;
    orwellId = lib.books.find(b => b.author === 'George Orwell').id;
  });

  test('author search is case-insensitive (KR 8)', async ({ page }) => {
    await page.getByTestId('search-input').fill('frank');
    await expect(page.getByTestId(`book-card-${herbertId}`)).toBeVisible();
    await expect(page.getByTestId(`book-card-${orwellId}`)).not.toBeVisible();
  });

  test('author search is a substring match (KR 8)', async ({ page }) => {
    // Use a partial fragment that excludes both the start and end of the name -
    // a whole-word or exact match would fail this, proving true substring semantics.
    await page.getByTestId('search-input').fill('rwell');
    await expect(page.getByTestId(`book-card-${orwellId}`)).toBeVisible();
    await expect(page.getByTestId(`book-card-${herbertId}`)).not.toBeVisible();
  });

  test('clearing search restores all books', async ({ page }) => {
    await page.getByTestId('search-input').fill('frank');
    await page.getByTestId('search-input').fill('');
    await expect(page.getByTestId(`book-card-${herbertId}`)).toBeVisible();
    await expect(page.getByTestId(`book-card-${orwellId}`)).toBeVisible();
  });

  // T23 fix: uses setFilterOption instead of selectOption('5')
  test('rating filter applies to Finished shelf only - does not exclude Currently Reading (KR 9)', async ({ page }) => {
    await finishBook(page, herbertId, 3, 'OK');
    await setFilterOption(page, 'filter-rating', '5');
    await expect(page.getByTestId(`book-card-${herbertId}`)).not.toBeVisible();
    await expect(page.getByTestId(`book-card-${orwellId}`)).toBeVisible();
  });

  // T24 fix: uses setFilterOption; injected id kept (prompt requires id preservation)
  test('year filter applies to Finished shelf only - does not exclude Currently Reading (KR 9)', async ({ page }) => {
    // Finish Herbert's book this year; inject a second finished book from 2020
    // directly into localStorage so both year options are guaranteed in the dropdown.
    await finishBook(page, herbertId, 4, 'Good');
    await page.evaluate(() => {
      const data = JSON.parse(localStorage.getItem('reading-journal'));
      data.books.push({
        id: 'past-book', title: 'Old Book', author: 'Past Author',
        totalPages: 200, currentPage: 200, status: 'finished',
        rating: 3, review: 'Old', createdAt: '2020-06-01T00:00:00.000Z',
        finishedAt: '2020-06-15T00:00:00.000Z',
      });
      localStorage.setItem('reading-journal', JSON.stringify(data));
    });
    await page.reload();

    const currentYear = String(new Date().getFullYear());

    // Filter to current year: Herbert visible, 2020 book hidden
    await setFilterOption(page, 'filter-year', currentYear);
    await expect(page.getByTestId(`book-card-${herbertId}`)).toBeVisible();
    await expect(page.getByTestId('book-card-past-book')).not.toBeVisible();
    // Currently Reading must not be excluded by year filter
    await expect(page.getByTestId(`book-card-${orwellId}`)).toBeVisible();

    // Filter to 2020: past book visible, Herbert's book hidden (different year)
    await setFilterOption(page, 'filter-year', '2020');
    await expect(page.getByTestId('book-card-past-book')).toBeVisible();
    await expect(page.getByTestId(`book-card-${herbertId}`)).not.toBeVisible();
    // Currently Reading still not excluded
    await expect(page.getByTestId(`book-card-${orwellId}`)).toBeVisible();
  });

  // T25 fix: uses setFilterOption instead of selectOption('Frank Herbert')
  test('author filter applies across both shelves (KR 9)', async ({ page }) => {
    await finishBook(page, herbertId, 5, 'Epic');
    await setFilterOption(page, 'filter-author', 'Frank Herbert');
    await expect(page.getByTestId(`book-card-${herbertId}`)).toBeVisible();
    await expect(page.getByTestId(`book-card-${orwellId}`)).not.toBeVisible();
  });

  test('search and filter combine with AND logic (KR 9)', async ({ page }) => {
    await finishBook(page, herbertId, 5, 'Great');
    // Search "erbert" + rating=5: Herbert matches both (AND) -> visible
    await page.getByTestId('search-input').fill('erbert');
    await setFilterOption(page, 'filter-rating', '5');
    await expect(page.getByTestId(`book-card-${herbertId}`)).toBeVisible();
    // Orwell's author "George Orwell" does not contain "erbert" ->
    // search excludes him (KR 8 applies to both shelves); must not be visible
    await expect(page.getByTestId(`book-card-${orwellId}`)).not.toBeVisible();
    // Switch search to "rwell": now Orwell matches search, Herbert doesn't.
    // Orwell is currently_reading so rating filter does not apply (KR 9) -> visible.
    // Herbert no longer matches search -> hidden.
    await page.getByTestId('search-input').fill('rwell');
    await expect(page.getByTestId(`book-card-${orwellId}`)).toBeVisible();
    await expect(page.getByTestId(`book-card-${herbertId}`)).not.toBeVisible();
  });
});

// --- KR 10, 11, 12 - Stats dashboard -----------------------------------------

test.describe('KR 10, 11, 12 - Stats dashboard', () => {
  test.beforeEach(({ page }) => clearAndReload(page));

  test('all stat values start at 0 with no finished books', async ({ page }) => {
    await expect(page.getByTestId('stats-books-finished-this-year')).toHaveText(/\b0\b/);
    await expect(page.getByTestId('stats-total-pages-this-year')).toHaveText(/\b0\b/);
    await expect(page.getByTestId('stats-total-pages-all')).toHaveText(/\b0\b/);
    // stats-average-length-this-year zero-divisor display is unspecified by the prompt
    // (valid values include '0', '-', 'N/A', empty); covered by rubrics.
  });

  test('stats update immediately after finishing a book (KR 12)', async ({ page }) => {
    await addBook(page, 'Moby Dick', 'Melville', 250);
    const id = await getFirstBookId(page);
    await finishBook(page, id, 5, 'Classic');
    await expect(page.getByTestId('stats-books-finished-this-year')).toContainText('1');
    await expect(page.getByTestId('stats-total-pages-this-year')).toContainText('250');
    await expect(page.getByTestId('stats-total-pages-all')).toContainText('250');
    await expect(page.getByTestId('stats-average-length-this-year')).toContainText('250');
  });

  test('stats-total-pages-all counts only finished books', async ({ page }) => {
    await addBook(page, 'Book A', 'Author', 100);
    await addBook(page, 'Book B', 'Author', 200);
    const lib = await getLibrary(page);
    await finishBook(page, lib.books[0].id, 4, 'Good');
    await expect(page.getByTestId('stats-total-pages-all')).toContainText('100');
  });

  test('stats-average-length-this-year uses Math.round (KR 10)', async ({ page }) => {
    // 100 + 201 = 301 pages across 2 books -> average = 150.5
    // Math.round(150.5) = 151 vs Math.floor(150.5) = 150 - unambiguously distinguishes them
    await addBook(page, 'Book A', 'Author', 100);
    await addBook(page, 'Book B', 'Author', 201);
    const lib = await getLibrary(page);
    await finishBook(page, lib.books[0].id, 4, 'Good');
    await finishBook(page, lib.books[1].id, 4, 'Good');
    await expect(page.getByTestId('stats-average-length-this-year')).toContainText('151');
  });

  // T30 fix: added a non-Monday entry in the same week to verify UTC-Monday bucketing.
  // pagesAdded sum left to rubrics (inspecting Recharts bar values would be overly specific).
  test('pages-per-week chart renders correct UTC Monday week bucket label (KR 11)', async ({ page }) => {
    // Compute the most recent Monday in UTC
    const now = new Date();
    const utcDay = now.getUTCDay(); // 0=Sun, 1=Mon, …, 6=Sat
    const daysToMonday = utcDay === 0 ? 6 : utcDay - 1;
    const monday = new Date(Date.UTC(
      now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - daysToMonday,
    ));
    const expectedLabel = monday.toISOString().slice(0, 10); // YYYY-MM-DD

    // A Wednesday in the same week (Monday + 2 days)
    const wednesday = new Date(monday.getTime() + 2 * 24 * 60 * 60 * 1000);
    const wednesdayLabel = wednesday.toISOString().slice(0, 10);
    const wednesdayTimestamp = wednesday.toISOString();

    const mondayTimestamp = monday.toISOString();

    // Inject two activity entries: one on Monday, one on Wednesday of the same week.
    // Both must be bucketed to the Monday label, not to Wednesday's date.
    await page.evaluate(({ mondayTs, wednesdayTs }) => {
      localStorage.setItem('reading-journal', JSON.stringify({
        books: [{
          id: 'b1', title: 'T', author: 'A', totalPages: 100, currentPage: 40,
          status: 'currently_reading', rating: null, review: null,
          createdAt: mondayTs, finishedAt: null,
        }],
        activity: [
          { id: 'e1', bookId: 'b1', timestamp: mondayTs, pagesAdded: 20 },
          { id: 'e2', bookId: 'b1', timestamp: wednesdayTs, pagesAdded: 20 },
        ],
      }));
    }, { mondayTs: mondayTimestamp, wednesdayTs: wednesdayTimestamp });

    await page.reload();
    await expect(page.getByTestId('stats-pages-per-week-chart')).toBeVisible();

    const chart = page.getByTestId('stats-pages-per-week-chart');

    // The Monday label MUST appear (both entries belong to this bucket)
    await expect(
      chart.locator('svg text').filter({ hasText: expectedLabel })
    ).toBeVisible();

    // The Wednesday date label must NOT appear as a separate bucket
    // (confirms non-Monday timestamps are bucketed to their week's Monday)
    await expect(
      chart.locator('svg text').filter({ hasText: wednesdayLabel })
    ).not.toBeVisible();
  });
});

// --- KR 12 - Stats recompute on reload ---------------------------------------

test.describe('KR 12 - Stats recompute on reload', () => {
  test('stats reflect persisted finished books immediately after reload', async ({ page }) => {
    // Seed localStorage directly with a finished book from the current year
    const now = new Date().toISOString();
    await page.goto(BASE_URL);
    await page.evaluate((ts) => {
      localStorage.setItem('reading-journal', JSON.stringify({
        books: [{
          id: 'seed-1', title: 'Seed Book', author: 'Author',
          totalPages: 180, currentPage: 180, status: 'finished',
          rating: 4, review: 'Good', createdAt: ts, finishedAt: ts,
        }],
        activity: [{ id: 'a1', bookId: 'seed-1', timestamp: ts, pagesAdded: 180 }],
      }));
    }, now);
    // Reload - stats must recompute from persisted data, not require any in-page action
    await page.reload();
    await expect(page.getByTestId('stats-books-finished-this-year')).toHaveText(/\b1\b/);
    await expect(page.getByTestId('stats-total-pages-this-year')).toHaveText(/\b180\b/);
    await expect(page.getByTestId('stats-total-pages-all')).toHaveText(/\b180\b/);
  });
});

// --- KR 15 - Production runtime: no service worker ----------------------------

test('app does not register a service worker (KR 15)', async ({ page }) => {
  await page.goto(BASE_URL);
  await page.waitForLoadState('networkidle');
  const swCount = await page.evaluate(() =>
    navigator.serviceWorker.getRegistrations().then(regs => regs.length)
  );
  expect(swCount).toBe(0);
});

test('app makes no outbound remote-origin network requests at runtime (KR 15)', async ({ page }) => {
  const remoteRequests = [];
  // Listen before navigation so all requests - including initial asset loads - are captured
  page.on('request', req => {
    const url = req.url();
    if (
      !url.startsWith(`http://localhost:4173`) &&
      !url.startsWith('data:') &&
      !url.startsWith('blob:') &&
      !url.startsWith('about:')
    ) {
      remoteRequests.push(url);
    }
  });

  await page.goto(BASE_URL);
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.waitForLoadState('networkidle');

  expect(remoteRequests).toHaveLength(0);
});

// --- KR 13 - Persistence -----------------------------------------------------

test.describe('KR 13 - localStorage persistence', () => {
  test('books and activity persist under key "reading-journal" across reload', async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Persistent', 'Author', 200);
    const id = await getFirstBookId(page);
    await page.getByTestId(`update-progress-input-${id}`).fill('80');
    await page.getByTestId(`update-progress-submit-${id}`).click();

    const raw = await page.evaluate(() => localStorage.getItem('reading-journal'));
    expect(raw).not.toBeNull();
    const stored = JSON.parse(raw);
    expect(Array.isArray(stored.books)).toBe(true);
    expect(Array.isArray(stored.activity)).toBe(true);

    await page.reload();
    const lib = await getLibrary(page);
    expect(lib.books).toHaveLength(1);
    expect(lib.books[0].id).toBe(id);
    expect(lib.books[0].currentPage).toBe(80);
    expect(lib.activity.length).toBeGreaterThan(0);
    await expect(page.getByTestId(`book-card-${id}`)).toBeVisible();
  });
});

// --- KR 16 - Reset ------------------------------------------------------------

test.describe('KR 16 - Reset all data', () => {
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Book', 'Author', 100);
  });

  test('clicking reset-library alone does not clear data (confirmation required)', async ({ page }) => {
    await page.getByTestId('reset-library').click();
    // Do NOT click reset-confirm - data must remain intact
    const lib = await getLibrary(page);
    expect(lib.books).toHaveLength(1);
    await expect(page.locator('[data-testid^="book-card-"]')).toHaveCount(1);
  });

  test('confirming reset clears all books and activity', async ({ page }) => {
    await page.getByTestId('reset-library').click();
    await page.getByTestId('reset-confirm').click();
    const lib = await getLibrary(page);
    expect(lib.books).toHaveLength(0);
    expect(lib.activity ?? []).toHaveLength(0);
    await expect(page.locator('[data-testid^="book-card-"]')).toHaveCount(0);
  });
});