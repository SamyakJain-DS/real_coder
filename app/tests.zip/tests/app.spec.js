import { test, expect } from '@playwright/test';
import fs from 'fs';
import path from 'path';

const BASE_URL = 'http://localhost:4173';

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function clearAndReload(page) {
  await page.goto(BASE_URL);
  await page.evaluate(() => localStorage.clear());
  await page.reload();
}

async function addBook(page, title, author, totalPages) {
  await page.getByTestId('field-title').fill(title);
  await page.getByTestId('field-author').fill(author);
  await page.getByTestId('field-total-pages').fill(String(totalPages));
  await page.getByTestId('submit-add-book').click();
}

async function getLibrary(page) {
  return page.evaluate(() => {
    const raw = localStorage.getItem('reading-journal');
    return raw ? JSON.parse(raw) : { books: [], activity: [] };
  });
}

async function getFirstBookId(page) {
  const lib = await getLibrary(page);
  return lib.books[0]?.id;
}

async function finishBook(page, id, rating, review) {
  await page.getByTestId(`mark-finished-${id}`).click();
  await page.getByTestId(`finish-rating-${id}`).fill(String(rating));
  await page.getByTestId(`finish-review-${id}`).fill(review);
  await page.getByTestId(`finish-submit-${id}`).click();
}

// ─── package.json interface ───────────────────────────────────────────────────

test('package.json has required dependencies and scripts', () => {
  const pkgPath = path.resolve('package.json');
  expect(fs.existsSync(pkgPath)).toBe(true);
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
  expect(pkg.dependencies?.react).toBeTruthy();
  expect(pkg.dependencies?.['react-dom']).toBeTruthy();
  expect(pkg.dependencies?.recharts).toBeTruthy();
  expect(pkg.devDependencies?.vite).toBeTruthy();
  expect(pkg.devDependencies?.['@vitejs/plugin-react']).toBeTruthy();
  expect(typeof pkg.scripts?.dev).toBe('string');
  expect(typeof pkg.scripts?.build).toBe('string');
});

// ─── App loads — stable testids ───────────────────────────────────────────────

test('app renders with all required global testids', async ({ page }) => {
  await clearAndReload(page);
  const globalIds = [
    'add-book-form', 'field-title', 'field-author', 'field-total-pages',
    'submit-add-book', 'shelf-currently-reading', 'shelf-finished',
    'search-input', 'filter-author', 'filter-rating', 'filter-year',
    'stats-books-finished-this-year', 'stats-total-pages-this-year',
    'stats-total-pages-all', 'stats-average-length-this-year',
    'stats-pages-per-week-chart', 'reset-library',
  ];
  for (const id of globalIds) {
    await expect(page.getByTestId(id)).toBeVisible();
  }
});

// ─── KR 1, 2 — Add book ───────────────────────────────────────────────────────

test.describe('KR 1, 2 — Add book', () => {
  test.beforeEach(({ page }) => clearAndReload(page));

  test('valid book is stored with correct initial values in localStorage', async ({ page }) => {
    await addBook(page, 'Dune', 'Frank Herbert', 412);
    const lib = await getLibrary(page);
    const book = lib.books[0];
    expect(lib.books).toHaveLength(1);
    expect(book.title).toBe('Dune');
    expect(book.author).toBe('Frank Herbert');
    expect(book.totalPages).toBe(412);
    expect(book.currentPage).toBe(0);
    expect(book.status).toBe('currently_reading');
    expect(book.rating).toBeNull();
    expect(book.review).toBeNull();
    expect(book.finishedAt).toBeNull();
    expect(typeof book.id).toBe('string');
    expect(book.id.length).toBeGreaterThan(0);
    expect(typeof book.createdAt).toBe('string');
    expect(isNaN(Date.parse(book.createdAt))).toBe(false);
  });

  test('new book appears on Currently Reading shelf with per-book testids', async ({ page }) => {
    await addBook(page, 'Dune', 'Frank Herbert', 412);
    const id = await getFirstBookId(page);
    await expect(page.getByTestId('shelf-currently-reading').getByTestId(`book-card-${id}`)).toBeVisible();
    await expect(page.getByTestId(`progress-bar-${id}`)).toBeVisible();
    await expect(page.getByTestId(`progress-percent-${id}`)).toBeVisible();
    await expect(page.getByTestId(`update-progress-input-${id}`)).toBeVisible();
    await expect(page.getByTestId(`update-progress-submit-${id}`)).toBeVisible();
    await expect(page.getByTestId(`mark-finished-${id}`)).toBeVisible();
  });

  test('new book does not appear on Finished shelf and return-to-reading is absent', async ({ page }) => {
    await addBook(page, 'Dune', 'Frank Herbert', 412);
    const id = await getFirstBookId(page);
    await expect(page.getByTestId('shelf-finished').getByTestId(`book-card-${id}`)).not.toBeVisible();
    await expect(page.getByTestId(`return-to-reading-${id}`)).not.toBeVisible();
  });
});

// ─── KR 3, 4 — Progress ───────────────────────────────────────────────────────

test.describe('KR 3, 4 — Progress tracking', () => {
  let bookId;
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Dune', 'Frank Herbert', 400);
    bookId = await getFirstBookId(page);
  });

  test('progress percent is 0 before any update', async ({ page }) => {
    const text = await page.getByTestId(`progress-percent-${bookId}`).textContent();
    expect(parseInt(text, 10)).toBe(0);
  });

  test('progress percent reflects Math.round formula after update', async ({ page }) => {
    // 200 / 400 * 100 = exactly 50
    await page.getByTestId(`update-progress-input-${bookId}`).fill('200');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const text = await page.getByTestId(`progress-percent-${bookId}`).textContent();
    expect(parseInt(text, 10)).toBe(50);
  });

  test('currentPage is persisted in localStorage after update', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('150');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib = await getLibrary(page);
    expect(lib.books[0].currentPage).toBe(150);
  });

  test('increasing currentPage appends an ActivityEntry with correct shape', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib = await getLibrary(page);
    const entry = lib.activity.find(e => e.bookId === bookId);
    expect(entry).toBeDefined();
    expect(entry.pagesAdded).toBe(100);
    expect(typeof entry.id).toBe('string');
    expect(entry.id.length).toBeGreaterThan(0);
    expect(typeof entry.timestamp).toBe('string');
    expect(isNaN(Date.parse(entry.timestamp))).toBe(false);
  });

  test('pagesAdded is the delta from previous currentPage', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    await page.getByTestId(`update-progress-input-${bookId}`).fill('160');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib = await getLibrary(page);
    const entries = lib.activity.filter(e => e.bookId === bookId);
    expect(entries[0].pagesAdded).toBe(100);
    expect(entries[1].pagesAdded).toBe(60);
  });

  test('decreasing currentPage does not append a new ActivityEntry', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('200');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib1 = await getLibrary(page);
    const countBefore = lib1.activity.length;

    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    const lib2 = await getLibrary(page);
    expect(lib2.activity.length).toBe(countBefore);
  });
});

// ─── KR 5, 6, 7 — Shelves and finish flow ────────────────────────────────────

test.describe('KR 5, 6, 7 — Shelf and finish flow', () => {
  let bookId;
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Dune', 'Frank Herbert', 400);
    bookId = await getFirstBookId(page);
  });

  test('finishing a book moves it to Finished shelf', async ({ page }) => {
    await finishBook(page, bookId, 5, 'Loved it');
    await expect(page.getByTestId('shelf-finished').getByTestId(`book-card-${bookId}`)).toBeVisible();
    await expect(page.getByTestId('shelf-currently-reading').getByTestId(`book-card-${bookId}`)).not.toBeVisible();
  });

  test('finishing sets correct fields in localStorage', async ({ page }) => {
    await finishBook(page, bookId, 4, 'Very good');
    const lib = await getLibrary(page);
    const book = lib.books.find(b => b.id === bookId);
    expect(book.status).toBe('finished');
    expect(book.rating).toBe(4);
    expect(book.review).toBe('Very good');
    expect(book.currentPage).toBe(book.totalPages);
    expect(typeof book.finishedAt).toBe('string');
    expect(isNaN(Date.parse(book.finishedAt))).toBe(false);
  });

  test('progress controls are absent on a finished book', async ({ page }) => {
    await finishBook(page, bookId, 5, 'Great');
    await expect(page.getByTestId(`progress-bar-${bookId}`)).not.toBeVisible();
    await expect(page.getByTestId(`update-progress-input-${bookId}`)).not.toBeVisible();
    await expect(page.getByTestId(`mark-finished-${bookId}`)).not.toBeVisible();
  });

  test('return-to-reading is present only after finishing', async ({ page }) => {
    await expect(page.getByTestId(`return-to-reading-${bookId}`)).not.toBeVisible();
    await finishBook(page, bookId, 5, 'Great');
    await expect(page.getByTestId(`return-to-reading-${bookId}`)).toBeVisible();
  });

  test('return-to-reading clears finish fields and moves book to Currently Reading', async ({ page }) => {
    await finishBook(page, bookId, 3, 'OK');
    await page.getByTestId(`return-to-reading-${bookId}`).click();
    const lib = await getLibrary(page);
    const book = lib.books.find(b => b.id === bookId);
    expect(book.status).toBe('currently_reading');
    expect(book.rating).toBeNull();
    expect(book.review).toBeNull();
    expect(book.finishedAt).toBeNull();
    await expect(page.getByTestId('shelf-currently-reading').getByTestId(`book-card-${bookId}`)).toBeVisible();
  });

  test('return-to-reading does not change the ActivityEntry list', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    await finishBook(page, bookId, 5, 'Great');
    const lib1 = await getLibrary(page);
    const activityCount = lib1.activity.length;

    await page.getByTestId(`return-to-reading-${bookId}`).click();
    const lib2 = await getLibrary(page);
    expect(lib2.activity.length).toBe(activityCount);
  });
});

// ─── KR 18 — Inline validation: add-book form ────────────────────────────────

test.describe('KR 18 — Add-book validation', () => {
  test.beforeEach(({ page }) => clearAndReload(page));

  test('empty title prevents submission', async ({ page }) => {
    await page.getByTestId('field-author').fill('Author');
    await page.getByTestId('field-total-pages').fill('100');
    await page.getByTestId('submit-add-book').click();
    expect((await getLibrary(page)).books).toHaveLength(0);
  });

  test('whitespace-only title prevents submission', async ({ page }) => {
    await page.getByTestId('field-title').fill('   ');
    await page.getByTestId('field-author').fill('Author');
    await page.getByTestId('field-total-pages').fill('100');
    await page.getByTestId('submit-add-book').click();
    expect((await getLibrary(page)).books).toHaveLength(0);
  });

  test('empty author prevents submission', async ({ page }) => {
    await page.getByTestId('field-title').fill('Title');
    await page.getByTestId('field-total-pages').fill('100');
    await page.getByTestId('submit-add-book').click();
    expect((await getLibrary(page)).books).toHaveLength(0);
  });

  test('non-integer totalPages prevents submission', async ({ page }) => {
    await page.getByTestId('field-title').fill('Title');
    await page.getByTestId('field-author').fill('Author');
    await page.getByTestId('field-total-pages').fill('twelve');
    await page.getByTestId('submit-add-book').click();
    expect((await getLibrary(page)).books).toHaveLength(0);
  });

  test('zero totalPages prevents submission', async ({ page }) => {
    await page.getByTestId('field-title').fill('Title');
    await page.getByTestId('field-author').fill('Author');
    await page.getByTestId('field-total-pages').fill('0');
    await page.getByTestId('submit-add-book').click();
    expect((await getLibrary(page)).books).toHaveLength(0);
  });

  test('negative totalPages prevents submission', async ({ page }) => {
    await page.getByTestId('field-title').fill('Title');
    await page.getByTestId('field-author').fill('Author');
    await page.getByTestId('field-total-pages').fill('-5');
    await page.getByTestId('submit-add-book').click();
    expect((await getLibrary(page)).books).toHaveLength(0);
  });

  test('decimal totalPages prevents submission', async ({ page }) => {
    await page.getByTestId('field-title').fill('Title');
    await page.getByTestId('field-author').fill('Author');
    await page.getByTestId('field-total-pages').fill('1.5');
    await page.getByTestId('submit-add-book').click();
    expect((await getLibrary(page)).books).toHaveLength(0);
  });
});

// ─── KR 18 — Inline validation: update-progress ──────────────────────────────

test.describe('KR 18 — Update-progress validation', () => {
  let bookId;
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Book', 'Author', 100);
    bookId = await getFirstBookId(page);
  });

  test('value above totalPages is rejected', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('101');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    expect((await getLibrary(page)).books[0].currentPage).toBe(0);
  });

  test('negative value is rejected', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('-1');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    expect((await getLibrary(page)).books[0].currentPage).toBe(0);
  });

  test('value equal to totalPages is accepted (boundary)', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('100');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    expect((await getLibrary(page)).books[0].currentPage).toBe(100);
  });

  test('value of 0 is accepted (boundary)', async ({ page }) => {
    await page.getByTestId(`update-progress-input-${bookId}`).fill('50');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    await page.getByTestId(`update-progress-input-${bookId}`).fill('0');
    await page.getByTestId(`update-progress-submit-${bookId}`).click();
    // 0 is in valid range; currentPage should update
    expect((await getLibrary(page)).books[0].currentPage).toBe(0);
  });
});

// ─── KR 18 — Inline validation: finish form ──────────────────────────────────

test.describe('KR 18 — Finish-form validation', () => {
  let bookId;
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Book', 'Author', 100);
    bookId = await getFirstBookId(page);
    await page.getByTestId(`mark-finished-${bookId}`).click();
  });

  test('rating above 5 is rejected', async ({ page }) => {
    await page.getByTestId(`finish-rating-${bookId}`).fill('6');
    await page.getByTestId(`finish-review-${bookId}`).fill('Great');
    await page.getByTestId(`finish-submit-${bookId}`).click();
    expect((await getLibrary(page)).books[0].status).toBe('currently_reading');
  });

  test('rating of 0 is rejected', async ({ page }) => {
    await page.getByTestId(`finish-rating-${bookId}`).fill('0');
    await page.getByTestId(`finish-review-${bookId}`).fill('Great');
    await page.getByTestId(`finish-submit-${bookId}`).click();
    expect((await getLibrary(page)).books[0].status).toBe('currently_reading');
  });

  test('whitespace-only review is rejected', async ({ page }) => {
    await page.getByTestId(`finish-rating-${bookId}`).fill('4');
    await page.getByTestId(`finish-review-${bookId}`).fill('   ');
    await page.getByTestId(`finish-submit-${bookId}`).click();
    expect((await getLibrary(page)).books[0].status).toBe('currently_reading');
  });
});

// ─── KR 8, 9 — Search and filtering ──────────────────────────────────────────

test.describe('KR 8, 9 — Search and filtering', () => {
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Dune', 'Frank Herbert', 400);
    await addBook(page, '1984', 'George Orwell', 300);
  });

  test('author search is case-insensitive (KR 8)', async ({ page }) => {
    await page.getByTestId('search-input').fill('frank');
    await expect(page.locator('[data-testid^="book-card-"]').filter({ hasText: 'Dune' })).toBeVisible();
    await expect(page.locator('[data-testid^="book-card-"]').filter({ hasText: '1984' })).not.toBeVisible();
  });

  test('author search is a substring match (KR 8)', async ({ page }) => {
    await page.getByTestId('search-input').fill('ORWELL');
    await expect(page.locator('[data-testid^="book-card-"]').filter({ hasText: '1984' })).toBeVisible();
    await expect(page.locator('[data-testid^="book-card-"]').filter({ hasText: 'Dune' })).not.toBeVisible();
  });

  test('clearing search restores all books', async ({ page }) => {
    await page.getByTestId('search-input').fill('frank');
    await page.getByTestId('search-input').fill('');
    await expect(page.locator('[data-testid^="book-card-"]').filter({ hasText: 'Dune' })).toBeVisible();
    await expect(page.locator('[data-testid^="book-card-"]').filter({ hasText: '1984' })).toBeVisible();
  });

  test('rating filter does not exclude Currently Reading books (KR 9)', async ({ page }) => {
    // Finish one book with rating 3; the other stays Currently Reading
    const lib = await getLibrary(page);
    await finishBook(page, lib.books[0].id, 3, 'OK');
    // Filter by rating 5 — no finished book matches, but Currently Reading must still appear
    await page.getByTestId('filter-rating').selectOption('5');
    await expect(
      page.getByTestId('shelf-currently-reading').locator('[data-testid^="book-card-"]')
    ).toBeVisible();
  });

  test('year filter does not exclude Currently Reading books (KR 9)', async ({ page }) => {
    // Finish one book; it acquires a finishedAt in the current year
    const lib = await getLibrary(page);
    await finishBook(page, lib.books[0].id, 4, 'Good');
    const currentYear = String(new Date().getFullYear());
    await page.getByTestId('filter-year').selectOption(currentYear);
    // The still-reading book must remain visible
    await expect(
      page.getByTestId('shelf-currently-reading').locator('[data-testid^="book-card-"]')
    ).toBeVisible();
  });

  test('author filter applies across both shelves (KR 9)', async ({ page }) => {
    // Finish Frank Herbert's book; George Orwell stays Currently Reading
    const lib = await getLibrary(page);
    const herbertId = lib.books.find(b => b.author === 'Frank Herbert').id;
    await finishBook(page, herbertId, 5, 'Epic');
    // Filter to Frank Herbert only
    await page.getByTestId('filter-author').selectOption('Frank Herbert');
    // Finished shelf shows Herbert's book
    await expect(page.getByTestId('shelf-finished').locator('[data-testid^="book-card-"]')).toBeVisible();
    // Currently Reading shelf hides Orwell's book (different author, AND logic)
    await expect(
      page.getByTestId('shelf-currently-reading').locator('[data-testid^="book-card-"]')
    ).not.toBeVisible();
  });
});

// ─── KR 10, 12 — Stats ───────────────────────────────────────────────────────

test.describe('KR 10, 12 — Stats dashboard', () => {
  test.beforeEach(({ page }) => clearAndReload(page));

  test('all stat values start at 0 with no finished books', async ({ page }) => {
    await expect(page.getByTestId('stats-books-finished-this-year')).toContainText('0');
    await expect(page.getByTestId('stats-total-pages-this-year')).toContainText('0');
    await expect(page.getByTestId('stats-total-pages-all')).toContainText('0');
  });

  test('stats update immediately after finishing a book (KR 12)', async ({ page }) => {
    await addBook(page, 'Moby Dick', 'Melville', 250);
    const id = await getFirstBookId(page);
    await finishBook(page, id, 5, 'Classic');
    await expect(page.getByTestId('stats-books-finished-this-year')).toContainText('1');
    await expect(page.getByTestId('stats-total-pages-this-year')).toContainText('250');
    await expect(page.getByTestId('stats-total-pages-all')).toContainText('250');
    await expect(page.getByTestId('stats-average-length-this-year')).toContainText('250');
  });

  test('stats-total-pages-all counts only finished books', async ({ page }) => {
    // Add two books; finish only one
    await addBook(page, 'Book A', 'Author', 100);
    await addBook(page, 'Book B', 'Author', 200);
    const lib = await getLibrary(page);
    await finishBook(page, lib.books[0].id, 4, 'Good');
    // total-pages-all should reflect only the finished book
    await expect(page.getByTestId('stats-total-pages-all')).toContainText('100');
  });

  test('pages-per-week chart element is present and visible', async ({ page }) => {
    await expect(page.getByTestId('stats-pages-per-week-chart')).toBeVisible();
  });
});

// ─── KR 13 — Persistence ─────────────────────────────────────────────────────

test.describe('KR 13 — localStorage persistence', () => {
  test('books and activity persist under key "reading-journal" across reload', async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Persistent', 'Author', 200);
    const id = await getFirstBookId(page);
    await page.getByTestId(`update-progress-input-${id}`).fill('80');
    await page.getByTestId(`update-progress-submit-${id}`).click();

    // Verify the key and structure before reload
    const raw = await page.evaluate(() => localStorage.getItem('reading-journal'));
    expect(raw).not.toBeNull();
    const stored = JSON.parse(raw);
    expect(Array.isArray(stored.books)).toBe(true);
    expect(Array.isArray(stored.activity)).toBe(true);

    // Reload and verify data survived
    await page.reload();
    const lib = await getLibrary(page);
    expect(lib.books).toHaveLength(1);
    expect(lib.books[0].id).toBe(id);
    expect(lib.books[0].currentPage).toBe(80);
    expect(lib.activity.length).toBeGreaterThan(0);
    await expect(page.getByTestId(`book-card-${id}`)).toBeVisible();
  });
});

// ─── KR 16 — Reset ────────────────────────────────────────────────────────────

test.describe('KR 16 — Reset all data', () => {
  test.beforeEach(async ({ page }) => {
    await clearAndReload(page);
    await addBook(page, 'Book', 'Author', 100);
  });

  test('reset-confirm is not visible before reset-library is clicked', async ({ page }) => {
    await expect(page.getByTestId('reset-confirm')).not.toBeVisible();
  });

  test('reset-confirm becomes visible after clicking reset-library', async ({ page }) => {
    await page.getByTestId('reset-library').click();
    await expect(page.getByTestId('reset-confirm')).toBeVisible();
  });

  test('confirming reset clears all books and activity', async ({ page }) => {
    await page.getByTestId('reset-library').click();
    await page.getByTestId('reset-confirm').click();
    const lib = await getLibrary(page);
    expect(lib.books).toHaveLength(0);
    expect(lib.activity ?? []).toHaveLength(0);
    await expect(page.locator('[data-testid^="book-card-"]')).toHaveCount(0);
  });
});

// ─── KR 17 — Responsive layout ───────────────────────────────────────────────

test.describe('KR 17 — Responsive layout', () => {
  test('no horizontal scroll at 320px viewport', async ({ page }) => {
    await page.setViewportSize({ width: 320, height: 667 });
    await page.goto(BASE_URL);
    await page.evaluate(() => localStorage.clear());
    await page.reload();
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth
    );
    expect(overflow).toBeLessThanOrEqual(0);
  });

  test('no horizontal scroll at 1024px viewport', async ({ page }) => {
    await page.setViewportSize({ width: 1024, height: 768 });
    await page.goto(BASE_URL);
    await page.evaluate(() => localStorage.clear());
    await page.reload();
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth
    );
    expect(overflow).toBeLessThanOrEqual(0);
  });
});
