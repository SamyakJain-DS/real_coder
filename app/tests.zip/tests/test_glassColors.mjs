/**
 * Tests for glassColors.js
 * Covers: GLASS_COLORS named export
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';

const MODULE_PATH = new URL('../glassColors.js', import.meta.url).href;

async function loadModule() {
  try {
    return await import(MODULE_PATH);
  } catch {
    return null;
  }
}

// --- Array structure ----------------------------------------------------------

test('glassColors: GLASS_COLORS array is frozen', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('glassColors.js has not been implemented');
  assert.ok(Object.isFrozen(mod.GLASS_COLORS), 'GLASS_COLORS array is not frozen');
});

// --- Entry structure ----------------------------------------------------------

test('glassColors: every entry is frozen', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('glassColors.js has not been implemented');
  for (let i = 0; i < mod.GLASS_COLORS.length; i++) {
    assert.ok(Object.isFrozen(mod.GLASS_COLORS[i]), `Entry ${i} is not frozen`);
  }
});

// --- Specific entries (spot-check from spec table) ----------------------------

test('glassColors: all 24 entries match the spec table exactly', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('glassColors.js has not been implemented');

  assert.equal(mod.GLASS_COLORS.length, 24, 'GLASS_COLORS should have exactly 24 entries');

  const EXPECTED = [
    { name: 'Ruby Red',     r: 224, g:  17, b:  95, hex: '#e0115f' },
    { name: 'Crimson',      r: 220, g:  20, b:  60, hex: '#dc143c' },
    { name: 'Coral',        r: 255, g: 127, b:  80, hex: '#ff7f50' },
    { name: 'Tangerine',    r: 242, g: 133, b:   0, hex: '#f28500' },
    { name: 'Amber',        r: 255, g: 191, b:   0, hex: '#ffbf00' },
    { name: 'Gold',         r: 255, g: 215, b:   0, hex: '#ffd700' },
    { name: 'Sunflower',    r: 255, g: 200, b:  40, hex: '#ffc828' },
    { name: 'Emerald',      r:  80, g: 200, b: 120, hex: '#50c878' },
    { name: 'Forest Green', r:  34, g: 139, b:  34, hex: '#228b22' },
    { name: 'Mint',         r: 152, g: 255, b: 152, hex: '#98ff98' },
    { name: 'Sky Blue',     r: 135, g: 206, b: 235, hex: '#87ceeb' },
    { name: 'Cobalt Blue',  r:   0, g:  71, b: 171, hex: '#0047ab' },
    { name: 'Sapphire',     r:  15, g:  82, b: 186, hex: '#0f52ba' },
    { name: 'Royal Purple', r: 120, g:  81, b: 169, hex: '#7851a9' },
    { name: 'Amethyst',     r: 153, g: 102, b: 204, hex: '#9966cc' },
    { name: 'Lavender',     r: 230, g: 230, b: 250, hex: '#e6e6fa' },
    { name: 'Rose Pink',    r: 255, g: 102, b: 204, hex: '#ff66cc' },
    { name: 'Bronze',       r: 205, g: 127, b:  50, hex: '#cd7f32' },
    { name: 'Copper',       r: 184, g: 115, b:  51, hex: '#b87333' },
    { name: 'Charcoal',     r:  54, g:  69, b:  79, hex: '#36454f' },
    { name: 'Onyx',         r:  53, g:  56, b:  57, hex: '#353839' },
    { name: 'Snow White',   r: 255, g: 250, b: 250, hex: '#fffafa' },
    { name: 'Ivory',        r: 255, g: 255, b: 240, hex: '#fffff0' },
    { name: 'Clear',        r: 240, g: 255, b: 255, hex: '#f0ffff' },
  ];

  for (let i = 0; i < EXPECTED.length; i++) {
    const exp   = EXPECTED[i];
    const entry = mod.GLASS_COLORS[i];
    assert.equal(entry.name, exp.name,  `Entry ${i} name`);
    assert.equal(entry.r,    exp.r,     `Entry ${i} r`);
    assert.equal(entry.g,    exp.g,     `Entry ${i} g`);
    assert.equal(entry.b,    exp.b,     `Entry ${i} b`);
    assert.equal(entry.hex,  exp.hex,   `Entry ${i} hex`);
  }
});