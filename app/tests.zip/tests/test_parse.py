import pytest

from nacha import parse_file
from nacha.model import (
    NachaFile, Batch, Entry,
    FileHeader, BatchHeader, EntryDetail, Addenda, BatchControl, FileControl,
)

from tests.helpers import (
    build_file_text,
    simple_credit_entry,
    simple_debit_entry,
    make_iat_addenda,
)


# ---------------------------------------------------------------------------
# Structural shape of the parsed result
# ---------------------------------------------------------------------------

def test_parse_returns_nacha_file_instance():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    result = parse_file(text)
    assert isinstance(result, NachaFile)


def test_parse_exposes_file_header_and_control():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    result = parse_file(text)
    assert isinstance(result.file_header, FileHeader)
    assert isinstance(result.file_control, FileControl)


def test_parse_exposes_batches_list():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
        {"sec_code": "CCD", "entries": [simple_credit_entry()]},
    ])
    result = parse_file(text)
    assert isinstance(result.batches, list)
    assert len(result.batches) == 2
    for b in result.batches:
        assert isinstance(b, Batch)
        assert isinstance(b.batch_header, BatchHeader)
        assert isinstance(b.batch_control, BatchControl)
        assert isinstance(b.entries, list)


def test_parse_exposes_entry_and_addenda_objects():
    text = build_file_text([
        {
            "sec_code": "PPD",
            "entries": [
                {**simple_credit_entry(),
                 "addenda": [("05", "REMITTANCE INFO")]},
            ],
        },
    ])
    result = parse_file(text)
    batch = result.batches[0]
    assert len(batch.entries) == 1
    entry = batch.entries[0]
    assert isinstance(entry, Entry)
    assert isinstance(entry.entry_detail, EntryDetail)
    assert isinstance(entry.addenda, list)
    assert len(entry.addenda) == 1
    assert isinstance(entry.addenda[0], Addenda)


# ---------------------------------------------------------------------------
# Line terminator preservation
# ---------------------------------------------------------------------------

def test_parse_preserves_lf_line_terminator():
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry()]}],
        line_terminator="\n",
    )
    result = parse_file(text)
    assert result.line_terminator == "\n"


def test_parse_preserves_crlf_line_terminator():
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry()]}],
        line_terminator="\r\n",
    )
    result = parse_file(text)
    assert result.line_terminator == "\r\n"


# ---------------------------------------------------------------------------
# Block padding preservation
# ---------------------------------------------------------------------------

def test_parse_preserves_block_padding_lines():
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry()]}],
        pad_to_block=True,
    )
    result = parse_file(text)
    # Padding lines exist and each is a 94-character all-9 line.
    assert isinstance(result.block_padding, list)
    assert len(result.block_padding) > 0
    for pad in result.block_padding:
        assert len(pad) == 94
        assert set(pad) == {"9"}


def test_parse_no_block_padding_when_file_is_unpadded():
    # Construct a file whose record count is already a multiple of 10 so
    # there is no trailing padding to preserve.
    text = build_file_text(
        [
            {"sec_code": "PPD",
             "entries": [simple_credit_entry() for _ in range(6)]},
        ],
        pad_to_block=True,
    )
    # 1 header + 1 batch header + 6 entries + 1 batch control + 1 file control = 10
    result = parse_file(text)
    assert result.block_padding == []


# ---------------------------------------------------------------------------
# SEC code coverage
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("sec_code,entry_factory", [
    ("PPD", lambda: simple_credit_entry()),
    ("CCD", lambda: simple_credit_entry()),
    ("WEB", lambda: simple_credit_entry()),
    ("TEL", lambda: simple_credit_entry()),
    ("ARC", lambda: simple_debit_entry()),
    ("BOC", lambda: simple_debit_entry()),
    ("POP", lambda: simple_debit_entry()),
    ("RCK", lambda: simple_debit_entry()),
])
def test_parse_accepts_all_simple_sec_codes(sec_code, entry_factory):
    text = build_file_text([
        {"sec_code": sec_code, "entries": [entry_factory()]},
    ])
    result = parse_file(text)
    assert result.batches[0].batch_header.sec_code == sec_code


def test_parse_accepts_ctx_with_multiple_type_05_addenda():
    addenda = [("05", f"PAYLOAD {i}") for i in range(5)]
    text = build_file_text([
        {"sec_code": "CTX",
         "entries": [{**simple_credit_entry(), "addenda": addenda}]},
    ])
    result = parse_file(text)
    entry = result.batches[0].entries[0]
    assert len(entry.addenda) == 5
    for a in entry.addenda:
        assert a.addenda_type_code == "05"


def test_parse_accepts_iat_with_seven_mandatory_addenda():
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(),
                      "addenda": make_iat_addenda()}]},
    ])
    result = parse_file(text)
    entry = result.batches[0].entries[0]
    type_codes = [a.addenda_type_code for a in entry.addenda]
    assert type_codes == ["10", "11", "12", "13", "14", "15", "16"]


def test_parse_accepts_iat_with_seventeen_addenda():
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(),
                      "addenda": make_iat_addenda(extra=("17",))}]},
    ])
    result = parse_file(text)
    entry = result.batches[0].entries[0]
    type_codes = [a.addenda_type_code for a in entry.addenda]
    assert type_codes == ["10", "11", "12", "13", "14", "15", "16", "17"]


def test_parse_accepts_iat_with_seventeen_and_eighteen_addenda():
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(),
                      "addenda": make_iat_addenda(extra=("17", "18"))}]},
    ])
    result = parse_file(text)
    entry = result.batches[0].entries[0]
    type_codes = [a.addenda_type_code for a in entry.addenda]
    assert type_codes == ["10", "11", "12", "13", "14", "15", "16", "17", "18"]


def test_parse_accepts_ppd_with_one_addenda_when_indicator_is_1():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [{**simple_credit_entry(),
                      "addenda_indicator": "1",
                      "addenda": [("05", "REMIT")]}]},
    ])
    result = parse_file(text)
    entry = result.batches[0].entries[0]
    assert entry.entry_detail.addenda_record_indicator == "1"
    assert len(entry.addenda) == 1


def test_parse_accepts_ppd_with_zero_addenda_when_indicator_is_0():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [{**simple_credit_entry(),
                      "addenda_indicator": "0"}]},
    ])
    result = parse_file(text)
    entry = result.batches[0].entries[0]
    assert entry.entry_detail.addenda_record_indicator == "0"
    assert entry.addenda == []


@pytest.mark.parametrize("sec_code", ["ARC", "BOC", "POP", "RCK"])
def test_parse_accepts_arc_boc_pop_rck_with_zero_addenda(sec_code):
    text = build_file_text([
        {"sec_code": sec_code,
         "entries": [{**simple_debit_entry(), "addenda_indicator": "0"}]},
    ])
    result = parse_file(text)
    entry = result.batches[0].entries[0]
    assert entry.addenda == []


# ---------------------------------------------------------------------------
# Field exposure on parsed records
# ---------------------------------------------------------------------------

def test_parse_preserves_entry_amount_as_int_cents():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [simple_credit_entry(amount=12345)]},
    ])
    result = parse_file(text)
    entry = result.batches[0].entries[0]
    assert entry.entry_detail.amount == 12345


def test_parse_preserves_entry_transaction_code():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [{**simple_credit_entry(), "transaction_code": "27"}]},
    ])
    result = parse_file(text)
    assert result.batches[0].entries[0].entry_detail.transaction_code == "27"


def test_parse_ordering_of_batches_and_entries_matches_source():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [
             simple_credit_entry(amount=100),
             simple_credit_entry(amount=200),
             simple_credit_entry(amount=300),
         ]},
        {"sec_code": "CCD",
         "entries": [
             simple_credit_entry(amount=400),
             simple_credit_entry(amount=500),
         ]},
    ])
    result = parse_file(text)
    assert [e.entry_detail.amount for e in result.batches[0].entries] == \
        [100, 200, 300]
    assert [e.entry_detail.amount for e in result.batches[1].entries] == \
        [400, 500]


# ---------------------------------------------------------------------------
# Gap 7: Addenda.payload is sliced from the correct line positions (4-83)
# ---------------------------------------------------------------------------

def test_parse_addenda_payload_sliced_from_correct_line_positions():
    distinctive_payload = "A" * 20 + "B" * 40 + "C" * 20  # exactly 80 chars
    text = build_file_text([
        {"sec_code": "CTX",
         "entries": [{**simple_credit_entry(),
                      "addenda": [("05", distinctive_payload)]}]},
    ])
    result = parse_file(text)
    addenda = result.batches[0].entries[0].addenda[0]
    assert addenda.payload == distinctive_payload
    assert len(addenda.payload) == 80


# ---------------------------------------------------------------------------
# Gap #3: parse_file accepts a file with record count NOT a multiple of 10
# ---------------------------------------------------------------------------

def test_parse_accepts_unpadded_file_with_record_count_not_multiple_of_10():
    from nacha import serialize_file
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry()]}],
        pad_to_block=False,
    )
    result = parse_file(text)
    assert result.block_padding == []
    assert serialize_file(result) == text