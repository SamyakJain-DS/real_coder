import pytest

from nacha import parse_file, NachaParseError

from tests.helpers import (
    build_file_text,
    simple_credit_entry,
    file_header_line,
    batch_header_line,
    entry_detail_line,
    batch_control_line,
    file_control_line,
)


def test_nacha_parse_error_is_an_exception():
    assert issubclass(NachaParseError, Exception)


def test_nacha_parse_error_carries_line_number():
    err = NachaParseError("boom", 7)
    assert err.line_number == 7


def test_parse_raises_when_line_not_94_chars():
    valid = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    lines = valid.split("\n")
    # Truncate the second line so it is not 94 characters.
    lines[1] = lines[1][:80]
    bad = "\n".join(lines)
    with pytest.raises(NachaParseError):
        parse_file(bad)


def test_parse_raises_when_file_does_not_start_with_record_type_1():
    # Build a syntactically-94-char first line whose record type is not '1'.
    not_a_header = "X" + " " * 93
    valid = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    lines = valid.split("\n")
    lines[0] = not_a_header
    bad = "\n".join(lines)
    with pytest.raises(NachaParseError):
        parse_file(bad)


def test_parse_raises_when_record_type_code_is_unrecognized():
    # Insert a line that starts with an unknown record type code (e.g. '3').
    fh = file_header_line()
    bh = batch_header_line()
    bogus = "3" + " " * 93
    ed = entry_detail_line()
    bc = batch_control_line()
    fc = file_control_line(block_count=1)
    bad = "\n".join([fh, bh, bogus, ed, bc, fc]) + "\n"
    with pytest.raises(NachaParseError):
        parse_file(bad)


def test_parse_error_line_number_is_1_based_for_bad_line():
    # Bad line is line 2 (1-based).
    valid = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    lines = valid.split("\n")
    lines[1] = "Z" + " " * 93  # unrecognized record type at line 2
    bad = "\n".join(lines)
    with pytest.raises(NachaParseError) as exc_info:
        parse_file(bad)
    assert exc_info.value.line_number == 2


# ---------------------------------------------------------------------------
# D7-4 / D8-6: NachaParseError stores the constructor message argument
# ---------------------------------------------------------------------------

def test_nacha_parse_error_carries_message():
    err = NachaParseError("line too short", 3)
    # The message supplied to the constructor must be recoverable.
    assert "line too short" in str(err)


# ---------------------------------------------------------------------------
# D8-7: parse_file raises NachaParseError with line_number=1 when the first
#        line does not carry record type code "1"
# ---------------------------------------------------------------------------

def test_parse_raises_with_line_number_1_for_non_type_1_first_line():
    not_a_header = "X" + " " * 93  # 94 chars, but record type is not "1"
    valid = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    lines = valid.split("\n")
    lines[0] = not_a_header
    bad = "\n".join(lines)
    with pytest.raises(NachaParseError) as exc_info:
        parse_file(bad)
    assert exc_info.value.line_number == 1
