import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

import java.io.*;
import java.lang.reflect.*;
import java.util.Arrays;
import java.util.Random;

/**
 * JUnit 5 test suite for the Java Data Compression Library.
 *
 * All classes are loaded via reflection so this file compiles and runs
 * (reporting failures) even when the implementation does not yet exist.
 *
 * Requirements covered:
 *  - LZ77Codec: encode, decode, getStats, round-trip, window-size bounds
 *  - HuffmanCodec: encode, decode, getStats, round-trip
 *  - DeflateCodec: encode, decode, getStats, round-trip
 *  - CompressionStats: all five public fields, compressionRatio formula
 *  - StreamingCompressor: compress, decompress, round-trip for all three codecs
 */
public class CompressionLibraryTest {

    // -------------------------------------------------------------------------
    // Reflection helpers
    // -------------------------------------------------------------------------

    private static Class<?> loadClass(String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    private static Object newInstance(Class<?> clazz) throws Exception {
        Constructor<?> ctor = clazz.getConstructor();
        return ctor.newInstance();
    }

    private static Object invoke(Object target, String methodName, Class<?>[] paramTypes, Object[] args)
            throws Exception {
        Method m = target.getClass().getMethod(methodName, paramTypes);
        return m.invoke(target, args);
    }

    private static Object invokeStatic(Class<?> clazz, String methodName, Class<?>[] paramTypes, Object[] args)
            throws Exception {
        Method m = clazz.getMethod(methodName, paramTypes);
        return m.invoke(null, args);
    }

    /** Encode via LZ77Codec.encode(byte[], int). */
    private byte[] lz77Encode(Object codec, byte[] input, int windowSize) throws Exception {
        return (byte[]) invoke(codec, "encode", new Class[]{byte[].class, int.class},
                new Object[]{input, windowSize});
    }

    /** Decode via LZ77Codec.decode(byte[]). */
    private byte[] lz77Decode(Object codec, byte[] encoded) throws Exception {
        return (byte[]) invoke(codec, "decode", new Class[]{byte[].class}, new Object[]{encoded});
    }

    /** Encode via HuffmanCodec.encode(byte[]). */
    private byte[] huffmanEncode(Object codec, byte[] input) throws Exception {
        return (byte[]) invoke(codec, "encode", new Class[]{byte[].class}, new Object[]{input});
    }

    /** Decode via HuffmanCodec.decode(byte[]). */
    private byte[] huffmanDecode(Object codec, byte[] encoded) throws Exception {
        return (byte[]) invoke(codec, "decode", new Class[]{byte[].class}, new Object[]{encoded});
    }

    /** Encode via DeflateCodec.encode(byte[]). */
    private byte[] deflateEncode(Object codec, byte[] input) throws Exception {
        return (byte[]) invoke(codec, "encode", new Class[]{byte[].class}, new Object[]{input});
    }

    /** Decode via DeflateCodec.decode(byte[]). */
    private byte[] deflateDecode(Object codec, byte[] encoded) throws Exception {
        return (byte[]) invoke(codec, "decode", new Class[]{byte[].class}, new Object[]{encoded});
    }

    // -------------------------------------------------------------------------
    // Test data helpers
    // -------------------------------------------------------------------------

    private static byte[] singleByte() {
        return new byte[]{(byte) 0x42};
    }

    private static byte[] identicalBytes(int len) {
        byte[] data = new byte[len];
        Arrays.fill(data, (byte) 0xAA);
        return data;
    }

    private static byte[] randomBytes(int len, long seed) {
        byte[] data = new byte[len];
        new Random(seed).nextBytes(data);
        return data;
    }

    private static byte[] repetitivePattern(int len) {
        byte[] pattern = "ABCABC".getBytes();
        byte[] data = new byte[len];
        for (int i = 0; i < len; i++) data[i] = pattern[i % pattern.length];
        return data;
    }

    // =========================================================================
    // 1. LZ77Codec Tests
    // =========================================================================

    @Nested
    @DisplayName("LZ77Codec")
    class LZ77CodecTests {

        private Class<?> lz77Class;

        @BeforeEach
        void loadClass() {
            lz77Class = CompressionLibraryTest.loadClass("compression.LZ77Codec");
            assertNotNull(lz77Class, "compression.LZ77Codec class must exist");
        }

        // -- 1.1 Round-trip correctness --

        @Test
        @DisplayName("LZ77 round-trip: single byte")
        void roundTripSingleByte() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] original = singleByte();
            byte[] encoded = lz77Encode(codec, original, 256);
            byte[] decoded = lz77Decode(codec, encoded);
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (single byte)");
        }

        @Test
        @DisplayName("LZ77 round-trip: all identical bytes")
        void roundTripIdenticalBytes() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] original = identicalBytes(512);
            byte[] encoded = lz77Encode(codec, original, 1024);
            byte[] decoded = lz77Decode(codec, encoded);
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (identical bytes)");
        }

        @Test
        @DisplayName("LZ77 round-trip: high-entropy random bytes")
        void roundTripRandomBytes() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] original = randomBytes(4096, 12345L);
            byte[] encoded = lz77Encode(codec, original, 32768);
            byte[] decoded = lz77Decode(codec, encoded);
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (random bytes)");
        }

        @Test
        @DisplayName("LZ77 round-trip: repetitive pattern")
        void roundTripRepetitivePattern() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] original = repetitivePattern(2048);
            byte[] encoded = lz77Encode(codec, original, 1024);
            byte[] decoded = lz77Decode(codec, encoded);
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (repetitive pattern)");
        }

        // -- 1.2 Window size boundaries --

        @Test
        @DisplayName("LZ77 round-trip: minimum window size 1")
        void roundTripWindowSizeOne() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] original = repetitivePattern(64);
            byte[] encoded = lz77Encode(codec, original, 1);
            byte[] decoded = lz77Decode(codec, encoded);
            assertArrayEquals(original, decoded,
                    "Round-trip must succeed with window size 1");
        }

        @Test
        @DisplayName("LZ77 round-trip: maximum window size 32768")
        void roundTripWindowSizeMax() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] original = randomBytes(1024, 99999L);
            byte[] encoded = lz77Encode(codec, original, 32768);
            byte[] decoded = lz77Decode(codec, encoded);
            assertArrayEquals(original, decoded,
                    "Round-trip must succeed with window size 32768");
        }

        // -- 1.3 Statistics after encode --

        @Test
        @DisplayName("LZ77 stats.originalSize equals input length after encode")
        void statsOriginalSizeAfterEncode() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] input = repetitivePattern(300);
            lz77Encode(codec, input, 512);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            assertEquals(input.length, originalSize,
                    "originalSize must equal the length of the input byte array");
        }

        @Test
        @DisplayName("LZ77 stats.compressedSize equals encoded array length after encode")
        void statsCompressedSizeAfterEncode() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] input = repetitivePattern(300);
            byte[] encoded = lz77Encode(codec, input, 512);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            assertEquals(encoded.length, compressedSize,
                    "compressedSize must equal the length of the encoded byte array");
        }

        @Test
        @DisplayName("LZ77 stats.compressionRatio matches originalSize/compressedSize")
        void statsCompressionRatioAfterEncode() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] input = repetitivePattern(512);
            lz77Encode(codec, input, 1024);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            double ratio = (double) stats.getClass().getField("compressionRatio").get(stats);
            assertEquals((double) originalSize / compressedSize, ratio, 1e-9,
                    "compressionRatio must equal originalSize / compressedSize");
        }

        @Test
        @DisplayName("LZ77 stats.encodingTimeMs is non-negative after encode")
        void statsEncodingTimeMsAfterEncode() throws Exception {
            Object codec = newInstance(lz77Class);
            lz77Encode(codec, randomBytes(1024, 1L), 512);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long encodingTimeMs = (long) stats.getClass().getField("encodingTimeMs").get(stats);
            assertTrue(encodingTimeMs >= 0,
                    "encodingTimeMs must be non-negative after encode");
        }

        @Test
        @DisplayName("LZ77 stats.decodingTimeMs is non-negative after decode")
        void statsDecodingTimeMsAfterDecode() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] encoded = lz77Encode(codec, randomBytes(1024, 2L), 512);
            lz77Decode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long decodingTimeMs = (long) stats.getClass().getField("decodingTimeMs").get(stats);
            assertTrue(decodingTimeMs >= 0,
                    "decodingTimeMs must be non-negative after decode");
        }

        // -- 1.4 Encode returns non-null, non-empty byte array --

        @Test
        @DisplayName("LZ77 encode returns non-null byte array")
        void encodeReturnsNonNull() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] result = lz77Encode(codec, randomBytes(256, 42L), 512);
            assertNotNull(result, "encode must return a non-null byte array");
            assertTrue(result.length > 0, "encode must return a non-empty byte array");
        }

        // -- 1.5 Statistics after decode --

        @Test
        @DisplayName("LZ77 stats.originalSize equals input length after decode")
        void statsOriginalSizeAfterDecode() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] input = repetitivePattern(300);
            byte[] encoded = lz77Encode(codec, input, 512);
            lz77Decode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            assertEquals(input.length, originalSize,
                    "originalSize must equal the input length after decode");
        }

        @Test
        @DisplayName("LZ77 stats.compressedSize equals encoded array length after decode")
        void statsCompressedSizeAfterDecode() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] input = repetitivePattern(300);
            byte[] encoded = lz77Encode(codec, input, 512);
            lz77Decode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            assertEquals(encoded.length, compressedSize,
                    "compressedSize must equal the length of the encoded byte array after decode");
        }

        @Test
        @DisplayName("LZ77 stats.compressionRatio matches originalSize/compressedSize after decode")
        void statsCompressionRatioAfterDecode() throws Exception {
            Object codec = newInstance(lz77Class);
            byte[] input = repetitivePattern(300);
            byte[] encoded = lz77Encode(codec, input, 512);
            lz77Decode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            double ratio = (double) stats.getClass().getField("compressionRatio").get(stats);
            assertEquals((double) originalSize / compressedSize, ratio, 1e-9,
                    "compressionRatio must equal originalSize / compressedSize after decode");
        }
    }

    // =========================================================================
    // 2. HuffmanCodec Tests
    // =========================================================================

    @Nested
    @DisplayName("HuffmanCodec")
    class HuffmanCodecTests {

        private Class<?> huffClass;

        @BeforeEach
        void loadClass() {
            huffClass = CompressionLibraryTest.loadClass("compression.HuffmanCodec");
            assertNotNull(huffClass, "compression.HuffmanCodec class must exist");
        }

        // -- 2.1 Round-trip correctness --

        @Test
        @DisplayName("Huffman round-trip: single byte")
        void roundTripSingleByte() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] original = singleByte();
            byte[] decoded = huffmanDecode(codec, huffmanEncode(codec, original));
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (single byte)");
        }

        @Test
        @DisplayName("Huffman round-trip: all identical bytes")
        void roundTripIdenticalBytes() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] original = identicalBytes(512);
            byte[] decoded = huffmanDecode(codec, huffmanEncode(codec, original));
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (identical bytes)");
        }

        @Test
        @DisplayName("Huffman round-trip: high-entropy random bytes")
        void roundTripRandomBytes() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] original = randomBytes(4096, 77777L);
            byte[] decoded = huffmanDecode(codec, huffmanEncode(codec, original));
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (random bytes)");
        }

        @Test
        @DisplayName("Huffman round-trip: repetitive pattern")
        void roundTripRepetitivePattern() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] original = repetitivePattern(2048);
            byte[] decoded = huffmanDecode(codec, huffmanEncode(codec, original));
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (repetitive pattern)");
        }

        // -- 2.2 Statistics after encode --

        @Test
        @DisplayName("Huffman stats.originalSize equals input length after encode")
        void statsOriginalSizeAfterEncode() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] input = repetitivePattern(300);
            huffmanEncode(codec, input);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            assertEquals(input.length, originalSize,
                    "originalSize must equal the input length after encode");
        }

        @Test
        @DisplayName("Huffman stats.compressedSize equals encoded array length after encode")
        void statsCompressedSizeAfterEncode() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] input = repetitivePattern(300);
            byte[] encoded = huffmanEncode(codec, input);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            assertEquals(encoded.length, compressedSize,
                    "compressedSize must equal the length of the encoded byte array");
        }

        @Test
        @DisplayName("Huffman stats.compressionRatio matches originalSize/compressedSize")
        void statsCompressionRatioAfterEncode() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] input = repetitivePattern(512);
            huffmanEncode(codec, input);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            double ratio = (double) stats.getClass().getField("compressionRatio").get(stats);
            assertEquals((double) originalSize / compressedSize, ratio, 1e-9,
                    "compressionRatio must equal originalSize / compressedSize");
        }

        @Test
        @DisplayName("Huffman stats.encodingTimeMs is non-negative after encode")
        void statsEncodingTimeMsAfterEncode() throws Exception {
            Object codec = newInstance(huffClass);
            huffmanEncode(codec, randomBytes(1024, 3L));
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long encodingTimeMs = (long) stats.getClass().getField("encodingTimeMs").get(stats);
            assertTrue(encodingTimeMs >= 0, "encodingTimeMs must be non-negative after encode");
        }

        @Test
        @DisplayName("Huffman stats.decodingTimeMs is non-negative after decode")
        void statsDecodingTimeMsAfterDecode() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] encoded = huffmanEncode(codec, randomBytes(1024, 4L));
            huffmanDecode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long decodingTimeMs = (long) stats.getClass().getField("decodingTimeMs").get(stats);
            assertTrue(decodingTimeMs >= 0, "decodingTimeMs must be non-negative after decode");
        }

        // -- 2.3 Encode produces non-null output --

        @Test
        @DisplayName("Huffman encode returns non-null byte array")
        void encodeReturnsNonNull() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] result = huffmanEncode(codec, randomBytes(256, 5L));
            assertNotNull(result, "encode must return a non-null byte array");
            assertTrue(result.length > 0, "encode must return a non-empty byte array");
        }

        // -- 2.4 Statistics after decode --

        @Test
        @DisplayName("Huffman stats.originalSize equals input length after decode")
        void statsOriginalSizeAfterDecode() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] input = repetitivePattern(300);
            byte[] encoded = huffmanEncode(codec, input);
            huffmanDecode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            assertEquals(input.length, originalSize,
                    "originalSize must equal the input length after decode");
        }

        @Test
        @DisplayName("Huffman stats.compressedSize equals encoded array length after decode")
        void statsCompressedSizeAfterDecode() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] input = repetitivePattern(300);
            byte[] encoded = huffmanEncode(codec, input);
            huffmanDecode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            assertEquals(encoded.length, compressedSize,
                    "compressedSize must equal the length of the encoded byte array after decode");
        }

        @Test
        @DisplayName("Huffman stats.compressionRatio matches originalSize/compressedSize after decode")
        void statsCompressionRatioAfterDecode() throws Exception {
            Object codec = newInstance(huffClass);
            byte[] input = repetitivePattern(300);
            byte[] encoded = huffmanEncode(codec, input);
            huffmanDecode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            double ratio = (double) stats.getClass().getField("compressionRatio").get(stats);
            assertEquals((double) originalSize / compressedSize, ratio, 1e-9,
                    "compressionRatio must equal originalSize / compressedSize after decode");
        }
    }

    // =========================================================================
    // 3. DeflateCodec Tests
    // =========================================================================

    @Nested
    @DisplayName("DeflateCodec")
    class DeflateCodecTests {

        private Class<?> deflateClass;

        @BeforeEach
        void loadClass() {
            deflateClass = CompressionLibraryTest.loadClass("compression.DeflateCodec");
            assertNotNull(deflateClass, "compression.DeflateCodec class must exist");
        }

        // -- 3.1 Round-trip correctness --

        @Test
        @DisplayName("Deflate round-trip: single byte")
        void roundTripSingleByte() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] original = singleByte();
            byte[] decoded = deflateDecode(codec, deflateEncode(codec, original));
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (single byte)");
        }

        @Test
        @DisplayName("Deflate round-trip: all identical bytes")
        void roundTripIdenticalBytes() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] original = identicalBytes(512);
            byte[] decoded = deflateDecode(codec, deflateEncode(codec, original));
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (identical bytes)");
        }

        @Test
        @DisplayName("Deflate round-trip: high-entropy random bytes")
        void roundTripRandomBytes() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] original = randomBytes(4096, 55555L);
            byte[] decoded = deflateDecode(codec, deflateEncode(codec, original));
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (random bytes)");
        }

        @Test
        @DisplayName("Deflate round-trip: repetitive pattern")
        void roundTripRepetitivePattern() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] original = repetitivePattern(2048);
            byte[] decoded = deflateDecode(codec, deflateEncode(codec, original));
            assertArrayEquals(original, decoded,
                    "Decoded output must be byte-identical to original (repetitive pattern)");
        }

        // -- 3.2 Statistics after encode --

        @Test
        @DisplayName("Deflate stats.originalSize equals input length after encode")
        void statsOriginalSizeAfterEncode() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] input = repetitivePattern(300);
            deflateEncode(codec, input);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            assertEquals(input.length, originalSize,
                    "originalSize must equal the input length after encode");
        }

        @Test
        @DisplayName("Deflate stats.compressedSize equals encoded array length after encode")
        void statsCompressedSizeAfterEncode() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] input = repetitivePattern(300);
            byte[] encoded = deflateEncode(codec, input);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            assertEquals(encoded.length, compressedSize,
                    "compressedSize must equal the length of the encoded byte array");
        }

        @Test
        @DisplayName("Deflate stats.compressionRatio matches originalSize/compressedSize")
        void statsCompressionRatioAfterEncode() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] input = repetitivePattern(512);
            deflateEncode(codec, input);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            double ratio = (double) stats.getClass().getField("compressionRatio").get(stats);
            assertEquals((double) originalSize / compressedSize, ratio, 1e-9,
                    "compressionRatio must equal originalSize / compressedSize");
        }

        @Test
        @DisplayName("Deflate stats.encodingTimeMs is non-negative after encode")
        void statsEncodingTimeMsAfterEncode() throws Exception {
            Object codec = newInstance(deflateClass);
            deflateEncode(codec, randomBytes(1024, 6L));
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long encodingTimeMs = (long) stats.getClass().getField("encodingTimeMs").get(stats);
            assertTrue(encodingTimeMs >= 0, "encodingTimeMs must be non-negative after encode");
        }

        @Test
        @DisplayName("Deflate stats.decodingTimeMs is non-negative after decode")
        void statsDecodingTimeMsAfterDecode() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] encoded = deflateEncode(codec, randomBytes(1024, 7L));
            deflateDecode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long decodingTimeMs = (long) stats.getClass().getField("decodingTimeMs").get(stats);
            assertTrue(decodingTimeMs >= 0, "decodingTimeMs must be non-negative after decode");
        }

        // -- 3.3 Statistics after decode --

        @Test
        @DisplayName("Deflate stats.originalSize equals input length after decode")
        void statsOriginalSizeAfterDecode() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] input = repetitivePattern(300);
            byte[] encoded = deflateEncode(codec, input);
            deflateDecode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            assertEquals(input.length, originalSize,
                    "originalSize must equal the input length after decode");
        }

        @Test
        @DisplayName("Deflate stats.compressedSize equals encoded array length after decode")
        void statsCompressedSizeAfterDecode() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] input = repetitivePattern(300);
            byte[] encoded = deflateEncode(codec, input);
            deflateDecode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            assertEquals(encoded.length, compressedSize,
                    "compressedSize must equal the length of the encoded byte array after decode");
        }

        @Test
        @DisplayName("Deflate stats.compressionRatio matches originalSize/compressedSize after decode")
        void statsCompressionRatioAfterDecode() throws Exception {
            Object codec = newInstance(deflateClass);
            byte[] input = repetitivePattern(300);
            byte[] encoded = deflateEncode(codec, input);
            deflateDecode(codec, encoded);
            Object stats = invoke(codec, "getStats", new Class[0], new Object[0]);
            assertNotNull(stats);
            long originalSize = (long) stats.getClass().getField("originalSize").get(stats);
            long compressedSize = (long) stats.getClass().getField("compressedSize").get(stats);
            double ratio = (double) stats.getClass().getField("compressionRatio").get(stats);
            assertEquals((double) originalSize / compressedSize, ratio, 1e-9,
                    "compressionRatio must equal originalSize / compressedSize after decode");
        }
    }

    // =========================================================================
    // 4. CompressionStats Tests
    // =========================================================================

    @Nested
    @DisplayName("CompressionStats")
    class CompressionStatsTests {

        private Class<?> statsClass;

        @BeforeEach
        void loadClass() {
            statsClass = CompressionLibraryTest.loadClass("compression.CompressionStats");
            assertNotNull(statsClass, "compression.CompressionStats class must exist");
        }

        @Test
        @DisplayName("CompressionStats has public field originalSize of type long")
        void hasFieldOriginalSize() throws Exception {
            Field f = statsClass.getField("originalSize");
            assertEquals(long.class, f.getType(),
                    "originalSize must be a public long field");
        }

        @Test
        @DisplayName("CompressionStats has public field compressedSize of type long")
        void hasFieldCompressedSize() throws Exception {
            Field f = statsClass.getField("compressedSize");
            assertEquals(long.class, f.getType(),
                    "compressedSize must be a public long field");
        }

        @Test
        @DisplayName("CompressionStats has public field compressionRatio of type double")
        void hasFieldCompressionRatio() throws Exception {
            Field f = statsClass.getField("compressionRatio");
            assertEquals(double.class, f.getType(),
                    "compressionRatio must be a public double field");
        }

        @Test
        @DisplayName("CompressionStats has public field encodingTimeMs of type long")
        void hasFieldEncodingTimeMs() throws Exception {
            Field f = statsClass.getField("encodingTimeMs");
            assertEquals(long.class, f.getType(),
                    "encodingTimeMs must be a public long field");
        }

        @Test
        @DisplayName("CompressionStats has public field decodingTimeMs of type long")
        void hasFieldDecodingTimeMs() throws Exception {
            Field f = statsClass.getField("decodingTimeMs");
            assertEquals(long.class, f.getType(),
                    "decodingTimeMs must be a public long field");
        }
    }

    // =========================================================================
    // 5. StreamingCompressor Tests
    // =========================================================================

    @Nested
    @DisplayName("StreamingCompressor")
    class StreamingCompressorTests {

        private Class<?> scClass;

        @BeforeEach
        void loadClass() {
            scClass = CompressionLibraryTest.loadClass("compression.StreamingCompressor");
            assertNotNull(scClass, "compression.StreamingCompressor class must exist");
        }

        // -- Round-trip for each supported codec --

        private byte[] streamingRoundTrip(String codec, byte[] data, int blockSize) throws Exception {
            ByteArrayOutputStream compressedOut = new ByteArrayOutputStream();
            invokeStatic(scClass, "compress",
                    new Class[]{InputStream.class, OutputStream.class, int.class, String.class},
                    new Object[]{new ByteArrayInputStream(data), compressedOut, blockSize, codec});

            ByteArrayOutputStream decompressedOut = new ByteArrayOutputStream();
            byte[] compressedBytes = compressedOut.toByteArray();
            invokeStatic(scClass, "decompress",
                    new Class[]{InputStream.class, OutputStream.class, String.class},
                    new Object[]{new ByteArrayInputStream(compressedBytes), decompressedOut, codec});

            return decompressedOut.toByteArray();
        }

        @Test
        @DisplayName("Streaming round-trip with 'lz77' codec")
        void streamingRoundTripLZ77() throws Exception {
            byte[] original = repetitivePattern(1024);
            byte[] recovered = streamingRoundTrip("lz77", original, 256);
            assertArrayEquals(original, recovered,
                    "Streaming lz77 round-trip must produce byte-identical output");
        }

        @Test
        @DisplayName("Streaming round-trip with 'huffman' codec")
        void streamingRoundTripHuffman() throws Exception {
            byte[] original = repetitivePattern(1024);
            byte[] recovered = streamingRoundTrip("huffman", original, 256);
            assertArrayEquals(original, recovered,
                    "Streaming huffman round-trip must produce byte-identical output");
        }

        @Test
        @DisplayName("Streaming round-trip with 'deflate' codec")
        void streamingRoundTripDeflate() throws Exception {
            byte[] original = repetitivePattern(1024);
            byte[] recovered = streamingRoundTrip("deflate", original, 256);
            assertArrayEquals(original, recovered,
                    "Streaming deflate round-trip must produce byte-identical output");
        }

        @Test
        @DisplayName("Streaming round-trip with data larger than block size (lz77)")
        void streamingMultipleBlocksLZ77() throws Exception {
            byte[] original = randomBytes(2048, 88888L);
            byte[] recovered = streamingRoundTrip("lz77", original, 300);
            assertArrayEquals(original, recovered,
                    "Streaming must handle multiple blocks correctly");
        }

        @Test
        @DisplayName("Streaming round-trip with data larger than block size (huffman)")
        void streamingMultipleBlocksHuffman() throws Exception {
            byte[] original = randomBytes(2048, 11111L);
            byte[] recovered = streamingRoundTrip("huffman", original, 300);
            assertArrayEquals(original, recovered,
                    "Streaming must handle multiple blocks correctly with huffman");
        }

        @Test
        @DisplayName("Streaming round-trip with data larger than block size (deflate)")
        void streamingMultipleBlocksDeflate() throws Exception {
            byte[] original = randomBytes(2048, 22222L);
            byte[] recovered = streamingRoundTrip("deflate", original, 300);
            assertArrayEquals(original, recovered,
                    "Streaming must handle multiple blocks correctly with deflate");
        }

        @Test
        @DisplayName("Streaming compress writes 4-byte big-endian length prefix per block")
        void streamingBlockLengthPrefix() throws Exception {
            byte[] original = repetitivePattern(500);
            int blockSize = 256;
            ByteArrayOutputStream compressedOut = new ByteArrayOutputStream();
            invokeStatic(scClass, "compress",
                    new Class[]{InputStream.class, OutputStream.class, int.class, String.class},
                    new Object[]{new ByteArrayInputStream(original), compressedOut, blockSize, "lz77"});

            byte[] compressedBytes = compressedOut.toByteArray();
            assertTrue(compressedBytes.length >= 4,
                    "Compressed output must start with at least a 4-byte block length header");

            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(compressedBytes));
            int firstBlockLen = dis.readInt();
            assertTrue(firstBlockLen > 0,
                    "First 4-byte big-endian int must be a positive block length");
            assertTrue(firstBlockLen <= compressedBytes.length - 4,
                    "First block length must not exceed the remaining bytes");
        }
    }
}