/**
 * Tests for eyedropper.js
 * Covers: getPixelColorAt and findClosestColors named exports
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';

const MODULE_PATH = new URL('../eyedropper.js', import.meta.url).href;

async function loadModule() {
  try {
    return await import(MODULE_PATH);
  } catch {
    return null;
  }
}

/** Build a mock canvas where getImageData returns given pixel bytes [r,g,b,a]. */
function makeMockCanvas(r, g, b, a, onGetImageData) {
  return {
    getContext: (_type) => ({
      getImageData: (x, y, w, h) => {
        if (onGetImageData) onGetImageData(x, y, w, h);
        return { data: [r, g, b, a] };
      }
    })
  };
}

/** Minimal palette for findClosestColors tests. */
const SAMPLE_PALETTE = [
  { name: 'Black',  r: 0,   g: 0,   b: 0,   hex: '#000000' },
  { name: 'White',  r: 255, g: 255, b: 255, hex: '#ffffff' },
  { name: 'Red',    r: 255, g: 0,   b: 0,   hex: '#ff0000' },
  { name: 'Green',  r: 0,   g: 255, b: 0,   hex: '#00ff00' },
  { name: 'Blue',   r: 0,   g: 0,   b: 255, hex: '#0000ff' },
];

// ─── getPixelColorAt ──────────────────────────────────────────────────────────

test('eyedropper: getPixelColorAt returns object with r, g, b, a properties', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  const canvas = makeMockCanvas(100, 150, 200, 255);
  const result = mod.getPixelColorAt(canvas, 5, 10);
  assert.equal(result.r, 100);
  assert.equal(result.g, 150);
  assert.equal(result.b, 200);
  assert.equal(result.a, 255);
});

test('eyedropper: getPixelColorAt uses Math.floor of the x,y coordinates', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  let calledX, calledY;
  const canvas = makeMockCanvas(10, 20, 30, 255, (x, y) => { calledX = x; calledY = y; });
  mod.getPixelColorAt(canvas, 3.9, 7.8);
  assert.equal(calledX, 3, `Expected floored x=3, got ${calledX}`);
  assert.equal(calledY, 7, `Expected floored y=7, got ${calledY}`);
});

test('eyedropper: getPixelColorAt reads exactly 1x1 pixel region', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  let calledW, calledH;
  const canvas = makeMockCanvas(0, 0, 0, 255, (_x, _y, w, h) => { calledW = w; calledH = h; });
  mod.getPixelColorAt(canvas, 0, 0);
  assert.equal(calledW, 1);
  assert.equal(calledH, 1);
});

// ─── findClosestColors ────────────────────────────────────────────────────────

test('eyedropper: findClosestColors returns array of requested count', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  const result = mod.findClosestColors({ r: 128, g: 128, b: 128 }, SAMPLE_PALETTE, 3);
  assert.equal(result.length, 3);
});

test('eyedropper: findClosestColors returns empty array when count is 0', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  const result = mod.findClosestColors({ r: 0, g: 0, b: 0 }, SAMPLE_PALETTE, 0);
  assert.equal(result.length, 0);
});

test('eyedropper: findClosestColors throws RangeError when count is negative', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  assert.throws(
    () => mod.findClosestColors({ r: 0, g: 0, b: 0 }, SAMPLE_PALETTE, -1),
    (err) => err instanceof RangeError
  );
});

test('eyedropper: findClosestColors RangeError message is exactly "Invalid count"', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  try {
    mod.findClosestColors({ r: 0, g: 0, b: 0 }, SAMPLE_PALETTE, -5);
    assert.fail('Expected RangeError');
  } catch (err) {
    assert.ok(err instanceof RangeError);
    assert.equal(err.message, 'Invalid count');
  }
});

test('eyedropper: findClosestColors results are sorted ascending by Euclidean distance', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  // Target is pure red: closest should be Red, then either Black or Blue, etc.
  const target = { r: 255, g: 0, b: 0 };
  const result = mod.findClosestColors(target, SAMPLE_PALETTE, 5);
  // Compute expected distances
  const distFn = (entry) =>
    Math.sqrt((target.r - entry.r) ** 2 + (target.g - entry.g) ** 2 + (target.b - entry.b) ** 2);
  for (let i = 0; i < result.length - 1; i++) {
    const d1 = distFn(result[i]);
    const d2 = distFn(result[i + 1]);
    assert.ok(d1 <= d2, `Results not sorted: dist[${i}]=${d1} > dist[${i+1}]=${d2}`);
  }
});

test('eyedropper: findClosestColors first result is nearest palette entry', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  // Target exactly matches Black
  const result = mod.findClosestColors({ r: 0, g: 0, b: 0 }, SAMPLE_PALETTE, 1);
  assert.equal(result[0].name, 'Black');
});

test('eyedropper: findClosestColors returns whole palette sorted when count >= palette.length', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  const target = { r: 128, g: 128, b: 128 };
  const result = mod.findClosestColors(target, SAMPLE_PALETTE, 100);

  // Correct length — entire palette returned
  assert.equal(result.length, SAMPLE_PALETTE.length);

  // Is a permutation of the full palette (every name from palette present)
  const resultNames  = result.map(e => e.name).sort();
  const paletteNames = SAMPLE_PALETTE.map(e => e.name).sort();
  assert.deepEqual(resultNames, paletteNames,
    'Returned entries should be a permutation of the full palette');

  // Sorted ascending by Euclidean distance
  const dist = (e) =>
    Math.sqrt((target.r - e.r) ** 2 + (target.g - e.g) ** 2 + (target.b - e.b) ** 2);
  for (let i = 0; i < result.length - 1; i++) {
    assert.ok(dist(result[i]) <= dist(result[i + 1]),
      `Results not sorted at index ${i}: dist=${dist(result[i])} > dist=${dist(result[i+1])}`);
  }
});

test('eyedropper: findClosestColors returns a new array and does not mutate palette', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  const paletteCopy = [...SAMPLE_PALETTE];
  const result = mod.findClosestColors({ r: 128, g: 128, b: 128 }, SAMPLE_PALETTE, 3);
  // Result is a new array instance
  assert.notEqual(result, SAMPLE_PALETTE);
  // Palette order unchanged
  for (let i = 0; i < paletteCopy.length; i++) {
    assert.equal(SAMPLE_PALETTE[i].name, paletteCopy[i].name);
  }
});

test('eyedropper: findClosestColors lower-index entry wins on equal distance', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('eyedropper.js has not been implemented');
  // Two palette entries equidistant from target
  const palette = [
    { name: 'A', r: 10, g: 0, b: 0, hex: '#0a0000' },  // dist = 10 from (0,0,0)
    { name: 'B', r: 0, g: 10, b: 0, hex: '#000a00' },  // dist = 10 from (0,0,0)
  ];
  const result = mod.findClosestColors({ r: 0, g: 0, b: 0 }, palette, 2);
  // Both have same distance; lower-index (A) must come first
  assert.equal(result[0].name, 'A');
  assert.equal(result[1].name, 'B');
});
