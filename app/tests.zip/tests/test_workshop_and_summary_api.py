from conftest import create_commission, money, request_json


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def workshop_session(**overrides):
    """Return a valid workshop session payload, with optional field overrides."""
    payload = {
        "sessionDate": "2026-05-09",
        "veneerCuts": [
            {
                "pieceName": "left outer rail",
                "templateName": "outer rail",
                "material": "walnut veneer",
                "quantityCut": 4,
            },
            {
                "pieceName": "field triangle",
                "templateName": "board point",
                "material": "holly veneer",
                "quantityCut": 12,
            },
        ],
        "checkerProduction": [
            {
                "checkerColor": "ivory",
                "material": "boxwood",
                "quantityTurned": 25,
                "quantityFinished": 20,
            },
            {
                "checkerColor": "black",
                "material": "ebony",
                "quantityTurned": 22,
                "quantityFinished": 18,
            },
        ],
        "hardwareInstallations": [
            hardware(1),
        ],
    }
    payload.update(overrides)
    return payload


def hardware(set_number, finish="brass"):
    return {
        "setNumber": set_number,
        "hingeFinish": finish,
        "claspFinish": finish,
        "diceMaterial": "bone",
        "diceSize": "16mm",
        "doublingCubeMaterial": "maple",
        "doublingCubeSize": "25mm",
    }


def add_session(base_url, commission_id, **overrides):
    status, body = request_json(
        base_url,
        "POST",
        f"/api/commissions/{commission_id}/workshop-sessions",
        workshop_session(**overrides),
    )
    assert status == 201, f"Expected 201 adding session, got {status}: {body}"
    return body


# ---------------------------------------------------------------------------
# Workshop session - creation and persistence
# ---------------------------------------------------------------------------

def test_workshop_session_entry_fields_are_all_persisted_and_returned(api_base_url):
    """All prompt-specified fields for veneerCuts, checkerProduction, and
    hardwareInstallations entries - including id fields - are persisted and
    returned in the session response."""
    commission = create_commission(api_base_url, plannedSetCount=2)

    payload = {
        "sessionDate": "2026-06-01",
        "veneerCuts": [
            {
                "pieceName": "left side panel",
                "templateName": "side panel",
                "material": "rosewood veneer",
                "quantityCut": 3,
            }
        ],
        "checkerProduction": [
            {
                "checkerColor": "cream",
                "material": "bone",
                "quantityTurned": 12,
                "quantityFinished": 8,
            }
        ],
        "hardwareInstallations": [
            {
                "setNumber": 1,
                "hingeFinish": "gold",
                "claspFinish": "silver",
                "diceMaterial": "ivory",
                "diceSize": "18mm",
                "doublingCubeMaterial": "ebony",
                "doublingCubeSize": "30mm",
            }
        ],
    }

    status, session = request_json(
        api_base_url,
        "POST",
        f"/api/commissions/{commission['id']}/workshop-sessions",
        payload,
    )

    assert status == 201, session
    assert isinstance(session.get("id"), int), "Session response must include an id field"
    assert session["sessionDate"] == "2026-06-01"

    # veneerCuts - all four prompt-specified fields plus id
    assert len(session["veneerCuts"]) == 1
    vc = session["veneerCuts"][0]
    assert isinstance(vc.get("id"), int), "veneerCut entry must include an id field"
    assert vc["pieceName"] == "left side panel"
    assert vc["templateName"] == "side panel"
    assert vc["material"] == "rosewood veneer"
    assert vc["quantityCut"] == 3

    # checkerProduction - all four prompt-specified fields plus id
    assert len(session["checkerProduction"]) == 1
    cp = session["checkerProduction"][0]
    assert isinstance(cp.get("id"), int), "checkerProduction entry must include an id field"
    assert cp["checkerColor"] == "cream"
    assert cp["material"] == "bone"
    assert cp["quantityTurned"] == 12
    assert cp["quantityFinished"] == 8

    # hardwareInstallations - all seven prompt-specified fields plus id
    assert len(session["hardwareInstallations"]) == 1
    hi = session["hardwareInstallations"][0]
    assert isinstance(hi.get("id"), int), "hardwareInstallation entry must include an id field"
    assert hi["setNumber"] == 1
    assert hi["hingeFinish"] == "gold"
    assert hi["claspFinish"] == "silver"
    assert hi["diceMaterial"] == "ivory"
    assert hi["diceSize"] == "18mm"
    assert hi["doublingCubeMaterial"] == "ebony"
    assert hi["doublingCubeSize"] == "30mm"


def test_add_workshop_session_returns_persisted_session(api_base_url):
    """POST workshop-sessions returns HTTP 201 with the full session structure."""
    commission = create_commission(api_base_url, plannedSetCount=2)

    status, session = request_json(
        api_base_url,
        "POST",
        f"/api/commissions/{commission['id']}/workshop-sessions",
        workshop_session(),
    )

    assert status == 201, session
    assert session["sessionDate"] == "2026-05-09"
    assert len(session["veneerCuts"]) == 2
    assert len(session["checkerProduction"]) == 2
    assert len(session["hardwareInstallations"]) == 1
    assert session["hardwareInstallations"][0]["setNumber"] == 1


def test_workshop_session_appears_in_commission_detail(api_base_url):
    """A posted workshop session is included in the GET /api/commissions/{id} response."""
    commission = create_commission(api_base_url, plannedSetCount=2)
    add_session(api_base_url, commission["id"])

    status, detail = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}"
    )

    assert status == 200, detail
    assert len(detail["workshopSessions"]) == 1
    session = detail["workshopSessions"][0]
    assert session["sessionDate"] == "2026-05-09"
    assert len(session["veneerCuts"]) == 2
    assert len(session["checkerProduction"]) == 2
    assert len(session["hardwareInstallations"]) == 1


# ---------------------------------------------------------------------------
# Workshop session - validation
# ---------------------------------------------------------------------------

def test_workshop_session_validates_negative_quantities(api_base_url):
    """Negative quantityCut, quantityTurned, or quantityFinished returns HTTP 400."""
    commission = create_commission(api_base_url, plannedSetCount=1)

    invalid_cases = [
        workshop_session(
            veneerCuts=[
                {"pieceName": "rail", "templateName": "outer rail",
                 "material": "walnut", "quantityCut": -1}
            ]
        ),
        workshop_session(
            checkerProduction=[
                {"checkerColor": "ivory", "material": "boxwood",
                 "quantityTurned": -1, "quantityFinished": 0}
            ]
        ),
        workshop_session(
            checkerProduction=[
                {"checkerColor": "ivory", "material": "boxwood",
                 "quantityTurned": 10, "quantityFinished": -1}
            ]
        ),
    ]

    for payload in invalid_cases:
        status, body = request_json(
            api_base_url,
            "POST",
            f"/api/commissions/{commission['id']}/workshop-sessions",
            payload,
        )
        assert status == 400, f"Expected 400 for negative quantity, got {status}: {body}"
        assert body["status"] == 400
        assert body["error"] == "Bad Request"
        assert isinstance(body.get("messages"), list) and body["messages"], body


def test_workshop_session_validates_set_number_out_of_range(api_base_url):
    """Hardware setNumber outside 1..plannedSetCount returns HTTP 400."""
    commission = create_commission(api_base_url, plannedSetCount=2)

    for bad_number in (0, 3):
        status, body = request_json(
            api_base_url,
            "POST",
            f"/api/commissions/{commission['id']}/workshop-sessions",
            workshop_session(hardwareInstallations=[hardware(bad_number)]),
        )
        assert status == 400, (
            f"Expected 400 for setNumber={bad_number} with plannedSetCount=2, "
            f"got {status}: {body}"
        )
        assert isinstance(body.get("messages"), list) and body["messages"], body


def test_workshop_session_accepts_zero_quantities(api_base_url):
    """quantityCut=0, quantityTurned=0, and quantityFinished=0 are >= 0 and must
    be accepted (HTTP 201). An implementation using > 0 instead of >= 0 would
    incorrectly reject sessions with zero-quantity entries."""
    commission = create_commission(api_base_url, plannedSetCount=1)

    status, session = request_json(
        api_base_url,
        "POST",
        f"/api/commissions/{commission['id']}/workshop-sessions",
        workshop_session(
            veneerCuts=[
                {"pieceName": "rail", "templateName": "outer rail",
                 "material": "walnut", "quantityCut": 0}
            ],
            checkerProduction=[
                {"checkerColor": "ivory", "material": "boxwood",
                 "quantityTurned": 0, "quantityFinished": 0}
            ],
        ),
    )

    assert status == 201, session


def test_workshop_session_rejects_duplicate_hardware_within_same_session(api_base_url):
    """Two hardware installations with the same setNumber in one session returns HTTP 400."""
    commission = create_commission(api_base_url, plannedSetCount=2)

    status, body = request_json(
        api_base_url,
        "POST",
        f"/api/commissions/{commission['id']}/workshop-sessions",
        workshop_session(hardwareInstallations=[hardware(1), hardware(1)]),
    )

    assert status == 400, body
    assert isinstance(body.get("messages"), list) and body["messages"], body


def test_workshop_session_rejects_duplicate_hardware_across_sessions(api_base_url):
    """A setNumber already installed in a prior session returns HTTP 400 in a new session."""
    commission = create_commission(api_base_url, plannedSetCount=2)
    add_session(api_base_url, commission["id"], hardwareInstallations=[hardware(1)])

    status, body = request_json(
        api_base_url,
        "POST",
        f"/api/commissions/{commission['id']}/workshop-sessions",
        workshop_session(
            sessionDate="2026-05-10",
            hardwareInstallations=[hardware(1)],
        ),
    )

    assert status == 400, body
    assert isinstance(body.get("messages"), list) and body["messages"], body


def test_workshop_session_validation_collects_multiple_failures(api_base_url):
    """Multiple session-level failures are all collected in a single HTTP 400 response."""
    commission = create_commission(api_base_url, plannedSetCount=1)

    # negative quantityCut AND setNumber out of range - both should be reported
    status, body = request_json(
        api_base_url,
        "POST",
        f"/api/commissions/{commission['id']}/workshop-sessions",
        workshop_session(
            veneerCuts=[
                {"pieceName": "rail", "templateName": "outer rail",
                 "material": "walnut", "quantityCut": -1}
            ],
            hardwareInstallations=[hardware(2)],   # setNumber=2 invalid for plannedSetCount=1
        ),
    )

    assert status == 400, body
    assert isinstance(body.get("messages"), list)
    assert len(body["messages"]) >= 2, (
        f"Expected at least 2 failure messages, got: {body['messages']}"
    )


def test_workshop_session_to_unknown_commission_returns_not_found(api_base_url):
    """POST workshop-sessions to an unknown commission id returns HTTP 404 with
    an ErrorResponse containing exactly one not-found message."""
    status, body = request_json(
        api_base_url,
        "POST",
        "/api/commissions/99999999/workshop-sessions",
        workshop_session(),
    )

    assert status == 404, body
    assert body["status"] == 404
    assert body["error"] == "Not Found"
    assert isinstance(body.get("messages"), list) and body["messages"], body
    assert len(body["messages"]) == 1, (
        f"404 ErrorResponse must contain exactly one message, got: {body['messages']}"
    )


def test_commission_existence_checked_before_session_validation(api_base_url):
    """HTTP 404 (commission not found) takes priority over session-level HTTP 400
    (invalid data). Sending invalid session data to a non-existent commission
    must return 404, not 400."""
    invalid_session = {
        "sessionDate": "2026-05-09",
        "veneerCuts": [
            {
                "pieceName": "rail",
                "templateName": "outer rail",
                "material": "walnut",
                "quantityCut": -1,  # invalid: negative quantity
            }
        ],
        "checkerProduction": [],
        "hardwareInstallations": [
            {
                "setNumber": 99,  # invalid: far outside any valid range
                "hingeFinish": "brass",
                "claspFinish": "brass",
                "diceMaterial": "bone",
                "diceSize": "16mm",
                "doublingCubeMaterial": "maple",
                "doublingCubeSize": "25mm",
            }
        ],
    }

    status, body = request_json(
        api_base_url,
        "POST",
        "/api/commissions/99999999/workshop-sessions",
        invalid_session,
    )

    assert status == 404, (
        f"Expected 404 (commission not found) despite invalid session data, got {status}: {body}"
    )
    assert body["status"] == 404
    assert body["error"] == "Not Found"
    assert len(body["messages"]) == 1


# ---------------------------------------------------------------------------
# Production summary - aggregation
# ---------------------------------------------------------------------------

def test_production_summary_aggregates_veneer_cuts_by_template(api_base_url):
    """veneerCutsByTemplate sums quantityCut per templateName across all sessions."""
    commission = create_commission(api_base_url, plannedSetCount=1)

    add_session(
        api_base_url,
        commission["id"],
        veneerCuts=[
            {"pieceName": "left rail", "templateName": "outer rail",
             "material": "walnut", "quantityCut": 4},
            {"pieceName": "triangle", "templateName": "board point",
             "material": "holly", "quantityCut": 12},
        ],
        hardwareInstallations=[hardware(1)],
    )
    add_session(
        api_base_url,
        commission["id"],
        sessionDate="2026-05-10",
        veneerCuts=[
            {"pieceName": "right rail", "templateName": "outer rail",
             "material": "walnut", "quantityCut": 2},
        ],
        hardwareInstallations=[],
    )

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    assert summary["veneerCutsByTemplate"]["outer rail"] == 6
    assert summary["veneerCutsByTemplate"]["board point"] == 12


def test_production_summary_aggregates_checkers_by_color(api_base_url):
    """checkersByColor sums quantityTurned and quantityFinished per color across sessions."""
    commission = create_commission(api_base_url, plannedSetCount=1)

    add_session(
        api_base_url,
        commission["id"],
        checkerProduction=[
            {"checkerColor": "ivory", "material": "boxwood",
             "quantityTurned": 10, "quantityFinished": 8},
        ],
        hardwareInstallations=[hardware(1)],
    )
    add_session(
        api_base_url,
        commission["id"],
        sessionDate="2026-05-10",
        checkerProduction=[
            {"checkerColor": "ivory", "material": "boxwood",
             "quantityTurned": 5, "quantityFinished": 4},
        ],
        hardwareInstallations=[],
    )

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    by_color = {e["checkerColor"]: e for e in summary["checkersByColor"]}
    assert by_color["ivory"]["totalTurned"] == 15
    assert by_color["ivory"]["totalFinished"] == 12


def test_production_summary_checkers_required_equals_planned_sets_times_thirty(api_base_url):
    """totalCheckersRequired is plannedSetCount * 30."""
    commission = create_commission(api_base_url, plannedSetCount=3)
    add_session(api_base_url, commission["id"],
                hardwareInstallations=[hardware(1)])

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    assert summary["totalCheckersRequired"] == 90  # 3 * 30


def test_production_summary_checkers_remaining_when_not_all_finished(api_base_url):
    """totalCheckersRemainingToFinish is totalCheckersRequired minus total finished when positive."""
    commission = create_commission(api_base_url, plannedSetCount=2)

    # Only finish 10 checkers; required = 60; remaining = 50
    add_session(
        api_base_url,
        commission["id"],
        checkerProduction=[
            {"checkerColor": "ivory", "material": "boxwood",
             "quantityTurned": 15, "quantityFinished": 10},
        ],
        hardwareInstallations=[hardware(1)],
    )

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    assert summary["totalCheckersRequired"] == 60
    assert summary["totalCheckersRemainingToFinish"] == 50


def test_production_summary_checkers_remaining_clamped_to_zero(api_base_url):
    """totalCheckersRemainingToFinish is 0 when finished quantity meets or exceeds required."""
    commission = create_commission(api_base_url, plannedSetCount=1)

    # Finish 40, but only 30 required -> clamp to 0
    add_session(
        api_base_url,
        commission["id"],
        checkerProduction=[
            {"checkerColor": "ivory", "material": "boxwood",
             "quantityTurned": 40, "quantityFinished": 40},
        ],
        hardwareInstallations=[hardware(1)],
    )

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    assert summary["totalCheckersRequired"] == 30
    assert summary["totalCheckersRemainingToFinish"] == 0


def test_production_summary_hardware_counts(api_base_url):
    """installedHardwareCount and remainingHardwareInstallations reflect installed sets."""
    commission = create_commission(api_base_url, plannedSetCount=3)

    # Install hardware for sets 1 and 2 only (set 3 still pending)
    add_session(
        api_base_url,
        commission["id"],
        hardwareInstallations=[hardware(1), hardware(2)],
    )

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    assert summary["installedHardwareCount"] == 2
    assert summary["remainingHardwareInstallations"] == 1


def test_production_summary_hardware_count_aggregates_across_sessions(api_base_url):
    """installedHardwareCount and remainingHardwareInstallations aggregate hardware
    installations across all sessions, not only the most recent session."""
    commission = create_commission(api_base_url, plannedSetCount=3)

    # Session 1: install hardware for set 1 only
    add_session(api_base_url, commission["id"],
                hardwareInstallations=[hardware(1)])
    # Session 2: install hardware for set 2 only
    add_session(api_base_url, commission["id"],
                sessionDate="2026-05-10",
                hardwareInstallations=[hardware(2)])

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    assert summary["installedHardwareCount"] == 2      # sets 1 and 2 across both sessions
    assert summary["remainingHardwareInstallations"] == 1  # set 3 still pending


def test_production_summary_includes_billing(api_base_url):
    """Production summary includes commissionId, plannedSetCount, and correct billing."""
    commission = create_commission(
        api_base_url,
        agreedQuote=5000.00,
        depositPaid=1250.25,
        plannedSetCount=1,
    )
    add_session(api_base_url, commission["id"], hardwareInstallations=[hardware(1)])

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    assert summary["commissionId"] == commission["id"]
    assert summary["plannedSetCount"] == 1
    assert money(summary["billing"]["agreedQuote"]) == money(5000.00)
    assert money(summary["billing"]["depositPaid"]) == money(1250.25)
    assert money(summary["billing"]["outstandingBalance"]) == money(3749.75)


def test_production_summary_for_unknown_commission_returns_not_found(api_base_url):
    """GET production-summary for an unknown commission id returns HTTP 404 with
    an ErrorResponse containing exactly one not-found message."""
    status, body = request_json(
        api_base_url, "GET", "/api/commissions/99999999/production-summary"
    )

    assert status == 404, body
    assert body["status"] == 404
    assert body["error"] == "Not Found"
    assert isinstance(body.get("messages"), list) and body["messages"], body
    assert len(body["messages"]) == 1, (
        f"404 ErrorResponse must contain exactly one message, got: {body['messages']}"
    )


def test_production_summary_with_no_sessions_returns_zero_baseline(api_base_url):
    """Production summary for a commission with no workshop sessions returns
    all aggregation fields at their zero/empty baseline values."""
    commission = create_commission(api_base_url, plannedSetCount=2)

    # Request summary immediately - no sessions added
    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    assert summary["commissionId"] == commission["id"]
    assert summary["plannedSetCount"] == 2
    assert summary["veneerCutsByTemplate"] == {}
    assert summary["checkersByColor"] == []
    assert summary["totalCheckersRequired"] == 60          # 2 * 30
    assert summary["totalCheckersRemainingToFinish"] == 60  # max(0, 60 - 0)
    assert summary["installedHardwareCount"] == 0
    assert summary["remainingHardwareInstallations"] == 2
    assert "billing" in summary


def test_get_commission_includes_full_nested_session_fields(api_base_url):
    """GET /api/commissions/{id} returns all prompt-specified field names and
    values for nested veneerCuts, checkerProduction, and hardwareInstallations
    entries, confirming the GET response is fully serialized."""
    commission = create_commission(api_base_url, plannedSetCount=2)

    session_payload = {
        "sessionDate": "2026-07-15",
        "veneerCuts": [
            {
                "pieceName": "center bar",
                "templateName": "bar template",
                "material": "maple veneer",
                "quantityCut": 6,
            }
        ],
        "checkerProduction": [
            {
                "checkerColor": "red",
                "material": "jasper",
                "quantityTurned": 8,
                "quantityFinished": 5,
            }
        ],
        "hardwareInstallations": [
            {
                "setNumber": 1,
                "hingeFinish": "antique brass",
                "claspFinish": "chrome",
                "diceMaterial": "jade",
                "diceSize": "20mm",
                "doublingCubeMaterial": "rosewood",
                "doublingCubeSize": "35mm",
            }
        ],
    }
    post_status, _ = request_json(
        api_base_url,
        "POST",
        f"/api/commissions/{commission['id']}/workshop-sessions",
        session_payload,
    )
    assert post_status == 201

    status, detail = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}"
    )

    assert status == 200, detail
    assert len(detail["workshopSessions"]) == 1
    session = detail["workshopSessions"][0]
    assert isinstance(session.get("id"), int)
    assert session["sessionDate"] == "2026-07-15"

    # Verify veneerCuts fields in GET response
    vc = session["veneerCuts"][0]
    assert isinstance(vc.get("id"), int)
    assert vc["pieceName"] == "center bar"
    assert vc["templateName"] == "bar template"
    assert vc["material"] == "maple veneer"
    assert vc["quantityCut"] == 6

    # Verify checkerProduction fields in GET response
    cp = session["checkerProduction"][0]
    assert isinstance(cp.get("id"), int)
    assert cp["checkerColor"] == "red"
    assert cp["material"] == "jasper"
    assert cp["quantityTurned"] == 8
    assert cp["quantityFinished"] == 5

    # Verify hardwareInstallations fields in GET response
    hi = session["hardwareInstallations"][0]
    assert isinstance(hi.get("id"), int)
    assert hi["setNumber"] == 1
    assert hi["hingeFinish"] == "antique brass"
    assert hi["claspFinish"] == "chrome"
    assert hi["diceMaterial"] == "jade"
    assert hi["diceSize"] == "20mm"
    assert hi["doublingCubeMaterial"] == "rosewood"
    assert hi["doublingCubeSize"] == "35mm"


def test_production_summary_checkers_remaining_sums_across_all_colors(api_base_url):
    """totalCheckersRemainingToFinish subtracts the sum of finished checkers
    across ALL colors, not per-color independently."""
    commission = create_commission(api_base_url, plannedSetCount=2)  # required = 60

    add_session(
        api_base_url,
        commission["id"],
        checkerProduction=[
            {"checkerColor": "ivory", "material": "boxwood",
             "quantityTurned": 15, "quantityFinished": 10},
            {"checkerColor": "black", "material": "ebony",
             "quantityTurned": 12, "quantityFinished": 8},
        ],
        hardwareInstallations=[hardware(1)],
    )

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )

    assert status == 200, summary
    assert summary["totalCheckersRequired"] == 60
    # ivory finished=10, black finished=8 -> total finished=18 -> remaining=60-18=42
    assert summary["totalCheckersRemainingToFinish"] == 42
