"""Tests for TaxAdministrationPlatform.generate_regulatory_report."""

from __future__ import annotations

from decimal import Decimal

import pytest

from _helpers import build_platform


def _processed_return(filer_category: str, total_tax: str) -> dict:
    return {
        "filer_id": "F",
        "filer_category": filer_category,
        "filing_period": "2024-01",
        "total_taxable_sales_usd": Decimal("0.00"),
        "total_exempt_sales_usd": Decimal("0.00"),
        "total_tax_due_usd": Decimal(total_tax),
        "jurisdiction_breakdown": [],
    }


def _selected_audit(audit_status: str) -> dict:
    return {
        "filer_id": "F",
        "rank": 1,
        "audit_status": audit_status,
        "selection_reason": "RISK=0;LIABILITY=0",
    }


def _collection_action(stage: str, liability: str) -> dict:
    return {
        "filer_id": "F",
        "collection_stage": stage,
        "collection_action": "SEND_NOTICE",
        "unpaid_liability_usd": Decimal(liability),
        "days_past_due": 1,
    }


def _refund_decision(decision: str, payable: str) -> dict:
    return {
        "claim_id": "C",
        "filer_id": "F",
        "decision": decision,
        "payable_amount_usd": Decimal(payable),
        "offset_amount_usd": Decimal("0.00"),
    }


# --------------------------------------------------------------------------- #
# Test ID: REP-01
# Requirement: Reporting #2 (top-level keys).
# --------------------------------------------------------------------------- #
def test_report_top_level_keys():
    try:
        platform = build_platform()
        report = platform.generate_regulatory_report(
            reporting_period="2024-Q1",
            generated_at="2024-04-01T00:00:00Z",
            processed_returns=[],
            selected_audits=[],
            collection_actions=[],
            refund_decisions=[],
        )

        for key in (
            "reporting_period",
            "filing_summary",
            "collection_summary",
            "audit_summary",
            "refund_summary",
            "ssuta_summary",
            "legislative_auditor_summary",
        ):
            assert key in report, f"missing key {key!r}"
        assert report["reporting_period"] == "2024-Q1"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-02
# Requirement: Reporting #3 (filing_summary contents) and #9 (filer_mix_counts
#   includes every enum key with default 0).
# --------------------------------------------------------------------------- #
def test_report_filing_summary():
    try:
        platform = build_platform()
        processed = [
            _processed_return("IN_STATE_RETAILER", "10.00"),
            _processed_return("IN_STATE_RETAILER", "5.50"),
            _processed_return("REMOTE_SELLER", "20.00"),
        ]
        report = platform.generate_regulatory_report(
            reporting_period="2024-Q2",
            generated_at="2024-07-01",
            processed_returns=processed,
            selected_audits=[],
            collection_actions=[],
            refund_decisions=[],
        )
        fs = report["filing_summary"]

        assert fs["total_returns_processed"] == 3
        assert Decimal(fs["total_tax_due_usd"]) == Decimal("35.50")
        assert set(fs["filer_mix_counts"].keys()) == {
            "IN_STATE_RETAILER",
            "REMOTE_SELLER",
            "MARKETPLACE_FACILITATOR",
            "USE_TAX_FILER",
        }
        assert fs["filer_mix_counts"]["IN_STATE_RETAILER"] == 2
        assert fs["filer_mix_counts"]["REMOTE_SELLER"] == 1
        assert fs["filer_mix_counts"]["MARKETPLACE_FACILITATOR"] == 0
        assert fs["filer_mix_counts"]["USE_TAX_FILER"] == 0
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-03
# Requirement: Reporting #4 (collection_summary) and #9 (stage_counts has
#   every collection-stage enum key).
# --------------------------------------------------------------------------- #
def test_report_collection_summary():
    try:
        platform = build_platform()
        actions = [
            _collection_action("NOTICE", "100.00"),
            _collection_action("NOTICE", "50.00"),
            _collection_action("PAYMENT_PLAN", "25.00"),
        ]
        report = platform.generate_regulatory_report(
            reporting_period="2024-Q2",
            generated_at="2024-07-01",
            processed_returns=[],
            selected_audits=[],
            collection_actions=actions,
            refund_decisions=[],
        )
        cs = report["collection_summary"]

        assert Decimal(cs["total_unpaid_liability_usd"]) == Decimal("175.00")
        assert set(cs["stage_counts"].keys()) == {"NOTICE", "PAYMENT_PLAN", "ENFORCEMENT"}
        assert cs["stage_counts"]["NOTICE"] == 2
        assert cs["stage_counts"]["PAYMENT_PLAN"] == 1
        assert cs["stage_counts"]["ENFORCEMENT"] == 0
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-04
# Requirement: Reporting #5 (audit_summary) and #9 (status_counts has every
#   audit-status enum key).
# --------------------------------------------------------------------------- #
def test_report_audit_summary():
    try:
        platform = build_platform()
        audits = [_selected_audit("SELECTED"), _selected_audit("SELECTED"), _selected_audit("CLOSED")]
        report = platform.generate_regulatory_report(
            reporting_period="2024-Q3",
            generated_at="2024-10-01",
            processed_returns=[],
            selected_audits=audits,
            collection_actions=[],
            refund_decisions=[],
        )
        au = report["audit_summary"]

        assert au["selected_case_count"] == 3
        assert set(au["status_counts"].keys()) == {"SELECTED", "IN_EXAMINATION", "CLOSED"}
        assert au["status_counts"]["SELECTED"] == 2
        assert au["status_counts"]["IN_EXAMINATION"] == 0
        assert au["status_counts"]["CLOSED"] == 1
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-05
# Requirement: Reporting #6 (refund_summary) and #9 (decision_counts has
#   exactly OFFSET and APPROVED keys).
# --------------------------------------------------------------------------- #
def test_report_refund_summary():
    try:
        platform = build_platform()
        decisions = [
            _refund_decision("APPROVED", "10.00"),
            _refund_decision("APPROVED", "5.00"),
            _refund_decision("OFFSET", "0.00"),
        ]
        report = platform.generate_regulatory_report(
            reporting_period="2024-Q4",
            generated_at="2025-01-01",
            processed_returns=[],
            selected_audits=[],
            collection_actions=[],
            refund_decisions=decisions,
        )
        rs = report["refund_summary"]

        assert rs["claim_count"] == 3
        assert set(rs["decision_counts"].keys()) == {"OFFSET", "APPROVED"}
        assert rs["decision_counts"]["APPROVED"] == 2
        assert rs["decision_counts"]["OFFSET"] == 1
        assert Decimal(rs["total_payable_amount_usd"]) == Decimal("15.00")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-06
# Requirement: Reporting #7 (ssuta_summary keys and values).
# Test Description: destination_sourcing_applied is True;
#   state_rate_coverage_count equals number of distinct state codes in the
#   rate table; local_rate_coverage_count equals number of distinct
#   (state, local) keys in the rate table.
# --------------------------------------------------------------------------- #
def test_report_ssuta_summary_uses_init_rate_table():
    try:
        from tax_administration import TaxAdministrationPlatform

        rate_table = [
            {
                "destination_state_code": "CA",
                "destination_local_code": "LA",
                "state_rate": Decimal("0.06"),
                "local_rate": Decimal("0.025"),
            },
            {
                "destination_state_code": "CA",
                "destination_local_code": "SF",
                "state_rate": Decimal("0.06"),
                "local_rate": Decimal("0.0125"),
            },
            {
                "destination_state_code": "NY",
                "destination_local_code": "NYC",
                "state_rate": Decimal("0.04"),
                "local_rate": Decimal("0.045"),
            },
        ]
        platform = TaxAdministrationPlatform(rate_table=rate_table)

        report = platform.generate_regulatory_report(
            reporting_period="2024-Q4",
            generated_at="2025-01-01",
            processed_returns=[],
            selected_audits=[],
            collection_actions=[],
            refund_decisions=[],
        )
        ss = report["ssuta_summary"]

        assert ss["destination_sourcing_applied"] is True
        assert ss["state_rate_coverage_count"] == 2
        assert ss["local_rate_coverage_count"] == 3
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-11
# Requirement: Reporting #7 (state_rate_coverage_count and
#   local_rate_coverage_count reflect distinct-key counts; duplicate
#   rate-table entries for the same (state, local) key are counted once).
# Test Description: A rate table containing two entries for the same
#   (destination_state_code, destination_local_code) key must produce
#   local_rate_coverage_count == 1 and state_rate_coverage_count == 1.
# --------------------------------------------------------------------------- #
def test_report_ssuta_coverage_counts_deduplicate_duplicate_rate_table_entries():
    try:
        from tax_administration import TaxAdministrationPlatform

        rate_table = [
            {
                "destination_state_code": "CA",
                "destination_local_code": "LA",
                "state_rate": Decimal("0.06"),
                "local_rate": Decimal("0.025"),
            },
            {
                "destination_state_code": "CA",
                "destination_local_code": "LA",
                "state_rate": Decimal("0.07"),
                "local_rate": Decimal("0.030"),
            },
        ]
        platform = TaxAdministrationPlatform(rate_table=rate_table)
        report = platform.generate_regulatory_report(
            reporting_period="2024-Q1",
            generated_at="2024-04-01",
            processed_returns=[],
            selected_audits=[],
            collection_actions=[],
            refund_decisions=[],
        )
        ss = report["ssuta_summary"]

        assert ss["state_rate_coverage_count"] == 1
        assert ss["local_rate_coverage_count"] == 1
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-07
# Requirement: Reporting #8 (legislative_auditor_summary contains
#   reporting_period, generated_at, metrics_snapshot).
# --------------------------------------------------------------------------- #
def test_report_legislative_auditor_summary_keys_and_propagation():
    try:
        platform = build_platform()
        report = platform.generate_regulatory_report(
            reporting_period="LEG-PD",
            generated_at="2025-02-15T10:00:00Z",
            processed_returns=[],
            selected_audits=[],
            collection_actions=[],
            refund_decisions=[],
        )
        las = report["legislative_auditor_summary"]

        for key in ("reporting_period", "generated_at", "metrics_snapshot"):
            assert key in las, f"missing key {key!r}"
        assert las["reporting_period"] == "LEG-PD"
        assert las["generated_at"] == "2025-02-15T10:00:00Z"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-08
# Requirement: Reporting #10 (metrics_snapshot exact keys and derivations).
# --------------------------------------------------------------------------- #
def test_report_metrics_snapshot_contents():
    try:
        platform = build_platform()
        processed = [_processed_return("IN_STATE_RETAILER", "10.00"), _processed_return("REMOTE_SELLER", "20.00")]
        audits = [_selected_audit("SELECTED")]
        actions = [_collection_action("NOTICE", "5.00"), _collection_action("PAYMENT_PLAN", "15.00")]
        decisions = [_refund_decision("APPROVED", "7.00")]

        report = platform.generate_regulatory_report(
            reporting_period="MS-PD",
            generated_at="2025-03-01",
            processed_returns=processed,
            selected_audits=audits,
            collection_actions=actions,
            refund_decisions=decisions,
        )
        snap = report["legislative_auditor_summary"]["metrics_snapshot"]

        assert set(snap.keys()) == {
            "returns_processed",
            "audits_selected",
            "collection_actions_count",
            "refund_decisions_count",
            "total_tax_due_usd",
            "total_unpaid_liability_usd",
            "total_payable_amount_usd",
        }
        assert snap["returns_processed"] == 2
        assert snap["audits_selected"] == 1
        assert snap["collection_actions_count"] == 2
        assert snap["refund_decisions_count"] == 1
        assert Decimal(snap["total_tax_due_usd"]) == Decimal("30.00")
        assert Decimal(snap["total_unpaid_liability_usd"]) == Decimal("20.00")
        assert Decimal(snap["total_payable_amount_usd"]) == Decimal("7.00")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-09
# Requirement: Validation #5 (zero-valued aggregates when every input
#   collection is empty).
# --------------------------------------------------------------------------- #
def test_report_zero_valued_aggregates_when_all_inputs_empty():
    try:
        platform = build_platform()
        report = platform.generate_regulatory_report(
            reporting_period="EMPTY",
            generated_at="2025-04-01",
            processed_returns=[],
            selected_audits=[],
            collection_actions=[],
            refund_decisions=[],
        )

        assert report["filing_summary"]["total_returns_processed"] == 0
        assert Decimal(report["filing_summary"]["total_tax_due_usd"]) == Decimal("0.00")
        for v in report["filing_summary"]["filer_mix_counts"].values():
            assert v == 0

        assert Decimal(report["collection_summary"]["total_unpaid_liability_usd"]) == Decimal("0.00")
        for v in report["collection_summary"]["stage_counts"].values():
            assert v == 0

        assert report["audit_summary"]["selected_case_count"] == 0
        for v in report["audit_summary"]["status_counts"].values():
            assert v == 0

        assert report["refund_summary"]["claim_count"] == 0
        assert Decimal(report["refund_summary"]["total_payable_amount_usd"]) == Decimal("0.00")
        for v in report["refund_summary"]["decision_counts"].values():
            assert v == 0

        snap = report["legislative_auditor_summary"]["metrics_snapshot"]
        assert snap["returns_processed"] == 0
        assert snap["audits_selected"] == 0
        assert snap["collection_actions_count"] == 0
        assert snap["refund_decisions_count"] == 0
        assert Decimal(snap["total_tax_due_usd"]) == Decimal("0.00")
        assert Decimal(snap["total_unpaid_liability_usd"]) == Decimal("0.00")
        assert Decimal(snap["total_payable_amount_usd"]) == Decimal("0.00")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REP-10
# Requirement: Aggregate quantization (top-of-prompt rule applied to
#   total_tax_due_usd, total_unpaid_liability_usd, total_payable_amount_usd):
#   ROUND_HALF_UP at 2 fractional digits.
# Test Description: Inputs whose sum has a third fractional half-digit must
#   round UP, not to even.
# --------------------------------------------------------------------------- #
def test_report_aggregates_quantize_round_half_up():
    try:
        platform = build_platform()
        processed = [
            _processed_return("IN_STATE_RETAILER", "0.005"),
            _processed_return("REMOTE_SELLER", "0.020"),
        ]
        actions = [
            _collection_action("NOTICE", "0.005"),
            _collection_action("NOTICE", "0.020"),
        ]
        decisions = [
            _refund_decision("APPROVED", "0.005"),
            _refund_decision("APPROVED", "0.020"),
        ]

        report = platform.generate_regulatory_report(
            reporting_period="QZ",
            generated_at="2025-05-01",
            processed_returns=processed,
            selected_audits=[],
            collection_actions=actions,
            refund_decisions=decisions,
        )

        assert Decimal(report["filing_summary"]["total_tax_due_usd"]) == Decimal("0.03")
        assert Decimal(report["collection_summary"]["total_unpaid_liability_usd"]) == Decimal("0.03")
        assert Decimal(report["refund_summary"]["total_payable_amount_usd"]) == Decimal("0.03")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"generate_regulatory_report raised unexpected exception: {exc!r}")
