"""Shared helpers for the test suite.

These helpers exist to keep individual test files concise. They do not
encode any implementation detail beyond what the prompt explicitly defines
(e.g. building a valid rate_table payload that matches the documented
input contract for TaxAdministrationPlatform).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any


def default_rate_table() -> list[dict]:
    """Return a minimal rate table covering several jurisdictions.

    Each entry follows the structure declared in the prompt:
    {destination_state_code, destination_local_code, state_rate, local_rate}.
    """

    return [
        {
            "destination_state_code": "CA",
            "destination_local_code": "LA",
            "state_rate": Decimal("0.06"),
            "local_rate": Decimal("0.025"),
        },
        {
            "destination_state_code": "CA",
            "destination_local_code": "SF",
            "state_rate": Decimal("0.06"),
            "local_rate": Decimal("0.0125"),
        },
        {
            "destination_state_code": "NY",
            "destination_local_code": "NYC",
            "state_rate": Decimal("0.04"),
            "local_rate": Decimal("0.045"),
        },
        {
            "destination_state_code": "TX",
            "destination_local_code": "AUS",
            "state_rate": Decimal("0.0625"),
            "local_rate": Decimal("0.02"),
        },
    ]


def build_platform() -> Any:
    """Instantiate TaxAdministrationPlatform with the default rate table."""

    from tax_administration import TaxAdministrationPlatform

    return TaxAdministrationPlatform(rate_table=default_rate_table())
