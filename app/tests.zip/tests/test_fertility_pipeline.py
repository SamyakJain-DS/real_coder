import os
import re
import tempfile

import numpy as np
import pandas as pd
import pytest

# ---------------------------------------------------------------------------
# Graceful import handling -- must not ERROR on empty repo
# ---------------------------------------------------------------------------

try:
    from fertility_pipeline import FertilityPipeline, load_dataset
    _IMPORT_ERROR = None
except Exception as exc:
    FertilityPipeline = None  # type: ignore[assignment,misc]
    load_dataset = None       # type: ignore[assignment]
    _IMPORT_ERROR = str(exc)

# ---------------------------------------------------------------------------
# Constants from the prompt
# ---------------------------------------------------------------------------

REQUIRED_COLUMNS = [
    "patient_id", "age", "amh", "fsh", "prior_pregnancies", "prior_losses",
    "bmi", "partner_factor", "protocol", "oocytes_retrieved",
    "fertilization_rate", "blastocyst_formation_rate", "embryo_grade",
    "transfer_type", "outcome_pregnancy", "outcome_ongoing_pregnancy",
    "outcome_live_birth",
]

REQUIRED_PROTOCOLS = {"antagonist", "agonist_long", "mini_stim", "natural"}

AGE_BAND_LABELS = ["under_35", "35_37", "38_40", "41_42", "over_42"]

PREDICT_OUTCOME_COLS = [
    "pregnancy_prob", "pregnancy_ci_lower", "pregnancy_ci_upper",
    "ongoing_pregnancy_prob", "ongoing_pregnancy_ci_lower", "ongoing_pregnancy_ci_upper",
    "live_birth_prob", "live_birth_ci_lower", "live_birth_ci_upper",
]

PROTOCOL_EFFECT_COLS = [
    "n_cycles", "unadjusted_live_birth_rate", "ipw_adjusted_live_birth_rate",
]

SART_AGE_COLS = [
    "n_cycles", "n_retrievals", "n_transfers",
    "pregnancy_rate", "ongoing_pregnancy_rate", "live_birth_rate",
]

SART_PROTOCOL_COLS = [
    "n_cycles", "n_transfers",
    "pregnancy_rate", "ongoing_pregnancy_rate", "live_birth_rate",
]

# ---------------------------------------------------------------------------
# Module-level cache (avoids re-reading CSV and re-fitting on every test)
# ---------------------------------------------------------------------------

_cache: dict = {}


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _require_import():
    """Fail (FAILED, not ERROR) if the module could not be imported."""
    if _IMPORT_ERROR is not None:
        pytest.fail(f"fertility_pipeline could not be imported: {_IMPORT_ERROR}")


def _get_data_path() -> str:
    """Return the expected path of data/fertility_cycles.csv."""
    # When running inside the validation container PYTHONPATH=/app and tests
    # are in /eval_assets. Locate the CSV relative to the module file so that
    # all three execution contexts (local, full Docker, validation) work.
    if _IMPORT_ERROR is None:
        try:
            import fertility_pipeline as _fp
            module_dir = os.path.dirname(os.path.abspath(_fp.__file__))
            return os.path.join(module_dir, "data", "fertility_cycles.csv")
        except Exception:
            pass
    return os.path.join(os.getcwd(), "data", "fertility_cycles.csv")


def _get_df() -> pd.DataFrame:
    """Load the dataset, calling pytest.fail() on any problem."""
    _require_import()
    if "df" not in _cache:
        data_path = _get_data_path()
        if not os.path.exists(data_path):
            pytest.fail(
                f"data/fertility_cycles.csv not found at: {data_path}. "
                "The implementation must create this file."
            )
        try:
            df = load_dataset(data_path)  # type: ignore[misc]
            _cache["df"] = df
            _cache["data_path"] = data_path
        except Exception as exc:
            pytest.fail(f"load_dataset raised an unexpected error: {exc}")
    return _cache["df"]


def _get_fitted_pipeline():
    """Return (fitted FertilityPipeline, training df), failing gracefully."""
    df = _get_df()
    if "pipeline" not in _cache:
        try:
            pipeline = FertilityPipeline()  # type: ignore[misc]
            pipeline.fit(df)
            _cache["pipeline"] = pipeline
        except Exception as exc:
            pytest.fail(f"FertilityPipeline().fit() raised an unexpected error: {exc}")
    return _cache["pipeline"], df


def _is_rounded_4dp(value: float) -> bool:
    """Return True if value has at most 4 significant decimal digits."""
    return abs(round(float(value), 4) - float(value)) < 1e-9


def _numbers_in_string(s: str):
    """Extract all float-like numbers from a string."""
    return [float(x) for x in re.findall(r"\d+\.\d+|\d+", s)]


def _value_present(value: float, nums, tol: float = 0.005) -> bool:
    """Check if value (probability) appears in nums at prob or % scale."""
    return any(abs(n - value) <= tol for n in nums) or any(
        abs(n - value * 100) <= tol * 100 for n in nums
    )


# ===========================================================================
# 1. Dataset -- data/fertility_cycles.csv
# ===========================================================================

class TestDataset:
    """Tests for the required structure and coverage of fertility_cycles.csv."""

    # --- Column presence ---

    def test_dataset_has_all_required_columns(self):
        # Req: CSV contains exactly these 17 columns (no more, no less)
        df = _get_df()
        assert set(df.columns) == set(REQUIRED_COLUMNS), (
            f"Column mismatch. Missing: {set(REQUIRED_COLUMNS) - set(df.columns)}, "
            f"Extra: {set(df.columns) - set(REQUIRED_COLUMNS)}"
        )

    # --- Row count ---

    def test_dataset_has_at_least_100_rows(self):
        # Req: generated file contains at least 100 rows
        df = _get_df()
        assert len(df) >= 100

    def test_patient_id_is_string_type(self):
        # Req: patient_id: str
        df = _get_df()
        assert df["patient_id"].apply(lambda x: isinstance(x, str)).all(), (
            "Not all patient_id values are of type str"
        )

    # --- Per-column constraints ---

    def test_age_in_range(self):
        # Req: age float, range 18 to 50
        df = _get_df()
        assert pd.api.types.is_float_dtype(df["age"])
        assert df["age"].between(18.0, 50.0).all()

    def test_amh_non_negative(self):
        # Req: amh float, non-negative
        df = _get_df()
        assert pd.api.types.is_float_dtype(df["amh"])
        assert (df["amh"] >= 0).all()

    def test_fsh_non_negative(self):
        # Req: fsh float, non-negative
        df = _get_df()
        assert pd.api.types.is_float_dtype(df["fsh"])
        assert (df["fsh"] >= 0).all()

    def test_prior_pregnancies_non_negative_integer(self):
        # Req: prior_pregnancies int, non-negative
        df = _get_df()
        assert (df["prior_pregnancies"] >= 0).all()
        assert df["prior_pregnancies"].apply(lambda x: float(x).is_integer()).all()

    def test_prior_losses_non_negative_integer(self):
        # Req: prior_losses int, non-negative
        df = _get_df()
        assert (df["prior_losses"] >= 0).all()
        assert df["prior_losses"].apply(lambda x: float(x).is_integer()).all()

    def test_bmi_in_range(self):
        # Req: bmi float, range 15 to 60
        df = _get_df()
        assert pd.api.types.is_float_dtype(df["bmi"])
        assert df["bmi"].between(15.0, 60.0).all()

    def test_partner_factor_binary(self):
        # Req: partner_factor int, 0 or 1
        df = _get_df()
        assert df["partner_factor"].isin([0, 1]).all()

    def test_protocol_exactly_four_required_values(self):
        # Req: protocol str, exactly four distinct values: antagonist, agonist_long,
        #      mini_stim, natural
        df = _get_df()
        observed = set(df["protocol"].unique())
        assert observed == REQUIRED_PROTOCOLS, (
            f"Expected protocols {REQUIRED_PROTOCOLS}, got {observed}"
        )

    def test_oocytes_retrieved_non_negative_integer(self):
        # Req: oocytes_retrieved int, non-negative
        df = _get_df()
        assert (df["oocytes_retrieved"] >= 0).all()
        assert df["oocytes_retrieved"].apply(lambda x: float(x).is_integer()).all()

    def test_fertilization_rate_in_unit_interval(self):
        # Req: fertilization_rate float in [0.0, 1.0]
        df = _get_df()
        assert pd.api.types.is_float_dtype(df["fertilization_rate"])
        assert df["fertilization_rate"].between(0.0, 1.0).all()

    def test_blastocyst_formation_rate_in_unit_interval(self):
        # Req: blastocyst_formation_rate float in [0.0, 1.0]
        df = _get_df()
        assert pd.api.types.is_float_dtype(df["blastocyst_formation_rate"])
        assert df["blastocyst_formation_rate"].between(0.0, 1.0).all()

    def test_embryo_grade_valid_values(self):
        # Req: embryo_grade str, one of A, B, C, D
        df = _get_df()
        assert df["embryo_grade"].isin(["A", "B", "C", "D"]).all()

    def test_transfer_type_valid_values(self):
        # Req: transfer_type str, "fresh" or "frozen", nullable
        df = _get_df()
        non_null = df["transfer_type"].dropna()
        assert non_null.isin(["fresh", "frozen"]).all()

    def test_outcome_columns_binary(self):
        # Req: outcome_pregnancy, outcome_ongoing_pregnancy, outcome_live_birth
        #      are each int 0 or 1
        df = _get_df()
        for col in ["outcome_pregnancy", "outcome_ongoing_pregnancy", "outcome_live_birth"]:
            assert df[col].isin([0, 1]).all(), f"{col} has values outside {{0, 1}}"

    # --- Coverage guarantees ---

    def test_all_five_age_bands_represented(self):
        # Req: all five age bands contain at least one row
        df = _get_df()
        ages = df["age"]
        assert (ages < 35).any(), "No row with age < 35"
        assert ((ages >= 35) & (ages < 38)).any(), "No row with 35 <= age < 38"
        assert ((ages >= 38) & (ages < 41)).any(), "No row with 38 <= age < 41"
        assert ((ages >= 41) & (ages < 43)).any(), "No row with 41 <= age < 43"
        assert (ages >= 43).any(), "No row with age >= 43"

    def test_transfer_type_coverage(self):
        # Req: both fresh and frozen appear; at least one null
        df = _get_df()
        assert "fresh" in df["transfer_type"].values
        assert "frozen" in df["transfer_type"].values
        assert df["transfer_type"].isna().any()

    def test_each_outcome_has_both_classes(self):
        # Req: each outcome column contains at least one 0 and one 1
        df = _get_df()
        for col in ["outcome_pregnancy", "outcome_ongoing_pregnancy", "outcome_live_birth"]:
            assert 0 in df[col].values, f"No 0 in {col}"
            assert 1 in df[col].values, f"No 1 in {col}"


# ===========================================================================
# 2. load_dataset
# ===========================================================================

class TestLoadDataset:
    """Tests for the load_dataset function interface."""

    def test_raises_file_not_found_error(self):
        # Req: raises FileNotFoundError if filepath does not exist
        _require_import()
        with pytest.raises(FileNotFoundError):
            load_dataset("/nonexistent_path_abc123/fertility_cycles.csv")  # type: ignore[misc]

    def test_raises_value_error_on_missing_column(self):
        # Req: raises ValueError if any of the 17 required columns are absent
        _require_import()
        df = _get_df()
        incomplete = df.drop(columns=["outcome_live_birth"])
        with tempfile.NamedTemporaryFile(suffix=".csv", mode="w", delete=False) as f:
            tmppath = f.name
            incomplete.to_csv(tmppath, index=False)
        try:
            with pytest.raises(ValueError):
                load_dataset(tmppath)  # type: ignore[misc]
        finally:
            os.unlink(tmppath)


# ===========================================================================
# 3. FertilityPipeline -- fit
# ===========================================================================

class TestFit:
    """Tests for FertilityPipeline.fit."""

    def test_fit_returns_none(self):
        # Req: fit Output: None
        _require_import()
        df = _get_df()
        pipeline = FertilityPipeline()  # type: ignore[misc]
        result = pipeline.fit(df)
        assert result is None, f"fit() returned {result!r} instead of None"

    def test_fit_raises_value_error_on_missing_feature_column(self):
        # Req: raises ValueError if any required feature column is missing
        _require_import()
        df = _get_df().drop(columns=["age"])
        pipeline = FertilityPipeline()  # type: ignore[misc]
        with pytest.raises(ValueError):
            pipeline.fit(df)

    def test_fit_raises_value_error_on_missing_outcome_column(self):
        # Req: raises ValueError if any required outcome column is missing
        _require_import()
        df = _get_df().drop(columns=["outcome_pregnancy"])
        pipeline = FertilityPipeline()  # type: ignore[misc]
        with pytest.raises(ValueError):
            pipeline.fit(df)


# ===========================================================================
# 5. FertilityPipeline.predict_outcomes
# ===========================================================================

class TestPredictOutcomes:
    """Tests for FertilityPipeline.predict_outcomes."""

    def test_raises_runtime_error_before_fit(self):
        # Req: raises RuntimeError if fit has not been called
        _require_import()
        df = _get_df()
        pipeline = FertilityPipeline()  # type: ignore[misc]
        with pytest.raises(RuntimeError):
            pipeline.predict_outcomes(df.head(1))

    def test_output_has_nine_required_columns(self):
        # Req: DataFrame containing exactly these columns (no more, no less)
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.predict_outcomes(df.head(3))
        assert set(result.columns) == set(PREDICT_OUTCOME_COLS), (
            f"Column mismatch. Missing: {set(PREDICT_OUTCOME_COLS) - set(result.columns)}, "
            f"Extra: {set(result.columns) - set(PREDICT_OUTCOME_COLS)}"
        )

    def test_row_count_matches_input(self):
        # Req: one row per row in patient_df
        pipeline, df = _get_fitted_pipeline()
        sample = df.head(4)
        result = pipeline.predict_outcomes(sample)
        assert len(result) == len(sample)

    def test_all_values_in_unit_interval(self):
        # Req: all values are floats in [0.0, 1.0]
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.predict_outcomes(df.head(3))
        for col in PREDICT_OUTCOME_COLS:
            assert (result[col] >= 0.0).all() and (result[col] <= 1.0).all(), (
                f"Column {col} has values outside [0, 1]"
            )

    def test_monotonic_ordering_enforced(self):
        # Req: pregnancy_prob >= ongoing_pregnancy_prob >= live_birth_prob
        #      enforced on every row of point estimates
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.predict_outcomes(df.head(5))
        tol = 1e-9
        assert (result["pregnancy_prob"] >= result["ongoing_pregnancy_prob"] - tol).all()
        assert (result["ongoing_pregnancy_prob"] >= result["live_birth_prob"] - tol).all()

    def test_ci_brackets_point_estimate(self):
        # Req: ci_lower <= prob <= ci_upper for each outcome after clipping
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.predict_outcomes(df.head(5))
        tol = 1e-9
        for prefix in ["pregnancy", "ongoing_pregnancy", "live_birth"]:
            prob = result[f"{prefix}_prob"]
            lower = result[f"{prefix}_ci_lower"]
            upper = result[f"{prefix}_ci_upper"]
            assert (lower <= prob + tol).all(), f"{prefix}: ci_lower > prob"
            assert (upper >= prob - tol).all(), f"{prefix}: ci_upper < prob"


# ===========================================================================
# 6. FertilityPipeline.compute_protocol_selection_effects
# ===========================================================================

class TestComputeProtocolSelectionEffects:
    """Tests for FertilityPipeline.compute_protocol_selection_effects."""

    def test_raises_runtime_error_before_fit(self):
        # Req: raises RuntimeError if fit has not been called
        _require_import()
        df = _get_df()
        pipeline = FertilityPipeline()  # type: ignore[misc]
        with pytest.raises(RuntimeError):
            pipeline.compute_protocol_selection_effects(df)

    def test_has_required_columns(self):
        # Req: DataFrame contains columns n_cycles, unadjusted_live_birth_rate,
        #      ipw_adjusted_live_birth_rate
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.compute_protocol_selection_effects(df)
        missing = [c for c in PROTOCOL_EFFECT_COLS if c not in result.columns]
        assert not missing, f"Missing columns: {missing}"

    def test_indexed_by_protocol_values(self):
        # Req: indexed by the unique protocol values present in df
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.compute_protocol_selection_effects(df)
        expected = set(df["protocol"].unique())
        assert set(result.index) == expected

    def test_n_cycles_matches_actual_counts(self):
        # Req: n_cycles (int) per protocol equals actual row count per protocol
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.compute_protocol_selection_effects(df)
        for protocol in df["protocol"].unique():
            expected = int((df["protocol"] == protocol).sum())
            assert result.loc[protocol, "n_cycles"] == expected

    def test_unadjusted_rate_in_unit_interval(self):
        # Req: unadjusted (raw) live birth rate is a mean of binary outcomes,
        #      so it is mathematically bounded to [0.0, 1.0]
        # Note: prompt does not constrain IPW-adjusted rates to [0, 1]; a
        #       Horvitz-Thompson IPW estimator with clipped weights can exceed
        #       that range in finite samples, so only unadjusted is checked here.
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.compute_protocol_selection_effects(df)
        assert (result["unadjusted_live_birth_rate"] >= 0.0).all()
        assert (result["unadjusted_live_birth_rate"] <= 1.0).all()

    def test_rates_rounded_to_4_decimal_places(self):
        # Req: both rate columns rounded to 4 decimal places
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.compute_protocol_selection_effects(df)
        for col in ["unadjusted_live_birth_rate", "ipw_adjusted_live_birth_rate"]:
            for val in result[col]:
                assert _is_rounded_4dp(val), (
                    f"{col} value {val} is not rounded to 4 decimal places"
                )

    def test_unadjusted_rate_matches_raw_mean(self):
        # Req: unadjusted (raw) live birth rate = simple mean of outcome_live_birth
        #      per protocol
        pipeline, df = _get_fitted_pipeline()
        result = pipeline.compute_protocol_selection_effects(df)
        for protocol in df["protocol"].unique():
            subset = df[df["protocol"] == protocol]
            expected = round(float(subset["outcome_live_birth"].mean()), 4)
            actual = float(result.loc[protocol, "unadjusted_live_birth_rate"])
            assert abs(actual - expected) < 1e-4, (
                f"Protocol {protocol}: unadjusted rate {actual} != raw mean {expected}"
            )


# ===========================================================================
# 7. FertilityPipeline.generate_sart_summary
# ===========================================================================

class TestGenerateSARTSummary:
    """Tests for FertilityPipeline.generate_sart_summary."""

    def _sart(self):
        pipeline, df = _get_fitted_pipeline()
        return pipeline.generate_sart_summary(df), df

    def test_has_by_age_and_by_protocol_keys(self):
        # Req: dict with exactly two keys: by_age and by_protocol
        result, _ = self._sart()
        assert set(result.keys()) == {"by_age", "by_protocol"}

    def test_by_age_has_five_band_index(self):
        # Req: by_age indexed by exactly the five specified age band labels
        result, _ = self._sart()
        age_df = result["by_age"]
        assert set(age_df.index) == set(AGE_BAND_LABELS), (
            f"Index mismatch. Missing: {set(AGE_BAND_LABELS) - set(age_df.index)}, "
            f"Extra: {set(age_df.index) - set(AGE_BAND_LABELS)}"
        )

    def test_by_age_has_required_columns(self):
        # Req: by_age contains columns n_cycles, n_retrievals, n_transfers,
        #      pregnancy_rate, ongoing_pregnancy_rate, live_birth_rate
        result, _ = self._sart()
        missing = [c for c in SART_AGE_COLS if c not in result["by_age"].columns]
        assert not missing, f"Missing by_age columns: {missing}"

    def test_by_protocol_has_required_columns(self):
        # Req: by_protocol contains columns n_cycles, n_transfers, pregnancy_rate,
        #      ongoing_pregnancy_rate, live_birth_rate
        result, _ = self._sart()
        missing = [c for c in SART_PROTOCOL_COLS if c not in result["by_protocol"].columns]
        assert not missing, f"Missing by_protocol columns: {missing}"

    def test_by_age_rate_columns_rounded_to_4dp(self):
        # Req: all rate columns are floats rounded to 4 decimal places (NaN is invalid)
        result, _ = self._sart()
        for col in ["pregnancy_rate", "ongoing_pregnancy_rate", "live_birth_rate"]:
            for val in result["by_age"][col]:
                assert _is_rounded_4dp(val), (
                    f"by_age.{col} value {val!r} not a float rounded to 4dp"
                )

    def test_by_protocol_rate_columns_rounded_to_4dp(self):
        # Req: all rate columns are floats rounded to 4 decimal places (NaN is invalid)
        result, _ = self._sart()
        for col in ["pregnancy_rate", "ongoing_pregnancy_rate", "live_birth_rate"]:
            for val in result["by_protocol"][col]:
                assert _is_rounded_4dp(val), (
                    f"by_protocol.{col} value {val!r} not a float rounded to 4dp"
                )

    def test_by_age_n_cycles_matches_actual_band_counts(self):
        # Req: n_cycles per age band equals the actual row count in that band
        result, df = self._sart()
        age_df = result["by_age"]
        band_counts = {
            "under_35": int((df["age"] < 35).sum()),
            "35_37": int(((df["age"] >= 35) & (df["age"] < 38)).sum()),
            "38_40": int(((df["age"] >= 38) & (df["age"] < 41)).sum()),
            "41_42": int(((df["age"] >= 41) & (df["age"] < 43)).sum()),
            "over_42": int((df["age"] >= 43).sum()),
        }
        for label, expected in band_counts.items():
            if label in age_df.index:
                assert age_df.loc[label, "n_cycles"] == expected, (
                    f"n_cycles mismatch for age band {label}"
                )

    def test_by_age_n_retrievals_counts_positive_oocyte_rows(self):
        # Req: n_retrievals counts rows where oocytes_retrieved > 0
        result, df = self._sart()
        age_df = result["by_age"]
        bands = {
            "under_35": df[df["age"] < 35],
            "35_37": df[(df["age"] >= 35) & (df["age"] < 38)],
            "38_40": df[(df["age"] >= 38) & (df["age"] < 41)],
            "41_42": df[(df["age"] >= 41) & (df["age"] < 43)],
            "over_42": df[df["age"] >= 43],
        }
        for label, subset in bands.items():
            if label in age_df.index:
                expected = int((subset["oocytes_retrieved"] > 0).sum())
                assert age_df.loc[label, "n_retrievals"] == expected, (
                    f"n_retrievals mismatch for age band {label}"
                )

    def test_by_age_n_transfers_counts_non_null_transfer_type(self):
        # Req: n_transfers counts rows where transfer_type is not null
        result, df = self._sart()
        age_df = result["by_age"]
        bands = {
            "under_35": df[df["age"] < 35],
            "35_37": df[(df["age"] >= 35) & (df["age"] < 38)],
            "38_40": df[(df["age"] >= 38) & (df["age"] < 41)],
            "41_42": df[(df["age"] >= 41) & (df["age"] < 43)],
            "over_42": df[df["age"] >= 43],
        }
        for label, subset in bands.items():
            if label in age_df.index:
                expected = int(subset["transfer_type"].notna().sum())
                assert age_df.loc[label, "n_transfers"] == expected, (
                    f"n_transfers mismatch for age band {label}"
                )

    def test_by_protocol_index_contains_all_dataset_protocols(self):
        # Req: by_protocol uses protocol names present in df as the index (exact match)
        result, df = self._sart()
        expected = set(df["protocol"].unique())
        assert set(result["by_protocol"].index) == expected, (
            f"Index mismatch. Missing: {expected - set(result['by_protocol'].index)}, "
            f"Extra: {set(result['by_protocol'].index) - expected}"
        )

    def test_by_protocol_n_cycles_values_correct(self):
        # Req: n_cycles per protocol equals the actual row count for that protocol
        result, df = self._sart()
        proto_df = result["by_protocol"]
        for protocol in df["protocol"].unique():
            expected = int((df["protocol"] == protocol).sum())
            assert proto_df.loc[protocol, "n_cycles"] == expected, (
                f"by_protocol '{protocol}': n_cycles={proto_df.loc[protocol, 'n_cycles']} != {expected}"
            )

    def test_by_protocol_n_transfers_values_correct(self):
        # Req: n_transfers per protocol counts rows where transfer_type is not null
        result, df = self._sart()
        proto_df = result["by_protocol"]
        for protocol in df["protocol"].unique():
            subset = df[df["protocol"] == protocol]
            expected = int(subset["transfer_type"].notna().sum())
            assert proto_df.loc[protocol, "n_transfers"] == expected, (
                f"by_protocol '{protocol}': n_transfers={proto_df.loc[protocol, 'n_transfers']} != {expected}"
            )



# ===========================================================================
# 8. FertilityPipeline.generate_counseling_report
# ===========================================================================

class TestGenerateCounselingReport:
    """Tests for FertilityPipeline.generate_counseling_report."""

    def _sample(self, df: pd.DataFrame):
        """Return (patient_row copy, protocol) from the first row of df."""
        return df.iloc[0].copy(), df["protocol"].iloc[0]

    def test_raises_runtime_error_before_fit(self):
        # Req: raises RuntimeError if fit has not been called
        _require_import()
        df = _get_df()
        pipeline = FertilityPipeline()  # type: ignore[misc]
        row, protocol = df.iloc[0].copy(), df["protocol"].iloc[0]
        with pytest.raises(RuntimeError):
            pipeline.generate_counseling_report(row, protocol)

    def test_raises_value_error_for_unknown_protocol(self):
        # Req: raises ValueError if protocol was not present in training data
        pipeline, df = _get_fitted_pipeline()
        row = df.iloc[0].copy()
        with pytest.raises(ValueError):
            pipeline.generate_counseling_report(row, "__unknown_protocol_xyz__")

    def test_has_four_required_top_level_keys(self):
        # Req: dict with keys pregnancy, ongoing_pregnancy, live_birth, protocol_effect
        pipeline, df = _get_fitted_pipeline()
        row, protocol = self._sample(df)
        result = pipeline.generate_counseling_report(row, protocol)
        for key in ["pregnancy", "ongoing_pregnancy", "live_birth", "protocol_effect"]:
            assert key in result, f"Missing top-level key: {key}"

    def test_outcome_subkeys_present(self):
        # Req: each outcome includes point_estimate, ci_lower, ci_upper,
        #      interpretation, high_uncertainty
        pipeline, df = _get_fitted_pipeline()
        row, protocol = self._sample(df)
        result = pipeline.generate_counseling_report(row, protocol)
        for outcome in ["pregnancy", "ongoing_pregnancy", "live_birth"]:
            for key in ["point_estimate", "ci_lower", "ci_upper",
                        "interpretation", "high_uncertainty"]:
                assert key in result[outcome], (
                    f"Missing key '{key}' in outcome '{outcome}'"
                )

    def test_point_estimates_in_unit_interval(self):
        # Req: point_estimate is a float in [0.0, 1.0]
        pipeline, df = _get_fitted_pipeline()
        row, protocol = self._sample(df)
        result = pipeline.generate_counseling_report(row, protocol)
        for outcome in ["pregnancy", "ongoing_pregnancy", "live_birth"]:
            pe = result[outcome]["point_estimate"]
            assert 0.0 <= pe <= 1.0, (
                f"{outcome}: point_estimate {pe} out of [0, 1]"
            )

    def test_ci_bounds_are_floats(self):
        # Req: ci_lower (float), ci_upper (float) per counseling report spec
        pipeline, df = _get_fitted_pipeline()
        row, protocol = self._sample(df)
        result = pipeline.generate_counseling_report(row, protocol)
        for outcome in ["pregnancy", "ongoing_pregnancy", "live_birth"]:
            sub = result[outcome]
            assert isinstance(sub["ci_lower"], (int, float, np.floating)), (
                f"{outcome}: ci_lower is not a float (got {type(sub['ci_lower']).__name__})"
            )
            assert isinstance(sub["ci_upper"], (int, float, np.floating)), (
                f"{outcome}: ci_upper is not a float (got {type(sub['ci_upper']).__name__})"
            )

    def test_interpretation_contains_estimate_and_ci_values(self):
        # Req: interpretation is a str containing the point estimate value and
        #      both CI bound values as human-readable numeric substrings
        pipeline, df = _get_fitted_pipeline()
        row, protocol = self._sample(df)
        result = pipeline.generate_counseling_report(row, protocol)
        for outcome in ["pregnancy", "ongoing_pregnancy", "live_birth"]:
            sub = result[outcome]
            interp = sub["interpretation"]
            assert isinstance(interp, str), (
                f"{outcome}: interpretation is not a str (got {type(interp).__name__})"
            )
            nums = _numbers_in_string(interp)
            pe = sub["point_estimate"]
            cl = sub["ci_lower"]
            cu = sub["ci_upper"]
            assert _value_present(pe, nums), (
                f"{outcome}: point_estimate {pe} not found in interpretation: '{interp}'"
            )
            assert _value_present(cl, nums), (
                f"{outcome}: ci_lower {cl} not found in interpretation: '{interp}'"
            )
            assert _value_present(cu, nums), (
                f"{outcome}: ci_upper {cu} not found in interpretation: '{interp}'"
            )

    def test_high_uncertainty_flag_is_boolean(self):
        # Req: high_uncertainty is a bool
        pipeline, df = _get_fitted_pipeline()
        row, protocol = self._sample(df)
        result = pipeline.generate_counseling_report(row, protocol)
        for outcome in ["pregnancy", "ongoing_pregnancy", "live_birth"]:
            assert isinstance(result[outcome]["high_uncertainty"], bool)

    def test_high_uncertainty_flag_logic(self):
        # Req: high_uncertainty is True when ci_upper - ci_lower > 0.20
        # Run across all protocols to exercise more CI widths and increase
        # the chance of covering both True and False branches of the flag.
        pipeline, df = _get_fitted_pipeline()
        row = df.iloc[0].copy()
        for protocol in df["protocol"].unique():
            result = pipeline.generate_counseling_report(row.copy(), protocol)
            for outcome in ["pregnancy", "ongoing_pregnancy", "live_birth"]:
                sub = result[outcome]
                expected_flag = (sub["ci_upper"] - sub["ci_lower"]) > 0.20
                assert sub["high_uncertainty"] == expected_flag, (
                    f"Protocol '{protocol}', {outcome}: high_uncertainty="
                    f"{sub['high_uncertainty']} but "
                    f"ci_upper - ci_lower = {sub['ci_upper'] - sub['ci_lower']}"
                )

    def test_protocol_effect_has_required_keys(self):
        # Req: protocol_effect has unadjusted_live_birth_rate and
        #      ipw_adjusted_live_birth_rate
        pipeline, df = _get_fitted_pipeline()
        row, protocol = self._sample(df)
        result = pipeline.generate_counseling_report(row, protocol)
        pe = result["protocol_effect"]
        assert "unadjusted_live_birth_rate" in pe
        assert "ipw_adjusted_live_birth_rate" in pe

    def test_protocol_effect_rates_rounded_to_4dp(self):
        # Req: both protocol_effect rates rounded to 4 decimal places
        pipeline, df = _get_fitted_pipeline()
        row, protocol = self._sample(df)
        result = pipeline.generate_counseling_report(row, protocol)
        pe = result["protocol_effect"]
        assert _is_rounded_4dp(pe["unadjusted_live_birth_rate"])
        assert _is_rounded_4dp(pe["ipw_adjusted_live_birth_rate"])

    def test_protocol_effect_unadjusted_rate_matches_raw_mean(self):
        # Req: protocol_effect unadjusted_live_birth_rate equals the raw mean of
        #      outcome_live_birth for the specified protocol in the training data
        pipeline, df = _get_fitted_pipeline()
        row, protocol = self._sample(df)
        report = pipeline.generate_counseling_report(row, protocol)
        expected = round(
            float(df[df["protocol"] == protocol]["outcome_live_birth"].mean()), 4
        )
        actual = report["protocol_effect"]["unadjusted_live_birth_rate"]
        assert abs(actual - expected) < 1e-4, (
            f"Protocol '{protocol}': unadjusted_live_birth_rate={actual} != "
            f"raw mean {expected}"
        )

    def test_specified_protocol_is_used_for_prediction(self):
        # Req: "the method sets patient_row['protocol'] = protocol so that all
        #      outcome estimates ... reference the same protocol"
        # Verify the outcome point estimates in the report match a direct call
        # to predict_outcomes on a row that already has the protocol applied.
        pipeline, df = _get_fitted_pipeline()
        protocols = list(df["protocol"].unique())
        row = df.iloc[0].copy()

        for protocol in protocols:
            # Build the row as the method should internally see it
            row_with_protocol = row.copy()
            row_with_protocol["protocol"] = protocol
            direct = pipeline.predict_outcomes(pd.DataFrame([row_with_protocol]))

            report = pipeline.generate_counseling_report(row.copy(), protocol)

            tol = 1e-9
            assert abs(
                report["pregnancy"]["point_estimate"]
                - float(direct["pregnancy_prob"].iloc[0])
            ) <= tol, f"Protocol '{protocol}': pregnancy point_estimate mismatch"
            assert abs(
                report["ongoing_pregnancy"]["point_estimate"]
                - float(direct["ongoing_pregnancy_prob"].iloc[0])
            ) <= tol, f"Protocol '{protocol}': ongoing_pregnancy point_estimate mismatch"
            assert abs(
                report["live_birth"]["point_estimate"]
                - float(direct["live_birth_prob"].iloc[0])
            ) <= tol, f"Protocol '{protocol}': live_birth point_estimate mismatch"