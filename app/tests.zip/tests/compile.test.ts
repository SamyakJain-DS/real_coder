import { describe, it, expect } from "vitest";
import { loadModule, defaultTheme, bytesEqual } from "./helpers";

describe("SlideDeckCompiler.compile - Expected Interface", () => {
  it("C1: returns { deck, html, pdf } with the declared types", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# Title One\nbody one\n---\n# Title Two\nbody two";
      const result = await compiler.compile(md, {});
      if (!result) throw new Error("compile returned falsy");
      if (!result.deck || !Array.isArray(result.deck.slides))
        throw new Error("deck or deck.slides missing/invalid");
      if (typeof result.html !== "string")
        throw new Error("html is not a string");
      if (!(result.pdf instanceof Uint8Array))
        throw new Error("pdf is not a Uint8Array");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("C2: compile() output matches parse() + renderHtml() + renderPdf() composed for the same inputs", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# A\nbody A\n---\n# B\nbody B";
      const themeOverride = { accentColor: "#abcdef" };

      const result = await compiler.compile(md, themeOverride);

      const deck = compiler.parse(md);
      const html: string = compiler.renderHtml(deck, themeOverride);
      const pdf: Uint8Array = await compiler.renderPdf(deck, themeOverride, md);

      if (JSON.stringify(result.deck) !== JSON.stringify(deck))
        throw new Error("compile().deck differs from parse(markdownSource)");
      if (result.html !== html)
        throw new Error(
          "compile().html differs from renderHtml(deck, themeOverride)",
        );
      if (!bytesEqual(result.pdf, pdf))
        throw new Error(
          `compile().pdf differs from renderPdf(deck, themeOverride, markdownSource) (lenC=${result.pdf.length}, lenR=${pdf.length})`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});
