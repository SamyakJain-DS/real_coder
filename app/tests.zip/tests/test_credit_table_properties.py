import numpy as np
import pandas as pd
import pytest


def _events() -> pd.DataFrame:
    df = pd.DataFrame(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T02:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J2",
                "touchpoint_index": 0,
                "channel": "Search",
                "touchpoint_ts": "2026-01-02T00:00:00Z",
                "converted": 0,
            },
            {
                "journey_id": "J2",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-02T01:00:00Z",
                "converted": 0,
            },
        ]
    )
    df["touchpoint_ts"] = pd.to_datetime(df["touchpoint_ts"], utc=True)
    return df


def _channel_cols(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if c not in {"journey_id", "converted"}]


@pytest.mark.parametrize("model,kwargs", [
    ("first_touch", {}),
    ("last_touch", {}),
    ("linear", {}),
    ("time_decay", {}),
    ("markov", {}),
    ("shapley", {"num_permutations": 50, "random_seed": 0}),
])
def test_credit_table_has_one_row_per_journey(import_or_fail, model, kwargs):
    attr = import_or_fail("app.attribution")
    credits = attr.compute_journey_channel_credits(_events(), model=model, **kwargs)
    assert credits["journey_id"].is_unique
    assert set(credits["journey_id"].tolist()) == {"J1", "J2"}


def test_credit_table_includes_converted_column_with_0_and_1(import_or_fail):
    attr = import_or_fail("app.attribution")
    credits = attr.compute_journey_channel_credits(_events(), model="linear")
    assert set(credits["converted"].tolist()) == {0, 1}


def test_credit_table_includes_one_column_per_observed_channel(import_or_fail):
    attr = import_or_fail("app.attribution")
    credits = attr.compute_journey_channel_credits(_events(), model="linear")
    assert set(_channel_cols(credits)) == {"Email", "Search"}


@pytest.mark.parametrize("model,kwargs", [
    ("first_touch", {}),
    ("last_touch", {}),
    ("linear", {}),
    ("time_decay", {}),
    ("markov", {}),
    ("shapley", {"num_permutations": 50, "random_seed": 0}),
])
def test_credit_rows_sum_to_one(import_or_fail, model, kwargs):
    attr = import_or_fail("app.attribution")
    credits = attr.compute_journey_channel_credits(_events(), model=model, **kwargs)
    sums = credits[_channel_cols(credits)].sum(axis=1).to_numpy(dtype=float)
    assert np.allclose(sums, 1.0)


def test_credit_values_are_finite_floats(import_or_fail):
    attr = import_or_fail("app.attribution")
    credits = attr.compute_journey_channel_credits(_events(), model="time_decay")
    vals = credits[_channel_cols(credits)].to_numpy(dtype=float)
    assert np.isfinite(vals).all()


def test_credit_values_are_numeric_floats(import_or_fail):
    attr = import_or_fail("app.attribution")
    credits = attr.compute_journey_channel_credits(_events(), model="linear")
    for col in _channel_cols(credits):
        for v in credits[col].tolist():
            assert isinstance(v, (float, np.floating))

def test_channel_universe_for_simple_models_excludes_train_events_only_channels(import_or_fail):
    attr = import_or_fail("app.attribution")
    train_events = pd.DataFrame(
        [
            {
                "journey_id": "T1",
                "touchpoint_index": 0,
                "channel": "TrainOnly",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            }
        ]
    )
    train_events["touchpoint_ts"] = pd.to_datetime(train_events["touchpoint_ts"], utc=True)
    events = pd.DataFrame(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-02T00:00:00Z",
                "converted": 1,
            }
        ]
    )
    events["touchpoint_ts"] = pd.to_datetime(events["touchpoint_ts"], utc=True)
    for model in ("first_touch", "last_touch", "linear", "time_decay"):
        credits = attr.compute_journey_channel_credits(events, model=model, train_events=train_events)
        channel_cols = [c for c in credits.columns if c not in {"journey_id", "converted"}]
        assert "TrainOnly" not in channel_cols, f"model={model} incorrectly included train_events channels"
        assert "Email" in channel_cols


def test_channel_universe_uses_trimmed_channel_names(import_or_fail):
    attr = import_or_fail("app.attribution")
    df = pd.DataFrame(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "  Email  ",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J2",
                "touchpoint_index": 0,
                "channel": "Search",
                "touchpoint_ts": "2026-01-02T00:00:00Z",
                "converted": 0,
            },
        ]
    )
    df["touchpoint_ts"] = pd.to_datetime(df["touchpoint_ts"], utc=True)
    credits = attr.compute_journey_channel_credits(df, model="first_touch")
    channel_cols = [c for c in credits.columns if c not in {"journey_id", "converted"}]
    assert "Email" in channel_cols
    assert "  Email  " not in channel_cols

def test_markov_and_shapley_include_train_events_channels_in_output_columns(import_or_fail):
    attr = import_or_fail("app.attribution")
    train_events = pd.DataFrame(
        [
            {
                "journey_id": "T1",
                "touchpoint_index": 0,
                "channel": "TrainOnly",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "T2",
                "touchpoint_index": 0,
                "channel": "Shared",
                "touchpoint_ts": "2026-01-02T00:00:00Z",
                "converted": 0,
            },
        ]
    )
    train_events["touchpoint_ts"] = pd.to_datetime(train_events["touchpoint_ts"], utc=True)
    events = pd.DataFrame(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Shared",
                "touchpoint_ts": "2026-01-03T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J2",
                "touchpoint_index": 0,
                "channel": "Shared",
                "touchpoint_ts": "2026-01-04T00:00:00Z",
                "converted": 0,
            },
        ]
    )
    events["touchpoint_ts"] = pd.to_datetime(events["touchpoint_ts"], utc=True)
    for model in ("markov", "shapley"):
        credits = attr.compute_journey_channel_credits(
            events, model=model, train_events=train_events, num_permutations=10, random_seed=0
        )
        channel_cols = [c for c in credits.columns if c not in {"journey_id", "converted"}]
        assert "TrainOnly" in channel_cols, f"{model}: train_events-only channel missing"
        assert "Shared" in channel_cols, f"{model}: shared channel missing"
        # Journeys in events have no TrainOnly touchpoints; credit must be 0.0
        assert (credits["TrainOnly"] == pytest.approx(0.0)).all(), f"{model}: TrainOnly credit should be 0.0"

def test_markov_and_shapley_channel_universe_trims_whitespace_from_train_events(import_or_fail):
    attr = import_or_fail("app.attribution")
    train_events = pd.DataFrame([
        {"journey_id": "T1", "touchpoint_index": 0, "channel": "  Email  ",
         "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
        {"journey_id": "T2", "touchpoint_index": 0, "channel": "  Email  ",
         "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 0},
    ])
    train_events["touchpoint_ts"] = pd.to_datetime(train_events["touchpoint_ts"], utc=True)
    events = pd.DataFrame([
        {"journey_id": "J1", "touchpoint_index": 0, "channel": " Search ",
         "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 1},
        {"journey_id": "J2", "touchpoint_index": 0, "channel": " Search ",
         "touchpoint_ts": "2026-01-04T00:00:00Z", "converted": 0},
    ])
    events["touchpoint_ts"] = pd.to_datetime(events["touchpoint_ts"], utc=True)
    for model in ("markov", "shapley"):
        credits = attr.compute_journey_channel_credits(
            events, model=model, train_events=train_events, num_permutations=10, random_seed=0
        )
        channel_cols = [c for c in credits.columns if c not in {"journey_id", "converted"}]
        assert "Email" in channel_cols, f"{model}: trimmed train_events channel missing"
        assert "Search" in channel_cols, f"{model}: trimmed events channel missing"
        assert "  Email  " not in channel_cols, f"{model}: untrimmed train_events channel present"
        assert " Search " not in channel_cols, f"{model}: untrimmed events channel present"