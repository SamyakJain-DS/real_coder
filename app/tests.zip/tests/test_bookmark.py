"""
F2P test suite for the Personal Command Bookmark CLI Tool.
"""

import importlib
import importlib.util
import json
import os
import subprocess
import sys
import pytest
from pathlib import Path
from unittest import mock

_TEST_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.join(_TEST_DIR, "..")
sys.path.insert(0, _PARENT_DIR)


# ------------------------------------------------------------------------------
# Lazy-import fixture
# Returns None on ImportError so every dependent test is reported as
# FAILED (not ERROR) when the codebase is empty.
# ------------------------------------------------------------------------------

@pytest.fixture(scope="session")
def main_fn():
    """
    Session-scoped fixture that lazily imports `main` from bookmark.
    Returns None on ImportError so that dependent tests are reported as
    FAILED rather than ERROR when the codebase is empty.
    """
    try:
        mod = importlib.import_module("bookmark")
        return mod.main
    except ImportError:
        return None


# ------------------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------------------

def run_main(main_fn, args):
    """
    Invoke main_fn with the given args list. Returns the exit code.
    Explicitly fails (not errors) when main_fn is None so that every
    dependent test is reported as FAILED on an empty repository.
    """
    if main_fn is None:
        pytest.fail("bookmark module could not be imported")
    exit_code = 0
    try:
        main_fn(args)
    except SystemExit as e:
        exit_code = e.code if e.code is not None else 0
    return exit_code


# ------------------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------------------

@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    """
    Redirect the home directory to tmp_path so that ~/.bookmarks.json
    is isolated per test and never touches the real home directory.
    """
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    return tmp_path


@pytest.fixture
def bookmarks_path(home_dir):
    return home_dir / ".bookmarks.json"


# ------------------------------------------------------------------------------
# Storage
# ------------------------------------------------------------------------------

class TestStorage:

    def test_bookmarks_file_created_on_first_save(self, main_fn, home_dir, bookmarks_path):
        assert not bookmarks_path.exists()
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        assert bookmarks_path.exists()

    def test_bookmarks_file_is_json_array(self, main_fn, home_dir, bookmarks_path):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        data = json.loads(bookmarks_path.read_text())
        assert isinstance(data, list)
        assert all(isinstance(item, dict) for item in data)

    def test_bookmark_entry_values_match_input(self, main_fn, home_dir, bookmarks_path):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        data = json.loads(bookmarks_path.read_text())
        entry = data[0]
        assert entry["name"] == "find-large"
        assert entry["command"] == "find . -size +100M"
        assert entry["description"] == "Find files over 100MB"


# ------------------------------------------------------------------------------
# Save Command
# ------------------------------------------------------------------------------

class TestSaveCommand:

    def test_save_adds_new_bookmark(self, main_fn, home_dir, bookmarks_path):
        run_main(main_fn, ["save", "my-cmd", "echo hello", "Say hello"])
        data = json.loads(bookmarks_path.read_text())
        assert len(data) == 1

    def test_save_multiple_bookmarks_accumulate(self, main_fn, home_dir, bookmarks_path):
        run_main(main_fn, ["save", "cmd1", "echo one", "First command"])
        run_main(main_fn, ["save", "cmd2", "echo two", "Second command"])
        data = json.loads(bookmarks_path.read_text())
        assert len(data) == 2

    def test_save_overwrites_existing_entry_with_same_name(self, main_fn, home_dir, bookmarks_path):
        run_main(main_fn, ["save", "my-cmd", "echo hello", "Old description"])
        run_main(main_fn, ["save", "my-cmd", "echo world", "New description"])
        data = json.loads(bookmarks_path.read_text())
        assert len(data) == 1
        assert data[0]["command"] == "echo world"
        assert data[0]["description"] == "New description"


# ------------------------------------------------------------------------------
# Find Command
# ------------------------------------------------------------------------------

class TestFindCommand:

    def test_find_matches_by_name_subsequence(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        # "fnlg" is a non-contiguous subsequence of "find-large" (f,n,l,g)
        # but does not appear in "find . -size +100M" (no 'l') or "Find files over 100MB" (no 'g')
        run_main(main_fn, ["find", "fnlg"])
        captured = capsys.readouterr()
        assert "find-large" in captured.out

    def test_find_matches_by_command_field_subsequence(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        # "fnd." is a non-contiguous subsequence of "find . -size +100M" (f,n,d,.)
        # but does not appear in "find-large" (no dot) or "Find files over 100MB" (no dot)
        run_main(main_fn, ["find", "fnd."])
        captured = capsys.readouterr()
        assert "find-large" in captured.out

    def test_find_matches_by_description_field_subsequence(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        # "fls" is a non-contiguous subsequence of "Find files over 100MB" (f,l,s)
        # but does not appear in "find-large" (no 's') or "find . -size +100M" (no 'l')
        run_main(main_fn, ["find", "fls"])
        captured = capsys.readouterr()
        assert "find-large" in captured.out

    def test_find_is_case_insensitive(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        run_main(main_fn, ["find", "LARGE"])
        captured = capsys.readouterr()
        assert "find-large" in captured.out

    def test_find_displays_name_label(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        run_main(main_fn, ["find", "large"])
        captured = capsys.readouterr()
        assert "Name: find-large" in captured.out

    def test_find_displays_command_label(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        run_main(main_fn, ["find", "large"])
        captured = capsys.readouterr()
        assert "Command: find . -size +100M" in captured.out

    def test_find_displays_description_label(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        run_main(main_fn, ["find", "large"])
        captured = capsys.readouterr()
        assert "Description: Find files over 100MB" in captured.out

    def test_find_multiple_results_separated_by_blank_line(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "cmd-alpha", "echo alpha", "Alpha command"])
        run_main(main_fn, ["save", "cmd-beta", "echo beta", "Beta command"])
        run_main(main_fn, ["find", "cmd"])
        captured = capsys.readouterr()
        assert "Name: cmd-alpha" in captured.out
        assert "Name: cmd-beta" in captured.out
        blocks = [b for b in captured.out.split("\n\n") if b.strip()]
        assert len(blocks) == 2
        for block in blocks:
            lines = block.strip().split("\n")
            assert len(lines) == 3
            assert lines[0].startswith("Name: ")
            assert lines[1].startswith("Command: ")
            assert lines[2].startswith("Description: ")

    def test_find_no_match_prints_no_bookmarks_match_message(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        run_main(main_fn, ["find", "zzznomatch"])
        captured = capsys.readouterr()
        assert "No bookmarks match 'zzznomatch'" in captured.out

    def test_find_does_not_return_non_matching_bookmarks(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "find-large", "find . -size +100M", "Find files over 100MB"])
        run_main(main_fn, ["save", "git-log", "git log --oneline", "Short git log"])
        run_main(main_fn, ["find", "large"])
        captured = capsys.readouterr()
        assert "find-large" in captured.out
        assert "git-log" not in captured.out


    def test_find_does_not_match_cross_field_subsequence(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "ab", "cd", "ef"])
        run_main(main_fn, ["find", "ad"])
        captured = capsys.readouterr()
        assert "No bookmarks match 'ad'" in captured.out

# ------------------------------------------------------------------------------
# List Command
# ------------------------------------------------------------------------------

class TestListCommand:

    def test_list_shows_all_saved_bookmarks(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "cmd1", "echo one", "First"])
        run_main(main_fn, ["save", "cmd2", "echo two", "Second"])
        run_main(main_fn, ["list"])
        captured = capsys.readouterr()
        assert "Name: cmd1" in captured.out
        assert "Name: cmd2" in captured.out

    def test_list_displays_name_label(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "my-cmd", "echo hello", "Say hello"])
        run_main(main_fn, ["list"])
        captured = capsys.readouterr()
        assert "Name: my-cmd" in captured.out

    def test_list_displays_command_label(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "my-cmd", "echo hello", "Say hello"])
        run_main(main_fn, ["list"])
        captured = capsys.readouterr()
        assert "Command: echo hello" in captured.out

    def test_list_displays_description_label(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "my-cmd", "echo hello", "Say hello"])
        run_main(main_fn, ["list"])
        captured = capsys.readouterr()
        assert "Description: Say hello" in captured.out

    def test_list_multiple_bookmarks_separated_by_blank_line(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "cmd1", "echo one", "First"])
        run_main(main_fn, ["save", "cmd2", "echo two", "Second"])
        run_main(main_fn, ["list"])
        captured = capsys.readouterr()
        blocks = [b for b in captured.out.split("\n\n") if b.strip()]
        assert len(blocks) == 2
        for block in blocks:
            lines = block.strip().split("\n")
            assert len(lines) == 3
            assert lines[0].startswith("Name: ")
            assert lines[1].startswith("Command: ")
            assert lines[2].startswith("Description: ")

    def test_list_empty_prints_no_bookmarks_saved(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["list"])
        captured = capsys.readouterr()
        assert "No bookmarks saved" in captured.out


# ------------------------------------------------------------------------------
# Copy Command
# ------------------------------------------------------------------------------

class TestCopyCommand:

    def test_copy_calls_pyperclip_with_correct_command(self, main_fn, home_dir, monkeypatch):
        run_main(main_fn, ["save", "my-cmd", "echo hello", "Say hello"])
        run_main(main_fn, ["save", "other-cmd", "echo world", "Say world"])
        calls = []
        def fake_copy(text):
            calls.append(text)
        monkeypatch.setattr("pyperclip.copy", fake_copy)
        bookmark_mod = sys.modules.get("bookmark")
        if bookmark_mod is not None:
            monkeypatch.setattr(bookmark_mod, "copy", fake_copy, raising=False)
        run_main(main_fn, ["copy", "my-cmd"])
        assert "echo hello" in calls

    def test_copy_prints_confirmation_message(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["save", "my-cmd", "echo hello", "Say hello"])
        with mock.patch("pyperclip.copy"):
            run_main(main_fn, ["copy", "my-cmd"])
        captured = capsys.readouterr()
        assert "Copied 'my-cmd' to clipboard" in captured.out

    def test_copy_missing_bookmark_exits_code_1(self, main_fn, home_dir):
        exit_code = run_main(main_fn, ["copy", "nonexistent"])
        assert exit_code == 1

    def test_copy_missing_bookmark_prints_error_to_stdout(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["copy", "nonexistent"])
        captured = capsys.readouterr()
        assert "No bookmark named 'nonexistent'" in captured.out


# ------------------------------------------------------------------------------
# Run Command
# ------------------------------------------------------------------------------

class TestRunCommand:

    def test_run_executes_command_and_prints_stdout(self, main_fn, home_dir, capsys):
        # echo $HOME requires shell variable expansion - only works via system shell execution
        # home_dir fixture sets HOME to tmp_path, so the expanded value is predictable
        run_main(main_fn, ["save", "show-home", "echo $HOME", "Show home directory"])
        run_main(main_fn, ["run", "show-home"])
        captured = capsys.readouterr()
        assert str(home_dir) in captured.out

    def test_run_missing_bookmark_exits_code_1(self, main_fn, home_dir):
        exit_code = run_main(main_fn, ["run", "nonexistent"])
        assert exit_code == 1

    def test_run_missing_bookmark_prints_error_to_stdout(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["run", "nonexistent"])
        captured = capsys.readouterr()
        assert "No bookmark named 'nonexistent'" in captured.out


# ------------------------------------------------------------------------------
# Unknown Subcommand
# ------------------------------------------------------------------------------

class TestUnknownSubcommand:

    def test_unknown_subcommand_exits_code_1(self, main_fn, home_dir):
        exit_code = run_main(main_fn, ["unknowncmd"])
        assert exit_code == 1

    def test_unknown_subcommand_prints_usage_to_stdout(self, main_fn, home_dir, capsys):
        run_main(main_fn, ["unknowncmd"])
        captured = capsys.readouterr()
        assert "Usage: bookmark {save|find|list|copy|run}" in captured.out


# ------------------------------------------------------------------------------
# main() Programmatic Interface
# ------------------------------------------------------------------------------

class TestMainInterface:

    def test_main_none_reads_from_sys_argv(self, main_fn, home_dir, monkeypatch, capsys):
        if main_fn is None:
            pytest.fail("bookmark module could not be imported")
        monkeypatch.setattr(sys, "argv", ["bookmark.py", "list"])
        run_main(main_fn, None)
        captured = capsys.readouterr()
        assert "No bookmarks saved" in captured.out


# ------------------------------------------------------------------------------
# __main__ Entry Point
# ------------------------------------------------------------------------------

class TestMainBlock:

    def test_script_invocation_via_main_block(self, home_dir):
        spec = importlib.util.find_spec("bookmark")
        if spec is None:
            pytest.fail("bookmark module could not be found")
        bookmark_script = spec.origin
        env = {**os.environ, "HOME": str(home_dir), "USERPROFILE": str(home_dir)}
        result = subprocess.run(
            [sys.executable, bookmark_script, "list"],
            capture_output=True,
            text=True,
            env=env
        )
        assert "No bookmarks saved" in result.stdout