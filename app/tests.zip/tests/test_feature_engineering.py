"""Tests for the engineered feature matrix described in section 3.

These tests assert per-feature *values* and *dtypes* and the
``channel_share_<channel>`` enumeration / ordering rules. They locate
the persisted feature matrix on the pipeline by introspection (any
``DataFrame`` attribute carrying the documented feature columns), so no
specific attribute name is assumed - but the matrix MUST be persisted
somewhere for these tests to run, which simultaneously pins the
"feature matrix is persisted" requirement.

The ``deterministic_donations`` fixture is hand-crafted so that every
expected feature value below is straightforwardly recomputable:

* ``max(date) == 2024-12-01``  ->  resolved ``as_of_date == 2024-11-01``.
* Donor C's first donation is ``2024-11-20``, so it is excluded from
  the feature matrix; donors A, B, D, E remain.
"""

from __future__ import annotations

import pandas as pd
import pytest


EXPECTED_RFM_AND_TENURE = {
    # donor: (recency_days, frequency, monetary_total, monetary_mean, tenure_days)
    "A": (31, 3, 600.0, 200.0, 305),
    "B": (17, 2, 300.0, 150.0,  92),
    "D": (61, 2, 200.0, 100.0, 245),
    "E": (47, 2, 150.0,  75.0, 184),
}

EXPECTED_CHANNEL_SHARES = {
    "A": {"email": 2.0 / 3.0, "mail": 1.0 / 3.0, "phone": 0.0},
    "B": {"email": 0.0,       "mail": 0.0,       "phone": 1.0},
    "D": {"email": 0.0,       "mail": 1.0,       "phone": 0.0},
    "E": {"email": 0.5,       "mail": 0.5,       "phone": 0.0},
}


def _row(fm, donor_ids, donor):
    return fm.iloc[donor_ids.index(donor)]


def test_feature_matrix_contains_only_eligible_donors(
    fitted_deterministic, locate_feature_matrix, feature_donor_ids
):
    """Donor C's first donation (2024-11-20) is strictly after the
    resolved ``as_of_date`` (2024-11-01) and therefore must be absent
    from the feature matrix; donors A, B, D and E remain - exactly one
    row each."""

    fm = locate_feature_matrix(fitted_deterministic)
    donor_ids = feature_donor_ids(fm)

    assert sorted(donor_ids) == ["A", "B", "D", "E"]
    assert len(donor_ids) == len(set(donor_ids))


def test_recency_days_value_and_dtype(
    fitted_deterministic, locate_feature_matrix, feature_donor_ids
):
    """``recency_days`` equals the integer day difference between
    ``as_of_date`` and the donor's most recent donation date on or
    before ``as_of_date``, and the column dtype is ``int64``."""

    fm = locate_feature_matrix(fitted_deterministic)
    donor_ids = feature_donor_ids(fm)

    for donor, (expected, *_rest) in EXPECTED_RFM_AND_TENURE.items():
        actual = _row(fm, donor_ids, donor)["recency_days"]
        assert actual == expected, f"recency_days[{donor}] = {actual}, expected {expected}"
    assert fm["recency_days"].dtype == "int64"


def test_frequency_value_and_dtype(
    fitted_deterministic, locate_feature_matrix, feature_donor_ids
):
    """``frequency`` equals the count of donations on or before
    ``as_of_date`` and has dtype ``int64``."""

    fm = locate_feature_matrix(fitted_deterministic)
    donor_ids = feature_donor_ids(fm)

    for donor, (_r, expected, *_rest) in EXPECTED_RFM_AND_TENURE.items():
        actual = _row(fm, donor_ids, donor)["frequency"]
        assert actual == expected, f"frequency[{donor}] = {actual}, expected {expected}"
    assert fm["frequency"].dtype == "int64"


def test_monetary_total_value_and_dtype(
    fitted_deterministic, locate_feature_matrix, feature_donor_ids
):
    """``monetary_total`` equals the sum of ``donation_amount`` on or
    before ``as_of_date`` and has dtype ``float64``."""

    fm = locate_feature_matrix(fitted_deterministic)
    donor_ids = feature_donor_ids(fm)

    for donor, (_r, _f, expected, *_rest) in EXPECTED_RFM_AND_TENURE.items():
        actual = _row(fm, donor_ids, donor)["monetary_total"]
        assert actual == pytest.approx(expected), f"monetary_total[{donor}] = {actual}, expected {expected}"
    assert fm["monetary_total"].dtype == "float64"


def test_monetary_mean_value_and_dtype(
    fitted_deterministic, locate_feature_matrix, feature_donor_ids
):
    """``monetary_mean`` equals the arithmetic mean of
    ``donation_amount`` on or before ``as_of_date`` and has dtype
    ``float64``."""

    fm = locate_feature_matrix(fitted_deterministic)
    donor_ids = feature_donor_ids(fm)

    for donor, (_r, _f, _mt, expected, _t) in EXPECTED_RFM_AND_TENURE.items():
        actual = _row(fm, donor_ids, donor)["monetary_mean"]
        assert actual == pytest.approx(expected), f"monetary_mean[{donor}] = {actual}, expected {expected}"
    assert fm["monetary_mean"].dtype == "float64"


def test_tenure_days_value_and_dtype(
    fitted_deterministic, locate_feature_matrix, feature_donor_ids
):
    """``tenure_days`` equals the integer day difference between
    ``as_of_date`` and the donor's first donation date and has dtype
    ``int64``."""

    fm = locate_feature_matrix(fitted_deterministic)
    donor_ids = feature_donor_ids(fm)

    for donor, (*_rest, expected) in EXPECTED_RFM_AND_TENURE.items():
        actual = _row(fm, donor_ids, donor)["tenure_days"]
        assert actual == expected, f"tenure_days[{donor}] = {actual}, expected {expected}"
    assert fm["tenure_days"].dtype == "int64"


def test_channel_share_columns_exist_for_every_distinct_channel(
    fitted_deterministic, locate_feature_matrix
):
    """The feature matrix exposes one ``channel_share_<channel>`` column
    for every distinct channel appearing anywhere in ``donations``
    (here: email, mail, phone) - and **no extras**. The ``len`` check
    pins the bidirectional version of req 21: every distinct channel
    gets a column AND no spurious ``channel_share_*`` columns are
    fabricated for channels not present in the input."""

    fm = locate_feature_matrix(fitted_deterministic)
    channel_cols = [c for c in fm.columns if c.startswith("channel_share_")]
    for channel in ("email", "mail", "phone"):
        assert f"channel_share_{channel}" in fm.columns, channel
    assert len(channel_cols) == 3, (
        f"Expected exactly 3 channel_share_* columns (one per distinct "
        f"channel in the input); found {len(channel_cols)}: {channel_cols}"
    )


def test_channel_share_columns_are_ordered_alphabetically(
    fitted_deterministic, locate_feature_matrix
):
    """The ``channel_share_*`` columns appear in alphabetical order of
    the underlying channel value."""

    fm = locate_feature_matrix(fitted_deterministic)
    channel_cols = [c for c in fm.columns if c.startswith("channel_share_")]

    assert channel_cols == [
        "channel_share_email",
        "channel_share_mail",
        "channel_share_phone",
    ]


def test_channel_share_values_and_dtype(
    fitted_deterministic, locate_feature_matrix, feature_donor_ids
):
    """Each ``channel_share_<channel>`` value equals the donor's
    donation count through that channel divided by the donor's total
    donation count (both evaluated on or before ``as_of_date``), and
    the column dtype is ``float64``."""

    fm = locate_feature_matrix(fitted_deterministic)
    donor_ids = feature_donor_ids(fm)

    for donor, expected_shares in EXPECTED_CHANNEL_SHARES.items():
        row = _row(fm, donor_ids, donor)
        for channel, expected in expected_shares.items():
            actual = row[f"channel_share_{channel}"]
            assert actual == pytest.approx(expected), (
                f"channel_share_{channel}[{donor}] = {actual}, expected {expected}"
            )
    for channel in ("email", "mail", "phone"):
        assert fm[f"channel_share_{channel}"].dtype == "float64"


def test_channel_share_includes_channels_present_only_in_excluded_or_post_as_of_rows(
    DonorPipeline, deterministic_donations, make_donations, locate_feature_matrix
):
    """req 21: ``channel_share_<channel>`` columns must be generated for
    every distinct channel value present **anywhere** in ``donations``,
    not only for channels appearing in the eligible donors' pre-
    ``as_of_date`` history.

    Strategy: introduce a brand-new channel ``"sms"`` in two rows that
    are *invisible* to a hypothetical implementation that builds the
    channel set from the eligible-donor feature subset:

    * one ``"sms"`` row for donor C, whose first donation date
      (2024-11-20) is strictly after the resolved ``as_of_date``
      (2024-11-01) - so C is *excluded* from the feature matrix; and
    * one ``"sms"`` row for donor A dated 2024-11-20, i.e. **after**
      ``as_of_date`` - so it does not contribute to A's pre-``as_of``
      channel counts.

    A spec-compliant implementation must still emit
    ``channel_share_sms`` (because ``"sms"`` exists *anywhere* in
    ``donations``) and the value must be ``0.0`` for every eligible
    donor (because none of them donated through ``"sms"`` on or before
    ``as_of_date``).
    """

    extras = make_donations(
        [
            {
                "donor_id": "C",
                "donation_amount": 10.0,
                "date": "2024-11-25",
                "campaign": "c1",
                "channel": "sms",
            },
            {
                "donor_id": "A",
                "donation_amount": 20.0,
                "date": "2024-11-20",
                "campaign": "c1",
                "channel": "sms",
            },
        ]
    )
    augmented = pd.concat([deterministic_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(augmented)
    fm = locate_feature_matrix(pipeline)

    assert "channel_share_sms" in fm.columns, (
        "channel_share_sms must exist because 'sms' appears in donations, "
        "even though it only shows up in excluded donor C's history and in "
        "A's post-as_of_date donation."
    )
    assert (fm["channel_share_sms"] == 0.0).all(), (
        "Every eligible donor's channel_share_sms must be 0.0 because none "
        "of them donated through 'sms' on or before as_of_date."
    )


def test_donor_with_first_donation_at_exact_as_of_date_is_included(
    DonorPipeline,
    deterministic_donations,
    make_donations,
    locate_feature_matrix,
    feature_donor_ids,
):
    """A donor whose only donation lands **exactly** on the resolved
    ``as_of_date`` must be present in the feature matrix (req 15: the
    eligibility predicate is closed at the boundary -
    ``first_donation <= as_of``). The same donor's ``recency_days``
    and ``tenure_days`` must both be 0 because their first and most
    recent donation are both at ``as_of_date`` itself (req 16, 20
    boundaries). Their ``frequency`` is exactly 1.

    This guards three families of off-by-one bugs in a single shot:

    * dropping the boundary donor entirely (eligibility uses ``<``),
    * subtracting one extra day from the recency / tenure deltas, and
    * using ``< as_of`` for the historical donation count so the
      donor would silently degrade to ``frequency == 0``.
    """

    as_of = deterministic_donations["date"].max() - pd.Timedelta(days=30)
    extras = make_donations(
        [
            {
                "donor_id": "BOUNDARY",
                "donation_amount": 50.0,
                "date": as_of,
                "campaign": "c1",
                "channel": "email",
            }
        ]
    )
    augmented = pd.concat([deterministic_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(augmented)
    fm = locate_feature_matrix(pipeline)
    donor_ids = feature_donor_ids(fm)

    assert "BOUNDARY" in donor_ids, (
        "Donor with first_donation == as_of_date must be included in the "
        "feature matrix (eligibility predicate is closed at the boundary)."
    )
    row = fm.iloc[donor_ids.index("BOUNDARY")]
    assert row["recency_days"] == 0
    assert row["tenure_days"] == 0
    assert row["frequency"] == 1
    assert row["monetary_total"] == pytest.approx(50.0)
    assert row["monetary_mean"] == pytest.approx(50.0)
