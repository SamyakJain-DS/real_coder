"""
Tests for Build Session Logging endpoints.
Covers: create_build_session, get_build_session,
        log_turning_pass, log_finger_hole_undercut,
        log_joint_lapping, log_tuning_rig_session.
"""


class TestCreateBuildSession:
    def test_create_build_session_response_fields(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.post(
            f"/commissions/{cid}/build-sessions",
            json={"session_date": "2026-05-01", "notes": "Rough shaping"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["commission_id"] == cid
        assert "session_date" in data
        assert "notes" in data

    def test_create_build_session_notes_nullable(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.post(
            f"/commissions/{cid}/build-sessions",
            json={"session_date": "2026-05-02"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["notes"] is None

    def test_create_build_session_nonexistent_commission_returns_404(self, client, created_commission):
        cid = created_commission["id"]
        valid_resp = client.post(
            f"/commissions/{cid}/build-sessions",
            json={"session_date": "2026-05-01"},
        )
        assert valid_resp.status_code == 201, "Route must exist for valid IDs"
        resp = client.post(
            "/commissions/99999/build-sessions",
            json={"session_date": "2026-05-01"},
        )
        assert resp.status_code == 404
        assert resp.json().get("detail")

    def test_commission_supports_multiple_build_sessions(self, client, created_commission):
        """A commission can have one or more build sessions; all appear in GET /commissions/{id}."""
        cid = created_commission["id"]
        r1 = client.post(f"/commissions/{cid}/build-sessions",
                         json={"session_date": "2026-05-01", "notes": "First session"})
        r2 = client.post(f"/commissions/{cid}/build-sessions",
                         json={"session_date": "2026-05-02", "notes": "Second session"})
        assert r1.status_code == 201
        assert r2.status_code == 201
        sid1, sid2 = r1.json()["id"], r2.json()["id"]

        resp = client.get(f"/commissions/{cid}")
        session_ids = [s["id"] for s in resp.json()["build_sessions"]]
        assert sid1 in session_ids
        assert sid2 in session_ids


class TestGetBuildSession:
    def test_get_build_session_contains_session_fields(self, client, created_build_session, created_commission):
        sid = created_build_session["id"]
        resp = client.get(f"/build-sessions/{sid}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["id"] == sid
        assert data["commission_id"] == created_commission["id"]
        assert "session_date" in data
        assert "notes" in data

    def test_get_build_session_has_nested_array_keys(self, client, created_build_session):
        """Response must contain the four specified nested array keys."""
        sid = created_build_session["id"]
        resp = client.get(f"/build-sessions/{sid}")
        data = resp.json()
        assert "turning_passes" in data
        assert "undercuts" in data
        assert "lappings" in data
        assert "tuning_sessions" in data
        assert isinstance(data["turning_passes"], list)
        assert isinstance(data["undercuts"], list)
        assert isinstance(data["lappings"], list)
        assert isinstance(data["tuning_sessions"], list)

    def test_get_build_session_nonexistent_returns_404(self, client, created_build_session):
        sid = created_build_session["id"]
        valid_resp = client.get(f"/build-sessions/{sid}")
        assert valid_resp.status_code == 200, "Route must exist for valid IDs"
        resp = client.get("/build-sessions/99999")
        assert resp.status_code == 404
        assert resp.json().get("detail")


class TestLogTurningPass:
    def test_log_turning_pass_response_fields(self, client, created_build_session):
        sid = created_build_session["id"]
        payload = {
            "pass_number": 1,
            "target_diameter_mm": 19.0,
            "achieved_diameter_mm": 19.2,
            "tool_used": "roughing gouge",
        }
        resp = client.post(f"/build-sessions/{sid}/turning-passes", json=payload)
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["build_session_id"] == sid
        assert data["pass_number"] == 1
        assert data["target_diameter_mm"] == 19.0
        assert data["achieved_diameter_mm"] == 19.2
        assert data["tool_used"] == "roughing gouge"

    def test_log_turning_pass_nonexistent_session_returns_404(self, client, created_build_session):
        sid = created_build_session["id"]
        payload = {
            "pass_number": 1,
            "target_diameter_mm": 19.0,
            "achieved_diameter_mm": 19.2,
            "tool_used": "roughing gouge",
        }
        valid_resp = client.post(f"/build-sessions/{sid}/turning-passes", json=payload)
        assert valid_resp.status_code == 201, "Route must exist for valid IDs"
        resp = client.post("/build-sessions/99999/turning-passes", json=payload)
        assert resp.status_code == 404
        assert resp.json().get("detail")


class TestLogFingerHoleUndercut:
    def test_log_undercut_response_fields(self, client, created_build_session):
        sid = created_build_session["id"]
        payload = {
            "hole_number": 3,
            "undercut_depth_mm": 0.8,
            "undercut_angle_degrees": 20.0,
            "is_thumb_hole": True,
        }
        resp = client.post(f"/build-sessions/{sid}/undercuts", json=payload)
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["build_session_id"] == sid
        assert data["hole_number"] == 3
        assert data["undercut_depth_mm"] == 0.8
        assert data["undercut_angle_degrees"] == 20.0
        assert data["is_thumb_hole"] is True

    def test_log_undercut_nonexistent_session_returns_404(self, client, created_build_session):
        sid = created_build_session["id"]
        payload = {
            "hole_number": 1,
            "undercut_depth_mm": 0.5,
            "undercut_angle_degrees": 15.0,
            "is_thumb_hole": False,
        }
        valid_resp = client.post(f"/build-sessions/{sid}/undercuts", json=payload)
        assert valid_resp.status_code == 201, "Route must exist for valid IDs"
        resp = client.post("/build-sessions/99999/undercuts", json=payload)
        assert resp.status_code == 404
        assert resp.json().get("detail")

    def test_log_undercut_out_of_range_hole_number_returns_422(self, client, created_build_session):
        """hole_number must be between 1 and 6 inclusive per prompt Key Requirement 6."""
        sid = created_build_session["id"]
        base = {"undercut_depth_mm": 0.5, "undercut_angle_degrees": 15.0, "is_thumb_hole": False}
        for out_of_range in [0, 7]:
            resp = client.post(f"/build-sessions/{sid}/undercuts",
                               json={**base, "hole_number": out_of_range})
            assert resp.status_code == 422, f"Expected 422 for hole_number={out_of_range}"
            assert resp.json().get("detail")


class TestLogJointLapping:
    def test_log_lapping_response_fields(self, client, created_build_session):
        sid = created_build_session["id"]
        payload = {
            "joint_identifier": "body-foot",
            "thread_material": "hemp",
            "num_wraps": 8,
            "fit_tightness": "tight",
        }
        resp = client.post(f"/build-sessions/{sid}/lappings", json=payload)
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["build_session_id"] == sid
        assert data["joint_identifier"] == "body-foot"
        assert data["thread_material"] == "hemp"
        assert data["num_wraps"] == 8
        assert data["fit_tightness"] == "tight"

    def test_log_lapping_nonexistent_session_returns_404(self, client, created_build_session):
        sid = created_build_session["id"]
        payload = {
            "joint_identifier": "head-body",
            "thread_material": "waxed linen",
            "num_wraps": 12,
            "fit_tightness": "snug",
        }
        valid_resp = client.post(f"/build-sessions/{sid}/lappings", json=payload)
        assert valid_resp.status_code == 201, "Route must exist for valid IDs"
        resp = client.post("/build-sessions/99999/lappings", json=payload)
        assert resp.status_code == 404
        assert resp.json().get("detail")

    def test_log_lapping_invalid_fit_tightness_returns_422(self, client, created_build_session):
        sid = created_build_session["id"]
        resp = client.post(f"/build-sessions/{sid}/lappings", json={
            "joint_identifier": "head-body",
            "thread_material": "linen",
            "num_wraps": 8,
            "fit_tightness": "medium",
        })
        assert resp.status_code == 422
        assert resp.json().get("detail")


class TestLogTuningRigSession:
    def test_log_tuning_response_fields(self, client, created_build_session):
        sid = created_build_session["id"]
        payload = {
            "hole_number": 2,
            "target_frequency_hz": 659.25,
            "measured_frequency_hz": 660.0,
            "deviation_cents": 1.97,
        }
        resp = client.post(f"/build-sessions/{sid}/tuning-sessions", json=payload)
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["build_session_id"] == sid
        assert data["hole_number"] == 2
        assert data["target_frequency_hz"] == 659.25
        assert data["measured_frequency_hz"] == 660.0
        assert data["deviation_cents"] == 1.97

    def test_log_tuning_nonexistent_session_returns_404(self, client, created_build_session):
        sid = created_build_session["id"]
        payload = {
            "hole_number": 1,
            "target_frequency_hz": 587.33,
            "measured_frequency_hz": 585.0,
            "deviation_cents": -6.87,
        }
        valid_resp = client.post(f"/build-sessions/{sid}/tuning-sessions", json=payload)
        assert valid_resp.status_code == 201, "Route must exist for valid IDs"
        resp = client.post("/build-sessions/99999/tuning-sessions", json=payload)
        assert resp.status_code == 404
        assert resp.json().get("detail")


class TestGetBuildSessionWithNestedData:
    def test_turning_passes_nested_under_correct_key(self, client, created_build_session):
        sid = created_build_session["id"]
        client.post(
            f"/build-sessions/{sid}/turning-passes",
            json={
                "pass_number": 1,
                "target_diameter_mm": 19.0,
                "achieved_diameter_mm": 19.1,
                "tool_used": "skew chisel",
            },
        )
        resp = client.get(f"/build-sessions/{sid}")
        data = resp.json()
        assert "turning_passes" in data
        assert isinstance(data["turning_passes"], list)
        assert len(data["turning_passes"]) >= 1
        assert "pass_number" in data["turning_passes"][0]

    def test_undercuts_nested_under_correct_key(self, client, created_build_session):
        sid = created_build_session["id"]
        client.post(
            f"/build-sessions/{sid}/undercuts",
            json={
                "hole_number": 1,
                "undercut_depth_mm": 0.5,
                "undercut_angle_degrees": 15.0,
                "is_thumb_hole": False,
            },
        )
        resp = client.get(f"/build-sessions/{sid}")
        data = resp.json()
        assert "undercuts" in data
        assert isinstance(data["undercuts"], list)
        assert len(data["undercuts"]) >= 1
        assert "undercut_depth_mm" in data["undercuts"][0]

    def test_lappings_nested_under_correct_key(self, client, created_build_session):
        sid = created_build_session["id"]
        client.post(
            f"/build-sessions/{sid}/lappings",
            json={
                "joint_identifier": "head-body",
                "thread_material": "linen",
                "num_wraps": 10,
                "fit_tightness": "loose",
            },
        )
        resp = client.get(f"/build-sessions/{sid}")
        data = resp.json()
        assert "lappings" in data
        assert isinstance(data["lappings"], list)
        assert len(data["lappings"]) >= 1
        assert "joint_identifier" in data["lappings"][0]

    def test_tuning_sessions_nested_under_correct_key(self, client, created_build_session):
        sid = created_build_session["id"]
        client.post(
            f"/build-sessions/{sid}/tuning-sessions",
            json={
                "hole_number": 1,
                "target_frequency_hz": 587.33,
                "measured_frequency_hz": 586.0,
                "deviation_cents": -3.93,
            },
        )
        resp = client.get(f"/build-sessions/{sid}")
        data = resp.json()
        assert "tuning_sessions" in data
        assert isinstance(data["tuning_sessions"], list)
        assert len(data["tuning_sessions"]) >= 1
        assert "target_frequency_hz" in data["tuning_sessions"][0]
