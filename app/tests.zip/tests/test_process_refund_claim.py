"""Tests for TaxAdministrationPlatform.process_refund_claim."""

from __future__ import annotations

from decimal import Decimal

import pytest

from _helpers import build_platform


def _claim(claim_id: str, category: str, claim_amount: str, outstanding: str) -> dict:
    return {
        "claim_id": claim_id,
        "filer_id": "F-X",
        "refund_category": category,
        "claim_amount_usd": Decimal(claim_amount),
        "outstanding_liability_usd": Decimal(outstanding),
    }


# --------------------------------------------------------------------------- #
# Test ID: REF-01
# Requirement: Refund #2 (decision == OFFSET when outstanding >= claim).
# --------------------------------------------------------------------------- #
def test_process_refund_claim_decision_offset_when_outstanding_ge_claim():
    try:
        platform = build_platform()
        result = platform.process_refund_claim(_claim("C-1", "OVERPAYMENT", "100.00", "150.00"))
        assert result["decision"] == "OFFSET"

        # Boundary: outstanding == claim -> OFFSET (>= rule).
        result_eq = platform.process_refund_claim(_claim("C-2", "OVERPAYMENT", "100.00", "100.00"))
        assert result_eq["decision"] == "OFFSET"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_refund_claim raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REF-02
# Requirement: Refund #2 (decision == APPROVED when outstanding < claim).
# --------------------------------------------------------------------------- #
def test_process_refund_claim_decision_approved_when_outstanding_lt_claim():
    try:
        platform = build_platform()
        result = platform.process_refund_claim(_claim("C-3", "BAD_DEBT", "200.00", "50.00"))
        assert result["decision"] == "APPROVED"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_refund_claim raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REF-03
# Requirement: Refund #3 (payable_amount_usd == MAX(claim - outstanding, 0)).
# --------------------------------------------------------------------------- #
def test_process_refund_claim_payable_amount_formula():
    try:
        platform = build_platform()
        # Approved case: 200 - 50 = 150.
        a = platform.process_refund_claim(_claim("C-A", "OVERPAYMENT", "200.00", "50.00"))
        assert Decimal(a["payable_amount_usd"]) == Decimal("150.00")

        # Offset case (outstanding > claim): MAX(100 - 200, 0) = 0.
        o = platform.process_refund_claim(_claim("C-O", "OVERPAYMENT", "100.00", "200.00"))
        assert Decimal(o["payable_amount_usd"]) == Decimal("0.00")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_refund_claim raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REF-04
# Requirement: Refund #4 (offset_amount_usd == MIN(claim, outstanding)).
# --------------------------------------------------------------------------- #
def test_process_refund_claim_offset_amount_formula():
    try:
        platform = build_platform()
        # claim=100, outstanding=200 -> MIN = 100.
        a = platform.process_refund_claim(_claim("C-1", "EXEMPTION_CORRECTION", "100.00", "200.00"))
        assert Decimal(a["offset_amount_usd"]) == Decimal("100.00")

        # claim=200, outstanding=50 -> MIN = 50.
        b = platform.process_refund_claim(_claim("C-2", "MARKETPLACE_ADJUSTMENT", "200.00", "50.00"))
        assert Decimal(b["offset_amount_usd"]) == Decimal("50.00")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_refund_claim raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REF-05
# Requirement: Refund #5 (output keys: claim_id, filer_id, decision,
#   payable_amount_usd, offset_amount_usd; identity propagation).
# --------------------------------------------------------------------------- #
def test_process_refund_claim_output_schema_and_propagation():
    try:
        platform = build_platform()
        claim = {
            "claim_id": "C-PROP",
            "filer_id": "F-PROP",
            "refund_category": "OVERPAYMENT",
            "claim_amount_usd": Decimal("80.00"),
            "outstanding_liability_usd": Decimal("0.00"),
        }
        result = platform.process_refund_claim(claim)

        for key in ("claim_id", "filer_id", "decision", "payable_amount_usd", "offset_amount_usd"):
            assert key in result, f"missing key {key!r}"
        assert result["claim_id"] == "C-PROP"
        assert result["filer_id"] == "F-PROP"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_refund_claim raised unexpected exception: {exc!r}")
