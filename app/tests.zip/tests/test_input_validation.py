"""Verify ValueError contracts on the donations DataFrame.

Both ``fit`` and ``rank_donors`` must validate the input contract
defined in section 1 of the prompt and raise ``ValueError`` for every
violation: a missing required column, a null cell in any required
column, or a ``donation_amount`` value below the 0.01 floor.
"""

import numpy as np
import pandas as pd
import pytest


REQUIRED_COLUMNS = ("donor_id", "donation_amount", "date", "campaign", "channel")


def _null_value_for(column: str):
    if column == "date":
        return pd.NaT
    if column == "donation_amount":
        return np.nan
    return None


@pytest.mark.parametrize("missing_column", REQUIRED_COLUMNS)
def test_fit_raises_value_error_when_required_column_missing(
    DonorPipeline, sample_donations, missing_column
):
    """``fit`` rejects a DataFrame that is missing any required column."""

    bad_df = sample_donations.drop(columns=[missing_column])
    with pytest.raises(ValueError):
        DonorPipeline().fit(bad_df)


@pytest.mark.parametrize("nulled_column", REQUIRED_COLUMNS)
def test_fit_raises_value_error_when_required_column_has_null(
    DonorPipeline, sample_donations, nulled_column
):
    """``fit`` rejects a DataFrame that holds a null in any required column."""

    bad_df = sample_donations.copy()
    bad_df.loc[bad_df.index[0], nulled_column] = _null_value_for(nulled_column)
    with pytest.raises(ValueError):
        DonorPipeline().fit(bad_df)


def test_fit_raises_value_error_for_donation_amount_below_floor(
    DonorPipeline, sample_donations
):
    """``fit`` rejects a DataFrame whose ``donation_amount`` is below 0.01."""

    bad_df = sample_donations.copy()
    bad_df.loc[bad_df.index[0], "donation_amount"] = 0.005
    with pytest.raises(ValueError):
        DonorPipeline().fit(bad_df)


@pytest.mark.parametrize("missing_column", REQUIRED_COLUMNS)
def test_rank_donors_raises_value_error_when_required_column_missing(
    DonorPipeline, sample_donations, missing_column
):
    """``rank_donors`` rejects a DataFrame missing any required column,
    even after ``fit`` has succeeded."""

    pipeline = DonorPipeline().fit(sample_donations)
    bad_df = sample_donations.drop(columns=[missing_column])
    with pytest.raises(ValueError):
        pipeline.rank_donors(bad_df)


@pytest.mark.parametrize("nulled_column", REQUIRED_COLUMNS)
def test_rank_donors_raises_value_error_when_required_column_has_null(
    DonorPipeline, sample_donations, nulled_column
):
    """``rank_donors`` rejects a DataFrame holding a null in any required
    column, even after ``fit`` has succeeded."""

    pipeline = DonorPipeline().fit(sample_donations)
    bad_df = sample_donations.copy()
    bad_df.loc[bad_df.index[0], nulled_column] = _null_value_for(nulled_column)
    with pytest.raises(ValueError):
        pipeline.rank_donors(bad_df)


def test_rank_donors_raises_value_error_for_donation_amount_below_floor(
    DonorPipeline, sample_donations
):
    """``rank_donors`` rejects a DataFrame whose ``donation_amount`` is
    below 0.01, even after ``fit`` has succeeded."""

    pipeline = DonorPipeline().fit(sample_donations)
    bad_df = sample_donations.copy()
    bad_df.loc[bad_df.index[0], "donation_amount"] = 0.005
    with pytest.raises(ValueError):
        pipeline.rank_donors(bad_df)


def test_fit_accepts_donation_amount_at_exact_floor(DonorPipeline, sample_donations):
    """``donation_amount == 0.01`` is permitted because the floor is
    "less than 0.01" rather than "less than or equal"."""

    df = sample_donations.copy()
    df.loc[df.index[0], "donation_amount"] = 0.01
    DonorPipeline().fit(df)


def test_fit_rejects_donation_amount_just_below_floor(DonorPipeline, sample_donations):
    """``donation_amount`` strictly below the 0.01 floor is rejected,
    pinning the strictness of the comparison at the boundary."""

    df = sample_donations.copy()
    df.loc[df.index[0], "donation_amount"] = 0.0099
    with pytest.raises(ValueError):
        DonorPipeline().fit(df)


def test_rank_donors_accepts_donation_amount_at_exact_floor(
    DonorPipeline, sample_donations
):
    """``rank_donors`` mirrors ``fit`` and accepts a donation at exactly
    the 0.01 floor."""

    pipeline = DonorPipeline().fit(sample_donations)
    df = sample_donations.copy()
    df.loc[df.index[0], "donation_amount"] = 0.01
    pipeline.rank_donors(df)


def test_rank_donors_rejects_donation_amount_just_below_floor(
    DonorPipeline, sample_donations
):
    """``rank_donors`` mirrors ``fit`` and rejects a donation strictly
    below the 0.01 floor."""

    pipeline = DonorPipeline().fit(sample_donations)
    df = sample_donations.copy()
    df.loc[df.index[0], "donation_amount"] = 0.0099
    with pytest.raises(ValueError):
        pipeline.rank_donors(df)
