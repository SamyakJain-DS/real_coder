import pytest
import os


# ---------------------------------------------------------------------------
# Fixture - must NEVER raise, so that failures produce FAILED not ERROR
# ---------------------------------------------------------------------------

@pytest.fixture
def client(tmp_path):
    """
    Safe fixture. Yields None when app.py cannot be imported so the test
    body can call _require(client) and produce FAILED status (not ERROR).

    pytest.fail() must never be called here - only inside test bodies.
    """
    try:
        from app import app as flask_app
    except ImportError:
        yield None
        return

    flask_app.config["TESTING"] = True
    flask_app.config["DATABASE"] = str(tmp_path / "test.db")

    with flask_app.app_context():
        try:
            from app import init_db
            init_db()
        except ImportError:
            pass

    yield flask_app.test_client()


# ---------------------------------------------------------------------------
# Guard - call as the FIRST LINE of every test body
# ---------------------------------------------------------------------------

def _require(client):
    """
    Raise pytest.Failed when the app could not be imported.
    Must be called from inside a test body so the test shows as FAILED
    rather than ERROR at setup.
    """
    if client is None:
        pytest.fail("Could not import 'app' from app.py - module not found")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_class(client, instructor="Jane", room="A1", day_of_week="Monday",
               time="10:00", capacity=5, price=50.0):
    return client.post("/api/classes", json={
        "instructor": instructor, "room": room, "day_of_week": day_of_week,
        "time": time, "capacity": capacity, "price": price,
    })


def make_student(client, email="alice@example.com",
                 first_name="Alice", last_name="Smith"):
    return client.post("/api/students", json={
        "email": email, "first_name": first_name, "last_name": last_name,
    })


def enroll(client, student_id, class_id):
    return client.post("/api/enrollments", json={
        "student_id": student_id, "class_id": class_id,
    })


def make_inventory(client, name="Red Clay", material_type="clay",
                   quantity=50.0, unit="kg", reorder_threshold=10.0):
    return client.post("/api/inventory", json={
        "name": name, "material_type": material_type,
        "quantity": quantity, "unit": unit,
        "reorder_threshold": reorder_threshold,
    })


# ===========================================================================
# POST /api/classes
# ===========================================================================

class TestCreateClass:
    def test_returns_201(self, client):
        _require(client)
        assert make_class(client).status_code == 201

    def test_response_contains_required_fields(self, client):
        _require(client)
        data = make_class(client).get_json()
        for field in ("id", "instructor", "room", "day_of_week", "time", "capacity", "price"):
            assert field in data

    def test_stored_values_match_input(self, client):
        _require(client)
        data = make_class(client, instructor="Bob", room="B2",
                          day_of_week="Tuesday", time="14:00",
                          capacity=10, price=75.0).get_json()
        assert data["instructor"] == "Bob"
        assert data["room"] == "B2"
        assert data["day_of_week"] == "Tuesday"
        assert data["time"] == "14:00"
        assert data["capacity"] == 10
        assert data["price"] == 75.0

    def test_assigned_id_is_integer(self, client):
        _require(client)
        data = make_class(client).get_json()
        assert isinstance(data["id"], int)


# ===========================================================================
# GET /api/classes
# ===========================================================================

class TestGetClasses:
    def test_returns_200(self, client):
        _require(client)
        assert client.get("/api/classes").status_code == 200

    def test_returns_list(self, client):
        _require(client)
        assert isinstance(client.get("/api/classes").get_json(), list)

    def test_created_class_appears_in_list(self, client):
        _require(client)
        make_class(client, instructor="UniqueInstructor")
        data = client.get("/api/classes").get_json()
        assert any(c["instructor"] == "UniqueInstructor" for c in data)


# ===========================================================================
# POST /api/students
# ===========================================================================

class TestRegisterStudent:
    def test_returns_201(self, client):
        _require(client)
        assert make_student(client).status_code == 201

    def test_response_contains_required_fields(self, client):
        _require(client)
        data = make_student(client).get_json()
        for field in ("id", "email", "first_name", "last_name"):
            assert field in data

    def test_stored_values_match_input(self, client):
        _require(client)
        data = make_student(client, email="bob@example.com",
                            first_name="Bob", last_name="Jones").get_json()
        assert data["email"] == "bob@example.com"
        assert data["first_name"] == "Bob"
        assert data["last_name"] == "Jones"

    def test_duplicate_email_returns_409(self, client):
        _require(client)
        make_student(client, email="dup@example.com")
        resp = make_student(client, email="dup@example.com")
        assert resp.status_code == 409


# ===========================================================================
# GET /api/students
# ===========================================================================

class TestGetStudents:
    def test_returns_200(self, client):
        _require(client)
        assert client.get("/api/students").status_code == 200

    def test_returns_list(self, client):
        _require(client)
        assert isinstance(client.get("/api/students").get_json(), list)

    def test_registered_student_appears_in_list(self, client):
        _require(client)
        make_student(client, email="listed@example.com")
        emails = [s["email"] for s in client.get("/api/students").get_json()]
        assert "listed@example.com" in emails


# ===========================================================================
# POST /api/enrollments
# ===========================================================================

class TestEnrollStudent:
    def test_below_capacity_returns_201(self, client):
        _require(client)
        cls = make_class(client, capacity=5).get_json()
        stu = make_student(client, email="en1@example.com").get_json()
        assert enroll(client, stu["id"], cls["id"]).status_code == 201

    def test_below_capacity_status_enrolled(self, client):
        _require(client)
        cls = make_class(client, capacity=5).get_json()
        stu = make_student(client, email="en2@example.com").get_json()
        data = enroll(client, stu["id"], cls["id"]).get_json()
        assert data["status"] == "enrolled"

    def test_at_capacity_status_waitlisted(self, client):
        _require(client)
        cls = make_class(client, capacity=1).get_json()
        s1 = make_student(client, email="wl1@example.com").get_json()
        s2 = make_student(client, email="wl2@example.com").get_json()
        enroll(client, s1["id"], cls["id"])
        data = enroll(client, s2["id"], cls["id"]).get_json()
        assert data["status"] == "waitlisted"

    def test_response_contains_created_at_in_iso_8601_format(self, client):
        _require(client)
        from datetime import datetime
        cls = make_class(client, capacity=5).get_json()
        stu = make_student(client, email="en3@example.com").get_json()
        data = enroll(client, stu["id"], cls["id"]).get_json()
        assert "created_at" in data
        created_at = data["created_at"]
        try:
            datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            pytest.fail(f"created_at value {created_at!r} is not a valid ISO 8601 timestamp")

    def test_response_contains_required_fields(self, client):
        _require(client)
        cls = make_class(client, capacity=5).get_json()
        stu = make_student(client, email="en4@example.com").get_json()
        data = enroll(client, stu["id"], cls["id"]).get_json()
        for field in ("id", "student_id", "class_id", "status", "created_at"):
            assert field in data

    def test_invalid_student_returns_404(self, client):
        _require(client)
        cls = make_class(client, capacity=5).get_json()
        assert enroll(client, 99999, cls["id"]).status_code == 404

    def test_invalid_class_returns_404(self, client):
        _require(client)
        stu = make_student(client, email="en5@example.com").get_json()
        assert enroll(client, stu["id"], 99999).status_code == 404

    def test_duplicate_enrollment_returns_409(self, client):
        _require(client)
        cls = make_class(client, capacity=5).get_json()
        stu = make_student(client, email="en6@example.com").get_json()
        enroll(client, stu["id"], cls["id"])
        assert enroll(client, stu["id"], cls["id"]).status_code == 409


# ===========================================================================
# GET /api/classes/{class_id}/enrollments
# ===========================================================================

class TestGetClassEnrollments:
    def test_returns_200(self, client):
        _require(client)
        cls = make_class(client, capacity=5).get_json()
        assert client.get(f'/api/classes/{cls["id"]}/enrollments').status_code == 200

    def test_response_has_enrolled_and_waitlisted_keys(self, client):
        _require(client)
        cls = make_class(client, capacity=5).get_json()
        data = client.get(f'/api/classes/{cls["id"]}/enrollments').get_json()
        assert "enrolled" in data
        assert "waitlisted" in data

    def test_enrolled_students_appear_in_enrolled_array(self, client):
        _require(client)
        cls = make_class(client, capacity=2).get_json()
        s1 = make_student(client, email="ge1@example.com").get_json()
        s2 = make_student(client, email="ge2@example.com").get_json()
        enroll(client, s1["id"], cls["id"])
        enroll(client, s2["id"], cls["id"])
        data = client.get(f'/api/classes/{cls["id"]}/enrollments').get_json()
        assert len(data["enrolled"]) == 2

    def test_waitlisted_students_appear_in_waitlisted_array(self, client):
        _require(client)
        cls = make_class(client, capacity=1).get_json()
        s1 = make_student(client, email="gw1@example.com").get_json()
        s2 = make_student(client, email="gw2@example.com").get_json()
        enroll(client, s1["id"], cls["id"])
        enroll(client, s2["id"], cls["id"])
        data = client.get(f'/api/classes/{cls["id"]}/enrollments').get_json()
        assert len(data["waitlisted"]) == 1

    def test_enrollment_objects_contain_required_fields(self, client):
        _require(client)
        cls = make_class(client, capacity=5).get_json()
        stu = make_student(client, email="ge3@example.com").get_json()
        enroll(client, stu["id"], cls["id"])
        data = client.get(f'/api/classes/{cls["id"]}/enrollments').get_json()
        entry = data["enrolled"][0]
        for field in ("id", "student_id", "status", "created_at"):
            assert field in entry

    def test_invalid_class_returns_404(self, client):
        _require(client)
        assert client.get("/api/classes/99999/enrollments").status_code == 404


# ===========================================================================
# POST /api/attendance
# ===========================================================================

class TestRecordAttendance:
    def test_returns_201(self, client):
        _require(client)
        cls = make_class(client).get_json()
        stu = make_student(client, email="at1@example.com").get_json()
        resp = client.post("/api/attendance", json={
            "student_id": stu["id"], "class_id": cls["id"],
            "session_date": "2024-01-15", "present": True,
        })
        assert resp.status_code == 201

    def test_response_contains_required_fields(self, client):
        _require(client)
        cls = make_class(client).get_json()
        stu = make_student(client, email="at2@example.com").get_json()
        data = client.post("/api/attendance", json={
            "student_id": stu["id"], "class_id": cls["id"],
            "session_date": "2024-01-15", "present": True,
        }).get_json()
        for field in ("id", "student_id", "class_id", "session_date", "present"):
            assert field in data

    def test_stored_values_match_input(self, client):
        _require(client)
        cls = make_class(client).get_json()
        stu = make_student(client, email="at3@example.com").get_json()
        data = client.post("/api/attendance", json={
            "student_id": stu["id"], "class_id": cls["id"],
            "session_date": "2024-03-10", "present": False,
        }).get_json()
        assert data["session_date"] == "2024-03-10"
        assert data["present"] == False

    def test_invalid_student_returns_404(self, client):
        _require(client)
        cls = make_class(client).get_json()
        resp = client.post("/api/attendance", json={
            "student_id": 99999, "class_id": cls["id"],
            "session_date": "2024-01-15", "present": True,
        })
        assert resp.status_code == 404

    def test_invalid_class_returns_404(self, client):
        _require(client)
        stu = make_student(client, email="at4@example.com").get_json()
        resp = client.post("/api/attendance", json={
            "student_id": stu["id"], "class_id": 99999,
            "session_date": "2024-01-15", "present": True,
        })
        assert resp.status_code == 404


# ===========================================================================
# GET /api/classes/{class_id}/attendance/{session_date}
# ===========================================================================

class TestGetSessionAttendance:
    def test_returns_200(self, client):
        _require(client)
        cls = make_class(client).get_json()
        assert client.get(f'/api/classes/{cls["id"]}/attendance/2024-01-15').status_code == 200

    def test_returns_list(self, client):
        _require(client)
        cls = make_class(client).get_json()
        assert isinstance(
            client.get(f'/api/classes/{cls["id"]}/attendance/2024-01-15').get_json(),
            list,
        )

    def test_returns_records_for_correct_date(self, client):
        _require(client)
        cls = make_class(client).get_json()
        stu = make_student(client, email="gat1@example.com").get_json()
        client.post("/api/attendance", json={
            "student_id": stu["id"], "class_id": cls["id"],
            "session_date": "2024-02-20", "present": True,
        })
        data = client.get(f'/api/classes/{cls["id"]}/attendance/2024-02-20').get_json()
        assert len(data) >= 1
        assert all(r["session_date"] == "2024-02-20" for r in data)

    def test_invalid_class_returns_404(self, client):
        _require(client)
        assert client.get("/api/classes/99999/attendance/2024-01-15").status_code == 404


# ===========================================================================
# POST /api/kiln-loads
# ===========================================================================

class TestCreateKilnLoad:
    def test_returns_201(self, client):
        _require(client)
        stu = make_student(client, email="kl1@example.com").get_json()
        resp = client.post("/api/kiln-loads", json={
            "name": "Load A", "firing_date": "2024-04-01",
            "pieces": [{"student_id": stu["id"], "label": "Vase"}],
        })
        assert resp.status_code == 201

    def test_response_contains_required_fields(self, client):
        _require(client)
        stu = make_student(client, email="kl2@example.com").get_json()
        data = client.post("/api/kiln-loads", json={
            "name": "Load B", "firing_date": "2024-04-01",
            "pieces": [{"student_id": stu["id"], "label": "Bowl"}],
        }).get_json()
        for field in ("id", "name", "firing_date", "completed", "pieces"):
            assert field in data

    def test_completed_defaults_to_false(self, client):
        _require(client)
        stu = make_student(client, email="kl3@example.com").get_json()
        data = client.post("/api/kiln-loads", json={
            "name": "Load C", "firing_date": "2024-04-01",
            "pieces": [{"student_id": stu["id"], "label": "Mug"}],
        }).get_json()
        assert data["completed"] == False

    def test_pieces_returned_with_correct_data(self, client):
        _require(client)
        stu = make_student(client, email="kl4@example.com").get_json()
        data = client.post("/api/kiln-loads", json={
            "name": "Load D", "firing_date": "2024-04-01",
            "pieces": [{"student_id": stu["id"], "label": "Plate"}],
        }).get_json()
        assert len(data["pieces"]) == 1
        piece = data["pieces"][0]
        assert piece["label"] == "Plate"
        assert piece["student_id"] == stu["id"]
        assert "id" in piece

    def test_invalid_student_in_pieces_returns_404(self, client):
        _require(client)
        resp = client.post("/api/kiln-loads", json={
            "name": "Load E", "firing_date": "2024-04-01",
            "pieces": [{"student_id": 99999, "label": "Tile"}],
        })
        assert resp.status_code == 404


# ===========================================================================
# PUT /api/kiln-loads/{kiln_load_id}
# ===========================================================================

class TestUpdateKilnLoad:
    def _make_load(self, client, email):
        stu = make_student(client, email=email).get_json()
        return client.post("/api/kiln-loads", json={
            "name": "Load", "firing_date": "2024-04-01",
            "pieces": [{"student_id": stu["id"], "label": "Piece"}],
        }).get_json()

    def test_returns_200(self, client):
        _require(client)
        load = self._make_load(client, "ukl1@example.com")
        assert client.put(f'/api/kiln-loads/{load["id"]}',
                          json={"completed": True}).status_code == 200

    def test_completed_field_is_updated(self, client):
        _require(client)
        load = self._make_load(client, "ukl2@example.com")
        data = client.put(f'/api/kiln-loads/{load["id"]}',
                          json={"completed": True}).get_json()
        assert data["completed"] == True

    def test_response_contains_pieces(self, client):
        _require(client)
        load = self._make_load(client, "ukl3@example.com")
        data = client.put(f'/api/kiln-loads/{load["id"]}',
                          json={"completed": True}).get_json()
        assert "pieces" in data

    def test_invalid_id_returns_404(self, client):
        _require(client)
        assert client.put("/api/kiln-loads/99999",
                          json={"completed": True}).status_code == 404


# ===========================================================================
# GET /api/kiln-loads
# ===========================================================================

class TestGetKilnLoads:
    def test_returns_200(self, client):
        _require(client)
        assert client.get("/api/kiln-loads").status_code == 200

    def test_returns_list(self, client):
        _require(client)
        assert isinstance(client.get("/api/kiln-loads").get_json(), list)

    def test_created_load_appears_in_list(self, client):
        _require(client)
        stu = make_student(client, email="gkl1@example.com").get_json()
        client.post("/api/kiln-loads", json={
            "name": "UniqueLoadName", "firing_date": "2024-04-01",
            "pieces": [{"student_id": stu["id"], "label": "Piece"}],
        })
        names = [l["name"] for l in client.get("/api/kiln-loads").get_json()]
        assert "UniqueLoadName" in names

    def test_each_load_contains_pieces(self, client):
        _require(client)
        stu = make_student(client, email="gkl2@example.com").get_json()
        client.post("/api/kiln-loads", json={
            "name": "LoadWithPieces", "firing_date": "2024-04-01",
            "pieces": [{"student_id": stu["id"], "label": "Piece"}],
        })
        loads = client.get("/api/kiln-loads").get_json()
        target = next(l for l in loads if l["name"] == "LoadWithPieces")
        assert "pieces" in target


# ===========================================================================
# POST /api/pieces
# ===========================================================================

class TestCreatePieceLabel:
    def test_returns_201(self, client):
        _require(client)
        cls = make_class(client).get_json()
        stu = make_student(client, email="pl1@example.com").get_json()
        resp = client.post("/api/pieces", json={
            "label": "My Vase", "student_id": stu["id"], "class_id": cls["id"],
        })
        assert resp.status_code == 201

    def test_response_contains_required_fields(self, client):
        _require(client)
        cls = make_class(client).get_json()
        stu = make_student(client, email="pl2@example.com").get_json()
        data = client.post("/api/pieces", json={
            "label": "My Bowl", "student_id": stu["id"], "class_id": cls["id"],
        }).get_json()
        for field in ("id", "label", "student_id", "class_id"):
            assert field in data

    def test_stored_values_match_input(self, client):
        _require(client)
        cls = make_class(client).get_json()
        stu = make_student(client, email="pl3@example.com").get_json()
        data = client.post("/api/pieces", json={
            "label": "Unique Label XYZ",
            "student_id": stu["id"],
            "class_id": cls["id"],
        }).get_json()
        assert data["label"] == "Unique Label XYZ"
        assert data["student_id"] == stu["id"]
        assert data["class_id"] == cls["id"]

    def test_invalid_student_returns_404(self, client):
        _require(client)
        cls = make_class(client).get_json()
        resp = client.post("/api/pieces", json={
            "label": "Piece", "student_id": 99999, "class_id": cls["id"],
        })
        assert resp.status_code == 404

    def test_invalid_class_returns_404(self, client):
        _require(client)
        stu = make_student(client, email="pl4@example.com").get_json()
        resp = client.post("/api/pieces", json={
            "label": "Piece", "student_id": stu["id"], "class_id": 99999,
        })
        assert resp.status_code == 404


# ===========================================================================
# GET /api/students/{student_id}/pieces
# ===========================================================================

class TestGetStudentPieces:
    def test_returns_200(self, client):
        _require(client)
        stu = make_student(client, email="gpl1@example.com").get_json()
        assert client.get(f'/api/students/{stu["id"]}/pieces').status_code == 200

    def test_returns_list(self, client):
        _require(client)
        stu = make_student(client, email="gpl2@example.com").get_json()
        assert isinstance(
            client.get(f'/api/students/{stu["id"]}/pieces').get_json(), list
        )

    def test_returns_pieces_belonging_to_student(self, client):
        _require(client)
        cls = make_class(client).get_json()
        stu = make_student(client, email="gpl3@example.com").get_json()
        client.post("/api/pieces", json={
            "label": "StuPieceUnique", "student_id": stu["id"], "class_id": cls["id"],
        })
        labels = [
            p["label"]
            for p in client.get(f'/api/students/{stu["id"]}/pieces').get_json()
        ]
        assert "StuPieceUnique" in labels

    def test_invalid_student_returns_404(self, client):
        _require(client)
        assert client.get("/api/students/99999/pieces").status_code == 404


# ===========================================================================
# POST /api/inventory
# ===========================================================================

class TestCreateInventoryItem:
    def test_returns_201_for_clay(self, client):
        _require(client)
        assert make_inventory(client, material_type="clay").status_code == 201

    def test_returns_201_for_glaze(self, client):
        _require(client)
        assert make_inventory(client, name="Blue Glaze",
                              material_type="glaze").status_code == 201

    def test_response_contains_required_fields(self, client):
        _require(client)
        data = make_inventory(client).get_json()
        for field in ("id", "name", "material_type", "quantity", "unit", "reorder_threshold"):
            assert field in data

    def test_invalid_material_type_returns_400(self, client):
        _require(client)
        resp = make_inventory(client, name="Sand", material_type="sand")
        assert resp.status_code == 400


# ===========================================================================
# GET /api/inventory
# ===========================================================================

class TestGetInventory:
    def test_returns_200(self, client):
        _require(client)
        assert client.get("/api/inventory").status_code == 200

    def test_returns_list(self, client):
        _require(client)
        assert isinstance(client.get("/api/inventory").get_json(), list)

    def test_created_item_appears_in_list(self, client):
        _require(client)
        make_inventory(client, name="UniqueClayItem")
        names = [i["name"] for i in client.get("/api/inventory").get_json()]
        assert "UniqueClayItem" in names


# ===========================================================================
# PUT /api/inventory/{item_id}
# ===========================================================================

class TestUpdateInventoryQuantity:
    def test_returns_200(self, client):
        _require(client)
        item = make_inventory(client).get_json()
        assert client.put(
            f'/api/inventory/{item["id"]}', json={"quantity": 25.0}
        ).status_code == 200

    def test_quantity_is_updated(self, client):
        _require(client)
        item = make_inventory(client, name="UpdateTarget").get_json()
        data = client.put(
            f'/api/inventory/{item["id"]}', json={"quantity": 8.0}
        ).get_json()
        assert data["quantity"] == 8.0

    def test_invalid_id_returns_404(self, client):
        _require(client)
        assert client.put(
            "/api/inventory/99999", json={"quantity": 10.0}
        ).status_code == 404


# ===========================================================================
# GET /api/inventory/alerts
# ===========================================================================

class TestInventoryAlerts:
    def test_returns_200(self, client):
        _require(client)
        assert client.get("/api/inventory/alerts").status_code == 200

    def test_returns_list(self, client):
        _require(client)
        assert isinstance(client.get("/api/inventory/alerts").get_json(), list)

    def test_item_below_threshold_is_included(self, client):
        _require(client)
        make_inventory(client, name="LowClay", quantity=5.0, reorder_threshold=10.0)
        names = [i["name"] for i in client.get("/api/inventory/alerts").get_json()]
        assert "LowClay" in names

    def test_item_exactly_at_threshold_is_included(self, client):
        _require(client)
        make_inventory(client, name="ExactClay", quantity=10.0, reorder_threshold=10.0)
        names = [i["name"] for i in client.get("/api/inventory/alerts").get_json()]
        assert "ExactClay" in names

    def test_item_above_threshold_is_excluded(self, client):
        _require(client)
        make_inventory(client, name="PlentyGlaze", material_type="glaze",
                       quantity=100.0, reorder_threshold=10.0)
        names = [i["name"] for i in client.get("/api/inventory/alerts").get_json()]
        assert "PlentyGlaze" not in names


# ===========================================================================
# GET /api/revenue
# ===========================================================================

class TestRevenueReport:
    def test_returns_200(self, client):
        _require(client)
        assert client.get("/api/revenue").status_code == 200

    def test_returns_list(self, client):
        _require(client)
        assert isinstance(client.get("/api/revenue").get_json(), list)

    def test_response_entries_contain_required_fields(self, client):
        _require(client)
        cls = make_class(client, price=50.0, capacity=5,
                         instructor="RevInstructor",
                         day_of_week="Wednesday",
                         time="09:00").get_json()
        stu = make_student(client, email="rv1@example.com").get_json()
        enroll(client, stu["id"], cls["id"])
        entries = [
            e for e in client.get("/api/revenue").get_json()
            if e["class_id"] == cls["id"]
        ]
        assert len(entries) >= 1
        for field in ("class_id", "instructor", "day_of_week", "time", "month", "revenue"):
            assert field in entries[0]

    def test_revenue_equals_enrolled_count_times_price(self, client):
        _require(client)
        cls = make_class(client, price=60.0, capacity=5).get_json()
        s1 = make_student(client, email="rv2@example.com").get_json()
        s2 = make_student(client, email="rv3@example.com").get_json()
        enroll(client, s1["id"], cls["id"])
        enroll(client, s2["id"], cls["id"])
        entries = [
            e for e in client.get("/api/revenue").get_json()
            if e["class_id"] == cls["id"]
        ]
        assert len(entries) >= 1
        assert pytest.approx(entries[0]["revenue"]) == 120.0

    def test_waitlisted_students_excluded_from_revenue(self, client):
        _require(client)
        cls = make_class(client, price=50.0, capacity=1).get_json()
        s1 = make_student(client, email="rv4@example.com").get_json()
        s2 = make_student(client, email="rv5@example.com").get_json()
        enroll(client, s1["id"], cls["id"])
        enroll(client, s2["id"], cls["id"])
        entries = [
            e for e in client.get("/api/revenue").get_json()
            if e["class_id"] == cls["id"]
        ]
        assert len(entries) >= 1
        assert pytest.approx(entries[0]["revenue"]) == 50.0

    def test_month_field_is_yyyy_mm_format(self, client):
        _require(client)
        cls = make_class(client, price=40.0, capacity=5).get_json()
        stu = make_student(client, email="rv6@example.com").get_json()
        enroll(client, stu["id"], cls["id"])
        entries = [
            e for e in client.get("/api/revenue").get_json()
            if e["class_id"] == cls["id"]
        ]
        assert len(entries) >= 1
        month = entries[0]["month"]
        assert len(month) == 7
        assert month[4] == "-"
        assert month[:4].isdigit()
        assert month[5:].isdigit()


# ===========================================================================
# GET / - Frontend
# ===========================================================================

class TestFrontend:
    def test_returns_200(self, client):
        _require(client)
        assert client.get("/").status_code == 200