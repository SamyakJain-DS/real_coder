import uuid
import pytest
from conftest import create_insurer


class TestCreateInsurer:
    def test_create_insurer_returns_201(self, client):
        resp = create_insurer(client)
        assert resp.status_code == 201

    def test_create_insurer_returns_server_generated_id(self, client):
        resp = create_insurer(client)
        data = resp.json()
        assert "insurer_id" in data
        assert isinstance(data["insurer_id"], str)
        assert len(data["insurer_id"]) > 0
        uuid.UUID(data["insurer_id"])  # raises ValueError if not a valid UUID

    def test_create_insurer_returns_all_fields(self, client):
        resp = create_insurer(
            client,
            naic_code="99999",
            company_name="Acme Health",
            company_type="mco",
            state_license_status="active",
            domicile_state="NY",
            admitted_date="2022-03-10",
        )
        data = resp.json()
        assert data["naic_code"] == "99999"
        assert data["company_name"] == "Acme Health"
        assert data["company_type"] == "mco"
        assert data["state_license_status"] == "active"
        assert data["domicile_state"] == "NY"
        assert data["admitted_date"] == "2022-03-10"


    def test_server_does_not_use_client_supplied_insurer_id(self, client):
        # The Expected Interface states insurer_id "is server-generated and must not be
        # provided by the client." This test sends an insurer_id in the body and verifies
        # the server either rejects the request or ignores the supplied value and returns
        # its own server-generated ID.
        fake_id = "client-provided-id-should-be-ignored"
        resp = create_insurer(client, insurer_id=fake_id)
        # Server must respond with a valid outcome: accept (201) or reject (400/422).
        # This assertion fails on an empty repo (stub returns -1) to preserve F2P integrity.
        assert resp.status_code in (201, 400, 422)
        if resp.status_code == 201:
            assert resp.json()["insurer_id"] != fake_id


class TestGetInsurers:
    def test_get_all_insurers_returns_list(self, client):
        resp = client.get("/api/insurers")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_get_all_insurers_includes_created_records(self, client):
        r1 = create_insurer(client).json()
        r2 = create_insurer(client).json()
        resp = client.get("/api/insurers")
        assert resp.status_code == 200
        ids = {i["insurer_id"] for i in resp.json()}
        assert r1["insurer_id"] in ids
        assert r2["insurer_id"] in ids

    def test_get_insurer_by_id(self, client):
        created = create_insurer(client).json()
        insurer_id = created["insurer_id"]
        resp = client.get(f"/api/insurers/{insurer_id}")
        assert resp.status_code == 200
        assert resp.json()["insurer_id"] == insurer_id

    def test_get_insurer_not_found(self, client):
        resp = client.get("/api/insurers/nonexistent-id")
        assert resp.status_code == 404


class TestUpdateInsurer:
    def test_update_insurer_partial(self, client):
        created = create_insurer(client).json()
        insurer_id = created["insurer_id"]
        resp = client.put(
            f"/api/insurers/{insurer_id}",
            json={"company_name": "Updated Name"},
        )
        assert resp.status_code == 200
        assert resp.json()["company_name"] == "Updated Name"
        assert resp.json()["naic_code"] == created["naic_code"]

    def test_update_insurer_status(self, client):
        created = create_insurer(client).json()
        insurer_id = created["insurer_id"]
        resp = client.put(
            f"/api/insurers/{insurer_id}",
            json={"state_license_status": "suspended"},
        )
        assert resp.status_code == 200
        assert resp.json()["state_license_status"] == "suspended"

    def test_update_insurer_not_found(self, client):
        resp = client.put(
            "/api/insurers/nonexistent-id",
            json={"company_name": "No One"},
        )
        assert resp.status_code == 404


class TestDeleteInsurer:
    def test_delete_insurer(self, client):
        created = create_insurer(client).json()
        insurer_id = created["insurer_id"]
        resp = client.delete(f"/api/insurers/{insurer_id}")
        assert resp.status_code == 204
        get_resp = client.get(f"/api/insurers/{insurer_id}")
        assert get_resp.status_code == 404

    def test_delete_insurer_not_found(self, client):
        resp = client.delete("/api/insurers/nonexistent-id")
        assert resp.status_code == 404
