"""Tests for the Registration Workflow (TaxAdministrationPlatform.register_filer).

Each test wraps execution in a try/except block and converts any
unexpected exception (including ImportError on an empty codebase) into a
pytest.fail so the suite fails gracefully rather than erroring.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from _helpers import build_platform


# --------------------------------------------------------------------------- #
# Test ID: REG-01
# Requirement: Registration Workflow #1 (nexus_by_sales triggers eligibility)
# Test Description: Verify nexus_eligible is True when annual_gross_sales_usd
#   meets the sales threshold even if transaction count is below the
#   transaction threshold.
# Input: registration with sales >= sales threshold and transactions <
#   transaction threshold.
# Expected Output: nexus_eligible == True, registration_status == "ACTIVE".
# Coverage Notes: Validates the sales-side branch of the deterministic nexus
#   rule set together with the ACTIVE status mapping.
# --------------------------------------------------------------------------- #
def test_register_filer_nexus_by_sales_only():
    try:
        platform = build_platform()
        result = platform.register_filer({
            "filer_id": "F-1001",
            "filer_category": "REMOTE_SELLER",
            "annual_gross_sales_usd": Decimal("250000.00"),
            "annual_transaction_count": 50,
            "nexus_threshold_sales_usd": Decimal("100000.00"),
            "nexus_threshold_transaction_count": 200,
            "registration_date": "2024-01-15",
        })

        assert result["nexus_eligible"] is True
        assert result["registration_status"] == "ACTIVE"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover - F2P guard
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REG-02
# Requirement: Registration Workflow #1 (nexus_by_transactions triggers
#   eligibility)
# Test Description: Verify nexus_eligible is True when transaction count
#   meets the transaction threshold even if sales are below the sales
#   threshold.
# Input: registration with sales < sales threshold and transactions >=
#   transaction threshold.
# Expected Output: nexus_eligible == True, registration_status == "ACTIVE".
# Coverage Notes: Validates the transaction-side branch of the nexus rule.
# --------------------------------------------------------------------------- #
def test_register_filer_nexus_by_transactions_only():
    try:
        platform = build_platform()
        result = platform.register_filer({
            "filer_id": "F-1002",
            "filer_category": "REMOTE_SELLER",
            "annual_gross_sales_usd": Decimal("50000.00"),
            "annual_transaction_count": 250,
            "nexus_threshold_sales_usd": Decimal("100000.00"),
            "nexus_threshold_transaction_count": 200,
            "registration_date": "2024-02-01",
        })

        assert result["nexus_eligible"] is True
        assert result["registration_status"] == "ACTIVE"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REG-03
# Requirement: Registration Workflow #1 (both branches False) and #4
#   (PENDING_REVIEW status when ineligible).
# Test Description: Verify nexus_eligible is False and registration_status
#   is PENDING_REVIEW when both threshold checks fail.
# Input: registration with sales < sales threshold and transactions <
#   transaction threshold.
# Expected Output: nexus_eligible == False, registration_status ==
#   "PENDING_REVIEW".
# Coverage Notes: Validates the False-branch of the nexus rule and the
#   PENDING_REVIEW status mapping.
# --------------------------------------------------------------------------- #
def test_register_filer_no_nexus_results_in_pending_review():
    try:
        platform = build_platform()
        result = platform.register_filer({
            "filer_id": "F-1003",
            "filer_category": "USE_TAX_FILER",
            "annual_gross_sales_usd": Decimal("9000.00"),
            "annual_transaction_count": 5,
            "nexus_threshold_sales_usd": Decimal("100000.00"),
            "nexus_threshold_transaction_count": 200,
            "registration_date": "2024-03-10",
        })

        assert result["nexus_eligible"] is False
        assert result["registration_status"] == "PENDING_REVIEW"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REG-04
# Requirement: Registration Workflow #2 (output keys).
# Test Description: Verify the registration output dictionary contains all
#   five required keys.
# Input: any valid registration.
# Expected Output: result contains keys filer_id, filer_category,
#   nexus_eligible, registration_status, effective_start_date.
# Coverage Notes: Schema completeness for register_filer output.
# --------------------------------------------------------------------------- #
def test_register_filer_output_includes_required_keys():
    try:
        platform = build_platform()
        result = platform.register_filer({
            "filer_id": "F-1004",
            "filer_category": "IN_STATE_RETAILER",
            "annual_gross_sales_usd": Decimal("500000.00"),
            "annual_transaction_count": 1000,
            "nexus_threshold_sales_usd": Decimal("100000.00"),
            "nexus_threshold_transaction_count": 200,
            "registration_date": "2024-04-01",
        })

        for key in (
            "filer_id",
            "filer_category",
            "nexus_eligible",
            "registration_status",
            "effective_start_date",
        ):
            assert key in result, f"missing key {key!r} in registration output"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REG-05
# Requirement: Registration Workflow #5 (effective_start_date == registration_date).
# Test Description: Verify effective_start_date equals the input registration_date.
# Input: registration with registration_date "2024-05-20".
# Expected Output: effective_start_date == "2024-05-20".
# Coverage Notes: Direct propagation of registration_date.
# --------------------------------------------------------------------------- #
def test_register_filer_effective_start_date_equals_registration_date():
    try:
        platform = build_platform()
        result = platform.register_filer({
            "filer_id": "F-1005",
            "filer_category": "MARKETPLACE_FACILITATOR",
            "annual_gross_sales_usd": Decimal("750000.00"),
            "annual_transaction_count": 1500,
            "nexus_threshold_sales_usd": Decimal("100000.00"),
            "nexus_threshold_transaction_count": 200,
            "registration_date": "2024-05-20",
        })

        assert result["effective_start_date"] == "2024-05-20"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REG-06
# Requirement: Registration Workflow #1 (boundary equality on transaction
#   count triggers nexus).
# Test Description: When annual_transaction_count equals the transaction
#   threshold exactly, nexus_eligible is True (uses >=).
# Input: transactions == threshold, sales < threshold.
# Expected Output: nexus_eligible == True.
# Coverage Notes: Inclusive lower bound check in nexus_by_transactions,
#   mirroring REG-07 for the sales-side boundary.
# --------------------------------------------------------------------------- #
def test_register_filer_transaction_count_boundary_inclusive():
    try:
        platform = build_platform()
        result = platform.register_filer({
            "filer_id": "F-1006",
            "filer_category": "REMOTE_SELLER",
            "annual_gross_sales_usd": Decimal("10.00"),
            "annual_transaction_count": 200,
            "nexus_threshold_sales_usd": Decimal("100000.00"),
            "nexus_threshold_transaction_count": 200,
            "registration_date": "2024-06-01",
        })

        assert result["nexus_eligible"] is True
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REG-07
# Requirement: Registration Workflow #1 (boundary equality on sales triggers
#   nexus).
# Test Description: When annual_gross_sales_usd equals the sales threshold
#   exactly, nexus_eligible is True (uses >=).
# Input: sales == threshold, transactions < threshold.
# Expected Output: nexus_eligible == True.
# Coverage Notes: Inclusive lower bound check in nexus_by_sales.
# --------------------------------------------------------------------------- #
def test_register_filer_sales_boundary_inclusive():
    try:
        platform = build_platform()
        result = platform.register_filer({
            "filer_id": "F-1007",
            "filer_category": "REMOTE_SELLER",
            "annual_gross_sales_usd": Decimal("100000.00"),
            "annual_transaction_count": 10,
            "nexus_threshold_sales_usd": Decimal("100000.00"),
            "nexus_threshold_transaction_count": 200,
            "registration_date": "2024-07-01",
        })

        assert result["nexus_eligible"] is True
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: REG-08
# Requirement: Registration Workflow #2 (filer_id and filer_category in output).
# Test Description: Verify input filer_id and filer_category appear unchanged
#   in the output.
# Input: filer_id="F-PROP", filer_category="USE_TAX_FILER".
# Expected Output: result["filer_id"] == "F-PROP" and
#   result["filer_category"] == "USE_TAX_FILER".
# Coverage Notes: Identity propagation of declared output fields.
# --------------------------------------------------------------------------- #
def test_register_filer_propagates_identity_fields():
    try:
        platform = build_platform()
        result = platform.register_filer({
            "filer_id": "F-PROP",
            "filer_category": "USE_TAX_FILER",
            "annual_gross_sales_usd": Decimal("1.00"),
            "annual_transaction_count": 0,
            "nexus_threshold_sales_usd": Decimal("100000.00"),
            "nexus_threshold_transaction_count": 200,
            "registration_date": "2024-08-08",
        })

        assert result["filer_id"] == "F-PROP"
        assert result["filer_category"] == "USE_TAX_FILER"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")
