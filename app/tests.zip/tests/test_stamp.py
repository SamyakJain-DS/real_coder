import json
import re
import pytest
from click.testing import CliRunner


def _check(cli):
    if cli is None:
        pytest.fail("stamp module not importable - empty repository")


class _Result:
    """Wraps a CliRunner result to match the subprocess result interface used in assertions."""
    def __init__(self, r):
        self.returncode = r.exit_code
        self.stdout = r.output
        self.stderr = ""


def _run(cli, args, workdir=None):
    runner = CliRunner(mix_stderr=True)
    r = runner.invoke(cli, args)
    return _Result(r)


def test_stamp_cli_group_accessible(stamp_cli, workdir):
    _check(stamp_cli)
    assert {"add", "list", "catalog", "value"}.issubset(set(stamp_cli.commands.keys()))


def test_add_prints_assigned_id(stamp_cli, workdir):
    _check(stamp_cli)
    result = _run(stamp_cli, ["add", "2000", "us", "24c", "eagle", "good"], workdir)
    assert result.returncode == 0
    assert result.stdout.strip() != ""
    assert re.search(r'\b1\b', result.stdout)


def test_add_sequential_ids(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    result2 = _run(stamp_cli, ["add", "1900", "uk", "1p", "queen", "used"], workdir)
    assert result2.returncode == 0
    assert re.search(r'\b2\b', result2.stdout)


def test_list_no_args_returns_all(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    _run(stamp_cli, ["add", "1900", "uk", "1p", "queen", "used"], workdir)
    result = _run(stamp_cli, ["list"], workdir)
    assert result.returncode == 0
    lines = [l for l in result.stdout.strip().split("\n") if l.strip()]
    assert len(lines) == 2


def test_list_single_country_filter(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    _run(stamp_cli, ["add", "1900", "uk", "1p", "queen", "used"], workdir)
    result = _run(stamp_cli, ["list", "us"], workdir)
    assert result.returncode == 0
    lines = [l for l in result.stdout.strip().split("\n") if l.strip()]
    assert len(lines) == 1
    assert lines[0].split()[2] == "us"


def test_list_country_year_filter(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    _run(stamp_cli, ["add", "1900", "us", "2c", "flag", "used"], workdir)
    _run(stamp_cli, ["add", "1900", "uk", "1p", "queen", "good"], workdir)
    result = _run(stamp_cli, ["list", "us", "1900"], workdir)
    assert result.returncode == 0
    lines = [l for l in result.stdout.strip().split("\n") if l.strip()]
    assert len(lines) == 1
    fields = lines[0].split()
    assert fields[2] == "us"
    assert fields[1] == "1900"


def test_list_no_match_empty_output(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    result = _run(stamp_cli, ["list", "jp"], workdir)
    assert result.returncode == 0
    assert result.stdout.strip() == ""


def test_list_field_order_and_separator(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    result = _run(stamp_cli, ["list"], workdir)
    assert result.returncode == 0
    line = result.stdout.strip()
    fields = line.split(" ")
    assert len(fields) == 7
    assert fields[0] == "1"
    assert fields[1] == "1869"
    assert fields[2] == "us"
    assert fields[3] == "24c"
    assert fields[4] == "eagle"
    assert fields[5] == "mint"
    assert fields[6] == "N/A"


def test_list_creates_file_no_error(stamp_cli, workdir):
    _check(stamp_cli)
    result = _run(stamp_cli, ["list"], workdir)
    assert result.returncode == 0
    assert result.stdout.strip() == ""
    stamps_file = workdir / "stamps.json"
    assert stamps_file.exists()
    data = json.loads(stamps_file.read_text())
    assert data["stamps"] == []
    assert data["next_id"] == 1


def test_catalog_sets_value_on_highest_id(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    _run(stamp_cli, ["add", "1900", "uk", "1p", "queen", "used"], workdir)
    catalog_result = _run(stamp_cli, ["catalog", "75.5"], workdir)
    assert catalog_result.returncode == 0
    assert catalog_result.stdout.strip() != ""
    list_result = _run(stamp_cli, ["list"], workdir)
    lines = [l for l in list_result.stdout.strip().split("\n") if l.strip()]
    stamp1_fields = next(l.split() for l in lines if l.split()[0] == "1")
    stamp2_fields = next(l.split() for l in lines if l.split()[0] == "2")
    assert stamp1_fields[-1] == "N/A"
    assert stamp2_fields[-1] != "N/A"
    assert float(stamp2_fields[-1]) == pytest.approx(75.5)


def test_catalog_overwrites_previous_value(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    _run(stamp_cli, ["catalog", "50.0"], workdir)
    _run(stamp_cli, ["catalog", "99.99"], workdir)
    result = _run(stamp_cli, ["list"], workdir)
    fields = result.stdout.strip().split()
    assert float(fields[-1]) == pytest.approx(99.99)


def test_catalog_empty_collection_fails(stamp_cli, workdir):
    _check(stamp_cli)
    result = _run(stamp_cli, ["catalog", "75.0"], workdir)
    assert result.returncode != 0
    assert result.stderr.strip() != "" or result.stdout.strip() != ""


def test_value_zero_when_no_catalog_values(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    result = _run(stamp_cli, ["value"], workdir)
    assert result.returncode == 0
    assert result.stdout.strip() == "0.00"


def test_value_sum_of_non_null(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    _run(stamp_cli, ["catalog", "10.0"], workdir)
    _run(stamp_cli, ["add", "1900", "uk", "1p", "queen", "used"], workdir)
    _run(stamp_cli, ["catalog", "20.5"], workdir)
    result = _run(stamp_cli, ["value"], workdir)
    assert result.returncode == 0
    assert result.stdout.strip() == "30.50"


def test_value_ignores_null_catalog(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    _run(stamp_cli, ["catalog", "10.0"], workdir)
    _run(stamp_cli, ["add", "1900", "uk", "1p", "queen", "used"], workdir)
    result = _run(stamp_cli, ["value"], workdir)
    assert result.returncode == 0
    assert result.stdout.strip() == "10.00"


def test_value_two_decimal_places(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    _run(stamp_cli, ["catalog", "75.0"], workdir)
    result = _run(stamp_cli, ["value"], workdir)
    assert result.returncode == 0
    assert re.match(r"^\d+\.\d{2}$", result.stdout.strip())


def test_value_creates_file_no_error(stamp_cli, workdir):
    _check(stamp_cli)
    result = _run(stamp_cli, ["value"], workdir)
    assert result.returncode == 0
    assert result.stdout.strip() == "0.00"
    assert (workdir / "stamps.json").exists()


def test_add_creates_file_and_persists_fields(stamp_cli, workdir):
    _check(stamp_cli)
    result = _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    assert result.returncode == 0
    stamps_file = workdir / "stamps.json"
    assert stamps_file.exists()
    data = json.loads(stamps_file.read_text())
    assert len(data["stamps"]) == 1
    stamp = data["stamps"][0]
    assert stamp["country"] == "us"
    assert isinstance(stamp["id"], int)
    assert isinstance(stamp["year"], int)


def test_add_stamps_json_contains_next_id(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    data = json.loads((workdir / "stamps.json").read_text())
    assert "next_id" in data
    assert isinstance(data["next_id"], int)
    assert data["next_id"] == 2


def test_add_sets_catalog_value_null(stamp_cli, workdir):
    _check(stamp_cli)
    _run(stamp_cli, ["add", "1869", "us", "24c", "eagle", "mint"], workdir)
    data = json.loads((workdir / "stamps.json").read_text())
    assert data["stamps"][0]["catalog_value"] is None


def test_catalog_creates_file_when_absent(stamp_cli, workdir):
    _check(stamp_cli)
    assert not (workdir / "stamps.json").exists()
    _run(stamp_cli, ["catalog", "75.0"], workdir)
    assert (workdir / "stamps.json").exists()