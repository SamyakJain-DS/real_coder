"""
F2P test suite for the Go CLI framework library.

Every test maps to an explicit requirement from the prompt.
Tests verify observable behaviour through compiled Go snippets.
"""

import os
import subprocess
import textwrap
from pathlib import Path

import pytest

# =============================================================================
# Infrastructure
# =============================================================================

def _find_module_root() -> Path:
    """
    Locate the Go module root (directory containing go.mod or cli/).
    Checks /app first (standard Docker codebase location), then relative paths.
    """
    for candidate in [
        Path("/app"),
        Path(__file__).parent.parent,
        Path(__file__).parent,
    ]:
        if (candidate / "go.mod").exists() or (candidate / "cli").is_dir():
            return candidate
    return Path("/app")


def _cli_pkg_exists() -> bool:
    """
    Return True when at least one .go source file exists in the cli/ package
    directory.  This is the Go equivalent of catching ImportError for a missing
    Python module: file absence is detectable at Python runtime even though Go's
    import resolution is compile-time only.
    """
    cli_dir = _find_module_root() / "cli"
    return cli_dir.is_dir() and any(cli_dir.glob("*.go"))


def _get_module_name() -> str:
    """Read the declared module name from go.mod."""
    gomod = _find_module_root() / "go.mod"
    if gomod.exists():
        for line in gomod.read_text().splitlines():
            line = line.strip()
            if line.startswith("module "):
                parts = line.split()
                if len(parts) >= 2:
                    return parts[1]
    return "go_cli_framework"


def _require_cli():
    """
    Call as the FIRST LINE of every test body.
    Raises pytest.Failed (FAILED, not ERROR) when the cli package is absent.
    This is the direct Go-equivalent of:
        _require(pr_module)  # Python reference pattern
        fail("Missing class resolver.X")  # Java reflection pattern
    """
    if not _cli_pkg_exists():
        pytest.fail("cli package absent - empty repository baseline")


def _run_go(source: str, extra_env: dict | None = None) -> tuple[int, str, str]:
    """
    Write `source` to a temporary Go module, compile and run it.
    The temp module imports the cli package via a `replace` directive pointing
    to the actual module root, so no pre-built artifacts are required.
    Returns (returncode, stdout, stderr).
    """
    import tempfile

    module_name = _get_module_name()
    module_root = _find_module_root()

    gomod_content = (
        f"module _testharness\n\ngo 1.21\n\n"
        f"require {module_name} v0.0.0\n\n"
        f"replace {module_name} => {module_root}\n"
    )

    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)

    with tempfile.TemporaryDirectory() as tmpdir:
        d = Path(tmpdir)
        (d / "go.mod").write_text(gomod_content)
        (d / "main.go").write_text(source)
        result = subprocess.run(
            # -mod=mod allows Go to create/update go.sum for the temp module on
            # first run.  Passed here (not via GOFLAGS in the Dockerfile) so the
            # flag is scoped only to this subprocess and does not affect the
            # global Go environment.
            ["go", "run", "-mod=mod", "."],
            cwd=str(d),
            capture_output=True,
            text=True,
            timeout=60,
            env=env,
        )
    return result.returncode, result.stdout, result.stderr


# ---------------------------------------------------------------------------
# Go snippet builder
#
# _snippet(main_body) returns a complete, self-contained Go main program.
# Every snippet includes all command structs used in tests and the
# captureOutput / failMsg helpers so each program is independently runnable.
# ---------------------------------------------------------------------------

_COMMON_TEMPLATE = '''\
package main

import (
\t"bytes"
\t"fmt"
\t"io"
\t"os"
\t"strings"
\t"MODULE_NAME/cli"
)

// suppress unused-import error for tests that do not call strings directly
var _ = strings.Contains

type stringCmd struct {
\tName     string `cli:"name,n" help:"a name"`
\texecuted bool
}
func (c *stringCmd) Execute() error { c.executed = true; return nil }

type intCmd struct {
\tCount    int `cli:"count,c" help:"a count"`
\texecuted bool
}
func (c *intCmd) Execute() error { c.executed = true; return nil }

type boolCmd struct {
\tVerbose  bool `cli:"verbose,v" help:"verbose mode"`
\texecuted bool
}
func (c *boolCmd) Execute() error { c.executed = true; return nil }

type float64Cmd struct {
\tRate     float64 `cli:"rate,r" help:"a rate"`
\texecuted bool
}
func (c *float64Cmd) Execute() error { c.executed = true; return nil }

type requiredCmd struct {
\tName string `cli:"name,n" help:"a name" required:"true"`
\texecuted bool
}
func (c *requiredCmd) Execute() error { c.executed = true; return nil }

type envCmd struct {
\tHost string `cli:"host,o" help:"a host" env:"TEST_CLI_HOST"`
\texecuted bool
}
func (c *envCmd) Execute() error { c.executed = true; return nil }

type posCmd struct {
\tInput string `pos:"1" help:"input file"`
\texecuted bool
}
func (c *posCmd) Execute() error { c.executed = true; return nil }

func captureOutput(f func()) string {
\told := os.Stdout
\tr, w, _ := os.Pipe()
\tos.Stdout = w
\tf()
\tw.Close()
\tos.Stdout = old
\tvar buf bytes.Buffer
\tio.Copy(&buf, r)
\treturn buf.String()
}

func failMsg(msg string) {
\tfmt.Fprintln(os.Stderr, "FAIL: "+msg)
\tos.Exit(1)
}

func main() {
'''


def _snippet(main_body: str) -> str:
    """Build a complete Go main program from a main() body string."""
    module = _get_module_name()
    header = _COMMON_TEMPLATE.replace("MODULE_NAME", module)
    dedented = textwrap.dedent(main_body.strip("\n"))
    indented = textwrap.indent(dedented, "\t")
    return header + indented + "\n}\n"


# =============================================================================
# App Initialization
# =============================================================================

def test_new_returns_app():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        if app == nil {
            failMsg("New returned nil, expected *App")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_version_flag_writes_version_and_returns_nil():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "2.3.4")
        var runErr error
        output := captureOutput(func() {
            runErr = app.Run([]string{"--version"})
        })
        if runErr != nil {
            failMsg("expected nil error for --version, got: " + runErr.Error())
        }
        if !strings.Contains(output, "2.3.4") {
            failMsg("expected '2.3.4' in stdout, got: " + output)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


# =============================================================================
# Command Registration
# =============================================================================

def test_add_command_success():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        err := app.AddCommand("greet", "Greet someone", &stringCmd{})
        if err != nil {
            failMsg("expected nil error on successful AddCommand, got: " + err.Error())
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_add_command_duplicate_command_name():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        err := app.AddCommand("greet", "Greet again", &stringCmd{})
        if err == nil {
            failMsg("expected non-nil error for duplicate command name, got nil")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_add_command_collides_with_group_name():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddGroup("user", "User commands")
        err := app.AddCommand("user", "Top-level user", &stringCmd{})
        if err == nil {
            failMsg("expected non-nil error when command name matches existing group name")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_add_group_success():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        group, err := app.AddGroup("user", "User commands")
        if err != nil {
            failMsg("expected nil error on successful AddGroup, got: " + err.Error())
        }
        if group == nil {
            failMsg("expected non-nil *Group, got nil")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_add_group_duplicate_group_name():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddGroup("user", "User commands")
        group, err := app.AddGroup("user", "User commands again")
        if err == nil {
            failMsg("expected non-nil error for duplicate group name")
        }
        if group != nil {
            failMsg("expected nil *Group on error, got non-nil")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_add_group_collides_with_command_name():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        group, err := app.AddGroup("greet", "Greet group")
        if err == nil {
            failMsg("expected non-nil error when group name matches existing command name")
        }
        if group != nil {
            failMsg("expected nil *Group on error, got non-nil")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_group_add_command_success():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        group, _ := app.AddGroup("user", "User commands")
        err := group.AddCommand("list", "List users", &stringCmd{})
        if err != nil {
            failMsg("expected nil error on successful Group.AddCommand, got: " + err.Error())
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_group_add_command_duplicate_within_group():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        group, _ := app.AddGroup("user", "User commands")
        group.AddCommand("list", "List users", &stringCmd{})
        err := group.AddCommand("list", "List users again", &stringCmd{})
        if err == nil {
            failMsg("expected non-nil error for duplicate subcommand name within group")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


# =============================================================================
# Field Type Parsing
# =============================================================================

def test_run_parses_string_flag_long_form():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &stringCmd{}
        app.AddCommand("greet", "Greet someone", cmd)
        err := app.Run([]string{"greet", "--name", "Alice"})
        if err != nil {
            failMsg("expected nil error, got: " + err.Error())
        }
        if cmd.Name != "Alice" {
            failMsg("expected Name='Alice', got: " + cmd.Name)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_parses_string_flag_short_form():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &stringCmd{}
        app.AddCommand("greet", "Greet someone", cmd)
        err := app.Run([]string{"greet", "-n", "Bob"})
        if err != nil {
            failMsg("expected nil error, got: " + err.Error())
        }
        if cmd.Name != "Bob" {
            failMsg("expected Name='Bob', got: " + cmd.Name)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_parses_int_flag():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &intCmd{}
        app.AddCommand("run", "Run something", cmd)
        err := app.Run([]string{"run", "--count", "42"})
        if err != nil {
            failMsg("expected nil error, got: " + err.Error())
        }
        if cmd.Count != 42 {
            failMsg(fmt.Sprintf("expected Count=42, got: %d", cmd.Count))
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_parses_bool_flag():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &boolCmd{}
        app.AddCommand("run", "Run something", cmd)
        err := app.Run([]string{"run", "--verbose", "true"})
        if err != nil {
            failMsg("expected nil error, got: " + err.Error())
        }
        if !cmd.Verbose {
            failMsg("expected Verbose=true")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_parses_float64_flag():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &float64Cmd{}
        app.AddCommand("run", "Run something", cmd)
        err := app.Run([]string{"run", "--rate", "3.14"})
        if err != nil {
            failMsg("expected nil error, got: " + err.Error())
        }
        if cmd.Rate < 3.139 || cmd.Rate > 3.141 {
            failMsg(fmt.Sprintf("expected Rate~3.14, got: %f", cmd.Rate))
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_invalid_int_conversion():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &intCmd{}
        app.AddCommand("run", "Run something", cmd)
        err := app.Run([]string{"run", "--count", "notanint"})
        if err == nil {
            failMsg("expected non-nil error for invalid int value, got nil")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_invalid_float64_conversion():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &float64Cmd{}
        app.AddCommand("run", "Run something", cmd)
        err := app.Run([]string{"run", "--rate", "notafloat"})
        if err == nil {
            failMsg("expected non-nil error for invalid float64 value, got nil")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_invalid_bool_conversion():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &boolCmd{}
        app.AddCommand("run", "Run something", cmd)
        err := app.Run([]string{"run", "--verbose", "notabool"})
        if err == nil {
            failMsg("expected non-nil error for invalid bool value, got nil")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


# =============================================================================
# Environment Variable Binding
# =============================================================================

def test_run_env_var_binds_field():
    _require_cli()
    rc, _, stderr = _run_go(
        _snippet("""\
            app := cli.New("myapp", "1.0.0")
            cmd := &envCmd{}
            app.AddCommand("connect", "Connect to host", cmd)
            err := app.Run([]string{"connect"})
            if err != nil {
                failMsg("expected nil error, got: " + err.Error())
            }
            if cmd.Host != "localhost" {
                failMsg("expected Host='localhost' from env var, got: " + cmd.Host)
            }
        """),
        extra_env={"TEST_CLI_HOST": "localhost"},
    )
    assert rc == 0, f"FAIL: {stderr}"


def test_run_args_precedence_over_env_var():
    _require_cli()
    rc, _, stderr = _run_go(
        _snippet("""\
            app := cli.New("myapp", "1.0.0")
            cmd := &envCmd{}
            app.AddCommand("connect", "Connect to host", cmd)
            err := app.Run([]string{"connect", "--host", "argshost"})
            if err != nil {
                failMsg("expected nil error, got: " + err.Error())
            }
            if cmd.Host != "argshost" {
                failMsg("expected Host='argshost' (args over env), got: " + cmd.Host)
            }
        """),
        extra_env={"TEST_CLI_HOST": "envhost"},
    )
    assert rc == 0, f"FAIL: {stderr}"


# =============================================================================
# Execution
# =============================================================================

def test_run_calls_execute_on_matched_struct():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &stringCmd{}
        app.AddCommand("greet", "Greet someone", cmd)
        app.Run([]string{"greet", "--name", "Alice"})
        if !cmd.executed {
            failMsg("expected Execute() to be called on matched command struct")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_required_field_missing():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &requiredCmd{}
        app.AddCommand("greet", "Greet someone", cmd)
        err := app.Run([]string{"greet"})
        if err == nil {
            failMsg("expected non-nil error when required field is missing")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_unrecognized_flag_returns_error():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &stringCmd{}
        app.AddCommand("greet", "Greet someone", cmd)
        err := app.Run([]string{"greet", "--unknown", "value"})
        if err == nil {
            failMsg("expected non-nil error for unrecognized flag, got nil")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_unmatched_command_returns_error():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        err := app.Run([]string{"unknown"})
        if err == nil {
            failMsg("expected non-nil error for unmatched command, got nil")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_positional_arg():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &posCmd{}
        app.AddCommand("process", "Process a file", cmd)
        err := app.Run([]string{"process", "myfile.txt"})
        if err != nil {
            failMsg("expected nil error, got: " + err.Error())
        }
        if cmd.Input != "myfile.txt" {
            failMsg("expected Input='myfile.txt', got: " + cmd.Input)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


# =============================================================================
# Subcommand Group Dispatch
# =============================================================================

def test_run_group_subcommand_dispatch():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        group, _ := app.AddGroup("user", "User commands")
        cmd := &stringCmd{}
        group.AddCommand("list", "List users", cmd)
        err := app.Run([]string{"user", "list"})
        if err != nil {
            failMsg("expected nil error for group-subcommand dispatch, got: " + err.Error())
        }
        if !cmd.executed {
            failMsg("expected Execute() to be called on subcommand struct")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


# =============================================================================
# Help Text
# =============================================================================

def test_run_top_level_help_long():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        app.AddGroup("user", "User commands")
        var runErr error
        output := captureOutput(func() {
            runErr = app.Run([]string{"--help"})
        })
        if runErr != nil {
            failMsg("expected nil error for --help, got: " + runErr.Error())
        }
        if !strings.Contains(output, "greet") {
            failMsg("expected top-level help to contain 'greet', got: " + output)
        }
        if !strings.Contains(output, "user") {
            failMsg("expected top-level help to contain group name 'user', got: " + output)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_top_level_help_short():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        var runErr error
        output := captureOutput(func() {
            runErr = app.Run([]string{"-h"})
        })
        if runErr != nil {
            failMsg("expected nil error for -h, got: " + runErr.Error())
        }
        if !strings.Contains(output, "greet") {
            failMsg("expected top-level help to contain 'greet', got: " + output)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_command_help_long():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        var runErr error
        output := captureOutput(func() {
            runErr = app.Run([]string{"greet", "--help"})
        })
        if runErr != nil {
            failMsg("expected nil error for 'greet --help', got: " + runErr.Error())
        }
        if !strings.Contains(output, "greet") {
            failMsg("expected command help to contain 'greet', got: " + output)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_command_help_short():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        var runErr error
        output := captureOutput(func() {
            runErr = app.Run([]string{"greet", "-h"})
        })
        if runErr != nil {
            failMsg("expected nil error for 'greet -h', got: " + runErr.Error())
        }
        if !strings.Contains(output, "greet") {
            failMsg("expected command help to contain 'greet', got: " + output)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_group_help_long():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        group, _ := app.AddGroup("user", "User commands")
        group.AddCommand("list", "List users", &stringCmd{})
        var runErr error
        output := captureOutput(func() {
            runErr = app.Run([]string{"user", "--help"})
        })
        if runErr != nil {
            failMsg("expected nil error for 'user --help', got: " + runErr.Error())
        }
        if !strings.Contains(output, "list") {
            failMsg("expected group help to contain subcommand 'list', got: " + output)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_run_group_help_short():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        group, _ := app.AddGroup("user", "User commands")
        group.AddCommand("list", "List users", &stringCmd{})
        var runErr error
        output := captureOutput(func() {
            runErr = app.Run([]string{"user", "-h"})
        })
        if runErr != nil {
            failMsg("expected nil error for 'user -h', got: " + runErr.Error())
        }
        if !strings.Contains(output, "list") {
            failMsg("expected group help to contain subcommand 'list', got: " + output)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_help_text_content():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        output := captureOutput(func() {
            app.Run([]string{"greet", "--help"})
        })
        if !strings.Contains(output, "greet") {
            failMsg("expected help to contain command name 'greet', got: " + output)
        }
        if !strings.Contains(output, "Greet someone") {
            failMsg("expected help to contain command description 'Greet someone', got: " + output)
        }
        if !strings.Contains(output, "name") {
            failMsg("expected help to contain flag long name 'name', got: " + output)
        }
        if !strings.Contains(output, "a name") {
            failMsg("expected help to contain flag description 'a name', got: " + output)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_help_text_contains_positional_arg_info():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("process", "Process a file", &posCmd{})
        output := captureOutput(func() {
            app.Run([]string{"process", "--help"})
        })
        if !strings.Contains(output, "input file") {
            failMsg("expected help to contain positional arg description 'input file', got: " + output)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


# =============================================================================
# Shell Completion
# =============================================================================

def test_generate_completion_bash():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        script, err := app.GenerateCompletion("bash")
        if err != nil {
            failMsg("expected nil error for bash completion, got: " + err.Error())
        }
        if script == "" {
            failMsg("expected non-empty bash completion script")
        }
        if !strings.Contains(script, "greet") {
            failMsg("expected bash script to contain 'greet', got: " + script)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_generate_completion_zsh():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        app.AddCommand("greet", "Greet someone", &stringCmd{})
        script, err := app.GenerateCompletion("zsh")
        if err != nil {
            failMsg("expected nil error for zsh completion, got: " + err.Error())
        }
        if script == "" {
            failMsg("expected non-empty zsh completion script")
        }
        if !strings.Contains(script, "greet") {
            failMsg("expected zsh script to contain 'greet', got: " + script)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_generate_completion_unsupported_shell():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        script, err := app.GenerateCompletion("fish")
        if err == nil {
            failMsg("expected non-nil error for unsupported shell 'fish', got nil")
        }
        if script != "" {
            failMsg("expected empty string for unsupported shell, got: " + script)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"


def test_generate_completion_includes_group_subcommands():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        group, _ := app.AddGroup("user", "User commands")
        group.AddCommand("list", "List users", &stringCmd{})
        script, err := app.GenerateCompletion("bash")
        if err != nil {
            failMsg("expected nil error, got: " + err.Error())
        }
        if !strings.Contains(script, "list") {
            failMsg("expected completion script to contain subcommand 'list', got: " + script)
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"

def test_run_parses_bool_flag_false():
    _require_cli()
    rc, _, stderr = _run_go(_snippet("""\
        app := cli.New("myapp", "1.0.0")
        cmd := &boolCmd{}
        app.AddCommand("run", "Run something", cmd)
        err := app.Run([]string{"run", "--verbose", "false"})
        if err != nil {
            failMsg("expected nil error, got: " + err.Error())
        }
        if cmd.Verbose {
            failMsg("expected Verbose=false")
        }
    """))
    assert rc == 0, f"FAIL: {stderr}"