from __future__ import annotations

import abc
import dataclasses
import datetime
import email.utils
import inspect
import io
import re
import threading
import time
import typing
import urllib.parse
import uuid
import xml.etree.ElementTree as ET

import pytest

try:
    import embeddable_webdav
    from embeddable_webdav import (
        DeadPropertyBackend,
        ResourceInfo,
        VirtualFileSystem,
        WebDAVServer,
    )

    _SOLUTION_AVAILABLE = True
except ImportError:
    _SOLUTION_AVAILABLE = False
    embeddable_webdav = None

_BASE_FS = VirtualFileSystem if _SOLUTION_AVAILABLE else object
_BASE_DPB = DeadPropertyBackend if _SOLUTION_AVAILABLE else object


# ===========================================================================
# In-memory test backends
# ===========================================================================


@dataclasses.dataclass
class _Resource:
    is_collection: bool
    content: bytes
    content_type: str
    created_at: datetime.datetime
    modified_at: datetime.datetime
    display_name: str
    etag: str


def _utcnow() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc)


def _strong_etag(content: bytes) -> str:
    return '"' + str(abs(hash(content))) + '"'


def _parent_path(path: str) -> str | None:
    if path == "/":
        return None
    head = path.rsplit("/", 1)[0]
    return head if head else "/"


def _basename(path: str) -> str:
    if path == "/":
        return ""
    return path.rsplit("/", 1)[1]


class InMemoryFS(_BASE_FS):
    """A trivial in-memory concrete VirtualFileSystem for tests."""

    def __init__(self) -> None:
        now = _utcnow()
        self._tree: dict[str, _Resource] = {
            "/": _Resource(True, b"", "", now, now, "", ""),
        }

    def exists(self, path: str) -> bool:
        return path in self._tree

    def get_info(self, path: str) -> ResourceInfo:
        if path not in self._tree:
            raise FileNotFoundError(path)
        r = self._tree[path]
        return ResourceInfo(
            is_collection=r.is_collection,
            content_length=0 if r.is_collection else len(r.content),
            content_type="" if r.is_collection else r.content_type,
            etag="" if r.is_collection else r.etag,
            created_at=r.created_at,
            modified_at=r.modified_at,
            display_name=r.display_name,
        )

    def list_children(self, path: str) -> list[str]:
        if path not in self._tree:
            raise FileNotFoundError(path)
        if not self._tree[path].is_collection:
            raise NotADirectoryError(path)
        prefix = "/" if path == "/" else path + "/"
        names: list[str] = []
        for p in self._tree:
            if p == path:
                continue
            if not p.startswith(prefix):
                continue
            rest = p[len(prefix):]
            if "/" not in rest:
                names.append(rest)
        return sorted(names)

    def read_bytes(self, path: str) -> bytes:
        if path not in self._tree:
            raise FileNotFoundError(path)
        if self._tree[path].is_collection:
            raise IsADirectoryError(path)
        return self._tree[path].content

    def write_bytes(
        self, path: str, content: bytes, content_type: str
    ) -> None:
        parent = _parent_path(path)
        if parent is None or parent not in self._tree:
            raise FileNotFoundError(parent)
        if not self._tree[parent].is_collection:
            raise NotADirectoryError(parent)
        if path in self._tree and self._tree[path].is_collection:
            raise IsADirectoryError(path)
        now = _utcnow()
        if path in self._tree:
            old = self._tree[path]
            self._tree[path] = _Resource(
                False, content, content_type,
                old.created_at, now, old.display_name or _basename(path),
                _strong_etag(content),
            )
        else:
            self._tree[path] = _Resource(
                False, content, content_type, now, now,
                _basename(path), _strong_etag(content),
            )

    def create_collection(self, path: str) -> None:
        if path in self._tree:
            raise FileExistsError(path)
        parent = _parent_path(path)
        if parent is None or parent not in self._tree:
            raise FileNotFoundError(parent)
        if not self._tree[parent].is_collection:
            raise NotADirectoryError(parent)
        now = _utcnow()
        self._tree[path] = _Resource(
            True, b"", "", now, now, _basename(path), "",
        )

    def delete(self, path: str) -> None:
        if path not in self._tree:
            raise FileNotFoundError(path)
        prefix = "/" if path == "/" else path + "/"
        victims = [
            p for p in list(self._tree)
            if p == path or p.startswith(prefix)
        ]
        for p in victims:
            del self._tree[p]

    def copy(
        self, source: str, destination: str, depth_infinity: bool
    ) -> None:
        if source not in self._tree:
            raise FileNotFoundError(source)
        dst_parent = _parent_path(destination)
        if dst_parent is None or dst_parent not in self._tree:
            raise FileNotFoundError(dst_parent)
        if not self._tree[dst_parent].is_collection:
            raise NotADirectoryError(dst_parent)
        src = self._tree[source]
        now = _utcnow()
        if not src.is_collection:
            self._tree[destination] = _Resource(
                False, src.content, src.content_type, now, now,
                _basename(destination), _strong_etag(src.content),
            )
            return
        if destination in self._tree:
            self.delete(destination)
        self._tree[destination] = _Resource(
            True, b"", "", now, now, _basename(destination), "",
        )
        if not depth_infinity:
            return
        src_prefix = "/" if source == "/" else source + "/"
        dst_prefix = "/" if destination == "/" else destination + "/"
        for p in list(self._tree):
            if p == source:
                continue
            if not p.startswith(src_prefix):
                continue
            rest = p[len(src_prefix):]
            new_p = dst_prefix + rest
            r = self._tree[p]
            self._tree[new_p] = _Resource(
                r.is_collection, r.content, r.content_type, now, now,
                _basename(new_p),
                "" if r.is_collection else _strong_etag(r.content),
            )

    def move(self, source: str, destination: str) -> None:
        if source not in self._tree:
            raise FileNotFoundError(source)
        dst_parent = _parent_path(destination)
        if dst_parent is None or dst_parent not in self._tree:
            raise FileNotFoundError(dst_parent)
        if not self._tree[dst_parent].is_collection:
            raise NotADirectoryError(dst_parent)
        if destination in self._tree:
            self.delete(destination)
        src_prefix = "/" if source == "/" else source + "/"
        dst_prefix = "/" if destination == "/" else destination + "/"
        moves: list[tuple[str, str]] = [(source, destination)]
        for p in list(self._tree):
            if p == source:
                continue
            if not p.startswith(src_prefix):
                continue
            moves.append((p, dst_prefix + p[len(src_prefix):]))
        for old_p, new_p in moves:
            self._tree[new_p] = self._tree[old_p]
        for old_p, _ in moves:
            if old_p in self._tree:
                del self._tree[old_p]


class InMemoryDPB(_BASE_DPB):

    def __init__(self) -> None:
        self._props: dict[str, dict[tuple[str, str], str]] = {}
        self.calls: list[tuple] = []

    def get_property(self, path: str, namespace: str, name: str) -> str:
        self.calls.append(("get_property", path, namespace, name))
        if path not in self._props or (namespace, name) not in self._props[path]:
            raise KeyError((path, namespace, name))
        return self._props[path][(namespace, name)]

    def set_property(
        self, path: str, namespace: str, name: str, xml_value: str
    ) -> None:
        self.calls.append(("set_property", path, namespace, name, xml_value))
        self._props.setdefault(path, {})[(namespace, name)] = xml_value

    def remove_property(self, path: str, namespace: str, name: str) -> None:
        self.calls.append(("remove_property", path, namespace, name))
        if path not in self._props or (namespace, name) not in self._props[path]:
            raise KeyError((path, namespace, name))
        del self._props[path][(namespace, name)]

    def list_properties(self, path: str) -> list[tuple[str, str, str]]:
        self.calls.append(("list_properties", path))
        if path not in self._props:
            return []
        return sorted(
            (ns, n, v) for (ns, n), v in self._props[path].items()
        )

    def copy_properties(self, source: str, destination: str) -> None:
        self.calls.append(("copy_properties", source, destination))
        self._props.pop(destination, None)
        if source in self._props:
            self._props[destination] = dict(self._props[source])

    def move_properties(self, source: str, destination: str) -> None:
        self.calls.append(("move_properties", source, destination))
        self._props.pop(destination, None)
        if source in self._props:
            self._props[destination] = dict(self._props[source])
        self._props.pop(source, None)


class RecordingFS(InMemoryFS):

    def __init__(self) -> None:
        super().__init__()
        self.calls: list[tuple] = []

    def exists(self, path):
        self.calls.append(("exists", path))
        return super().exists(path)

    def get_info(self, path):
        self.calls.append(("get_info", path))
        return super().get_info(path)

    def list_children(self, path):
        self.calls.append(("list_children", path))
        return super().list_children(path)

    def read_bytes(self, path):
        self.calls.append(("read_bytes", path))
        return super().read_bytes(path)

    def write_bytes(self, path, content, content_type):
        self.calls.append(("write_bytes", path, content, content_type))
        return super().write_bytes(path, content, content_type)

    def create_collection(self, path):
        self.calls.append(("create_collection", path))
        return super().create_collection(path)

    def delete(self, path):
        self.calls.append(("delete", path))
        return super().delete(path)

    def copy(self, source, destination, depth_infinity):
        self.calls.append(("copy", source, destination, depth_infinity))
        return super().copy(source, destination, depth_infinity)

    def move(self, source, destination):
        self.calls.append(("move", source, destination))
        return super().move(source, destination)


# ===========================================================================
# WSGI invocation helpers
# ===========================================================================


def _build_environ(
    method: str,
    path: str,
    body: bytes = b"",
    headers: dict[str, str] | None = None,
) -> dict[str, typing.Any]:
    headers = headers or {}
    environ: dict[str, typing.Any] = {
        "REQUEST_METHOD": method,
        "PATH_INFO": path,
        "QUERY_STRING": "",
        "SERVER_NAME": "test",
        "SERVER_PORT": "80",
        "SERVER_PROTOCOL": "HTTP/1.1",
        "wsgi.version": (1, 0),
        "wsgi.url_scheme": "http",
        "wsgi.input": io.BytesIO(body),
        "wsgi.errors": io.BytesIO(),
        "wsgi.multithread": True,
        "wsgi.multiprocess": False,
        "wsgi.run_once": False,
        "CONTENT_LENGTH": str(len(body)),
    }
    for k, v in headers.items():
        env_k = k.upper().replace("-", "_")
        if env_k in ("CONTENT_TYPE", "CONTENT_LENGTH"):
            environ[env_k] = v
        else:
            environ["HTTP_" + env_k] = v
    return environ


def call_wsgi(
    server: WebDAVServer,
    method: str,
    path: str,
    body: bytes = b"",
    headers: dict[str, str] | None = None,
) -> tuple[str, list[tuple[str, str]], bytes]:
    """Invoke ``server`` as a WSGI app. Returns (status, headers, body)."""
    captured: dict[str, typing.Any] = {}

    def start_response(
        status: str,
        response_headers: list[tuple[str, str]],
        exc_info: typing.Any = None,
    ) -> typing.Callable[[bytes], None]:
        captured["status"] = status
        captured["headers"] = response_headers

        def write(_b: bytes) -> None:
            raise RuntimeError("write() callable should not be needed")

        return write

    environ = _build_environ(method, path, body, headers)
    body_iter = server(environ, start_response)
    body_bytes = b"".join(body_iter)
    return captured["status"], captured["headers"], body_bytes


def header(headers: list[tuple[str, str]], name: str) -> str | None:
    for k, v in headers:
        if k.lower() == name.lower():
            return v
    return None


def headers_lower(
    headers: list[tuple[str, str]],
) -> dict[str, str]:
    return {k.lower(): v for k, v in headers}

STATUS_OK = "200 OK"
STATUS_CREATED = "201 Created"
STATUS_NO_CONTENT = "204 No Content"
STATUS_MULTI_STATUS = "207 Multi-Status"
STATUS_BAD_REQUEST = "400 Bad Request"
STATUS_NOT_FOUND = "404 Not Found"
STATUS_METHOD_NOT_ALLOWED = "405 Method Not Allowed"
STATUS_CONFLICT = "409 Conflict"
STATUS_PRECONDITION_FAILED = "412 Precondition Failed"
STATUS_UNSUPPORTED_MEDIA_TYPE = "415 Unsupported Media Type"
STATUS_LOCKED = "423 Locked"

ALLOW_GLOBAL = (
    "OPTIONS, GET, HEAD, PUT, DELETE, MKCOL, COPY, MOVE, "
    "PROPFIND, PROPPATCH, LOCK, UNLOCK"
)
ALLOW_ON_COLLECTION = (
    "OPTIONS, HEAD, PROPFIND, PROPPATCH, COPY, MOVE, DELETE, LOCK, UNLOCK"
)
ALLOW_ON_NON_COLLECTION_PUT = (
    "OPTIONS, GET, HEAD, PROPFIND, PROPPATCH, COPY, MOVE, DELETE, LOCK, UNLOCK"
)
ALLOW_ON_EXISTING_FOR_MKCOL = (
    "OPTIONS, GET, HEAD, PUT, PROPFIND, PROPPATCH, COPY, MOVE, DELETE, LOCK, UNLOCK"
)


# ===========================================================================
# Pytest fixtures
# ===========================================================================


@pytest.fixture
def fs() -> InMemoryFS:
    if not _SOLUTION_AVAILABLE:
        return None
    return InMemoryFS()


@pytest.fixture
def dpb() -> InMemoryDPB:
    if not _SOLUTION_AVAILABLE:
        return None
    return InMemoryDPB()


@pytest.fixture
def server(fs: InMemoryFS, dpb: InMemoryDPB) -> WebDAVServer:
    if not _SOLUTION_AVAILABLE:
        return None
    return WebDAVServer(fs, dpb)


# ===========================================================================
# XML helpers
# ===========================================================================

DAV_NS = "DAV:"
DAV = "{DAV:}"


def _xml_lockinfo(scope: str = "exclusive", owner: str = "tester") -> bytes:
    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<D:lockinfo xmlns:D="DAV:">\n'
        f"  <D:lockscope><D:{scope}/></D:lockscope>\n"
        '  <D:locktype><D:write/></D:locktype>\n'
        f"  <D:owner>{owner}</D:owner>\n"
        '</D:lockinfo>\n'
    ).encode("utf-8")


def _xml_propfind_allprop() -> bytes:
    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<D:propfind xmlns:D="DAV:"><D:allprop/></D:propfind>'
    ).encode("utf-8")


def _xml_propfind_propname() -> bytes:
    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<D:propfind xmlns:D="DAV:"><D:propname/></D:propfind>'
    ).encode("utf-8")


def _xml_propfind_prop(props: list[tuple[str, str]]) -> bytes:
    """Build a PROPFIND prop body. ``props`` is list of (namespace, local)."""
    inner = ""
    for i, (ns, name) in enumerate(props):
        inner += f'<P{i}:{name} xmlns:P{i}="{ns}"/>'
    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<D:propfind xmlns:D="DAV:"><D:prop>'
        + inner +
        '</D:prop></D:propfind>'
    ).encode("utf-8")


def _xml_proppatch(
    set_props: list[tuple[str, str, str]] | None = None,
    remove_props: list[tuple[str, str]] | None = None,
) -> bytes:
    """``set_props`` is list of (ns, name, inner_xml). ``remove_props`` (ns, name)."""
    set_props = set_props or []
    remove_props = remove_props or []
    blocks = ""
    for i, (ns, name, val) in enumerate(set_props):
        blocks += (
            '<D:set><D:prop>'
            f'<P{i}:{name} xmlns:P{i}="{ns}">{val}</P{i}:{name}>'
            '</D:prop></D:set>'
        )
    for i, (ns, name) in enumerate(remove_props):
        blocks += (
            '<D:remove><D:prop>'
            f'<R{i}:{name} xmlns:R{i}="{ns}"/>'
            '</D:prop></D:remove>'
        )
    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<D:propertyupdate xmlns:D="DAV:">'
        + blocks +
        '</D:propertyupdate>'
    ).encode("utf-8")


def _parse_multistatus(body: bytes) -> ET.Element:
    root = ET.fromstring(body)
    assert root.tag == DAV + "multistatus", f"unexpected root: {root.tag}"
    return root


def _responses(root: ET.Element) -> list[ET.Element]:
    return root.findall(DAV + "response")


def _href(resp: ET.Element) -> str:
    h = resp.find(DAV + "href")
    assert h is not None
    return h.text or ""


def _propstats(resp: ET.Element) -> list[ET.Element]:
    return resp.findall(DAV + "propstat")


def _propstat_status(ps: ET.Element) -> str:
    s = ps.find(DAV + "status")
    assert s is not None
    return s.text or ""


def _propstat_props(ps: ET.Element) -> list[ET.Element]:
    p = ps.find(DAV + "prop")
    assert p is not None
    return list(p)

PROPSTAT_STATUS_OK = "HTTP/1.1 200 OK"
PROPSTAT_STATUS_NOT_FOUND = "HTTP/1.1 404 Not Found"
PROPSTAT_STATUS_FORBIDDEN = "HTTP/1.1 403 Forbidden"
PROPSTAT_STATUS_FAILED_DEPENDENCY = "HTTP/1.1 424 Failed Dependency"


def _success_props(resp: ET.Element) -> list[ET.Element]:
    out: list[ET.Element] = []
    for ps in _propstats(resp):
        if _propstat_status(ps).strip() == PROPSTAT_STATUS_OK:
            out.extend(_propstat_props(ps))
    return out


def _absent_props(resp: ET.Element) -> list[ET.Element]:
    out: list[ET.Element] = []
    for ps in _propstats(resp):
        if _propstat_status(ps).strip() == PROPSTAT_STATUS_NOT_FOUND:
            out.extend(_propstat_props(ps))
    return out


def _forbidden_props(resp: ET.Element) -> list[ET.Element]:
    out: list[ET.Element] = []
    for ps in _propstats(resp):
        if _propstat_status(ps).strip() == PROPSTAT_STATUS_FORBIDDEN:
            out.extend(_propstat_props(ps))
    return out


def _failed_dep_props(resp: ET.Element) -> list[ET.Element]:
    out: list[ET.Element] = []
    for ps in _propstats(resp):
        if _propstat_status(ps).strip() == PROPSTAT_STATUS_FAILED_DEPENDENCY:
            out.extend(_propstat_props(ps))
    return out


# ---------------------------------------------------------------------------
# Convenience seeders
# ---------------------------------------------------------------------------


def seed_file(
    fs: InMemoryFS, path: str, content: bytes = b"hello",
    content_type: str = "text/plain",
) -> None:
    fs.write_bytes(path, content, content_type)


def seed_collection(fs: InMemoryFS, path: str) -> None:
    fs.create_collection(path)


def acquire_lock(
    server: WebDAVServer, path: str, *,
    scope: str = "exclusive", depth: str = "infinity",
    timeout: str = "Second-3600", owner: str = "tester",
) -> str:
    """Acquire a lock and return its token text (without urn:uuid:... wrapper).

    The returned string is the lock token text used inside ``<...>`` brackets
    (e.g. "urn:uuid:...").
    """
    status, hdrs, _ = call_wsgi(
        server, "LOCK", path,
        body=_xml_lockinfo(scope=scope, owner=owner),
        headers={"Depth": depth, "Timeout": timeout},
    )
    assert status == STATUS_OK, f"LOCK failed: {status}"
    raw = header(hdrs, "Lock-Token") or ""
    assert raw.startswith("<") and raw.endswith(">"), raw
    return raw[1:-1]


# ===========================================================================
# T1 .. T10 -- VirtualFileSystem abstract interface (Req 1)
# ===========================================================================


def test_t001_virtualfilesystem_inherits_abc():
    """T1: VirtualFileSystem is a class inheriting abc.ABC."""
    assert inspect.isclass(VirtualFileSystem)
    assert issubclass(VirtualFileSystem, abc.ABC)


def _check_abstract_signature(
    cls: type, name: str,
    expected_params: list[tuple[str, typing.Any]],
    expected_return: typing.Any,
) -> None:
    """Verify ``cls.name`` is abstract and matches expected (name, type) params + return.

    Tolerant of ``from __future__ import annotations`` (string annotations).
    """
    assert name in getattr(cls, "__abstractmethods__", set()), (
        f"{cls.__name__}.{name} must be marked @abc.abstractmethod"
    )
    method = getattr(cls, name)
    sig = inspect.signature(method)
    params = list(sig.parameters.values())
    actual_names = [p.name for p in params]
    expected_names = [n for n, _ in expected_params]
    assert actual_names == expected_names, (
        f"{cls.__name__}.{name} parameter names mismatch: "
        f"expected {expected_names}, got {actual_names}"
    )

    try:
        hints = typing.get_type_hints(method)
    except Exception:
        hints = {}

    for p in params:
        if p.name == "self":
            continue
        expected_type = next(t for n, t in expected_params if n == p.name)
        resolved = hints.get(p.name, p.annotation)
        if resolved == expected_type:
            continue
        exp_repr = (
            getattr(expected_type, "__name__", None)
            or repr(expected_type)
        )
        if isinstance(resolved, str) and resolved.replace(" ", "") in (
            exp_repr.replace(" ", ""),
            repr(expected_type).replace(" ", ""),
            str(expected_type).replace(" ", ""),
        ):
            continue
        raise AssertionError(
            f"{cls.__name__}.{name}({p.name}) annotation mismatch: "
            f"expected {expected_type!r}, got {resolved!r}"
        )

    resolved_return = hints.get("return", sig.return_annotation)
    if resolved_return == expected_return:
        return
    exp_return_repr = (
        getattr(expected_return, "__name__", None)
        or repr(expected_return)
    )
    if expected_return is None and resolved_return in (None, type(None)):
        return
    if isinstance(resolved_return, str) and resolved_return.replace(" ", "") in (
        exp_return_repr.replace(" ", ""),
        repr(expected_return).replace(" ", ""),
        str(expected_return).replace(" ", ""),
        "None" if expected_return is None else "",
    ):
        return
    raise AssertionError(
        f"{cls.__name__}.{name} return annotation mismatch: "
        f"expected {expected_return!r}, got {resolved_return!r}"
    )


def test_t002_vfs_exists_signature():
    """T2: VirtualFileSystem.exists is abstract with (self, path: str) -> bool."""
    _check_abstract_signature(
        VirtualFileSystem, "exists",
        [("self", inspect.Parameter.empty), ("path", str)],
        bool,
    )


def test_t003_vfs_get_info_signature():
    """T3: VirtualFileSystem.get_info abstract: (self, path: str) -> ResourceInfo."""
    _check_abstract_signature(
        VirtualFileSystem, "get_info",
        [("self", inspect.Parameter.empty), ("path", str)],
        ResourceInfo,
    )


def test_t004_vfs_list_children_signature():
    """T4: VirtualFileSystem.list_children abstract: (self, path: str) -> list[str]."""
    _check_abstract_signature(
        VirtualFileSystem, "list_children",
        [("self", inspect.Parameter.empty), ("path", str)],
        list[str],
    )


def test_t005_vfs_read_bytes_signature():
    """T5: VirtualFileSystem.read_bytes abstract: (self, path: str) -> bytes."""
    _check_abstract_signature(
        VirtualFileSystem, "read_bytes",
        [("self", inspect.Parameter.empty), ("path", str)],
        bytes,
    )


def test_t006_vfs_write_bytes_signature():
    """T6: VirtualFileSystem.write_bytes abstract: (self, path, content, content_type) -> None."""
    _check_abstract_signature(
        VirtualFileSystem, "write_bytes",
        [
            ("self", inspect.Parameter.empty),
            ("path", str),
            ("content", bytes),
            ("content_type", str),
        ],
        None,
    )


def test_t007_vfs_create_collection_signature():
    """T7: VirtualFileSystem.create_collection abstract: (self, path: str) -> None."""
    _check_abstract_signature(
        VirtualFileSystem, "create_collection",
        [("self", inspect.Parameter.empty), ("path", str)],
        None,
    )


def test_t008_vfs_delete_signature():
    """T8: VirtualFileSystem.delete abstract: (self, path: str) -> None."""
    _check_abstract_signature(
        VirtualFileSystem, "delete",
        [("self", inspect.Parameter.empty), ("path", str)],
        None,
    )


def test_t009_vfs_copy_signature():
    """T9: VirtualFileSystem.copy abstract: (self, source, destination, depth_infinity) -> None."""
    _check_abstract_signature(
        VirtualFileSystem, "copy",
        [
            ("self", inspect.Parameter.empty),
            ("source", str),
            ("destination", str),
            ("depth_infinity", bool),
        ],
        None,
    )


def test_t010_vfs_move_signature():
    """T10: VirtualFileSystem.move abstract: (self, source, destination) -> None."""
    _check_abstract_signature(
        VirtualFileSystem, "move",
        [
            ("self", inspect.Parameter.empty),
            ("source", str),
            ("destination", str),
        ],
        None,
    )


# ===========================================================================
# T11 .. T12 -- ResourceInfo (Req 2)
# ===========================================================================


def test_t011_resourceinfo_frozen_dataclass_with_fields():
    """T11: ResourceInfo is a frozen dataclass with the seven required fields and types."""
    cls = ResourceInfo
    assert dataclasses.is_dataclass(cls)
    assert cls.__dataclass_params__.frozen is True

    expected_types = {
        "is_collection": bool,
        "content_length": int,
        "content_type": str,
        "etag": str,
        "created_at": datetime.datetime,
        "modified_at": datetime.datetime,
        "display_name": str,
    }
    fields = {f.name: f.type for f in dataclasses.fields(cls)}
    assert set(fields) == set(expected_types), (
        f"ResourceInfo fields mismatch: {set(fields)} != {set(expected_types)}"
    )

    try:
        hints = typing.get_type_hints(cls)
    except Exception:
        hints = {}

    for fname, expected_type in expected_types.items():
        resolved = hints.get(fname, fields[fname])
        if resolved == expected_type:
            continue
        exp_repr = (
            getattr(expected_type, "__name__", None)
            or repr(expected_type)
        )
        if isinstance(resolved, str) and resolved.replace(" ", "") in (
            exp_repr.replace(" ", ""),
            repr(expected_type).replace(" ", ""),
            str(expected_type).replace(" ", ""),
        ):
            continue
        raise AssertionError(
            f"ResourceInfo.{fname} type mismatch: expected {expected_type!r}, "
            f"got {resolved!r}"
        )


def test_t012_resourceinfo_is_immutable():
    """T12: ResourceInfo instances raise FrozenInstanceError on field assignment."""
    now = _utcnow()
    info = ResourceInfo(
        is_collection=False,
        content_length=3,
        content_type="text/plain",
        etag='"x"',
        created_at=now,
        modified_at=now,
        display_name="x",
    )
    with pytest.raises(dataclasses.FrozenInstanceError):
        info.content_length = 99  # type: ignore[misc]


# ===========================================================================
# T13 .. T19 -- DeadPropertyBackend abstract interface (Req 3)
# ===========================================================================


def test_t013_deadpropertybackend_inherits_abc():
    """T13: DeadPropertyBackend is a class inheriting abc.ABC."""
    assert inspect.isclass(DeadPropertyBackend)
    assert issubclass(DeadPropertyBackend, abc.ABC)


def test_t014_dpb_get_property_signature():
    """T14: DeadPropertyBackend.get_property abstract: (self, path, ns, name) -> str."""
    _check_abstract_signature(
        DeadPropertyBackend, "get_property",
        [
            ("self", inspect.Parameter.empty),
            ("path", str),
            ("namespace", str),
            ("name", str),
        ],
        str,
    )


def test_t015_dpb_set_property_signature():
    """T15: DeadPropertyBackend.set_property abstract: (self, path, ns, name, xml_value) -> None."""
    _check_abstract_signature(
        DeadPropertyBackend, "set_property",
        [
            ("self", inspect.Parameter.empty),
            ("path", str),
            ("namespace", str),
            ("name", str),
            ("xml_value", str),
        ],
        None,
    )


def test_t016_dpb_remove_property_signature():
    """T16: DeadPropertyBackend.remove_property abstract: (self, path, ns, name) -> None."""
    _check_abstract_signature(
        DeadPropertyBackend, "remove_property",
        [
            ("self", inspect.Parameter.empty),
            ("path", str),
            ("namespace", str),
            ("name", str),
        ],
        None,
    )


def test_t017_dpb_list_properties_signature():
    """T17: DeadPropertyBackend.list_properties abstract: (self, path) -> list[tuple[str,str,str]]."""
    _check_abstract_signature(
        DeadPropertyBackend, "list_properties",
        [("self", inspect.Parameter.empty), ("path", str)],
        list[tuple[str, str, str]],
    )


def test_t018_dpb_copy_properties_signature():
    """T18: DeadPropertyBackend.copy_properties abstract: (self, source, destination) -> None."""
    _check_abstract_signature(
        DeadPropertyBackend, "copy_properties",
        [
            ("self", inspect.Parameter.empty),
            ("source", str),
            ("destination", str),
        ],
        None,
    )


def test_t019_dpb_move_properties_signature():
    """T19: DeadPropertyBackend.move_properties abstract: (self, source, destination) -> None."""
    _check_abstract_signature(
        DeadPropertyBackend, "move_properties",
        [
            ("self", inspect.Parameter.empty),
            ("source", str),
            ("destination", str),
        ],
        None,
    )


# ===========================================================================
# T20 .. T23 -- WebDAVServer constructor and dispatch (Req 4)
# ===========================================================================


def test_t020_server_init_accepts_and_stores_backends(
    fs: InMemoryFS, dpb: InMemoryDPB
):
    """T20: __init__ takes filesystem and dead_property_backend and uses both.

    We verify by constructing the server and exercising one read-path
    (GET on a seeded file -> requires the filesystem) and one
    PROPFIND with a dead property (requires the backend). If either
    backend were not retained the calls would fail.
    """
    seed_file(fs, "/file.txt", b"abc", "text/plain")
    dpb.set_property("/file.txt", "x:", "tag", "<v/>")
    s = WebDAVServer(fs, dpb)

    status, _, body = call_wsgi(s, "GET", "/file.txt")
    assert status == STATUS_OK, status
    assert body == b"abc"

    status, _, body = call_wsgi(
        s, "PROPFIND", "/file.txt",
        body=_xml_propfind_prop([("x:", "tag")]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status


def test_t021_server_call_is_wsgi_callable(server: WebDAVServer):
    """T21: WebDAVServer.__call__ is WSGI-shaped (returns Iterable[bytes])."""
    captured: dict = {}

    def start_response(status, headers, exc_info=None):
        captured["status"] = status
        captured["headers"] = headers
        return lambda b: None

    environ = _build_environ("OPTIONS", "/")
    body = server(environ, start_response)
    assert iter(body) is not None  # iterable
    chunks = list(body)
    for c in chunks:
        assert isinstance(c, (bytes, bytearray)), (
            f"WSGI body chunk must be bytes-like, got {type(c)}"
        )
    assert "status" in captured


@pytest.mark.parametrize("method", ["PATCH", "TRACE", "CONNECT", "FROBNICATE"])
def test_t022_unsupported_method_returns_405(server: WebDAVServer, method: str):
    """T22: Any method outside the dispatched set yields 405 Method Not Allowed + full Allow + Content-Length: 0 + empty body (Req 4)."""
    status, hdrs, body = call_wsgi(server, method, "/")
    assert status == STATUS_METHOD_NOT_ALLOWED, f"{method}: {status!r}"
    assert header(hdrs, "Allow") == ALLOW_GLOBAL
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t023_request_path_is_unquoted_once(server: WebDAVServer, fs: InMemoryFS):
    """T23: PATH_INFO is run through urllib.parse.unquote exactly once."""
    seed_file(fs, "/with space.txt", b"S", "text/plain")
    status, _, body = call_wsgi(server, "GET", "/with%20space.txt")
    assert status == STATUS_OK, status
    assert body == b"S"

    status, _, _ = call_wsgi(server, "GET", "/with%2520space.txt")
    assert status == STATUS_NOT_FOUND, (
        "double-encoded path should not match (would mean unquote ran twice)"
    )


# ===========================================================================
# T24 -- OPTIONS (Req 5)
# ===========================================================================


@pytest.mark.parametrize(
    "options_path,seed_kind",
    [
        ("/", None),
        ("/missing", None),
        ("/f.txt", "file"),
        ("/dir", "collection"),
    ],
)
def test_t024_options_returns_200_with_dav_and_allow(
    server: WebDAVServer, fs: InMemoryFS, options_path: str, seed_kind: str | None,
):
    """T24: OPTIONS returns the same success response for every request path (Req 5)."""
    if seed_kind == "file":
        seed_file(fs, options_path, b"x", "text/plain")
    elif seed_kind == "collection":
        seed_collection(fs, options_path)
    status, hdrs, body = call_wsgi(server, "OPTIONS", options_path)
    assert status == STATUS_OK, f"OPTIONS {options_path!r}: {status!r}"
    assert header(hdrs, "DAV") == "1, 2"
    assert header(hdrs, "Allow") == ALLOW_GLOBAL
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


# ===========================================================================
# T25 .. T30 -- GET / HEAD (Req 6)
# ===========================================================================


def test_t025_get_404_on_missing(server: WebDAVServer):
    """T25: GET on nonexistent resource returns 404 Not Found, Content-Length: 0, empty body."""
    status, hdrs, body = call_wsgi(server, "GET", "/missing.bin")
    assert status == STATUS_NOT_FOUND, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t026_get_405_on_collection(server: WebDAVServer, fs: InMemoryFS):
    """T26: GET on collection returns 405 Method Not Allowed with collection-Allow set."""
    seed_collection(fs, "/dir")
    status, hdrs, body = call_wsgi(server, "GET", "/dir")
    assert status == STATUS_METHOD_NOT_ALLOWED, status
    assert header(hdrs, "Allow") == ALLOW_ON_COLLECTION
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t027_get_200_on_non_collection(server: WebDAVServer, fs: InMemoryFS):
    """T27: GET on file returns 200 OK, correct content-type, length, etag, last-modified, body."""
    seed_file(fs, "/note.txt", b"hello world", "text/plain")
    info = fs.get_info("/note.txt")
    expected_lm = email.utils.format_datetime(info.modified_at, usegmt=True)

    status, hdrs, body = call_wsgi(server, "GET", "/note.txt")
    assert status == STATUS_OK, status
    assert header(hdrs, "Content-Type") == "text/plain"
    assert header(hdrs, "Content-Length") == str(len(b"hello world"))
    assert header(hdrs, "ETag") == info.etag
    assert header(hdrs, "Last-Modified") == expected_lm
    assert body == b"hello world"


def test_t028_head_matches_get_headers_with_empty_body(
    server: WebDAVServer, fs: InMemoryFS
):
    """T28: HEAD returns same status/headers as GET but empty body."""
    seed_file(fs, "/note.txt", b"hello", "text/plain")
    g_status, g_hdrs, _ = call_wsgi(server, "GET", "/note.txt")
    h_status, h_hdrs, h_body = call_wsgi(server, "HEAD", "/note.txt")
    assert h_status == g_status
    assert headers_lower(h_hdrs) == headers_lower(g_hdrs)
    assert h_body == b""


def test_t029_head_404_on_missing(server: WebDAVServer):
    """T29: HEAD on nonexistent resource returns 404 Not Found with same headers as GET (Content-Length: 0) and empty body."""
    g_status, g_hdrs, _ = call_wsgi(server, "GET", "/nope")
    status, hdrs, body = call_wsgi(server, "HEAD", "/nope")
    assert status == STATUS_NOT_FOUND, status
    assert status == g_status
    assert headers_lower(hdrs) == headers_lower(g_hdrs)
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t030_head_405_on_collection(server: WebDAVServer, fs: InMemoryFS):
    """T30: HEAD on collection returns 405 Method Not Allowed with same headers as GET (Allow + Content-Length: 0) and empty body."""
    seed_collection(fs, "/dir")
    g_status, g_hdrs, _ = call_wsgi(server, "GET", "/dir")
    status, hdrs, body = call_wsgi(server, "HEAD", "/dir")
    assert status == STATUS_METHOD_NOT_ALLOWED, status
    assert status == g_status
    assert headers_lower(hdrs) == headers_lower(g_hdrs)
    assert header(hdrs, "Allow") == ALLOW_ON_COLLECTION
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


# ===========================================================================
# T31 .. T35 -- PUT (Req 7)
# ===========================================================================


def test_t031_put_405_on_collection(server: WebDAVServer, fs: InMemoryFS):
    """T31: PUT on collection returns 405 Method Not Allowed with put-Allow + Content-Length: 0 + empty body."""
    seed_collection(fs, "/dir")
    status, hdrs, body = call_wsgi(
        server, "PUT", "/dir",
        body=b"x", headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_METHOD_NOT_ALLOWED, status
    assert header(hdrs, "Allow") == ALLOW_ON_NON_COLLECTION_PUT
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t032_put_409_when_parent_missing(server: WebDAVServer):
    """T32: PUT when parent path does not exist returns 409 Conflict + Content-Length: 0 + empty body."""
    status, hdrs, body = call_wsgi(
        server, "PUT", "/nodir/file",
        body=b"x", headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_CONFLICT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t033_put_409_when_parent_is_file(server: WebDAVServer, fs: InMemoryFS):
    """T33: PUT when parent path is a non-collection returns 409 Conflict + Content-Length: 0 + empty body."""
    seed_file(fs, "/parent", b"x", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "PUT", "/parent/child",
        body=b"y", headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_CONFLICT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t034_put_creates_new_resource_returns_201(dpb: InMemoryDPB):
    """T34: PUT creating a new resource calls write_bytes(path, body, content_type)
    and returns 201 Created + ETag + Content-Length: 0 + empty body."""
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    status, hdrs, body = call_wsgi(
        s, "PUT", "/new.txt",
        body=b"abc", headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_CREATED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""
    assert rfs.exists("/new.txt")
    info = rfs.get_info("/new.txt")
    assert header(hdrs, "ETag") == info.etag
    assert rfs.read_bytes("/new.txt") == b"abc"
    assert info.content_type == "text/plain", (
        "PUT must forward the request Content-Type to write_bytes"
    )
    write_calls = [c for c in rfs.calls if c[0] == "write_bytes"]
    assert ("write_bytes", "/new.txt", b"abc", "text/plain") in write_calls, (
        f"write_bytes must be called with (path, body, content_type); calls were {write_calls}"
    )


def test_t035_put_overwrite_existing_returns_204(dpb: InMemoryDPB):
    """T35: PUT overwriting an existing file calls write_bytes and returns
    204 No Content + new ETag + Content-Length: 0 + empty body."""
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    seed_file(rfs, "/note.txt", b"old", "text/plain")
    rfs.calls.clear()
    status, hdrs, body = call_wsgi(
        s, "PUT", "/note.txt",
        body=b"new content", headers={"Content-Type": "text/markdown"},
    )
    assert status == STATUS_NO_CONTENT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""
    info = rfs.get_info("/note.txt")
    assert header(hdrs, "ETag") == info.etag
    assert rfs.read_bytes("/note.txt") == b"new content"
    assert info.content_type == "text/markdown", (
        "PUT overwrite must forward the request Content-Type to write_bytes"
    )
    write_calls = [c for c in rfs.calls if c[0] == "write_bytes"]
    assert ("write_bytes", "/note.txt", b"new content", "text/markdown") in write_calls, (
        f"write_bytes must be called with (path, body, content_type); calls were {write_calls}"
    )


# ===========================================================================
# T36 .. T39 -- DELETE (Req 8)
# ===========================================================================


def test_t036_delete_404_on_missing(server: WebDAVServer):
    """T36: DELETE on nonexistent resource returns 404 Not Found + Content-Length: 0 + empty body."""
    status, hdrs, body = call_wsgi(server, "DELETE", "/nope")
    assert status == STATUS_NOT_FOUND, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t037_delete_returns_204_and_removes_resource(dpb: InMemoryDPB):
    """T37: DELETE on existing resource invokes VFS.delete(path) and returns
    204 No Content + Content-Length: 0 + empty body."""
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    seed_file(rfs, "/file.txt", b"x", "text/plain")
    rfs.calls.clear()
    status, hdrs, body = call_wsgi(s, "DELETE", "/file.txt")
    assert status == STATUS_NO_CONTENT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""
    assert not rfs.exists("/file.txt")
    assert ("delete", "/file.txt") in rfs.calls, (
        f"DELETE must invoke VirtualFileSystem.delete(path); calls were {rfs.calls}"
    )


def test_t038_delete_removes_locks_on_path_and_descendants(
    server: WebDAVServer, fs: InMemoryFS
):
    """T38: DELETE removes active locks anchored at path and all descendant paths."""
    seed_collection(fs, "/dir")
    seed_file(fs, "/dir/child.txt", b"x", "text/plain")

    tok_root = acquire_lock(server, "/dir", depth="0")
    tok_child = acquire_lock(server, "/dir/child.txt", depth="0")

    if_hdr = f"(<{tok_root}>) (<{tok_child}>)"
    status, _, _ = call_wsgi(
        server, "DELETE", "/dir", headers={"If": if_hdr}
    )
    assert status == STATUS_NO_CONTENT, status

    seed_collection(fs, "/dir")
    seed_file(fs, "/dir/child.txt", b"x", "text/plain")

    status, _, body = call_wsgi(
        server, "PROPFIND", "/dir",
        body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    root = _parse_multistatus(body)
    resp = _responses(root)[0]
    sp = _success_props(resp)
    ld = next(p for p in sp if p.tag == DAV + "lockdiscovery")
    assert list(ld) == [], "lockdiscovery should be empty after DELETE"

    status, _, body = call_wsgi(
        server, "PROPFIND", "/dir/child.txt",
        body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
        headers={"Depth": "0"},
    )
    root = _parse_multistatus(body)
    resp = _responses(root)[0]
    sp = _success_props(resp)
    ld = next(p for p in sp if p.tag == DAV + "lockdiscovery")
    assert list(ld) == [], "descendant lockdiscovery should be empty after DELETE"


def test_t039_delete_removes_dead_properties_for_path_and_descendants(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """T39: DELETE removes dead properties at path and all descendants
    via DeadPropertyBackend.list_properties + DeadPropertyBackend.remove_property."""
    seed_collection(fs, "/dir")
    seed_file(fs, "/dir/child.txt", b"x", "text/plain")
    dpb.set_property("/dir", "x:", "n", "<v>r</v>")
    dpb.set_property("/dir/child.txt", "x:", "n", "<v>c</v>")
    dpb.calls.clear()

    status, _, _ = call_wsgi(server, "DELETE", "/dir")
    assert status == STATUS_NO_CONTENT, status

    list_calls = [c for c in dpb.calls if c[0] == "list_properties"]
    list_paths = {c[1] for c in list_calls}
    assert "/dir" in list_paths, (
        f"list_properties must be invoked for the deleted path; calls were {list_calls}"
    )
    assert "/dir/child.txt" in list_paths, (
        f"list_properties must be invoked for every descendant; calls were {list_calls}"
    )

    remove_calls = [c for c in dpb.calls if c[0] == "remove_property"]
    assert ("remove_property", "/dir", "x:", "n") in remove_calls, (
        f"remove_property must be invoked for the deleted path's stored entries; calls were {remove_calls}"
    )
    assert ("remove_property", "/dir/child.txt", "x:", "n") in remove_calls, (
        f"remove_property must be invoked for descendants' stored entries; calls were {remove_calls}"
    )

    assert dpb.list_properties("/dir") == []
    assert dpb.list_properties("/dir/child.txt") == []


# ===========================================================================
# T40 .. T44 -- MKCOL (Req 9)
# ===========================================================================


def test_t040_mkcol_415_on_non_empty_body(server: WebDAVServer):
    """T40: MKCOL with non-empty body returns 415 Unsupported Media Type + Content-Length: 0 + empty body."""
    status, hdrs, body = call_wsgi(server, "MKCOL", "/d", body=b"junk")
    assert status == STATUS_UNSUPPORTED_MEDIA_TYPE, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


@pytest.mark.parametrize("existing_kind", ["collection", "file"])
def test_t041_mkcol_405_when_target_exists(
    server: WebDAVServer, fs: InMemoryFS, existing_kind: str,
):
    """T41: MKCOL when one resource already exists at the path (collection or file) returns 405 (Req 9.2)."""
    if existing_kind == "collection":
        seed_collection(fs, "/d")
    else:
        seed_file(fs, "/d", b"x", "text/plain")
    status, hdrs, body = call_wsgi(server, "MKCOL", "/d")
    assert status == STATUS_METHOD_NOT_ALLOWED, (
        f"MKCOL on existing {existing_kind}: {status!r}"
    )
    assert header(hdrs, "Allow") == ALLOW_ON_EXISTING_FOR_MKCOL
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t042_mkcol_409_when_parent_missing(server: WebDAVServer):
    """T42: MKCOL when parent does not exist returns 409 Conflict + Content-Length: 0 + empty body."""
    status, hdrs, body = call_wsgi(server, "MKCOL", "/nodir/sub")
    assert status == STATUS_CONFLICT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t043_mkcol_409_when_parent_is_file(server: WebDAVServer, fs: InMemoryFS):
    """T43: MKCOL when parent path is a non-collection returns 409 Conflict + Content-Length: 0 + empty body."""
    seed_file(fs, "/parent", b"x", "text/plain")
    status, hdrs, body = call_wsgi(server, "MKCOL", "/parent/sub")
    assert status == STATUS_CONFLICT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t044_mkcol_creates_collection_returns_201(dpb: InMemoryDPB):
    """T44: MKCOL with valid conditions invokes VFS.create_collection(path) and returns
    201 Created + Content-Length: 0 + empty body."""
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    status, hdrs, body = call_wsgi(s, "MKCOL", "/d")
    assert status == STATUS_CREATED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""
    assert rfs.exists("/d")
    assert rfs.get_info("/d").is_collection
    assert ("create_collection", "/d") in rfs.calls, (
        f"MKCOL must invoke VirtualFileSystem.create_collection(path); calls were {rfs.calls}"
    )


# ===========================================================================
# T45 .. T56 -- COPY (Req 10)
# ===========================================================================


def test_t045_copy_400_when_destination_header_missing(
    server: WebDAVServer, fs: InMemoryFS
):
    """T45: COPY without Destination header returns 400 Bad Request + Content-Length: 0 + empty body."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    status, hdrs, body = call_wsgi(server, "COPY", "/src.txt")
    assert status == STATUS_BAD_REQUEST, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t046_copy_404_when_source_missing(server: WebDAVServer):
    """T46: COPY when source does not exist returns 404 Not Found + Content-Length: 0 + empty body."""
    status, hdrs, body = call_wsgi(
        server, "COPY", "/missing.txt",
        headers={"Destination": "http://localhost/dst.txt"},
    )
    assert status == STATUS_NOT_FOUND, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t047_copy_409_when_destination_parent_missing(
    server: WebDAVServer, fs: InMemoryFS
):
    """T47: COPY when destination parent does not exist returns 409 Conflict + Content-Length: 0 + empty body."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "COPY", "/src.txt",
        headers={"Destination": "http://localhost/nodir/dst.txt"},
    )
    assert status == STATUS_CONFLICT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t048_copy_409_when_destination_parent_is_file(
    server: WebDAVServer, fs: InMemoryFS
):
    """T48: COPY when destination parent is non-collection returns 409 Conflict + Content-Length: 0 + empty body."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    seed_file(fs, "/file_parent", b"y", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "COPY", "/src.txt",
        headers={"Destination": "http://localhost/file_parent/dst.txt"},
    )
    assert status == STATUS_CONFLICT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t049_copy_412_when_destination_exists_and_overwrite_false(
    server: WebDAVServer, fs: InMemoryFS
):
    """T49: COPY when destination exists and Overwrite: F returns 412 Precondition Failed + Content-Length: 0 + empty body."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    seed_file(fs, "/dst.txt", b"y", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "COPY", "/src.txt",
        headers={
            "Destination": "http://localhost/dst.txt",
            "Overwrite": "F",
        },
    )
    assert status == STATUS_PRECONDITION_FAILED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t050_copy_overwrite_true_existing_destination_returns_204(dpb: InMemoryDPB):
    """T50: COPY overwriting existing destination removes destination dead props,
    invokes VFS.delete(destination), invokes VFS.copy, calls DPB.copy_properties
    exactly once for the root pair and exactly once per descendant tuple,
    returns 204 No Content + Content-Length: 0 + empty body."""
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    seed_collection(rfs, "/src")
    seed_file(rfs, "/src/a.txt", b"AA", "text/plain")
    seed_collection(rfs, "/dst")
    seed_file(rfs, "/dst/old.txt", b"OLD", "text/plain")

    dpb.set_property("/src", "x:", "tag", "<v>SRC</v>")
    dpb.set_property("/src/a.txt", "x:", "tag", "<v>SRCA</v>")
    dpb.set_property("/dst", "x:", "tag", "<v>DST_PRE</v>")
    dpb.set_property("/dst/old.txt", "x:", "tag", "<v>OLD</v>")
    rfs.calls.clear()
    dpb.calls.clear()

    status, hdrs, body = call_wsgi(
        s, "COPY", "/src",
        headers={
            "Destination": "http://localhost/dst",
            "Overwrite": "T",
            "Depth": "infinity",
        },
    )
    assert status == STATUS_NO_CONTENT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""

    assert rfs.exists("/dst")
    assert rfs.exists("/dst/a.txt")
    assert rfs.read_bytes("/dst/a.txt") == b"AA"
    assert not rfs.exists("/dst/old.txt")

    assert dpb.list_properties("/dst") == [("x:", "tag", "<v>SRC</v>")]
    assert dpb.list_properties("/dst/a.txt") == [("x:", "tag", "<v>SRCA</v>")]
    assert dpb.list_properties("/dst/old.txt") == []

    assert ("delete", "/dst") in rfs.calls, (
        f"COPY overwrite must invoke VirtualFileSystem.delete(destination); calls were {rfs.calls}"
    )
    copy_calls = [c for c in rfs.calls if c[0] == "copy"]
    assert ("copy", "/src", "/dst", True) in copy_calls, (
        f"COPY must invoke VirtualFileSystem.copy(source, destination, True) for Depth: infinity; calls were {copy_calls}"
    )

    cp_calls = [c for c in dpb.calls if c[0] == "copy_properties"]
    assert cp_calls.count(("copy_properties", "/src", "/dst")) == 1, (
        f"copy_properties must be invoked EXACTLY ONCE for the root pair; calls were {cp_calls}"
    )
    assert cp_calls.count(("copy_properties", "/src/a.txt", "/dst/a.txt")) == 1, (
        f"copy_properties must be invoked EXACTLY ONCE per descendant tuple; calls were {cp_calls}"
    )

    list_paths = {c[1] for c in dpb.calls if c[0] == "list_properties"}
    assert "/dst" in list_paths, (
        f"COPY overwrite MUST invoke list_properties on destination path; "
        f"calls were {dpb.calls}"
    )
    assert "/dst/old.txt" in list_paths, (
        f"COPY overwrite MUST invoke list_properties on every destination "
        f"descendant; calls were {dpb.calls}"
    )
    remove_calls = [
        c for c in dpb.calls if c[0] == "remove_property"
    ]
    assert ("remove_property", "/dst", "x:", "tag") in remove_calls, (
        f"COPY overwrite MUST invoke remove_property for each stored "
        f"destination property; calls were {remove_calls}"
    )
    assert ("remove_property", "/dst/old.txt", "x:", "tag") in remove_calls, (
        f"COPY overwrite MUST invoke remove_property for each stored "
        f"destination-descendant property; calls were {remove_calls}"
    )


def test_t051_copy_to_new_destination_returns_201(dpb: InMemoryDPB):
    """T51: COPY when destination does not exist invokes VFS.copy, calls
    DPB.copy_properties EXACTLY ONCE for the root pair and EXACTLY ONCE per
    descendant tuple, returns 201 Created + Content-Length: 0 + empty body."""
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    seed_collection(rfs, "/src")
    seed_file(rfs, "/src/a.txt", b"A", "text/plain")
    dpb.set_property("/src", "x:", "tag", "<v>R</v>")
    dpb.set_property("/src/a.txt", "x:", "tag", "<v>D</v>")
    rfs.calls.clear()
    dpb.calls.clear()

    status, hdrs, body = call_wsgi(
        s, "COPY", "/src",
        headers={
            "Destination": "http://localhost/dst",
            "Depth": "infinity",
        },
    )
    assert status == STATUS_CREATED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""

    assert rfs.exists("/dst")
    assert rfs.exists("/dst/a.txt")
    assert dpb.list_properties("/dst") == [("x:", "tag", "<v>R</v>")]
    assert dpb.list_properties("/dst/a.txt") == [("x:", "tag", "<v>D</v>")]

    copy_calls = [c for c in rfs.calls if c[0] == "copy"]
    assert ("copy", "/src", "/dst", True) in copy_calls, (
        f"COPY Depth: infinity must invoke VirtualFileSystem.copy(source, dest, True); calls were {copy_calls}"
    )

    cp_calls = [c for c in dpb.calls if c[0] == "copy_properties"]
    assert cp_calls.count(("copy_properties", "/src", "/dst")) == 1, (
        f"copy_properties must be invoked EXACTLY ONCE for the root pair; calls were {cp_calls}"
    )
    assert cp_calls.count(("copy_properties", "/src/a.txt", "/dst/a.txt")) == 1, (
        f"copy_properties must be invoked EXACTLY ONCE per descendant tuple; calls were {cp_calls}"
    )


def test_t052_copy_destination_decoded_with_urlsplit_and_unquote(
    server: WebDAVServer, fs: InMemoryFS
):
    """T52: COPY parses Destination via urlsplit then unquote on the path component."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    status, _, _ = call_wsgi(
        server, "COPY", "/src.txt",
        headers={"Destination": "http://localhost/dst%20file.txt"},
    )
    assert status in (STATUS_CREATED, STATUS_NO_CONTENT), status
    assert fs.exists("/dst file.txt")
    assert not fs.exists("/dst%20file.txt")


def test_t053_copy_overwrite_header_resolution(
    server: WebDAVServer, fs: InMemoryFS
):
    """T53: COPY Overwrite header: T -> True, F -> False, absent -> True."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    seed_file(fs, "/dst.txt", b"y", "text/plain")

    status, _, _ = call_wsgi(
        server, "COPY", "/src.txt",
        headers={
            "Destination": "http://localhost/dst.txt",
            "Overwrite": "T",
        },
    )
    assert status == STATUS_NO_CONTENT, status

    fs.write_bytes("/dst.txt", b"y", "text/plain")
    status, _, _ = call_wsgi(
        server, "COPY", "/src.txt",
        headers={
            "Destination": "http://localhost/dst.txt",
            "Overwrite": "F",
        },
    )
    assert status == STATUS_PRECONDITION_FAILED, status

    fs.write_bytes("/dst.txt", b"y", "text/plain")
    status, _, _ = call_wsgi(
        server, "COPY", "/src.txt",
        headers={"Destination": "http://localhost/dst.txt"},
    )
    assert status == STATUS_NO_CONTENT, (
        f"absent Overwrite header must resolve to True; got {status!r}"
    )


def test_t054_copy_depth_header_resolution(
    server: WebDAVServer, fs: InMemoryFS
):
    """T54: COPY Depth header: 0 -> shallow, infinity -> deep, absent -> infinity."""
    def _setup() -> None:
        for p in ("/src", "/src/inner.txt", "/dst"):
            if fs.exists(p):
                fs.delete(p)
        seed_collection(fs, "/src")
        seed_file(fs, "/src/inner.txt", b"X", "text/plain")

    _setup()
    call_wsgi(
        server, "COPY", "/src",
        headers={
            "Destination": "http://localhost/dst",
            "Depth": "0",
        },
    )
    assert fs.exists("/dst") and not fs.exists("/dst/inner.txt"), (
        "Depth: 0 must produce empty collection"
    )

    fs.delete("/dst")
    call_wsgi(
        server, "COPY", "/src",
        headers={
            "Destination": "http://localhost/dst",
            "Depth": "infinity",
        },
    )
    assert fs.exists("/dst/inner.txt"), "Depth: infinity must copy descendants"

    fs.delete("/dst")
    call_wsgi(
        server, "COPY", "/src",
        headers={"Destination": "http://localhost/dst"},
    )
    assert fs.exists("/dst/inner.txt"), (
        "absent Depth header must resolve to infinity"
    )


def test_t055_copy_depth_zero_on_collection_yields_empty_collection(dpb: InMemoryDPB):
    """T55: COPY Depth: 0 on a collection invokes VFS.copy(source, dest, False)
    creating empty destination collection."""
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    seed_collection(rfs, "/src")
    seed_file(rfs, "/src/a.txt", b"A", "text/plain")
    seed_file(rfs, "/src/b.txt", b"B", "text/plain")
    rfs.calls.clear()

    status, _, _ = call_wsgi(
        s, "COPY", "/src",
        headers={
            "Destination": "http://localhost/dst",
            "Depth": "0",
        },
    )
    assert status == STATUS_CREATED, status
    assert rfs.exists("/dst")
    assert rfs.list_children("/dst") == []
    copy_calls = [c for c in rfs.calls if c[0] == "copy"]
    assert ("copy", "/src", "/dst", False) in copy_calls, (
        f"COPY Depth: 0 must invoke VirtualFileSystem.copy(source, dest, False); calls were {copy_calls}"
    )


def test_t056_copy_depth_infinity_copies_descendant_dead_properties(dpb: InMemoryDPB):
    """T56: COPY Depth: infinity on collection invokes VFS.copy(source, dest, True)
    AND copies descendant dead properties (one DPB.copy_properties per descendant pair)."""
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    seed_collection(rfs, "/src")
    seed_file(rfs, "/src/a.txt", b"A", "text/plain")
    dpb.set_property("/src/a.txt", "x:", "tag", "<v>VAL</v>")
    rfs.calls.clear()
    dpb.calls.clear()

    status, _, _ = call_wsgi(
        s, "COPY", "/src",
        headers={
            "Destination": "http://localhost/dst",
            "Depth": "infinity",
        },
    )
    assert status == STATUS_CREATED, status
    assert dpb.list_properties("/dst/a.txt") == [("x:", "tag", "<v>VAL</v>")]
    copy_calls = [c for c in rfs.calls if c[0] == "copy"]
    assert ("copy", "/src", "/dst", True) in copy_calls, (
        f"COPY Depth: infinity must invoke VirtualFileSystem.copy(source, dest, True); calls were {copy_calls}"
    )
    cp_calls = [c for c in dpb.calls if c[0] == "copy_properties"]
    assert ("copy_properties", "/src/a.txt", "/dst/a.txt") in cp_calls, (
        f"COPY Depth: infinity must invoke copy_properties for each descendant; calls were {cp_calls}"
    )


# ===========================================================================
# T57 .. T64 -- MOVE (Req 11)
# ===========================================================================


def test_t057_move_400_when_destination_header_missing(
    server: WebDAVServer, fs: InMemoryFS
):
    """T57: MOVE without Destination header returns 400 Bad Request + Content-Length: 0 + empty body."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    status, hdrs, body = call_wsgi(server, "MOVE", "/src.txt")
    assert status == STATUS_BAD_REQUEST, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t058_move_404_when_source_missing(server: WebDAVServer):
    """T58: MOVE when source does not exist returns 404 Not Found + Content-Length: 0 + empty body."""
    status, hdrs, body = call_wsgi(
        server, "MOVE", "/nope",
        headers={"Destination": "http://localhost/dst"},
    )
    assert status == STATUS_NOT_FOUND, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t059_move_409_when_destination_parent_missing(
    server: WebDAVServer, fs: InMemoryFS
):
    """T59: MOVE when destination parent does not exist returns 409 Conflict + Content-Length: 0 + empty body."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "MOVE", "/src.txt",
        headers={"Destination": "http://localhost/nodir/dst.txt"},
    )
    assert status == STATUS_CONFLICT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t060_move_409_when_destination_parent_is_file(
    server: WebDAVServer, fs: InMemoryFS
):
    """T60: MOVE when destination parent is non-collection returns 409 Conflict + Content-Length: 0 + empty body."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    seed_file(fs, "/parent", b"y", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "MOVE", "/src.txt",
        headers={"Destination": "http://localhost/parent/dst.txt"},
    )
    assert status == STATUS_CONFLICT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t061_move_412_when_destination_exists_and_overwrite_false(
    server: WebDAVServer, fs: InMemoryFS
):
    """T61: MOVE when destination exists and Overwrite: F returns 412 Precondition Failed + Content-Length: 0 + empty body."""
    seed_file(fs, "/src.txt", b"x", "text/plain")
    seed_file(fs, "/dst.txt", b"y", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "MOVE", "/src.txt",
        headers={
            "Destination": "http://localhost/dst.txt",
            "Overwrite": "F",
        },
    )
    assert status == STATUS_PRECONDITION_FAILED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t062_move_overwrite_true_existing_destination_returns_204(dpb: InMemoryDPB):
    """T62: MOVE with overwrite to existing dest removes locks on src+descendants,
    removes dead props on dst+descendants, invokes VFS.delete(destination),
    invokes VFS.move(source, destination), invokes DPB.move_properties EXACTLY
    ONCE for root pair and EXACTLY ONCE per descendant tuple, returns
    204 No Content + Content-Length: 0 + empty body.
    """
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    seed_collection(rfs, "/src")
    seed_file(rfs, "/src/a.txt", b"AA", "text/plain")
    seed_collection(rfs, "/dst")
    seed_file(rfs, "/dst/old.txt", b"OLD", "text/plain")

    dpb.set_property("/src", "x:", "tag", "<v>R</v>")
    dpb.set_property("/src/a.txt", "x:", "tag", "<v>D</v>")
    dpb.set_property("/dst", "x:", "tag", "<v>OLD_R</v>")
    dpb.set_property("/dst/old.txt", "x:", "tag", "<v>OLD_D</v>")

    tok_src = acquire_lock(s, "/src", scope="exclusive", depth="0")
    tok_descendant = acquire_lock(
        s, "/src/a.txt", scope="exclusive", depth="0"
    )

    rfs.calls.clear()
    dpb.calls.clear()

    if_hdr = f"(<{tok_src}>) (<{tok_descendant}>)"
    status, hdrs, body = call_wsgi(
        s, "MOVE", "/src",
        headers={
            "Destination": "http://localhost/dst",
            "Overwrite": "T",
            "If": if_hdr,
        },
    )
    assert status == STATUS_NO_CONTENT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""

    assert not rfs.exists("/src")
    assert not rfs.exists("/src/a.txt")
    assert rfs.exists("/dst/a.txt")
    assert dpb.list_properties("/dst") == [("x:", "tag", "<v>R</v>")]
    assert dpb.list_properties("/dst/a.txt") == [("x:", "tag", "<v>D</v>")]
    assert dpb.list_properties("/src") == []
    assert dpb.list_properties("/src/a.txt") == []
    assert dpb.list_properties("/dst/old.txt") == []

    assert ("delete", "/dst") in rfs.calls, (
        f"MOVE overwrite must invoke VirtualFileSystem.delete(destination); calls were {rfs.calls}"
    )
    assert ("move", "/src", "/dst") in rfs.calls, (
        f"MOVE must invoke VirtualFileSystem.move(source, destination); calls were {rfs.calls}"
    )

    mv_calls = [c for c in dpb.calls if c[0] == "move_properties"]
    assert mv_calls.count(("move_properties", "/src", "/dst")) == 1, (
        f"move_properties must be invoked EXACTLY ONCE for the root pair; calls were {mv_calls}"
    )
    assert mv_calls.count(("move_properties", "/src/a.txt", "/dst/a.txt")) == 1, (
        f"move_properties must be invoked EXACTLY ONCE per descendant tuple; calls were {mv_calls}"
    )

    list_paths = {c[1] for c in dpb.calls if c[0] == "list_properties"}
    assert "/dst" in list_paths, (
        f"MOVE overwrite MUST invoke list_properties on destination path; "
        f"calls were {dpb.calls}"
    )
    assert "/dst/old.txt" in list_paths, (
        f"MOVE overwrite MUST invoke list_properties on every destination "
        f"descendant; calls were {dpb.calls}"
    )
    remove_calls = [c for c in dpb.calls if c[0] == "remove_property"]
    assert ("remove_property", "/dst", "x:", "tag") in remove_calls, (
        f"MOVE overwrite MUST invoke remove_property for each stored "
        f"destination property; calls were {remove_calls}"
    )
    assert ("remove_property", "/dst/old.txt", "x:", "tag") in remove_calls, (
        f"MOVE overwrite MUST invoke remove_property for each stored "
        f"destination-descendant property; calls were {remove_calls}"
    )

    status, _, _ = call_wsgi(s, "MKCOL", "/src")
    assert status == STATUS_CREATED, (
        f"MOVE must remove the lock anchored at the source path (no orphan); "
        f"got {status!r} on subsequent MKCOL /src"
    )
    status, _, _ = call_wsgi(
        s, "PUT", "/src/a.txt",
        body=b"unblocked",
        headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_CREATED, (
        f"MOVE must remove EVERY lock anchored at every source descendant "
        f"(no orphan); got {status!r} on subsequent PUT /src/a.txt — the "
        f"depth-0 lock previously anchored AT /src/a.txt was not removed"
    )


def test_t063_move_to_new_destination_returns_201(dpb: InMemoryDPB):
    """T63: MOVE to new destination removes locks anchored at source+descendants,
    invokes VFS.move, invokes DPB.move_properties EXACTLY ONCE for root pair and
    EXACTLY ONCE per descendant tuple, returns 201 Created + Content-Length: 0
    + empty body.
    """
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    seed_collection(rfs, "/src")
    seed_file(rfs, "/src/a.txt", b"A", "text/plain")
    dpb.set_property("/src", "x:", "tag", "<v>R</v>")
    dpb.set_property("/src/a.txt", "x:", "tag", "<v>D</v>")

    tok_src = acquire_lock(s, "/src", scope="exclusive", depth="0")
    tok_descendant = acquire_lock(
        s, "/src/a.txt", scope="exclusive", depth="0"
    )

    rfs.calls.clear()
    dpb.calls.clear()

    if_hdr = f"(<{tok_src}>) (<{tok_descendant}>)"
    status, hdrs, body = call_wsgi(
        s, "MOVE", "/src",
        headers={"Destination": "http://localhost/dst", "If": if_hdr},
    )
    assert status == STATUS_CREATED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""
    assert not rfs.exists("/src")
    assert rfs.exists("/dst/a.txt")
    assert dpb.list_properties("/dst") == [("x:", "tag", "<v>R</v>")]
    assert dpb.list_properties("/dst/a.txt") == [("x:", "tag", "<v>D</v>")]
    assert dpb.list_properties("/src") == []
    assert dpb.list_properties("/src/a.txt") == []

    assert ("move", "/src", "/dst") in rfs.calls, (
        f"MOVE must invoke VirtualFileSystem.move(source, destination); calls were {rfs.calls}"
    )

    mv_calls = [c for c in dpb.calls if c[0] == "move_properties"]
    assert mv_calls.count(("move_properties", "/src", "/dst")) == 1, (
        f"move_properties must be invoked EXACTLY ONCE for the root pair; calls were {mv_calls}"
    )
    assert mv_calls.count(("move_properties", "/src/a.txt", "/dst/a.txt")) == 1, (
        f"move_properties must be invoked EXACTLY ONCE per descendant tuple; calls were {mv_calls}"
    )

    status, _, _ = call_wsgi(s, "MKCOL", "/src")
    assert status == STATUS_CREATED, (
        f"MOVE must remove the lock anchored at the source path (no orphan); "
        f"got {status!r} on subsequent MKCOL /src"
    )
    status, _, _ = call_wsgi(
        s, "PUT", "/src/a.txt",
        body=b"unblocked",
        headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_CREATED, (
        f"MOVE must remove EVERY lock anchored at every source descendant "
        f"(no orphan); got {status!r} on subsequent PUT /src/a.txt — the "
        f"depth-0 lock previously anchored AT /src/a.txt was not removed"
    )


def test_t06x_move_destination_decoded_with_urlsplit_and_unquote(
    server: WebDAVServer, fs: InMemoryFS
):
    """MOVE parses Destination via urlsplit then unquote on the path component
    (Req 11, line 126). Direct symmetric of T52 for COPY: an implementation
    that forgets to apply ``urllib.parse.unquote`` to the destination path
    would create the resource at the literal ``/dst%20file.txt`` rather than
    at ``/dst file.txt``.
    """
    seed_file(fs, "/src.txt", b"x", "text/plain")
    status, _, _ = call_wsgi(
        server, "MOVE", "/src.txt",
        headers={"Destination": "http://localhost/dst%20file.txt"},
    )
    assert status in (STATUS_CREATED, STATUS_NO_CONTENT), status
    assert fs.exists("/dst file.txt"), (
        "MOVE destination path component must be decoded through "
        "urllib.parse.unquote (Req 11)"
    )
    assert not fs.exists("/dst%20file.txt"), (
        "MOVE must not create the resource at the percent-encoded literal path"
    )
    assert not fs.exists("/src.txt"), (
        "MOVE source must be removed after a successful move"
    )


@pytest.mark.parametrize(
    "method,with_destination",
    [
        ("PUT", False),
        ("MKCOL", False),
        ("COPY", True),
        ("MOVE", True),
    ],
)
def test_t06y_parent_path_rule_generalizes_to_deeper_paths(
    fs: InMemoryFS, dpb: InMemoryDPB, method: str, with_destination: bool
):
    """Parent-path computation MUST generalize beyond depth 2: per the prompt
    (Req 1, line 34) "The parent path of /x is /. The parent path of /a/b/c is
    /a/b." Existing parent-aware tests (T032, T033, T042, T043, T047, T048,
    T059, T060) only exercise one-level parents, so an implementation that
    hardcoded depth-2 splitting (e.g., ``path.split('/', 2)``) would slip
    through. Here we install a non-collection at /a/b and verify that the
    request-path /a/b/c (whose parent is /a/b) is rejected with 409 by every
    handler that consults the parent path of its target.
    """
    server = WebDAVServer(fs, dpb)
    seed_collection(fs, "/a")
    seed_file(fs, "/a/b", b"x", "text/plain")
    if with_destination:
        seed_file(fs, "/src.txt", b"x", "text/plain")
        request_path = "/src.txt"
        headers = {"Destination": "http://localhost/a/b/c"}
        body = b""
    else:
        request_path = "/a/b/c"
        headers = (
            {"Content-Type": "text/plain"} if method == "PUT" else None
        )
        body = b"data" if method == "PUT" else b""
    status, hdrs, response_body = call_wsgi(
        server, method, request_path, body=body, headers=headers,
    )
    assert status == STATUS_CONFLICT, (
        f"{method} targeting a path whose parent (/a/b) is a non-collection "
        f"resource MUST return 409 Conflict regardless of nesting depth; got "
        f"{status!r}"
    )
    assert header(hdrs, "Content-Length") == "0"
    assert response_body == b""

    fs.delete("/a/b")
    if with_destination:
        request_path = "/src.txt"
        headers = {"Destination": "http://localhost/a/b/c"}
    else:
        request_path = "/a/b/c"
    status, hdrs, response_body = call_wsgi(
        server, method, request_path, body=body, headers=headers,
    )
    assert status == STATUS_CONFLICT, (
        f"{method} targeting a path whose parent (/a/b) does not exist MUST "
        f"return 409 Conflict regardless of nesting depth; got {status!r}"
    )
    assert header(hdrs, "Content-Length") == "0"
    assert response_body == b""


def test_t064_move_descendant_pair_set_computed_before_move(dpb: InMemoryDPB):
    """T64: MOVE computes the source descendant pair set BEFORE invoking
    VirtualFileSystem.move.

    Verified directly by inspecting the recorded order of calls on the VFS
    backend: every list_children invocation against /src or /src/sub MUST
    appear before the move() invocation on /src. If the implementation
    enumerated descendants AFTER move, the source paths would no longer
    exist and either no list_children calls would precede move() or those
    calls would happen against the destination tree.
    """
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    seed_collection(rfs, "/src")
    seed_collection(rfs, "/src/sub")
    seed_file(rfs, "/src/sub/leaf.txt", b"L", "text/plain")
    dpb.set_property("/src/sub", "x:", "n", "<v>S</v>")
    dpb.set_property("/src/sub/leaf.txt", "x:", "n", "<v>L</v>")
    rfs.calls.clear()

    status, _, _ = call_wsgi(
        s, "MOVE", "/src",
        headers={"Destination": "http://localhost/dst"},
    )
    assert status == STATUS_CREATED, status
    assert dpb.list_properties("/dst/sub") == [("x:", "n", "<v>S</v>")]
    assert dpb.list_properties("/dst/sub/leaf.txt") == [("x:", "n", "<v>L</v>")]

    move_idx = next(
        i for i, c in enumerate(rfs.calls) if c[0] == "move" and c[1] == "/src"
    )
    src_enum_indices = [
        i for i, c in enumerate(rfs.calls)
        if c[0] == "list_children" and (c[1] == "/src" or c[1].startswith("/src/"))
    ]
    assert src_enum_indices, (
        "MOVE on a collection must enumerate source descendants via list_children "
        "before calling move()"
    )
    assert max(src_enum_indices) < move_idx, (
        f"Source descendant pair set MUST be computed BEFORE VirtualFileSystem.move; "
        f"observed list_children indices {src_enum_indices} vs move at {move_idx}; "
        f"calls were {rfs.calls}"
    )


# ===========================================================================
# T65 .. T71 -- PROPFIND request handling (Req 12)
# ===========================================================================


def test_t065_propfind_404_on_missing(server: WebDAVServer):
    """T65: PROPFIND on nonexistent resource returns 404 Not Found + Content-Length: 0 + empty body."""
    status, hdrs, body = call_wsgi(
        server, "PROPFIND", "/missing",
        body=_xml_propfind_allprop(),
        headers={"Depth": "0"},
    )
    assert status == STATUS_NOT_FOUND, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t066_propfind_depth_header_resolution(
    server: WebDAVServer, fs: InMemoryFS
):
    """T66: PROPFIND Depth: 0 -> 1 entry, 1 -> 1+children, infinity -> all,
    absent -> infinity."""
    seed_collection(fs, "/c")
    seed_collection(fs, "/c/a")
    seed_file(fs, "/c/a/leaf", b"X", "text/plain")
    seed_file(fs, "/c/top.txt", b"T", "text/plain")

    def _count(depth_header: dict[str, str]) -> int:
        st, _, body = call_wsgi(
            server, "PROPFIND", "/c",
            body=_xml_propfind_allprop(),
            headers=depth_header,
        )
        assert st == STATUS_MULTI_STATUS, st
        return len(_responses(_parse_multistatus(body)))

    assert _count({"Depth": "0"}) == 1
    assert _count({"Depth": "1"}) == 1 + 2
    assert _count({"Depth": "infinity"}) == 1 + 2 + 1
    assert _count({}) == 1 + 2 + 1, "absent Depth must resolve to infinity"


def test_t067_propfind_returns_207_with_xml_content_type(
    server: WebDAVServer, fs: InMemoryFS
):
    """T67: PROPFIND returns 207 Multi-Status with Content-Type: application/xml; charset=utf-8."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_allprop(),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    assert header(hdrs, "Content-Type") == "application/xml; charset=utf-8"
    _parse_multistatus(body)


def test_t068_propfind_depth_zero_on_collection_returns_one_response(
    server: WebDAVServer, fs: InMemoryFS
):
    """T68: PROPFIND Depth: 0 on a collection returns one response for itself only."""
    seed_collection(fs, "/c")
    seed_file(fs, "/c/a.txt", b"A", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/c",
        body=_xml_propfind_allprop(),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resps = _responses(_parse_multistatus(body))
    assert len(resps) == 1
    assert urllib.parse.unquote(_href(resps[0])) == "/c"


def test_t069_propfind_depth_one_on_collection_returns_self_plus_children(
    server: WebDAVServer, fs: InMemoryFS
):
    """T69: PROPFIND Depth: 1 on collection returns self + each immediate child."""
    seed_collection(fs, "/c")
    seed_file(fs, "/c/a.txt", b"A", "text/plain")
    seed_collection(fs, "/c/sub")
    seed_file(fs, "/c/sub/deep.txt", b"D", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/c",
        body=_xml_propfind_allprop(),
        headers={"Depth": "1"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resps = _responses(_parse_multistatus(body))
    hrefs = {urllib.parse.unquote(_href(r)) for r in resps}
    assert hrefs == {"/c", "/c/a.txt", "/c/sub"}, (
        f"Depth: 1 must list self + immediate children only; got {hrefs}"
    )


def test_t070_propfind_depth_infinity_on_collection_returns_all_descendants(
    server: WebDAVServer, fs: InMemoryFS
):
    """T70: PROPFIND Depth: infinity on collection returns self + all descendants."""
    seed_collection(fs, "/c")
    seed_file(fs, "/c/a.txt", b"A", "text/plain")
    seed_collection(fs, "/c/sub")
    seed_file(fs, "/c/sub/deep.txt", b"D", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/c",
        body=_xml_propfind_allprop(),
        headers={"Depth": "infinity"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resps = _responses(_parse_multistatus(body))
    hrefs = {urllib.parse.unquote(_href(r)) for r in resps}
    assert hrefs == {"/c", "/c/a.txt", "/c/sub", "/c/sub/deep.txt"}


def _prop_text(prop: ET.Element) -> str:
    """Serialize the inner XML content of a property element to a string."""
    return (
        (prop.text or "")
        + "".join(ET.tostring(child, encoding="unicode") for child in prop)
    )


def test_t071_propfind_empty_body_treated_as_allprop(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """T71: PROPFIND with empty body is treated as {DAV:}allprop (same tag set
    AND same per-tag values as an explicit allprop request)."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    dpb.set_property("/x.txt", "u:", "extra", "<v>SAME</v>")

    status, _, body_empty = call_wsgi(
        server, "PROPFIND", "/x.txt", body=b"", headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    status, _, body_all = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_allprop(),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status

    sp_empty = _success_props(_responses(_parse_multistatus(body_empty))[0])
    sp_all = _success_props(_responses(_parse_multistatus(body_all))[0])
    assert {p.tag for p in sp_empty} == {p.tag for p in sp_all}
    by_tag_empty = {p.tag: _prop_text(p) for p in sp_empty}
    by_tag_all = {p.tag: _prop_text(p) for p in sp_all}
    assert by_tag_empty == by_tag_all, (
        "empty PROPFIND body and explicit allprop must produce identical values"
    )


def _parse_owner_inner_xml(inner: str) -> ET.Element:
    """Parse owner inner XML for semantic comparison (Req 13 / T86)."""
    return ET.fromstring(f'<wrap xmlns:D="DAV:">{inner}</wrap>')


def _normalize_el_tree(el: ET.Element) -> tuple:
    """Structural normalizer for XML subtree comparison."""
    return (
        el.tag,
        tuple(sorted(el.attrib.items())),
        (el.text or "").strip(),
        tuple(_normalize_el_tree(c) for c in el),
        (el.tail or "").strip(),
    )


def _assert_supportedlock_req13_shape(sl: ET.Element) -> None:
    """Assert {DAV:}supportedlock matches Req 13 (same checks as T85)."""
    entries = sl.findall(DAV + "lockentry")
    assert len(entries) == 2, (
        f"supportedlock must carry exactly two lockentry children; got {len(entries)}"
    )
    scopes: list[str] = []
    types: list[str] = []
    scope_inner_els: list[ET.Element] = []
    type_inner_els: list[ET.Element] = []
    for e in entries:
        scope_el = e.find(DAV + "lockscope")
        type_el = e.find(DAV + "locktype")
        assert scope_el is not None and type_el is not None
        scope_kids = list(scope_el)
        type_kids = list(type_el)
        assert len(scope_kids) == 1
        assert len(type_kids) == 1
        scopes.append(scope_kids[0].tag)
        types.append(type_kids[0].tag)
        scope_inner_els.append(scope_kids[0])
        type_inner_els.append(type_kids[0])
    assert scopes == [DAV + "exclusive", DAV + "shared"], (
        f"supportedlock entries MUST be in document order exclusive then shared; got {scopes}"
    )
    assert types == [DAV + "write", DAV + "write"]
    for el in scope_inner_els + type_inner_els:
        assert list(el) == [], (
            f"{el.tag} MUST be an empty element (no nested children); "
            f"got {[c.tag for c in el]}"
        )
        assert (el.text or "").strip() == "", (
            f"{el.tag} MUST be an empty element (no text content); "
            f"got {el.text!r}"
        )


def _assert_activelock_complete_req13(
    al: ET.Element,
    *,
    token: str,
    scope: str,
    depth_text: str,
    owner_xml_inner: str,
    target_path: str,
    requested_timeout_s: int,
    timeout_slack: int = 30,
) -> None:
    """Assert one {DAV:}activelock has every child required by Req 13 (cf. T86)."""
    lt = al.find(DAV + "locktype")
    assert lt is not None and lt.find(DAV + "write") is not None
    write_el = lt.find(DAV + "write")
    assert write_el is not None
    assert list(write_el) == [], "{DAV:}write must be an empty element"
    assert (write_el.text or "").strip() == "", "{DAV:}write must be empty"

    ls = al.find(DAV + "lockscope")
    assert ls is not None
    expected_scope_tag = DAV + scope
    scope_kids = list(ls)
    assert len(scope_kids) == 1, (
        f"lockscope must wrap exactly one scope element; got {len(scope_kids)}"
    )
    assert scope_kids[0].tag == expected_scope_tag, (
        f"lockscope child MUST be {expected_scope_tag} for {scope!r} lock; "
        f"got {scope_kids[0].tag}"
    )
    assert list(scope_kids[0]) == [], (
        f"{expected_scope_tag} must be an empty element"
    )
    assert (scope_kids[0].text or "").strip() == "", (
        f"{expected_scope_tag} must have no text"
    )

    dp = al.find(DAV + "depth")
    assert dp is not None
    assert (dp.text or "").strip() == depth_text, (
        f"{{DAV:}}depth text MUST be {depth_text!r}; got {(dp.text or '').strip()!r}"
    )

    own = al.find(DAV + "owner")
    assert own is not None
    owner_inner = _prop_text(own).strip()
    expected_owner_tree = _normalize_el_tree(_parse_owner_inner_xml(owner_xml_inner))
    actual_owner_tree = _normalize_el_tree(_parse_owner_inner_xml(owner_inner))
    assert actual_owner_tree == expected_owner_tree, (
        f"owner element MUST carry the VERBATIM XML inner content "
        f"supplied at LOCK time (Req 13). Expected structure "
        f"{expected_owner_tree!r}, got {actual_owner_tree!r}; raw owner "
        f"inner was {owner_inner!r}"
    )

    to = al.find(DAV + "timeout")
    assert to is not None
    timeout_text = (to.text or "").strip()
    m = re.fullmatch(r"Second-(\d+)", timeout_text)
    assert m, f"timeout element must be 'Second-<int>'; got {timeout_text!r}"
    remaining = int(m.group(1))
    assert 0 <= remaining <= requested_timeout_s, (
        f"timeout numeric value {remaining} must be in [0, {requested_timeout_s}]"
    )
    assert remaining >= requested_timeout_s - timeout_slack, (
        f"timeout numeric value {remaining} must be close to the requested "
        f"{requested_timeout_s}s window (allowing <={timeout_slack}s clock drift)"
    )

    lt2 = al.find(DAV + "locktoken")
    assert lt2 is not None
    href_el = lt2.find(DAV + "href")
    assert href_el is not None
    assert (href_el.text or "") == token

    lr = al.find(DAV + "lockroot")
    assert lr is not None
    href_el = lr.find(DAV + "href")
    assert href_el is not None
    assert (href_el.text or "") == urllib.parse.quote(target_path)
    assert urllib.parse.unquote(href_el.text or "") == target_path


# ===========================================================================
# T72 .. T87 -- PROPFIND response body and live properties (Req 13)
# ===========================================================================


LIVE_PROPS = (
    "creationdate", "displayname", "getcontentlength", "getcontenttype",
    "getetag", "getlastmodified", "lockdiscovery", "resourcetype",
    "supportedlock",
)


def test_t072_allprop_returns_all_nine_live_plus_dead_in_success(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """T72: allprop returns all 9 live props + all dead props (with their stored
    XML values) in the 200 OK propstat."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    dpb.set_property("/x.txt", "u:", "extra", "<v>VAL</v>")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_allprop(),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    success = _success_props(resp)
    tags = {p.tag for p in success}
    for live in LIVE_PROPS:
        assert (DAV + live) in tags, f"missing live property {live}"
    dead = next((p for p in success if p.tag == "{u:}extra"), None)
    assert dead is not None, "dead property missing from allprop success"
    assert _prop_text(dead) == "<v>VAL</v>", (
        f"allprop dead property must carry the stored XML value; got {_prop_text(dead)!r}"
    )


def test_t073_propname_returns_empty_elements_for_all_live_plus_dead(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """T73: propname returns empty elements for all 9 live + dead names in 200 OK."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    dpb.set_property("/x.txt", "u:", "extra", "<v>1</v>")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_propname(),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    success = _success_props(resp)
    tags = {p.tag for p in success}
    for live in LIVE_PROPS:
        assert (DAV + live) in tags, f"missing live property name {live}"
    assert "{u:}extra" in tags
    for p in success:
        assert list(p) == [], f"propname response element {p.tag} must be empty"
        assert (p.text or "").strip() == "", (
            f"propname response element {p.tag} must have no text"
        )


@pytest.mark.parametrize("live_name", list(LIVE_PROPS))
def test_t074_prop_known_live_property_in_success(
    server: WebDAVServer, fs: InMemoryFS, live_name: str
):
    """T74: prop with each known DAV live property classifies into 200 OK with the computed value (Req 13)."""
    content = b"hi"
    seed_file(fs, "/x.txt", content, "text/plain")
    info = fs.get_info("/x.txt")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, live_name)]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    success = _success_props(resp)
    prop = next((p for p in success if p.tag == DAV + live_name), None)
    assert prop is not None, (
        f"live property {live_name} must classify into 200 OK propstat"
    )
    if live_name == "creationdate":
        assert (prop.text or "") == info.created_at.strftime("%Y-%m-%dT%H:%M:%SZ")
    elif live_name == "displayname":
        assert (prop.text or "") == info.display_name
    elif live_name == "getcontentlength":
        assert (prop.text or "") == str(len(content))
    elif live_name == "getcontenttype":
        assert (prop.text or "") == "text/plain"
    elif live_name == "getetag":
        assert (prop.text or "") == info.etag
    elif live_name == "getlastmodified":
        expected = email.utils.format_datetime(info.modified_at, usegmt=True)
        assert (prop.text or "") == expected
    elif live_name == "lockdiscovery":
        assert prop.findall(DAV + "activelock") == [], (
            "unlocked resource must have empty lockdiscovery"
        )
    elif live_name == "resourcetype":
        assert list(prop) == [], (
            f"non-collection resourcetype must have no child elements; got {[c.tag for c in prop]}"
        )
        assert (prop.text or "").strip() == "", (
            f"non-collection resourcetype must have no text; got {prop.text!r}"
        )
    elif live_name == "supportedlock":
        _assert_supportedlock_req13_shape(prop)
    else: 
        raise AssertionError(f"unhandled live property {live_name!r}")


def test_t075_prop_unknown_dav_property_in_404(
    server: WebDAVServer, fs: InMemoryFS
):
    """T75: prop with an unknown DAV: name (and absent dead) goes to 404 propstat."""
    seed_file(fs, "/x.txt", b"hi", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, "unknown_prop")]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    absent = _absent_props(resp)
    assert any(p.tag == DAV + "unknown_prop" for p in absent), (
        "unknown DAV: property must classify into 404 group"
    )


def test_t076_prop_custom_dead_property_present_in_success(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """T76: prop with a custom-namespace dead property present goes to 200 propstat
    and the returned dead property element carries the stored XML value."""
    seed_file(fs, "/x.txt", b"hi", "text/plain")
    dpb.set_property("/x.txt", "u:", "tag", "<v>VAL</v>")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([("u:", "tag")]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    success = _success_props(resp)
    dead = next((p for p in success if p.tag == "{u:}tag"), None)
    assert dead is not None, "present dead property must classify into 200 OK propstat"
    assert _prop_text(dead) == "<v>VAL</v>", (
        f"present dead property must carry the stored XML value; got {_prop_text(dead)!r}"
    )


def test_t077_prop_custom_dead_property_absent_in_404(
    server: WebDAVServer, fs: InMemoryFS
):
    """T77: prop with a custom-namespace dead property absent goes to 404 propstat."""
    seed_file(fs, "/x.txt", b"hi", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([("u:", "tag")]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    absent = _absent_props(resp)
    assert any(p.tag == "{u:}tag" for p in absent)


def test_t078_creationdate_format(server: WebDAVServer, fs: InMemoryFS):
    """T78: {DAV:}creationdate is created_at formatted as %Y-%m-%dT%H:%M:%SZ."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    info = fs.get_info("/x.txt")
    expected = info.created_at.strftime("%Y-%m-%dT%H:%M:%SZ")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, "creationdate")]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    sp = _success_props(resp)
    cd = next(p for p in sp if p.tag == DAV + "creationdate")
    assert (cd.text or "") == expected


def test_t079_displayname_text(server: WebDAVServer, fs: InMemoryFS):
    """T79: {DAV:}displayname carries text equal to display_name."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    info = fs.get_info("/x.txt")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, "displayname")]),
        headers={"Depth": "0"},
    )
    resp = _responses(_parse_multistatus(body))[0]
    dn = next(p for p in _success_props(resp) if p.tag == DAV + "displayname")
    assert (dn.text or "") == info.display_name


def test_t080_getcontentlength_text(server: WebDAVServer, fs: InMemoryFS):
    """T80: {DAV:}getcontentlength carries the decimal byte length."""
    seed_file(fs, "/x.txt", b"abcd", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, "getcontentlength")]),
        headers={"Depth": "0"},
    )
    resp = _responses(_parse_multistatus(body))[0]
    cl = next(p for p in _success_props(resp) if p.tag == DAV + "getcontentlength")
    assert (cl.text or "") == "4"


def test_t081_getcontenttype_text(server: WebDAVServer, fs: InMemoryFS):
    """T81: {DAV:}getcontenttype carries the content_type text."""
    seed_file(fs, "/x.bin", b"x", "application/octet-stream")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.bin",
        body=_xml_propfind_prop([(DAV_NS, "getcontenttype")]),
        headers={"Depth": "0"},
    )
    resp = _responses(_parse_multistatus(body))[0]
    ct = next(p for p in _success_props(resp) if p.tag == DAV + "getcontenttype")
    assert (ct.text or "") == "application/octet-stream"


def test_t082_getetag_text(server: WebDAVServer, fs: InMemoryFS):
    """T82: {DAV:}getetag carries the etag text."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    info = fs.get_info("/x.txt")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, "getetag")]),
        headers={"Depth": "0"},
    )
    resp = _responses(_parse_multistatus(body))[0]
    et = next(p for p in _success_props(resp) if p.tag == DAV + "getetag")
    assert (et.text or "") == info.etag


def test_t083_getlastmodified_text(server: WebDAVServer, fs: InMemoryFS):
    """T83: {DAV:}getlastmodified is modified_at via email.utils.format_datetime(usegmt=True)."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    info = fs.get_info("/x.txt")
    expected = email.utils.format_datetime(info.modified_at, usegmt=True)
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, "getlastmodified")]),
        headers={"Depth": "0"},
    )
    resp = _responses(_parse_multistatus(body))[0]
    lm = next(p for p in _success_props(resp) if p.tag == DAV + "getlastmodified")
    assert (lm.text or "") == expected


def test_t084_resourcetype_collection_vs_non_collection(
    server: WebDAVServer, fs: InMemoryFS
):
    """T84: {DAV:}resourcetype carries EXACTLY one {DAV:}collection EMPTY child
    element when the resource is a collection, and EMPTY content when the
    resource is non-collection (Req 13)."""
    seed_collection(fs, "/c")
    seed_file(fs, "/c/a.txt", b"x", "text/plain")
    for path, expect_coll in (("/c", True), ("/c/a.txt", False)):
        status, _, body = call_wsgi(
            server, "PROPFIND", path,
            body=_xml_propfind_prop([(DAV_NS, "resourcetype")]),
            headers={"Depth": "0"},
        )
        assert status == STATUS_MULTI_STATUS, status
        resp = _responses(_parse_multistatus(body))[0]
        rt = next(p for p in _success_props(resp) if p.tag == DAV + "resourcetype")
        kids = list(rt)
        if expect_coll:
            assert len(kids) == 1, (
                f"collection {path} resourcetype MUST carry exactly one "
                f"child element; got {len(kids)} children with tags "
                f"{[c.tag for c in kids]}"
            )
            assert kids[0].tag == DAV + "collection", (
                f"collection {path} resourcetype child MUST be "
                f"{{DAV:}}collection; got {kids[0].tag}"
            )
            assert list(kids[0]) == [], (
                f"{{DAV:}}collection MUST be an empty element (no children); "
                f"got {[c.tag for c in kids[0]]}"
            )
            assert (kids[0].text or "").strip() == "", (
                f"{{DAV:}}collection MUST have no text content; "
                f"got {kids[0].text!r}"
            )
        else:
            assert kids == [], (
                f"non-collection {path} must have empty resourcetype"
            )
            assert (rt.text or "").strip() == "", (
                f"non-collection {path} resourcetype MUST have no text "
                f"content (empty); got {rt.text!r}"
            )


def test_t085_supportedlock_two_lockentry_elements(
    server: WebDAVServer, fs: InMemoryFS
):
    """T85: {DAV:}supportedlock has EXACTLY two lockentry blocks in document order
    (exclusive/write FOLLOWED BY shared/write), and EVERY inner scope/type
    marker ({DAV:}exclusive, {DAV:}shared, {DAV:}write) MUST be an EMPTY
    element per Req 13."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, "supportedlock")]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    sl = next(p for p in _success_props(resp) if p.tag == DAV + "supportedlock")
    entries = sl.findall(DAV + "lockentry")
    assert len(entries) == 2, (
        f"supportedlock must carry exactly two lockentry children; got {len(entries)}"
    )
    scopes: list[str] = []
    types: list[str] = []
    scope_inner_els: list[ET.Element] = []
    type_inner_els: list[ET.Element] = []
    for e in entries:
        scope_el = e.find(DAV + "lockscope")
        type_el = e.find(DAV + "locktype")
        assert scope_el is not None and type_el is not None
        scope_kids = list(scope_el)
        type_kids = list(type_el)
        assert len(scope_kids) == 1
        assert len(type_kids) == 1
        scopes.append(scope_kids[0].tag)
        types.append(type_kids[0].tag)
        scope_inner_els.append(scope_kids[0])
        type_inner_els.append(type_kids[0])
    assert scopes == [DAV + "exclusive", DAV + "shared"], (
        f"supportedlock entries MUST be in document order exclusive then shared; got {scopes}"
    )
    assert types == [DAV + "write", DAV + "write"]

    for el in scope_inner_els + type_inner_els:
        assert list(el) == [], (
            f"{el.tag} MUST be an empty element (no nested children); "
            f"got {[c.tag for c in el]}"
        )
        assert (el.text or "").strip() == "", (
            f"{el.tag} MUST be an empty element (no text content); "
            f"got {el.text!r}"
        )


@pytest.mark.parametrize(
    "scope,depth,owner_xml,is_collection_target",
    [
        ("exclusive", "0", "me", False),
        (
            "shared",
            "infinity",
            '<D:href>http://example.com/me</D:href>',
            True,
        ),
    ],
    ids=["exclusive-depth0-text-owner", "shared-depthinfinity-href-owner"],
)
def test_t086_lockdiscovery_lists_active_locks_with_correct_children(
    fs: InMemoryFS, dpb: InMemoryDPB,
    scope: str, depth: str, owner_xml: str, is_collection_target: bool,
):
    """T86: {DAV:}lockdiscovery has one activelock per active lock with ALL
    required child elements (locktype/write, lockscope matching the requested
    scope, depth matching the requested depth, owner carrying the VERBATIM
    XML inner content supplied at LOCK time, timeout 'Second-N', locktoken
    /href, lockroot/href) per Req 13.

    Parametrized over (scope, depth, owner_xml) so we exercise:
      - exclusive vs shared lockscope branches
      - depth 0 vs depth infinity branches
      - simple-text owner vs complex nested-XML owner (verbatim preservation)
    """
    server = WebDAVServer(fs, dpb)
    target_path = "/c" if is_collection_target else "/x.txt"
    if is_collection_target:
        seed_collection(fs, target_path)
    else:
        seed_file(fs, target_path, b"x", "text/plain")

    requested_timeout_s = 3600
    token = acquire_lock(
        server, target_path, scope=scope, depth=depth,
        timeout=f"Second-{requested_timeout_s}", owner=owner_xml,
    )
    status, _, body = call_wsgi(
        server, "PROPFIND", target_path,
        body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    ld = next(p for p in _success_props(resp) if p.tag == DAV + "lockdiscovery")
    locks = ld.findall(DAV + "activelock")
    assert len(locks) == 1
    al = locks[0]

    lt = al.find(DAV + "locktype")
    assert lt is not None and lt.find(DAV + "write") is not None
    write_el = lt.find(DAV + "write")
    assert write_el is not None
    assert list(write_el) == [], "{DAV:}write must be an empty element"
    assert (write_el.text or "").strip() == "", "{DAV:}write must be empty"

    ls = al.find(DAV + "lockscope")
    assert ls is not None
    expected_scope_tag = DAV + scope
    scope_kids = list(ls)
    assert len(scope_kids) == 1, (
        f"lockscope must wrap exactly one scope element; got {len(scope_kids)}"
    )
    assert scope_kids[0].tag == expected_scope_tag, (
        f"lockscope child MUST be {expected_scope_tag} for {scope!r} lock; "
        f"got {scope_kids[0].tag}"
    )
    assert list(scope_kids[0]) == [], (
        f"{expected_scope_tag} must be an empty element"
    )
    assert (scope_kids[0].text or "").strip() == "", (
        f"{expected_scope_tag} must have no text"
    )

    dp = al.find(DAV + "depth")
    assert dp is not None
    expected_depth_text = "0" if depth == "0" else "infinity"
    assert (dp.text or "").strip() == expected_depth_text, (
        f"{{DAV:}}depth text MUST be {expected_depth_text!r} for Depth: "
        f"{depth!r}; got {(dp.text or '').strip()!r}"
    )

    own = al.find(DAV + "owner")
    assert own is not None
    owner_inner = _prop_text(own).strip()

    def _parse_owner_inner(inner: str) -> ET.Element:
        return ET.fromstring(f'<wrap xmlns:D="DAV:">{inner}</wrap>')

    def _normalize(el: ET.Element) -> tuple:
        return (
            el.tag,
            tuple(sorted(el.attrib.items())),
            (el.text or "").strip(),
            tuple(_normalize(c) for c in el),
            (el.tail or "").strip(),
        )

    expected_owner_tree = _normalize(_parse_owner_inner(owner_xml))
    actual_owner_tree = _normalize(_parse_owner_inner(owner_inner))
    assert actual_owner_tree == expected_owner_tree, (
        f"owner element MUST carry the VERBATIM XML inner content "
        f"supplied at LOCK time (Req 13). Expected structure "
        f"{expected_owner_tree!r}, got {actual_owner_tree!r}; raw owner "
        f"inner was {owner_inner!r}"
    )

    to = al.find(DAV + "timeout")
    assert to is not None
    timeout_text = (to.text or "").strip()
    m = re.fullmatch(r"Second-(\d+)", timeout_text)
    assert m, f"timeout element must be 'Second-<int>'; got {timeout_text!r}"
    remaining = int(m.group(1))
    assert 0 <= remaining <= requested_timeout_s, (
        f"timeout numeric value {remaining} must be in [0, {requested_timeout_s}]"
    )
    assert remaining >= requested_timeout_s - 30, (
        f"timeout numeric value {remaining} must be close to the requested "
        f"{requested_timeout_s}s window (allowing <=30s clock drift)"
    )

    lt2 = al.find(DAV + "locktoken")
    assert lt2 is not None
    href_el = lt2.find(DAV + "href")
    assert href_el is not None
    assert (href_el.text or "") == token

    lr = al.find(DAV + "lockroot")
    assert lr is not None
    href_el = lr.find(DAV + "href")
    assert href_el is not None
    assert (href_el.text or "") == urllib.parse.quote(target_path)
    assert urllib.parse.unquote(href_el.text or "") == target_path


def test_t087_response_href_is_url_encoded(server: WebDAVServer, fs: InMemoryFS):
    """T87: Each {DAV:}response has {DAV:}href URL-encoded via urllib.parse.quote."""
    seed_file(fs, "/with space.txt", b"x", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPFIND", "/with space.txt",
        body=_xml_propfind_allprop(),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    h = _href(resp)
    assert h == urllib.parse.quote("/with space.txt"), (
        f"href must be urllib.parse.quote of the path, got {h!r}"
    )


# ===========================================================================
# T88 .. T95 -- PROPPATCH (Req 14)
# ===========================================================================


def test_t088_proppatch_404_on_missing(server: WebDAVServer):
    """T88: PROPPATCH on nonexistent resource returns 404 Not Found + Content-Length: 0 + empty body."""
    status, hdrs, body = call_wsgi(
        server, "PROPPATCH", "/nope",
        body=_xml_proppatch(set_props=[("u:", "n", "1")]),
    )
    assert status == STATUS_NOT_FOUND, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t089_proppatch_returns_207_with_xml_content_type(
    server: WebDAVServer, fs: InMemoryFS
):
    """T89: PROPPATCH returns 207 Multi-Status with application/xml; charset=utf-8."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    status, hdrs, _ = call_wsgi(
        server, "PROPPATCH", "/x.txt",
        body=_xml_proppatch(set_props=[("u:", "n", "v")]),
    )
    assert status == STATUS_MULTI_STATUS, status
    assert header(hdrs, "Content-Type") == "application/xml; charset=utf-8"


def test_t090_proppatch_set_dead_property_in_success_and_persisted(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """T90: PROPPATCH set on a dead property invokes DPB.set_property with the
    canonical XML serialization of the inner content of the property element,
    and routes the property into 200 OK propstat.

    Per Req 14, ``xml_value`` is the canonical XML serialization of the
    INNER content of the <prop> child element. Verifying only that some
    fragment of the inner text appears (e.g. just the leaf text "VAL")
    would let an implementation drop the surrounding XML structure.
    """
    seed_file(fs, "/x.txt", b"x", "text/plain")
    dpb.calls.clear()
    inner_xml = (
        '<a:wrapper xmlns:a="custom:">'
        'before<a:nested attr="v">leaf</a:nested>after'
        '</a:wrapper>'
    )
    status, _, body = call_wsgi(
        server, "PROPPATCH", "/x.txt",
        body=_xml_proppatch(set_props=[("u:", "tag", inner_xml)]),
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    success = _success_props(resp)
    assert any(p.tag == "{u:}tag" for p in success), (
        "dead property targeted by SET must classify into 200 OK propstat"
    )
    stored = dpb.list_properties("/x.txt")
    assert any(ns == "u:" and n == "tag" for (ns, n, _) in stored)
    set_calls = [c for c in dpb.calls if c[0] == "set_property"]
    matching = [
        c for c in set_calls
        if c[1] == "/x.txt" and c[2] == "u:" and c[3] == "tag"
    ]
    assert matching, (
        f"set_property must be invoked for the SET dead property; "
        f"calls were {set_calls}"
    )
    stored_value = matching[-1][4]

    def _parse_inner(xml_inner: str) -> ET.Element:
        return ET.fromstring(f"<wrap>{xml_inner}</wrap>")

    def _normalize(el: ET.Element) -> tuple:
        return (
            el.tag,
            tuple(sorted(el.attrib.items())),
            (el.text or "").strip(),
            tuple(_normalize(c) for c in el),
            (el.tail or "").strip(),
        )

    expected_tree = _normalize(_parse_inner(inner_xml))
    actual_tree = _normalize(_parse_inner(stored_value))
    assert actual_tree == expected_tree, (
        f"set_property xml_value MUST be the canonical XML serialization of "
        f"the property element's inner content (Req 14). Expected structure "
        f"{expected_tree!r}, got {actual_tree!r}; raw stored value was "
        f"{stored_value!r}"
    )

    status, _, pf_body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([("u:", "tag")]),
        headers={"Depth": "0"},
    )
    assert status == STATUS_MULTI_STATUS, status
    pf_resp = _responses(_parse_multistatus(pf_body))[0]
    pf_dead = next(
        (p for p in _success_props(pf_resp) if p.tag == "{u:}tag"), None
    )
    assert pf_dead is not None, (
        "stored dead property must round-trip through PROPFIND success group"
    )
    pf_inner_tree = _normalize(_parse_inner(_prop_text(pf_dead)))
    assert pf_inner_tree == expected_tree, (
        f"PROPFIND of stored dead property MUST echo back the canonical inner "
        f"content. Expected {expected_tree!r}, got {pf_inner_tree!r}"
    )


def test_t091_proppatch_remove_dead_property_in_success_and_removed(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """T91: PROPPATCH remove on a dead property invokes DPB.remove_property
    and routes the property into 200 OK propstat."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    dpb.set_property("/x.txt", "u:", "tag", "<v>v</v>")
    dpb.calls.clear()
    status, _, body = call_wsgi(
        server, "PROPPATCH", "/x.txt",
        body=_xml_proppatch(remove_props=[("u:", "tag")]),
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    success = _success_props(resp)
    assert any(p.tag == "{u:}tag" for p in success)
    assert dpb.list_properties("/x.txt") == []
    assert ("remove_property", "/x.txt", "u:", "tag") in dpb.calls, (
        f"remove_property must be invoked; calls were {dpb.calls}"
    )


def test_t092_proppatch_remove_absent_dead_property_treated_as_success(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """T92: PROPPATCH remove on absent dead property invokes remove_property; KeyError is success no-op (Req 14)."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    dpb.calls.clear()
    status, _, body = call_wsgi(
        server, "PROPPATCH", "/x.txt",
        body=_xml_proppatch(remove_props=[("u:", "missing")]),
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    assert any(
        p.tag == "{u:}missing" for p in _success_props(resp)
    ), "absent-dead-property remove must classify into success"
    assert ("remove_property", "/x.txt", "u:", "missing") in dpb.calls, (
        f"remove_property must still be invoked for absent dead props "
        f"(KeyError is the no-op path); calls were {dpb.calls}"
    )


@pytest.mark.parametrize("live_name", list(LIVE_PROPS))
def test_t093_proppatch_live_property_in_403(
    server: WebDAVServer, fs: InMemoryFS, live_name: str
):
    """T93: PROPPATCH targeting any of the 9 live properties goes to 403 Forbidden propstat."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPPATCH", "/x.txt",
        body=_xml_proppatch(set_props=[(DAV_NS, live_name, "X")]),
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    forbidden = _forbidden_props(resp)
    assert any(p.tag == DAV + live_name for p in forbidden), (
        f"live property {live_name} must classify into 403 Forbidden propstat"
    )


def test_t094_proppatch_mixed_live_and_dead_routes_to_403_and_424(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """T94: Mixed live+dead PROPPATCH: live -> 403, dead -> 424, no DPB mutation."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    pre = list(dpb.list_properties("/x.txt"))
    dpb.calls.clear()
    status, _, body = call_wsgi(
        server, "PROPPATCH", "/x.txt",
        body=_xml_proppatch(set_props=[
            (DAV_NS, "displayname", "X"),
            ("u:", "tag", "V"),
        ]),
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    forbidden = _forbidden_props(resp)
    failed_dep = _failed_dep_props(resp)
    assert any(p.tag == DAV + "displayname" for p in forbidden)
    assert any(p.tag == "{u:}tag" for p in failed_dep)
    assert dpb.list_properties("/x.txt") == pre, (
        "no DeadPropertyBackend mutation may occur on a mixed PROPPATCH"
    )
    mutating_calls = [
        c for c in dpb.calls if c[0] in ("set_property", "remove_property")
    ]
    assert mutating_calls == [], (
        f"no DPB mutation calls (set_property/remove_property) may occur on a "
        f"mixed PROPPATCH; observed {mutating_calls}"
    )


def test_t09x_proppatch_set_then_remove_same_property_in_document_order(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """PROPPATCH processes set + remove instructions in document order
    (Req 14, line 178). When ``<set foo=A/>`` precedes ``<remove foo/>`` for
    the same dead property, the final stored state MUST be 'absent' (the
    document-order outcome). An implementation that batched all removes
    BEFORE all sets would instead produce the value ``A`` because the
    leading remove of an absent property is a no-op while the trailing set
    would persist.
    """
    seed_file(fs, "/x.txt", b"x", "text/plain")
    dpb.calls.clear()
    body = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<D:propertyupdate xmlns:D="DAV:">'
        '<D:set><D:prop>'
        '<P0:foo xmlns:P0="u:">A</P0:foo>'
        '</D:prop></D:set>'
        '<D:remove><D:prop>'
        '<R0:foo xmlns:R0="u:"/>'
        '</D:prop></D:remove>'
        '</D:propertyupdate>'
    ).encode("utf-8")
    status, _, _ = call_wsgi(server, "PROPPATCH", "/x.txt", body=body)
    assert status == STATUS_MULTI_STATUS, status

    stored = dpb.list_properties("/x.txt")
    assert all(not (ns == "u:" and n == "foo") for (ns, n, _) in stored), (
        "After document-order processing of <set foo=A/> then "
        "<remove foo/>, the property MUST be absent. A non-empty stored "
        f"value indicates removes were processed before sets. Got: {stored!r}"
    )

    set_indices = [
        i for i, c in enumerate(dpb.calls)
        if c[0] == "set_property" and c[1] == "/x.txt"
        and c[2] == "u:" and c[3] == "foo"
    ]
    remove_indices = [
        i for i, c in enumerate(dpb.calls)
        if c[0] == "remove_property" and c[1] == "/x.txt"
        and c[2] == "u:" and c[3] == "foo"
    ]
    assert set_indices and remove_indices, (
        "Both set_property and remove_property MUST be invoked when each "
        "instruction targets a dead property classified into the success "
        f"group; calls were {dpb.calls}"
    )
    assert min(set_indices) < max(remove_indices), (
        "Document order requires the SET on foo to be invoked before the "
        f"REMOVE on foo; calls were {dpb.calls}"
    )


def test_t09y_proppatch_remove_then_set_same_property_in_document_order(
    server: WebDAVServer, fs: InMemoryFS, dpb: InMemoryDPB
):
    """PROPPATCH processes set + remove instructions in document order
    (Req 14, line 178). When ``<remove foo/>`` precedes ``<set foo=B/>`` for
    the same dead property starting from no prior value, the final stored
    state MUST be ``B``. An implementation that batched all sets BEFORE all
    removes would store ``B`` first and then erase it via the trailing
    remove, leaving the property absent.
    """
    seed_file(fs, "/x.txt", b"x", "text/plain")
    dpb.calls.clear()
    body = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<D:propertyupdate xmlns:D="DAV:">'
        '<D:remove><D:prop>'
        '<R0:foo xmlns:R0="u:"/>'
        '</D:prop></D:remove>'
        '<D:set><D:prop>'
        '<P0:foo xmlns:P0="u:">B</P0:foo>'
        '</D:prop></D:set>'
        '</D:propertyupdate>'
    ).encode("utf-8")
    status, _, _ = call_wsgi(server, "PROPPATCH", "/x.txt", body=body)
    assert status == STATUS_MULTI_STATUS, status

    stored_foo = [
        (ns, n, v) for (ns, n, v) in dpb.list_properties("/x.txt")
        if ns == "u:" and n == "foo"
    ]
    assert len(stored_foo) == 1, (
        "After document-order processing of <remove foo/> then "
        f"<set foo=B/>, foo MUST be stored exactly once. Got: {stored_foo!r}"
    )

    set_indices = [
        i for i, c in enumerate(dpb.calls)
        if c[0] == "set_property" and c[1] == "/x.txt"
        and c[2] == "u:" and c[3] == "foo"
    ]
    remove_indices = [
        i for i, c in enumerate(dpb.calls)
        if c[0] == "remove_property" and c[1] == "/x.txt"
        and c[2] == "u:" and c[3] == "foo"
    ]
    assert set_indices and remove_indices, (
        "Both remove_property and set_property MUST be invoked when each "
        "instruction targets a dead property classified into the success "
        f"group; calls were {dpb.calls}"
    )
    assert min(remove_indices) < max(set_indices), (
        "Document order requires the REMOVE on foo to be invoked before the "
        f"SET on foo; calls were {dpb.calls}"
    )


def test_t095_proppatch_response_href_url_encoded(
    server: WebDAVServer, fs: InMemoryFS
):
    """T95: PROPPATCH response href is URL-encoded via urllib.parse.quote."""
    seed_file(fs, "/space file.txt", b"x", "text/plain")
    status, _, body = call_wsgi(
        server, "PROPPATCH", "/space file.txt",
        body=_xml_proppatch(set_props=[("u:", "tag", "V")]),
    )
    assert status == STATUS_MULTI_STATUS, status
    resp = _responses(_parse_multistatus(body))[0]
    assert _href(resp) == urllib.parse.quote("/space file.txt")


# ===========================================================================
# T96 .. T109 -- LOCK (Req 15)
# ===========================================================================


def test_t096_lock_new_acquisition_basic_success(
    server: WebDAVServer, fs: InMemoryFS
):
    """T96: LOCK new acquisition exclusive on unlocked resource returns 200 OK,
    Lock-Token header carrying EXACTLY '<' + token + '>', Content-Type
    application/xml; charset=utf-8, and a body whose root is {DAV:}prop
    wrapping a {DAV:}lockdiscovery whose single activelock carries a
    {DAV:}locktoken/{DAV:}href whose text matches the token in the header."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "LOCK", "/x.txt",
        body=_xml_lockinfo("exclusive", "tester"),
        headers={"Depth": "0", "Timeout": "Second-3600"},
    )
    assert status == STATUS_OK, status
    lt = header(hdrs, "Lock-Token")
    assert lt is not None, "Lock-Token header missing"
    m = re.fullmatch(r"<([^<>]+)>", lt)
    assert m, (
        f"Lock-Token header MUST be exactly '<' + token + '>'; got {lt!r}"
    )
    token_text = m.group(1)
    assert token_text.startswith("urn:uuid:"), (
        f"Lock-Token text must start with 'urn:uuid:'; got {token_text!r}"
    )
    suffix = token_text[len("urn:uuid:"):]
    assert len(suffix) == 36, (
        f"Lock-Token UUID must be canonical 36-char form; got {suffix!r}"
    )
    parsed_uuid = uuid.UUID(suffix)
    assert parsed_uuid.version == 4, "Lock-Token UUID must be UUID4"

    assert header(hdrs, "Content-Type") == "application/xml; charset=utf-8"

    root = ET.fromstring(body)
    assert root.tag == DAV + "prop", (
        f"LOCK response root MUST be {{DAV:}}prop; got {root.tag!r}"
    )
    ld = root.find(DAV + "lockdiscovery")
    assert ld is not None, "response body must wrap {DAV:}lockdiscovery"
    active = ld.findall(DAV + "activelock")
    assert len(active) == 1, (
        f"response lockdiscovery must contain exactly one activelock; got {len(active)}"
    )
    lt_el = active[0].find(DAV + "locktoken")
    assert lt_el is not None, "activelock must carry {DAV:}locktoken"
    href_el = lt_el.find(DAV + "href")
    assert href_el is not None, "{DAV:}locktoken must wrap {DAV:}href"
    assert (href_el.text or "") == token_text, (
        f"locktoken/href text must equal the token returned in the Lock-Token "
        f"header; header carried {token_text!r}, body carried {href_el.text!r}"
    )
    _assert_activelock_complete_req13(
        active[0],
        token=token_text,
        scope="exclusive",
        depth_text="0",
        owner_xml_inner="tester",
        target_path="/x.txt",
        requested_timeout_s=3600,
    )


def test_t097_lock_token_format(server: WebDAVServer, fs: InMemoryFS):
    """T97: LOCK new acquisition generates token = 'urn:uuid:' + UUID4 (36 chars)."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    token = acquire_lock(server, "/x.txt", depth="0")
    assert token.startswith("urn:uuid:"), token
    suffix = token[len("urn:uuid:"):]
    assert len(suffix) == 36, suffix
    parsed = uuid.UUID(suffix)
    assert parsed.version == 4, "lock token must be a UUID4"


def test_t098_lock_creates_resource_when_missing(dpb: InMemoryDPB):
    """T98: LOCK new acquisition on nonexistent resource invokes
    VFS.write_bytes(path, b"", "application/octet-stream")."""
    rfs = RecordingFS()
    s = WebDAVServer(rfs, dpb)
    assert not rfs.exists("/new.bin")
    rfs.calls.clear()
    status, _, _ = call_wsgi(
        s, "LOCK", "/new.bin",
        body=_xml_lockinfo("exclusive", "tester"),
        headers={"Depth": "0", "Timeout": "Second-3600"},
    )
    assert status == STATUS_OK, status
    assert rfs.exists("/new.bin")
    assert rfs.read_bytes("/new.bin") == b""
    assert rfs.get_info("/new.bin").content_type == "application/octet-stream"
    assert ("write_bytes", "/new.bin", b"", "application/octet-stream") in rfs.calls, (
        f"LOCK on missing path must invoke write_bytes(path, b'', 'application/octet-stream'); "
        f"calls were {rfs.calls}"
    )


def test_t099_lock_exclusive_on_already_exclusively_locked_returns_423(
    server: WebDAVServer, fs: InMemoryFS
):
    """T99: LOCK exclusive when path already exclusively locked returns 423 Locked + Content-Length: 0 + empty body."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    acquire_lock(server, "/x.txt", scope="exclusive", depth="0")
    status, hdrs, body = call_wsgi(
        server, "LOCK", "/x.txt",
        body=_xml_lockinfo("exclusive", "B"),
        headers={"Depth": "0", "Timeout": "Second-3600"},
    )
    assert status == STATUS_LOCKED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t100_lock_exclusive_on_shared_locked_returns_423(
    server: WebDAVServer, fs: InMemoryFS
):
    """T100: LOCK exclusive when path has active shared lock returns 423 Locked + Content-Length: 0 + empty body."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    acquire_lock(server, "/x.txt", scope="shared", depth="0")
    status, hdrs, body = call_wsgi(
        server, "LOCK", "/x.txt",
        body=_xml_lockinfo("exclusive", "B"),
        headers={"Depth": "0", "Timeout": "Second-3600"},
    )
    assert status == STATUS_LOCKED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t101_lock_shared_on_exclusive_locked_returns_423(
    server: WebDAVServer, fs: InMemoryFS
):
    """T101: LOCK shared when path is exclusively locked returns 423 Locked + Content-Length: 0 + empty body."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    acquire_lock(server, "/x.txt", scope="exclusive", depth="0")
    status, hdrs, body = call_wsgi(
        server, "LOCK", "/x.txt",
        body=_xml_lockinfo("shared", "B"),
        headers={"Depth": "0", "Timeout": "Second-3600"},
    )
    assert status == STATUS_LOCKED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t102_lock_shared_on_shared_locked_succeeds(
    server: WebDAVServer, fs: InMemoryFS
):
    """T102: Second shared LOCK on same path returns full success response per Req 15.4 + 13 (two activelocks in body)."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    tok_a = acquire_lock(server, "/x.txt", scope="shared", depth="0", owner="A")
    status, hdrs, body = call_wsgi(
        server, "LOCK", "/x.txt",
        body=_xml_lockinfo("shared", "B"),
        headers={"Depth": "0", "Timeout": "Second-3600"},
    )
    assert status == STATUS_OK, status
    lt = header(hdrs, "Lock-Token")
    assert lt is not None
    m = re.fullmatch(r"<([^<>]+)>", lt)
    assert m, f"Lock-Token MUST be '<' + token + '>'; got {lt!r}"
    new_token = m.group(1)
    assert new_token.startswith("urn:uuid:")
    assert len(new_token[len("urn:uuid:"):]) == 36
    assert uuid.UUID(new_token[len("urn:uuid:"):]).version == 4

    assert header(hdrs, "Content-Type") == "application/xml; charset=utf-8"

    root = ET.fromstring(body)
    assert root.tag == DAV + "prop"
    ld = root.find(DAV + "lockdiscovery")
    assert ld is not None
    actives = ld.findall(DAV + "activelock")
    assert len(actives) == 2, (
        f"second shared lock must list both activelocks in response; got {len(actives)}"
    )
    by_token: dict[str, ET.Element] = {}
    for alock in actives:
        href_el = alock.find(DAV + "locktoken/" + DAV + "href")
        assert href_el is not None
        by_token[href_el.text or ""] = alock
    assert set(by_token.keys()) == {tok_a, new_token}, (
        f"expected activelocks for both shared tokens; got {set(by_token.keys())!r}"
    )
    _assert_activelock_complete_req13(
        by_token[tok_a],
        token=tok_a,
        scope="shared",
        depth_text="0",
        owner_xml_inner="A",
        target_path="/x.txt",
        requested_timeout_s=3600,
    )
    _assert_activelock_complete_req13(
        by_token[new_token],
        token=new_token,
        scope="shared",
        depth_text="0",
        owner_xml_inner="B",
        target_path="/x.txt",
        requested_timeout_s=3600,
    )


def test_t103_lock_depth_infinity_with_descendant_locked_returns_423(
    server: WebDAVServer, fs: InMemoryFS
):
    """T103: LOCK depth-infinity on collection when descendant has active lock returns 423 Locked + Content-Length: 0 + empty body."""
    seed_collection(fs, "/c")
    seed_file(fs, "/c/leaf.txt", b"x", "text/plain")
    acquire_lock(server, "/c/leaf.txt", scope="exclusive", depth="0")
    status, hdrs, body = call_wsgi(
        server, "LOCK", "/c",
        body=_xml_lockinfo("exclusive", "B"),
        headers={"Depth": "infinity", "Timeout": "Second-3600"},
    )
    assert status == STATUS_LOCKED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t104_lock_depth_header_resolution(server: WebDAVServer, fs: InMemoryFS):
    """T104: LOCK Depth: 0 -> zero, infinity -> infinity, absent -> infinity."""
    seed_collection(fs, "/c")
    seed_file(fs, "/c/leaf.txt", b"x", "text/plain")
    acquire_lock(server, "/c", scope="exclusive", depth="0")
    status, _, _ = call_wsgi(
        server, "LOCK", "/c/leaf.txt",
        body=_xml_lockinfo("exclusive", "B"),
        headers={"Depth": "0", "Timeout": "Second-3600"},
    )
    assert status == STATUS_OK, (
        f"depth 0 lock on /c must NOT extend to descendants; got {status!r}"
    )
    fs2 = InMemoryFS()
    dpb2 = InMemoryDPB()
    s2 = WebDAVServer(fs2, dpb2)
    seed_collection(fs2, "/c")
    seed_file(fs2, "/c/leaf.txt", b"x", "text/plain")
    acquire_lock(s2, "/c", scope="exclusive", depth="infinity")
    status, _, _ = call_wsgi(
        s2, "LOCK", "/c/leaf.txt",
        body=_xml_lockinfo("exclusive", "B"),
        headers={"Depth": "0", "Timeout": "Second-3600"},
    )
    assert status == STATUS_LOCKED, (
        f"depth infinity lock on /c MUST extend to /c/leaf.txt; got {status!r}"
    )

    fs3 = InMemoryFS()
    dpb3 = InMemoryDPB()
    s3 = WebDAVServer(fs3, dpb3)
    seed_collection(fs3, "/c")
    seed_file(fs3, "/c/leaf.txt", b"x", "text/plain")
    status, hdrs, _ = call_wsgi(
        s3, "LOCK", "/c",
        body=_xml_lockinfo("exclusive", "tester"),
        headers={"Timeout": "Second-3600"},
    )
    assert status == STATUS_OK, status
    status, _, _ = call_wsgi(
        s3, "LOCK", "/c/leaf.txt",
        body=_xml_lockinfo("exclusive", "B"),
        headers={"Depth": "0", "Timeout": "Second-3600"},
    )
    assert status == STATUS_LOCKED, (
        f"absent Depth on /c lock must default to infinity (descendant blocked); got {status!r}"
    )


def test_t105_lock_timeout_header_resolution(
    server: WebDAVServer, fs: InMemoryFS
):
    """T105: LOCK Timeout: Infinite -> 3600, Second-N -> min(N, 3600), absent -> 600."""
    def _timeout_seconds(path: str) -> int:
        s, _, body = call_wsgi(
            server, "PROPFIND", path,
            body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
            headers={"Depth": "0"},
        )
        assert s == STATUS_MULTI_STATUS, s
        resp = _responses(_parse_multistatus(body))[0]
        ld = next(
            p for p in _success_props(resp) if p.tag == DAV + "lockdiscovery"
        )
        al = ld.find(DAV + "activelock")
        assert al is not None
        to = al.find(DAV + "timeout")
        assert to is not None
        text = (to.text or "").strip()
        m = re.fullmatch(r"Second-(\d+)", text)
        assert m, f"unexpected timeout format: {text}"
        return int(m.group(1))

    seed_file(fs, "/a.txt", b"x", "text/plain")
    acquire_lock(server, "/a.txt", depth="0", timeout="Infinite")
    sec_a = _timeout_seconds("/a.txt")
    assert 3590 <= sec_a <= 3600

    seed_file(fs, "/b.txt", b"x", "text/plain")
    acquire_lock(server, "/b.txt", depth="0", timeout="Second-50")
    sec_b = _timeout_seconds("/b.txt")
    assert 40 <= sec_b <= 50

    seed_file(fs, "/c.txt", b"x", "text/plain")
    acquire_lock(server, "/c.txt", depth="0", timeout="Second-10000")
    sec_c = _timeout_seconds("/c.txt")
    assert 3590 <= sec_c <= 3600

    seed_file(fs, "/d.txt", b"x", "text/plain")
    status, hdrs, _ = call_wsgi(
        server, "LOCK", "/d.txt",
        body=_xml_lockinfo("exclusive", "tester"),
        headers={"Depth": "0"},
    )
    assert status == STATUS_OK, status
    sec_d = _timeout_seconds("/d.txt")
    assert 590 <= sec_d <= 600


def test_t106_lock_refresh_with_matching_token_returns_200(
    server: WebDAVServer, fs: InMemoryFS
):
    """T106: LOCK refresh resets expires_at only for locks whose tokens appear in If (Req 15);
    response lists every activelock with full Req 13 shape."""
    def _timeouts_by_token(path: str) -> dict[str, int]:
        s, _, body = call_wsgi(
            server, "PROPFIND", path,
            body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
            headers={"Depth": "0"},
        )
        assert s == STATUS_MULTI_STATUS, s
        resp = _responses(_parse_multistatus(body))[0]
        ld = next(
            p for p in _success_props(resp) if p.tag == DAV + "lockdiscovery"
        )
        out: dict[str, int] = {}
        for alock in ld.findall(DAV + "activelock"):
            href_el = alock.find(DAV + "locktoken/" + DAV + "href")
            assert href_el is not None
            tok = href_el.text or ""
            to_el = alock.find(DAV + "timeout")
            assert to_el is not None
            text = (to_el.text or "").strip()
            m = re.fullmatch(r"Second-(\d+)", text)
            assert m, f"unexpected timeout format: {text}"
            out[tok] = int(m.group(1))
        return out

    seed_file(fs, "/x.txt", b"x", "text/plain")
    token_matched = acquire_lock(
        server, "/x.txt", scope="shared", depth="0",
        timeout="Second-120", owner="matched",
    )
    token_other = acquire_lock(
        server, "/x.txt", scope="shared", depth="0",
        timeout="Second-120", owner="other",
    )

    before = _timeouts_by_token("/x.txt")
    assert set(before.keys()) == {token_matched, token_other}
    assert all(90 <= v <= 120 for v in before.values()), before

    status, hdrs, body = call_wsgi(
        server, "LOCK", "/x.txt",
        body=b"",
        headers={"If": f"(<{token_matched}>)", "Timeout": "Second-3600"},
    )
    assert status == STATUS_OK, status
    assert header(hdrs, "Content-Type") == "application/xml; charset=utf-8", (
        f"LOCK refresh response MUST carry Content-Type "
        f"'application/xml; charset=utf-8'; got "
        f"{header(hdrs, 'Content-Type')!r}"
    )
    root = ET.fromstring(body)
    assert root.tag == DAV + "prop"
    ld = root.find(DAV + "lockdiscovery")
    assert ld is not None, "response body must wrap {DAV:}lockdiscovery"
    active = ld.findall(DAV + "activelock")
    assert len(active) == 2, (
        f"refresh must list both active shared locks; got {len(active)}"
    )
    by_tok: dict[str, ET.Element] = {}
    for alock in active:
        href_el = alock.find(DAV + "locktoken/" + DAV + "href")
        assert href_el is not None
        by_tok[href_el.text or ""] = alock
    assert set(by_tok) == {token_matched, token_other}
    _assert_activelock_complete_req13(
        by_tok[token_matched],
        token=token_matched,
        scope="shared",
        depth_text="0",
        owner_xml_inner="matched",
        target_path="/x.txt",
        requested_timeout_s=3600,
    )
    _assert_activelock_complete_req13(
        by_tok[token_other],
        token=token_other,
        scope="shared",
        depth_text="0",
        owner_xml_inner="other",
        target_path="/x.txt",
        requested_timeout_s=120,
        timeout_slack=40,
    )

    after = _timeouts_by_token("/x.txt")
    assert after[token_matched] >= 3590, (
        f"matched lock must be refreshed to ~3600s; got {after[token_matched]}"
    )
    assert after[token_other] < 600, (
        f"non-matched lock must NOT receive the refresh timeout; got "
        f"{after[token_other]} (expected still ~120s window)"
    )


def test_t107_lock_refresh_without_matching_token_returns_412(
    server: WebDAVServer, fs: InMemoryFS
):
    """T107: LOCK refresh with no matching If token returns 412 Precondition Failed + Content-Length: 0 + empty body."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    acquire_lock(server, "/x.txt", depth="0")
    bad = "urn:uuid:" + str(uuid.uuid4())
    status, hdrs, body = call_wsgi(
        server, "LOCK", "/x.txt",
        body=b"", headers={"If": f"(<{bad}>)"},
    )
    assert status == STATUS_PRECONDITION_FAILED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t108_lock_records_thread_safe_in_memory(
    server: WebDAVServer, fs: InMemoryFS
):
    """T108: Lock records are stored in a process-wide thread-safe in-memory
    structure shared across requests (Req 15).
    """
    for i in range(16):
        fs.write_bytes(f"/p{i}.txt", b"x", "text/plain")

    tokens: dict[int, str] = {}
    errors: list[Exception] = []
    lock = threading.Lock()

    def worker(i: int) -> None:
        try:
            status, hdrs, _ = call_wsgi(
                server, "LOCK", f"/p{i}.txt",
                body=_xml_lockinfo("exclusive", f"w{i}"),
                headers={"Depth": "0", "Timeout": "Second-600"},
            )
            assert status == STATUS_OK, status
            tk = (header(hdrs, "Lock-Token") or "")[1:-1]
            with lock:
                tokens[i] = tk
        except Exception as e:
            with lock:
                errors.append(e)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(16)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors, errors
    assert len(tokens) == 16
    assert len(set(tokens.values())) == 16, "tokens must be distinct"

    for i, tok in tokens.items():
        status, _, body = call_wsgi(
            server, "PROPFIND", f"/p{i}.txt",
            body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
            headers={"Depth": "0"},
        )
        resp = _responses(_parse_multistatus(body))[0]
        ld = next(p for p in _success_props(resp) if p.tag == DAV + "lockdiscovery")
        active = ld.findall(DAV + "activelock")
        assert len(active) == 1
        href_el = active[0].find(DAV + "locktoken/" + DAV + "href")
        assert href_el is not None and (href_el.text or "") == tok

    fs.write_bytes("/shared.txt", b"x", "text/plain")
    shared_tokens: list[str] = []
    shared_errors: list[Exception] = []
    n_shared = 16

    def shared_worker(i: int) -> None:
        try:
            status, hdrs, _ = call_wsgi(
                server, "LOCK", "/shared.txt",
                body=_xml_lockinfo("shared", f"sw{i}"),
                headers={"Depth": "0", "Timeout": "Second-600"},
            )
            assert status == STATUS_OK, status
            tk = (header(hdrs, "Lock-Token") or "")[1:-1]
            with lock:
                shared_tokens.append(tk)
        except Exception as e:
            with lock:
                shared_errors.append(e)

    threads = [
        threading.Thread(target=shared_worker, args=(i,))
        for i in range(n_shared)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not shared_errors, shared_errors
    assert len(shared_tokens) == n_shared, (
        f"all {n_shared} concurrent shared LOCKs on the same path must "
        f"succeed; only {len(shared_tokens)} did"
    )
    assert len(set(shared_tokens)) == n_shared, (
        "concurrent shared-lock acquisitions on the same path must produce "
        "distinct tokens (tests that no race lost a record under contention)"
    )

    status, _, body = call_wsgi(
        server, "PROPFIND", "/shared.txt",
        body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
        headers={"Depth": "0"},
    )
    resp = _responses(_parse_multistatus(body))[0]
    ld = next(p for p in _success_props(resp) if p.tag == DAV + "lockdiscovery")
    active = ld.findall(DAV + "activelock")
    reported = {
        (al.find(DAV + "locktoken/" + DAV + "href").text or "")  # type: ignore[union-attr]
        for al in active
    }
    assert reported == set(shared_tokens), (
        f"lockdiscovery on the contested path MUST enumerate ALL {n_shared} "
        f"shared-lock tokens that were concurrently acquired (no record may "
        f"be lost to a race in the shared in-memory structure). Expected "
        f"{set(shared_tokens)}, got {reported}"
    )

    fs.write_bytes("/mixed.txt", b"x", "text/plain")
    acquired: list[str] = []
    released: list[str] = []
    propfind_failures: list[Exception] = []
    mix_lock = threading.Lock()

    def mix_lock_worker(i: int) -> None:
        try:
            status, hdrs, _ = call_wsgi(
                server, "LOCK", "/mixed.txt",
                body=_xml_lockinfo("shared", f"m{i}"),
                headers={"Depth": "0", "Timeout": "Second-600"},
            )
            assert status == STATUS_OK, status
            tk = (header(hdrs, "Lock-Token") or "")[1:-1]
            with mix_lock:
                acquired.append(tk)
            if i % 2 == 0:
                status, _, _ = call_wsgi(
                    server, "UNLOCK", "/mixed.txt",
                    headers={"Lock-Token": f"<{tk}>"},
                )
                assert status == STATUS_NO_CONTENT, status
                with mix_lock:
                    released.append(tk)
        except Exception as e:
            with mix_lock:
                propfind_failures.append(e)

    def mix_pf_worker() -> None:
        try:
            for _ in range(8):
                status, _, _ = call_wsgi(
                    server, "PROPFIND", "/mixed.txt",
                    body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
                    headers={"Depth": "0"},
                )
                assert status == STATUS_MULTI_STATUS, status
        except Exception as e:
            with mix_lock:
                propfind_failures.append(e)

    n_mix = 16
    workers = [
        threading.Thread(target=mix_lock_worker, args=(i,))
        for i in range(n_mix)
    ] + [
        threading.Thread(target=mix_pf_worker) for _ in range(4)
    ]
    for t in workers:
        t.start()
    for t in workers:
        t.join()

    assert not propfind_failures, propfind_failures
    assert len(acquired) == n_mix, (
        f"all {n_mix} concurrent LOCK workers must succeed under mixed "
        f"contention; only {len(acquired)} did"
    )

    status, _, body = call_wsgi(
        server, "PROPFIND", "/mixed.txt",
        body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
        headers={"Depth": "0"},
    )
    resp = _responses(_parse_multistatus(body))[0]
    ld = next(p for p in _success_props(resp) if p.tag == DAV + "lockdiscovery")
    final_reported = {
        (al.find(DAV + "locktoken/" + DAV + "href").text or "")
        for al in ld.findall(DAV + "activelock")
    }
    expected_alive = set(acquired) - set(released)
    assert final_reported == expected_alive, (
        f"after concurrent LOCK/UNLOCK/PROPFIND mix the lockdiscovery state "
        f"MUST equal acquired-tokens minus released-tokens. Expected "
        f"{expected_alive}, got {final_reported}; acquired={set(acquired)}, "
        f"released={set(released)}"
    )


def test_t109_expired_locks_are_not_active(
    server: WebDAVServer, fs: InMemoryFS
):
    """T109: A lock whose expires_at <= now is not active (vanishes from lockdiscovery
    and stops blocking mutations).
    """
    seed_file(fs, "/x.txt", b"x", "text/plain")
    status, hdrs, _ = call_wsgi(
        server, "LOCK", "/x.txt",
        body=_xml_lockinfo("exclusive", "tester"),
        headers={"Depth": "0", "Timeout": "Second-1"},
    )
    assert status == STATUS_OK, status

    time.sleep(1.5)

    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
        headers={"Depth": "0"},
    )
    resp = _responses(_parse_multistatus(body))[0]
    ld = next(p for p in _success_props(resp) if p.tag == DAV + "lockdiscovery")
    assert ld.findall(DAV + "activelock") == [], (
        "expired lock must not appear in lockdiscovery"
    )

    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"new", headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_NO_CONTENT, (
        f"expired lock must not block subsequent mutations; got {status!r}"
    )


# ===========================================================================
# T110 .. T113 -- UNLOCK (Req 16)
# ===========================================================================


def test_t110_unlock_400_when_no_lock_token_header(
    server: WebDAVServer, fs: InMemoryFS
):
    """T110: UNLOCK without Lock-Token header returns 400 Bad Request + Content-Length: 0 + empty body."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    status, hdrs, body = call_wsgi(server, "UNLOCK", "/x.txt")
    assert status == STATUS_BAD_REQUEST, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t111_unlock_409_when_token_does_not_match(
    server: WebDAVServer, fs: InMemoryFS
):
    """T111: UNLOCK with non-matching Lock-Token returns 409 Conflict + Content-Length: 0 + empty body."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    acquire_lock(server, "/x.txt", depth="0")
    bogus = "urn:uuid:" + str(uuid.uuid4())
    status, hdrs, body = call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"<{bogus}>"},
    )
    assert status == STATUS_CONFLICT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t112_unlock_with_valid_token_returns_204(
    server: WebDAVServer, fs: InMemoryFS
):
    """T112: UNLOCK with valid token removes the lock and returns 204 No Content + Content-Length: 0 + empty body."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    token = acquire_lock(server, "/x.txt", depth="0")
    status, hdrs, body = call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"<{token}>"},
    )
    assert status == STATUS_NO_CONTENT, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""

    status, _, body = call_wsgi(
        server, "PROPFIND", "/x.txt",
        body=_xml_propfind_prop([(DAV_NS, "lockdiscovery")]),
        headers={"Depth": "0"},
    )
    resp = _responses(_parse_multistatus(body))[0]
    ld = next(p for p in _success_props(resp) if p.tag == DAV + "lockdiscovery")
    assert ld.findall(DAV + "activelock") == []


def test_t113_unlock_strips_angle_brackets_from_lock_token(
    server: WebDAVServer, fs: InMemoryFS
):
    """T113: UNLOCK extracts the token by removing EXACTLY ONE leading '<'
    and EXACTLY ONE trailing '>' (Req 16.2).
    """
    def _bogus() -> str:
        return acquire_lock(server, "/x.txt", depth="0")

    seed_file(fs, "/x.txt", b"x", "text/plain")

    token_a = acquire_lock(server, "/x.txt", depth="0")
    status, _, _ = call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"<{token_a}>"},
    )
    assert status == STATUS_NO_CONTENT, (
        f"(a) UNLOCK must accept Lock-Token wrapped in <...> brackets; got {status!r}"
    )

    token_b = _bogus()
    status, _, _ = call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"<<{token_b}>>"},
    )
    assert status == STATUS_CONFLICT, (
        f"(b) UNLOCK must strip EXACTLY ONE leading '<' and EXACTLY ONE "
        f"trailing '>'; with input '<<token>>' the resulting extracted text "
        f"is '<token>' which matches no active lock => expected 409 Conflict, "
        f"got {status!r}"
    )

    status, _, _ = call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"<{token_b}>"},
    )
    assert status == STATUS_NO_CONTENT

    token_c = _bogus()
    status, _, _ = call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"<{token_c}"},
    )
    assert status == STATUS_CONFLICT, (
        f"(c) UNLOCK with Lock-Token '<token' (no trailing '>') must NOT "
        f"match (the trailing-'>' strip is mandatory); expected 409 Conflict, "
        f"got {status!r}"
    )
    call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"<{token_c}>"},
    )

    token_d = _bogus()
    status, _, _ = call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"{token_d}>"},
    )
    assert status == STATUS_CONFLICT, (
        f"(d) UNLOCK with Lock-Token 'token>' (no leading '<') must NOT "
        f"match (the leading-'<' strip is mandatory); expected 409 Conflict, "
        f"got {status!r}"
    )
    call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"<{token_d}>"},
    )

    token_e = _bogus()
    status, _, _ = call_wsgi(
        server, "UNLOCK", "/x.txt",
        headers={"Lock-Token": f"<{token_e}>X"},
    )
    assert status == STATUS_CONFLICT, (
        f"(e) UNLOCK with Lock-Token '<token>X' (trailing junk after '>') "
        f"must NOT match; expected 409 Conflict, got {status!r}"
    )


# ===========================================================================
# T114 .. T122 -- If header parsing & evaluation (Req 17)
# ===========================================================================


def test_t114_if_no_tag_binds_to_request_path(
    server: WebDAVServer, fs: InMemoryFS
):
    """T114: If header no-tag shape binds parenthesized lists to the request path."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    token = acquire_lock(server, "/x.txt", depth="0")
    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"updated",
        headers={"Content-Type": "text/plain", "If": f"(<{token}>)"},
    )
    assert status == STATUS_NO_CONTENT, status


def test_t115_if_tagged_extracts_path_via_urlsplit_unquote(
    server: WebDAVServer, fs: InMemoryFS
):
    """T115: If header tagged shape extracts path via urlsplit + unquote, binding to that path."""
    seed_file(fs, "/space file.txt", b"x", "text/plain")
    token = acquire_lock(server, "/space file.txt", depth="0")
    if_hdr = f"<http://localhost/space%20file.txt> (<{token}>)"
    status, _, _ = call_wsgi(
        server, "PUT", "/space file.txt",
        body=b"updated",
        headers={"Content-Type": "text/plain", "If": if_hdr},
    )
    assert status == STATUS_NO_CONTENT, status


def test_t116_if_state_token_true_when_lock_matches(
    server: WebDAVServer, fs: InMemoryFS
):
    """T116: If header state-token evaluates True when bound path has matching lock token."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    token = acquire_lock(server, "/x.txt", depth="0")
    status, _, _ = call_wsgi(
        server, "PROPPATCH", "/x.txt",
        body=_xml_proppatch(set_props=[("u:", "n", "v")]),
        headers={"If": f"(<{token}>)"},
    )
    assert status == STATUS_MULTI_STATUS, status


def test_t116x_if_state_token_false_when_lock_anchor_differs_from_bound_path(
    server: WebDAVServer, fs: InMemoryFS
):
    """T116x: Per Req 17, the state-token production evaluates True only
    when one active lock LOCKS THE BOUND PATH while carrying the matching
    lock token text. "Locks the bound path" follows the Req 18 definition
    (anchor equals the bound path, or the lock has depth infinity and
    the bound path is a descendant of the anchor).
    """
    seed_file(fs, "/a.txt", b"A", "text/plain")
    seed_file(fs, "/b.txt", b"B", "text/plain")
    token_a = acquire_lock(server, "/a.txt", depth="0")

    status, hdrs, body = call_wsgi(
        server, "PUT", "/b.txt",
        body=b"would-be-new",
        headers={"Content-Type": "text/plain", "If": f"(<{token_a}>)"},
    )
    assert status == STATUS_PRECONDITION_FAILED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""
    assert fs.read_bytes("/b.txt") == b"B", (
        "no storage mutation may occur on If: False"
    )


def test_t117_if_entity_tag_true_when_etag_matches(
    server: WebDAVServer, fs: InMemoryFS
):
    """T117: If header entity-tag evaluates True for matching etag using
    STRONG comparison per RFC 9110 section 8.8.3.
    """
    seed_file(fs, "/x.txt", b"x", "text/plain")
    info = fs.get_info("/x.txt")

    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"new",
        headers={"Content-Type": "text/plain", "If": f"([{info.etag}])"},
    )
    assert status == STATUS_NO_CONTENT, status

    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"newer",
        headers={
            "Content-Type": "text/plain",
            "If": '(["nope-not-real"])',
        },
    )
    assert status == STATUS_PRECONDITION_FAILED, (
        f"entity-tag mismatch must yield 412 Precondition Failed; got {status!r}"
    )

    info = fs.get_info("/x.txt")
    weak_form_of_strong = "W/" + info.etag
    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"weakly-tagged",
        headers={
            "Content-Type": "text/plain",
            "If": f"([{weak_form_of_strong}])",
        },
    )
    assert status == STATUS_PRECONDITION_FAILED, (
        f"strong comparison MUST reject a weak entity-tag (W/...) even when "
        f"the opaque-tag bytes are identical to the resource's strong etag. "
        f"Per RFC 9110 8.8.3.2 strong comparison requires both tags to be "
        f"strong; got {status!r} for If: '([{weak_form_of_strong}])'"
    )
    assert fs.read_bytes("/x.txt") != b"weakly-tagged", (
        "no storage mutation may occur when If header evaluates to False"
    )


def test_t118_if_not_negates_inner_condition(
    server: WebDAVServer, fs: InMemoryFS
):
    """T118: If header 'Not' keyword negates the inner condition result."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    info = fs.get_info("/x.txt")
    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"new",
        headers={
            "Content-Type": "text/plain",
            "If": '(Not ["nope-not-real"])',
        },
    )
    assert status == STATUS_NO_CONTENT, status

    info = fs.get_info("/x.txt")
    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"newer",
        headers={
            "Content-Type": "text/plain",
            "If": f"(Not [{info.etag}])",
        },
    )
    assert status == STATUS_PRECONDITION_FAILED, status


def test_t119_if_list_uses_and_semantics(server: WebDAVServer, fs: InMemoryFS):
    """T119: If header parenthesized list is True only when ALL inner conditions are True."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    info = fs.get_info("/x.txt")
    token = acquire_lock(server, "/x.txt", depth="0")

    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"new",
        headers={
            "Content-Type": "text/plain",
            "If": f"(<{token}> [{info.etag}])",
        },
    )
    assert status == STATUS_NO_CONTENT, status

    info = fs.get_info("/x.txt")
    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"newer",
        headers={
            "Content-Type": "text/plain",
            "If": f"(<{token}> [\"wrong-etag\"])",
        },
    )
    assert status == STATUS_PRECONDITION_FAILED, status


def test_t120_if_uses_or_semantics_across_lists(
    server: WebDAVServer, fs: InMemoryFS
):
    """T120: If header overall is True when at least one parenthesized list is True."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    token = acquire_lock(server, "/x.txt", depth="0")
    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"new",
        headers={
            "Content-Type": "text/plain",
            "If": f'(["wrong-etag"]) (<{token}>)',
        },
    )
    assert status == STATUS_NO_CONTENT, status


def test_t121_if_false_returns_412_before_mutation(
    server: WebDAVServer, fs: InMemoryFS
):
    """T121: If header False returns 412 Precondition Failed + Content-Length: 0 + empty body BEFORE any mutation."""
    seed_file(fs, "/x.txt", b"original", "text/plain")
    status, hdrs, body = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"would-be-new",
        headers={
            "Content-Type": "text/plain",
            "If": '(["never-matches"])',
        },
    )
    assert status == STATUS_PRECONDITION_FAILED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""
    assert fs.read_bytes("/x.txt") == b"original", (
        "no storage mutation may occur on If: False"
    )


def test_t122_if_evaluation_applies_to_mutating_methods_only(
    server: WebDAVServer, fs: InMemoryFS
):
    """T122: If header evaluation applies to PUT, DELETE, MKCOL, COPY, MOVE, PROPPATCH."""
    bad_if = '(["never-matches"])'

    seed_file(fs, "/x.txt", b"x", "text/plain")
    s, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"y", headers={"Content-Type": "text/plain", "If": bad_if},
    )
    assert s == STATUS_PRECONDITION_FAILED, f"PUT: {s!r}"

    seed_file(fs, "/y.txt", b"y", "text/plain")
    s, _, _ = call_wsgi(server, "DELETE", "/y.txt", headers={"If": bad_if})
    assert s == STATUS_PRECONDITION_FAILED, f"DELETE: {s!r}"

    s, _, _ = call_wsgi(server, "MKCOL", "/newdir", headers={"If": bad_if})
    assert s == STATUS_PRECONDITION_FAILED, f"MKCOL: {s!r}"

    seed_file(fs, "/cp.txt", b"x", "text/plain")
    s, _, _ = call_wsgi(
        server, "COPY", "/cp.txt",
        headers={"Destination": "http://localhost/cp_dst.txt", "If": bad_if},
    )
    assert s == STATUS_PRECONDITION_FAILED, f"COPY: {s!r}"

    seed_file(fs, "/mv.txt", b"x", "text/plain")
    s, _, _ = call_wsgi(
        server, "MOVE", "/mv.txt",
        headers={"Destination": "http://localhost/mv_dst.txt", "If": bad_if},
    )
    assert s == STATUS_PRECONDITION_FAILED, f"MOVE: {s!r}"

    seed_file(fs, "/pp.txt", b"x", "text/plain")
    s, _, _ = call_wsgi(
        server, "PROPPATCH", "/pp.txt",
        body=_xml_proppatch(set_props=[("u:", "n", "v")]),
        headers={"If": bad_if},
    )
    assert s == STATUS_PRECONDITION_FAILED, f"PROPPATCH: {s!r}"


# ===========================================================================
# T123 .. T133 -- Lock conflict enforcement (Req 18)
# ===========================================================================


def test_t123_put_blocked_by_lock_without_if(
    server: WebDAVServer, fs: InMemoryFS
):
    """T123: PUT on a locked path without matching If returns 423 Locked
    + Content-Length: 0 + empty body; with matching If passes 204."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    token = acquire_lock(server, "/x.txt", depth="0")

    status, hdrs, body = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"new", headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_LOCKED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""

    status, _, _ = call_wsgi(
        server, "PUT", "/x.txt",
        body=b"new",
        headers={"Content-Type": "text/plain", "If": f"(<{token}>)"},
    )
    assert status == STATUS_NO_CONTENT, status


@pytest.mark.parametrize("locked_path", ["/dir", "/dir/leaf.txt"])
def test_t124_delete_blocked_by_lock_on_path_or_descendant(
    server: WebDAVServer, fs: InMemoryFS, locked_path: str,
):
    """T124: DELETE blocked when any path in the affected set is locked (Req 18): request path or descendant."""
    seed_collection(fs, "/dir")
    seed_file(fs, "/dir/leaf.txt", b"x", "text/plain")
    acquire_lock(server, locked_path, depth="0")

    status, hdrs, body = call_wsgi(server, "DELETE", "/dir")
    assert status == STATUS_LOCKED, f"locked={locked_path}: {status!r}"
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t125_mkcol_blocked_by_lock_on_path(
    server: WebDAVServer, fs: InMemoryFS
):
    """T125: MKCOL blocked when an active lock locks the request path: 423 Locked + Content-Length: 0 + empty body.
    """
    seed_collection(fs, "/parent")
    acquire_lock(server, "/parent", depth="infinity")
    status, hdrs, body = call_wsgi(server, "MKCOL", "/parent/sub")
    assert status == STATUS_LOCKED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t126_copy_blocked_by_lock_on_destination_when_dest_missing(
    server: WebDAVServer, fs: InMemoryFS
):
    """T126: COPY (no existing dest) blocked by active lock on destination path: 423 Locked + Content-Length: 0 + empty body."""
    seed_collection(fs, "/parent")
    seed_file(fs, "/src.txt", b"x", "text/plain")
    acquire_lock(server, "/parent", depth="infinity")
    status, hdrs, body = call_wsgi(
        server, "COPY", "/src.txt",
        headers={"Destination": "http://localhost/parent/new.txt"},
    )
    assert status == STATUS_LOCKED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


@pytest.mark.parametrize("locked_path", ["/dst", "/dst/old.txt"])
def test_t127_copy_blocked_by_lock_on_dest_or_descendant_when_dest_exists(
    locked_path: str,
):
    """T127: COPY with existing destination blocked by lock on dest OR dest descendants: 423 Locked + Content-Length: 0 + empty body."""
    fs = InMemoryFS()
    dpb = InMemoryDPB()
    server = WebDAVServer(fs, dpb)
    seed_collection(fs, "/src")
    seed_file(fs, "/src/a.txt", b"A", "text/plain")
    seed_collection(fs, "/dst")
    seed_file(fs, "/dst/old.txt", b"Z", "text/plain")
    acquire_lock(server, locked_path, depth="0")

    status, hdrs, body = call_wsgi(
        server, "COPY", "/src",
        headers={
            "Destination": "http://localhost/dst",
            "Overwrite": "T",
        },
    )
    assert status == STATUS_LOCKED, f"locked={locked_path}: {status!r}"
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


@pytest.mark.parametrize("locked_path", ["/src", "/src/a.txt", "/dst"])
def test_t128_move_blocked_by_lock_on_source_or_destination_when_dest_missing(
    locked_path: str,
):
    """T128: MOVE (no existing dest) blocked by lock on source, any source
    descendant, or destination: 423 Locked + Content-Length: 0 + empty body.
    """
    fs = InMemoryFS()
    dpb = InMemoryDPB()
    server = WebDAVServer(fs, dpb)
    seed_collection(fs, "/src")
    seed_file(fs, "/src/a.txt", b"A", "text/plain")
    if locked_path == "/dst":
        seed_collection(fs, "/dst-parent")
    acquire_lock(server, locked_path, depth="0")
    status, hdrs, body = call_wsgi(
        server, "MOVE", "/src",
        headers={"Destination": "http://localhost/dst"},
    )
    assert status == STATUS_LOCKED, f"locked={locked_path}: {status!r}"
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


@pytest.mark.parametrize(
    "locked_path", ["/src", "/src/a.txt", "/dst", "/dst/old.txt"]
)
def test_t129_move_blocked_by_lock_on_dest_descendants_when_dest_exists(
    locked_path: str,
):
    """T129: MOVE with existing dest blocked by lock on source, source
    descendant, dest, or dest descendant: 423 Locked + Content-Length: 0 + empty body."""
    fs = InMemoryFS()
    dpb = InMemoryDPB()
    server = WebDAVServer(fs, dpb)
    seed_collection(fs, "/src")
    seed_file(fs, "/src/a.txt", b"A", "text/plain")
    seed_collection(fs, "/dst")
    seed_file(fs, "/dst/old.txt", b"Z", "text/plain")
    acquire_lock(server, locked_path, depth="0")
    status, hdrs, body = call_wsgi(
        server, "MOVE", "/src",
        headers={
            "Destination": "http://localhost/dst",
            "Overwrite": "T",
        },
    )
    assert status == STATUS_LOCKED, f"locked={locked_path}: {status!r}"
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t130_proppatch_blocked_by_lock_on_path(
    server: WebDAVServer, fs: InMemoryFS
):
    """T130: PROPPATCH on locked path without matching If returns 423 Locked + Content-Length: 0 + empty body."""
    seed_file(fs, "/x.txt", b"x", "text/plain")
    acquire_lock(server, "/x.txt", depth="0")
    status, hdrs, body = call_wsgi(
        server, "PROPPATCH", "/x.txt",
        body=_xml_proppatch(set_props=[("u:", "n", "v")]),
    )
    assert status == STATUS_LOCKED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t131_lock_conflict_passes_when_all_blocking_tokens_in_if(
    server: WebDAVServer, fs: InMemoryFS
):
    """T131: Lock conflict check (Req 18) passes when every blocking
    lock's token is carried by the request ``If`` header.
    """
    seed_collection(fs, "/dir")
    seed_file(fs, "/dir/a.txt", b"A", "text/plain")
    seed_file(fs, "/dir/b.txt", b"B", "text/plain")

    t_a = acquire_lock(server, "/dir/a.txt", depth="0")
    t_b = acquire_lock(server, "/dir/b.txt", depth="0")
    if_hdr = (
        f"<http://localhost/dir/a.txt> (<{t_a}>) "
        f"<http://localhost/dir/b.txt> (<{t_b}>)"
    )
    status, _, _ = call_wsgi(
        server, "DELETE", "/dir", headers={"If": if_hdr},
    )
    assert status == STATUS_NO_CONTENT, status
    assert not fs.exists("/dir")


def test_t132_depth_infinity_lock_locks_descendants(
    server: WebDAVServer, fs: InMemoryFS
):
    """T132: An active lock with depth infinity locks every descendant path: 423 Locked + Content-Length: 0 + empty body."""
    seed_collection(fs, "/c")
    seed_collection(fs, "/c/sub")
    seed_file(fs, "/c/sub/leaf.txt", b"x", "text/plain")
    acquire_lock(server, "/c", depth="infinity")
    status, hdrs, body = call_wsgi(
        server, "PUT", "/c/sub/leaf.txt",
        body=b"new", headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_LOCKED, status
    assert header(hdrs, "Content-Length") == "0"
    assert body == b""


def test_t133_depth_zero_lock_locks_only_anchor(
    server: WebDAVServer, fs: InMemoryFS
):
    """T133: An active lock with depth 0 locks only the anchor path."""
    seed_collection(fs, "/c")
    seed_file(fs, "/c/leaf.txt", b"x", "text/plain")
    acquire_lock(server, "/c", depth="0")
    status, _, _ = call_wsgi(
        server, "PUT", "/c/leaf.txt",
        body=b"new", headers={"Content-Type": "text/plain"},
    )
    assert status == STATUS_NO_CONTENT, (
        f"depth-0 lock on /c must NOT block mutations on /c/leaf.txt; got {status!r}"
    )