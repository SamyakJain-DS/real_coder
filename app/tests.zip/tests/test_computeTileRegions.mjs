/**
 * Tests for printManager.js — computeTileRegions
 * Covers: computeTileRegions named export
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';

const MODULE_PATH = new URL('../printManager.js', import.meta.url).href;

async function loadModule() {
  try {
    return await import(MODULE_PATH);
  } catch {
    return null;
  }
}

// ─── Tile count (portrait) ────────────────────────────────────────────────────

test('computeTileRegions: portrait 7.5x10 inch image fits in exactly 1 tile', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // portrait contentWidth=7.5, contentHeight=10.0
  // cols=ceil(7.5/7.5)=1, rows=ceil(10/10)=1 → 1 tile
  const result = mod.computeTileRegions(750, 1000, 7.5, 10, 'portrait');
  assert.equal(result.length, 1);
});

test('computeTileRegions: portrait wider-than-one-page image spans 2 columns', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // portrait contentWidth=7.5; realWidth=10 → cols=ceil(10/7.5)=2
  // contentHeight=10.0; realHeight=10 → rows=1 → 2 tiles
  const result = mod.computeTileRegions(1000, 1000, 10, 10, 'portrait');
  assert.equal(result.length, 2);
});

test('computeTileRegions: portrait taller-than-one-page image spans 2 rows', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // portrait contentHeight=10.0; realHeight=15 → rows=ceil(15/10)=2
  // contentWidth=7.5; realWidth=7.5 → cols=1 → 2 tiles
  const result = mod.computeTileRegions(750, 1500, 7.5, 15, 'portrait');
  assert.equal(result.length, 2);
});

// ─── Tile count (landscape) ───────────────────────────────────────────────────

test('computeTileRegions: landscape 10x7.5 inch image fits in exactly 1 tile', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // landscape contentWidth=10.0, contentHeight=7.5
  // cols=ceil(10/10)=1, rows=ceil(7.5/7.5)=1 → 1 tile
  const result = mod.computeTileRegions(1000, 750, 10, 7.5, 'landscape');
  assert.equal(result.length, 1);
});

test('computeTileRegions: landscape taller image spans 2 rows (landscape contentHeight=7.5)', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // landscape contentHeight=7.5; realHeight=10 → rows=ceil(10/7.5)=2
  // contentWidth=10; realWidth=10 → cols=1 → 2 tiles
  const result = mod.computeTileRegions(1000, 1000, 10, 10, 'landscape');
  assert.equal(result.length, 2);
});

// ─── Row-major order ──────────────────────────────────────────────────────────

test('computeTileRegions: tiles are returned in row-major order (row outer, col inner)', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // 2 cols × 2 rows = 4 tiles; portrait
  // realWidth=15, contentWidth=7.5 → cols=2
  // realHeight=20, contentHeight=10 → rows=2
  const result = mod.computeTileRegions(1500, 2000, 15, 20, 'portrait');
  assert.equal(result.length, 4);
  // Row-major: (row=0,col=0), (row=0,col=1), (row=1,col=0), (row=1,col=1)
  assert.equal(result[0].row, 0); assert.equal(result[0].col, 0);
  assert.equal(result[1].row, 0); assert.equal(result[1].col, 1);
  assert.equal(result[2].row, 1); assert.equal(result[2].col, 0);
  assert.equal(result[3].row, 1); assert.equal(result[3].col, 1);
});

// ─── sx / sy computation ─────────────────────────────────────────────────────

test('computeTileRegions: first tile always has sx=0 and sy=0', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const result = mod.computeTileRegions(1000, 1000, 10, 10, 'landscape');
  assert.equal(result[0].sx, 0);
  assert.equal(result[0].sy, 0);
});

test('computeTileRegions: portrait second-column tile has correct sx', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // imageWidthPx=1000, realWidthInches=10 → pxPerInchX=100
  // portrait contentWidth=7.5 → sx for col=1: Math.floor(1*100*7.5)=750
  const result = mod.computeTileRegions(1000, 1000, 10, 10, 'portrait');
  const col1Tile = result.find(t => t.col === 1 && t.row === 0);
  assert.ok(col1Tile, 'Could not find tile at col=1, row=0');
  assert.equal(col1Tile.sx, 750);
});

// ─── sw / sh clip to image bounds ────────────────────────────────────────────

test('computeTileRegions: last tile sw equals exact clipped value', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // portrait: imageWidthPx=1000, realWidth=10 → pxPerInchX=100
  // cols=2 (ceil(10/7.5)); contentWidth=7.5
  // col=1: sx=Math.floor(1*100*7.5)=750
  //        sw=Math.min(Math.floor(100*7.5), 1000-750) = Math.min(750, 250) = 250
  const result = mod.computeTileRegions(1000, 1000, 10, 10, 'portrait');
  const lastColTile = result.find(t => t.col === 1);
  assert.ok(lastColTile, 'Could not find tile at col=1');

  const pxPerInchX = 1000 / 10; // 100
  const contentWidthInches = 7.5;
  const expectedSw = Math.min(
    Math.floor(pxPerInchX * contentWidthInches),
    1000 - lastColTile.sx
  );
  assert.equal(lastColTile.sw, expectedSw,
    `sw=${lastColTile.sw} expected ${expectedSw} (clipped to remaining image width)`);
});

// ─── widthInches / heightInches ───────────────────────────────────────────────

test('computeTileRegions: widthInches equals sw / pxPerInchX', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const imageWidthPx = 750;
  const realWidthInches = 7.5;
  const pxPerInchX = imageWidthPx / realWidthInches; // 100
  const result = mod.computeTileRegions(imageWidthPx, 1000, realWidthInches, 10, 'portrait');
  for (const tile of result) {
    const expected = tile.sw / pxPerInchX;
    assert.ok(Math.abs(tile.widthInches - expected) < 0.0001,
      `widthInches=${tile.widthInches} expected ${expected}`);
  }
});

test('computeTileRegions: heightInches equals sh / pxPerInchY', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const imageHeightPx = 1000;
  const realHeightInches = 10;
  const pxPerInchY = imageHeightPx / realHeightInches; // 100
  const result = mod.computeTileRegions(750, imageHeightPx, 7.5, realHeightInches, 'portrait');
  for (const tile of result) {
    const expected = tile.sh / pxPerInchY;
    assert.ok(Math.abs(tile.heightInches - expected) < 0.0001,
      `heightInches=${tile.heightInches} expected ${expected}`);
  }
});

test('computeTileRegions: last tile sh equals exact clipped value', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // portrait: imageHeightPx=1500, realHeight=15 → pxPerInchY=100, rows=2, contentHeight=10
  // row=1: sy=Math.floor(1*100*10)=1000; sh=Math.min(Math.floor(100*10), 1500-1000)=500
  const result = mod.computeTileRegions(750, 1500, 7.5, 15, 'portrait');
  const lastRowTile = result.find(t => t.row === 1);
  assert.ok(lastRowTile, 'Could not find tile at row=1');

  const pxPerInchY = 1500 / 15; // 100
  const contentHeightInches = 10.0;
  const expectedSh = Math.min(
    Math.floor(pxPerInchY * contentHeightInches),
    1500 - lastRowTile.sy
  );
  assert.equal(lastRowTile.sh, expectedSh,
    `sh=${lastRowTile.sh} expected ${expectedSh} (clipped to remaining image height)`);
});

test('computeTileRegions: second-row tile has correct sy', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  // portrait: imageHeightPx=1500, realHeight=15 → pxPerInchY=100, contentHeight=10
  // row=1: sy=Math.floor(1*100*10)=1000
  const result = mod.computeTileRegions(750, 1500, 7.5, 15, 'portrait');
  const row1Tile = result.find(t => t.row === 1 && t.col === 0);
  assert.ok(row1Tile, 'Could not find tile at row=1, col=0');
  const expectedSy = Math.floor(1 * (1500 / 15) * 10.0);
  assert.equal(row1Tile.sy, expectedSy,
    `sy=${row1Tile.sy} expected ${expectedSy}`);
});

// ─── Error cases ──────────────────────────────────────────────────────────────

test('computeTileRegions: throws RangeError for invalid orientation', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  assert.throws(
    () => mod.computeTileRegions(750, 1000, 7.5, 10, 'diagonal'),
    (err) => err instanceof RangeError
  );
});

test('computeTileRegions: RangeError message is exactly "Invalid orientation"', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  try {
    mod.computeTileRegions(750, 1000, 7.5, 10, 'bad');
    assert.fail('Expected RangeError');
  } catch (err) {
    assert.ok(err instanceof RangeError);
    assert.equal(err.message, 'Invalid orientation');
  }
});
