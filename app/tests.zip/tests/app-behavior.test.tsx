import { describe, it, expect, vi, beforeEach } from 'vitest'
import React from 'react'
import { render, screen, within, waitFor, act } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

// -- Test fixtures ------------------------------------------------------------

const SAMPLE_KNIFE_A = {
  id: 'k-A',
  maker: 'Maker-A-MAKER',
  pattern: 'Pattern-A-PATTERN',
  edgeGeometry: 'EdgeGeo-A-EG',
  scaleMaterial: 'ScaleMat-A-SM',
  photoDataUrl: 'data:image/png;base64,AAAA',
  provenanceChain: [
    { owner: 'Owner-A1', acquiredOn: '1980-01-02', note: 'note-A1' },
    { owner: 'Owner-A2', acquiredOn: '1990-06-07', note: 'note-A2' },
    { owner: 'Owner-A3-LAST', acquiredOn: '2000-12-31', note: 'note-A3' },
  ],
  sharpeningSessions: [
    { id: 's-A1', date: '2001-01-01', angle: 17, stoneGritProgression: [220, 1000, 4000] },
    { id: 's-A2', date: '2005-05-05', angle: 20, stoneGritProgression: [600, 3000, 8000] },
  ],
}

const SAMPLE_KNIFE_B = {
  id: 'k-B',
  maker: 'Maker-B-MAKER',
  pattern: 'Pattern-B-PATTERN',
  edgeGeometry: 'EdgeGeo-B-EG',
  scaleMaterial: 'ScaleMat-B-SM',
  photoDataUrl: 'data:image/png;base64,BBBB',
  provenanceChain: [
    { owner: 'Owner-B1-LAST', acquiredOn: '2010-03-04', note: 'note-B1' },
  ],
  sharpeningSessions: [],
}

// Stub FileReader for the photo input. The component is expected to read
// the selected file and store the result as a data URL.
class FakeFileReader {
  public result: string | ArrayBuffer | null = null
  public onload: ((ev: any) => void) | null = null
  public onloadend: ((ev: any) => void) | null = null
  public onerror: ((ev: any) => void) | null = null
  readAsDataURL(_file: Blob) {
    setTimeout(() => {
      this.result = 'data:image/png;base64,UPLOADEDPHOTO'
      const ev = { target: this }
      if (this.onload) this.onload(ev)
      if (this.onloadend) this.onloadend(ev)
    }, 0)
  }
}

beforeEach(() => {
  window.localStorage.clear()
  ;(globalThis as any).FileReader = FakeFileReader as any
  document.body.innerHTML = ''
})

async function importApp() {
  const src = ['/app', 'src', 'App'].join('/')
  const mod = await import(/* @vite-ignore */ src)
  return (mod as any).default
}

async function findControl(label: RegExp): Promise<HTMLElement> {
  const matches = await screen.findAllByText(label)
  for (const el of matches) {
    if (el.matches('button, a, [role="button"], [role="link"]')) return el
    const ancestor = el.closest('button, a, [role="button"], [role="link"]')
    if (ancestor) return ancestor as HTMLElement
  }
  return matches[0] as HTMLElement
}

function isSameIsoDate(actual: unknown, expected: string): boolean {
  if (typeof actual !== 'string') return false
  if (actual.length < 10) return false
  return actual.slice(0, 10) === expected
}

function getStoredCollection(): any[] {
  const raw = window.localStorage.getItem('knifeCollection')
  if (!raw) return []
  try {
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

function findKnifeRow(
  maker: string,
  pattern: string,
  extraFields: string[] = [],
): HTMLElement {
  const required = [maker, pattern, ...extraFields].filter(Boolean) as string[]
  const makerNodes = screen.getAllByText(new RegExp(maker))
  expect(makerNodes.length, `expected to find ${maker} in the DOM`).toBeGreaterThan(0)
  for (const node of makerNodes) {
    let el: HTMLElement | null = node as HTMLElement
    while (el && !required.every((t) => (el!.textContent || '').includes(t))) {
      el = el.parentElement
    }
    if (el) return el
  }
  throw new Error(
    `expected to find a container for ${maker} that includes all required fields: ${required.join(', ')}`,
  )
}

async function openDetailFor(
  maker: string,
  pattern: string,
  verifyToken?: string,
  extraRowFields: string[] = [],
) {
  const row = findKnifeRow(maker, pattern, extraRowFields)
  // Find clickable elements inside the row that could open the detail view.
  const clickable = [
    ...within(row).queryAllByRole('button'),
    ...within(row).queryAllByRole('link'),
  ]
  expect(clickable.length, `${maker} row must expose a control to open the detail view`).toBeGreaterThan(0)

  const isThisDetailOpen = () => {
    const text = document.body.textContent || ''
    const anyDetail =
      text.includes('Add Provenance Entry') ||
      text.includes('Add Sharpening Session')
    if (!anyDetail) return false
    if (verifyToken) return text.includes(verifyToken)
    return true
  }

  if (isThisDetailOpen()) return

  // Try each clickable element in the row until the detail view appears.
  for (const el of clickable) {
    await userEvent.click(el)
    if (isThisDetailOpen()) return
  }
}

// =============================================================================

function hasPhotoRendered(container: HTMLElement, dataUrl: string): boolean {
  return Array.from(container.querySelectorAll('*')).some((el) => {
    const src = el.getAttribute('src') || ''
    const srcset = el.getAttribute('srcset') || ''
    const style = el.getAttribute('style') || ''
    const dataSrc = el.getAttribute('data-src') || ''
    return (
      src.includes(dataUrl) ||
      srcset.includes(dataUrl) ||
      style.includes(dataUrl) ||
      dataSrc.includes(dataUrl)
    )
  })
}

describe('Requirement 7 & 8: localStorage is read on mount and the loaded collection is rendered', () => {
  it('renders the persisted collection from window.localStorage under key "knifeCollection"', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A, SAMPLE_KNIFE_B]))
    const getItemSpy = vi.spyOn(Storage.prototype, 'getItem')

    const App = await importApp()
    render(<App />)

    // The component read from localStorage on mount, using the documented key.
    const keysRead = getItemSpy.mock.calls.map((c) => c[0])
    expect(keysRead).toContain('knifeCollection')

    // The persisted knives are visible in the rendered UI.
    expect(await screen.findByText(new RegExp(SAMPLE_KNIFE_A.maker))).toBeInTheDocument()
    expect(screen.getByText(new RegExp(SAMPLE_KNIFE_B.maker))).toBeInTheDocument()
  })
})

describe('Requirement 9: collection view renders one item per knife', () => {
  it('renders a distinct entry for every knife in the loaded collection', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A, SAMPLE_KNIFE_B]))
    const App = await importApp()
    render(<App />)

    await screen.findByText(new RegExp(SAMPLE_KNIFE_A.maker))
    const rowA = findKnifeRow(SAMPLE_KNIFE_A.maker, SAMPLE_KNIFE_A.pattern, [
      SAMPLE_KNIFE_A.edgeGeometry,
      SAMPLE_KNIFE_A.scaleMaterial,
    ])
    const rowB = findKnifeRow(SAMPLE_KNIFE_B.maker, SAMPLE_KNIFE_B.pattern, [
      SAMPLE_KNIFE_B.edgeGeometry,
      SAMPLE_KNIFE_B.scaleMaterial,
    ])
    // Rows must be distinct containers - each knife has its own item.
    expect(rowA).not.toBe(rowB)
    // Each row must only contain its own knife's data - not the other knife's.
    expect(rowA.textContent).not.toContain(SAMPLE_KNIFE_B.maker)
    expect(rowB.textContent).not.toContain(SAMPLE_KNIFE_A.maker)
  })
})

describe('Requirement 10: each collection item displays maker, pattern, edgeGeometry, scaleMaterial, photo', () => {
  it('shows the documented fields and the photo for each knife', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A]))
    const App = await importApp()
    render(<App />)

    await screen.findByText(new RegExp(SAMPLE_KNIFE_A.maker))
    const row = findKnifeRow(SAMPLE_KNIFE_A.maker, SAMPLE_KNIFE_A.pattern, [
      SAMPLE_KNIFE_A.edgeGeometry,
      SAMPLE_KNIFE_A.scaleMaterial,
    ])
    expect(row.textContent).toContain(SAMPLE_KNIFE_A.maker)
    expect(row.textContent).toContain(SAMPLE_KNIFE_A.pattern)
    expect(row.textContent).toContain(SAMPLE_KNIFE_A.edgeGeometry)
    expect(row.textContent).toContain(SAMPLE_KNIFE_A.scaleMaterial)

    expect(hasPhotoRendered(row, SAMPLE_KNIFE_A.photoDataUrl), 'photo must be rendered via src/srcset/style attribute in the collection row').toBe(true)
  })
})

describe('Requirement 11: collection view exposes a control labelled "Add Knife"', () => {
  it('renders an "Add Knife" control', async () => {
    const App = await importApp()
    render(<App />)
    expect(await findControl(/Add Knife/)).toBeInTheDocument()
  })
})

describe('Requirement 13: each knife row exposes a control that opens the detail view for that specific knife', () => {
  it('row for knife A has a control that opens knife A\'s detail view', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A, SAMPLE_KNIFE_B]))
    const App = await importApp()
    render(<App />)
    await screen.findByText(new RegExp(SAMPLE_KNIFE_A.maker))

    const rowA = findKnifeRow(SAMPLE_KNIFE_A.maker, SAMPLE_KNIFE_A.pattern, [
      SAMPLE_KNIFE_A.edgeGeometry,
      SAMPLE_KNIFE_A.scaleMaterial,
    ])
    const controlsInRowA = [
      ...within(rowA).queryAllByRole('button'),
      ...within(rowA).queryAllByRole('link'),
    ]
    expect(
      controlsInRowA.length,
      `${SAMPLE_KNIFE_A.maker} row must expose a control to open the detail view`,
    ).toBeGreaterThan(0)

    await openDetailFor(
      SAMPLE_KNIFE_A.maker,
      SAMPLE_KNIFE_A.pattern,
      SAMPLE_KNIFE_A.provenanceChain[0].owner,
      [SAMPLE_KNIFE_A.edgeGeometry, SAMPLE_KNIFE_A.scaleMaterial],
    )

    await waitFor(() => {
      const text = document.body.textContent || ''
      expect(text).toContain(SAMPLE_KNIFE_A.maker)
      expect(text).toContain(SAMPLE_KNIFE_A.pattern)
      for (const p of SAMPLE_KNIFE_A.provenanceChain) {
        expect(text).toContain(p.owner)
      }
    })
  })

  it('row for knife B has a control that opens knife B\'s detail view', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A, SAMPLE_KNIFE_B]))
    const App = await importApp()
    render(<App />)
    await screen.findByText(new RegExp(SAMPLE_KNIFE_B.maker))

    const rowB = findKnifeRow(SAMPLE_KNIFE_B.maker, SAMPLE_KNIFE_B.pattern, [
      SAMPLE_KNIFE_B.edgeGeometry,
      SAMPLE_KNIFE_B.scaleMaterial,
    ])
    const controlsInRowB = [
      ...within(rowB).queryAllByRole('button'),
      ...within(rowB).queryAllByRole('link'),
    ]
    expect(
      controlsInRowB.length,
      `${SAMPLE_KNIFE_B.maker} row must expose a control to open the detail view`,
    ).toBeGreaterThan(0)

    await openDetailFor(
      SAMPLE_KNIFE_B.maker,
      SAMPLE_KNIFE_B.pattern,
      SAMPLE_KNIFE_B.provenanceChain[0].owner,
      [SAMPLE_KNIFE_B.edgeGeometry, SAMPLE_KNIFE_B.scaleMaterial],
    )

    await waitFor(() => {
      const text = document.body.textContent || ''
      expect(text).toContain(SAMPLE_KNIFE_B.maker)
      expect(text).toContain(SAMPLE_KNIFE_B.pattern)
      expect(text).toContain(SAMPLE_KNIFE_B.provenanceChain[0].owner)
    })
  })
})

// -- Entry form ---------------------------------------------------------------

async function fillKnifeEntryFormAndSubmit(opts: {
  maker: string
  pattern: string
  edgeGeometry: string
  scaleMaterial: string
  owner: string
  acquiredOn: string
  note: string
}) {
  // Ensure the form is reachable. If the file input is not already present,
  // click "Add Knife" to reveal the form. Avoids closing an already-open
  // form when "Add Knife" is implemented as a toggle.
  const fileInputPresent = () =>
    document.querySelectorAll('input[type="file"]').length > 0
  if (!fileInputPresent()) {
    const addBtn = await findControl(/Add Knife/)
    await userEvent.click(addBtn)
  }

  // Collect non-file inputs, textareas, and selects in document order so
  // the query matches the Req 14 count check and covers implementations
  // that use a <select> for any of the documented fields.
  const inputs = Array.from(
    document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>(
      'input:not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]), textarea, select',
    ),
  )

  // Try to match by name / placeholder / aria-label / id substring.
  function pickByHint(hints: string[]): HTMLInputElement | HTMLTextAreaElement | null {
    const lowerHints = hints.map((h) => h.toLowerCase())
    for (const el of inputs) {
      const labelTextById = (el as HTMLInputElement).id
        ? (document.querySelector(`label[for="${(el as HTMLInputElement).id}"]`)?.textContent || '')
        : ''
      const parentLabel = el.closest('label')?.textContent || ''
      const attrs = [
        (el as HTMLInputElement).name,
        (el as HTMLInputElement).id,
        el.getAttribute('placeholder') || '',
        el.getAttribute('aria-label') || '',
        labelTextById,
        parentLabel,
      ]
        .filter(Boolean)
        .map((s) => s.toLowerCase())
      if (lowerHints.some((h) => attrs.some((a) => a.includes(h)))) {
        return el
      }
    }
    return null
  }

  const targets: Array<{ hints: string[]; value: string }> = [
    { hints: ['maker'], value: opts.maker },
    { hints: ['pattern'], value: opts.pattern },
    { hints: ['edgegeometry', 'edge geometry', 'edge'], value: opts.edgeGeometry },
    { hints: ['scalematerial', 'scale material', 'scale'], value: opts.scaleMaterial },
    { hints: ['owner'], value: opts.owner },
    { hints: ['acquiredon', 'acquired on', 'acquired', 'date'], value: opts.acquiredOn },
    { hints: ['note'], value: opts.note },
  ]

  for (let idx = 0; idx < targets.length; idx++) {
    const t = targets[idx]
    const el = pickByHint(t.hints) || (idx < inputs.length ? inputs[idx] : null)
    if (!el) continue
    if (el instanceof HTMLSelectElement) {
      const match = Array.from(el.options).find(
        (o) => o.value === t.value || o.text === t.value,
      )
      if (match) await userEvent.selectOptions(el, match.value)
    } else {
      await userEvent.clear(el)
      await userEvent.type(el, t.value)
    }
  }

  // File input - set a fake file. The component should call FileReader and
  // place the resulting data URL onto the knife record.
  const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement | null
  expect(fileInput, 'entry form must have a photo file input').toBeTruthy()
  const file = new File([new Uint8Array([1, 2, 3])], 'photo.png', { type: 'image/png' })
  await userEvent.upload(fileInput!, file)

  // Submit. Look for a submit-style button (not the "Add Knife" toggle).
  const buttons = Array.from(document.querySelectorAll<HTMLButtonElement>('button, input[type="submit"]'))
  const submit = buttons.find((b) => {
    const txt = (b.textContent || (b as HTMLInputElement).value || '').toLowerCase().trim()
    return (b as HTMLInputElement).type === 'submit' ||
      /save|submit|add knife to|create|confirm|done/.test(txt) ||
      txt === 'add' || txt === 'ok'
  }) || buttons.find((b) => !/^add knife$/i.test((b.textContent || '').trim()))
  expect(submit, 'entry form must expose a submit/save control').toBeTruthy()
  await act(async () => {
    await userEvent.click(submit!)
    // Allow FileReader microtask to flush.
    await new Promise((r) => setTimeout(r, 10))
  })
}

describe('Requirement 14: knife entry form exposes all required inputs', () => {
  it('each required field has at least one form control programmatically associated with its field name', async () => {
    const App = await importApp()
    render(<App />)
    const addBtn = await findControl(/Add Knife/)
    await userEvent.click(addBtn)

    function hasAssociatedControl(hints: string[]): boolean {
      const lower = hints.map((h) => h.toLowerCase())
      const inputs = Array.from(
        document.querySelectorAll<HTMLElement>(
          'input:not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="hidden"]), textarea, select',
        ),
      )
      for (const input of inputs) {
        const el = input as HTMLInputElement
        // name attribute
        if (el.name && lower.some((h) => el.name.toLowerCase().includes(h))) return true
        // aria-label
        const ariaLabel = (input.getAttribute('aria-label') || '').toLowerCase()
        if (ariaLabel && lower.some((h) => ariaLabel.includes(h))) return true
        // aria-labelledby -> resolve referenced element's text
        const ariaLabelledBy = input.getAttribute('aria-labelledby')
        if (ariaLabelledBy) {
          const refText = (document.getElementById(ariaLabelledBy)?.textContent || '').toLowerCase()
          if (lower.some((h) => refText.includes(h))) return true
        }
        // <label for="inputId">
        if (el.id) {
          const labelText = (document.querySelector(`label[for="${el.id}"]`)?.textContent || '').toLowerCase()
          if (lower.some((h) => labelText.includes(h))) return true
        }
        // Enclosing <label>
        const enclosing = (input.closest('label')?.textContent || '').toLowerCase()
        if (enclosing && lower.some((h) => enclosing.includes(h))) return true
      }
      return false
    }

    const fields: Array<[string, string[]]> = [
      ['maker',         ['maker']],
      ['pattern',       ['pattern']],
      ['edgeGeometry',  ['edgegeometry', 'edge geometry', 'edge']],
      ['scaleMaterial', ['scalematerial', 'scale material', 'scale']],
      ['owner',         ['owner']],
      ['acquiredOn',    ['acquiredon', 'acquired on', 'acquired', 'date']],
      ['note',          ['note']],
    ]

    for (const [fieldName, hints] of fields) {
      expect(
        hasAssociatedControl(hints),
        `entry form must have a control programmatically associated with field "${fieldName}"`,
      ).toBe(true)
    }
  })
})

describe('Requirements 15-19: submitting the entry form adds a new knife with all fields, unique id, and persistence', () => {
  it('reads the photo as a data URL, appends a new knife, assigns a unique id, stores first provenance, and persists collection to localStorage', async () => {
    const App = await importApp()
    render(<App />)

    const data = {
      maker: 'TEST-MAKER-XYZ',
      pattern: 'TEST-PATTERN-XYZ',
      edgeGeometry: 'TEST-EDGE-GEO-XYZ',
      scaleMaterial: 'TEST-SCALE-MAT-XYZ',
      owner: 'TEST-OWNER-XYZ',
      acquiredOn: '2023-04-05',
      note: 'TEST-NOTE-XYZ',
    }

    await fillKnifeEntryFormAndSubmit(data)

    // (Req 19) Persisted to localStorage under key "knifeCollection".
    await waitFor(() => {
      const stored = getStoredCollection()
      expect(stored.length).toBeGreaterThanOrEqual(1)
    })
    const stored = getStoredCollection()
    expect(stored.length).toBe(1)
    const k = stored[0]

    // (Req 16) The new knife is part of the collection.
    expect(k.maker).toBe(data.maker)
    expect(k.pattern).toBe(data.pattern)
    expect(k.edgeGeometry).toBe(data.edgeGeometry)
    expect(k.scaleMaterial).toBe(data.scaleMaterial)

    // (Req 17) Unique non-empty string id.
    expect(typeof k.id).toBe('string')
    expect(k.id.length).toBeGreaterThan(0)

    expect(typeof k.photoDataUrl).toBe('string')
    expect(k.photoDataUrl).toMatch(/^data:[^,]*,.+/)

    // (Req 18) First provenance entry stored as the first item in provenanceChain.
    expect(Array.isArray(k.provenanceChain)).toBe(true)
    expect(k.provenanceChain.length).toBeGreaterThanOrEqual(1)
    expect(k.provenanceChain[0].owner).toBe(data.owner)
    expect(isSameIsoDate(k.provenanceChain[0].acquiredOn, data.acquiredOn)).toBe(true)
    expect(k.provenanceChain[0].note).toBe(data.note)

    // sharpeningSessions exists and is an array.
    expect(Array.isArray(k.sharpeningSessions)).toBe(true)

    // (Req 16 + 9) After form submission the new knife must be rendered in the
    // collection view - not just persisted to localStorage. An implementation
    // that writes to storage but never updates React state would fail here.
    await waitFor(() => expect(document.body.textContent).toContain(data.maker))
  })

  it('Requirement 17 (extended): two added knives get distinct non-empty string ids', async () => {
    const App = await importApp()
    render(<App />)

    await fillKnifeEntryFormAndSubmit({
      maker: 'M1', pattern: 'P1', edgeGeometry: 'E1', scaleMaterial: 'S1',
      owner: 'O1', acquiredOn: '2020-01-01', note: 'N1',
    })
    await fillKnifeEntryFormAndSubmit({
      maker: 'M2', pattern: 'P2', edgeGeometry: 'E2', scaleMaterial: 'S2',
      owner: 'O2', acquiredOn: '2020-02-02', note: 'N2',
    })

    const stored = getStoredCollection()
    expect(stored.length).toBe(2)
    // Both ids must be non-empty strings - the prompt requires a "unique
    // string id". Without these type/length assertions, an implementation
    // assigning null + "x" would slip through the simple inequality check.
    expect(typeof stored[0].id).toBe('string')
    expect(stored[0].id.length).toBeGreaterThan(0)
    expect(typeof stored[1].id).toBe('string')
    expect(stored[1].id.length).toBeGreaterThan(0)
    expect(stored[0].id).not.toBe(stored[1].id)
  })
})

// -- Detail view --------------------------------------------------------------

describe('Requirement 20: detail view shows all knife fields, full provenance chain, full sessions', () => {
  it('renders maker, pattern, edgeGeometry, scaleMaterial, photo, every provenance owner and every session date inside the detail view', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A]))
    const App = await importApp()
    render(<App />)

    await screen.findByText(new RegExp(SAMPLE_KNIFE_A.maker))
    await openDetailFor(
      SAMPLE_KNIFE_A.maker,
      SAMPLE_KNIFE_A.pattern,
      undefined,
      [SAMPLE_KNIFE_A.edgeGeometry, SAMPLE_KNIFE_A.scaleMaterial],
    )

    const provenanceOwners = SAMPLE_KNIFE_A.provenanceChain.map((p) => p.owner)
    const detailMarkers = [
      ...provenanceOwners,
      'Add Provenance Entry',
      'Add Sharpening Session',
    ]
    const ownerNodes = await screen.findAllByText(new RegExp(provenanceOwners[provenanceOwners.length - 1]))
    const startNode = (ownerNodes[0] as HTMLElement) || null
    expect(startNode, 'detail view must render the provenance chain').toBeTruthy()

    let detail: HTMLElement | null = startNode
    while (
      detail &&
      !detailMarkers.every((m) => (detail!.textContent || '').includes(m))
    ) {
      detail = detail.parentElement
    }
    expect(
      detail,
      'detail view container must include the full provenance chain and the Add Provenance/Sharpening controls',
    ).toBeTruthy()

    const detailText = detail!.textContent || ''
    expect(detailText).toContain(SAMPLE_KNIFE_A.maker)
    expect(detailText).toContain(SAMPLE_KNIFE_A.pattern)
    expect(detailText).toContain(SAMPLE_KNIFE_A.edgeGeometry)
    expect(detailText).toContain(SAMPLE_KNIFE_A.scaleMaterial)
    for (const p of SAMPLE_KNIFE_A.provenanceChain) {
      expect(detailText).toContain(p.owner)
      expect(detailText).toContain(p.acquiredOn.slice(0, 4))
      expect(detailText).toContain(p.note)
    }
    for (const s of SAMPLE_KNIFE_A.sharpeningSessions) {
      // Same rationale: accept any display format for the session date by
      // checking the year portion. Fixture years 2001 and 2005 are unique here.
      expect(detailText).toContain(s.date.slice(0, 4))
      expect(new RegExp(`\\b${s.angle}\\b`).test(detailText)).toBe(true)
      for (const grit of s.stoneGritProgression) {
        expect(detailText).toContain(String(grit))
      }
    }
    // Photo must be rendered as a visual element inside the detail view.
    expect(hasPhotoRendered(detail!, SAMPLE_KNIFE_A.photoDataUrl), 'photo must be rendered via src/srcset/style attribute in the detail view').toBe(true)
  })
})

describe('Requirement 21: detail view renders provenance chain earliest-acquisition-first', () => {
  it('owners appear in earliest-acquisition-first order (not alphabetical by owner name)', async () => {
    const PROV_ORDER_KNIFE = {
      id: 'k-prov-order',
      maker: 'Maker-ProvOrder-REQ21',
      pattern: 'Pattern-ProvOrder-REQ21',
      edgeGeometry: 'EG-ProvOrder',
      scaleMaterial: 'SM-ProvOrder',
      photoDataUrl: 'data:image/png;base64,PROVORDER',
      provenanceChain: [
        { owner: 'Zara-FirstOwner', acquiredOn: '1955-06-10', note: 'oldest-prov' },
        { owner: 'Mike-SecondOwner', acquiredOn: '1978-11-22', note: 'middle-prov' },
        { owner: 'Alice-ThirdOwner', acquiredOn: '2005-03-15', note: 'newest-prov' },
      ],
      sharpeningSessions: [],
    }
    window.localStorage.setItem('knifeCollection', JSON.stringify([PROV_ORDER_KNIFE]))
    const App = await importApp()
    render(<App />)

    await screen.findByText(new RegExp(PROV_ORDER_KNIFE.maker))
    await openDetailFor(
      PROV_ORDER_KNIFE.maker,
      PROV_ORDER_KNIFE.pattern,
      undefined,
      [PROV_ORDER_KNIFE.edgeGeometry, PROV_ORDER_KNIFE.scaleMaterial],
    )

    await waitFor(() => {
      const owners = PROV_ORDER_KNIFE.provenanceChain.map((p) => p.owner)
      const requiredTexts = [...owners, 'Add Provenance Entry', 'Add Sharpening Session']
      const ctrlEl = Array.from(
        document.querySelectorAll<HTMLElement>('button, a, [role="button"], [role="link"]'),
      ).find((el) => /Add Provenance Entry/.test(el.textContent || ''))
      expect(ctrlEl, 'detail view must expose an "Add Provenance Entry" control').toBeTruthy()
      let detail: HTMLElement | null = ctrlEl || null
      while (detail && !requiredTexts.every((m) => (detail!.textContent || '').includes(m))) {
        detail = detail.parentElement
      }
      expect(detail, 'detail view container must hold all provenance owners and the add controls').toBeTruthy()
      const text = detail!.textContent || ''
      const iFirst = text.indexOf(PROV_ORDER_KNIFE.provenanceChain[0].owner)  // Zara-FirstOwner
      const iSecond = text.indexOf(PROV_ORDER_KNIFE.provenanceChain[1].owner) // Mike-SecondOwner
      const iThird = text.indexOf(PROV_ORDER_KNIFE.provenanceChain[2].owner)  // Alice-ThirdOwner
      expect(iFirst).toBeGreaterThanOrEqual(0)
      expect(iSecond).toBeGreaterThan(iFirst)
      expect(iThird).toBeGreaterThan(iSecond)
    })
  })
})

describe('Requirement 22: detail view renders sharpening sessions earliest-session-first', () => {
  it('session dates appear earliest-first in the rendered detail view (not sorted by session id)', async () => {
    const SESSION_ORDER_KNIFE = {
      id: 'k-sess-order',
      maker: 'Maker-SessOrder-REQ22',
      pattern: 'Pattern-SessOrder-REQ22',
      edgeGeometry: 'EG-SessOrder',
      scaleMaterial: 'SM-SessOrder',
      photoDataUrl: 'data:image/png;base64,SESSORDER',
      provenanceChain: [{ owner: 'Owner-SessOrder', acquiredOn: '2000-01-01', note: 'note' }],
      sharpeningSessions: [
        { id: 's-Z-early', date: '1998-04-12', angle: 15, stoneGritProgression: [400] },
        { id: 's-B-late', date: '2015-09-30', angle: 20, stoneGritProgression: [1000] },
      ],
    }
    window.localStorage.setItem('knifeCollection', JSON.stringify([SESSION_ORDER_KNIFE]))
    const App = await importApp()
    render(<App />)

    await screen.findByText(new RegExp(SESSION_ORDER_KNIFE.maker))
    await openDetailFor(
      SESSION_ORDER_KNIFE.maker,
      SESSION_ORDER_KNIFE.pattern,
      undefined,
      [SESSION_ORDER_KNIFE.edgeGeometry, SESSION_ORDER_KNIFE.scaleMaterial],
    )

    await waitFor(() => {
      const earlyYear = SESSION_ORDER_KNIFE.sharpeningSessions[0].date.slice(0, 4) // '1998'
      const lateYear  = SESSION_ORDER_KNIFE.sharpeningSessions[1].date.slice(0, 4) // '2015'
      const requiredTexts = [earlyYear, lateYear, 'Add Provenance Entry', 'Add Sharpening Session']
      const ctrlEl = Array.from(
        document.querySelectorAll<HTMLElement>('button, a, [role="button"], [role="link"]'),
      ).find((el) => /Add Sharpening Session/.test(el.textContent || ''))
      expect(ctrlEl, 'detail view must expose an "Add Sharpening Session" control').toBeTruthy()
      let detail: HTMLElement | null = ctrlEl || null
      while (detail && !requiredTexts.every((m) => (detail!.textContent || '').includes(m))) {
        detail = detail.parentElement
      }
      expect(detail, 'detail view container must hold both session years and the add controls').toBeTruthy()
      const text = detail!.textContent || ''
      const iEarly = text.indexOf(earlyYear)
      const iLate  = text.indexOf(lateYear)
      expect(iEarly).toBeGreaterThanOrEqual(0)
      expect(iLate).toBeGreaterThan(iEarly)
    })
  })
})

describe('Requirement 21 (extended): provenance order is enforced regardless of stored array order', () => {
  it('rendered provenance order remains earliest-first after appending an entry with an earlier date', async () => {
    // Start with two entries already in date order, then append a new entry
    // backdated before both. An implementation that appends and renders in
    // insertion order would show the 1990 entry last - the wrong order.
    const PROV_BACKDATE = {
      id: 'k-prov-backdate',
      maker: 'Maker-ProvBackdate-REQ21C',
      pattern: 'Pattern-ProvBackdate-REQ21C',
      edgeGeometry: 'EG-ProvBackdate',
      scaleMaterial: 'SM-ProvBackdate',
      photoDataUrl: 'data:image/png;base64,PROVBACKDATE',
      provenanceChain: [
        { owner: 'Owner-BD-2010', acquiredOn: '2010-05-01', note: 'second' },
        { owner: 'Owner-BD-2020', acquiredOn: '2020-08-15', note: 'third' },
      ],
      sharpeningSessions: [],
    }
    window.localStorage.setItem('knifeCollection', JSON.stringify([PROV_BACKDATE]))
    const App = await importApp()
    render(<App />)

    await screen.findByText(new RegExp(PROV_BACKDATE.maker))
    await openDetailFor(
      PROV_BACKDATE.maker,
      PROV_BACKDATE.pattern,
      undefined,
      [PROV_BACKDATE.edgeGeometry, PROV_BACKDATE.scaleMaterial],
    )

    await performAddProvenance({ owner: 'Owner-BD-1990', acquiredOn: '1990-03-20', note: 'first' })

    await waitFor(() => {
      const stored = getStoredCollection()
      const k = stored.find((x: any) => x.id === PROV_BACKDATE.id) || stored[0]
      expect(k.provenanceChain.length).toBe(3)
      expect(k.provenanceChain.some((p: any) => p.owner === 'Owner-BD-1990')).toBe(true)
      // The stored array itself must be ordered earliest acquiredOn first, not
      // merely sorted at render time. ISO date strings compare correctly
      // lexicographically in YYYY-MM-DD form, so a plain array sort suffices.
      const acquiredDates = k.provenanceChain.map((p: any) => p.acquiredOn.slice(0, 10))
      expect(acquiredDates).toEqual([...acquiredDates].sort())
    })

    await openDetailFor(
      PROV_BACKDATE.maker,
      PROV_BACKDATE.pattern,
      undefined,
      [PROV_BACKDATE.edgeGeometry, PROV_BACKDATE.scaleMaterial],
    )

    await waitFor(() => {
      const requiredTexts = [
        'Owner-BD-1990', 'Owner-BD-2010', 'Owner-BD-2020',
        'Add Provenance Entry', 'Add Sharpening Session',
      ]
      const ctrlEl = Array.from(
        document.querySelectorAll<HTMLElement>('button, a, [role="button"], [role="link"]'),
      ).find((el) => /Add Provenance Entry/.test(el.textContent || ''))
      expect(ctrlEl, 'detail view must expose an "Add Provenance Entry" control').toBeTruthy()
      let detail: HTMLElement | null = ctrlEl || null
      while (detail && !requiredTexts.every((m) => (detail!.textContent || '').includes(m))) {
        detail = detail.parentElement
      }
      expect(detail, 'detail view container must hold all provenance owners and the add controls').toBeTruthy()
      const text = detail!.textContent || ''
      const i1990 = text.indexOf('Owner-BD-1990')
      const i2010 = text.indexOf('Owner-BD-2010')
      const i2020 = text.indexOf('Owner-BD-2020')
      expect(i1990).toBeGreaterThanOrEqual(0)
      expect(i2010).toBeGreaterThan(i1990)
      expect(i2020).toBeGreaterThan(i2010)
    })
  })
})

describe('Requirement 22 (extended): session order is enforced regardless of stored array order', () => {
  it('rendered session order remains earliest-first after appending a session with an earlier date', async () => {
    // Start with two sessions already in date order, then append a session
    // backdated before both. An implementation that appends and renders in
    // insertion order would show 2008 last - the wrong order.
    const SESS_BACKDATE = {
      id: 'k-sess-backdate',
      maker: 'Maker-SessBackdate-REQ22C',
      pattern: 'Pattern-SessBackdate-REQ22C',
      edgeGeometry: 'EG-SessBackdate',
      scaleMaterial: 'SM-SessBackdate',
      photoDataUrl: 'data:image/png;base64,SESSBACKDATE',
      provenanceChain: [{ owner: 'Owner-SessBackdate', acquiredOn: '2000-01-01', note: 'note' }],
      sharpeningSessions: [
        { id: 's-bd-2015', date: '2015-06-10', angle: 17, stoneGritProgression: [400, 2000] },
        { id: 's-bd-2022', date: '2022-09-20', angle: 20, stoneGritProgression: [320, 1000] },
      ],
    }
    window.localStorage.setItem('knifeCollection', JSON.stringify([SESS_BACKDATE]))
    const App = await importApp()
    render(<App />)

    await screen.findByText(new RegExp(SESS_BACKDATE.maker))
    await openDetailFor(
      SESS_BACKDATE.maker,
      SESS_BACKDATE.pattern,
      undefined,
      [SESS_BACKDATE.edgeGeometry, SESS_BACKDATE.scaleMaterial],
    )

    await performAddSharpeningSession({ date: '2008-04-03', angle: '15', grits: [220, 800] })

    await waitFor(() => {
      const stored = getStoredCollection()
      const k = stored.find((x: any) => x.id === SESS_BACKDATE.id) || stored[0]
      expect(k.sharpeningSessions.length).toBe(3)
      expect(k.sharpeningSessions.some((s: any) => isSameIsoDate(s.date, '2008-04-03'))).toBe(true)
      // The stored array itself must be ordered earliest date first, not
      // merely sorted at render time. ISO date strings compare correctly
      // lexicographically in YYYY-MM-DD form, so a plain array sort suffices.
      const sessionDates = k.sharpeningSessions.map((s: any) => s.date.slice(0, 10))
      expect(sessionDates).toEqual([...sessionDates].sort())
    })

    await openDetailFor(
      SESS_BACKDATE.maker,
      SESS_BACKDATE.pattern,
      undefined,
      [SESS_BACKDATE.edgeGeometry, SESS_BACKDATE.scaleMaterial],
    )

    await waitFor(() => {
      // Years 2008, 2015, 2022 are unique within this test's DOM.
      const requiredTexts = ['2008', '2015', '2022', 'Add Provenance Entry', 'Add Sharpening Session']
      const ctrlEl = Array.from(
        document.querySelectorAll<HTMLElement>('button, a, [role="button"], [role="link"]'),
      ).find((el) => /Add Sharpening Session/.test(el.textContent || ''))
      expect(ctrlEl, 'detail view must expose an "Add Sharpening Session" control').toBeTruthy()
      let detail: HTMLElement | null = ctrlEl || null
      while (detail && !requiredTexts.every((m) => (detail!.textContent || '').includes(m))) {
        detail = detail.parentElement
      }
      expect(detail, 'detail view container must hold all session years and the add controls').toBeTruthy()
      const text = detail!.textContent || ''
      const i2008 = text.indexOf('2008')
      const i2015 = text.indexOf('2015')
      const i2022 = text.indexOf('2022')
      expect(i2008).toBeGreaterThanOrEqual(0)
      expect(i2015).toBeGreaterThan(i2008)
      expect(i2022).toBeGreaterThan(i2015)
    })
  })
})

// Helper: fill the "Add Provenance Entry" workflow.
async function performAddProvenance(opts: { owner: string; acquiredOn: string; note: string }) {
  function isLikelyVisible(el: HTMLElement): boolean {
    return (
      !el.hasAttribute('hidden') &&
      el.getAttribute('aria-hidden') !== 'true' &&
      el.style.display !== 'none' &&
      el.style.visibility !== 'hidden' &&
      (el as HTMLInputElement).type !== 'hidden'
    )
  }
  const allBefore = new Set(Array.from(document.querySelectorAll('input, textarea')))
  const visibleBefore = new Set(
    Array.from(document.querySelectorAll<HTMLElement>('input, textarea')).filter(isLikelyVisible),
  )

  const promptAnswers = [opts.owner, opts.acquiredOn, opts.note]
  let promptIdx = 0
  const promptSpy = vi.spyOn(window, 'prompt').mockImplementation(() => {
    const v = promptAnswers[promptIdx]
    promptIdx = Math.min(promptIdx + 1, promptAnswers.length - 1)
    return v
  })

  const ctrl = await findControl(/Add Provenance Entry/)
  await userEvent.click(ctrl)
  // Allow any synchronous prompt-based flow to complete.
  await new Promise((r) => setTimeout(r, 5))
  promptSpy.mockRestore()

  // Collect inputs now accessible: brand-new DOM nodes OR pre-rendered nodes
  // that were hidden (via inline style / hidden attr) and are now visible.
  const newInputs = Array.from(document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>(
    'input:not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]), textarea',
  )).filter((el) =>
    !allBefore.has(el) || (!visibleBefore.has(el as HTMLElement) && isLikelyVisible(el as HTMLElement)),
  )

  if (newInputs.length >= 3) {
    function pick(hints: string[]) {
      const lowerHints = hints.map((h) => h.toLowerCase())
      for (const el of newInputs) {
        const labelTextById = (el as HTMLInputElement).id
          ? (document.querySelector(`label[for="${(el as HTMLInputElement).id}"]`)?.textContent || '')
          : ''
        const parentLabel = el.closest('label')?.textContent || ''
        const attrs = [
          (el as HTMLInputElement).name,
          (el as HTMLInputElement).id,
          el.getAttribute('placeholder') || '',
          el.getAttribute('aria-label') || '',
          labelTextById,
          parentLabel,
        ].filter(Boolean).map((s) => s.toLowerCase())
        if (lowerHints.some((h) => attrs.some((a) => a.includes(h)))) return el
      }
      return null
    }
    const ownerInput = pick(['owner']) || newInputs[0]
    const dateInput = pick(['acquiredon', 'acquired', 'date']) || newInputs[1]
    const noteInput = pick(['note']) || newInputs[2]
    await userEvent.clear(ownerInput); await userEvent.type(ownerInput, opts.owner)
    await userEvent.clear(dateInput); await userEvent.type(dateInput, opts.acquiredOn)
    await userEvent.clear(noteInput); await userEvent.type(noteInput, opts.note)

    const buttons = Array.from(document.querySelectorAll<HTMLButtonElement>('button, input[type="submit"]'))
    const submit = buttons.find((b) => {
      const txt = (b.textContent || (b as HTMLInputElement).value || '').toLowerCase().trim()
      return (b as HTMLInputElement).type === 'submit' ||
        /save|submit|confirm|done|append|create/.test(txt) ||
        txt === 'add' || txt === 'ok'
    }) || buttons.find((b) => {
      const txt = (b.textContent || (b as HTMLInputElement).value || '').toLowerCase().trim()
      return !/add provenance entry/i.test(txt) && !/cancel|back|close|discard/i.test(txt) && txt.length > 0
    })
    if (submit) {
      await act(async () => { await userEvent.click(submit); await new Promise((r) => setTimeout(r, 5)) })
    }
  } else {
    function pickGlobal(hints: string[]) {
      const lower = hints.map((h) => h.toLowerCase())
      return Array.from(document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>(
        'input:not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="hidden"]), textarea',
      )).find((el) => {
        const labelById = el.id ? (document.querySelector(`label[for="${el.id}"]`)?.textContent || '') : ''
        const attrs = [
          (el as HTMLInputElement).name || '',
          el.id || '',
          el.getAttribute('placeholder') || '',
          el.getAttribute('aria-label') || '',
          labelById,
          el.closest('label')?.textContent || '',
        ].filter(Boolean).map((s) => s.toLowerCase())
        return lower.some((h) => attrs.some((a) => a.includes(h)))
      }) || null
    }
    const ownerEl = pickGlobal(['owner'])
    const dateEl = pickGlobal(['acquiredon', 'acquired', 'date'])
    const noteEl = pickGlobal(['note'])
    if (ownerEl && dateEl && noteEl) {
      await userEvent.clear(ownerEl); await userEvent.type(ownerEl, opts.owner)
      await userEvent.clear(dateEl); await userEvent.type(dateEl, opts.acquiredOn)
      await userEvent.clear(noteEl); await userEvent.type(noteEl, opts.note)
      const btns = Array.from(document.querySelectorAll<HTMLButtonElement>('button, input[type="submit"]'))
      const sub = btns.find((b) => {
        const txt = (b.textContent || (b as HTMLInputElement).value || '').toLowerCase().trim()
        return (b as HTMLInputElement).type === 'submit' ||
          /save|submit|confirm|done|append|create/.test(txt) ||
          txt === 'add' || txt === 'ok'
      }) || btns.find((b) => {
        const txt = (b.textContent || (b as HTMLInputElement).value || '').toLowerCase().trim()
        return !/add provenance entry/i.test(txt) && !/cancel|back|close|discard/i.test(txt) && txt.length > 0
      })
      if (sub) {
        await act(async () => { await userEvent.click(sub); await new Promise((r) => setTimeout(r, 5)) })
      }
    }
  }
}

describe('Requirements 24-26: Add Provenance Entry appends a new entry and persists', () => {
  it('appending a provenance entry stores the new entry on the knife and persists collection', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A]))
    const App = await importApp()
    render(<App />)

    await screen.findByText(new RegExp(SAMPLE_KNIFE_A.maker))
    await openDetailFor(SAMPLE_KNIFE_A.maker, SAMPLE_KNIFE_A.pattern, undefined, [SAMPLE_KNIFE_A.edgeGeometry, SAMPLE_KNIFE_A.scaleMaterial])

    const initial = getStoredCollection()
    const initialChainLen = initial[0].provenanceChain.length

    await performAddProvenance({
      owner: 'NEW-PROV-OWNER',
      acquiredOn: '2024-09-09',
      note: 'NEW-PROV-NOTE',
    })

    await waitFor(() => {
      const stored = getStoredCollection()
      const k = stored.find((x: any) => x.id === SAMPLE_KNIFE_A.id) || stored[0]
      expect(Array.isArray(k.provenanceChain)).toBe(true)
      expect(k.provenanceChain.length).toBe(initialChainLen + 1)
      // The new entry must be present with the values we entered.
      // acquiredOn is compared on its calendar-date portion to accept any
      // valid ISO date string form (date-only or full datetime).
      const found = k.provenanceChain.find((p: any) =>
        p.owner === 'NEW-PROV-OWNER' &&
        isSameIsoDate(p.acquiredOn, '2024-09-09') &&
        p.note === 'NEW-PROV-NOTE')
      expect(found).toBeTruthy()
      // The new entry must be appended - it must be the last element in the chain.
      const lastEntry = k.provenanceChain[k.provenanceChain.length - 1]
      expect(lastEntry.owner).toBe('NEW-PROV-OWNER')
    })

    // (Req 25 + 20) The updated provenance chain must be visible in the detail
    // view. Re-open in case the implementation navigated away after saving.
    await openDetailFor(SAMPLE_KNIFE_A.maker, SAMPLE_KNIFE_A.pattern, undefined, [SAMPLE_KNIFE_A.edgeGeometry, SAMPLE_KNIFE_A.scaleMaterial])
    await waitFor(() => expect(document.body.textContent).toContain('NEW-PROV-OWNER'))
  })
})

async function performAddSharpeningSession(opts: { date: string; angle: string; grits: number[] }) {
  function isLikelyVisible(el: HTMLElement): boolean {
    return (
      !el.hasAttribute('hidden') &&
      el.getAttribute('aria-hidden') !== 'true' &&
      el.style.display !== 'none' &&
      el.style.visibility !== 'hidden' &&
      (el as HTMLInputElement).type !== 'hidden'
    )
  }
  const allBefore = new Set(Array.from(document.querySelectorAll('input, textarea, select')))
  const visibleBefore = new Set(
    Array.from(document.querySelectorAll<HTMLElement>('input, textarea, select')).filter(isLikelyVisible),
  )

  // Support window.prompt-based workflows: date -> angle -> each grit value.
  const promptAnswers = [opts.date, opts.angle, ...opts.grits.map(String), opts.grits.join(', ')]
  let promptIdx = 0
  const promptSpy = vi.spyOn(window, 'prompt').mockImplementation(() => {
    const v = promptAnswers[Math.min(promptIdx, promptAnswers.length - 1)]
    promptIdx += 1
    return v
  })
  const ctrl = await findControl(/Add Sharpening Session/)
  await userEvent.click(ctrl)
  await new Promise((r) => setTimeout(r, 5))
  promptSpy.mockRestore()

  // Collect inputs now accessible: brand-new DOM nodes OR pre-rendered nodes
  // that were hidden (via inline style / hidden attr) and are now visible.
  const newInputs = Array.from(document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>(
    'input:not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]), textarea, select',
  )).filter((el) =>
    !allBefore.has(el) || (!visibleBefore.has(el as HTMLElement) && isLikelyVisible(el as HTMLElement)),
  )
  if (newInputs.length >= 3) {
    function hintsOf(el: HTMLElement) {
      const labelById = el.id ? (document.querySelector(`label[for="${el.id}"]`)?.textContent || '') : ''
      return [
        (el as HTMLInputElement).name || '',
        el.id || '',
        el.getAttribute('placeholder') || '',
        el.getAttribute('aria-label') || '',
        labelById,
        el.closest('label')?.textContent || '',
      ].join(' ').toLowerCase()
    }
    function pick(hints: string[]) {
      const lower = hints.map((h) => h.toLowerCase())
      for (const el of newInputs) {
        const h = hintsOf(el)
        if (lower.some((n) => h.includes(n))) return el
      }
      return null
    }
    const dateInput = pick(['date']) || newInputs[0]
    const angleInput = pick(['angle']) || newInputs[1]
    await userEvent.clear(dateInput); await userEvent.type(dateInput, opts.date)
    await userEvent.clear(angleInput); await userEvent.type(angleInput, opts.angle)

    // Find grit input(s). The agent may use a single input parsed by either
    // commas or whitespace, OR multiple distinct inputs. We try each
    // strategy in order and accept any that succeeds.
    const usedSet = new Set<HTMLElement>([dateInput, angleInput])
    const gritEls = newInputs.filter((el) => {
      if (usedSet.has(el)) return false
      const h = hintsOf(el)
      return /grit|stone|progression/.test(h)
    })
    const remaining = newInputs.filter((el) => !usedSet.has(el))

    if (gritEls.length >= opts.grits.length) {
      // Multiple grit inputs.
      for (let i = 0; i < opts.grits.length; i++) {
        await userEvent.clear(gritEls[i]); await userEvent.type(gritEls[i], String(opts.grits[i]))
      }
    } else if (gritEls.length === 1) {
      // Single grit input - try comma+space separated values.
      await userEvent.clear(gritEls[0])
      await userEvent.type(gritEls[0], opts.grits.join(', '))
    } else if (remaining.length >= opts.grits.length) {
      // Fallback: positional fill into the remaining inputs.
      for (let i = 0; i < opts.grits.length; i++) {
        await userEvent.clear(remaining[i]); await userEvent.type(remaining[i], String(opts.grits[i]))
      }
    } else if (remaining.length === 1) {
      await userEvent.clear(remaining[0])
      await userEvent.type(remaining[0], opts.grits.join(', '))
    }

    // Find a submit-style button (not the "Add Sharpening Session" toggle).
    // Catch-all fallback covers any valid label not in the keyword list.
    const buttons = Array.from(document.querySelectorAll<HTMLButtonElement>('button, input[type="submit"]'))
    const submit = buttons.find((b) => {
      const txt = (b.textContent || (b as HTMLInputElement).value || '').toLowerCase().trim()
      return (b as HTMLInputElement).type === 'submit' ||
        /save|submit|confirm|done|append|create/.test(txt) ||
        txt === 'add' || txt === 'ok' || txt === 'log'
    }) || buttons.find((b) => {
      const txt = (b.textContent || (b as HTMLInputElement).value || '').toLowerCase().trim()
      return !/add sharpening session/i.test(txt) && !/cancel|back|close|discard/i.test(txt) && txt.length > 0
    })
    if (submit) {
      await act(async () => { await userEvent.click(submit); await new Promise((r) => setTimeout(r, 5)) })
    }
  } else {
    function hintsOfGlobal(el: HTMLElement) {
      const labelById = el.id ? (document.querySelector(`label[for="${el.id}"]`)?.textContent || '') : ''
      return [
        (el as HTMLInputElement).name || '',
        el.id || '',
        el.getAttribute('placeholder') || '',
        el.getAttribute('aria-label') || '',
        labelById,
        el.closest('label')?.textContent || '',
      ].join(' ').toLowerCase()
    }
    function pickGlobal(hints: string[], excludeSet: Set<HTMLElement> = new Set()) {
      const lower = hints.map((h) => h.toLowerCase())
      return Array.from(document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>(
        'input:not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="hidden"]), textarea, select',
      )).find((el) => {
        if (excludeSet.has(el as HTMLElement)) return false
        const h = hintsOfGlobal(el as HTMLElement)
        return lower.some((n) => h.includes(n))
      }) || null
    }
    const allGlobal = Array.from(document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>(
      'input:not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="hidden"]), textarea, select',
    ))
    const dateEl = pickGlobal(['date']) || allGlobal[0]
    const used = new Set<HTMLElement>([dateEl].filter(Boolean) as HTMLElement[])
    const angleEl = pickGlobal(['angle'], used) || allGlobal[1]
    if (dateEl) { await userEvent.clear(dateEl); await userEvent.type(dateEl, opts.date) }
    if (angleEl) { await userEvent.clear(angleEl); await userEvent.type(angleEl, opts.angle) }
    used.add(angleEl as HTMLElement)
    const gritElsG = allGlobal.filter((el) => !used.has(el as HTMLElement) && /grit|stone|progression/.test(hintsOfGlobal(el as HTMLElement)))
    const remainingG = allGlobal.filter((el) => !used.has(el as HTMLElement))
    if (gritElsG.length >= opts.grits.length) {
      for (let i = 0; i < opts.grits.length; i++) { await userEvent.clear(gritElsG[i]); await userEvent.type(gritElsG[i], String(opts.grits[i])) }
    } else if (gritElsG.length === 1) {
      await userEvent.clear(gritElsG[0]); await userEvent.type(gritElsG[0], opts.grits.join(', '))
    } else if (remainingG.length >= opts.grits.length) {
      for (let i = 0; i < opts.grits.length; i++) { await userEvent.clear(remainingG[i]); await userEvent.type(remainingG[i], String(opts.grits[i])) }
    } else if (remainingG.length === 1) {
      await userEvent.clear(remainingG[0]); await userEvent.type(remainingG[0], opts.grits.join(', '))
    }
    const btns = Array.from(document.querySelectorAll<HTMLButtonElement>('button, input[type="submit"]'))
    const sub = btns.find((b) => {
      const txt = (b.textContent || (b as HTMLInputElement).value || '').toLowerCase().trim()
      return (b as HTMLInputElement).type === 'submit' ||
        /save|submit|confirm|done|append|create/.test(txt) ||
        txt === 'add' || txt === 'ok' || txt === 'log'
    }) || btns.find((b) => {
      const txt = (b.textContent || (b as HTMLInputElement).value || '').toLowerCase().trim()
      return !/add sharpening session/i.test(txt) && !/cancel|back|close|discard/i.test(txt) && txt.length > 0
    })
    if (sub) {
      await act(async () => { await userEvent.click(sub); await new Promise((r) => setTimeout(r, 5)) })
    }
  }
}

describe('Requirements 28-31: Add Sharpening Session captures fields, appends with unique id, stores grit order, persists', () => {
  it('appending a session stores date/angle/grit progression as an ordered list and persists', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A]))
    const App = await importApp()
    render(<App />)
    await screen.findByText(new RegExp(SAMPLE_KNIFE_A.maker))
    await openDetailFor(SAMPLE_KNIFE_A.maker, SAMPLE_KNIFE_A.pattern, undefined, [SAMPLE_KNIFE_A.edgeGeometry, SAMPLE_KNIFE_A.scaleMaterial])

    const initial = getStoredCollection()
    const initialLen = initial[0].sharpeningSessions.length
    const initialIds = new Set(initial[0].sharpeningSessions.map((s: any) => s.id))

    await performAddSharpeningSession({
      date: '2026-07-08',
      angle: '19',
      grits: [320, 1000, 6000],
    })

    await waitFor(() => {
      const stored = getStoredCollection()
      const k = stored.find((x: any) => x.id === SAMPLE_KNIFE_A.id) || stored[0]
      // (Req 29) Appended new session.
      expect(k.sharpeningSessions.length).toBe(initialLen + 1)
      const added = k.sharpeningSessions.find((s: any) => !initialIds.has(s.id))
      expect(added).toBeTruthy()
      // (Req 28) Captured date and angle.
      // date must be an ISO date string representing 2026-07-08; multiple
      // ISO forms are accepted as long as the calendar date matches.
      expect(isSameIsoDate(added.date, '2026-07-08')).toBe(true)
      expect(typeof added.angle).toBe('number')
      expect(added.angle).toBe(19)
      // (Req 29) Unique non-empty string id.
      expect(typeof added.id).toBe('string')
      expect(added.id.length).toBeGreaterThan(0)
      // (Req 30) stoneGritProgression is an ordered list of numbers preserving
      // the user-supplied order (coarsest-first to finest-last).
      expect(Array.isArray(added.stoneGritProgression)).toBe(true)
      expect(added.stoneGritProgression.length).toBe(3)
      added.stoneGritProgression.forEach((v: any) => {
        expect(typeof v === 'number' && !Number.isNaN(v)).toBe(true)
      })
      expect(added.stoneGritProgression).toEqual([320, 1000, 6000])
      // The new session must be appended - it must be the last element in the list.
      const lastSession = k.sharpeningSessions[k.sharpeningSessions.length - 1]
      expect(lastSession.id).toBe(added.id)
    })

    await openDetailFor(SAMPLE_KNIFE_A.maker, SAMPLE_KNIFE_A.pattern, undefined, [SAMPLE_KNIFE_A.edgeGeometry, SAMPLE_KNIFE_A.scaleMaterial])
    await waitFor(() => expect(document.body.textContent).toContain('2026'))
  })

  it('Requirement 29 (extended): two sharpening sessions added to the same knife receive distinct ids', async () => {
    // SAMPLE_KNIFE_B has an empty sharpeningSessions array, giving a clean
    // baseline for counting and id-comparison.
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_B]))
    const App = await importApp()
    render(<App />)
    await screen.findByText(new RegExp(SAMPLE_KNIFE_B.maker))
    await openDetailFor(SAMPLE_KNIFE_B.maker, SAMPLE_KNIFE_B.pattern, undefined, [SAMPLE_KNIFE_B.edgeGeometry, SAMPLE_KNIFE_B.scaleMaterial])

    await performAddSharpeningSession({ date: '2026-03-01', angle: '19', grits: [400, 1500, 6000] })

    // Re-enter the detail view in case the implementation navigated away after saving.
    await openDetailFor(SAMPLE_KNIFE_B.maker, SAMPLE_KNIFE_B.pattern, undefined, [SAMPLE_KNIFE_B.edgeGeometry, SAMPLE_KNIFE_B.scaleMaterial])

    await performAddSharpeningSession({ date: '2026-04-02', angle: '21', grits: [320, 2000, 8000] })

    await waitFor(() => {
      const stored = getStoredCollection()
      const k = stored.find((x: any) => x.id === SAMPLE_KNIFE_B.id) || stored[0]
      expect(k.sharpeningSessions.length).toBe(2)
      expect(typeof k.sharpeningSessions[0].id).toBe('string')
      expect(k.sharpeningSessions[0].id.length).toBeGreaterThan(0)
      expect(typeof k.sharpeningSessions[1].id).toBe('string')
      expect(k.sharpeningSessions[1].id.length).toBeGreaterThan(0)
      expect(k.sharpeningSessions[0].id).not.toBe(k.sharpeningSessions[1].id)
    })
  })
})

// -- Printable Display Card Export -------------------------------------------

async function navigateToPrintViewIfNeeded() {
  const has = () =>
    Array.from(document.querySelectorAll('*')).some((el) =>
      /Print Display Cards/.test(el.textContent || ''),
    )
  if (has()) return
  const candidates = Array.from(
    document.querySelectorAll<HTMLElement>('button, a, [role="tab"], [role="link"], [role="button"]'),
  ).filter((el) => {
    const t = (el.textContent || '').trim()
    if (!t) return false
    if (/print display cards/i.test(t)) return false
    return /print|display card|export|cards/i.test(t)
  })
  for (const el of candidates) {
    await userEvent.click(el)
    if (has()) return
  }
}

function findPrintSection(
  printBtn: HTMLElement,
  requiredTexts: string[],
): HTMLElement {
  let el: HTMLElement | null = printBtn.parentElement as HTMLElement | null
  while (el && el.parentElement) {
    const t = el.textContent || ''
    if (requiredTexts.every((s) => t.includes(s))) return el
    el = el.parentElement as HTMLElement | null
  }
  return document.body
}

function findDisplayCard(root: HTMLElement, maker: string, lastOwner: string): HTMLElement {
  const re = new RegExp(lastOwner.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
  const candidates = Array.from(root.querySelectorAll<HTMLElement>('*')).filter(
    (el) => re.test(el.textContent || ''),
  )
  for (const node of candidates) {
    let el: HTMLElement | null = node as HTMLElement
    while (el && el !== root && !(el.textContent || '').includes(maker)) {
      el = el.parentElement
    }
    if (el && el !== root) return el
  }
  throw new Error(`expected to find a display card container with ${maker} and ${lastOwner}`)
}

describe('Requirements 32-34: printable display card export view', () => {
  it('renders a display card per knife with required fields and last-provenance owner, plus a "Print Display Cards" control', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A, SAMPLE_KNIFE_B]))
    const App = await importApp()
    render(<App />)
    await screen.findByText(new RegExp(SAMPLE_KNIFE_A.maker))
    await navigateToPrintViewIfNeeded()

    // (Req 34) The Print Display Cards control must exist somewhere in the UI.
    const printControl = await findControl(/Print Display Cards/)
    expect(printControl).toBeInTheDocument()

    const lastOwnerA = SAMPLE_KNIFE_A.provenanceChain[SAMPLE_KNIFE_A.provenanceChain.length - 1].owner
    const lastOwnerB = SAMPLE_KNIFE_B.provenanceChain[SAMPLE_KNIFE_B.provenanceChain.length - 1].owner

    await waitFor(() => {
      const text = document.body.textContent || ''
      expect(text).toContain(SAMPLE_KNIFE_A.maker)
      expect(text).toContain(SAMPLE_KNIFE_B.maker)
      // Last-provenance owner must be present in the print view.
      expect(text).toContain(lastOwnerA)
      expect(text).toContain(lastOwnerB)
    })

    const printSection = findPrintSection(
      printControl as HTMLElement,
      [SAMPLE_KNIFE_A.maker, SAMPLE_KNIFE_B.maker, lastOwnerA, lastOwnerB],
    )

    // Req 32: locate each knife's display card within the print section and
    // verify they are distinct, per-knife containers.
    const cardA = findDisplayCard(printSection, SAMPLE_KNIFE_A.maker, lastOwnerA)
    const cardB = findDisplayCard(printSection, SAMPLE_KNIFE_B.maker, lastOwnerB)
    expect(cardA).not.toBe(cardB)
    expect(cardA.textContent).not.toContain(SAMPLE_KNIFE_B.maker)
    expect(cardB.textContent).not.toContain(SAMPLE_KNIFE_A.maker)

    // Req 33: each display card container must directly render all required
    // fields - maker, pattern, edge geometry, scale material, photo, and
    // the last-provenance owner.
    for (const [card, knife, lastOwner] of [
      [cardA, SAMPLE_KNIFE_A, lastOwnerA],
      [cardB, SAMPLE_KNIFE_B, lastOwnerB],
    ] as const) {
      expect(card.textContent).toContain(knife.maker)
      expect(card.textContent).toContain(knife.pattern)
      expect(card.textContent).toContain(knife.edgeGeometry)
      expect(card.textContent).toContain(knife.scaleMaterial)
      expect(card.textContent).toContain(lastOwner)
      // Photo must be rendered as a visual element in the display card.
      expect(hasPhotoRendered(card, knife.photoDataUrl), 'photo must be rendered via src/srcset/style attribute in the display card').toBe(true)
    }
  })
})

describe('Requirement 35: "Print Display Cards" invokes window.print()', () => {
  it('clicking the Print Display Cards control calls window.print()', async () => {
    window.localStorage.setItem('knifeCollection', JSON.stringify([SAMPLE_KNIFE_A]))
    const printSpy = vi.spyOn(window, 'print').mockImplementation(() => {})
    const App = await importApp()
    render(<App />)
    await navigateToPrintViewIfNeeded()
    const ctrl = await findControl(/Print Display Cards/)
    const callsBefore = printSpy.mock.calls.length
    await userEvent.click(ctrl)
    expect(printSpy.mock.calls.length).toBeGreaterThan(callsBefore)
  })
})