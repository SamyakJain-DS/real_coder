import { describe, it, expect, vi, beforeEach } from 'vitest'

describe('Requirement 5: App default export', () => {
  it('src/App.tsx default-exports a React component named App', async () => {
    const src = ['/app', 'src', 'App'].join('/')
    const mod = await import(/* @vite-ignore */ src)
    expect(mod).toBeTruthy()
    const Default: any = (mod as any).default
    expect(Default, 'src/App.tsx must default-export a value').toBeDefined()
    // React components are either a function (function/arrow component) or a
    // forwardRef/memo object with $$typeof. Accept both.
    const isFunction = typeof Default === 'function'
    const isComponentObject =
      Default && typeof Default === 'object' && '$$typeof' in Default
    expect(isFunction || isComponentObject).toBe(true)

    // The exported component should be reachable by the identifier `App`.
    // Accept any of: function name, displayName, or memo/forwardRef wrapped
    // inner component name.
    const inner = (Default && (Default as any).type) || null
    const name =
      (typeof Default === 'function' && Default.name) ||
      (Default && (Default as any).displayName) ||
      (typeof inner === 'function' && inner.name) ||
      (inner && (inner as any).displayName) ||
      ''
    expect(name).toBe('App')
  })
})

describe('Requirement 6: main.tsx mounts App into the #root element', () => {
  beforeEach(() => {
    document.body.innerHTML = '<div id="root"></div>'
    vi.resetModules()
  })

  it('calls ReactDOM.createRoot on the element with id "root" and renders App into it', async () => {
    // Import App before setting up the react-dom/client mock so that the
    // same module reference is in the cache when main.tsx executes.
    const appSrc = ['/app', 'src', 'App'].join('/')
    const AppModule = await import(/* @vite-ignore */ appSrc)
    const AppComponent = (AppModule as any).default

    const createRootSpy = vi.fn(() => ({ render: vi.fn(), unmount: vi.fn() }))

    // Mock react-dom/client.createRoot so we can capture the call.
    vi.doMock('react-dom/client', async () => {
      const actual: any = await vi.importActual('react-dom/client')
      return { ...actual, createRoot: createRootSpy, default: { ...actual, createRoot: createRootSpy } }
    })

    // Import main.tsx - it should run side-effectfully and mount the app.
    const mainSrc = ['/app', 'src', 'main'].join('/')
    await import(/* @vite-ignore */ mainSrc)

    expect(createRootSpy).toHaveBeenCalled()
    const firstArg = createRootSpy.mock.calls[0][0] as Element
    expect(firstArg).toBeInstanceOf(Element)
    expect((firstArg as Element).id).toBe('root')

    // Verify root.render() was called with an element that IS or CONTAINS
    // the App component. Allows valid wrapping such as
    // <React.StrictMode><App /></React.StrictMode>.
    const returnedRoot = createRootSpy.mock.results[0].value as { render: any }
    expect(returnedRoot.render).toHaveBeenCalled()
    const renderArg = returnedRoot.render.mock.calls[0][0]
    expect(renderArg).toBeTruthy()

    function containsType(el: any, type: any): boolean {
      if (!el || typeof el !== 'object') return false
      if (el.type === type) return true
      const children = el.props?.children
      if (!children) return false
      const arr = Array.isArray(children) ? children : [children]
      return arr.some((c: any) => containsType(c, type))
    }
    expect(
      containsType(renderArg, AppComponent),
      'root.render() must be called with the App component (possibly wrapped in providers)',
    ).toBe(true)
  })
})
