import { describe, it, expect } from "vitest";
import { loadModule, defaultTheme, bytesEqual } from "./helpers";

describe("Deterministic Behavior Contract", () => {
  it("D1: equal markdown input produces equal parse output across repeated calls (Determinism #1)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# A\nbody\n---\n# B\nbody";
      const a = compiler.parse(md);
      const b = compiler.parse(md);
      if (JSON.stringify(a) !== JSON.stringify(b))
        throw new Error("parse output not deterministic");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("D2: equal markdown + equal theme produces equal HTML across repeated calls (Determinism #1)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# A\nbody";
      const deck = compiler.parse(md);
      const a = compiler.renderHtml(deck, { accentColor: "#abcdef" });
      const b = compiler.renderHtml(deck, { accentColor: "#abcdef" });
      if (a !== b) throw new Error("HTML output not deterministic");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("D3: two independent compiler instances configured with the same default theme produce equal compile() output for equal inputs (Determinism #1, #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const md = "# A\nbody A\n---\n# B\nbody B";
      const themeOverride = { accentColor: "#abcdef" };

      const compilerA = new mod.SlideDeckCompiler(defaultTheme());
      const compilerB = new mod.SlideDeckCompiler(defaultTheme());

      const resultA = await compilerA.compile(md, themeOverride);
      const resultB = await compilerB.compile(md, themeOverride);

      if (JSON.stringify(resultA.deck) !== JSON.stringify(resultB.deck))
        throw new Error(
          "deck output differs between two independent compiler instances",
        );
      if (resultA.html !== resultB.html)
        throw new Error(
          "html output differs between two independent compiler instances",
        );
      if (!bytesEqual(resultA.pdf, resultB.pdf))
        throw new Error(
          `pdf bytes differ between two independent compiler instances (lenA=${resultA.pdf.length}, lenB=${resultB.pdf.length})`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("D4: slide `order` values returned by parse() are not mutated by subsequent renderHtml or renderPdf calls (Determinism #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = ["# Z", "---", "# Y", "---", "# X"].join("\n");
      const deck = compiler.parse(md);

      const ordersBeforeRender = deck.slides.map((s: any) => s.order);

      compiler.renderHtml(deck, {});
      await compiler.renderPdf(deck, {}, md);

      const ordersAfterRender = deck.slides.map((s: any) => s.order);
      if (
        JSON.stringify(ordersBeforeRender) !==
        JSON.stringify(ordersAfterRender)
      )
        throw new Error(
          `slide.order mutated by rendering: before=${JSON.stringify(ordersBeforeRender)} after=${JSON.stringify(ordersAfterRender)}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});
