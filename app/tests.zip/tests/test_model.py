import pytest

from nacha.model import (
    NachaFile, Batch, Entry,
    FileHeader, BatchHeader, EntryDetail, Addenda, BatchControl, FileControl,
)
from nacha.rules import OdfiRuleSet, ValidationIssue

from tests.helpers import (
    file_header_line, batch_header_line, entry_detail_line,
    addenda_line, batch_control_line, file_control_line,
)


# Common dataclass kwargs builders -------------------------------------------

def _file_header(**over):
    base = dict(
        record_type_code="1",
        priority_code="01",
        immediate_destination=" 071000000",
        immediate_origin=" 071000001",
        file_creation_date="240115",
        file_creation_time="0900",
        file_id_modifier="A",
        record_size="094",
        blocking_factor="10",
        format_code="1",
        immediate_destination_name="BANK NAME              ",
        immediate_origin_name="COMPANY NAME           ",
        reference_code="        ",
        raw=file_header_line(),
    )
    base.update(over)
    return FileHeader(**base)


def _batch_header(**over):
    base = dict(
        record_type_code="5",
        service_class_code="200",
        company_name="COMPANY NAME    ",
        company_discretionary_data="                    ",
        company_identification="1234567890",
        sec_code="PPD",
        company_entry_description="PAYROLL   ",
        company_descriptive_date="240115",
        effective_entry_date="240116",
        settlement_date="   ",
        originator_status_code="1",
        originating_dfi_identification="07100000",
        batch_number="0000001",
        raw=batch_header_line(),
    )
    base.update(over)
    return BatchHeader(**base)


def _entry_detail(**over):
    base = dict(
        record_type_code="6",
        transaction_code="22",
        receiving_dfi_identification="07100000",
        check_digit="0",
        dfi_account_number="ACCT123456789    ",
        amount=10000,
        individual_identification_number="ID12345        ",
        individual_name="JOHN DOE              ",
        discretionary_data="  ",
        addenda_record_indicator="0",
        trace_number="071000000000001",
        raw=entry_detail_line(),
    )
    base.update(over)
    return EntryDetail(**base)


def _addenda(**over):
    base = dict(
        record_type_code="7",
        addenda_type_code="05",
        payload=" " * 80,
        addenda_sequence_number="0001",
        entry_detail_sequence_number="0000001",
        raw=addenda_line(),
    )
    base.update(over)
    return Addenda(**base)


def _batch_control(**over):
    base = dict(
        record_type_code="8",
        service_class_code="200",
        entry_addenda_count=1,
        entry_hash="0007100000",
        total_debit=0,
        total_credit=10000,
        company_identification="1234567890",
        message_authentication_code="                   ",
        reserved="      ",
        originating_dfi_identification="07100000",
        batch_number="0000001",
        raw=batch_control_line(),
    )
    base.update(over)
    return BatchControl(**base)


def _file_control(**over):
    base = dict(
        record_type_code="9",
        batch_count=1,
        block_count=1,
        entry_addenda_count=1,
        entry_hash="0007100000",
        total_debit=0,
        total_credit=10000,
        reserved=" " * 39,
        raw=file_control_line(),
    )
    base.update(over)
    return FileControl(**base)


# ---------------------------------------------------------------------------
# Leaf record dataclasses
# ---------------------------------------------------------------------------

def test_file_header_constructor_and_attributes():
    fh = _file_header()
    assert fh.record_type_code == "1"
    assert fh.priority_code == "01"
    assert fh.immediate_destination == " 071000000"
    assert fh.immediate_origin == " 071000001"
    assert fh.file_creation_date == "240115"
    assert fh.file_creation_time == "0900"
    assert fh.file_id_modifier == "A"
    assert fh.record_size == "094"
    assert fh.blocking_factor == "10"
    assert fh.format_code == "1"
    assert fh.immediate_destination_name == "BANK NAME              "
    assert fh.immediate_origin_name == "COMPANY NAME           "
    assert fh.reference_code == "        "
    assert fh.raw == file_header_line()


def test_batch_header_constructor_and_attributes():
    bh = _batch_header()
    assert bh.record_type_code == "5"
    assert bh.service_class_code == "200"
    assert bh.company_name == "COMPANY NAME    "
    assert bh.company_discretionary_data == "                    "
    assert bh.company_identification == "1234567890"
    assert bh.sec_code == "PPD"
    assert bh.company_entry_description == "PAYROLL   "
    assert bh.company_descriptive_date == "240115"
    assert bh.effective_entry_date == "240116"
    assert bh.settlement_date == "   "
    assert bh.originator_status_code == "1"
    assert bh.originating_dfi_identification == "07100000"
    assert bh.batch_number == "0000001"
    assert bh.raw == batch_header_line()


def test_entry_detail_constructor_and_attributes():
    ed = _entry_detail()
    assert ed.record_type_code == "6"
    assert ed.transaction_code == "22"
    assert ed.receiving_dfi_identification == "07100000"
    assert ed.check_digit == "0"
    assert ed.dfi_account_number == "ACCT123456789    "
    assert ed.amount == 10000
    assert ed.individual_identification_number == "ID12345        "
    assert ed.individual_name == "JOHN DOE              "
    assert ed.discretionary_data == "  "
    assert ed.addenda_record_indicator == "0"
    assert ed.trace_number == "071000000000001"
    assert ed.raw == entry_detail_line()


def test_addenda_constructor_and_attributes():
    a = _addenda()
    assert a.record_type_code == "7"
    assert a.addenda_type_code == "05"
    assert a.payload == " " * 80
    assert a.addenda_sequence_number == "0001"
    assert a.entry_detail_sequence_number == "0000001"
    assert a.raw == addenda_line()


def test_batch_control_constructor_and_attributes():
    bc = _batch_control()
    assert bc.record_type_code == "8"
    assert bc.service_class_code == "200"
    assert bc.entry_addenda_count == 1
    assert bc.entry_hash == "0007100000"
    assert bc.total_debit == 0
    assert bc.total_credit == 10000
    assert bc.company_identification == "1234567890"
    assert bc.message_authentication_code == "                   "
    assert bc.reserved == "      "
    assert bc.originating_dfi_identification == "07100000"
    assert bc.batch_number == "0000001"
    assert bc.raw == batch_control_line()


def test_file_control_constructor_and_attributes():
    fc = _file_control()
    assert fc.record_type_code == "9"
    assert fc.batch_count == 1
    assert fc.block_count == 1
    assert fc.entry_addenda_count == 1
    assert fc.entry_hash == "0007100000"
    assert fc.total_debit == 0
    assert fc.total_credit == 10000
    assert fc.reserved == " " * 39
    assert fc.raw == file_control_line()


# ---------------------------------------------------------------------------
# Aggregate dataclasses
# ---------------------------------------------------------------------------

def test_entry_constructor_and_attributes():
    ed = _entry_detail()
    a1 = _addenda()
    e = Entry(entry_detail=ed, addenda=[a1])
    assert e.entry_detail == ed
    assert e.addenda == [a1]


def test_batch_constructor_and_attributes():
    bh = _batch_header()
    bc = _batch_control()
    e = Entry(entry_detail=_entry_detail(), addenda=[])
    b = Batch(batch_header=bh, entries=[e], batch_control=bc)
    assert b.batch_header == bh
    assert b.batch_control == bc
    assert b.entries == [e]


def test_nacha_file_constructor_and_attributes():
    fh = _file_header()
    fc = _file_control()
    f = NachaFile(
        file_header=fh,
        batches=[],
        file_control=fc,
        block_padding=["9" * 94],
        line_terminator="\n",
    )
    assert f.file_header == fh
    assert f.file_control == fc
    assert f.batches == []
    assert f.block_padding == ["9" * 94]
    assert f.line_terminator == "\n"


# ---------------------------------------------------------------------------
# Rule set / issue dataclasses
# ---------------------------------------------------------------------------

def test_odfi_rule_set_constructor_required_fields():
    rs = OdfiRuleSet(
        permitted_immediate_origins=["A"],
        permitted_immediate_destinations=["B"],
        permitted_company_ids=["C"],
    )
    assert rs.permitted_immediate_origins == ["A"]
    assert rs.permitted_immediate_destinations == ["B"]
    assert rs.permitted_company_ids == ["C"]


def test_odfi_rule_set_default_enforce_flags_are_true():
    rs = OdfiRuleSet(
        permitted_immediate_origins=[],
        permitted_immediate_destinations=[],
        permitted_company_ids=[],
    )
    assert rs.enforce_structural is True
    assert rs.enforce_control_fields is True
    assert rs.enforce_sec_addenda_content is True


def test_odfi_rule_set_enforce_flags_can_be_overridden():
    rs = OdfiRuleSet(
        permitted_immediate_origins=[],
        permitted_immediate_destinations=[],
        permitted_company_ids=[],
        enforce_structural=False,
        enforce_control_fields=False,
        enforce_sec_addenda_content=False,
    )
    assert rs.enforce_structural is False
    assert rs.enforce_control_fields is False
    assert rs.enforce_sec_addenda_content is False


def test_validation_issue_constructor_and_attributes():
    issue = ValidationIssue(
        rule="control.batch_total_credit",
        message="Mismatch in batch credit total",
        line_number=4,
        record_type="8",
    )
    assert issue.rule == "control.batch_total_credit"
    assert issue.message == "Mismatch in batch credit total"
    assert issue.line_number == 4
    assert issue.record_type == "8"
