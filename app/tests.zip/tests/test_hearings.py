import uuid
import pytest
from conftest import create_insurer, create_filing


class TestPublicHearings:
    def test_create_hearing_success(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/filings/{filing['filing_id']}/hearings",
            json={
                "hearing_date": "2025-03-15",
                "location": "State Capitol Building",
                "hearing_officer": "Judge Martinez",
                "notice_published_date": "2025-02-01",
            },
        )
        assert resp.status_code == 201

    def test_create_hearing_returns_required_fields(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/filings/{filing['filing_id']}/hearings",
            json={
                "hearing_date": "2025-04-15T10:00:00",
                "location": "City Hall",
                "hearing_officer": "Officer Lee",
                "notice_published_date": "2025-03-01",
            },
        )
        data = resp.json()
        assert "hearing_id" in data
        assert isinstance(data["hearing_id"], str)
        uuid.UUID(data["hearing_id"])  # raises ValueError if not a valid UUID
        assert data["filing_id"] == filing["filing_id"]
        assert data["location"] == "City Hall"
        assert data["hearing_officer"] == "Officer Lee"
        assert data["status"] == "scheduled"
        assert data["hearing_date"] == "2025-04-15T10:00:00"
        assert data["notice_published_date"] == "2025-03-01"

    def test_create_hearing_rejected_less_than_30_days(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/filings/{filing['filing_id']}/hearings",
            json={
                "hearing_date": "2025-02-15",
                "location": "Court Room",
                "hearing_officer": "Judge Brown",
                "notice_published_date": "2025-02-01",
            },
        )
        assert resp.status_code == 400

    def test_create_hearing_exactly_30_days_ok(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/filings/{filing['filing_id']}/hearings",
            json={
                "hearing_date": "2025-03-03",
                "location": "Main Office",
                "hearing_officer": "Officer Adams",
                "notice_published_date": "2025-02-01",
            },
        )
        assert resp.status_code == 201

    def test_create_hearing_filing_not_found(self, client):
        resp = client.post(
            "/api/filings/nonexistent-filing/hearings",
            json={
                "hearing_date": "2025-06-01",
                "location": "Room A",
                "hearing_officer": "Judge X",
                "notice_published_date": "2025-04-01",
            },
        )
        assert resp.status_code == 404

    def test_get_hearings_for_filing(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        client.post(
            f"/api/filings/{filing['filing_id']}/hearings",
            json={
                "hearing_date": "2025-05-01",
                "location": "Location A",
                "hearing_officer": "Officer One",
                "notice_published_date": "2025-03-15",
            },
        )
        client.post(
            f"/api/filings/{filing['filing_id']}/hearings",
            json={
                "hearing_date": "2025-06-01",
                "location": "Location B",
                "hearing_officer": "Officer Two",
                "notice_published_date": "2025-04-15",
            },
        )
        resp = client.get(f"/api/filings/{filing['filing_id']}/hearings")
        assert resp.status_code == 200
        hearings = resp.json()
        assert isinstance(hearings, list)
        assert len(hearings) == 2

    def test_get_hearings_filing_not_found(self, client):
        resp = client.get("/api/filings/nonexistent-filing/hearings")
        assert resp.status_code == 404

    def test_create_hearing_datetime_exactly_30_calendar_days_accepted(self, client):
        # hearing_date carries a time component; the calendar date is exactly 30 days after
        # notice_published_date (2025-02-01 -> 2025-03-03).
        # Feb 2025 has 28 days: Feb 1 -> Mar 3 = 30 calendar days.
        # An implementation that computes the gap in seconds would see < 30*24h and wrongly
        # reject - this test asserts calendar-date-only comparison is used.
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/filings/{filing['filing_id']}/hearings",
            json={
                "hearing_date": "2025-03-03T00:00:01",
                "location": "State Office",
                "hearing_officer": "Officer Calendar",
                "notice_published_date": "2025-02-01",
            },
        )
        assert resp.status_code == 201

    def test_create_hearing_datetime_29_calendar_days_rejected(self, client):
        # hearing_date is 2025-03-02T23:59:59: calendar day is March 2 = 29 days after
        # Feb 1, even though the elapsed seconds are nearly 30 * 24h.
        # The calendar-date-only rule must reject this.
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/filings/{filing['filing_id']}/hearings",
            json={
                "hearing_date": "2025-03-02T23:59:59",
                "location": "State Office",
                "hearing_officer": "Officer Calendar",
                "notice_published_date": "2025-02-01",
            },
        )
        assert resp.status_code == 400
