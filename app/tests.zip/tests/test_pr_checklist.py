from __future__ import annotations

import dataclasses
import io
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

import pytest
import yaml

from conftest import import_public, VALID_CONFIG_DICT


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _make_triggered_rule(rule_id: str, name_or_items, items_or_files=None, matched_files=None):
    """Unified helper supporting both call signatures used across checker and renderer tests.

    Checker-style (3 positional args):
        _make_triggered_rule(rule_id, items, matched_files)
        -- arg 2 is a list; rule name defaults to rule_id

    Renderer-style (4 positional args):
        _make_triggered_rule(rule_id, rule_name, items, matched_files)
        -- arg 2 is a str
    """
    Rule = import_public("pr_checklist.config", "Rule")
    Trigger = import_public("pr_checklist.config", "Trigger")
    ChecklistItem = import_public("pr_checklist.config", "ChecklistItem")
    TriggeredRule = import_public("pr_checklist.matcher", "TriggeredRule")

    if isinstance(name_or_items, str):
        # Renderer-style: (rule_id, rule_name, items, matched_files)
        rule_name = name_or_items
        items = items_or_files
        files = matched_files
    else:
        # Checker-style: (rule_id, items, matched_files)
        rule_name = rule_id
        items = name_or_items
        files = items_or_files

    checklist = [ChecklistItem(key=k, text=t) for k, t in items]
    trigger = Trigger(extensions=[], paths=[], patterns=[])
    rule = Rule(id=rule_id, name=rule_name, trigger=trigger, checklist=checklist)
    return TriggeredRule(rule=rule, matched_files=sorted(files))


def _make_changed_file(path: str, status: str = "modified"):
    ChangedFile = import_public("pr_checklist.diff_parser", "ChangedFile")
    return ChangedFile(path=path, status=status)


def _make_config(rules_data: list[dict]) -> object:
    load_config = import_public("pr_checklist.config", "load_config")
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump({"rules": rules_data}, f)
        f.flush()
        return load_config(Path(f.name))


def _write_config(tmp_path: Path) -> Path:
    p = tmp_path / "checklist.yaml"
    p.write_text(yaml.dump(VALID_CONFIG_DICT, default_flow_style=False))
    return p


def _write_diff(tmp_path: Path) -> Path:
    diff = textwrap.dedent("""\
        diff --git a/frontend/Button.tsx b/frontend/Button.tsx
        new file mode 100644
        index 0000000..abc1234
        --- /dev/null
        +++ b/frontend/Button.tsx
        @@ -0,0 +1,3 @@
        +export const Button = () => {
        +  return <button>Click</button>;
        +};
    """)
    p = tmp_path / "pr.diff"
    p.write_text(diff)
    return p


def _write_description(tmp_path: Path, content: str) -> Path:
    p = tmp_path / "pr_description.md"
    p.write_text(content)
    return p


# ---------------------------------------------------------------------------
# test_checker
# ---------------------------------------------------------------------------

def test_check_description_all_items_addressed_returns_pass():
    check_description = import_public("pr_checklist.checker", "check_description")

    triggered = [
        _make_triggered_rule("r1", [("k1", "Item 1"), ("k2", "Item 2")], ["a.py"])
    ]
    description = (
        "- [x] Item 1 <!-- checklist:k1 -->\n"
        "- [x] Item 2 <!-- checklist:k2 -->\n"
    )

    result = check_description(triggered, description)

    assert result.passed is True
    assert "k1" in result.addressed
    assert "k2" in result.addressed
    assert len(result.missing) == 0


def test_check_description_missing_items_returns_fail():
    check_description = import_public("pr_checklist.checker", "check_description")

    triggered = [
        _make_triggered_rule("r1", [("k1", "Item 1"), ("k2", "Item 2")], ["a.py"])
    ]
    description = "- [x] Item 1 <!-- checklist:k1 -->\n- [ ] Item 2 <!-- checklist:k2 -->\n"

    result = check_description(triggered, description)

    assert result.passed is False
    assert "k1" in result.addressed
    assert "k2" in result.missing


def test_check_description_recognizes_uppercase_x_checkbox():
    check_description = import_public("pr_checklist.checker", "check_description")

    triggered = [
        _make_triggered_rule("r1", [("k1", "Item 1")], ["a.py"])
    ]
    description = "- [X] Item 1 <!-- checklist:k1 -->\n"

    result = check_description(triggered, description)

    assert result.passed is True
    assert "k1" in result.addressed


def test_check_description_no_triggered_rules_returns_pass():
    check_description = import_public("pr_checklist.checker", "check_description")

    result = check_description([], "Some PR description text")

    assert result.passed is True
    assert len(result.addressed) == 0
    assert len(result.missing) == 0


def test_check_description_missing_marker_counts_as_not_addressed():
    check_description = import_public("pr_checklist.checker", "check_description")

    triggered = [
        _make_triggered_rule("r1", [("k1", "Item 1")], ["a.py"])
    ]
    description = "This PR has no checklist markers at all.\n"

    result = check_description(triggered, description)

    assert result.passed is False
    assert "k1" in result.missing


def test_check_description_unchecked_checkbox_counts_as_not_addressed():
    check_description = import_public("pr_checklist.checker", "check_description")

    triggered = [
        _make_triggered_rule("r1", [("k1", "Item 1")], ["a.py"])
    ]
    description = "- [ ] Item 1 <!-- checklist:k1 -->\n"

    result = check_description(triggered, description)

    assert result.passed is False
    assert "k1" in result.missing


def test_check_result_has_passed_addressed_missing_fields():
    check_description = import_public("pr_checklist.checker", "check_description")
    CheckResult = import_public("pr_checklist.checker", "CheckResult")

    triggered = [
        _make_triggered_rule("r1", [("k1", "Item")], ["f.py"])
    ]
    description = "- [x] Item <!-- checklist:k1 -->\n"

    result = check_description(triggered, description)

    assert isinstance(result, CheckResult)
    assert result.passed is True
    assert result.addressed == ["k1"]
    assert result.missing == []


def test_check_description_preserves_configuration_order_in_lists():
    check_description = import_public("pr_checklist.checker", "check_description")

    triggered = [
        _make_triggered_rule("r1", [("alpha", "A"), ("beta", "B")], ["f.py"]),
        _make_triggered_rule("r2", [("gamma", "C")], ["g.py"]),
    ]
    description = (
        "- [x] A <!-- checklist:alpha -->\n"
        "- [ ] B <!-- checklist:beta -->\n"
        "- [x] C <!-- checklist:gamma -->\n"
    )

    result = check_description(triggered, description)

    assert result.addressed == ["alpha", "gamma"]
    assert result.missing == ["beta"]


def test_check_description_marker_and_checkbox_must_be_on_same_line():
    check_description = import_public("pr_checklist.checker", "check_description")

    triggered = [
        _make_triggered_rule("r1", [("k1", "Item 1")], ["a.py"])
    ]
    # [x] is on one line; the marker is on the very next line.
    # Because they are not on the same line, the item must NOT be treated as addressed.
    description = (
        "- [x] Item 1\n"
        "<!-- checklist:k1 -->\n"
    )

    result = check_description(triggered, description)

    assert result.passed is False
    assert "k1" in result.missing


# ---------------------------------------------------------------------------
# test_cli
# ---------------------------------------------------------------------------

def test_cli_generate_writes_markdown_to_stdout(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    config_file = _write_config(tmp_path)
    diff_file = _write_diff(tmp_path)

    exit_code = main(["generate", "--config", str(config_file), "--diff", str(diff_file)])

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "## PR Checklist" in captured.out
    assert "### Frontend Accessibility" in captured.out


def test_cli_check_pass_output_includes_item_count(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    config = {
        "rules": [
            {
                "id": "py-rule",
                "name": "Python Rule",
                "trigger": {"extensions": [".py"], "paths": [], "patterns": []},
                "checklist": [
                    {"key": "py-k1", "text": "First check"},
                ],
            }
        ]
    }
    config_file = tmp_path / "config.yaml"
    config_file.write_text(yaml.dump(config, default_flow_style=False))
    diff = textwrap.dedent("""\
        diff --git a/module.py b/module.py
        index 0000000..1111111 100644
        --- a/module.py
        +++ b/module.py
        @@ -1 +1 @@
        -old
        +new
    """)
    diff_file = tmp_path / "pr.diff"
    diff_file.write_text(diff)
    desc_file = tmp_path / "desc.md"
    desc_file.write_text("- [x] First check <!-- checklist:py-k1 -->\n")

    exit_code = main([
        "check", "--config", str(config_file),
        "--diff", str(diff_file),
        "--description", str(desc_file),
    ])

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "PR Checklist: PASS - 1 of 1 items addressed." in captured.out


def test_cli_check_fails_when_items_missing(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    config_file = _write_config(tmp_path)
    diff_file = _write_diff(tmp_path)
    desc_file = _write_description(tmp_path, "No checklist markers here.\n")

    exit_code = main([
        "check", "--config", str(config_file),
        "--diff", str(diff_file), "--description", str(desc_file),
    ])

    assert exit_code == 1
    captured = capsys.readouterr()
    assert "PR Checklist: FAIL - 0 of 2 items addressed." in captured.out
    assert "  - Verify ARIA attributes on interactive elements (key: a11y-aria)" in captured.out
    assert "  - Check color contrast ratios (key: a11y-contrast)" in captured.out


def test_cli_check_fail_output_format_and_missing_item_lines(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    config = {
        "rules": [
            {
                "id": "py-rule",
                "name": "Python Rule",
                "trigger": {"extensions": [".py"], "paths": [], "patterns": []},
                "checklist": [
                    {"key": "py-k1", "text": "First check"},
                    {"key": "py-k2", "text": "Second check"},
                ],
            }
        ]
    }
    config_file = tmp_path / "config.yaml"
    config_file.write_text(yaml.dump(config, default_flow_style=False))
    diff = textwrap.dedent("""\
        diff --git a/module.py b/module.py
        index 0000000..1111111 100644
        --- a/module.py
        +++ b/module.py
        @@ -1 +1 @@
        -old
        +new
    """)
    diff_file = tmp_path / "pr.diff"
    diff_file.write_text(diff)
    desc_file = tmp_path / "desc.md"
    desc_file.write_text("- [x] First check <!-- checklist:py-k1 -->\n")

    exit_code = main([
        "check", "--config", str(config_file),
        "--diff", str(diff_file),
        "--description", str(desc_file),
    ])

    assert exit_code == 1
    captured = capsys.readouterr()
    assert "PR Checklist: FAIL - 1 of 2 items addressed." in captured.out
    assert "Missing items:" in captured.out
    assert "  - Second check (key: py-k2)" in captured.out


def test_cli_exits_2_for_missing_config_file(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    diff_file = _write_diff(tmp_path)

    exit_code = main([
        "generate", "--config", str(tmp_path / "nonexistent.yaml"),
        "--diff", str(diff_file),
    ])

    assert exit_code == 2
    captured = capsys.readouterr()
    assert f"Error: Configuration file not found: {tmp_path / 'nonexistent.yaml'}" in captured.err


def test_cli_exits_2_for_missing_diff_file(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    config_file = _write_config(tmp_path)

    exit_code = main([
        "generate", "--config", str(config_file),
        "--diff", str(tmp_path / "nonexistent.diff"),
    ])

    assert exit_code == 2
    captured = capsys.readouterr()
    assert f"Error: Diff file not found: {tmp_path / 'nonexistent.diff'}" in captured.err


def test_cli_exits_2_for_missing_description_file(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    config_file = _write_config(tmp_path)
    diff_file = _write_diff(tmp_path)

    exit_code = main([
        "check", "--config", str(config_file),
        "--diff", str(diff_file),
        "--description", str(tmp_path / "nonexistent.md"),
    ])

    assert exit_code == 2
    captured = capsys.readouterr()
    assert f"Error: Description file not found: {tmp_path / 'nonexistent.md'}" in captured.err


def test_cli_exits_2_for_invalid_yaml(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    bad_yaml = tmp_path / "bad.yaml"
    bad_yaml.write_text(": : : [invalid yaml\n")
    diff_file = _write_diff(tmp_path)

    exit_code = main([
        "generate", "--config", str(bad_yaml), "--diff", str(diff_file),
    ])

    assert exit_code == 2
    captured = capsys.readouterr()
    assert "Error: Invalid YAML in configuration file." in captured.err


def test_cli_exits_2_for_schema_validation_error(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    # Valid YAML syntax but fails schema validation - missing required "rules" key.
    bad_schema = tmp_path / "bad_schema.yaml"
    bad_schema.write_text(yaml.dump({"version": 1}))
    diff_file = _write_diff(tmp_path)

    exit_code = main([
        "generate", "--config", str(bad_schema), "--diff", str(diff_file),
    ])

    assert exit_code == 2
    captured = capsys.readouterr()
    assert "Configuration missing required key: rules" in captured.err


def test_cli_check_reports_pass_when_no_items_triggered(tmp_path: Path, capsys):
    main = import_public("pr_checklist.cli", "main")
    config = {
        "rules": [
            {
                "id": "js-only",
                "name": "JS Rule",
                "trigger": {"extensions": [".js"], "paths": [], "patterns": []},
                "checklist": [{"key": "js-check", "text": "JS check"}],
            }
        ]
    }
    config_file = tmp_path / "config.yaml"
    config_file.write_text(yaml.dump(config, default_flow_style=False))
    diff = textwrap.dedent("""\
        diff --git a/readme.md b/readme.md
        index 0000000..1111111 100644
        --- a/readme.md
        +++ b/readme.md
        @@ -1 +1 @@
        -old
        +new
    """)
    diff_file = tmp_path / "pr.diff"
    diff_file.write_text(diff)
    desc_file = _write_description(tmp_path, "No checklist needed.\n")

    exit_code = main([
        "check", "--config", str(config_file),
        "--diff", str(diff_file), "--description", str(desc_file),
    ])

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "PR Checklist: PASS - 0 items triggered." in captured.out


def test_cli_generate_reads_diff_from_stdin(tmp_path: Path, capsys, monkeypatch):
    main = import_public("pr_checklist.cli", "main")
    config_file = _write_config(tmp_path)
    diff_text = _write_diff(tmp_path).read_text()

    monkeypatch.setattr("sys.stdin", io.StringIO(diff_text))

    exit_code = main(["generate", "--config", str(config_file)])  # --diff omitted

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "## PR Checklist" in captured.out
    assert "Frontend Accessibility" in captured.out


def test_cli_check_reads_diff_from_stdin(tmp_path: Path, capsys, monkeypatch):
    main = import_public("pr_checklist.cli", "main")
    config_file = _write_config(tmp_path)
    diff_text = _write_diff(tmp_path).read_text()
    desc_file = _write_description(tmp_path, (
        "- [x] Verify ARIA attributes on interactive elements <!-- checklist:a11y-aria -->\n"
        "- [x] Check color contrast ratios <!-- checklist:a11y-contrast -->\n"
    ))

    monkeypatch.setattr("sys.stdin", io.StringIO(diff_text))

    exit_code = main([
        "check", "--config", str(config_file), "--description", str(desc_file),
    ])  # --diff omitted

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "PR Checklist: PASS - 2 of 2 items addressed." in captured.out


def test_module_invocation_via_python_m(tmp_path: Path):
    config_file = _write_config(tmp_path)
    diff_file = _write_diff(tmp_path)

    result = subprocess.run(
        [
            sys.executable, "-m", "pr_checklist",
            "generate", "--config", str(config_file), "--diff", str(diff_file),
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
    )

    assert result.returncode == 0
    assert "## PR Checklist" in result.stdout
    assert "### Frontend Accessibility" in result.stdout


def test_cli_main_with_argv_none_uses_sys_argv(tmp_path: Path, capsys, monkeypatch):
    main = import_public("pr_checklist.cli", "main")
    config_file = _write_config(tmp_path)
    diff_file = _write_diff(tmp_path)

    monkeypatch.setattr("sys.argv", [
        "pr_checklist", "generate",
        "--config", str(config_file),
        "--diff", str(diff_file),
    ])

    exit_code = main(None)

    assert exit_code == 0
    captured = capsys.readouterr()
    assert "## PR Checklist" in captured.out
    assert "### Frontend Accessibility" in captured.out


# ---------------------------------------------------------------------------
# test_config
# ---------------------------------------------------------------------------

def test_package_root_re_exports_all_thirteen_public_symbols():
    # Every documented public symbol must be importable from pr_checklist and
    # must be the identical object as the one on its source submodule, confirming
    # the re-export is a live reference and not a stub or reimplementation.
    pairs = [
        ("pr_checklist.config",      "load_config"),
        ("pr_checklist.config",      "ChecklistConfig"),
        ("pr_checklist.config",      "Rule"),
        ("pr_checklist.config",      "Trigger"),
        ("pr_checklist.config",      "ChecklistItem"),
        ("pr_checklist.config",      "ConfigError"),
        ("pr_checklist.diff_parser", "parse_diff"),
        ("pr_checklist.diff_parser", "ChangedFile"),
        ("pr_checklist.matcher",     "match_rules"),
        ("pr_checklist.matcher",     "TriggeredRule"),
        ("pr_checklist.renderer",    "render_markdown"),
        ("pr_checklist.checker",     "check_description"),
        ("pr_checklist.checker",     "CheckResult"),
    ]
    for submodule, name in pairs:
        from_submodule = import_public(submodule, name)
        from_package = import_public("pr_checklist", name)
        assert from_submodule is from_package, (
            f"pr_checklist.{name} is not the same object as {submodule}.{name}"
        )


def test_load_config_returns_checklist_config_with_parsed_rules(config_path: Path):
    load_config = import_public("pr_checklist.config", "load_config")
    ChecklistConfig = import_public("pr_checklist.config", "ChecklistConfig")

    result = load_config(config_path)

    assert isinstance(result, ChecklistConfig)
    assert len(result.rules) == 3
    assert result.rules[0].id == "frontend-a11y"
    assert result.rules[0].name == "Frontend Accessibility"
    assert len(result.rules[0].trigger.extensions) == 3
    assert len(result.rules[0].checklist) == 2
    assert result.rules[0].checklist[0].key == "a11y-aria"


def test_load_config_raises_config_error_when_rules_key_missing(tmp_path: Path):
    load_config = import_public("pr_checklist.config", "load_config")
    ConfigError = import_public("pr_checklist.config", "ConfigError")

    config_file = tmp_path / "bad.yaml"
    config_file.write_text(yaml.dump({"version": 1}))

    with pytest.raises(ConfigError, match="Configuration missing required key: rules"):
        load_config(config_file)


def test_load_config_raises_config_error_for_missing_rule_field(tmp_path: Path):
    load_config = import_public("pr_checklist.config", "load_config")
    ConfigError = import_public("pr_checklist.config", "ConfigError")

    base_rule = {
        "id": "r1",
        "name": "Rule One",
        "trigger": {"extensions": [], "paths": [], "patterns": []},
        "checklist": [{"key": "k1", "text": "t1"}],
    }

    for field in ("id", "name", "trigger", "checklist"):
        rule = {k: v for k, v in base_rule.items() if k != field}
        config_file = tmp_path / f"missing_rule_{field}.yaml"
        config_file.write_text(yaml.dump({"rules": [rule]}))
        with pytest.raises(ConfigError, match=rf"Rule at index 0 missing required field: {field}"):
            load_config(config_file)


def test_load_config_raises_config_error_for_missing_trigger_field(tmp_path: Path):
    load_config = import_public("pr_checklist.config", "load_config")
    ConfigError = import_public("pr_checklist.config", "ConfigError")

    base_trigger = {"extensions": [".py"], "paths": [], "patterns": []}

    for field in ("extensions", "paths", "patterns"):
        trigger = {k: v for k, v in base_trigger.items() if k != field}
        config_file = tmp_path / f"missing_trigger_{field}.yaml"
        config_file.write_text(yaml.dump({
            "rules": [{
                "id": "r1",
                "name": "Rule One",
                "trigger": trigger,
                "checklist": [{"key": "k1", "text": "t1"}],
            }]
        }))
        with pytest.raises(ConfigError, match=rf"Rule 'r1' trigger missing required field: {field}"):
            load_config(config_file)


def test_load_config_raises_config_error_for_missing_checklist_item_field(tmp_path: Path):
    load_config = import_public("pr_checklist.config", "load_config")
    ConfigError = import_public("pr_checklist.config", "ConfigError")

    for field, item in [("key", {"text": "Item text"}), ("text", {"key": "k1"})]:
        config_file = tmp_path / f"missing_item_{field}.yaml"
        config_file.write_text(yaml.dump({
            "rules": [{
                "id": "r1",
                "name": "Rule One",
                "trigger": {"extensions": [], "paths": [], "patterns": []},
                "checklist": [item],
            }]
        }))
        with pytest.raises(ConfigError, match=rf"Rule 'r1' checklist item at index 0 missing required field: {field}"):
            load_config(config_file)


def test_load_config_raises_config_error_for_duplicate_rule_id(tmp_path: Path):
    load_config = import_public("pr_checklist.config", "load_config")
    ConfigError = import_public("pr_checklist.config", "ConfigError")

    bad_config = {
        "rules": [
            {
                "id": "dup",
                "name": "First",
                "trigger": {"extensions": [], "paths": [], "patterns": []},
                "checklist": [{"key": "k1", "text": "t1"}],
            },
            {
                "id": "dup",
                "name": "Second",
                "trigger": {"extensions": [], "paths": [], "patterns": []},
                "checklist": [{"key": "k2", "text": "t2"}],
            },
        ]
    }
    config_file = tmp_path / "bad.yaml"
    config_file.write_text(yaml.dump(bad_config))

    with pytest.raises(ConfigError, match=r"Duplicate rule id: dup"):
        load_config(config_file)


def test_load_config_raises_config_error_for_duplicate_checklist_key(tmp_path: Path):
    load_config = import_public("pr_checklist.config", "load_config")
    ConfigError = import_public("pr_checklist.config", "ConfigError")

    bad_config = {
        "rules": [
            {
                "id": "r1",
                "name": "First",
                "trigger": {"extensions": [".py"], "paths": [], "patterns": []},
                "checklist": [{"key": "shared-key", "text": "Item in rule 1"}],
            },
            {
                "id": "r2",
                "name": "Second",
                "trigger": {"extensions": [".js"], "paths": [], "patterns": []},
                "checklist": [{"key": "shared-key", "text": "Item in rule 2"}],
            },
        ]
    }
    config_file = tmp_path / "bad.yaml"
    config_file.write_text(yaml.dump(bad_config))

    with pytest.raises(ConfigError, match=r"Duplicate checklist item key: shared-key"):
        load_config(config_file)


def test_config_error_is_exception_subclass():
    ConfigError = import_public("pr_checklist.config", "ConfigError")

    assert issubclass(ConfigError, Exception)
    err = ConfigError("test message")
    assert str(err) == "test message"


def test_load_config_propagates_yaml_error_for_invalid_yaml(tmp_path: Path):
    load_config = import_public("pr_checklist.config", "load_config")

    bad_yaml_file = tmp_path / "invalid.yaml"
    bad_yaml_file.write_text(": : : [invalid yaml\n")

    with pytest.raises(yaml.YAMLError):
        load_config(bad_yaml_file)


def test_config_dataclasses_are_frozen(config_path: Path):
    load_config = import_public("pr_checklist.config", "load_config")

    config = load_config(config_path)

    with pytest.raises(dataclasses.FrozenInstanceError):
        config.rules = []
    with pytest.raises(dataclasses.FrozenInstanceError):
        config.rules[0].id = "changed"
    with pytest.raises(dataclasses.FrozenInstanceError):
        config.rules[0].trigger.extensions = []
    with pytest.raises(dataclasses.FrozenInstanceError):
        config.rules[0].checklist[0].key = "changed"


def test_diff_parser_and_result_dataclasses_are_frozen():
    ChangedFile = import_public("pr_checklist.diff_parser", "ChangedFile")
    Rule = import_public("pr_checklist.config", "Rule")
    Trigger = import_public("pr_checklist.config", "Trigger")
    TriggeredRule = import_public("pr_checklist.matcher", "TriggeredRule")
    CheckResult = import_public("pr_checklist.checker", "CheckResult")

    changed_file = ChangedFile(path="a.py", status="modified")
    with pytest.raises(dataclasses.FrozenInstanceError):
        changed_file.path = "b.py"

    trigger = Trigger(extensions=[], paths=[], patterns=[])
    rule = Rule(id="r1", name="R1", trigger=trigger, checklist=[])
    triggered_rule = TriggeredRule(rule=rule, matched_files=[])
    with pytest.raises(dataclasses.FrozenInstanceError):
        triggered_rule.matched_files = ["new.py"]

    check_result = CheckResult(passed=True, addressed=[], missing=[])
    with pytest.raises(dataclasses.FrozenInstanceError):
        check_result.passed = False


# ---------------------------------------------------------------------------
# test_diff_parser
# ---------------------------------------------------------------------------

def test_parse_diff_empty_input_returns_empty_list():
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")

    result = parse_diff("")

    assert result == []


def test_parse_diff_extracts_added_file():
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")
    diff = textwrap.dedent("""\
        diff --git a/src/new_module.py b/src/new_module.py
        new file mode 100644
        index 0000000..abc1234
        --- /dev/null
        +++ b/src/new_module.py
        @@ -0,0 +1,3 @@
        +def hello():
        +    pass
    """)

    result = parse_diff(diff)

    assert len(result) == 1
    assert result[0].path == "src/new_module.py"
    assert result[0].status == "added"


def test_parse_diff_extracts_modified_file():
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")
    diff = textwrap.dedent("""\
        diff --git a/src/existing.py b/src/existing.py
        index aaa1111..bbb2222 100644
        --- a/src/existing.py
        +++ b/src/existing.py
        @@ -1,3 +1,4 @@
         def hello():
        -    pass
        +    print("hello")
        +    return True
    """)

    result = parse_diff(diff)

    assert len(result) == 1
    assert result[0].path == "src/existing.py"
    assert result[0].status == "modified"


def test_parse_diff_extracts_deleted_file():
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")
    diff = textwrap.dedent("""\
        diff --git a/docs/old.md b/docs/old.md
        deleted file mode 100644
        index ccc3333..0000000
        --- a/docs/old.md
        +++ /dev/null
        @@ -1,2 +0,0 @@
        -# Old doc
        -Remove this
    """)

    result = parse_diff(diff)

    assert len(result) == 1
    assert result[0].path == "docs/old.md"
    assert result[0].status == "deleted"


def test_parse_diff_extracts_renamed_file_with_destination_path():
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")
    diff = textwrap.dedent("""\
        diff --git a/old_name.py b/new_name.py
        similarity index 95%
        rename from old_name.py
        rename to new_name.py
        index ddd4444..eee5555 100644
        --- a/old_name.py
        +++ b/new_name.py
        @@ -1,3 +1,3 @@
         def func():
        -    pass
        +    return 1
    """)

    result = parse_diff(diff)

    assert len(result) == 1
    assert result[0].path == "new_name.py"
    assert result[0].status == "renamed"


def test_parse_diff_handles_binary_file():
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")
    diff = textwrap.dedent("""\
        diff --git a/assets/logo.png b/assets/logo.png
        new file mode 100644
        index 0000000..fff6666
        Binary files /dev/null and b/assets/logo.png differ
    """)

    result = parse_diff(diff)

    assert len(result) == 1
    assert result[0].path == "assets/logo.png"
    assert result[0].status == "added"


def test_parse_diff_handles_binary_deleted_file():
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")
    diff = textwrap.dedent("""\
        diff --git a/assets/logo.png b/assets/logo.png
        deleted file mode 100644
        index fff6666..0000000
        Binary files a/assets/logo.png and /dev/null differ
    """)

    result = parse_diff(diff)

    assert len(result) == 1
    assert result[0].path == "assets/logo.png"
    assert result[0].status == "deleted"


def test_parse_diff_handles_binary_modified_file():
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")
    diff = textwrap.dedent("""\
        diff --git a/assets/logo.png b/assets/logo.png
        index abc1234..def5678 100644
        Binary files a/assets/logo.png and b/assets/logo.png differ
    """)

    result = parse_diff(diff)

    assert len(result) == 1
    assert result[0].path == "assets/logo.png"
    assert result[0].status == "modified"


def test_parse_diff_extracts_multiple_files(sample_diff_text: str):
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")

    result = parse_diff(sample_diff_text)

    assert len(result) == 4
    paths = [f.path for f in result]
    assert "frontend/Button.tsx" in paths
    assert "migrations/0002_add_column.py" in paths
    assert "backend/api/routes.py" in paths
    assert "README.md" in paths


def test_parse_diff_changed_file_dataclass_has_path_and_status():
    parse_diff = import_public("pr_checklist.diff_parser", "parse_diff")
    ChangedFile = import_public("pr_checklist.diff_parser", "ChangedFile")
    diff = textwrap.dedent("""\
        diff --git a/file.py b/file.py
        index 0000000..1111111 100644
        --- a/file.py
        +++ b/file.py
        @@ -1 +1 @@
        -old
        +new
    """)

    result = parse_diff(diff)

    assert len(result) == 1
    assert isinstance(result[0], ChangedFile)
    assert result[0].path == "file.py"
    assert result[0].status == "modified"


# ---------------------------------------------------------------------------
# test_matcher
# ---------------------------------------------------------------------------

def test_match_rules_triggers_by_extension_case_insensitive():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([
        {
            "id": "py-rule",
            "name": "Python Rule",
            "trigger": {"extensions": [".py"], "paths": [], "patterns": []},
            "checklist": [{"key": "py-check", "text": "Check Python"}],
        }
    ])
    files = [_make_changed_file("src/module.PY")]

    result = match_rules(files, config)

    assert len(result) == 1
    assert result[0].rule.id == "py-rule"
    assert "src/module.PY" in result[0].matched_files


def test_match_rules_extension_is_last_dot_segment_of_filename():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config_gz = _make_config([{
        "id": "gz-rule", "name": "GZ Rule",
        "trigger": {"extensions": [".gz"], "paths": [], "patterns": []},
        "checklist": [{"key": "gz-check", "text": "GZ check"}],
    }])
    config_tar = _make_config([{
        "id": "tar-rule", "name": "TAR Rule",
        "trigger": {"extensions": [".tar"], "paths": [], "patterns": []},
        "checklist": [{"key": "tar-check", "text": "TAR check"}],
    }])
    config_py = _make_config([{
        "id": "py-rule", "name": "PY Rule",
        "trigger": {"extensions": [".py"], "paths": [], "patterns": []},
        "checklist": [{"key": "py-check", "text": "PY check"}],
    }])

    multi_dot = [_make_changed_file("archive.tar.gz")]
    assert len(match_rules(multi_dot, config_gz)) == 1   # .gz matches (last dot)
    assert len(match_rules(multi_dot, config_tar)) == 0  # .tar does not match

    no_dot = [_make_changed_file("Makefile")]
    assert len(match_rules(no_dot, config_py)) == 0      # no dot means no extension match


def test_match_rules_triggers_by_path_prefix():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([
        {
            "id": "frontend-rule",
            "name": "Frontend Rule",
            "trigger": {"extensions": [], "paths": ["frontend/"], "patterns": []},
            "checklist": [{"key": "fe-check", "text": "Check frontend"}],
        }
    ])
    files = [_make_changed_file("frontend/components/Button.tsx")]

    result = match_rules(files, config)

    assert len(result) == 1
    assert result[0].rule.id == "frontend-rule"


def test_match_rules_path_prefix_is_case_sensitive():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([
        {
            "id": "case-rule",
            "name": "Case Rule",
            "trigger": {"extensions": [], "paths": ["Frontend/"], "patterns": []},
            "checklist": [{"key": "case-check", "text": "Check case"}],
        }
    ])
    files = [_make_changed_file("frontend/app.js")]

    result = match_rules(files, config)

    assert len(result) == 0


def test_match_rules_triggers_by_fnmatch_pattern():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([
        {
            "id": "api-rule",
            "name": "API Rule",
            "trigger": {"extensions": [], "paths": [], "patterns": ["**/api/**"]},
            "checklist": [{"key": "api-check", "text": "Check API"}],
        }
    ])
    files = [_make_changed_file("backend/api/routes.py")]

    result = match_rules(files, config)

    assert len(result) == 1
    assert result[0].rule.id == "api-rule"


def test_match_rules_skips_rule_with_all_empty_trigger_lists():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([
        {
            "id": "empty-rule",
            "name": "Empty Triggers",
            "trigger": {"extensions": [], "paths": [], "patterns": []},
            "checklist": [{"key": "empty-check", "text": "Never triggered"}],
        }
    ])
    files = [_make_changed_file("anything.py")]

    result = match_rules(files, config)

    assert len(result) == 0


def test_match_rules_preserves_configuration_order():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([
        {
            "id": "rule-b",
            "name": "Rule B",
            "trigger": {"extensions": [".py"], "paths": [], "patterns": []},
            "checklist": [{"key": "b-check", "text": "B check"}],
        },
        {
            "id": "rule-a",
            "name": "Rule A",
            "trigger": {"extensions": [".py"], "paths": [], "patterns": []},
            "checklist": [{"key": "a-check", "text": "A check"}],
        },
    ])
    files = [_make_changed_file("test.py")]

    result = match_rules(files, config)

    assert len(result) == 2
    assert result[0].rule.id == "rule-b"
    assert result[1].rule.id == "rule-a"


def test_match_rules_sorts_matched_files_alphabetically():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([
        {
            "id": "multi-rule",
            "name": "Multi File Rule",
            "trigger": {"extensions": [".py"], "paths": [], "patterns": []},
            "checklist": [{"key": "multi-check", "text": "Multi check"}],
        }
    ])
    files = [
        _make_changed_file("z_module.py"),
        _make_changed_file("a_module.py"),
        _make_changed_file("m_module.py"),
    ]

    result = match_rules(files, config)

    assert len(result) == 1
    assert result[0].matched_files == ["a_module.py", "m_module.py", "z_module.py"]


def test_match_rules_returns_empty_when_no_files_match():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([
        {
            "id": "js-rule",
            "name": "JS Rule",
            "trigger": {"extensions": [".js"], "paths": [], "patterns": []},
            "checklist": [{"key": "js-check", "text": "Check JS"}],
        }
    ])
    files = [_make_changed_file("module.py")]

    result = match_rules(files, config)

    assert len(result) == 0


def test_match_rules_triggered_rule_contains_rule_and_matched_files(config_path: Path):
    match_rules = import_public("pr_checklist.matcher", "match_rules")
    load_config = import_public("pr_checklist.config", "load_config")
    TriggeredRule = import_public("pr_checklist.matcher", "TriggeredRule")
    Rule = import_public("pr_checklist.config", "Rule")

    config = load_config(config_path)
    files = [_make_changed_file("frontend/app.tsx")]

    result = match_rules(files, config)

    assert len(result) == 1
    assert isinstance(result[0], TriggeredRule)
    assert isinstance(result[0].rule, Rule)
    assert result[0].matched_files == ["frontend/app.tsx"]


def test_match_rules_matched_files_excludes_non_matching_files():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([{
        "id": "py-rule",
        "name": "Python Rule",
        "trigger": {"extensions": [".py"], "paths": [], "patterns": []},
        "checklist": [{"key": "py-check", "text": "Python check"}],
    }])
    files = [
        _make_changed_file("a.py"),
        _make_changed_file("b.js"),   # does not match .py extension
        _make_changed_file("c.py"),
    ]

    result = match_rules(files, config)

    assert len(result) == 1
    assert result[0].matched_files == ["a.py", "c.py"]


def test_match_rules_or_semantics_across_active_trigger_types():
    match_rules = import_public("pr_checklist.matcher", "match_rules")

    config = _make_config([{
        "id": "combo-rule",
        "name": "Combo Rule",
        "trigger": {"extensions": [".py"], "paths": ["frontend/"], "patterns": []},
        "checklist": [{"key": "combo-check", "text": "Combo check"}],
    }])
    files = [
        _make_changed_file("backend/script.py"),   # matches extension only
        _make_changed_file("frontend/style.css"),  # matches path only
    ]

    result = match_rules(files, config)

    assert len(result) == 1
    assert result[0].matched_files == ["backend/script.py", "frontend/style.css"]


# ---------------------------------------------------------------------------
# test_renderer
# ---------------------------------------------------------------------------

def test_render_markdown_produces_heading_and_checklist_for_triggered_rules():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    triggered = [
        _make_triggered_rule(
            "fe-rule", "Frontend Accessibility",
            [("a11y-aria", "Verify ARIA attributes"), ("a11y-contrast", "Check color contrast")],
            ["frontend/Button.tsx", "frontend/App.tsx"],
        )
    ]

    output = render_markdown(triggered)

    assert output.startswith("## PR Checklist\n")
    assert "### Frontend Accessibility" in output
    assert "- [ ] Verify ARIA attributes <!-- checklist:a11y-aria -->" in output
    assert "- [ ] Check color contrast <!-- checklist:a11y-contrast -->" in output


def test_render_markdown_includes_triggered_by_line_with_backtick_wrapped_files():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    triggered = [
        _make_triggered_rule(
            "rule1", "Test Rule",
            [("k1", "Item one")],
            ["b_file.py", "a_file.py"],
        )
    ]

    output = render_markdown(triggered)

    assert "_Triggered by: `a_file.py`, `b_file.py`_" in output


def test_render_markdown_no_triggered_rules_produces_no_items_message():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    output = render_markdown([])

    assert "## PR Checklist" in output
    assert "No checklist items were triggered by the changes in this PR." in output


def test_render_markdown_ends_with_single_trailing_newline():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    output_with_rules = render_markdown([
        _make_triggered_rule("r1", "Rule", [("k1", "Item")], ["file.py"])
    ])
    output_without_rules = render_markdown([])

    assert output_with_rules.endswith("\n")
    assert not output_with_rules.endswith("\n\n")
    assert output_without_rules.endswith("\n")
    assert not output_without_rules.endswith("\n\n")


def test_render_markdown_multiple_rules_in_configuration_order():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    triggered = [
        _make_triggered_rule("r1", "First Rule", [("k1", "Item 1")], ["a.py"]),
        _make_triggered_rule("r2", "Second Rule", [("k2", "Item 2")], ["b.js"]),
    ]

    output = render_markdown(triggered)

    first_pos = output.index("### First Rule")
    second_pos = output.index("### Second Rule")
    assert first_pos < second_pos


def test_render_markdown_checklist_item_format_includes_html_comment_marker():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    triggered = [
        _make_triggered_rule("r1", "Rule", [("my-key", "My text")], ["file.py"])
    ]

    output = render_markdown(triggered)

    lines = output.split("\n")
    checklist_lines = [line for line in lines if line.startswith("- [ ]")]
    assert len(checklist_lines) == 1
    assert checklist_lines[0] == "- [ ] My text <!-- checklist:my-key -->"


def test_render_markdown_heading_followed_by_blank_line():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    output_with_rules = render_markdown([
        _make_triggered_rule("r1", "Rule", [("k1", "Item")], ["file.py"])
    ])
    output_without_rules = render_markdown([])

    assert "## PR Checklist\n\n" in output_with_rules
    assert "## PR Checklist\n\n" in output_without_rules


def test_render_markdown_triggered_by_line_followed_by_blank_line():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    triggered = [
        _make_triggered_rule("r1", "Rule", [("k1", "Item")], ["file.py"])
    ]

    output = render_markdown(triggered)
    lines = output.split("\n")

    triggered_by_idx = next(i for i, l in enumerate(lines) if l.startswith("_Triggered by:"))
    assert lines[triggered_by_idx + 1] == ""


def test_render_markdown_blank_line_between_rules_not_after_final():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    triggered = [
        _make_triggered_rule("r1", "First Rule", [("k1", "Item 1")], ["a.py"]),
        _make_triggered_rule("r2", "Second Rule", [("k2", "Item 2")], ["b.py"]),
    ]

    output = render_markdown(triggered)

    # Blank line separates the first rule's last item from the next rule's heading
    assert "<!-- checklist:k1 -->\n\n### " in output
    # No extra blank line after the final rule's last item
    assert output.endswith("<!-- checklist:k2 -->\n")


def test_render_markdown_checklist_items_in_configuration_order():
    render_markdown = import_public("pr_checklist.renderer", "render_markdown")

    # Items whose keys sort alphabetically in reverse of configuration order,
    # so any alphabetical sorting would produce the wrong result.
    triggered = [
        _make_triggered_rule(
            "r1", "Test Rule",
            [("zeta", "Z item"), ("alpha", "A item")],
            ["file.py"],
        )
    ]

    output = render_markdown(triggered)

    zeta_pos = output.index("<!-- checklist:zeta -->")
    alpha_pos = output.index("<!-- checklist:alpha -->")
    assert zeta_pos < alpha_pos  # zeta first: configuration order, not alphabetical