import { describe, it, expect } from "vitest";
import { loadModule, defaultTheme, FENCE, fenceBlock } from "./helpers";

describe("SlideDeckCompiler.parse - Markdown Input Contract", () => {
  it("P1: returns a SlideDeck with a `slides` array (Interface: SlideDeck)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module src/index.ts not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const deck = compiler.parse("# Hello");
      if (!deck) throw new Error("parse returned falsy");
      if (!Array.isArray(deck.slides)) throw new Error("deck.slides is not an array");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P2: a line containing exactly `---` separates slides (Markdown #1)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = ["# A", "alpha", "---", "# B", "beta"].join("\n");
      const deck = compiler.parse(md);
      if (deck.slides.length !== 2)
        throw new Error(`expected 2 slides, got ${deck.slides.length}`);
      if (deck.slides[0].title !== "A")
        throw new Error(`slide 0 title: ${deck.slides[0].title}`);
      if (deck.slides[1].title !== "B")
        throw new Error(`slide 1 title: ${deck.slides[1].title}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P3: slide order is preserved exactly as it appears (Markdown #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = ["# First", "---", "# Second", "---", "# Third"].join("\n");
      const deck = compiler.parse(md);
      const titles = deck.slides.map((s: any) => s.title);
      if (JSON.stringify(titles) !== JSON.stringify(["First", "Second", "Third"]))
        throw new Error(`titles: ${JSON.stringify(titles)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P4: `order` starts at 0 and increases by 1 per slide (Slide Model #1)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = ["# A", "---", "# B", "---", "# C", "---", "# D"].join("\n");
      const deck = compiler.parse(md);
      const orders = deck.slides.map((s: any) => s.order);
      if (JSON.stringify(orders) !== JSON.stringify([0, 1, 2, 3]))
        throw new Error(`orders: ${JSON.stringify(orders)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P5: each slide title is taken from the first `# <title>` line (Markdown #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# My Slide Title\nSome body text.";
      const deck = compiler.parse(md);
      if (deck.slides[0].title !== "My Slide Title")
        throw new Error(`title: ${deck.slides[0].title}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P6: bodyContent removes the title line (Slide Model #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# Title\nbody line";
      const deck = compiler.parse(md);
      const body = deck.slides[0].bodyContent;
      if (typeof body !== "string") throw new Error("bodyContent not string");
      if (body.includes("# Title"))
        throw new Error(`title leaked into body: ${JSON.stringify(body)}`);
      if (!body.includes("body line"))
        throw new Error(`body missing content: ${JSON.stringify(body)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P7: bodyContent removes markdown image lines (Slide Model #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nintro\n![pic](http://x/p.png)\noutro";
      const deck = compiler.parse(md);
      const body = deck.slides[0].bodyContent;
      if (body.includes("![pic]"))
        throw new Error(`image line leaked: ${JSON.stringify(body)}`);
      if (!body.includes("intro") || !body.includes("outro"))
        throw new Error(`other text missing: ${JSON.stringify(body)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P8: bodyContent removes fenced code block lines including fences (Slide Model #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md =
        "# T\nbefore\n" + fenceBlock("ts", "const x = 1;") + "\nafter";
      const deck = compiler.parse(md);
      const body = deck.slides[0].bodyContent;
      if (body.includes(FENCE))
        throw new Error(`fence leaked into body: ${JSON.stringify(body)}`);
      if (body.includes("const x = 1;"))
        throw new Error(`code leaked into body: ${JSON.stringify(body)}`);
      if (!body.includes("before") || !body.includes("after"))
        throw new Error(`surrounding text missing: ${JSON.stringify(body)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P9: bodyContent removes `:::notes` block lines including markers (Slide Model #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\ntop\n:::notes\nspeaker said this\n:::\nbottom";
      const deck = compiler.parse(md);
      const body = deck.slides[0].bodyContent;
      if (body.includes(":::notes"))
        throw new Error(`notes opener leaked: ${JSON.stringify(body)}`);
      if (body.includes("speaker said this"))
        throw new Error(`notes content leaked: ${JSON.stringify(body)}`);
      if (body.includes(":::"))
        throw new Error(`notes closer leaked: ${JSON.stringify(body)}`);
      if (!body.includes("top") || !body.includes("bottom"))
        throw new Error(`other text missing: ${JSON.stringify(body)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P10: bodyContent preserves remaining lines verbatim (incl. whitespace) joined by `\\n` (Slide Model #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const lines = ["  indented line", "", "trailing space   ", "plain"];
      const md = "# T\n" + lines.join("\n");
      const deck = compiler.parse(md);
      const body = deck.slides[0].bodyContent;
      const expected = lines.join("\n");
      if (body !== expected)
        throw new Error(
          `body mismatch:\nexpected=${JSON.stringify(expected)}\nactual=${JSON.stringify(body)}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P11: `images` lists SlideImage entries in source order (Slide Model #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md =
        "# T\n![first](a.png)\nstuff\n![second](b.png)\n![third](c.png)";
      const deck = compiler.parse(md);
      const sources = deck.slides[0].images.map((i: any) => i.source);
      if (JSON.stringify(sources) !== JSON.stringify(["a.png", "b.png", "c.png"]))
        throw new Error(`sources: ${JSON.stringify(sources)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P12: `codeBlocks` lists SlideCodeBlock entries in source order (Slide Model #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md =
        "# T\n" +
        fenceBlock("ts", "const a = 1;") +
        "\n" +
        fenceBlock("js", "const b = 2;") +
        "\n" +
        fenceBlock("py", "c = 3");
      const deck = compiler.parse(md);
      const langs = deck.slides[0].codeBlocks.map((c: any) => c.language);
      if (JSON.stringify(langs) !== JSON.stringify(["ts", "js", "py"]))
        throw new Error(`languages: ${JSON.stringify(langs)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P13: SlideImage `altText` and `source` come from `![alt](src)` (Slide Model #5)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\n![Alt Text](https://example.com/img.png)";
      const deck = compiler.parse(md);
      const img = deck.slides[0].images[0];
      if (!img) throw new Error("no image extracted");
      if (img.altText !== "Alt Text")
        throw new Error(`altText: ${JSON.stringify(img.altText)}`);
      if (img.source !== "https://example.com/img.png")
        throw new Error(`source: ${JSON.stringify(img.source)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P14: SlideCodeBlock `language` is the opening fence language tag (Slide Model #6)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\n" + fenceBlock("ts", "const x: number = 1;");
      const deck = compiler.parse(md);
      const cb = deck.slides[0].codeBlocks[0];
      if (!cb) throw new Error("no code block extracted");
      if (cb.language !== "ts")
        throw new Error(`language: ${JSON.stringify(cb.language)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P15: SlideCodeBlock `rawCode` is body lines joined by `\\n` with no leading/trailing newline (Slide Model #6)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const codeLines = ["line 1", "line 2", "line 3"];
      const md = "# T\n" + fenceBlock("ts", codeLines.join("\n"));
      const deck = compiler.parse(md);
      const raw = deck.slides[0].codeBlocks[0].rawCode;
      if (raw !== codeLines.join("\n"))
        throw new Error(`rawCode: ${JSON.stringify(raw)}`);
      if (raw.startsWith("\n")) throw new Error("rawCode has leading newline");
      if (raw.endsWith("\n")) throw new Error("rawCode has trailing newline");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P16: `speakerNotes` equals the notes content joined by `\\n` (Slide Model #8)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\n:::notes\nfirst note\nsecond note\n:::";
      const deck = compiler.parse(md);
      const notes = deck.slides[0].speakerNotes;
      if (notes !== "first note\nsecond note")
        throw new Error(`speakerNotes: ${JSON.stringify(notes)}`);
      if (notes.startsWith("\n")) throw new Error("notes has leading newline");
      if (notes.endsWith("\n")) throw new Error("notes has trailing newline");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P17: `speakerNotes` is `\"\"` when no notes block is present (Slide Model #8)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const deck = compiler.parse("# T\nbody");
      if (deck.slides[0].speakerNotes !== "")
        throw new Error(
          `speakerNotes: ${JSON.stringify(deck.slides[0].speakerNotes)}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P18: `speakerNotes` is `\"\"` when the notes block is empty (Slide Model #8)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody\n:::notes\n:::";
      const deck = compiler.parse(md);
      if (deck.slides[0].speakerNotes !== "")
        throw new Error(
          `speakerNotes: ${JSON.stringify(deck.slides[0].speakerNotes)}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P19: a `---` line inside a fenced code block does NOT split slides (Markdown #8)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const code = ["a", "---", "b"].join("\n");
      const md = "# Only One\n" + fenceBlock("yaml", code);
      const deck = compiler.parse(md);
      if (deck.slides.length !== 1)
        throw new Error(`expected 1 slide, got ${deck.slides.length}`);
      const raw = deck.slides[0].codeBlocks[0].rawCode;
      if (raw !== code) throw new Error(`rawCode: ${JSON.stringify(raw)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P20: a `# Heading` line inside a fenced code block is treated as code (Markdown #8)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const code = "# not a slide title\nprint('x')";
      const md = "# Real Title\n" + fenceBlock("py", code);
      const deck = compiler.parse(md);
      if (deck.slides.length !== 1)
        throw new Error(`expected 1 slide, got ${deck.slides.length}`);
      if (deck.slides[0].title !== "Real Title")
        throw new Error(`title: ${deck.slides[0].title}`);
      const raw = deck.slides[0].codeBlocks[0].rawCode;
      if (raw !== code) throw new Error(`rawCode: ${JSON.stringify(raw)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P21: a markdown image line inside a fenced code block is treated as code (Markdown #8)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const code = "![not](really.png)\nrender(x)";
      const md = "# T\n" + fenceBlock("md", code);
      const deck = compiler.parse(md);
      if (deck.slides[0].images.length !== 0)
        throw new Error(
          `unexpected images: ${JSON.stringify(deck.slides[0].images)}`,
        );
      const raw = deck.slides[0].codeBlocks[0].rawCode;
      if (raw !== code) throw new Error(`rawCode: ${JSON.stringify(raw)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("P22: `:::notes` and `:::` lines inside a fenced code block are treated as code (Markdown #8)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const code = ":::notes\nfake\n:::";
      const md = "# T\n" + fenceBlock("md", code);
      const deck = compiler.parse(md);
      if (deck.slides[0].speakerNotes !== "")
        throw new Error(
          `unexpected notes: ${JSON.stringify(deck.slides[0].speakerNotes)}`,
        );
      const raw = deck.slides[0].codeBlocks[0].rawCode;
      if (raw !== code) throw new Error(`rawCode: ${JSON.stringify(raw)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});
