import uuid
import pytest
from conftest import create_insurer, create_filing


class TestPublicComments:
    def test_create_comment(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/filings/{filing['filing_id']}/comments",
            json={
                "commenter_name": "Jane Doe",
                "commenter_email": "jane@example.com",
                "comment_text": "This rate increase is too high.",
            },
        )
        assert resp.status_code == 201

    def test_create_comment_returns_required_fields(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/filings/{filing['filing_id']}/comments",
            json={
                "commenter_name": "John Smith",
                "commenter_email": "john@example.com",
                "comment_text": "Concerned about premium increases.",
            },
        )
        data = resp.json()
        assert "comment_id" in data
        assert isinstance(data["comment_id"], str)
        uuid.UUID(data["comment_id"])  # raises ValueError if not a valid UUID
        assert data["filing_id"] == filing["filing_id"]
        assert data["commenter_name"] == "John Smith"
        assert data["commenter_email"] == "john@example.com"
        assert data["comment_text"] == "Concerned about premium increases."
        assert "submitted_date" in data

    def test_create_comment_filing_not_found(self, client):
        resp = client.post(
            "/api/filings/nonexistent-filing/comments",
            json={
                "commenter_name": "Test",
                "commenter_email": "test@test.com",
                "comment_text": "Test comment.",
            },
        )
        assert resp.status_code == 404

    def test_get_comments_for_filing(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        client.post(
            f"/api/filings/{filing['filing_id']}/comments",
            json={
                "commenter_name": "Alice",
                "commenter_email": "alice@example.com",
                "comment_text": "First comment.",
            },
        )
        client.post(
            f"/api/filings/{filing['filing_id']}/comments",
            json={
                "commenter_name": "Bob",
                "commenter_email": "bob@example.com",
                "comment_text": "Second comment.",
            },
        )
        resp = client.get(f"/api/filings/{filing['filing_id']}/comments")
        assert resp.status_code == 200
        comments = resp.json()
        assert isinstance(comments, list)
        assert len(comments) == 2

    def test_get_comments_filing_not_found(self, client):
        resp = client.get("/api/filings/nonexistent-filing/comments")
        assert resp.status_code == 404
