import uuid
import pytest
from conftest import create_insurer, create_filing, unique_serff


class TestCreateFiling:
    def test_create_filing_success(self, client):
        insurer = create_insurer(client).json()
        resp = create_filing(client, insurer["insurer_id"])
        assert resp.status_code == 201

    def test_create_filing_returns_server_generated_filing_id(self, client):
        insurer = create_insurer(client).json()
        resp = create_filing(client, insurer["insurer_id"])
        data = resp.json()
        assert "filing_id" in data
        assert isinstance(data["filing_id"], str)
        assert len(data["filing_id"]) > 0
        uuid.UUID(data["filing_id"])  # raises ValueError if not a valid UUID
        assert "status" in data
        assert data["status"] == "received"

    def test_create_filing_includes_attachments(self, client):
        insurer = create_insurer(client).json()
        resp = create_filing(client, insurer["insurer_id"])
        data = resp.json()
        filing_id = data["filing_id"]
        assert "attachments" in data
        assert len(data["attachments"]) == 2
        attachment_types = {a["attachment_type"] for a in data["attachments"]}
        assert "actuarial_memorandum" in attachment_types
        assert "experience_exhibit" in attachment_types
        for att in data["attachments"]:
            assert "attachment_id" in att
            assert isinstance(att["attachment_id"], str)
            uuid.UUID(att["attachment_id"])  # raises ValueError if not a valid UUID
            assert att["filing_id"] == filing_id
            assert "filename" in att
            assert "uploaded_date" in att

    def test_create_filing_rejected_for_inactive_insurer(self, client):
        insurer = create_insurer(client, state_license_status="suspended").json()
        resp = create_filing(client, insurer["insurer_id"])
        assert resp.status_code == 400

    def test_create_filing_rejected_for_revoked_insurer(self, client):
        insurer = create_insurer(client, state_license_status="revoked").json()
        resp = create_filing(client, insurer["insurer_id"])
        assert resp.status_code == 400

    def test_create_filing_missing_actuarial_memorandum(self, client):
        insurer = create_insurer(client).json()
        payload = {
            "insurer_id": insurer["insurer_id"],
            "serff_tracking_number": unique_serff(),
            "filing_type": "initial",
            "product_type": "individual",
            "effective_date": "2025-01-01",
            "submission_date": "2024-06-01",
            "requested_rate_change_pct": 3.0,
            "attachments": [
                {
                    "attachment_type": "experience_exhibit",
                    "filename": "exhibit.pdf",
                    "uploaded_date": "2024-06-01",
                },
            ],
        }
        resp = client.post("/api/filings", json=payload)
        assert resp.status_code == 400

    def test_create_filing_missing_experience_exhibit(self, client):
        insurer = create_insurer(client).json()
        payload = {
            "insurer_id": insurer["insurer_id"],
            "serff_tracking_number": unique_serff(),
            "filing_type": "initial",
            "product_type": "individual",
            "effective_date": "2025-01-01",
            "submission_date": "2024-06-01",
            "requested_rate_change_pct": 3.0,
            "attachments": [
                {
                    "attachment_type": "actuarial_memorandum",
                    "filename": "memo.pdf",
                    "uploaded_date": "2024-06-01",
                },
            ],
        }
        resp = client.post("/api/filings", json=payload)
        assert resp.status_code == 400


    def test_create_filing_duplicate_attachment_type_rejected(self, client):
        insurer = create_insurer(client).json()
        payload = {
            "insurer_id": insurer["insurer_id"],
            "serff_tracking_number": unique_serff(),
            "filing_type": "initial",
            "product_type": "individual",
            "effective_date": "2025-01-01",
            "submission_date": "2024-06-01",
            "requested_rate_change_pct": 3.0,
            "attachments": [
                {
                    "attachment_type": "actuarial_memorandum",
                    "filename": "memo1.pdf",
                    "uploaded_date": "2024-06-01",
                },
                {
                    "attachment_type": "actuarial_memorandum",
                    "filename": "memo2.pdf",
                    "uploaded_date": "2024-06-01",
                },
            ],
        }
        resp = client.post("/api/filings", json=payload)
        assert resp.status_code == 400

    def test_create_filing_nonexistent_insurer(self, client):
        resp = create_filing(client, "nonexistent-insurer-id")
        assert resp.status_code == 404

    def test_create_filing_duplicate_serff_tracking_number_rejected(self, client):
        insurer = create_insurer(client).json()
        serff = unique_serff()
        create_filing(client, insurer["insurer_id"], serff_tracking_number=serff)
        resp = create_filing(client, insurer["insurer_id"], serff_tracking_number=serff)
        assert resp.status_code != 201

    def test_filing_stores_correct_fields(self, client):
        serff = unique_serff()
        insurer = create_insurer(client).json()
        resp = create_filing(
            client,
            insurer["insurer_id"],
            serff_tracking_number=serff,
            filing_type="renewal",
            product_type="small_group",
            effective_date="2025-07-01",
            submission_date="2024-12-01",
            requested_rate_change_pct=8.2,
        )
        data = resp.json()
        assert data["insurer_id"] == insurer["insurer_id"]
        assert data["serff_tracking_number"] == serff
        assert data["filing_type"] == "renewal"
        assert data["product_type"] == "small_group"
        assert data["effective_date"] == "2025-07-01"
        assert data["submission_date"] == "2024-12-01"
        assert data["requested_rate_change_pct"] == 8.2

    def test_aca_unreasonable_flag_true_when_at_or_above_threshold(self, client):
        insurer = create_insurer(client).json()
        resp = create_filing(
            client,
            insurer["insurer_id"],
            requested_rate_change_pct=10.0,
        )
        assert resp.status_code == 201
        assert resp.json()["aca_unreasonable_flag"] is True

    def test_aca_unreasonable_flag_true_when_above_threshold(self, client):
        insurer = create_insurer(client).json()
        resp = create_filing(
            client,
            insurer["insurer_id"],
            requested_rate_change_pct=15.5,
        )
        assert resp.status_code == 201
        assert resp.json()["aca_unreasonable_flag"] is True

    def test_aca_unreasonable_flag_false_when_below_threshold(self, client):
        insurer = create_insurer(client).json()
        resp = create_filing(
            client,
            insurer["insurer_id"],
            requested_rate_change_pct=5.5,
        )
        assert resp.status_code == 201
        assert resp.json()["aca_unreasonable_flag"] is False

    def test_filing_response_includes_aca_unreasonable_flag_field(self, client):
        insurer = create_insurer(client).json()
        resp = create_filing(client, insurer["insurer_id"])
        data = resp.json()
        assert "aca_unreasonable_flag" in data
        assert isinstance(data["aca_unreasonable_flag"], bool)


class TestGetFilings:
    def test_get_all_filings_returns_created(self, client):
        insurer = create_insurer(client).json()
        f1 = create_filing(client, insurer["insurer_id"]).json()
        f2 = create_filing(client, insurer["insurer_id"]).json()
        resp = client.get("/api/filings")
        assert resp.status_code == 200
        filing_ids = {f["filing_id"] for f in resp.json()}
        assert f1["filing_id"] in filing_ids
        assert f2["filing_id"] in filing_ids

    def test_get_filings_filtered_by_insurer(self, client):
        ins1 = create_insurer(client).json()
        ins2 = create_insurer(client).json()
        create_filing(client, ins1["insurer_id"])
        create_filing(client, ins2["insurer_id"])
        resp = client.get(f"/api/filings?insurer_id={ins1['insurer_id']}")
        assert resp.status_code == 200
        filings = resp.json()
        assert len(filings) == 1
        assert filings[0]["insurer_id"] == ins1["insurer_id"]


    def test_get_filings_list_includes_attachments(self, client):
        # GET /api/filings output spec: "each including its attachments list" - verified here
        # on the list endpoint independently of the single-item GET test.
        insurer = create_insurer(client).json()
        create_filing(client, insurer["insurer_id"])
        resp = client.get(f"/api/filings?insurer_id={insurer['insurer_id']}")
        assert resp.status_code == 200
        filings = resp.json()
        assert len(filings) >= 1
        for filing in filings:
            assert "attachments" in filing
            assert isinstance(filing["attachments"], list)
            assert len(filing["attachments"]) == 2
            attachment_types = {a["attachment_type"] for a in filing["attachments"]}
            assert "actuarial_memorandum" in attachment_types
            assert "experience_exhibit" in attachment_types

    def test_get_filing_by_id(self, client):
        insurer = create_insurer(client).json()
        created = create_filing(client, insurer["insurer_id"]).json()
        resp = client.get(f"/api/filings/{created['filing_id']}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["filing_id"] == created["filing_id"]
        assert "attachments" in data

    def test_get_filing_not_found(self, client):
        resp = client.get("/api/filings/nonexistent-filing-id")
        assert resp.status_code == 404
