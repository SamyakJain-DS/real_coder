import { describe, it, expect } from "vitest";
import {
  loadModule,
  defaultTheme,
  fenceBlock,
  indicesOf,
  strictlyIncreasing,
} from "./helpers";

function findSection(html: string, order: number): string | null {
  const re = new RegExp(
    `<section\\b[^>]*\\bclass\\s*=\\s*"[^"]*\\bslide\\b[^"]*"[^>]*\\bdata-order\\s*=\\s*"${order}"[^>]*>([\\s\\S]*?)</section>`,
  );
  const m = html.match(re);
  return m ? m[1] : null;
}

function findStyleContent(html: string): string | null {
  const m = html.match(/<style[^>]*>([\s\S]*?)<\/style>/);
  return m ? m[1] : null;
}

function rootDeclarations(css: string): Record<string, string> {
  const rootMatches = css.match(/:root\s*\{[\s\S]*?\}/g) || [];
  if (rootMatches.length === 0) return {};
  const merged = rootMatches
    .map((block) => { const m = block.match(/\{([\s\S]*)\}/); return m ? m[1] : ""; })
    .join(";");
  const out: Record<string, string> = {};
  for (const d of merged.split(";")) {
    const trimmed = d.trim();
    if (!trimmed) continue;
    const colon = trimmed.indexOf(":");
    if (colon < 0) continue;
    out[trimmed.slice(0, colon).trim()] = trimmed.slice(colon + 1).trim();
  }
  return out;
}

describe("SlideDeckCompiler.renderHtml - HTML Rendering Contract", () => {
  it("HR1: returns a complete HTML document beginning with <!DOCTYPE html> (Rendering #1)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const deck = compiler.parse("# T\nbody");
      const html = compiler.renderHtml(deck, {});
      if (typeof html !== "string") throw new Error("not a string");
      if (!html.startsWith("<!DOCTYPE html>"))
        throw new Error(`prefix: ${html.slice(0, 60)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR2: contains exactly one <html>, <head>, <body>, and <style> element (Rendering #1, #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const deck = compiler.parse("# T\nbody");
      const html: string = compiler.renderHtml(deck, {});
      const counts = {
        htmlOpen: (html.match(/<html[\s>]/g) || []).length,
        htmlClose: (html.match(/<\/html>/g) || []).length,
        headOpen: (html.match(/<head[\s>]/g) || []).length,
        headClose: (html.match(/<\/head>/g) || []).length,
        bodyOpen: (html.match(/<body[\s>]/g) || []).length,
        bodyClose: (html.match(/<\/body>/g) || []).length,
        styleOpen: (html.match(/<style[\s>]/g) || []).length,
        styleClose: (html.match(/<\/style>/g) || []).length,
      };
      for (const [k, v] of Object.entries(counts)) {
        if (v !== 1) throw new Error(`${k}=${v}, expected 1`);
      }
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR3: emits one <section class=\"slide\" data-order=\"N\"> per slide in parsed order (Rendering #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = ["# A", "---", "# B", "---", "# C"].join("\n");
      const deck = compiler.parse(md);
      const html: string = compiler.renderHtml(deck, {});
      const positions: number[] = [];
      for (let i = 0; i < deck.slides.length; i++) {
        const re = new RegExp(
          `<section\\b[^>]*\\bclass\\s*=\\s*"[^"]*\\bslide\\b[^"]*"[^>]*\\bdata-order\\s*=\\s*"${i}"[^>]*>`,
        );
        const m = html.match(re);
        if (!m || m.index == null)
          throw new Error(`missing section data-order="${i}"`);
        positions.push(m.index);
      }
      if (!strictlyIncreasing(positions))
        throw new Error(`section positions not increasing: ${positions}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR4: each slide section contains <h1> with the slide title (Rendering #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const deck = compiler.parse("# Hello World\nbody");
      const html: string = compiler.renderHtml(deck, {});
      const sec = findSection(html, 0);
      if (!sec) throw new Error("section data-order=0 missing");
      const m = sec.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/);
      if (!m) throw new Error("no <h1> in section");
      if (!m[1].includes("Hello World"))
        throw new Error(`<h1> text: ${m[1]}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR5: each slide section contains <div class=\"slide-body\"> (Rendering #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const deck = compiler.parse("# T\nbody");
      const html: string = compiler.renderHtml(deck, {});
      const sec = findSection(html, 0);
      if (!sec) throw new Error("section missing");
      if (!/<div\b[^>]*\bclass\s*=\s*"[^"]*\bslide-body\b[^"]*"/.test(sec))
        throw new Error("<div class=\"slide-body\"> not found");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR6: <div class=\"slide-images\"> wraps one <img> per image with matching alt and src in source order (Rendering #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\n![alpha](a.png)\n![beta](b.png)";
      const deck = compiler.parse(md);
      const html: string = compiler.renderHtml(deck, {});
      const sec = findSection(html, 0);
      if (!sec) throw new Error("section missing");
      const imgWrap = sec.match(
        /<div\b[^>]*\bclass\s*=\s*"[^"]*\bslide-images\b[^"]*"[^>]*>([\s\S]*?)<\/div>/,
      );
      if (!imgWrap) throw new Error("<div class=\"slide-images\"> not found");
      const imgs = imgWrap[1].match(/<img\b[^>]*>/g) || [];
      if (imgs.length !== 2)
        throw new Error(`expected 2 imgs, got ${imgs.length}`);
      const expectAlt = ["alpha", "beta"];
      const expectSrc = ["a.png", "b.png"];
      for (let i = 0; i < imgs.length; i++) {
        const altM = imgs[i].match(/\balt\s*=\s*"([^"]*)"/);
        const srcM = imgs[i].match(/\bsrc\s*=\s*"([^"]*)"/);
        if (!altM || altM[1] !== expectAlt[i])
          throw new Error(`img ${i} alt mismatch: ${imgs[i]}`);
        if (!srcM || srcM[1] !== expectSrc[i])
          throw new Error(`img ${i} src mismatch: ${imgs[i]}`);
      }
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR7: <div class=\"slide-code\"> contains each highlightedHtml emitted verbatim with no extra wrapping element (Rendering #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md =
        "# T\n" +
        fenceBlock("ts", "const a = 1;") +
        "\n" +
        fenceBlock("js", "const b = 2;") +
        "\n:::notes\nn\n:::";
      const deck = compiler.parse(md);
      const html: string = compiler.renderHtml(deck, {});
      const sec = findSection(html, 0);
      if (!sec) throw new Error("section missing");
      const codeWrap = sec.match(
        /<div\b[^>]*\bclass\s*=\s*"[^"]*\bslide-code\b[^"]*"[^>]*>([\s\S]*?)<\/div>\s*<aside\b/,
      );
      if (!codeWrap)
        throw new Error("<div class=\"slide-code\"> wrapper not found");
      let inner = codeWrap[1];

      let cursor = 0;
      for (const cb of deck.slides[0].codeBlocks) {
        const expected: string = cb.highlightedHtml;
        const idx = inner.indexOf(expected, cursor);
        if (idx < 0)
          throw new Error(
            `highlightedHtml for language=${cb.language} not present verbatim or out of source order`,
          );
        cursor = idx + expected.length;
      }

      let stripped = inner;
      for (const cb of deck.slides[0].codeBlocks) {
        stripped = stripped.replace(cb.highlightedHtml, "");
      }
      stripped = stripped.replace(/<!--[\s\S]*?-->/g, "");
      const stray = stripped.match(/<[A-Za-z][^>]*>/);
      if (stray)
        throw new Error(
          `extra wrapping element detected inside <div class="slide-code">: ${JSON.stringify(stray[0])}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR8: each section contains <aside class=\"speaker-notes\"> with the speaker notes (Rendering #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody\n:::notes\nremember to smile\n:::";
      const deck = compiler.parse(md);
      const html: string = compiler.renderHtml(deck, {});
      const sec = findSection(html, 0);
      if (!sec) throw new Error("section missing");
      const m = sec.match(
        /<aside\b[^>]*\bclass\s*=\s*"[^"]*\bspeaker-notes\b[^"]*"[^>]*>([\s\S]*?)<\/aside>/,
      );
      if (!m) throw new Error("<aside class=\"speaker-notes\"> not found");
      if (!m[1].includes("remember to smile"))
        throw new Error(`speaker-notes content: ${m[1]}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR9: child elements appear in the required order: h1, slide-body, slide-images, slide-code, speaker-notes (Rendering #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody\n![a](a.png)\n" +
        fenceBlock("ts", "const x = 1;") +
        "\n:::notes\nn\n:::";
      const deck = compiler.parse(md);
      const html: string = compiler.renderHtml(deck, {});
      const sec = findSection(html, 0);
      if (!sec) throw new Error("section missing");
      const idx = {
        h1: sec.search(/<h1\b/),
        body: sec.search(/<div\b[^>]*\bclass\s*=\s*"[^"]*\bslide-body\b/),
        images: sec.search(/<div\b[^>]*\bclass\s*=\s*"[^"]*\bslide-images\b/),
        code: sec.search(/<div\b[^>]*\bclass\s*=\s*"[^"]*\bslide-code\b/),
        notes: sec.search(/<aside\b[^>]*\bclass\s*=\s*"[^"]*\bspeaker-notes\b/),
      };
      for (const [k, v] of Object.entries(idx)) {
        if (v < 0) throw new Error(`${k} not found in section`);
      }
      const order = [idx.h1, idx.body, idx.images, idx.code, idx.notes];
      if (!strictlyIncreasing(order))
        throw new Error(`order not strictly increasing: ${JSON.stringify(idx)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR10: <head> contains a <style> declaring the six CSS custom properties on :root with merged-theme values (Rendering #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const theme = {
        fontFamily: "TestFont",
        backgroundColor: "#abcdef",
        textColor: "#123456",
        accentColor: "#fedcba",
        codeTheme: "test-code-theme",
        slidePaddingPx: 24,
      };
      const compiler = new mod.SlideDeckCompiler(theme);
      const deck = compiler.parse("# T\nbody");
      const html: string = compiler.renderHtml(deck, {});

      const headM = html.match(/<head[^>]*>([\s\S]*?)<\/head>/);
      if (!headM) throw new Error("<head> not found");
      const headInner = headM[1];
      const styleM = headInner.match(/<style[^>]*>([\s\S]*?)<\/style>/);
      if (!styleM) throw new Error("<style> not in <head>");
      const css = styleM[1];

      // :root selector must exist with the six declarations.
      if (!/:root\s*\{[\s\S]*?\}/.test(css))
        throw new Error(":root rule not found in <style>");

      const decls = rootDeclarations(css);
      const required: Record<string, string> = {
        "--font-family": "TestFont",
        "--background-color": "#abcdef",
        "--text-color": "#123456",
        "--accent-color": "#fedcba",
        "--code-theme": "test-code-theme",
        "--slide-padding": "24px",
      };
      for (const [prop, value] of Object.entries(required)) {
        if (decls[prop] !== value)
          throw new Error(`expected ${prop}: ${value}; got ${decls[prop]}`);
      }
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR11: <style> contains a CSS rule referencing each of the six custom properties via var() (Rendering #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const deck = compiler.parse("# T\nbody");
      const html: string = compiler.renderHtml(deck, {});
      const css = findStyleContent(html);
      if (!css) throw new Error("<style> not found");
      const required = [
        "var(--font-family)",
        "var(--background-color)",
        "var(--text-color)",
        "var(--accent-color)",
        "var(--code-theme)",
        "var(--slide-padding)",
      ];
      for (const ref of required) {
        if (!css.includes(ref)) throw new Error(`${ref} not referenced in <style>`);
      }
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("HR12: bodyContent text appears inside <div class=\"slide-body\"> (Rendering #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nHello rendered paragraph.";
      const deck = compiler.parse(md);
      const html: string = compiler.renderHtml(deck, {});
      const sec = findSection(html, 0);
      if (!sec) throw new Error("section data-order=0 missing");
      const bodyM = sec.match(
        /<div\b[^>]*\bclass\s*=\s*"[^"]*\bslide-body\b[^"]*"[^>]*>([\s\S]*?)<\/div>/,
      );
      if (!bodyM)
        throw new Error("<div class=\"slide-body\"> not found in section");
      const bodyInner = bodyM[1];
      if (!bodyInner.includes("Hello rendered paragraph."))
        throw new Error(
          `body text content not present inside slide-body. ` +
          `Slide body: ${JSON.stringify(bodyInner.slice(0, 300))}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

});