#!/usr/bin/env python3

import sys
import threading
import time
import dataclasses
from pathlib import Path

import pytest

APP_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(APP_DIR))

_AVAILABLE = False

try:
    from pake_framework import (
        get_group, Group, AuthenticationError,
        OpaqueRegistrationRequest, OpaqueRegistrationResponse, OpaqueRegistrationRecord,
        OpaqueKE1, OpaqueKE2, OpaqueKE3,
        OpaqueClientRegistrationState, OpaqueClientLoginState, OpaqueServerLoginState,
        OpaqueClient, OpaqueServer,
        SPAKE2Message, SPAKE2ConfirmMessage, SPAKE2State, SPAKE2PlusState,
        SPAKE2Client, SPAKE2Server, SPAKE2PlusClient, SPAKE2PlusServer,
        CPaceMessage, CPaceState, CPaceParty,
        AugmentedEnvelope, AugmentedCredentialManager,
        RoundTiming, PAKEProfiler,
        P256Group, P384Group, Ristretto255Group, X25519Group,
    )
    _AVAILABLE = True
except ImportError:
    pass


def _require():
    """Fail the current test immediately if pake_framework is not installed."""
    if not _AVAILABLE:
        pytest.fail("pake_framework is not installed")


# ---------------------------------------------------------------------------
# Internal helpers (only called after _require() has passed)
# ---------------------------------------------------------------------------

def _make_opaque_pair(gname="P-256"):
    g = get_group(gname)
    sk = g.random_scalar()
    pk = g.scalar_mult(sk, g.base_point())
    return OpaqueServer(g, sk, pk), OpaqueClient(g)


def _opaque_register(gname="P-256", password=b"password"):
    """Run OPAQUE registration and return (server, client, record)."""
    srv, cli = _make_opaque_pair(gname)
    st, req = cli.registration_request(password)
    record = cli.registration_record(st, srv.registration_response(req))
    return srv, cli, record


# ---------------------------------------------------------------------------
# Group framework -- factory
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255", "X25519"])
def test_get_group_returns_correct_name(gname):
    _require()
    assert get_group(gname).name == gname


def test_get_group_unknown_raises_value_error():
    _require()
    with pytest.raises(ValueError):
        get_group("no-such-group")


# ---------------------------------------------------------------------------
# Group framework -- concrete class instantiation
# ---------------------------------------------------------------------------

def test_concrete_group_classes_are_instantiable():
    _require()
    for cls in [P256Group, P384Group, Ristretto255Group, X25519Group]:
        g = cls()
        assert isinstance(g, Group)


def test_group_abstract_base_cannot_be_instantiated():
    # Prompt: "Abstract base class ... Declares ... as abstract methods."
    # Python's ABC machinery must prevent direct Group() instantiation.
    _require()
    with pytest.raises(TypeError):
        Group()


def test_group_all_five_methods_are_abstract():
    # Prompt: "Declares scalar_mult, base_point, random_scalar, point_add, and
    # hash_to_group as abstract methods" + "@abstractmethod" on each entry.
    # Group.__abstractmethods__ is a frozenset populated by the ABC machinery.
    _require()
    required = {"scalar_mult", "base_point", "random_scalar", "point_add", "hash_to_group"}
    assert required.issubset(Group.__abstractmethods__)


def test_group_name_is_read_only():
    # The @property annotation in the prompt makes name a read-only descriptor.
    _require()
    g = get_group("P-256")
    with pytest.raises(AttributeError):
        g.name = "modified"


# ---------------------------------------------------------------------------
# Group framework -- base_point
# ---------------------------------------------------------------------------

def test_x25519_base_point_returns_nonempty_bytes():
    # X25519 has no DH commutativity companion test; this is the only direct
    # verification that X25519 base_point() returns valid non-empty bytes.
    _require()
    bp = get_group("X25519").base_point()
    assert isinstance(bp, bytes) and len(bp) > 0


# ---------------------------------------------------------------------------
# Group framework -- random_scalar
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255", "X25519"])
def test_random_scalar_is_nondeterministic(gname):
    _require()
    g = get_group(gname)
    assert g.random_scalar() != g.random_scalar()


# ---------------------------------------------------------------------------
# Group framework -- scalar_mult
# ---------------------------------------------------------------------------

def test_x25519_scalar_mult_returns_nonempty_bytes():
    # X25519 has no DH commutativity companion and no protocol flow tests;
    # this is the only direct verification that X25519 scalar_mult succeeds.
    _require()
    g = get_group("X25519")
    result = g.scalar_mult(g.random_scalar(), g.base_point())
    assert isinstance(result, bytes) and len(result) > 0


@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255", "X25519"])
def test_scalar_mult_invalid_scalar_raises_value_error(gname):
    _require()
    g = get_group(gname)
    with pytest.raises(ValueError):
        g.scalar_mult(b"bad", g.base_point())


@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255", "X25519"])
def test_scalar_mult_invalid_point_raises_value_error(gname):
    _require()
    g = get_group(gname)
    with pytest.raises(ValueError):
        g.scalar_mult(g.random_scalar(), b"bad-point")


# ---------------------------------------------------------------------------
# Group framework -- point_add
# ---------------------------------------------------------------------------

def test_point_add_x25519_raises_not_implemented():
    _require()
    g = get_group("X25519")
    with pytest.raises(NotImplementedError):
        g.point_add(g.base_point(), g.base_point())


@pytest.mark.parametrize("gname,bad_first", [
    ("P-256", True), ("P-256", False),
    ("P-384", True), ("P-384", False),
    ("ristretto255", True), ("ristretto255", False),
])
def test_point_add_invalid_argument_raises_value_error(gname, bad_first):
    # Prompt: "Raises ValueError if either argument is not a valid encoding."
    # bad_first=True tests the first argument; bad_first=False tests the second.
    _require()
    g = get_group(gname)
    bp = g.base_point()
    with pytest.raises(ValueError):
        g.point_add(b"bad-point", bp) if bad_first else g.point_add(bp, b"bad-point")


# ---------------------------------------------------------------------------
# Group framework -- hash_to_group
# ---------------------------------------------------------------------------

def test_hash_to_group_x25519_raises_not_implemented():
    _require()
    with pytest.raises(NotImplementedError):
        get_group("X25519").hash_to_group(b"data")


@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255"])
def test_hash_to_group_is_deterministic(gname):
    _require()
    g = get_group(gname)
    data = b"consistent-input"
    assert g.hash_to_group(data) == g.hash_to_group(data)


@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255"])
def test_hash_to_group_different_inputs_give_different_outputs(gname):
    _require()
    g = get_group(gname)
    assert g.hash_to_group(b"input-one") != g.hash_to_group(b"input-two")


# ---------------------------------------------------------------------------
# Group framework -- DH commutativity
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255"])
def test_dh_commutativity(gname):
    _require()
    g = get_group(gname)
    bp = g.base_point()
    a = g.random_scalar()
    b = g.random_scalar()
    aG = g.scalar_mult(a, bp)
    bG = g.scalar_mult(b, bp)
    assert g.scalar_mult(a, bG) == g.scalar_mult(b, aG)


# ---------------------------------------------------------------------------
# OPAQUE -- message dataclasses
# ---------------------------------------------------------------------------

def test_opaque_registration_request_dataclass():
    _require()
    r = OpaqueRegistrationRequest(blinded_element=b"\x01" * 32)
    assert dataclasses.is_dataclass(r)
    assert r.blinded_element == b"\x01" * 32


def test_opaque_registration_response_dataclass():
    _require()
    r = OpaqueRegistrationResponse(evaluated_element=b"\x02" * 32, server_public_key=b"\x03" * 32)
    assert dataclasses.is_dataclass(r)
    assert r.evaluated_element == b"\x02" * 32
    assert r.server_public_key == b"\x03" * 32


def test_opaque_registration_record_dataclass():
    _require()
    r = OpaqueRegistrationRecord(
        envelope=b"\x04" * 32, masking_key=b"\x05" * 32, client_public_key=b"\x06" * 32
    )
    assert dataclasses.is_dataclass(r)
    assert r.envelope == b"\x04" * 32
    assert r.masking_key == b"\x05" * 32
    assert r.client_public_key == b"\x06" * 32


def test_opaque_ke1_dataclass():
    _require()
    r = OpaqueKE1(credential_request=b"\x07" * 32, auth_request=b"\x08" * 32)
    assert dataclasses.is_dataclass(r)
    assert r.credential_request == b"\x07" * 32
    assert r.auth_request == b"\x08" * 32


def test_opaque_ke2_dataclass():
    _require()
    r = OpaqueKE2(
        credential_response=b"\x09" * 32,
        auth_response=b"\x0a" * 32,
        masking_nonce=b"\x0b" * 32,
    )
    assert dataclasses.is_dataclass(r)
    assert r.credential_response == b"\x09" * 32
    assert r.auth_response == b"\x0a" * 32
    assert r.masking_nonce == b"\x0b" * 32


def test_opaque_ke3_dataclass():
    _require()
    r = OpaqueKE3(auth_finalizer=b"\x0c" * 32)
    assert dataclasses.is_dataclass(r)
    assert r.auth_finalizer == b"\x0c" * 32


# ---------------------------------------------------------------------------
# OPAQUE -- state dataclasses
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# OPAQUE -- method return types
# ---------------------------------------------------------------------------

def test_opaque_registration_request_return_type():
    _require()
    _, cli = _make_opaque_pair()
    st, req = cli.registration_request(b"pw")
    assert isinstance(req, OpaqueRegistrationRequest)
    assert isinstance(st, OpaqueClientRegistrationState)
    assert dataclasses.is_dataclass(st)


def test_opaque_registration_response_return_type():
    _require()
    srv, cli = _make_opaque_pair()
    _, req = cli.registration_request(b"pw")
    assert isinstance(srv.registration_response(req), OpaqueRegistrationResponse)


def test_opaque_registration_response_contains_configured_server_public_key():
    # Prompt: "Returns the registration response carrying the evaluated element
    # and the server public key." -- must echo back the pk passed to OpaqueServer.
    _require()
    g = get_group("P-256")
    sk = g.random_scalar()
    pk = g.scalar_mult(sk, g.base_point())
    _, req = OpaqueClient(g).registration_request(b"pw")
    resp = OpaqueServer(g, sk, pk).registration_response(req)
    assert resp.server_public_key == pk


def test_opaque_registration_record_return_type():
    _require()
    srv, cli = _make_opaque_pair()
    st, req = cli.registration_request(b"pw")
    record = cli.registration_record(st, srv.registration_response(req))
    assert isinstance(record, OpaqueRegistrationRecord)


def test_opaque_login_start_return_type():
    _require()
    _, cli = _make_opaque_pair()
    ls, ke1 = cli.login_start(b"pw")
    assert isinstance(ke1, OpaqueKE1)
    assert isinstance(ls, OpaqueClientLoginState)
    assert dataclasses.is_dataclass(ls)


def test_opaque_login_respond_return_type():
    _require()
    srv, cli, record = _opaque_register()
    _, ke1 = cli.login_start(b"password")
    sls, ke2 = srv.login_respond(ke1, record)
    assert isinstance(ke2, OpaqueKE2)
    assert isinstance(sls, OpaqueServerLoginState)
    assert dataclasses.is_dataclass(sls)


def test_opaque_login_finish_return_type():
    _require()
    srv, cli, record = _opaque_register()
    ls, ke1 = cli.login_start(b"password")
    _, ke2 = srv.login_respond(ke1, record)
    ke3, ckey = cli.login_finish(ls, ke2)
    assert isinstance(ke3, OpaqueKE3)
    assert isinstance(ckey, bytes) and len(ckey) > 0


def test_opaque_login_finalize_return_type():
    _require()
    srv, cli, record = _opaque_register()
    ls, ke1 = cli.login_start(b"password")
    sls, ke2 = srv.login_respond(ke1, record)
    ke3, _ = cli.login_finish(ls, ke2)
    skey = srv.login_finalize(sls, ke3)
    assert isinstance(skey, bytes) and len(skey) > 0


def test_opaque_login_finalize_raises_for_tampered_ke3():
    # Prompt: "Raises AuthenticationError if the client MAC fails."
    # Run a complete valid flow to get a real ke3, then flip one byte in
    # auth_finalizer -- the server must reject it with AuthenticationError.
    _require()
    srv, cli, record = _opaque_register()
    ls, ke1 = cli.login_start(b"password")
    sls, ke2 = srv.login_respond(ke1, record)
    ke3, _ = cli.login_finish(ls, ke2)
    tampered = OpaqueKE3(
        auth_finalizer=bytes([ke3.auth_finalizer[0] ^ 0xFF]) + ke3.auth_finalizer[1:]
    )
    with pytest.raises(AuthenticationError):
        srv.login_finalize(sls, tampered)


def test_opaque_login_finish_raises_for_tampered_ke2():
    # Prompt: "Raises AuthenticationError if the server MAC fails." (login_finish)
    # Mirrors test_opaque_login_finalize_raises_for_tampered_ke3: run a valid
    # registration + login_start + login_respond, then flip one byte in
    # ke2.auth_response -- the client must reject it with AuthenticationError.
    _require()
    srv, cli, record = _opaque_register()
    ls, ke1 = cli.login_start(b"password")
    _, ke2 = srv.login_respond(ke1, record)
    tampered = OpaqueKE2(
        credential_response=ke2.credential_response,
        auth_response=bytes([ke2.auth_response[0] ^ 0xFF]) + ke2.auth_response[1:],
        masking_nonce=ke2.masking_nonce,
    )
    with pytest.raises(AuthenticationError):
        cli.login_finish(ls, tampered)


def test_opaque_different_passwords_produce_different_evaluated_elements():
    # Prompt: "OPRF-evaluated element" -- the OPRF evaluates over the blinded
    # input; different passwords yield different blinded elements and therefore
    # different OPRF outputs in the registration response.
    _require()
    g = get_group("P-256")
    sk = g.random_scalar()
    pk = g.scalar_mult(sk, g.base_point())
    srv = OpaqueServer(g, sk, pk)
    _, req1 = OpaqueClient(g).registration_request(b"password-one")
    _, req2 = OpaqueClient(g).registration_request(b"password-two")
    assert srv.registration_response(req1).evaluated_element != \
           srv.registration_response(req2).evaluated_element


def test_opaque_login_respond_masking_nonce_is_fresh_each_call():
    # Prompt: "masking nonce" in OpaqueKE2 -- must be randomized per
    # login_respond call to uniquely mask each credential response.
    _require()
    srv, cli, record = _opaque_register()
    _, ke1a = cli.login_start(b"password")
    _, ke1b = cli.login_start(b"password")
    _, ke2a = srv.login_respond(ke1a, record)
    _, ke2b = srv.login_respond(ke1b, record)
    assert ke2a.masking_nonce != ke2b.masking_nonce


# ---------------------------------------------------------------------------
# OPAQUE -- full flows
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255"])
def test_opaque_full_flow_matching_keys(gname):
    _require()
    srv, cli, record = _opaque_register(gname, b"secret")
    ls, ke1 = cli.login_start(b"secret")
    sls, ke2 = srv.login_respond(ke1, record)
    ke3, ckey = cli.login_finish(ls, ke2)
    skey = srv.login_finalize(sls, ke3)
    assert ckey == skey


def test_opaque_wrong_password_raises_authentication_error():
    _require()
    srv, cli, record = _opaque_register(password=b"correct")
    ls, ke1 = cli.login_start(b"wrong")
    sls, ke2 = srv.login_respond(ke1, record)
    ke3_msg = None
    raised = False
    try:
        ke3_msg, _ = cli.login_finish(ls, ke2)
    except AuthenticationError:
        raised = True
    if not raised and ke3_msg is not None:
        try:
            srv.login_finalize(sls, ke3_msg)
        except AuthenticationError:
            raised = True
    assert raised, "Expected AuthenticationError for wrong OPAQUE password"


def test_opaque_server_oprf_derived_deterministically_from_private_key():
    # The prompt states: "The OPRF secret key is derived internally from
    # server_private_key via HKDF."  Two OpaqueServer instances constructed
    # with the same server_private_key must produce identical evaluated_element
    # for the same blinded request, proving deterministic (not random) derivation.
    _require()
    g = get_group("P-256")
    sk = g.random_scalar()
    pk = g.scalar_mult(sk, g.base_point())
    _, req = OpaqueClient(g).registration_request(b"pw")
    resp1 = OpaqueServer(g, sk, pk).registration_response(req)
    resp2 = OpaqueServer(g, sk, pk).registration_response(req)
    assert resp1.evaluated_element == resp2.evaluated_element


# ---------------------------------------------------------------------------
# X25519 incompatibility with all four protocols
# ---------------------------------------------------------------------------

def test_x25519_with_opaque_raises_not_implemented():
    _require()
    with pytest.raises(NotImplementedError):
        OpaqueClient(get_group("X25519")).registration_request(b"pw")


def test_x25519_with_spake2_raises_not_implemented():
    _require()
    with pytest.raises(NotImplementedError):
        SPAKE2Client(get_group("X25519")).start(b"pw")


def test_x25519_with_spake2plus_raises_not_implemented():
    _require()
    with pytest.raises(NotImplementedError):
        SPAKE2PlusClient(get_group("X25519")).start(b"pw", b"A", b"B")


def test_x25519_with_cpace_raises_not_implemented():
    _require()
    with pytest.raises(NotImplementedError):
        CPaceParty(get_group("X25519")).start(b"pw", b"chan", b"ctx")


# ---------------------------------------------------------------------------
# SPAKE2 -- dataclasses
# ---------------------------------------------------------------------------

def test_spake2_message_dataclass():
    _require()
    m = SPAKE2Message(element=b"\x04" + b"\x00" * 64)
    assert dataclasses.is_dataclass(m)
    assert m.element == b"\x04" + b"\x00" * 64


def test_spake2_confirm_message_dataclass():
    _require()
    m = SPAKE2ConfirmMessage(mac=b"\xff" * 32)
    assert dataclasses.is_dataclass(m)
    assert m.mac == b"\xff" * 32


def test_spake2_state_is_dataclass():
    _require()
    assert dataclasses.is_dataclass(SPAKE2State)


# ---------------------------------------------------------------------------
# SPAKE2 -- method return types
# ---------------------------------------------------------------------------

def test_spake2_client_start_return_type():
    _require()
    cs, cm = SPAKE2Client(get_group("P-256")).start(b"pw")
    assert isinstance(cs, SPAKE2State) and isinstance(cm, SPAKE2Message)


def test_spake2_server_start_return_type():
    _require()
    ss, sm = SPAKE2Server(get_group("P-256")).start(b"pw")
    assert isinstance(ss, SPAKE2State) and isinstance(sm, SPAKE2Message)


def test_spake2_client_finish_return_type():
    _require()
    g = get_group("P-256")
    c = SPAKE2Client(g)
    s = SPAKE2Server(g)
    cs, _ = c.start(b"pw")
    _, sm = s.start(b"pw")
    key, conf = c.finish(cs, sm)
    assert isinstance(key, bytes) and isinstance(conf, SPAKE2ConfirmMessage)


def test_spake2_server_finish_return_type():
    _require()
    g = get_group("P-256")
    c = SPAKE2Client(g)
    s = SPAKE2Server(g)
    _, cm = c.start(b"pw")
    ss, _ = s.start(b"pw")
    key, conf = s.finish(ss, cm)
    assert isinstance(key, bytes) and isinstance(conf, SPAKE2ConfirmMessage)


def test_spake2_client_confirm_return_type():
    _require()
    g = get_group("P-256")
    c = SPAKE2Client(g)
    s = SPAKE2Server(g)
    cs, cm = c.start(b"pw")
    ss, sm = s.start(b"pw")
    ckey, _ = c.finish(cs, sm)
    _, s_conf = s.finish(ss, cm)
    result = c.confirm(ckey, s_conf)
    assert isinstance(result, bytes) and len(result) > 0


def test_spake2_server_confirm_return_type():
    _require()
    g = get_group("P-256")
    c = SPAKE2Client(g)
    s = SPAKE2Server(g)
    cs, cm = c.start(b"pw")
    ss, sm = s.start(b"pw")
    ckey, c_conf = c.finish(cs, sm)
    skey, s_conf = s.finish(ss, cm)
    c.confirm(ckey, s_conf)
    result = s.confirm(skey, c_conf)
    assert isinstance(result, bytes) and len(result) > 0


def test_spake2_client_confirm_returns_same_session_key():
    # Prompt: "session_key is the key returned by the preceding finish call
    # and is passed through unchanged as the return value on success."
    _require()
    g = get_group("P-256")
    c = SPAKE2Client(g)
    s = SPAKE2Server(g)
    cs, cm = c.start(b"pw")
    ss, sm = s.start(b"pw")
    ckey, _ = c.finish(cs, sm)
    _, s_conf = s.finish(ss, cm)
    assert c.confirm(ckey, s_conf) == ckey


def test_spake2_server_confirm_returns_same_session_key():
    _require()
    g = get_group("P-256")
    c = SPAKE2Client(g)
    s = SPAKE2Server(g)
    cs, cm = c.start(b"pw")
    ss, sm = s.start(b"pw")
    ckey, c_conf = c.finish(cs, sm)
    skey, s_conf = s.finish(ss, cm)
    c.confirm(ckey, s_conf)
    assert s.confirm(skey, c_conf) == skey


# ---------------------------------------------------------------------------
# SPAKE2 -- full flows
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255"])
def test_spake2_full_flow_matching_keys(gname):
    _require()
    g = get_group(gname)
    c = SPAKE2Client(g)
    s = SPAKE2Server(g)
    cs, cm = c.start(b"pw")
    ss, sm = s.start(b"pw")
    ckey, c_conf = c.finish(cs, sm)
    skey, s_conf = s.finish(ss, cm)
    ck = c.confirm(ckey, s_conf)
    sk = s.confirm(skey, c_conf)
    assert ck == sk


def test_spake2_confirm_macs_use_distinct_role_labels():
    # Prompt: "The client sends `confirmP` (derived from the transcript and shared
    # key with a client-role label) and the server sends `confirmV` (server-role
    # label)." An implementation that uses the same label for both would produce
    # identical MACs; this test catches that bug.
    _require()
    g = get_group("P-256")
    c = SPAKE2Client(g)
    s = SPAKE2Server(g)
    cs, cm = c.start(b"pw")
    ss, sm = s.start(b"pw")
    _, c_conf = c.finish(cs, sm)
    _, s_conf = s.finish(ss, cm)
    assert c_conf.mac != s_conf.mac, (
        "confirmP and confirmV must use distinct role labels; got identical MACs"
    )


def test_spake2_client_start_produces_fresh_element_each_call():
    # Prompt: SPAKE2Client.start "Generates a random scalar" -- each call uses
    # a fresh random scalar, so two independent clients with the same password
    # produce different outgoing elements.
    _require()
    g = get_group("P-256")
    _, msg1 = SPAKE2Client(g).start(b"pw")
    _, msg2 = SPAKE2Client(g).start(b"pw")
    assert msg1.element != msg2.element


def test_spake2_server_start_produces_fresh_element_each_call():
    _require()
    g = get_group("P-256")
    _, msg1 = SPAKE2Server(g).start(b"pw")
    _, msg2 = SPAKE2Server(g).start(b"pw")
    assert msg1.element != msg2.element


def test_spake2_wrong_password_raises_authentication_error():
    _require()
    g = get_group("P-256")
    c = SPAKE2Client(g)
    s = SPAKE2Server(g)
    cs, cm = c.start(b"correct")
    ss, sm = s.start(b"wrong")
    ckey, c_conf = c.finish(cs, sm)
    skey, s_conf = s.finish(ss, cm)
    raised = False
    try:
        c.confirm(ckey, s_conf)
    except AuthenticationError:
        raised = True
    if not raised:
        try:
            s.confirm(skey, c_conf)
        except AuthenticationError:
            raised = True
    assert raised, "Expected AuthenticationError for mismatched SPAKE2 passwords"


def test_spake2plus_state_is_dataclass():
    _require()
    assert dataclasses.is_dataclass(SPAKE2PlusState)


def test_spake2plus_verifier_is_not_raw_password():
    _require()
    pw = b"raw-password"
    v = SPAKE2PlusServer(get_group("P-256")).create_verifier(pw)
    assert v != pw


def test_spake2plus_different_passwords_produce_different_verifiers():
    _require()
    srv = SPAKE2PlusServer(get_group("P-256"))
    assert srv.create_verifier(b"pw1") != srv.create_verifier(b"pw2")


# ---------------------------------------------------------------------------
# SPAKE2+ -- method return types
# ---------------------------------------------------------------------------

def test_spake2plus_client_start_return_type():
    _require()
    cs, cm = SPAKE2PlusClient(get_group("P-256")).start(b"pw", b"alice", b"bob")
    assert isinstance(cs, SPAKE2PlusState) and isinstance(cm, SPAKE2Message)


def test_spake2plus_server_start_return_type():
    _require()
    srv = SPAKE2PlusServer(get_group("P-256"))
    v = srv.create_verifier(b"pw")
    ss, sm = srv.start(v, b"alice", b"bob")
    assert isinstance(ss, SPAKE2PlusState) and isinstance(sm, SPAKE2Message)


def test_spake2plus_client_finish_return_type():
    _require()
    g = get_group("P-256")
    c = SPAKE2PlusClient(g)
    s = SPAKE2PlusServer(g)
    v = s.create_verifier(b"pw")
    cs, cm = c.start(b"pw", b"A", b"B")
    ss, sm = s.start(v, b"A", b"B")
    key, conf = c.finish(cs, sm)
    assert isinstance(key, bytes) and isinstance(conf, SPAKE2ConfirmMessage)


def test_spake2plus_server_finish_return_type():
    _require()
    g = get_group("P-256")
    c = SPAKE2PlusClient(g)
    s = SPAKE2PlusServer(g)
    v = s.create_verifier(b"pw")
    cs, cm = c.start(b"pw", b"A", b"B")
    ss, sm = s.start(v, b"A", b"B")
    c.finish(cs, sm)
    key, conf = s.finish(ss, cm)
    assert isinstance(key, bytes) and isinstance(conf, SPAKE2ConfirmMessage)


def test_spake2plus_client_confirm_return_type():
    _require()
    g = get_group("P-256")
    c = SPAKE2PlusClient(g)
    s = SPAKE2PlusServer(g)
    v = s.create_verifier(b"pw")
    cs, cm = c.start(b"pw", b"A", b"B")
    ss, sm = s.start(v, b"A", b"B")
    ckey, _ = c.finish(cs, sm)
    _, s_conf = s.finish(ss, cm)
    result = c.confirm(ckey, s_conf)
    assert isinstance(result, bytes) and len(result) > 0


def test_spake2plus_server_confirm_return_type():
    _require()
    g = get_group("P-256")
    c = SPAKE2PlusClient(g)
    s = SPAKE2PlusServer(g)
    v = s.create_verifier(b"pw")
    cs, cm = c.start(b"pw", b"A", b"B")
    ss, sm = s.start(v, b"A", b"B")
    ckey, c_conf = c.finish(cs, sm)
    skey, s_conf = s.finish(ss, cm)
    c.confirm(ckey, s_conf)
    result = s.confirm(skey, c_conf)
    assert isinstance(result, bytes) and len(result) > 0


def test_spake2plus_client_confirm_returns_same_session_key():
    # Prompt: "session_key is the key returned by the preceding finish call
    # and is passed through unchanged as the return value on success."
    _require()
    g = get_group("P-256")
    c = SPAKE2PlusClient(g)
    s = SPAKE2PlusServer(g)
    v = s.create_verifier(b"pw")
    cs, cm = c.start(b"pw", b"A", b"B")
    ss, sm = s.start(v, b"A", b"B")
    ckey, _ = c.finish(cs, sm)
    _, s_conf = s.finish(ss, cm)
    assert c.confirm(ckey, s_conf) == ckey


def test_spake2plus_server_confirm_returns_same_session_key():
    _require()
    g = get_group("P-256")
    c = SPAKE2PlusClient(g)
    s = SPAKE2PlusServer(g)
    v = s.create_verifier(b"pw")
    cs, cm = c.start(b"pw", b"A", b"B")
    ss, sm = s.start(v, b"A", b"B")
    ckey, c_conf = c.finish(cs, sm)
    skey, s_conf = s.finish(ss, cm)
    c.confirm(ckey, s_conf)
    assert s.confirm(skey, c_conf) == skey


# ---------------------------------------------------------------------------
# SPAKE2+ -- full flows
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255"])
def test_spake2plus_full_flow_matching_keys(gname):
    _require()
    g = get_group(gname)
    c = SPAKE2PlusClient(g)
    s = SPAKE2PlusServer(g)
    v = s.create_verifier(b"secret")
    cs, cm = c.start(b"secret", b"alice", b"bob")
    ss, sm = s.start(v, b"alice", b"bob")
    ckey, c_conf = c.finish(cs, sm)
    skey, s_conf = s.finish(ss, cm)
    ck = c.confirm(ckey, s_conf)
    sk = s.confirm(skey, c_conf)
    assert ck == sk


def test_spake2plus_confirm_macs_use_distinct_role_labels():
    # Prompt: same role-label requirement as SPAKE2 (SPAKE2+'s key confirmation
    # step follows the same pattern as SPAKE2). Both confirmP and confirmV must
    # use distinct labels; identical MACs would indicate a missing role distinction.
    _require()
    g = get_group("P-256")
    c = SPAKE2PlusClient(g)
    s = SPAKE2PlusServer(g)
    v = s.create_verifier(b"pw")
    cs, cm = c.start(b"pw", b"A", b"B")
    ss, sm = s.start(v, b"A", b"B")
    _, c_conf = c.finish(cs, sm)
    _, s_conf = s.finish(ss, cm)
    assert c_conf.mac != s_conf.mac, (
        "SPAKE2+ confirmP and confirmV must use distinct role labels; got identical MACs"
    )


def test_spake2plus_client_start_produces_fresh_element_each_call():
    # Prompt: SPAKE2PlusClient.start "Initiates the SPAKE2+ exchange from the
    # client's role, applying the client-role blinding factor." -- each call
    # uses a fresh random scalar, verified via two independent instances.
    _require()
    g = get_group("P-256")
    _, msg1 = SPAKE2PlusClient(g).start(b"pw", b"A", b"B")
    _, msg2 = SPAKE2PlusClient(g).start(b"pw", b"A", b"B")
    assert msg1.element != msg2.element


def test_spake2plus_server_start_produces_fresh_element_each_call():
    _require()
    g = get_group("P-256")
    v = SPAKE2PlusServer(g).create_verifier(b"pw")
    _, msg1 = SPAKE2PlusServer(g).start(v, b"A", b"B")
    _, msg2 = SPAKE2PlusServer(g).start(v, b"A", b"B")
    assert msg1.element != msg2.element


def test_spake2plus_wrong_password_raises_authentication_error():
    _require()
    g = get_group("P-256")
    c = SPAKE2PlusClient(g)
    s = SPAKE2PlusServer(g)
    v = s.create_verifier(b"correct")
    cs, cm = c.start(b"wrong", b"A", b"B")
    ss, sm = s.start(v, b"A", b"B")
    ckey, c_conf = c.finish(cs, sm)
    skey, s_conf = s.finish(ss, cm)
    raised = False
    try:
        c.confirm(ckey, s_conf)
    except AuthenticationError:
        raised = True
    if not raised:
        try:
            s.confirm(skey, c_conf)
        except AuthenticationError:
            raised = True
    assert raised, "Expected AuthenticationError for wrong SPAKE2+ password"


def test_spake2plus_different_identities_produce_different_keys():
    _require()
    g = get_group("P-256")

    def run(id_a, id_b):
        c = SPAKE2PlusClient(g)
        s = SPAKE2PlusServer(g)
        v = s.create_verifier(b"secret")
        cs, cm = c.start(b"secret", id_a, id_b)
        ss, sm = s.start(v, id_a, id_b)
        ckey, c_conf = c.finish(cs, sm)
        _, s_conf = s.finish(ss, cm)
        return c.confirm(ckey, s_conf)

    assert run(b"alice", b"bob") != run(b"carol", b"dave")


# ---------------------------------------------------------------------------
# CPace -- dataclasses
# ---------------------------------------------------------------------------

def test_cpace_message_dataclass():
    _require()
    m = CPaceMessage(element=b"\x01" * 32)
    assert dataclasses.is_dataclass(m)
    assert m.element == b"\x01" * 32


def test_cpace_state_is_dataclass():
    _require()
    assert dataclasses.is_dataclass(CPaceState)


# ---------------------------------------------------------------------------
# CPace -- method return types
# ---------------------------------------------------------------------------

def test_cpace_start_return_type():
    _require()
    st, msg = CPaceParty(get_group("P-256")).start(b"pw", b"chan", b"ctx")
    assert isinstance(st, CPaceState) and isinstance(msg, CPaceMessage)


def test_cpace_finish_returns_nonempty_bytes():
    _require()
    g = get_group("P-256")
    pa = CPaceParty(g)
    pb = CPaceParty(g)
    sa, ma = pa.start(b"pw", b"chan", b"ctx")
    _, mb = pb.start(b"pw", b"chan", b"ctx")
    key = pa.finish(sa, mb)
    assert isinstance(key, bytes) and len(key) > 0


# ---------------------------------------------------------------------------
# CPace -- full flows
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("gname", ["P-256", "P-384", "ristretto255"])
def test_cpace_full_flow_matching_keys(gname):
    _require()
    g = get_group(gname)
    pa = CPaceParty(g)
    pb = CPaceParty(g)
    ctx = b"shared-context"
    sa, ma = pa.start(b"password", b"channel", ctx)
    sb, mb = pb.start(b"password", b"channel", ctx)
    ka = pa.finish(sa, mb)
    kb = pb.finish(sb, ma)
    assert ka == kb


def test_cpace_different_passwords_produce_different_keys():
    _require()
    g = get_group("P-256")

    def run(pw):
        pa = CPaceParty(g)
        pb = CPaceParty(g)
        sa, ma = pa.start(pw, b"chan", b"ctx")
        _, mb = pb.start(pw, b"chan", b"ctx")
        return pa.finish(sa, mb)

    assert run(b"pw-one") != run(b"pw-two")


def test_cpace_different_channel_ids_produce_different_keys():
    _require()
    g = get_group("P-256")

    def run(chan):
        pa = CPaceParty(g)
        pb = CPaceParty(g)
        sa, ma = pa.start(b"pw", chan, b"ctx")
        _, mb = pb.start(b"pw", chan, b"ctx")
        return pa.finish(sa, mb)

    assert run(b"chan-A") != run(b"chan-B")


def test_cpace_different_shared_party_contexts_produce_different_keys():
    _require()
    g = get_group("P-256")

    def run(ctx):
        pa = CPaceParty(g)
        pb = CPaceParty(g)
        sa, ma = pa.start(b"pw", b"chan", ctx)
        _, mb = pb.start(b"pw", b"chan", ctx)
        return pa.finish(sa, mb)

    assert run(b"context-A") != run(b"context-B")


def test_cpace_mismatched_party_id_produces_incompatible_keys():
    # Prompt: "using distinct values on each side produces different generators
    # and incompatible session keys." (CPaceParty.start description)
    _require()
    g = get_group("P-256")
    pa = CPaceParty(g)
    pb = CPaceParty(g)
    sa, ma = pa.start(b"pw", b"chan", b"ctx-A")   # pa uses ctx-A
    sb, mb = pb.start(b"pw", b"chan", b"ctx-B")   # pb uses ctx-B (mismatch)
    ka = pa.finish(sa, mb)
    kb = pb.finish(sb, ma)
    assert ka != kb


def test_cpace_mismatched_channel_id_produces_incompatible_keys():
    # Prompt: "Both parties hash the shared password, a channel identifier ...
    # to a group point" -- mismatched channel_id on each side breaks the shared
    # generator, yielding incompatible session keys.
    _require()
    g = get_group("P-256")
    pa = CPaceParty(g)
    pb = CPaceParty(g)
    sa, ma = pa.start(b"pw", b"chan-A", b"ctx")   # pa uses chan-A
    sb, mb = pb.start(b"pw", b"chan-B", b"ctx")   # pb uses chan-B (mismatch)
    ka = pa.finish(sa, mb)
    kb = pb.finish(sb, ma)
    assert ka != kb


def test_cpace_start_applies_fresh_ephemeral_scalar_each_call():
    # Prompt: "Applies a fresh random ephemeral scalar to the derived generator
    # via scalar_mult" (CPaceParty.start description). Two independent parties
    # with identical inputs produce different outgoing elements.
    _require()
    g = get_group("P-256")
    _, msg1 = CPaceParty(g).start(b"pw", b"chan", b"ctx")
    _, msg2 = CPaceParty(g).start(b"pw", b"chan", b"ctx")
    assert msg1.element != msg2.element


# ---------------------------------------------------------------------------
# Augmented credential envelope
# ---------------------------------------------------------------------------

def test_augmented_envelope_dataclass():
    _require()
    env = AugmentedEnvelope(
        credential_tag=b"\x01" * 32, nonce=b"\x02" * 32, auth_tag=b"\x03" * 32
    )
    assert dataclasses.is_dataclass(env)
    assert env.credential_tag == b"\x01" * 32
    assert env.nonce == b"\x02" * 32
    assert env.auth_tag == b"\x03" * 32


def test_create_envelope_returns_augmented_envelope():
    _require()
    env = AugmentedCredentialManager(get_group("P-256")).create_envelope(b"verifier")
    assert isinstance(env, AugmentedEnvelope)


def test_create_envelope_produces_unique_nonces():
    _require()
    mgr = AugmentedCredentialManager(get_group("P-256"))
    env1 = mgr.create_envelope(b"same-verifier")
    env2 = mgr.create_envelope(b"same-verifier")
    assert env1.nonce != env2.nonce


def test_verify_envelope_correct_verifier_returns_true():
    _require()
    mgr = AugmentedCredentialManager(get_group("P-256"))
    verifier = b"the-verifier"
    env = mgr.create_envelope(verifier)
    assert mgr.verify_envelope(verifier, env) is True


def test_verify_envelope_wrong_verifier_returns_false():
    _require()
    mgr = AugmentedCredentialManager(get_group("P-256"))
    env = mgr.create_envelope(b"correct")
    assert mgr.verify_envelope(b"wrong", env) is False


def test_verify_envelope_tampered_credential_tag_returns_false():
    # Exercises the AEAD authentication path: a single flipped bit in the
    # credential_tag (ciphertext) must cause verify_envelope to return False.
    _require()
    mgr = AugmentedCredentialManager(get_group("P-256"))
    verifier = b"my-verifier"
    env = mgr.create_envelope(verifier)
    tampered = AugmentedEnvelope(
        credential_tag=bytes([env.credential_tag[0] ^ 0xFF]) + env.credential_tag[1:],
        nonce=env.nonce,
        auth_tag=env.auth_tag,
    )
    assert mgr.verify_envelope(verifier, tampered) is False


def test_verify_envelope_tampered_nonce_returns_false():
    # Prompt: "per-envelope nonce" -- a flipped nonce byte alters HKDF key
    # derivation, making the stored auth_tag inconsistent with the new nonce.
    _require()
    mgr = AugmentedCredentialManager(get_group("P-256"))
    verifier = b"my-verifier"
    env = mgr.create_envelope(verifier)
    tampered = AugmentedEnvelope(
        credential_tag=env.credential_tag,
        nonce=bytes([env.nonce[0] ^ 0xFF]) + env.nonce[1:],
        auth_tag=env.auth_tag,
    )
    assert mgr.verify_envelope(verifier, tampered) is False


def test_verify_envelope_tampered_auth_tag_returns_false():
    # Prompt: "authentication tag" -- the auth_tag covers the credential_tag;
    # a single flipped bit must be detected by constant-time comparison.
    _require()
    mgr = AugmentedCredentialManager(get_group("P-256"))
    verifier = b"my-verifier"
    env = mgr.create_envelope(verifier)
    tampered = AugmentedEnvelope(
        credential_tag=env.credential_tag,
        nonce=env.nonce,
        auth_tag=bytes([env.auth_tag[0] ^ 0xFF]) + env.auth_tag[1:],
    )
    assert mgr.verify_envelope(verifier, tampered) is False

def test_round_timing_dataclass():
    _require()
    rt = RoundTiming(protocol_name="p", round_label="r", elapsed_ns=1000)
    assert dataclasses.is_dataclass(rt)
    assert rt.protocol_name == "p"
    assert rt.round_label == "r"
    assert rt.elapsed_ns == 1000


def test_profiler_profile_round_returns_fn_result():
    _require()
    profiler = PAKEProfiler()
    result = profiler.profile_round("p", "r", lambda x: x * 2, 21)
    assert result == 42


def test_profiler_profile_round_forwards_kwargs():
    # Prompt: "fn: Callable[..., Any], *args: Any, **kwargs: Any" and
    # "Calls fn(*args, **kwargs)" -- keyword arguments must reach the callable.
    _require()
    profiler = PAKEProfiler()
    result = profiler.profile_round("p", "r", lambda **kw: kw["v"] * 2, v=21)
    assert result == 42


def test_profiler_get_report_aggregates_multiple_samples_for_same_key():
    # Prompt: "1e9 / mean(elapsed_ns) over all recorded samples for that combination"
    # Five calls to the same (name, label) must produce a single aggregated float,
    # not N separate values or just the latest sample.
    _require()
    profiler = PAKEProfiler()
    for _ in range(5):
        profiler.profile_round("p", "r", lambda: None)
    report = profiler.get_report()
    assert isinstance(report["p"]["r"], float)
    assert report["p"]["r"] > 0


def test_profiler_profile_round_records_entry():
    _require()
    profiler = PAKEProfiler()
    profiler.profile_round("myproto", "myrnd", lambda: None)
    report = profiler.get_report()
    assert "myproto" in report and "myrnd" in report["myproto"]


def test_profiler_distinct_keys_are_tracked_independently():
    # Prompt: "keyed by protocol_name and round_label" -- two different
    # (protocol_name, round_label) combinations must produce separate,
    # independent entries in the nested report dict.
    _require()
    profiler = PAKEProfiler()
    profiler.profile_round("proto_A", "round_1", lambda: None)
    profiler.profile_round("proto_B", "round_2", lambda: None)
    report = profiler.get_report()
    assert "proto_A" in report and "round_1" in report["proto_A"]
    assert "proto_B" in report and "round_2" in report["proto_B"]
    assert "round_2" not in report.get("proto_A", {})
    assert "round_1" not in report.get("proto_B", {})


def test_profiler_get_report_returns_positive_float_throughput():
    _require()
    profiler = PAKEProfiler()
    profiler.profile_round("p", "r", lambda: None)
    report = profiler.get_report()
    assert isinstance(report, dict)
    tput = report["p"]["r"]
    assert isinstance(tput, float) and tput > 0


def test_profiler_get_report_empty_when_no_rounds():
    _require()
    assert PAKEProfiler().get_report() == {}


def test_profiler_records_elapsed_in_nanoseconds():
    # Prompt: "records per-call wall-clock duration in nanoseconds"
    # Profile a ~1 ms sleep. If elapsed is in nanoseconds, throughput ~ 1000.
    # If elapsed were in microseconds, throughput would be ~ 1e6 (> 100_000).
    # Wide upper bound tolerates heavy scheduling jitter (up to ~100 ms actual sleep).
    _require()
    profiler = PAKEProfiler()
    profiler.profile_round("p", "r", time.sleep, 0.001)
    tput = profiler.get_report()["p"]["r"]
    assert tput > 0.1, "throughput must be positive"
    assert tput < 100_000, "throughput inconsistent with nanosecond timing (unit error?)"


def test_profiler_is_thread_safe():
    # Prompt: "The profiler must be thread-safe."
    # All threads use the same (protocol_name, round_label) key to exercise
    # the critical race: concurrent appends to the same per-key accumulator.
    _require()
    profiler = PAKEProfiler()
    errors = []

    def worker():
        try:
            profiler.profile_round("p", "r", time.sleep, 0.001)
        except Exception as exc:
            errors.append(exc)

    threads = [threading.Thread(target=worker) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors
    report = profiler.get_report()
    assert isinstance(report["p"]["r"], float) and report["p"]["r"] > 0


# ---------------------------------------------------------------------------
# AuthenticationError
# ---------------------------------------------------------------------------

def test_authentication_error_is_exception_subclass():
    _require()
    assert issubclass(AuthenticationError, Exception)


def test_authentication_error_can_be_raised_and_caught():
    _require()
    with pytest.raises(AuthenticationError):
        raise AuthenticationError("test error")