#!/usr/bin/env python3
"""
Comprehensive integration test suite for the RentalYard cooperative equipment rental API.
Tests all interfaces defined in the prompt.
"""

import sys
import json
import uuid

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

BASE_URL = "http://localhost:8080"

# ============================================================
# Single source of truth for test names
# ============================================================
TEST_NAMES = [
    # Sample Data on Startup (run first - before tests modify state)
    "test_sample_data_open_dispute",
    "test_sample_data_peak_season_config",
    "test_sample_data_committee_config",
    "test_default_member_discount",

    # Member Management
    "test_create_member",
    "test_create_member_returns_id",
    "test_get_member",
    "test_get_member_not_found",

    # Equipment Management
    "test_register_equipment",
    "test_register_equipment_invalid_owner",
    "test_get_equipment",
    "test_get_equipment_not_found",
    "test_list_equipment_by_owner",
    "test_list_equipment_by_owner_not_found",
    "test_list_equipment_by_owner_empty",

    # Rental Request Lifecycle
    "test_create_rental_request",
    "test_create_rental_initial_status_pending",
    "test_create_rental_outside_availability_window",
    "test_create_rental_overlap_with_pending",
    "test_create_rental_overlap_with_approved",
    "test_approve_rental",
    "test_approve_rental_not_pending",
    "test_reject_rental",
    "test_reject_rental_not_pending",
    "test_complete_rental",
    "test_complete_rental_not_approved",
    "test_approve_rental_not_found",
    "test_reject_rental_not_found",
    "test_complete_rental_not_found",
    "test_get_rental",
    "test_get_rental_not_found",

    # Rental Cost Computation
    "test_rental_cost_basic",
    "test_rental_cost_coop_member_discount",
    "test_rental_cost_discount_applied_after_peak_surcharge",
    "test_rental_cost_no_discount_for_non_coop_member",
    "test_rental_cost_peak_season_surcharge",
    "test_rental_cost_highest_peak_multiplier",
    "test_rental_cost_mixed_peak_and_base_days",

    # Deposit Management
    "test_deposit_status_null_before_approve",
    "test_deposit_status_held_after_approve",
    "test_deposit_status_released_on_complete",
    "test_get_deposit_hold",
    "test_get_deposit_hold_not_found",
    "test_get_deposit_hold_no_hold_exists",

    # Printable Handover Checklist
    "test_handover_checklist_content_type_html",
    "test_handover_checklist_contains_required_elements",
    "test_handover_checklist_not_approved_returns_error",
    "test_handover_checklist_not_found",

    # Damage Disputes and Arbitration
    "test_open_dispute",
    "test_open_dispute_initial_status_open",
    "test_open_dispute_duplicate_returns_error",
    "test_open_dispute_invalid_rental_status",
    "test_open_dispute_on_completed_rental",
    "test_submit_vote",
    "test_submit_vote_not_committee_member",
    "test_submit_vote_duplicate_vote",
    "test_submit_vote_resolved_dispute",
    "test_get_dispute",
    "test_get_dispute_not_found",
    "test_dispute_resolution_owner_favored",
    "test_dispute_resolution_renter_favored",
    "test_dispute_tie_renter_favored",
    "test_deposit_forfeited_on_owner_favored",
    "test_deposit_released_on_renter_favored",

    # System Configuration
    "test_add_peak_season_period",
    "test_list_peak_season_periods",
    "test_multiple_peak_season_periods_coexist",
    "test_set_arbitration_committee",
    "test_set_arbitration_committee_invalid_member",
    "test_get_arbitration_committee",
    "test_set_member_discount",
    "test_get_member_discount",

    # Reports
    "test_member_earnings_report",
    "test_member_earnings_report_not_found",
    "test_disputed_transactions_report",
    "test_equipment_utilization_report",
    "test_equipment_utilization_report_not_found",
]


# ============================================================
# HTTP helpers
# ============================================================

def api(method, path, **kwargs):
    if not REQUESTS_AVAILABLE:
        raise AssertionError("requests library not available")
    try:
        response = getattr(requests, method)(
            f"{BASE_URL}{path}", timeout=10, **kwargs
        )
        return response
    except requests.exceptions.ConnectionError:
        raise AssertionError("Cannot connect to server at " + BASE_URL)
    except Exception as e:
        raise AssertionError(f"Request failed: {e}")


def create_member(name, email, coop_member=True):
    r = api("post", "/api/members", json={"name": name, "email": email, "coopMember": coop_member})
    assert r.status_code == 201, f"create_member failed: {r.status_code} {r.text}"
    return r.json()


def create_equipment(owner_id, name, description, daily_rate, deposit_amount,
                     condition, available_from, available_to):
    r = api("post", "/api/equipment", json={
        "ownerId": owner_id, "name": name, "description": description,
        "dailyRate": daily_rate, "depositAmount": deposit_amount,
        "condition": condition, "availableFrom": available_from, "availableTo": available_to
    })
    assert r.status_code == 201, f"create_equipment failed: {r.status_code} {r.text}"
    return r.json()


def create_rental(equipment_id, renter_id, start_date, end_date):
    r = api("post", "/api/rentals", json={
        "equipmentId": equipment_id, "renterId": renter_id,
        "startDate": start_date, "endDate": end_date
    })
    assert r.status_code == 201, f"create_rental failed: {r.status_code} {r.text}"
    return r.json()


def setup_approved_rental():
    """Create member, equipment, rental, then approve it. Returns (rental_json, owner, renter, equip)."""
    uid = uuid.uuid4().hex[:8]
    owner = create_member(f"Owner Test {uid}", f"owner_{uid}@test.com", False)
    renter = create_member(f"Renter Test {uid}", f"renter_{uid}@test.com", False)
    equip = create_equipment(
        owner["id"], f"Test Tool {uid}", "A test tool",
        50.0, 100.0, "Good", "2030-01-01", "2030-12-31"
    )
    rental = create_rental(equip["id"], renter["id"], "2030-03-01", "2030-03-03")
    r = api("post", f"/api/rentals/{rental['id']}/approve")
    assert r.status_code == 200
    return r.json(), owner, renter, equip


def setup_committee_with_voters():
    """Creates 2 members, sets them as the committee, returns (dispute, voter1, voter2, rental)."""
    uid = uuid.uuid4().hex[:8]
    voter1 = create_member(f"Voter A {uid}", f"voter_a_{uid}@test.com", False)
    voter2 = create_member(f"Voter B {uid}", f"voter_b_{uid}@test.com", False)
    # Set committee to these two members
    r = api("post", "/api/config/committee", json={"memberIds": [voter1["id"], voter2["id"]]})
    assert r.status_code == 200

    # Create a rental in APPROVED state to dispute
    owner = create_member(f"Owner D {uid}", f"owner_d_{uid}@test.com", False)
    renter = create_member(f"Renter D {uid}", f"renter_d_{uid}@test.com", False)
    equip = create_equipment(
        owner["id"], f"Tool D {uid}", "desc", 10.0, 20.0, "Good", "2030-01-01", "2030-12-31"
    )
    rental = create_rental(equip["id"], renter["id"], "2030-05-01", "2030-05-02")
    api("post", f"/api/rentals/{rental['id']}/approve")

    r = api("post", "/api/disputes", json={"rentalId": rental["id"], "description": "Dispute test"})
    assert r.status_code == 201
    return r.json(), voter1, voter2, rental


# ============================================================
# Sample Data Tests (run FIRST - fresh DB)
# ============================================================

def test_sample_data_open_dispute():
    """Startup seeds exactly 1 open dispute, verifiable via the disputed transactions report."""
    r = api("get", "/api/reports/disputes")
    assert r.status_code == 200
    body = r.json()
    assert isinstance(body, list)
    open_disputes = [e for e in body if e.get("disputeStatus") == "OPEN"]
    assert len(open_disputes) == 1, (
        f"Expected exactly 1 OPEN dispute from sample data, got {len(open_disputes)}"
    )


def test_sample_data_peak_season_config():
    """Startup seeds 1 peak season period."""
    r = api("get", "/api/config/peak-season")
    assert r.status_code == 200
    periods = r.json()
    assert isinstance(periods, list)
    assert len(periods) == 1, f"Expected exactly 1 seeded peak season period, got {len(periods)}"


def test_sample_data_committee_config():
    """Startup sets arbitration committee to exactly 2 member IDs."""
    r = api("get", "/api/config/committee")
    assert r.status_code == 200
    body = r.json()
    assert "memberIds" in body
    assert len(body["memberIds"]) == 2


def test_default_member_discount():
    """Default member discount is 10.0 on startup."""
    r = api("get", "/api/config/member-discount")
    assert r.status_code == 200
    body = r.json()
    assert "discountPercentage" in body
    assert body["discountPercentage"] == 10.0


# ============================================================
# Member Management
# ============================================================

def test_create_member():
    """POST /api/members creates a member and returns 201."""
    r = api("post", "/api/members", json={
        "name": "Jane Smith", "email": "jane@test.com", "coopMember": True
    })
    assert r.status_code == 201
    body = r.json()
    assert body["name"] == "Jane Smith"
    assert body["email"] == "jane@test.com"
    assert body["coopMember"] is True


def test_create_member_returns_id():
    """Created member has an assigned ID."""
    r = api("post", "/api/members", json={
        "name": "ID Test", "email": "idtest@test.com", "coopMember": False
    })
    assert r.status_code == 201
    body = r.json()
    assert "id" in body
    assert body["id"] is not None
    assert isinstance(body["id"], int)


def test_get_member():
    """GET /api/members/{id} returns the member."""
    member = create_member("Get Test", "gettest@test.com", True)
    r = api("get", f"/api/members/{member['id']}")
    assert r.status_code == 200
    body = r.json()
    assert body["id"] == member["id"]
    assert body["name"] == "Get Test"
    assert body["email"] == "gettest@test.com"
    assert body["coopMember"] is True


def test_get_member_not_found():
    """GET /api/members/{id} with non-existent ID returns 404."""
    r = api("get", "/api/members/999999")
    assert r.status_code == 404


# ============================================================
# Equipment Management
# ============================================================

def test_register_equipment():
    """POST /api/equipment creates equipment and returns 201."""
    owner = create_member("Equip Owner", "equip_owner@test.com", True)
    r = api("post", "/api/equipment", json={
        "ownerId": owner["id"],
        "name": "Power Drill",
        "description": "Cordless power drill",
        "dailyRate": 25.0,
        "depositAmount": 80.0,
        "condition": "Excellent",
        "availableFrom": "2030-01-01",
        "availableTo": "2030-12-31"
    })
    assert r.status_code == 201
    body = r.json()
    assert body["ownerId"] == owner["id"]
    assert body["name"] == "Power Drill"
    assert body["dailyRate"] == 25.0
    assert body["depositAmount"] == 80.0
    assert body["description"] == "Cordless power drill"
    assert body["condition"] == "Excellent"
    assert body["availableFrom"] == "2030-01-01"
    assert body["availableTo"] == "2030-12-31"
    assert "id" in body


def test_register_equipment_invalid_owner():
    """POST /api/equipment with non-existent ownerId returns 400."""
    r = api("post", "/api/equipment", json={
        "ownerId": 999999,
        "name": "Invalid Owner Tool",
        "description": "desc",
        "dailyRate": 10.0,
        "depositAmount": 30.0,
        "condition": "Good",
        "availableFrom": "2030-01-01",
        "availableTo": "2030-12-31"
    })
    assert r.status_code == 400


def test_get_equipment():
    """GET /api/equipment/{id} returns the equipment."""
    owner = create_member("Equip Owner 2", "equip_owner2@test.com", True)
    equip = create_equipment(owner["id"], "Laser Level", "Laser leveling tool",
                             30.0, 50.0, "Good", "2030-01-01", "2030-12-31")
    r = api("get", f"/api/equipment/{equip['id']}")
    assert r.status_code == 200
    body = r.json()
    assert body["id"] == equip["id"]
    assert body["name"] == "Laser Level"
    assert body["ownerId"] == owner["id"]


def test_get_equipment_not_found():
    """GET /api/equipment/{id} with non-existent ID returns 404."""
    r = api("get", "/api/equipment/999999")
    assert r.status_code == 404


def test_list_equipment_by_owner():
    """GET /api/members/{ownerId}/equipment returns all equipment for that owner."""
    owner = create_member("Multi Owner", "multi_owner@test.com", True)
    equip1 = create_equipment(owner["id"], "Tool A", "desc", 10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    equip2 = create_equipment(owner["id"], "Tool B", "desc", 15.0, 25.0, "Fair", "2030-01-01", "2030-12-31")
    r = api("get", f"/api/members/{owner['id']}/equipment")
    assert r.status_code == 200
    items = r.json()
    assert isinstance(items, list)
    ids = [item["id"] for item in items]
    assert equip1["id"] in ids
    assert equip2["id"] in ids


def test_list_equipment_by_owner_not_found():
    """GET /api/members/{ownerId}/equipment with non-existent owner returns 404."""
    r = api("get", "/api/members/999999/equipment")
    assert r.status_code == 404


def test_list_equipment_by_owner_empty():
    """GET /api/members/{ownerId}/equipment returns empty array when owner has no listings."""
    owner = create_member("No Equipment Owner", "no_equip_owner@test.com", True)
    r = api("get", f"/api/members/{owner['id']}/equipment")
    assert r.status_code == 200
    body = r.json()
    assert isinstance(body, list)
    assert len(body) == 0

# ============================================================
# Rental Request Lifecycle
# ============================================================

def test_create_rental_request():
    """POST /api/rentals creates a rental request and returns 201."""
    owner = create_member("Rental Owner 1", "rental_owner1@test.com", False)
    renter = create_member("Rental Renter 1", "rental_renter1@test.com", False)
    equip = create_equipment(owner["id"], "Test Rental Tool 1", "desc",
                              40.0, 80.0, "Good", "2030-01-01", "2030-12-31")
    r = api("post", "/api/rentals", json={
        "equipmentId": equip["id"], "renterId": renter["id"],
        "startDate": "2030-04-01", "endDate": "2030-04-05"
    })
    assert r.status_code == 201
    body = r.json()
    assert body["equipmentId"] == equip["id"]
    assert body["renterId"] == renter["id"]
    assert body["startDate"] == "2030-04-01"
    assert body["endDate"] == "2030-04-05"
    assert "id" in body


def test_create_rental_initial_status_pending():
    """New rental requests start with PENDING status."""
    owner = create_member("Pending Owner", "pending_owner@test.com", False)
    renter = create_member("Pending Renter", "pending_renter@test.com", False)
    equip = create_equipment(owner["id"], "Pending Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    r = api("post", "/api/rentals", json={
        "equipmentId": equip["id"], "renterId": renter["id"],
        "startDate": "2030-05-01", "endDate": "2030-05-02"
    })
    assert r.status_code == 201
    body = r.json()
    assert body["status"] == "PENDING"
    assert body["computedCost"] is None


def test_create_rental_outside_availability_window():
    """Rental outside availability window returns 400 with WINDOW_OUTSIDE_AVAILABILITY code."""
    owner = create_member("Window Owner", "window_owner@test.com", False)
    renter = create_member("Window Renter", "window_renter@test.com", False)
    equip = create_equipment(owner["id"], "Window Tool", "desc",
                              10.0, 20.0, "Good", "2030-06-01", "2030-06-30")
    r = api("post", "/api/rentals", json={
        "equipmentId": equip["id"], "renterId": renter["id"],
        "startDate": "2030-05-01",  # before availableFrom
        "endDate": "2030-05-10"
    })
    assert r.status_code == 400
    body = r.json()
    assert "code" in body
    assert body["code"] == "WINDOW_OUTSIDE_AVAILABILITY"


def test_create_rental_overlap_with_pending():
    """Rental overlapping a PENDING booking returns 400 with DATE_OVERLAP_CONFLICT code."""
    owner = create_member("Overlap Pending Owner", "overlap_p_owner@test.com", False)
    renter1 = create_member("Overlap Renter P1", "overlap_p1@test.com", False)
    renter2 = create_member("Overlap Renter P2", "overlap_p2@test.com", False)
    equip = create_equipment(owner["id"], "Overlap Pending Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    # First booking (stays PENDING)
    create_rental(equip["id"], renter1["id"], "2030-07-01", "2030-07-10")
    # Second overlapping booking
    r = api("post", "/api/rentals", json={
        "equipmentId": equip["id"], "renterId": renter2["id"],
        "startDate": "2030-07-05", "endDate": "2030-07-15"
    })
    assert r.status_code == 400
    body = r.json()
    assert "code" in body
    assert body["code"] == "DATE_OVERLAP_CONFLICT"


def test_create_rental_overlap_with_approved():
    """Rental overlapping an APPROVED booking returns 400 with DATE_OVERLAP_CONFLICT code."""
    owner = create_member("Overlap Appr Owner", "overlap_a_owner@test.com", False)
    renter1 = create_member("Overlap Renter A1", "overlap_a1@test.com", False)
    renter2 = create_member("Overlap Renter A2", "overlap_a2@test.com", False)
    equip = create_equipment(owner["id"], "Overlap Appr Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    # First booking - approve it
    rental = create_rental(equip["id"], renter1["id"], "2030-08-01", "2030-08-10")
    api("post", f"/api/rentals/{rental['id']}/approve")
    # Second overlapping booking
    r = api("post", "/api/rentals", json={
        "equipmentId": equip["id"], "renterId": renter2["id"],
        "startDate": "2030-08-05", "endDate": "2030-08-15"
    })
    assert r.status_code == 400
    body = r.json()
    assert "code" in body
    assert body["code"] == "DATE_OVERLAP_CONFLICT"


def test_approve_rental():
    """POST /api/rentals/{id}/approve transitions rental to APPROVED with computed cost and deposit held."""
    owner = create_member("Approve Owner", "approve_owner@test.com", False)
    renter = create_member("Approve Renter", "approve_renter@test.com", False)
    equip = create_equipment(owner["id"], "Approve Tool", "desc",
                              30.0, 60.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-09-01", "2030-09-03")  # 3 days
    r = api("post", f"/api/rentals/{rental['id']}/approve")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "APPROVED"
    assert body["computedCost"] is not None
    assert body["computedCost"] > 0
    assert body["depositStatus"] == "HELD"


def test_approve_rental_not_pending():
    """Approving a non-PENDING rental returns 400."""
    owner = create_member("Appr2 Owner", "appr2_owner@test.com", False)
    renter = create_member("Appr2 Renter", "appr2_renter@test.com", False)
    equip = create_equipment(owner["id"], "Appr2 Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-10-01", "2030-10-02")
    api("post", f"/api/rentals/{rental['id']}/approve")  # first approve
    r = api("post", f"/api/rentals/{rental['id']}/approve")  # second approve - should fail
    assert r.status_code == 400


def test_reject_rental():
    """POST /api/rentals/{id}/reject transitions rental to REJECTED with null cost and deposit."""
    owner = create_member("Reject Owner", "reject_owner@test.com", False)
    renter = create_member("Reject Renter", "reject_renter@test.com", False)
    equip = create_equipment(owner["id"], "Reject Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-11-01", "2030-11-02")
    r = api("post", f"/api/rentals/{rental['id']}/reject")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "REJECTED"
    assert body.get("computedCost") is None
    assert body.get("depositStatus") is None


def test_reject_rental_not_pending():
    """Rejecting a non-PENDING rental returns 400."""
    owner = create_member("Rej2 Owner", "rej2_owner@test.com", False)
    renter = create_member("Rej2 Renter", "rej2_renter@test.com", False)
    equip = create_equipment(owner["id"], "Rej2 Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-11-10", "2030-11-11")
    api("post", f"/api/rentals/{rental['id']}/reject")  # first reject
    r = api("post", f"/api/rentals/{rental['id']}/reject")  # second reject - should fail
    assert r.status_code == 400


def test_complete_rental():
    """POST /api/rentals/{id}/complete transitions APPROVED rental to COMPLETED with deposit released."""
    owner = create_member("Complete Owner", "complete_owner@test.com", False)
    renter = create_member("Complete Renter", "complete_renter@test.com", False)
    equip = create_equipment(owner["id"], "Complete Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-12-01", "2030-12-03")
    api("post", f"/api/rentals/{rental['id']}/approve")
    r = api("post", f"/api/rentals/{rental['id']}/complete")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "COMPLETED"
    assert body["depositStatus"] == "RELEASED"


def test_complete_rental_not_approved():
    """Completing a non-APPROVED rental returns 400."""
    owner = create_member("Comp2 Owner", "comp2_owner@test.com", False)
    renter = create_member("Comp2 Renter", "comp2_renter@test.com", False)
    equip = create_equipment(owner["id"], "Comp2 Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-01-15", "2030-01-16")
    # still PENDING - trying to complete should fail
    r = api("post", f"/api/rentals/{rental['id']}/complete")
    assert r.status_code == 400


def test_approve_rental_not_found():
    """POST /api/rentals/{id}/approve with non-existent rental returns 404."""
    r = api("post", "/api/rentals/999999/approve")
    assert r.status_code == 404


def test_reject_rental_not_found():
    """POST /api/rentals/{id}/reject with non-existent rental returns 404."""
    r = api("post", "/api/rentals/999999/reject")
    assert r.status_code == 404


def test_complete_rental_not_found():
    """POST /api/rentals/{id}/complete with non-existent rental returns 404."""
    r = api("post", "/api/rentals/999999/complete")
    assert r.status_code == 404


def test_get_rental():
    """GET /api/rentals/{id} returns the full rental record."""
    owner = create_member("Get Rental Owner", "get_rental_owner@test.com", False)
    renter = create_member("Get Rental Renter", "get_rental_renter@test.com", False)
    equip = create_equipment(owner["id"], "Get Rental Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-02-01", "2030-02-03")
    r = api("get", f"/api/rentals/{rental['id']}")
    assert r.status_code == 200
    body = r.json()
    assert body["id"] == rental["id"]
    assert body["equipmentId"] == equip["id"]
    assert body["renterId"] == renter["id"]
    assert "status" in body
    assert "startDate" in body
    assert "endDate" in body


def test_get_rental_not_found():
    """GET /api/rentals/{id} with non-existent ID returns 404."""
    r = api("get", "/api/rentals/999999")
    assert r.status_code == 404


# ============================================================
# Rental Cost Computation
# ============================================================

def test_rental_cost_basic():
    """Basic cost: dailyRate × numberOfDays (inclusive)."""
    # Set discount to 0 so coopMember doesn't affect this test
    api("post", "/api/config/member-discount", json={"discountPercentage": 0.0})
    owner = create_member("Cost Basic Owner", "cost_basic_owner@test.com", False)
    renter = create_member("Cost Basic Renter", "cost_basic_renter@test.com", False)
    equip = create_equipment(owner["id"], "Basic Cost Tool", "desc",
                              100.0, 200.0, "Good", "2038-01-01", "2038-12-31")
    rental = create_rental(equip["id"], renter["id"], "2038-02-01", "2038-02-05")  # 5 days
    r = api("post", f"/api/rentals/{rental['id']}/approve")
    assert r.status_code == 200
    cost = r.json()["computedCost"]
    # 5 days × $100 = $500 (no discount, no peak season in this far-future window)
    assert abs(cost - 500.0) < 0.01, f"Expected 500.0, got {cost}"


def test_rental_cost_coop_member_discount():
    """CoopMember renter gets configured discount applied to total."""
    # Set discount to 10%
    api("post", "/api/config/member-discount", json={"discountPercentage": 10.0})
    owner = create_member("Discount Owner", "discount_owner@test.com", False)
    renter_coop = create_member("Discount Renter Coop", "discount_coop@test.com", True)
    equip = create_equipment(owner["id"], "Discount Tool", "desc",
                              100.0, 200.0, "Good", "2038-01-01", "2038-12-31")
    rental = create_rental(equip["id"], renter_coop["id"], "2038-03-01", "2038-03-05")  # 5 days
    r = api("post", f"/api/rentals/{rental['id']}/approve")
    assert r.status_code == 200
    cost = r.json()["computedCost"]
    # 5 × $100 = $500, then 10% discount → $450
    assert abs(cost - 450.0) < 0.01, f"Expected 450.0 with 10% discount, got {cost}"


def test_rental_cost_discount_applied_after_peak_surcharge():
    """Coop discount is applied to the post-surcharge total, not to the base cost."""
    api("post", "/api/config/member-discount", json={"discountPercentage": 10.0})
    # Peak season covers only part of the rental window
    api("post", "/api/config/peak-season", json={
        "startDate": "2037-09-03", "endDate": "2037-09-04", "multiplier": 2.0
    })
    owner = create_member("Order Ops Owner", "order_ops_owner@test.com", False)
    renter_coop = create_member("Order Ops Coop", "order_ops_coop@test.com", True)
    equip = create_equipment(owner["id"], "Order Ops Tool", "desc",
                              100.0, 200.0, "Good", "2037-01-01", "2037-12-31")
    # 2037-09-01 to 2037-09-04: 4 days
    # 2037-09-01, 2037-09-02 → base: 2 × $100 = $200
    # 2037-09-03, 2037-09-04 → peak: 2 × $100 × 2.0 = $400
    # Post-surcharge subtotal = $600; 10% discount applied after → $540
    rental = create_rental(equip["id"], renter_coop["id"], "2037-09-01", "2037-09-04")
    r = api("post", f"/api/rentals/{rental['id']}/approve")
    assert r.status_code == 200
    cost = r.json()["computedCost"]
    assert abs(cost - 540.0) < 0.01, (
        f"Expected 540.0 (discount on post-surcharge total), got {cost}. "
        "Discount must be applied after peak surcharge computation."
    )


def test_rental_cost_no_discount_for_non_coop_member():
    """Non-coop renter does not receive the configured discount."""
    api("post", "/api/config/member-discount", json={"discountPercentage": 10.0})
    owner = create_member("NonCoop Disc Owner", "noncoop_disc_owner@test.com", False)
    renter_non_coop = create_member("NonCoop Disc Renter", "noncoop_disc_renter@test.com", False)
    equip = create_equipment(owner["id"], "NonCoop Disc Tool", "desc",
                              100.0, 200.0, "Good", "2037-01-01", "2037-12-31")
    # 5 days × $100, no peak season in this window, discount 10% but renter is not coop
    rental = create_rental(equip["id"], renter_non_coop["id"], "2037-10-01", "2037-10-05")
    r = api("post", f"/api/rentals/{rental['id']}/approve")
    assert r.status_code == 200
    cost = r.json()["computedCost"]
    assert abs(cost - 500.0) < 0.01, (
        f"Expected 500.0 (no discount for non-coop renter), got {cost}. "
        "Discount must only apply when coopMember is true."
    )


def test_rental_cost_peak_season_surcharge():
    """Days in a peak season period use dailyRate × peakMultiplier."""
    # Set discount to 0
    api("post", "/api/config/member-discount", json={"discountPercentage": 0.0})
    # Add a peak season period that covers our rental dates
    r = api("post", "/api/config/peak-season", json={
        "startDate": "2031-07-01", "endDate": "2031-07-31", "multiplier": 2.0
    })
    assert r.status_code == 201

    owner = create_member("Peak Owner", "peak_owner@test.com", False)
    renter = create_member("Peak Renter", "peak_renter@test.com", False)
    equip = create_equipment(owner["id"], "Peak Tool", "desc",
                              50.0, 100.0, "Good", "2031-01-01", "2031-12-31")
    # 3 days entirely in peak season
    rental = create_rental(equip["id"], renter["id"], "2031-07-01", "2031-07-03")
    r = api("post", f"/api/rentals/{rental['id']}/approve")
    assert r.status_code == 200
    cost = r.json()["computedCost"]
    # 3 days × $50 × 2.0 = $300
    assert abs(cost - 300.0) < 0.01, f"Expected 300.0 for peak season, got {cost}"


def test_rental_cost_highest_peak_multiplier():
    """When multiple peak seasons overlap a day, the highest multiplier applies."""
    api("post", "/api/config/member-discount", json={"discountPercentage": 0.0})
    # Two overlapping peak periods: multiplier 1.5 and 3.0 → should use 3.0
    api("post", "/api/config/peak-season", json={
        "startDate": "2032-06-01", "endDate": "2032-06-30", "multiplier": 1.5
    })
    api("post", "/api/config/peak-season", json={
        "startDate": "2032-06-10", "endDate": "2032-06-20", "multiplier": 3.0
    })
    owner = create_member("MultiPeak Owner", "multipeak_owner@test.com", False)
    renter = create_member("MultiPeak Renter", "multipeak_renter@test.com", False)
    equip = create_equipment(owner["id"], "MultiPeak Tool", "desc",
                              10.0, 20.0, "Good", "2032-01-01", "2032-12-31")
    # 1 day in overlap zone - should use 3.0
    rental = create_rental(equip["id"], renter["id"], "2032-06-15", "2032-06-15")
    r = api("post", f"/api/rentals/{rental['id']}/approve")
    assert r.status_code == 200
    cost = r.json()["computedCost"]
    # 1 day × $10 × 3.0 = $30
    assert abs(cost - 30.0) < 0.01, f"Expected 30.0 using highest multiplier, got {cost}"


def test_rental_cost_mixed_peak_and_base_days():
    """Rental straddling peak boundary: peak days use multiplier, non-peak days use base rate."""
    api("post", "/api/config/member-discount", json={"discountPercentage": 0.0})
    # Peak season: 2036-08-15 to 2036-08-31, multiplier 2.0
    api("post", "/api/config/peak-season", json={
        "startDate": "2036-08-15", "endDate": "2036-08-31", "multiplier": 2.0
    })
    owner = create_member("Mixed Peak Owner", "mixed_peak_owner@test.com", False)
    renter = create_member("Mixed Peak Renter", "mixed_peak_renter@test.com", False)
    equip = create_equipment(owner["id"], "Mixed Peak Tool", "desc",
                              100.0, 200.0, "Good", "2036-01-01", "2036-12-31")
    # 2036-08-13 to 2036-08-16: 4 days total
    # 2036-08-13, 2036-08-14 → base rate: 2 × $100 = $200
    # 2036-08-15, 2036-08-16 → peak rate: 2 × $100 × 2.0 = $400
    # Total: $600
    rental = create_rental(equip["id"], renter["id"], "2036-08-13", "2036-08-16")
    r = api("post", f"/api/rentals/{rental['id']}/approve")
    assert r.status_code == 200
    cost = r.json()["computedCost"]
    assert abs(cost - 600.0) < 0.01, f"Expected 600.0 for mixed peak/base days, got {cost}"


# ============================================================
# Deposit Management
# ============================================================


def test_deposit_status_null_before_approve():
    """Before approval, getRental shows depositStatus as null."""
    owner = create_member("Dep Null Owner", "dep_null_owner@test.com", False)
    renter = create_member("Dep Null Renter", "dep_null_renter@test.com", False)
    equip = create_equipment(owner["id"], "Dep Null Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-03-01", "2030-03-02")
    r = api("get", f"/api/rentals/{rental['id']}")
    assert r.status_code == 200
    body = r.json()
    assert body.get("depositStatus") is None


def test_deposit_status_held_after_approve():
    """After approval, deposit status is HELD."""
    approved_rental, *_ = setup_approved_rental()
    r = api("get", f"/api/rentals/{approved_rental['id']}")
    assert r.status_code == 200
    body = r.json()
    assert body["depositStatus"] == "HELD"


def test_deposit_status_released_on_complete():
    """Completing a rental releases the deposit."""
    owner = create_member("Dep Rel Owner", "dep_rel_owner@test.com", False)
    renter = create_member("Dep Rel Renter", "dep_rel_renter@test.com", False)
    equip = create_equipment(owner["id"], "Dep Rel Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-04-01", "2030-04-02")
    api("post", f"/api/rentals/{rental['id']}/approve")
    api("post", f"/api/rentals/{rental['id']}/complete")
    r = api("get", f"/api/rentals/{rental['id']}/deposit")
    assert r.status_code == 200
    assert r.json()["status"] == "RELEASED"


def test_get_deposit_hold():
    """GET /api/rentals/{id}/deposit returns deposit hold details."""
    approved_rental, _, _, equip = setup_approved_rental()
    r = api("get", f"/api/rentals/{approved_rental['id']}/deposit")
    assert r.status_code == 200
    body = r.json()
    assert "rentalId" in body
    assert "amount" in body
    assert "status" in body
    assert body["rentalId"] == approved_rental["id"]
    assert body["amount"] == equip["depositAmount"]
    assert body["status"] == "HELD"


def test_get_deposit_hold_not_found():
    """GET /api/rentals/{id}/deposit with non-existent rental ID returns 404."""
    r = api("get", "/api/rentals/999999/deposit")
    assert r.status_code == 404


def test_get_deposit_hold_no_hold_exists():
    """GET /api/rentals/{id}/deposit returns 404 when rental exists but has no deposit hold."""
    owner = create_member("No Hold Owner", "no_hold_owner@test.com", False)
    renter = create_member("No Hold Renter", "no_hold_renter@test.com", False)
    equip = create_equipment(owner["id"], "No Hold Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-08-01", "2030-08-02")
    # Rental is PENDING — no deposit hold has been created
    r = api("get", f"/api/rentals/{rental['id']}/deposit")
    assert r.status_code == 404


# ============================================================
# Handover Checklist
# ============================================================


def test_handover_checklist_content_type_html():
    """Handover checklist response has text/html content type."""
    approved_rental, *_ = setup_approved_rental()
    r = api("get", f"/api/rentals/{approved_rental['id']}/checklist")
    assert r.status_code == 200
    assert "text/html" in r.headers.get("Content-Type", "")


def test_handover_checklist_contains_required_elements():
    """Handover checklist HTML contains equipment name, owner name, renter name, dates, cost, deposit, and signature blocks."""
    approved_rental, owner, renter, equip = setup_approved_rental()
    r = api("get", f"/api/rentals/{approved_rental['id']}/checklist")
    assert r.status_code == 200
    html = r.text.lower()
    # Must contain owner name, renter name, equipment name
    assert owner["name"].lower() in html, "Owner name missing from checklist"
    assert renter["name"].lower() in html, "Renter name missing from checklist"
    assert equip["name"].lower() in html, "Equipment name missing from checklist"
    assert equip["condition"].lower() in html, "Equipment condition missing from checklist"
    # Computed rental cost and deposit amount must appear in the HTML
    # Check integer portion as substring — valid for any reasonable numeric formatting
    cost_str = str(int(approved_rental["computedCost"]))
    deposit_str = str(int(equip["depositAmount"]))
    assert cost_str in r.text, f"Computed rental cost ({cost_str}) missing from checklist"
    assert deposit_str in r.text, f"Deposit amount ({deposit_str}) missing from checklist"
    assert "equipment owner signature" in html, "Equipment Owner Signature block missing from checklist"
    assert "renter signature" in html, "Renter Signature block missing from checklist"


def test_handover_checklist_not_approved_returns_error():
    """GET /api/rentals/{id}/checklist for non-APPROVED rental returns 400."""
    owner = create_member("Chk Owner", "chk_owner@test.com", False)
    renter = create_member("Chk Renter", "chk_renter@test.com", False)
    equip = create_equipment(owner["id"], "Chk Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-05-01", "2030-05-02")
    # Rental is PENDING - checklist should fail
    r = api("get", f"/api/rentals/{rental['id']}/checklist")
    assert r.status_code == 400


def test_handover_checklist_not_found():
    """GET /api/rentals/{id}/checklist with non-existent rental returns 404."""
    r = api("get", "/api/rentals/999999/checklist")
    assert r.status_code == 404


# ============================================================
# Damage Disputes and Arbitration
# ============================================================

def test_open_dispute():
    """POST /api/disputes creates a dispute for an APPROVED rental and returns 201."""
    approved_rental, *_ = setup_approved_rental()
    r = api("post", "/api/disputes", json={
        "rentalId": approved_rental["id"],
        "description": "Equipment returned damaged"
    })
    assert r.status_code == 201
    body = r.json()
    assert "id" in body
    assert body["rentalId"] == approved_rental["id"]
    assert body["description"] == "Equipment returned damaged"


def test_open_dispute_initial_status_open():
    """New dispute starts with OPEN status and null outcome."""
    approved_rental, *_ = setup_approved_rental()
    r = api("post", "/api/disputes", json={
        "rentalId": approved_rental["id"],
        "description": "Damage claim"
    })
    assert r.status_code == 201
    body = r.json()
    assert body["status"] == "OPEN"
    assert body["outcome"] is None
    assert body["votes"] == []


def test_open_dispute_duplicate_returns_error():
    """Opening a second dispute for the same rental returns 400."""
    approved_rental, *_ = setup_approved_rental()
    api("post", "/api/disputes", json={"rentalId": approved_rental["id"], "description": "First"})
    r = api("post", "/api/disputes", json={"rentalId": approved_rental["id"], "description": "Second"})
    assert r.status_code == 400


def test_open_dispute_invalid_rental_status():
    """Opening a dispute for a PENDING rental returns 400."""
    owner = create_member("Disp Inv Owner", "disp_inv_owner@test.com", False)
    renter = create_member("Disp Inv Renter", "disp_inv_renter@test.com", False)
    equip = create_equipment(owner["id"], "Disp Inv Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-06-01", "2030-06-02")
    r = api("post", "/api/disputes", json={"rentalId": rental["id"], "description": "Pending dispute"})
    assert r.status_code == 400


def test_open_dispute_on_completed_rental():
    """POST /api/disputes can open a dispute against a COMPLETED rental."""
    owner = create_member("Comp Disp Owner", "comp_disp_owner@test.com", False)
    renter = create_member("Comp Disp Renter", "comp_disp_renter@test.com", False)
    equip = create_equipment(owner["id"], "Comp Disp Tool", "desc",
                              10.0, 20.0, "Good", "2030-01-01", "2030-12-31")
    rental = create_rental(equip["id"], renter["id"], "2030-09-01", "2030-09-02")
    api("post", f"/api/rentals/{rental['id']}/approve")
    api("post", f"/api/rentals/{rental['id']}/complete")
    r = api("post", "/api/disputes", json={
        "rentalId": rental["id"],
        "description": "Damage found after return"
    })
    assert r.status_code == 201
    body = r.json()
    assert body["status"] == "OPEN"
    assert body["rentalId"] == rental["id"]


def test_submit_vote():
    """POST /api/disputes/{id}/vote from a committee member returns full dispute schema."""
    dispute, voter1, voter2, _ = setup_committee_with_voters()
    r = api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "OWNER_FAVORED"
    })
    assert r.status_code == 200
    body = r.json()
    assert "id" in body
    assert "rentalId" in body
    assert "description" in body
    assert "status" in body
    assert "outcome" in body
    assert "votes" in body
    assert any(v["voterId"] == voter1["id"] for v in body["votes"])


def test_submit_vote_not_committee_member():
    """Vote from a non-committee member returns 400 with NOT_COMMITTEE_MEMBER code."""
    dispute, voter1, voter2, _ = setup_committee_with_voters()
    outsider = create_member("Outsider", "outsider_vote@test.com", False)
    r = api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": outsider["id"], "decision": "RENTER_FAVORED"
    })
    assert r.status_code == 400
    body = r.json()
    assert "code" in body
    assert body["code"] == "NOT_COMMITTEE_MEMBER"


def test_submit_vote_duplicate_vote():
    """Submitting a second vote from the same member returns 400 with DUPLICATE_VOTE code."""
    dispute, voter1, voter2, _ = setup_committee_with_voters()
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "RENTER_FAVORED"
    })
    r = api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "OWNER_FAVORED"
    })
    assert r.status_code == 400
    body = r.json()
    assert "code" in body
    assert body["code"] == "DUPLICATE_VOTE"


def test_submit_vote_resolved_dispute():
    """Voting on an already-resolved dispute returns 400 with DISPUTE_ALREADY_RESOLVED code."""
    dispute, voter1, voter2, _ = setup_committee_with_voters()
    # Both voters vote to resolve
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "OWNER_FAVORED"
    })
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter2["id"], "decision": "OWNER_FAVORED"
    })
    # Dispute should be resolved; adding another vote should fail
    outsider = create_member("Outsider2", "outsider2_vote@test.com", False)
    api("post", "/api/config/committee", json={"memberIds": [voter1["id"], voter2["id"], outsider["id"]]})
    r = api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": outsider["id"], "decision": "RENTER_FAVORED"
    })
    assert r.status_code == 400
    body = r.json()
    assert "code" in body
    assert body["code"] == "DISPUTE_ALREADY_RESOLVED"


def test_get_dispute():
    """GET /api/disputes/{id} returns the full dispute record with votes."""
    dispute, voter1, voter2, _ = setup_committee_with_voters()
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "RENTER_FAVORED"
    })
    r = api("get", f"/api/disputes/{dispute['id']}")
    assert r.status_code == 200
    body = r.json()
    assert body["id"] == dispute["id"]
    assert "rentalId" in body
    assert "description" in body
    assert "status" in body
    assert "outcome" in body
    assert "votes" in body
    assert isinstance(body["votes"], list)
    assert len(body["votes"]) >= 1
    vote = body["votes"][0]
    assert vote["voterId"] == voter1["id"]
    assert vote["decision"] == "RENTER_FAVORED"


def test_get_dispute_not_found():
    """GET /api/disputes/{id} with non-existent ID returns 404."""
    r = api("get", "/api/disputes/999999")
    assert r.status_code == 404


def test_dispute_resolution_owner_favored():
    """When majority votes OWNER_FAVORED, dispute resolves as OWNER_FAVORED."""
    dispute, voter1, voter2, _ = setup_committee_with_voters()
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "OWNER_FAVORED"
    })
    r = api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter2["id"], "decision": "OWNER_FAVORED"
    })
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "RESOLVED"
    assert body["outcome"] == "OWNER_FAVORED"


def test_dispute_resolution_renter_favored():
    """When majority votes RENTER_FAVORED, dispute resolves as RENTER_FAVORED."""
    dispute, voter1, voter2, _ = setup_committee_with_voters()
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "RENTER_FAVORED"
    })
    r = api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter2["id"], "decision": "RENTER_FAVORED"
    })
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "RESOLVED"
    assert body["outcome"] == "RENTER_FAVORED"


def test_dispute_tie_renter_favored():
    """A tie in votes resolves as RENTER_FAVORED and releases the deposit."""
    dispute, voter1, voter2, rental = setup_committee_with_voters()
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "OWNER_FAVORED"
    })
    r = api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter2["id"], "decision": "RENTER_FAVORED"
    })
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "RESOLVED"
    assert body["outcome"] == "RENTER_FAVORED"
    # Tie resolves as RENTER_FAVORED, which must release the deposit
    dep = api("get", f"/api/rentals/{rental['id']}/deposit")
    assert dep.status_code == 200
    assert dep.json()["status"] == "RELEASED", (
        "Tie outcome must transition deposit to RELEASED (same as RENTER_FAVORED)"
    )


def test_deposit_forfeited_on_owner_favored():
    """OWNER_FAVORED dispute outcome transitions deposit to FORFEITED."""
    dispute, voter1, voter2, rental = setup_committee_with_voters()
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "OWNER_FAVORED"
    })
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter2["id"], "decision": "OWNER_FAVORED"
    })
    r = api("get", f"/api/rentals/{rental['id']}/deposit")
    assert r.status_code == 200
    assert r.json()["status"] == "FORFEITED"


def test_deposit_released_on_renter_favored():
    """RENTER_FAVORED dispute outcome transitions deposit to RELEASED."""
    dispute, voter1, voter2, rental = setup_committee_with_voters()
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter1["id"], "decision": "RENTER_FAVORED"
    })
    api("post", f"/api/disputes/{dispute['id']}/vote", json={
        "voterId": voter2["id"], "decision": "RENTER_FAVORED"
    })
    r = api("get", f"/api/rentals/{rental['id']}/deposit")
    assert r.status_code == 200
    assert r.json()["status"] == "RELEASED"


# ============================================================
# System Configuration
# ============================================================

def test_add_peak_season_period():
    """POST /api/config/peak-season adds a peak season period and returns 201."""
    r = api("post", "/api/config/peak-season", json={
        "startDate": "2033-12-01", "endDate": "2033-12-31", "multiplier": 1.5
    })
    assert r.status_code == 201
    body = r.json()
    assert "id" in body
    assert body["startDate"] == "2033-12-01"
    assert body["endDate"] == "2033-12-31"
    assert body["multiplier"] == 1.5


def test_list_peak_season_periods():
    """GET /api/config/peak-season returns array of all peak season periods."""
    api("post", "/api/config/peak-season", json={
        "startDate": "2034-01-01", "endDate": "2034-01-31", "multiplier": 2.0
    })
    r = api("get", "/api/config/peak-season")
    assert r.status_code == 200
    periods = r.json()
    assert isinstance(periods, list)
    assert len(periods) >= 1
    for p in periods:
        assert "id" in p
        assert "startDate" in p
        assert "endDate" in p
        assert "multiplier" in p


def test_multiple_peak_season_periods_coexist():
    """Multiple peak season periods can be active simultaneously."""
    before_count = len(api("get", "/api/config/peak-season").json())
    api("post", "/api/config/peak-season", json={
        "startDate": "2035-03-01", "endDate": "2035-03-31", "multiplier": 1.2
    })
    api("post", "/api/config/peak-season", json={
        "startDate": "2035-04-01", "endDate": "2035-04-30", "multiplier": 1.8
    })
    r = api("get", "/api/config/peak-season")
    assert r.status_code == 200
    after_count = len(r.json())
    assert after_count >= before_count + 2, "Both new periods should coexist"


def test_set_arbitration_committee():
    """POST /api/config/committee replaces the committee and returns 200."""
    m1 = create_member("Committee M1", "comm_m1@test.com", False)
    m2 = create_member("Committee M2", "comm_m2@test.com", False)
    m3 = create_member("Committee M3", "comm_m3@test.com", False)
    r = api("post", "/api/config/committee", json={"memberIds": [m1["id"], m2["id"], m3["id"]]})
    assert r.status_code == 200
    body = r.json()
    assert "memberIds" in body
    assert set(body["memberIds"]) == {m1["id"], m2["id"], m3["id"]}


def test_set_arbitration_committee_invalid_member():
    """POST /api/config/committee with non-existent member ID returns 400."""
    r = api("post", "/api/config/committee", json={"memberIds": [999999]})
    assert r.status_code == 400


def test_get_arbitration_committee():
    """GET /api/config/committee returns exactly the currently configured committee."""
    m1 = create_member("Get Comm M1", "get_comm_m1@test.com", False)
    m2 = create_member("Get Comm M2", "get_comm_m2@test.com", False)
    api("post", "/api/config/committee", json={"memberIds": [m1["id"], m2["id"]]})
    r = api("get", "/api/config/committee")
    assert r.status_code == 200
    body = r.json()
    assert "memberIds" in body
    assert isinstance(body["memberIds"], list)
    assert set(body["memberIds"]) == {m1["id"], m2["id"]}, (
        f"Expected exactly committee members {{{m1['id']}, {m2['id']}}}, "
        f"got {body['memberIds']}"
    )


def test_set_member_discount():
    """POST /api/config/member-discount sets and returns the discount percentage."""
    r = api("post", "/api/config/member-discount", json={"discountPercentage": 15.0})
    assert r.status_code == 200
    body = r.json()
    assert "discountPercentage" in body
    assert body["discountPercentage"] == 15.0


def test_get_member_discount():
    """GET /api/config/member-discount returns the current discount percentage."""
    api("post", "/api/config/member-discount", json={"discountPercentage": 20.0})
    r = api("get", "/api/config/member-discount")
    assert r.status_code == 200
    body = r.json()
    assert "discountPercentage" in body
    assert body["discountPercentage"] == 20.0


# ============================================================
# Reports
# ============================================================

def test_member_earnings_report():
    """Member earnings report returns correct totalEarnings, per-equipment breakdown, and omits equipment with no COMPLETED rentals."""
    api("post", "/api/config/member-discount", json={"discountPercentage": 0.0})
    uid = uuid.uuid4().hex[:8]
    owner = create_member(f"Earnings Owner {uid}", f"earnings_owner_{uid}@test.com", False)
    renter = create_member(f"Earnings Renter {uid}", f"earnings_renter_{uid}@test.com", False)
    # Equipment 1: has a completed rental
    equip1 = create_equipment(owner["id"], f"Earnings Tool A {uid}", "desc",
                               100.0, 200.0, "Good", "2038-01-01", "2038-12-31")
    # Equipment 2: owned by same member, no rentals at all
    equip2 = create_equipment(owner["id"], f"Earnings Tool B {uid}", "desc",
                               80.0, 150.0, "Good", "2038-01-01", "2038-12-31")
    # Rental on equip1: 2038-06-01 to 2038-06-03 inclusive = 3 days → $300
    rental = create_rental(equip1["id"], renter["id"], "2038-06-01", "2038-06-03")
    api("post", f"/api/rentals/{rental['id']}/approve")
    api("post", f"/api/rentals/{rental['id']}/complete")

    r = api("get", f"/api/reports/members/{owner['id']}/earnings")
    assert r.status_code == 200
    body = r.json()
    assert body["memberId"] == owner["id"]
    assert "totalEarnings" in body
    assert "earningsByEquipment" in body
    assert isinstance(body["earningsByEquipment"], list)
    # Exactly one entry — equip1 only; equip2 has no COMPLETED rentals and must be omitted
    assert len(body["earningsByEquipment"]) == 1, (
        f"Expected 1 entry in earningsByEquipment (equip2 must be omitted), "
        f"got {len(body['earningsByEquipment'])}"
    )
    assert abs(body["totalEarnings"] - 300.0) < 0.01, (
        f"Expected totalEarnings=300.0 (3 days × $100), got {body['totalEarnings']}"
    )
    entry = body["earningsByEquipment"][0]
    assert entry["equipmentId"] == equip1["id"], (
        f"Expected equipmentId={equip1['id']} (equip with COMPLETED rental), got {entry['equipmentId']}"
    )
    assert "equipmentName" in entry
    assert abs(entry["totalEarnings"] - 300.0) < 0.01, (
        f"Expected per-equipment earnings=300.0, got {entry['totalEarnings']}"
    )
    # Explicitly verify equip2 is not in the breakdown
    breakdown_ids = [e["equipmentId"] for e in body["earningsByEquipment"]]
    assert equip2["id"] not in breakdown_ids, (
        f"equip2 (no COMPLETED rentals) must be omitted from earningsByEquipment but was included"
    )


def test_member_earnings_report_not_found():
    """GET /api/reports/members/{memberId}/earnings with non-existent ID returns 404."""
    r = api("get", "/api/reports/members/999999/earnings")
    assert r.status_code == 404


def test_disputed_transactions_report():
    """GET /api/reports/disputes returns list of disputed rentals with required fields."""
    r = api("get", "/api/reports/disputes")
    assert r.status_code == 200
    body = r.json()
    assert isinstance(body, list)
    assert len(body) >= 1, "Expected at least 1 dispute from sample data"
    for entry in body:
        assert "rentalId" in entry
        assert "equipmentName" in entry
        assert "ownerName" in entry
        assert "renterName" in entry
        assert "rentalCost" in entry
        assert "disputeStatus" in entry
        assert "disputeOutcome" in entry
        # Unresolved disputes must return null outcome, not a placeholder
        if entry["disputeStatus"] == "OPEN":
            assert entry["disputeOutcome"] is None, (
                f"Expected null disputeOutcome for OPEN dispute on rental "
                f"{entry['rentalId']}, got {entry['disputeOutcome']!r}"
            )


def test_equipment_utilization_report():
    """Equipment utilization computes totalAvailableDays, totalRentedDays, and utilizationPercentage correctly."""
    api("post", "/api/config/member-discount", json={"discountPercentage": 0.0})
    uid = uuid.uuid4().hex[:8]
    owner = create_member(f"Util Owner {uid}", f"util_owner_{uid}@test.com", False)
    renter = create_member(f"Util Renter {uid}", f"util_renter_{uid}@test.com", False)
    # Availability window: 2038-05-01 to 2038-05-10 inclusive = 10 days
    equip = create_equipment(owner["id"], f"Util Tool {uid}", "desc",
                              50.0, 100.0, "Good", "2038-05-01", "2038-05-10")
    # Rental: 2038-05-02 to 2038-05-04 inclusive = 3 days
    rental = create_rental(equip["id"], renter["id"], "2038-05-02", "2038-05-04")
    api("post", f"/api/rentals/{rental['id']}/approve")
    api("post", f"/api/rentals/{rental['id']}/complete")

    r = api("get", f"/api/reports/equipment/{equip['id']}/utilization")
    assert r.status_code == 200
    body = r.json()
    assert body["equipmentId"] == equip["id"]
    assert "equipmentName" in body
    # totalAvailableDays: May 1–10 inclusive = 10
    assert body["totalAvailableDays"] == 10, (
        f"Expected totalAvailableDays=10 (May 1–10 inclusive), got {body['totalAvailableDays']}"
    )
    # totalRentedDays: May 2–4 inclusive = 3
    assert body["totalRentedDays"] == 3, (
        f"Expected totalRentedDays=3 (May 2–4 inclusive), got {body['totalRentedDays']}"
    )
    # utilizationPercentage: 3/10 × 100 = 30.00
    assert abs(body["utilizationPercentage"] - 30.00) < 0.01, (
        f"Expected utilizationPercentage=30.00, got {body['utilizationPercentage']}"
    )


def test_equipment_utilization_report_not_found():
    """GET /api/reports/equipment/{equipmentId}/utilization with non-existent ID returns 404."""
    r = api("get", "/api/reports/equipment/999999/utilization")
    assert r.status_code == 404


# ============================================================
# Test runner
# ============================================================

def run_test(test_name, test_func):
    try:
        test_func()
        print(f"  PASSED {test_name}")
        return True
    except AssertionError:
        print(f"  FAILED {test_name}")
        return False
    except Exception:
        print(f"  FAILED {test_name}")
        return False


def main():
    print("Running RentalYard API tests...")
    print()
    passed = 0
    failed = 0
    for test_name in TEST_NAMES:
        test_func = globals().get(test_name)
        if test_func is None:
            print(f"  FAILED {test_name} (not found)")
            failed += 1
            continue
        if run_test(test_name, test_func):
            passed += 1
        else:
            failed += 1
    print()
    print(f"Results: {passed} passed, {failed} failed out of {len(TEST_NAMES)} tests")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
