import pytest
import sys
import os
import pandas as pd

PROJECT_ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, PROJECT_ROOT)

try:
    from pipeline import (
        load_receipts,
        fit_sell_through_curves,
        predict_clearance_time,
        recommend_markdown_schedule,
        run_pipeline,
    )
except Exception:
    load_receipts = None
    fit_sell_through_curves = None
    predict_clearance_time = None
    recommend_markdown_schedule = None
    run_pipeline = None


@pytest.fixture(scope="session")
def project_root():
    return PROJECT_ROOT


@pytest.fixture(scope="session")
def receipts_path():
    return os.path.join(PROJECT_ROOT, "data", "receipts.csv")


@pytest.fixture(scope="session")
def fn_load():
    return load_receipts


@pytest.fixture(scope="session")
def fn_fit():
    return fit_sell_through_curves


@pytest.fixture(scope="session")
def fn_predict():
    return predict_clearance_time


@pytest.fixture(scope="session")
def fn_markdown():
    return recommend_markdown_schedule


@pytest.fixture(scope="session")
def fn_pipeline():
    return run_pipeline


@pytest.fixture(scope="session")
def loaded_receipts(fn_load, receipts_path):
    if fn_load is None:
        return None
    try:
        result = fn_load(receipts_path)
    except Exception:
        return None
    if not isinstance(result, pd.DataFrame):
        return None
    return result


@pytest.fixture(scope="session")
def fitted_curves(fn_fit, loaded_receipts):
    if fn_fit is None or loaded_receipts is None:
        return None
    try:
        result = fn_fit(loaded_receipts)
    except Exception:
        return None
    if not isinstance(result, (tuple, list)) or len(result) < 2:
        return None
    return result


@pytest.fixture(scope="session")
def curve_params(fitted_curves):
    if fitted_curves is None:
        return None
    cp = fitted_curves[0]
    if not isinstance(cp, pd.DataFrame):
        return None
    return cp


@pytest.fixture(scope="session")
def seasonal_multipliers(fitted_curves):
    if fitted_curves is None:
        return None
    sm = fitted_curves[1]
    if not isinstance(sm, pd.DataFrame):
        return None
    return sm


@pytest.fixture(scope="session")
def clearance_predictions(fn_predict, loaded_receipts, curve_params, seasonal_multipliers):
    if fn_predict is None or loaded_receipts is None or curve_params is None or seasonal_multipliers is None:
        return None
    try:
        result = fn_predict(loaded_receipts, curve_params, seasonal_multipliers)
    except Exception:
        return None
    if not isinstance(result, pd.DataFrame):
        return None
    return result


@pytest.fixture(scope="session")
def markdown_schedule(fn_markdown, loaded_receipts, curve_params, seasonal_multipliers):
    if fn_markdown is None or loaded_receipts is None or curve_params is None or seasonal_multipliers is None:
        return None
    stores = loaded_receipts["store"].unique()
    shelf_cap = {s: 1000 for s in stores}
    try:
        result = fn_markdown(loaded_receipts, curve_params, seasonal_multipliers, 0.05, shelf_cap)
    except Exception:
        return None
    if not isinstance(result, pd.DataFrame):
        return None
    return result


@pytest.fixture(scope="session")
def pipeline_result(fn_pipeline, receipts_path, loaded_receipts):
    if fn_pipeline is None or loaded_receipts is None:
        return None
    stores = loaded_receipts["store"].unique()
    shelf_cap = {s: 1000 for s in stores}
    try:
        return fn_pipeline(receipts_path, 0.05, shelf_cap)
    except Exception:
        return None
