import sys
import pytest

sys.path.insert(0, '/app')

try:
    from stamp import stamp as _stamp_group
except ImportError:
    _stamp_group = None


@pytest.fixture(scope="session")
def stamp_cli():
    return _stamp_group


@pytest.fixture
def workdir(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    return tmp_path