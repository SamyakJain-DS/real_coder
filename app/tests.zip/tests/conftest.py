import json
import os
import shutil
import signal
import socket
import subprocess
import time
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import pytest


def _find_project_root():
    """Locate the Maven project root containing pom.xml.

    Checks the parent of the tests/ directory first, then /app (the standard
    Docker codebase location used during validation script execution).  Falls
    back to the parent of tests/ when no pom.xml is found so that the fixture
    can detect an empty repository and yield None gracefully.
    """
    candidates = [
        Path(__file__).resolve().parents[1],
        Path("/app"),
    ]
    for candidate in candidates:
        if (candidate / "pom.xml").exists():
            return candidate
    return Path(__file__).resolve().parents[1]


PROJECT_ROOT = _find_project_root()


def _free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


@pytest.fixture(scope="session")
def api_base_url():
    """Start the Spring Boot application and yield its base URL.

    Yields None (never raises) when prerequisites are absent or the server
    fails to start.  Individual tests assert on the yielded value so that
    failures appear as FAILED rather than ERROR.

    If the evaluation harness pre-started the server and exported
    SPRING_BASE_URL, that URL is used directly and no new process is launched.
    """
    external_url = os.environ.get("SPRING_BASE_URL")
    if external_url:
        yield external_url
        return

    if not shutil.which("mvn") or not (PROJECT_ROOT / "pom.xml").exists():
        yield None
        return

    port = _free_port()
    command = [
        "mvn",
        "-q",
        "spring-boot:run",
        f"-Dspring-boot.run.arguments=--server.port={port}",
    ]
    env = os.environ.copy()
    env.setdefault("MAVEN_OPTS", "-Djava.awt.headless=true")

    process = subprocess.Popen(
        command,
        cwd=PROJECT_ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
        start_new_session=True,
    )

    base_url = f"http://127.0.0.1:{port}"
    started = False
    deadline = time.time() + 90

    try:
        while time.time() < deadline:
            if process.poll() is not None:
                break  # process exited before becoming ready
            try:
                urlopen(f"{base_url}/api/commissions/-1", timeout=1)
                started = True
                break
            except HTTPError:
                started = True
                break
            except URLError:
                time.sleep(0.5)
            except Exception:
                time.sleep(0.5)

        yield base_url if started else None
    finally:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()


def request_json(base_url, method, path, payload=None):
    """Make an HTTP request and return (status_code, parsed_body).

    Asserts that base_url is not None so that tests depending on an
    unavailable server produce FAILED rather than ERROR.
    """
    assert base_url is not None, (
        "Spring Boot application did not start. "
        "Ensure a valid pom.xml and application source exist."
    )
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    request = Request(
        f"{base_url}{path}",
        data=body,
        method=method,
        headers={"Content-Type": "application/json", "Accept": "application/json"},
    )
    try:
        with urlopen(request, timeout=10) as response:
            content = response.read().decode("utf-8")
            return response.status, json.loads(content) if content else None
    except HTTPError as exc:
        content = exc.read().decode("utf-8")
        try:
            parsed = json.loads(content) if content else None
        except json.JSONDecodeError:
            parsed = {"raw": content}
        return exc.code, parsed
    except URLError as exc:
        pytest.fail(f"Cannot connect to Spring Boot application at {base_url}: {exc}")


def money(value):
    return Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def inlay_points():
    materials = ("holly", "ebony")
    colors = ("ivory", "black")
    return [
        {
            "pointNumber": number,
            "color": colors[number % 2],
            "material": materials[number % 2],
        }
        for number in range(1, 25)
    ]


def valid_commission(**overrides):
    payload = {
        "customerName": f"Collector {time.time_ns()}",
        "accountType": "collector",
        "agreedQuote": 2400.75,
        "depositPaid": 600.25,
        "plannedSetCount": 2,
        "caseMaterial": "walnut",
        "inlayPoints": inlay_points(),
    }
    payload.update(overrides)
    return payload


def create_commission(base_url, **overrides):
    status, body = request_json(
        base_url, "POST", "/api/commissions", valid_commission(**overrides)
    )
    assert status == 201, f"Expected 201 creating commission, got {status}: {body}"
    assert isinstance(body, dict)
    assert "id" in body
    return body
