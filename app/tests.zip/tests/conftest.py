import os
import sys
import pytest
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Must be set before the app module is imported so the app uses an in-memory test DB.
os.environ["DATABASE_URL"] = "sqlite://"


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_makereport(item, call):
    """Convert setup-phase failures into call-phase failures so tests show as FAILED not ERROR."""
    if call.when == "setup" and call.excinfo is not None:
        call.when = "call"


try:
    from flute_shop.main import app
    _IMPORT_ERROR = None
except Exception as e:
    _IMPORT_ERROR = str(e)
    from fastapi import FastAPI
    from fastapi.responses import JSONResponse
    app = FastAPI()

    @app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    async def _stub(path: str):
        return JSONResponse({"detail": "not implemented"}, status_code=500)


@pytest.fixture
def client():
    """
    Provide a TestClient that enters the app lifespan context per test function.
    Each test gets a fresh in-memory database (tables created on startup,
    dropped on shutdown via the app's lifespan handler).
    """
    with TestClient(app, raise_server_exceptions=False) as c:
        yield c


@pytest.fixture
def sample_commission_payload():
    return {
        "customer_name": "Seamus O'Brien",
        "instrument_type": "flute",
        "material": "African Blackwood",
        "pitch_reference": "A=440Hz",
        "target_key": "D",
        "bore_taper": "conical-gentle",
        "quoted_total": 1200.00,
        "deposit_amount": 300.00,
    }


@pytest.fixture
def created_commission(client, sample_commission_payload):
    resp = client.post("/commissions", json=sample_commission_payload)
    assert resp.status_code == 201, f"Setup failed: POST /commissions returned {resp.status_code}"
    data = resp.json()
    assert "id" in data, "Setup failed: commission response missing 'id'"
    return data


@pytest.fixture
def sample_inventory_payload():
    return {
        "material_name": "African Blackwood",
        "material_type": "wood",
        "unit_of_measure": "board_foot",
        "quantity_on_hand": 50.0,
        "reorder_threshold": 5.0,
    }


@pytest.fixture
def created_inventory_item(client, sample_inventory_payload):
    resp = client.post("/inventory", json=sample_inventory_payload)
    assert resp.status_code == 201, f"Setup failed: POST /inventory returned {resp.status_code}"
    data = resp.json()
    assert "id" in data, "Setup failed: inventory response missing 'id'"
    return data


@pytest.fixture
def created_build_session(client, created_commission):
    payload = {
        "session_date": "2026-05-01",
        "notes": "Initial rough turning",
    }
    resp = client.post(
        f"/commissions/{created_commission['id']}/build-sessions",
        json=payload,
    )
    assert resp.status_code == 201, f"Setup failed: POST build-sessions returned {resp.status_code}"
    data = resp.json()
    assert "id" in data, "Setup failed: build session response missing 'id'"
    return data
