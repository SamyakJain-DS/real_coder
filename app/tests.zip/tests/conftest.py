import sys
import types
from pathlib import Path

_HERE = Path(__file__).resolve().parent          # dir holding helpers.py + tests
_ROOT = _HERE.parent                             # repo root (holds nacha/ in-repo)

# Make both the repo root and this directory importable so `import nacha` and
# `from tests.helpers import ...` resolve regardless of pytest's CWD.
for _p in (str(_ROOT), str(_HERE)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# Ensure `import tests` / `from tests.helpers import ...` works even when the
# test files are unpacked flat (no real `tests/` package directory present).
if "tests" not in sys.modules:
    try:
        import tests  # noqa: F401  (real package on the in-repo layout)
    except ImportError:
        _pkg = types.ModuleType("tests")
        _pkg.__path__ = [str(_HERE)]
        sys.modules["tests"] = _pkg

# Detect whether the implementation package is available. When it is not, every
# test must still be COLLECTED (so the F2P baseline lists them as FAILED, not
# as a collection ERROR) - register lightweight stub modules so the top-level
# `from nacha import ...` statements in the test files succeed.
_import_error = None
try:
    import nacha  # noqa: F401
except ImportError as exc:
    _import_error = str(exc)

    class _StubAttr:
        """Callable / subscriptable placeholder for any imported name."""

        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            return self

        def __getattr__(self, _name):
            return _StubAttr()

    class _StubModule(types.ModuleType):
        def __getattr__(self, _name):
            return _StubAttr

    for _name in ("nacha", "nacha.model", "nacha.rules"):
        if _name not in sys.modules:
            sys.modules[_name] = _StubModule(_name)


def pytest_runtest_call(item):
    """Runs during the CALL phase of every test. When `nacha` cannot be
    imported, fail each test individually (FAILED, not ERROR) so the
    fail-to-pass baseline JSON is correct."""
    if _import_error:
        import pytest
        pytest.fail(f"nacha package not available: {_import_error}")
