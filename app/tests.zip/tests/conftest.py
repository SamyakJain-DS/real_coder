import uuid
import pytest

try:
    from src.main import application
    _src_available = True
except (ImportError, ModuleNotFoundError):
    application = None
    _src_available = False


class _StubResponse:
    """Dummy response returned when src module is not available."""
    status_code = -1

    def json(self):
        return {}


class _StubClient:
    """Dummy test client that always returns a stub response, ensuring tests FAIL (not ERROR)."""
    def get(self, *a, **kw):
        return _StubResponse()

    def post(self, *a, **kw):
        return _StubResponse()

    def put(self, *a, **kw):
        return _StubResponse()

    def patch(self, *a, **kw):
        return _StubResponse()

    def delete(self, *a, **kw):
        return _StubResponse()


@pytest.fixture()
def client():
    if not _src_available:
        yield _StubClient()
        return
    from fastapi.testclient import TestClient
    with TestClient(application) as c:
        yield c


def unique_naic_code():
    """Return a unique 5-digit numeric string for use as a NAIC code."""
    return f"{uuid.uuid4().int % 90000 + 10000:05d}"


def unique_serff():
    """Return a globally unique SERFF tracking number."""
    return f"SERFF-{uuid.uuid4().hex[:12].upper()}"


def create_insurer(client, **overrides):
    payload = {
        "naic_code": unique_naic_code(),
        "company_name": f"Health Insurer {uuid.uuid4().hex[:6]}",
        "company_type": "insurer",
        "state_license_status": "active",
        "domicile_state": "CA",
        "admitted_date": "2020-01-15",
    }
    payload.update(overrides)
    return client.post("/api/insurers", json=payload)


def create_filing(client, insurer_id, **overrides):
    payload = {
        "insurer_id": insurer_id,
        "serff_tracking_number": overrides.pop("serff_tracking_number", unique_serff()),
        "filing_type": "initial",
        "product_type": "individual",
        "effective_date": "2025-01-01",
        "submission_date": "2024-06-01",
        "requested_rate_change_pct": 5.5,
        "attachments": [
            {
                "attachment_type": "actuarial_memorandum",
                "filename": "memo.pdf",
                "uploaded_date": "2024-06-01",
            },
            {
                "attachment_type": "experience_exhibit",
                "filename": "exhibit.pdf",
                "uploaded_date": "2024-06-01",
            },
        ],
    }
    payload.update(overrides)
    return client.post("/api/filings", json=payload)
