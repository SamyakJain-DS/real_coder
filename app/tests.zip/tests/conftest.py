import os
import sys
import pytest
import pandas as pd
import numpy as np
import tempfile
import shutil
import types

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def pytest_configure(config):
    # Turn unexpected warnings into errors, but suppress known sklearn/numpy
    # operational warnings that arise with small synthetic datasets.
    config.addinivalue_line("filterwarnings", "error")
    config.addinivalue_line("filterwarnings", "ignore::sklearn.exceptions.ConvergenceWarning")
    config.addinivalue_line("filterwarnings", "ignore::sklearn.exceptions.UndefinedMetricWarning")
    config.addinivalue_line("filterwarnings", "ignore::FutureWarning:sklearn")
    config.addinivalue_line("filterwarnings", "ignore::RuntimeWarning:numpy")
    config.addinivalue_line("filterwarnings", "ignore::UserWarning:sklearn")


try:
    import pipeline as _pipeline_mod
except ImportError:
    _stub = types.ModuleType("pipeline")
    _stub.__file__ = "pipeline.py"

    def _not_implemented(*args, **kwargs):
        pytest.fail("pipeline module is not implemented")

    for _name in [
        "load_and_validate",
        "engineer_features",
        "train_models",
        "analyze_moratorium_violations",
        "generate_director_report",
        "generate_inspector_report",
    ]:
        setattr(_stub, _name, _not_implemented)

    sys.modules["pipeline"] = _stub


@pytest.fixture
def sample_data_dir(tmp_path):
    """Create a temporary directory with valid sample CSV data files for testing."""
    data_dir = tmp_path / "data"
    data_dir.mkdir()

    permits_df = pd.DataFrame({
        "permit_id": [f"P{i:03d}" for i in range(1, 51)],
        "permittee_id": [f"PT{(i % 10) + 1:03d}" for i in range(50)],
        "street_segment_id": [f"S{(i % 15) + 1:03d}" for i in range(50)],
        "issue_date": pd.date_range("2017-01-15", periods=50, freq="60D").strftime("%Y-%m-%d").tolist(),
        "excavation_purpose": (["utility_install", "emergency", "maintenance", "upgrade", "repair"] * 10),
        "restoration_scope": (["full", "partial", "temporary"] * 17)[:50],
        "traffic_control_plan_adequate": ([True, True, True, False, True] * 10),
        "warranty_start": pd.date_range("2017-01-10", periods=50, freq="60D").strftime("%Y-%m-%d").tolist(),
        "warranty_end": pd.date_range("2019-01-10", periods=50, freq="60D").strftime("%Y-%m-%d").tolist(),
    })
    permits_df.to_csv(data_dir / "permits.csv", index=False)

    inspections_rows = []
    insp_id = 1
    for i in range(1, 51):
        num_inspections = 1 + (i % 3)
        for j in range(num_inspections):
            inspections_rows.append({
                "inspection_id": f"I{insp_id:04d}",
                "permit_id": f"P{i:03d}",
                "inspection_date": (pd.Timestamp("2017-01-20") + pd.Timedelta(days=60 * (i - 1) + 10 * j)).strftime("%Y-%m-%d"),
                "backfill_accepted": bool((i + j) % 3 != 0),
                "base_course_accepted": bool((i + j) % 4 != 0),
                "surface_restoration_accepted": bool((i + j) % 5 != 0),
            })
            insp_id += 1
    pd.DataFrame(inspections_rows).to_csv(data_dir / "inspections.csv", index=False)

    permittees_df = pd.DataFrame({
        "permittee_id": [f"PT{i:03d}" for i in range(1, 11)],
        "name": [f"Company_{i}" for i in range(1, 11)],
        "type": (["utility", "telecom", "contractor"] * 4)[:10],
    })
    permittees_df.to_csv(data_dir / "permittees.csv", index=False)

    segments_data = {
        "segment_id": [f"S{i:03d}" for i in range(1, 16)],
        "corridor_name": [f"Corridor_{chr(65 + (i % 5))}" for i in range(15)],
        "pavement_install_date": pd.date_range("2010-01-01", periods=15, freq="120D").strftime("%Y-%m-%d").tolist(),
        "overlay_date": [None] * 5 + pd.date_range("2019-06-01", periods=10, freq="90D").strftime("%Y-%m-%d").tolist(),
        "moratorium_start": [None] * 8 + pd.date_range("2017-06-01", periods=7, freq="180D").strftime("%Y-%m-%d").tolist(),
        "moratorium_end": [None] * 8 + pd.date_range("2020-06-01", periods=7, freq="180D").strftime("%Y-%m-%d").tolist(),
    }
    pd.DataFrame(segments_data).to_csv(data_dir / "street_segments.csv", index=False)

    failures = []
    fail_id = 1
    for pid in ["P005", "P010", "P015", "P020", "P025", "P030", "P035", "P040"]:
        permit_idx = int(pid[1:]) - 1
        issue = pd.Timestamp("2017-01-15") + pd.Timedelta(days=60 * permit_idx)
        failures.append({
            "failure_id": f"F{fail_id:03d}",
            "permit_id": pid,
            "failure_date": (issue + pd.Timedelta(days=200)).strftime("%Y-%m-%d"),
            "severity": ["minor", "moderate", "severe"][fail_id % 3],
        })
        fail_id += 1
    pd.DataFrame(failures).to_csv(data_dir / "settlement_failures.csv", index=False)

    fee_rows = []
    fee_id = 1
    for i in range(1, 51):
        fee_rows.append({
            "assessment_id": f"FE{fee_id:04d}",
            "permittee_id": f"PT{((i - 1) % 10) + 1:03d}",
            "permit_id": f"P{i:03d}",
            "amount": 100.0 + (i * 13.5),
            "date": (pd.Timestamp("2017-02-01") + pd.Timedelta(days=60 * (i - 1))).strftime("%Y-%m-%d"),
        })
        fee_id += 1
    pd.DataFrame(fee_rows).to_csv(data_dir / "fee_assessments.csv", index=False)

    bond_rows = []
    bond_id = 1
    for ptid in ["PT001", "PT003", "PT005", "PT007"]:
        for j in range(2):
            bond_rows.append({
                "claim_id": f"B{bond_id:03d}",
                "permittee_id": ptid,
                "permit_id": f"P{bond_id:03d}",
                "claim_amount": 500.0 + bond_id * 100,
                "claim_date": (pd.Timestamp("2018-01-01") + pd.Timedelta(days=90 * j)).strftime("%Y-%m-%d"),
                "resolved": bool(j % 2 == 0),
            })
            bond_id += 1
    pd.DataFrame(bond_rows).to_csv(data_dir / "bond_claims.csv", index=False)

    coord_rows = []
    coord_id = 1
    for i in range(1, 21):
        coord_rows.append({
            "notice_id": f"CN{coord_id:04d}",
            "permittee_id": f"PT{((i - 1) % 10) + 1:03d}",
            "permit_id": f"P{i:03d}",
            "notice_date": (pd.Timestamp("2017-01-01") + pd.Timedelta(days=60 * (i - 1))).strftime("%Y-%m-%d"),
            "project_start_date": (pd.Timestamp("2017-01-15") + pd.Timedelta(days=60 * (i - 1))).strftime("%Y-%m-%d"),
        })
        coord_id += 1
    pd.DataFrame(coord_rows).to_csv(data_dir / "coordination_notices.csv", index=False)

    return str(data_dir)


@pytest.fixture
def output_dir(tmp_path):
    """Create a temporary output directory for reports."""
    out = tmp_path / "reports"
    out.mkdir()
    return str(out)