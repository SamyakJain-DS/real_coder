from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path
from typing import Callable

import pytest


_REAL_CODER_ROOT = os.environ.get("REAL_CODER_ROOT")
_DEFAULT_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(_REAL_CODER_ROOT).resolve() if _REAL_CODER_ROOT else _DEFAULT_ROOT


@pytest.fixture(scope="session")
def project_root() -> Path:
    return PROJECT_ROOT


@pytest.fixture(scope="session", autouse=True)
def _ensure_project_root_on_path_and_cwd(project_root: Path) -> None:
    if project_root.is_dir():
        os.chdir(project_root)
    sys.path.insert(0, str(project_root))


@pytest.fixture()
def import_or_fail(project_root: Path) -> Callable[[str], object]:
    def _import(module_name: str) -> object:
        try:
            mod = importlib.import_module(module_name)
        except Exception as e:  # pragma: no cover - want FAILED, not ERROR.
            pytest.fail(f"Could not import {module_name}: {e}")

        mod_file = getattr(mod, "__file__", None)
        if not mod_file:  # pragma: no cover
            pytest.fail(f"Imported {module_name} without a __file__; expected project code.")

        mod_path = Path(mod_file).resolve()
        try:
            mod_path.relative_to(project_root)
        except ValueError:  # pragma: no cover
            pytest.fail(f"Imported {module_name} from outside project root: {mod_file}")

        return mod

    return _import

