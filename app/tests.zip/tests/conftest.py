from __future__ import annotations

import importlib
import textwrap
from pathlib import Path

import pytest
import yaml


def import_public(module_name: str, attr_name: str | None = None):
    try:
        module = importlib.import_module(module_name)
    except Exception as exc:
        pytest.fail(f"Could not import {module_name}: {exc}")
    if attr_name is None:
        return module
    try:
        return getattr(module, attr_name)
    except AttributeError:
        pytest.fail(f"{module_name} does not expose {attr_name}")


VALID_CONFIG_DICT = {
    "rules": [
        {
            "id": "frontend-a11y",
            "name": "Frontend Accessibility",
            "trigger": {
                "extensions": [".tsx", ".jsx", ".css"],
                "paths": ["frontend/"],
                "patterns": [],
            },
            "checklist": [
                {"key": "a11y-aria", "text": "Verify ARIA attributes on interactive elements"},
                {"key": "a11y-contrast", "text": "Check color contrast ratios"},
            ],
        },
        {
            "id": "migration-safety",
            "name": "Schema Migration Safety",
            "trigger": {
                "extensions": [],
                "paths": ["migrations/"],
                "patterns": ["**/migrate_*.py"],
            },
            "checklist": [
                {"key": "mig-rollback", "text": "Include rollback instructions"},
                {"key": "mig-backup", "text": "Document backup procedure"},
            ],
        },
        {
            "id": "api-changelog",
            "name": "Public API Changelog",
            "trigger": {
                "extensions": [],
                "paths": [],
                "patterns": ["**/api/**"],
            },
            "checklist": [
                {"key": "api-entry", "text": "Add changelog entry for API changes"},
            ],
        },
    ]
}


@pytest.fixture()
def config_path(tmp_path: Path) -> Path:
    p = tmp_path / "checklist.yaml"
    p.write_text(yaml.dump(VALID_CONFIG_DICT, default_flow_style=False))
    return p


@pytest.fixture()
def sample_diff_text() -> str:
    return textwrap.dedent("""\
        diff --git a/frontend/Button.tsx b/frontend/Button.tsx
        new file mode 100644
        index 0000000..abc1234
        --- /dev/null
        +++ b/frontend/Button.tsx
        @@ -0,0 +1,5 @@
        +export const Button = () => {
        +  return <button>Click</button>;
        +};

        diff --git a/migrations/0002_add_column.py b/migrations/0002_add_column.py
        index def5678..ghi9012 100644
        --- a/migrations/0002_add_column.py
        +++ b/migrations/0002_add_column.py
        @@ -1,3 +1,5 @@
         def upgrade():
        -    pass
        +    op.add_column("users", sa.Column("email", sa.String))

        diff --git a/backend/api/routes.py b/backend/api/routes.py
        index 1111111..2222222 100644
        --- a/backend/api/routes.py
        +++ b/backend/api/routes.py
        @@ -10,3 +10,6 @@
         def get_users():
             return []
        +
        +def get_user(user_id):
        +    return {}

        diff --git a/README.md b/README.md
        deleted file mode 100644
        index 3333333..0000000
        --- a/README.md
        +++ /dev/null
        @@ -1,3 +0,0 @@
        -# Project
        -
        -Description here
    """)
