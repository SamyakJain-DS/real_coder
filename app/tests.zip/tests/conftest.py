"""Pytest configuration: ensure tax_administration module is importable.

The implementation file is expected at tax_administration.py. We add
candidate locations (project root and the app/ directory) to sys.path
so the tests work whether the developer places the module at the repository
root or under app/.
"""

from __future__ import annotations

import os
import sys


_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_APP_DIR = os.path.dirname(_THIS_DIR)
_PROJECT_ROOT = os.path.dirname(_APP_DIR)

for _candidate in (_PROJECT_ROOT, _APP_DIR):
    if _candidate and _candidate not in sys.path:
        sys.path.insert(0, _candidate)
