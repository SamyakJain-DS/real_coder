import pytest


@pytest.hookimpl(tryfirst=True)
def pytest_report_teststatus(report, config):
    """Convert fixture/setup ERRORs to FAILED.

    pytest's default implementation returns ("error","E","ERROR") whenever
    a test's setup or teardown phase fails, regardless of report.outcome.
    By returning ("failed","F","FAILED") first (tryfirst), we ensure the
    verbose output shows FAILED - not ERROR - for every fixture failure.
    """
    if report.when in ("setup", "teardown") and report.failed:
        return "failed", "F", "FAILED"