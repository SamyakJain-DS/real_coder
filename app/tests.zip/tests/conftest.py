"""Shared fixtures and bootstrap for the donor pipeline test suite.

The tests interact with ``DonorPipeline`` strictly through the public
surface documented in the prompt:

* the constructor and its three configuration arguments,
* the ``fit`` and ``rank_donors`` methods,
* the ``probability_model`` and ``amount_model`` attributes that the
  prompt explicitly names.

Nothing in this conftest assumes a particular feature-matrix attribute
name or any other internal implementation detail, so any conformant
solution should be exercised the same way.

F2P integrity note
------------------
Every fixture here is written so that an empty repository produces
FAILED (not ERROR) test outcomes.  The rule is: fixtures must never
raise exceptions themselves; instead they return sentinel values whose
*use inside the test body* triggers a natural assertion failure.

* ``DonorPipeline`` returns ``_NotImplementedPipeline`` when the module
  is absent.  Any test that calls ``DonorPipeline()`` will hit the
  ``AssertionError`` raised in ``__init__`` - inside the test body,
  so pytest records it as FAILED.
* ``fitted_pipeline``, ``ranked``, and ``fitted_deterministic`` return
  ``None`` on failure.  Tests that access attributes on ``None`` raise
  ``AttributeError`` inside the test body - again FAILED.
* ``repo_root`` returns ``None`` when the file is absent.  Tests that
  try ``None / "requirements.txt"`` get ``TypeError`` - FAILED.
"""

from __future__ import annotations

import sys
import warnings
from pathlib import Path
from typing import Callable, Iterable, Mapping

import pandas as pd
import pytest

warnings.filterwarnings("ignore")


def _candidate_roots() -> list[Path]:
    """Locations that may contain the candidate solution and manifest."""

    here = Path(__file__).resolve()
    return [
        Path("/app"),
        Path("/eval_assets"),
        here.parent.parent,
        here.parent.parent.parent,
        here.parent.parent.parent.parent,
    ]


def _ensure_importable() -> None:
    """Place the repository root on ``sys.path`` so ``src.donor_pipeline``
    is importable across local checkouts and the Docker validation layout.
    """

    for root in _candidate_roots():
        if (root / "src").is_dir() and str(root) not in sys.path:
            sys.path.insert(0, str(root))


_ensure_importable()


class _NotImplementedPipeline:
    """Sentinel returned by the ``DonorPipeline`` fixture when
    ``src.donor_pipeline`` cannot be imported.

    Raises ``AssertionError`` in ``__init__`` so any test that
    instantiates it fails inside the *test body* (FAILED, not ERROR).
    """

    def __init__(self, *args, **kwargs):
        raise AssertionError(
            "DonorPipeline could not be imported from src.donor_pipeline. "
            "The module or class is missing from the repository."
        )


REQUIRED_COLUMNS = ("donor_id", "donation_amount", "date", "campaign", "channel")

EXPECTED_FEATURE_COLUMNS = (
    "recency_days",
    "frequency",
    "monetary_total",
    "monetary_mean",
    "tenure_days",
)


def _coerce(rows: Iterable[Mapping]) -> pd.DataFrame:
    """Build a donations DataFrame with the dtypes mandated by the prompt."""

    df = pd.DataFrame(list(rows))
    df["donor_id"] = df["donor_id"].astype("object")
    df["donation_amount"] = df["donation_amount"].astype("float64")
    df["date"] = pd.to_datetime(df["date"])
    df["campaign"] = df["campaign"].astype("object")
    df["channel"] = df["channel"].astype("object")
    return df


def _locate_feature_matrix(pipeline) -> pd.DataFrame:
    """Locate the persisted feature matrix on a fitted pipeline.

    The prompt mandates that ``fit`` persists the engineered feature
    matrix on the instance but does not name the attribute. The locator
    inspects every ``DataFrame`` attribute on the pipeline and returns
    the one whose columns are dominated by the documented feature
    names. Tests that depend on the persisted feature matrix call this
    helper instead of guessing an attribute name.
    """

    candidates: list[tuple[int, str, pd.DataFrame]] = []
    for name, value in vars(pipeline).items():
        if not isinstance(value, pd.DataFrame):
            continue
        cols = set(value.columns)
        overlap = set(EXPECTED_FEATURE_COLUMNS) & cols
        if len(overlap) >= 3:
            candidates.append((len(overlap), name, value))

    assert candidates, (
        "Could not locate a persisted feature matrix on the fitted pipeline. "
        "Expected a DataFrame attribute that exposes at least 3 of "
        f"{EXPECTED_FEATURE_COLUMNS}. Visible attributes: "
        f"{sorted(vars(pipeline).keys())}"
    )
    candidates.sort(key=lambda triple: triple[0], reverse=True)
    return candidates[0][2]


def _feature_donor_ids(fm: pd.DataFrame) -> list:
    """Return the donor identifiers carried by the feature matrix in row order."""

    if "donor_id" in fm.columns:
        return fm["donor_id"].tolist()
    return fm.index.tolist()


def _feature_only(fm: pd.DataFrame) -> pd.DataFrame:
    """Return the feature columns of the matrix, dropping ``donor_id`` if present."""

    if "donor_id" in fm.columns:
        return fm.drop(columns=["donor_id"])
    return fm


@pytest.fixture
def DonorPipeline():
    """Return the candidate ``DonorPipeline`` class.

    Returns ``_NotImplementedPipeline`` when the module is absent so
    that tests which call ``DonorPipeline()`` fail *inside the test
    body* (FAILED) rather than during fixture setup (ERROR).
    """

    try:
        from src.donor_pipeline import DonorPipeline as _DonorPipeline
        return _DonorPipeline
    except (ImportError, ModuleNotFoundError):
        return _NotImplementedPipeline


@pytest.fixture
def repo_root() -> Path:
    """Locate the repository root that hosts ``requirements.txt``.

    Returns ``None`` when not found so that the test body receives the
    ``TypeError`` (FAILED) instead of fixture-setup ERROR.
    """

    for root in _candidate_roots():
        if (root / "requirements.txt").is_file():
            return root
    return None  # test will fail naturally when it tries None / "requirements.txt"


@pytest.fixture
def make_donations() -> Callable[[Iterable[Mapping]], pd.DataFrame]:
    """Factory that materialises a typed donations DataFrame from rows."""

    return _coerce


@pytest.fixture
def sample_donations(make_donations) -> pd.DataFrame:
    """Balanced donation history that exercises both target classes.

    Five "future" donors (target=1) have at least one donation inside the
    30-day window after the default ``as_of_date``, while five "no-future"
    donors (target=0) only contribute historical donations. Multiple
    channels and campaigns appear so the channel-mix features have
    meaningful variation. Every amount is well above the 0.01 floor and
    every value is deterministic so reproducibility tests are stable.
    """

    max_date = pd.Timestamp("2024-12-31")
    rows: list[dict] = []

    future_donors = ["F001", "F002", "F003", "F004", "F005"]
    history_offsets = [400, 320, 240, 160, 95]
    for idx, donor in enumerate(future_donors):
        base_amount = 60.0 + idx * 8.0
        for off_idx, off in enumerate(history_offsets):
            rows.append(
                {
                    "donor_id": donor,
                    "donation_amount": base_amount + off_idx * 5.0,
                    "date": max_date - pd.Timedelta(days=off),
                    "campaign": "spring" if off > 250 else "fall",
                    "channel": ["email", "mail", "phone"][idx % 3],
                }
            )
        rows.append(
            {
                "donor_id": donor,
                "donation_amount": 110.0 + idx * 7.0,
                "date": max_date,
                "campaign": "winter",
                "channel": "email",
            }
        )

    no_future_donors = ["N001", "N002", "N003", "N004", "N005"]
    no_future_offsets = [350, 270, 195, 135, 85]
    for idx, donor in enumerate(no_future_donors):
        base_amount = 35.0 + idx * 4.0
        for off_idx, off in enumerate(no_future_offsets):
            rows.append(
                {
                    "donor_id": donor,
                    "donation_amount": base_amount + off_idx * 3.0,
                    "date": max_date - pd.Timedelta(days=off),
                    "campaign": "spring" if off > 250 else "fall",
                    "channel": ["mail", "phone", "email"][idx % 3],
                }
            )

    return _coerce(rows)


@pytest.fixture
def fitted_pipeline(DonorPipeline, sample_donations):
    """Pipeline already fitted on ``sample_donations`` with defaults.

    Returns ``None`` on any exception so that tests fail inside the
    test body (FAILED) rather than during fixture setup (ERROR).
    """

    try:
        return DonorPipeline().fit(sample_donations)
    except Exception:
        return None


@pytest.fixture
def ranked(fitted_pipeline, sample_donations) -> pd.DataFrame:
    """Default ranking output produced by the fitted pipeline.

    Returns ``None`` on any exception (FAILED in test body, not ERROR).
    """

    try:
        return fitted_pipeline.rank_donors(sample_donations)
    except Exception:
        return None


@pytest.fixture
def deterministic_donations(make_donations) -> pd.DataFrame:
    """Hand-crafted donations DataFrame with known feature values.

    With ``max(date) == 2024-12-01`` the default ``as_of_date`` resolves
    to ``2024-11-01``. Donors A and D each have a donation inside the
    ``(as_of_date, as_of_date + 30 days]`` window (probability target =
    1); donors B and E do not (target = 0). Donor C's first donation
    falls after ``as_of_date`` so it must be excluded from the feature
    matrix. The channel mix spans email/mail/phone, exercising every
    ``channel_share_*`` column. All values are deterministic and
    hand-checkable so feature-engineering and target-semantics tests can
    assert exact numeric expectations.
    """

    rows = [
        {"donor_id": "A", "donation_amount": 100.0, "date": "2024-01-01", "campaign": "c1", "channel": "email"},
        {"donor_id": "A", "donation_amount": 200.0, "date": "2024-06-01", "campaign": "c1", "channel": "mail"},
        {"donor_id": "A", "donation_amount": 300.0, "date": "2024-10-01", "campaign": "c1", "channel": "email"},
        {"donor_id": "A", "donation_amount": 50.0,  "date": "2024-11-15", "campaign": "c1", "channel": "email"},
        {"donor_id": "B", "donation_amount": 100.0, "date": "2024-08-01", "campaign": "c1", "channel": "phone"},
        {"donor_id": "B", "donation_amount": 200.0, "date": "2024-10-15", "campaign": "c1", "channel": "phone"},
        {"donor_id": "D", "donation_amount": 75.0,  "date": "2024-03-01", "campaign": "c2", "channel": "mail"},
        {"donor_id": "D", "donation_amount": 125.0, "date": "2024-09-01", "campaign": "c2", "channel": "mail"},
        {"donor_id": "D", "donation_amount": 60.0,  "date": "2024-12-01", "campaign": "c2", "channel": "email"},
        {"donor_id": "E", "donation_amount": 50.0,  "date": "2024-05-01", "campaign": "c1", "channel": "email"},
        {"donor_id": "E", "donation_amount": 100.0, "date": "2024-09-15", "campaign": "c1", "channel": "mail"},
        {"donor_id": "C", "donation_amount": 80.0,  "date": "2024-11-20", "campaign": "c1", "channel": "phone"},
    ]
    return _coerce(rows)


@pytest.fixture
def fitted_deterministic(DonorPipeline, deterministic_donations):
    """Pipeline already fitted on ``deterministic_donations`` with defaults.

    Returns ``None`` on any exception (FAILED in test body, not ERROR).
    """

    try:
        return DonorPipeline().fit(deterministic_donations)
    except Exception:
        return None


@pytest.fixture
def locate_feature_matrix():
    """Helper that finds the persisted feature matrix on a fitted pipeline."""

    return _locate_feature_matrix


@pytest.fixture
def feature_donor_ids():
    """Helper that returns the donor_ids carried by a feature matrix."""

    return _feature_donor_ids


@pytest.fixture
def feature_only():
    """Helper that strips ``donor_id`` from a feature matrix when present."""

    return _feature_only
