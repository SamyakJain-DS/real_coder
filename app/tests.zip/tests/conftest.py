"""Pytest configuration for Adventure Booking Platform tests."""
import requests
import subprocess
import time
import os
import signal


_server_process = None

# Detect Docker evaluation environment vs local run.
# In Docker, /eval_assets exists and the codebase lives at /app.
# Locally, the codebase is two directories above this conftest file.
_IN_DOCKER = os.path.isdir('/eval_assets')

if _IN_DOCKER:
    _APP_DIR = '/app'
    _SERVER_CMD = ['ts-node', 'src/server.ts']   # ts-node installed globally via Dockerfile
else:
    _APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _SERVER_CMD = ['npx', 'ts-node', 'src/server.ts']


def pytest_configure(config):
    """Attempt to start the server before tests run."""
    global _server_process

    # If something is already listening, skip launch
    try:
        resp = requests.get("http://localhost:3000/api/trips", timeout=1)
        if resp.status_code == 200:
            print("\nServer already running")
            return
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
        pass

    print(f"\nStarting server from {_APP_DIR} ...")

    try:
        _server_process = subprocess.Popen(
            _SERVER_CMD,
            cwd=_APP_DIR,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid,
        )
    except Exception as exc:
        # Binary/source missing (e.g. empty codebase) - do NOT raise.
        # Individual tests will fail via the _patch_requests fixture.
        print(f"Server process could not be started: {exc}")
        return

    # Wait up to 15 seconds for the server to become ready
    for _ in range(30):
        try:
            resp = requests.get("http://localhost:3000/api/trips", timeout=1)
            if resp.status_code == 200:
                print(f"Server ready (PID: {_server_process.pid})")
                return
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            time.sleep(0.5)

    # Did not become ready - do NOT # raise RuntimeError  # CD_TO_APP_MARKER: Allow tests to run and fail naturally.
    print("Server failed to start within 15 seconds")
    if _server_process:
        try:
            _server_process.kill()
        except Exception:
            pass
    _server_process = None


def pytest_unconfigure(config):
    """Stop the server after all tests complete."""
    global _server_process

    if _server_process and _server_process.poll() is None:
        print(f"\n🛑 Stopping server (PID: {_server_process.pid})")
        try:
            os.killpg(os.getpgid(_server_process.pid), signal.SIGTERM)
            _server_process.wait(timeout=5)
        except Exception:
            try:
                _server_process.kill()
            except Exception:
                pass
        print("Server stopped")