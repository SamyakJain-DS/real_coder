"""Tests for ``as_of_date`` resolution and the reference-date guard."""

import pandas as pd
import pytest


def test_default_and_explicit_as_of_date_yield_equivalent_ranking(
    DonorPipeline, sample_donations
):
    """When constructed with ``as_of_date=None`` the pipeline resolves
    the reference date to ``donations["date"].max() - Timedelta(days=30)``;
    supplying that exact ``Timestamp`` explicitly must produce the same
    ranking output."""

    expected_default = sample_donations["date"].max() - pd.Timedelta(days=30)

    p_default = DonorPipeline(as_of_date=None).fit(sample_donations)
    p_explicit = DonorPipeline(as_of_date=expected_default).fit(sample_donations)

    pd.testing.assert_frame_equal(
        p_default.rank_donors(sample_donations),
        p_explicit.rank_donors(sample_donations),
    )


def test_resolved_as_of_date_after_max_minus_30_raises(
    DonorPipeline, sample_donations
):
    """``fit`` raises ``ValueError`` when the resolved reference date is
    strictly greater than ``donations["date"].max() - Timedelta(days=30)``."""

    bad_date = sample_donations["date"].max() - pd.Timedelta(days=29)
    with pytest.raises(ValueError):
        DonorPipeline(as_of_date=bad_date).fit(sample_donations)


def test_as_of_date_at_boundary_max_minus_30_is_accepted(
    DonorPipeline, sample_donations
):
    """The ``as_of_date <= max - 30 days`` guard is non-strict at the
    boundary itself: an explicit Timestamp equal to ``max - 30 days``
    must be accepted by ``fit``."""

    boundary = sample_donations["date"].max() - pd.Timedelta(days=30)
    DonorPipeline(as_of_date=boundary).fit(sample_donations)


def test_as_of_date_one_nanosecond_past_boundary_is_rejected(
    DonorPipeline, sample_donations
):
    """The boundary check operates at full ``datetime64[ns]`` precision:
    even one nanosecond past ``max - 30 days`` must raise ``ValueError``,
    which guards against implementations that silently truncate to day
    granularity."""

    over = (
        sample_donations["date"].max()
        - pd.Timedelta(days=30)
        + pd.Timedelta(nanoseconds=1)
    )
    with pytest.raises(ValueError):
        DonorPipeline(as_of_date=over).fit(sample_donations)


def test_explicit_as_of_date_yields_distinct_ranking_from_default(
    DonorPipeline, deterministic_donations
):
    """An explicit Timestamp earlier than the default produces a
    different ranking than ``as_of_date=None``. This rules out
    implementations that silently override the explicit value with the
    ``max - 30 days`` default - the equivalence test alone cannot
    distinguish those because it passes the default value as the
    "explicit" one."""

    explicit = pd.Timestamp("2024-10-01")
    out_explicit = (
        DonorPipeline(as_of_date=explicit)
        .fit(deterministic_donations)
        .rank_donors(deterministic_donations)
    )
    out_default = (
        DonorPipeline(as_of_date=None)
        .fit(deterministic_donations)
        .rank_donors(deterministic_donations)
    )

    assert not out_explicit.equals(out_default)