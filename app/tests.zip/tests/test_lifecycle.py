"""Tests for the ``fit`` / ``rank_donors`` lifecycle behaviour."""

import pytest


def test_fit_returns_pipeline_instance_for_chaining(DonorPipeline, sample_donations):
    """``fit`` returns the same ``DonorPipeline`` instance to enable the
    chained ``DonorPipeline().fit(df)`` pattern."""

    pipeline = DonorPipeline()
    result = pipeline.fit(sample_donations)

    assert result is pipeline


def test_rank_donors_before_fit_raises_runtime_error(DonorPipeline, sample_donations):
    """Calling ``rank_donors`` before any successful ``fit`` raises a
    ``RuntimeError`` whose message is **exactly** the documented phrase
    — no prefix, no suffix, no punctuation — pinning the "exact
    message" wording in requirement 6."""

    pipeline = DonorPipeline()
    with pytest.raises(RuntimeError) as excinfo:
        pipeline.rank_donors(sample_donations)

    assert str(excinfo.value) == "pipeline must be fit before calling rank_donors"
