"""
Tests for Commission CRUD endpoints.
Covers: create_commission, get_commission, list_commissions,
        update_commission_status, add_bom_item, list_bom_items.
"""


class TestCreateCommission:
    def test_create_commission_response_shape(self, client, sample_commission_payload):
        resp = client.post("/commissions", json=sample_commission_payload)
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["status"] == "quoted"
        assert data["customer_name"] == sample_commission_payload["customer_name"]
        assert data["instrument_type"] == sample_commission_payload["instrument_type"]
        assert data["material"] == sample_commission_payload["material"]
        assert data["pitch_reference"] == sample_commission_payload["pitch_reference"]
        assert data["target_key"] == sample_commission_payload["target_key"]
        assert data["bore_taper"] == sample_commission_payload["bore_taper"]
        assert data["quoted_total"] == sample_commission_payload["quoted_total"]
        assert data["deposit_amount"] == sample_commission_payload["deposit_amount"]
        expected_balance = sample_commission_payload["quoted_total"] - sample_commission_payload["deposit_amount"]
        assert data["final_balance"] == expected_balance

    def test_create_commission_missing_required_fields_returns_422(self, client):
        resp = client.post("/commissions", json={})
        assert resp.status_code == 422
        assert resp.json().get("detail")

    def test_create_commission_invalid_instrument_type_returns_422(self, client, sample_commission_payload):
        payload = {**sample_commission_payload, "instrument_type": "guitar"}
        resp = client.post("/commissions", json=payload)
        assert resp.status_code == 422
        assert resp.json().get("detail")

    def test_create_whistle_commission(self, client):
        payload = {
            "customer_name": "Paddy Moloney",
            "instrument_type": "whistle",
            "material": "brass",
            "pitch_reference": "A=442Hz",
            "target_key": "C",
            "bore_taper": "straight",
            "quoted_total": 350.00,
            "deposit_amount": 100.00,
        }
        resp = client.post("/commissions", json=payload)
        assert resp.status_code == 201
        data = resp.json()
        assert data["instrument_type"] == "whistle"
        assert data["material"] == "brass"


class TestGetCommission:
    def test_get_existing_commission(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.get(f"/commissions/{cid}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["id"] == cid

    def test_get_commission_returns_all_fields(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.get(f"/commissions/{cid}")
        data = resp.json()
        for field in [
            "customer_name", "instrument_type", "material",
            "pitch_reference", "target_key", "bore_taper",
            "status", "quoted_total", "deposit_amount", "final_balance",
        ]:
            assert field in data

    def test_get_commission_has_empty_build_sessions_list(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.get(f"/commissions/{cid}")
        data = resp.json()
        assert "build_sessions" in data
        assert isinstance(data["build_sessions"], list)
        assert data["build_sessions"] == []

    def test_get_commission_build_sessions_exclude_craftsmanship_sub_records(
        self, client, created_commission, created_build_session
    ):
        """build_sessions entries must be summaries only — no nested craftsmanship arrays."""
        sid = created_build_session["id"]
        client.post(f"/build-sessions/{sid}/turning-passes", json={
            "pass_number": 1, "target_diameter_mm": 19.0,
            "achieved_diameter_mm": 19.1, "tool_used": "gouge",
        })
        client.post(f"/build-sessions/{sid}/undercuts", json={
            "hole_number": 1, "undercut_depth_mm": 0.5,
            "undercut_angle_degrees": 15.0, "is_thumb_hole": False,
        })
        client.post(f"/build-sessions/{sid}/lappings", json={
            "joint_identifier": "head-body", "thread_material": "linen",
            "num_wraps": 8, "fit_tightness": "snug",
        })
        client.post(f"/build-sessions/{sid}/tuning-sessions", json={
            "hole_number": 1, "target_frequency_hz": 587.33,
            "measured_frequency_hz": 586.0, "deviation_cents": -3.9,
        })
        resp = client.get(f"/commissions/{created_commission['id']}")
        data = resp.json()
        assert len(data["build_sessions"]) >= 1
        summary = data["build_sessions"][0]
        for field in ["id", "commission_id", "session_date", "notes"]:
            assert field in summary
        for key in ["turning_passes", "undercuts", "lappings", "tuning_sessions"]:
            assert key not in summary

    def test_get_nonexistent_commission_returns_404(self, client, created_commission):
        valid_resp = client.get(f"/commissions/{created_commission['id']}")
        assert valid_resp.status_code == 200, "Route must exist for valid IDs"
        resp = client.get("/commissions/99999")
        assert resp.status_code == 404
        assert resp.json().get("detail")


class TestListCommissions:
    def test_list_commissions_includes_created(self, client, created_commission):
        resp = client.get("/commissions")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list), "Expected list response"
        match = next((c for c in data if c["id"] == created_commission["id"]), None)
        assert match is not None, "Created commission not found in list"
        for field in [
            "id", "customer_name", "instrument_type", "material",
            "pitch_reference", "target_key", "bore_taper",
            "status", "quoted_total", "deposit_amount", "final_balance",
        ]:
            assert field in match, f"List item missing required field '{field}'"

    def test_list_commissions_no_nested_build_session_data(self, client, created_commission):
        resp = client.get("/commissions")
        data = resp.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        for c in data:
            assert "build_sessions" not in c

    def test_list_commissions_filter_by_status(self, client, created_commission):
        resp = client.get("/commissions", params={"status": "quoted"})
        data = resp.json()
        assert isinstance(data, list), "Expected list response"
        assert len(data) >= 1
        for c in data:
            assert c["status"] == "quoted"

    def test_list_commissions_filter_by_status_no_match(self, client, created_commission):
        resp = client.get("/commissions", params={"status": "delivered"})
        data = resp.json()
        assert isinstance(data, list), "Expected list response"
        assert len(data) == 0

    def test_list_commissions_filter_by_customer_name(self, client, created_commission):
        name = created_commission["customer_name"]
        resp = client.get("/commissions", params={"customer_name": name})
        data = resp.json()
        assert isinstance(data, list), "Expected list response"
        assert len(data) >= 1
        for c in data:
            assert c["customer_name"] == name

    def test_list_commissions_filter_by_customer_name_no_match(self, client, created_commission):
        resp = client.get("/commissions", params={"customer_name": "Nonexistent Person XYZ"})
        data = resp.json()
        assert isinstance(data, list), "Expected list response"
        assert len(data) == 0


class TestUpdateCommissionStatus:
    def test_update_status_returns_200(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.patch(
            f"/commissions/{cid}/status",
            json={"status": "deposit_paid"},
        )
        assert resp.status_code == 200

    def test_update_status_reflects_new_value(self, client, created_commission):
        cid = created_commission["id"]
        client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        resp = client.get(f"/commissions/{cid}")
        data = resp.json()
        assert data.get("status") == "deposit_paid"

    def test_update_status_response_has_build_sessions_field(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        assert resp.status_code == 200
        data = resp.json()
        assert "build_sessions" in data
        assert isinstance(data["build_sessions"], list)

    def test_update_status_response_contains_all_commission_fields(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        assert resp.status_code == 200
        data = resp.json()
        for field in [
            "id", "customer_name", "instrument_type", "material",
            "pitch_reference", "target_key", "bore_taper",
            "status", "quoted_total", "deposit_amount", "final_balance",
        ]:
            assert field in data, f"PATCH response missing field '{field}'"

    def test_update_status_nonexistent_returns_404(self, client, created_commission):
        valid_resp = client.patch(
            f"/commissions/{created_commission['id']}/status",
            json={"status": "deposit_paid"},
        )
        assert valid_resp.status_code == 200, "Route must exist for valid IDs"
        resp = client.patch(
            "/commissions/99999/status",
            json={"status": "deposit_paid"},
        )
        assert resp.status_code == 404
        assert resp.json().get("detail")

    def test_invalid_status_transitions_return_409(self, client, created_commission):
        """Same-status, skip-forward, backward, and unknown values must all return 409."""
        cid = created_commission["id"]
        # Same status: quoted -> quoted is not the immediate next step
        assert client.patch(f"/commissions/{cid}/status", json={"status": "quoted"}).status_code == 409
        # Unknown/arbitrary status string is not the immediate next step
        assert client.patch(f"/commissions/{cid}/status", json={"status": "abandoned"}).status_code == 409
        # Skip: quoted -> in_progress skips deposit_paid
        assert client.patch(f"/commissions/{cid}/status", json={"status": "in_progress"}).status_code == 409
        # Advance legitimately to deposit_paid, then try to reverse
        client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        assert client.patch(f"/commissions/{cid}/status", json={"status": "quoted"}).status_code == 409

    def test_full_forward_status_sequence_is_valid(
        self, client, sample_commission_payload, sample_inventory_payload
    ):
        """All six transitions in the forward-only sequence must return 200."""
        comm_resp = client.post("/commissions", json=sample_commission_payload)
        cid = comm_resp.json()["id"]

        inv_resp = client.post("/inventory", json=sample_inventory_payload)
        inv_id = inv_resp.json()["id"]
        client.post(
            f"/commissions/{cid}/bom-items",
            json={"inventory_item_id": inv_id, "quantity_required": 1.0},
        )

        for status in ["deposit_paid", "in_progress", "final_fitting", "completed", "delivered"]:
            resp = client.patch(f"/commissions/{cid}/status", json={"status": status})
            assert resp.status_code == 200, f"Expected 200 for transition to '{status}', got {resp.status_code}"
            assert resp.json()["status"] == status

    def test_transition_to_in_progress_deducts_stock_and_records_deduction(
        self, client, created_commission, created_inventory_item
    ):
        """The in_progress transition must update inventory quantity AND persist a StockDeduction row."""
        cid = created_commission["id"]
        inv_id = created_inventory_item["id"]
        original_qty = created_inventory_item["quantity_on_hand"]
        qty_required = 5.0

        client.post(
            f"/commissions/{cid}/bom-items",
            json={"inventory_item_id": inv_id, "quantity_required": qty_required},
        )
        client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        resp = client.patch(f"/commissions/{cid}/status", json={"status": "in_progress"})
        assert resp.status_code == 200

        # Verify inventory quantity decreased
        inv_data = client.get("/inventory").json()
        matching_inv = [i for i in inv_data if i.get("id") == inv_id]
        assert len(matching_inv) > 0, "Inventory item not found after deduction"
        assert matching_inv[0]["quantity_on_hand"] == original_qty - qty_required

        # Verify StockDeduction record was persisted
        deductions = client.get("/inventory/deductions", params={"commission_id": cid}).json()
        assert isinstance(deductions, list)
        assert len(deductions) >= 1
        deduction = next(d for d in deductions if d.get("inventory_item_id") == inv_id)
        assert deduction["quantity"] == qty_required
        assert deduction["commission_id"] == cid
        assert deduction["deducted_at"] is not None

    def test_in_progress_deduction_fires_exactly_once(
        self, client, sample_commission_payload, sample_inventory_payload
    ):
        """A rejected re-attempt at in_progress must not create additional deductions
        or further reduce inventory — the deduction fires exactly once per commission."""
        comm_resp = client.post("/commissions", json=sample_commission_payload)
        cid = comm_resp.json()["id"]
        inv_resp = client.post("/inventory", json=sample_inventory_payload)
        inv_id = inv_resp.json()["id"]
        qty_req = 5.0

        client.post(f"/commissions/{cid}/bom-items",
                    json={"inventory_item_id": inv_id, "quantity_required": qty_req})
        client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        client.patch(f"/commissions/{cid}/status", json={"status": "in_progress"})

        qty_after = next(
            i["quantity_on_hand"]
            for i in client.get("/inventory").json()
            if i["id"] == inv_id
        )
        deduction_count_after = len(
            client.get("/inventory/deductions", params={"commission_id": cid}).json()
        )

        # Attempt to re-trigger in_progress; must be rejected (same status = not immediate next)
        rejected = client.patch(f"/commissions/{cid}/status", json={"status": "in_progress"})
        assert rejected.status_code == 409

        # Inventory and deduction count must be unchanged after the rejected attempt
        qty_now = next(
            i["quantity_on_hand"]
            for i in client.get("/inventory").json()
            if i["id"] == inv_id
        )
        deduction_count_now = len(
            client.get("/inventory/deductions", params={"commission_id": cid}).json()
        )
        assert qty_now == qty_after
        assert deduction_count_now == deduction_count_after

    def test_transition_to_in_progress_insufficient_stock_returns_409(
        self, client, created_commission, created_inventory_item
    ):
        cid = created_commission["id"]
        inv_id = created_inventory_item["id"]

        client.post(
            f"/commissions/{cid}/bom-items",
            json={"inventory_item_id": inv_id, "quantity_required": 9999.0},
        )
        # Forward-only: must go through deposit_paid first
        client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        resp = client.patch(f"/commissions/{cid}/status", json={"status": "in_progress"})
        assert resp.status_code == 409

    def test_insufficient_stock_no_partial_deduction(
        self, client, sample_commission_payload, sample_inventory_payload
    ):
        inv1_resp = client.post("/inventory", json=sample_inventory_payload)
        inv1 = inv1_resp.json()

        inv2_payload = {
            "material_name": "Cork",
            "material_type": "wood",
            "unit_of_measure": "sheet_sq_in",
            "quantity_on_hand": 2.0,
            "reorder_threshold": 1.0,
        }
        inv2_resp = client.post("/inventory", json=inv2_payload)
        inv2 = inv2_resp.json()

        comm_resp = client.post("/commissions", json=sample_commission_payload)
        cid = comm_resp.json().get("id", 0)

        client.post(
            f"/commissions/{cid}/bom-items",
            json={"inventory_item_id": inv1["id"], "quantity_required": 3.0},
        )
        client.post(
            f"/commissions/{cid}/bom-items",
            json={"inventory_item_id": inv2["id"], "quantity_required": 9999.0},
        )

        # Forward-only: must go through deposit_paid first
        client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        resp = client.patch(f"/commissions/{cid}/status", json={"status": "in_progress"})
        assert resp.status_code == 409

        inv_list = client.get("/inventory").json()
        assert isinstance(inv_list, list), "Expected inventory list response"
        matching = [i for i in inv_list if i.get("id") == inv1["id"]]
        assert len(matching) > 0
        assert matching[0]["quantity_on_hand"] == inv1["quantity_on_hand"]

    def test_transition_to_in_progress_deducts_all_bom_items(
        self, client, sample_commission_payload, sample_inventory_payload
    ):
        """Every BOM item must be deducted and recorded when transitioning to in_progress."""
        inv1_resp = client.post("/inventory", json=sample_inventory_payload)
        inv1 = inv1_resp.json()
        inv1_orig_qty = inv1["quantity_on_hand"]

        inv2_resp = client.post("/inventory", json={
            "material_name": "Brass Rod",
            "material_type": "metal",
            "unit_of_measure": "rod_length_cm",
            "quantity_on_hand": 30.0,
            "reorder_threshold": 5.0,
        })
        inv2 = inv2_resp.json()
        inv2_orig_qty = inv2["quantity_on_hand"]

        comm_resp = client.post("/commissions", json=sample_commission_payload)
        cid = comm_resp.json()["id"]

        qty1, qty2 = 4.0, 10.0
        client.post(f"/commissions/{cid}/bom-items",
                    json={"inventory_item_id": inv1["id"], "quantity_required": qty1})
        client.post(f"/commissions/{cid}/bom-items",
                    json={"inventory_item_id": inv2["id"], "quantity_required": qty2})

        client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        resp = client.patch(f"/commissions/{cid}/status", json={"status": "in_progress"})
        assert resp.status_code == 200

        # Both inventory quantities must have decreased
        inv_list = client.get("/inventory").json()
        m1 = next(i for i in inv_list if i["id"] == inv1["id"])
        m2 = next(i for i in inv_list if i["id"] == inv2["id"])
        assert m1["quantity_on_hand"] == inv1_orig_qty - qty1
        assert m2["quantity_on_hand"] == inv2_orig_qty - qty2

        # One StockDeduction record per BOM item must be persisted
        deductions = client.get("/inventory/deductions", params={"commission_id": cid}).json()
        ids_deducted = {d["inventory_item_id"] for d in deductions}
        assert inv1["id"] in ids_deducted
        assert inv2["id"] in ids_deducted

    def test_update_status_response_build_sessions_are_summaries_only(
        self, client, created_commission, created_build_session
    ):
        """PATCH /commissions/{id}/status build_sessions entries must match get_commission shape."""
        sid = created_build_session["id"]
        client.post(f"/build-sessions/{sid}/turning-passes", json={
            "pass_number": 1, "target_diameter_mm": 19.0,
            "achieved_diameter_mm": 19.1, "tool_used": "gouge",
        })
        client.post(f"/build-sessions/{sid}/lappings", json={
            "joint_identifier": "head-body", "thread_material": "linen",
            "num_wraps": 8, "fit_tightness": "snug",
        })
        cid = created_commission["id"]
        resp = client.patch(f"/commissions/{cid}/status", json={"status": "deposit_paid"})
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["build_sessions"]) >= 1
        summary = data["build_sessions"][0]
        for field in ["id", "commission_id", "session_date", "notes"]:
            assert field in summary
        for key in ["turning_passes", "undercuts", "lappings", "tuning_sessions"]:
            assert key not in summary


class TestBomItems:
    def test_add_bom_item_response_fields(
        self, client, created_commission, created_inventory_item
    ):
        cid = created_commission["id"]
        inv_id = created_inventory_item["id"]
        resp = client.post(
            f"/commissions/{cid}/bom-items",
            json={"inventory_item_id": inv_id, "quantity_required": 3.0},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["commission_id"] == cid
        assert data["inventory_item_id"] == inv_id
        assert data["quantity_required"] == 3.0
        assert "id" in data

    def test_add_bom_item_nonexistent_commission_returns_404(
        self, client, created_inventory_item
    ):
        resp = client.post(
            "/commissions/99999/bom-items",
            json={"inventory_item_id": created_inventory_item["id"], "quantity_required": 1.0},
        )
        assert resp.status_code == 404
        assert resp.json().get("detail")

    def test_add_bom_item_nonexistent_inventory_item_returns_404(self, client, created_commission):
        resp = client.post(
            f"/commissions/{created_commission['id']}/bom-items",
            json={"inventory_item_id": 99999, "quantity_required": 1.0},
        )
        assert resp.status_code == 404
        assert resp.json().get("detail")

    def test_list_bom_items_returns_200(self, client, created_commission):
        cid = created_commission["id"]
        resp = client.get(f"/commissions/{cid}/bom-items")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_list_bom_items_contains_added_item(
        self, client, created_commission, created_inventory_item
    ):
        cid = created_commission["id"]
        inv_id = created_inventory_item["id"]
        client.post(
            f"/commissions/{cid}/bom-items",
            json={"inventory_item_id": inv_id, "quantity_required": 2.5},
        )
        resp = client.get(f"/commissions/{cid}/bom-items")
        data = resp.json()
        assert isinstance(data, list), "Expected list response"
        assert len(data) >= 1
        match = next((item for item in data if item["inventory_item_id"] == inv_id), None)
        assert match is not None, "Added BOM item not found in list"
        for field in ["id", "commission_id", "inventory_item_id", "quantity_required"]:
            assert field in match, f"BOM list item missing required field '{field}'"

    def test_list_bom_items_nonexistent_commission_returns_404(self, client, created_commission):
        valid_resp = client.get(f"/commissions/{created_commission['id']}/bom-items")
        assert valid_resp.status_code == 200, "Route must exist for valid IDs"
        resp = client.get("/commissions/99999/bom-items")
        assert resp.status_code == 404
        assert resp.json().get("detail")
