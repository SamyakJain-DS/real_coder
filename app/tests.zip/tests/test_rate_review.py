import uuid
import pytest
from conftest import create_insurer, create_filing


def perform_review(client, filing_id, **overrides):
    payload = {
        "projected_incurred_claims": 800000.0,
        "projected_quality_improvement_expenses": 20000.0,
        "projected_earned_premium": 1000000.0,
        "trend_factor": 1.0,
        "administrative_expense_ratio": 0.15,
    }
    payload.update(overrides)
    return client.post(f"/api/filings/{filing_id}/review", json=payload)


class TestRateAdequacyReview:
    def test_review_adequate_individual(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"], product_type="individual").json()
        resp = perform_review(
            client,
            filing["filing_id"],
            projected_incurred_claims=850000.0,
            projected_quality_improvement_expenses=10000.0,
            projected_earned_premium=1000000.0,
            trend_factor=1.0,
            administrative_expense_ratio=0.15,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["adequacy_result"] == "adequate"
        assert data["target_mlr"] == 0.80

    def test_review_inadequate_individual(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"], product_type="individual").json()
        resp = perform_review(
            client,
            filing["filing_id"],
            projected_incurred_claims=700000.0,
            projected_quality_improvement_expenses=10000.0,
            projected_earned_premium=1000000.0,
            trend_factor=1.0,
            administrative_expense_ratio=0.15,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["adequacy_result"] == "inadequate"

    def test_review_adequate_large_group(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(
            client, insurer["insurer_id"],
            product_type="large_group",
        ).json()
        resp = perform_review(
            client,
            filing["filing_id"],
            projected_incurred_claims=900000.0,
            projected_quality_improvement_expenses=10000.0,
            projected_earned_premium=1000000.0,
            trend_factor=1.0,
            administrative_expense_ratio=0.10,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["adequacy_result"] == "adequate"
        assert data["target_mlr"] == 0.85

    def test_review_inadequate_large_group(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(
            client, insurer["insurer_id"],
            product_type="large_group",
        ).json()
        resp = perform_review(
            client,
            filing["filing_id"],
            projected_incurred_claims=800000.0,
            projected_quality_improvement_expenses=10000.0,
            projected_earned_premium=1000000.0,
            trend_factor=1.0,
            administrative_expense_ratio=0.10,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["adequacy_result"] == "inadequate"

    def test_review_small_group_uses_080_threshold(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(
            client, insurer["insurer_id"],
            product_type="small_group",
        ).json()
        resp = perform_review(
            client,
            filing["filing_id"],
            projected_incurred_claims=810000.0,
            projected_quality_improvement_expenses=0.0,
            projected_earned_premium=1000000.0,
            trend_factor=1.0,
            administrative_expense_ratio=0.15,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["target_mlr"] == 0.80
        assert data["adequacy_result"] == "adequate"


    def test_review_mlr_exactly_equal_to_target_is_adequate(self, client):
        # Verifies the >= (not just >) boundary: projected_mlr == target_mlr must be "adequate".
        # MLR = (800000 * 1.0 + 0) / 1000000 = 0.8000, target for individual = 0.80.
        insurer = create_insurer(client).json()
        filing = create_filing(
            client, insurer["insurer_id"],
            product_type="individual",
        ).json()
        resp = perform_review(
            client,
            filing["filing_id"],
            projected_incurred_claims=800000.0,
            projected_quality_improvement_expenses=0.0,
            projected_earned_premium=1000000.0,
            trend_factor=1.0,
            administrative_expense_ratio=0.10,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["projected_mlr"] == 0.8
        assert data["adequacy_result"] == "adequate"

    def test_review_mlr_calculation_with_trend_factor(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        # MLR = (500000 * 1.5 + 50000) / 1000000 = 0.8
        resp = perform_review(
            client,
            filing["filing_id"],
            projected_incurred_claims=500000.0,
            projected_quality_improvement_expenses=50000.0,
            projected_earned_premium=1000000.0,
            trend_factor=1.5,
            administrative_expense_ratio=0.15,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["projected_mlr"] == 0.8
        assert data["trend_factor_used"] == 1.5

    def test_review_mlr_rounded_to_4_decimal_places(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        # MLR = (333333 * 1.0 + 1) / 1000000 = 0.333334 → rounds to 0.3333
        resp = perform_review(
            client,
            filing["filing_id"],
            projected_incurred_claims=333333.0,
            projected_quality_improvement_expenses=1.0,
            projected_earned_premium=1000000.0,
            trend_factor=1.0,
            administrative_expense_ratio=0.10,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["projected_mlr"] == 0.3333

    def test_review_admin_expense_flag_true(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = perform_review(
            client,
            filing["filing_id"],
            administrative_expense_ratio=0.25,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["admin_expense_flag"] is True
        assert data["admin_expense_ratio"] == 0.25

    def test_review_admin_expense_flag_false(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = perform_review(
            client,
            filing["filing_id"],
            administrative_expense_ratio=0.15,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["admin_expense_flag"] is False


    def test_review_admin_expense_flag_false_at_exact_boundary(self, client):
        # Verifies strict > semantics: exactly 0.20 must NOT set admin_expense_flag.
        # A buggy >= implementation would incorrectly flag this as True.
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = perform_review(
            client,
            filing["filing_id"],
            administrative_expense_ratio=0.20,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["admin_expense_flag"] is False
        assert data["admin_expense_ratio"] == 0.20

    def test_review_transitions_filing_to_under_review(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        assert filing["status"] == "received"
        perform_review(client, filing["filing_id"])
        updated = client.get(f"/api/filings/{filing['filing_id']}").json()
        assert updated["status"] == "under_review"

    def test_review_returns_all_required_fields(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        resp = perform_review(client, filing["filing_id"])
        data = resp.json()
        required_fields = [
            "review_id", "filing_id", "projected_mlr", "target_mlr",
            "trend_factor_used", "admin_expense_ratio", "admin_expense_flag",
            "adequacy_result", "review_date",
        ]
        for field in required_fields:
            assert field in data, f"Missing field: {field}"
        uuid.UUID(data["review_id"])  # raises ValueError if not a valid UUID

    def test_review_filing_not_found(self, client):
        resp = perform_review(client, "nonexistent-filing")
        assert resp.status_code == 404
