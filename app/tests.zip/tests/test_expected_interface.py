import csv
import inspect
from pathlib import Path

import numpy as np
import pandas as pd
import pytest


def _write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def test_load_journey_events_csv_has_expected_parameter_and_loads_valid_csv(import_or_fail, tmp_path):
    io = import_or_fail("app.io")
    sig = inspect.signature(io.load_journey_events_csv)
    assert "csv_path" in sig.parameters
    p = tmp_path / "events.csv"
    _write_csv(
        p,
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            }
        ],
    )
    out = io.load_journey_events_csv(str(p))
    assert isinstance(out, pd.DataFrame)
    assert set(out.columns.tolist()) == {
        "journey_id",
        "touchpoint_index",
        "channel",
        "touchpoint_ts",
        "converted",
    }
    assert pd.api.types.is_datetime64tz_dtype(out["touchpoint_ts"])
    assert str(out["touchpoint_ts"].dt.tz) == "UTC"
    assert pd.api.types.is_integer_dtype(out["touchpoint_index"])
    assert pd.api.types.is_integer_dtype(out["converted"])
    assert pd.api.types.is_object_dtype(out["journey_id"]) or pd.api.types.is_string_dtype(out["journey_id"])
    assert pd.api.types.is_object_dtype(out["channel"]) or pd.api.types.is_string_dtype(out["channel"])


def test_compute_journey_channel_credits_has_expected_defaults_and_runs(import_or_fail):
    attr = import_or_fail("app.attribution")
    sig = inspect.signature(attr.compute_journey_channel_credits)
    assert "events" in sig.parameters
    assert "model" in sig.parameters
    assert sig.parameters["half_life_hours"].default == 168.0
    assert sig.parameters["num_permutations"].default == 2000
    assert sig.parameters["random_seed"].default == 0
    assert sig.parameters["train_events"].default is None
    events = pd.DataFrame(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "A",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            }
        ]
    )
    events["touchpoint_ts"] = pd.to_datetime(events["touchpoint_ts"], utc=True)
    out = attr.compute_journey_channel_credits(events, model="first_touch")
    channel_cols = [c for c in out.columns if c not in {"journey_id", "converted"}]
    assert set(out["journey_id"].astype(str).tolist()) == {"J1"}
    assert float(out[channel_cols].sum(axis=1).to_numpy(dtype=float)[0]) == pytest.approx(1.0)
    assert np.isfinite(out[channel_cols].to_numpy(dtype=float)).all()


def test_compute_aggregated_channel_shares_has_expected_parameter_and_returns_series(import_or_fail):
    attr = import_or_fail("app.attribution")
    sig = inspect.signature(attr.compute_aggregated_channel_shares)
    assert "journey_credits" in sig.parameters
    journey_credits = pd.DataFrame(
        [
            {"journey_id": "J1", "converted": 1, "A": 0.25, "B": 0.75},
            {"journey_id": "J2", "converted": 0, "A": 0.9, "B": 0.1},
        ]
    )
    shares = attr.compute_aggregated_channel_shares(journey_credits)
    assert isinstance(shares, pd.Series)


def test_run_attribution_comparison_has_expected_defaults_and_runs(import_or_fail, tmp_path):
    runner = import_or_fail("app.runner")
    sig = inspect.signature(runner.run_attribution_comparison)
    assert sig.parameters["random_seed"].default == 0
    assert sig.parameters["holdout_fraction"].default == 0.2
    assert sig.parameters["n_bootstrap"].default == 200
    assert sig.parameters["half_life_hours"].default == 168.0
    assert sig.parameters["num_permutations"].default == 2000
    in_csv = tmp_path / "events.csv"
    _write_csv(
        in_csv,
        [
            {"journey_id": "J1", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
            {"journey_id": "J2", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 1},
            {"journey_id": "J3", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 0},
            {"journey_id": "J4", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-04T00:00:00Z", "converted": 0},
        ],
    )
    out_dir = tmp_path / "nested" / "out"
    out = runner.run_attribution_comparison(
        str(in_csv),
        str(out_dir),
        random_seed=0,
        holdout_fraction=0.5,
        n_bootstrap=1,
        num_permutations=10,
    )
    assert out_dir.is_dir()
    assert isinstance(out, dict)
    assert {"channel_shares", "holdout_metrics", "stability_scores", "recommended_model", "written_files"}.issubset(set(out.keys()))
