import { describe, it, expect } from "vitest";
import { createHash } from "node:crypto";
import { loadModule, defaultTheme, bytesEqual } from "./helpers";

describe("SlideDeckCompiler.renderPdf - PDF Rendering Contract", () => {
  it("PDF1: returns a Uint8Array (Rendering #5, Interface)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody";
      const deck = compiler.parse(md);
      const pdf = await compiler.renderPdf(deck, {}, md);
      if (!(pdf instanceof Uint8Array))
        throw new Error(`not Uint8Array, got ${Object.prototype.toString.call(pdf)}`);
      if (pdf.length === 0) throw new Error("empty Uint8Array");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF2: bytes begin with the literal `%PDF-` header (Rendering #5)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody";
      const deck = compiler.parse(md);
      const pdf: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const header = String.fromCharCode(...pdf.slice(0, 5));
      if (header !== "%PDF-")
        throw new Error(`first 5 bytes: ${JSON.stringify(header)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF3: byte-identical output for repeated calls with equal inputs (Determinism #1, #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# Slide One\nbody one\n---\n# Slide Two\nbody two";
      const deck = compiler.parse(md);
      const a: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const b: Uint8Array = await compiler.renderPdf(deck, {}, md);
      if (!bytesEqual(a, b))
        throw new Error(
          `pdf bytes differ across calls (lenA=${a.length}, lenB=${b.length})`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF4: differing markdown sources produce differing PDF bytes (sanity for Rendering #6 / Determinism #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const mdA = "# Alpha\nbody A";
      const mdB = "# Beta\nbody B different content here";
      const deckA = compiler.parse(mdA);
      const deckB = compiler.parse(mdB);
      const a: Uint8Array = await compiler.renderPdf(deckA, {}, mdA);
      const b: Uint8Array = await compiler.renderPdf(deckB, {}, mdB);
      if (bytesEqual(a, b))
        throw new Error("different markdown sources produced identical PDFs");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF5: differing themes produce differing PDF bytes for the same markdown (Theme #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody";
      const deck = compiler.parse(md);
      const a: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const b: Uint8Array = await compiler.renderPdf(
        deck,
        { backgroundColor: "#000000", textColor: "#ffffff", slidePaddingPx: 64 },
        md,
      );
      if (bytesEqual(a, b))
        throw new Error("different themes produced identical PDFs");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF6: /ID array contains the first 32 lowercase hex chars of SHA-256(UTF-8 markdown source) (Determinism #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# Hello\nbody text for id derivation";
      const deck = compiler.parse(md);
      const pdf: Uint8Array = await compiler.renderPdf(deck, {}, md);

      const expectedHex = createHash("sha256")
        .update(Buffer.from(md, "utf8"))
        .digest("hex")
        .slice(0, 32);

      const text = Buffer.from(pdf).toString("latin1");
      const occurrences = (
        text.match(new RegExp(expectedHex, "g")) || []
      ).length;
      if (occurrences < 2)
        throw new Error(
          `expected at least 2 occurrences of SHA-256[:32]="${expectedHex}" in PDF bytes (one per /ID entry); got ${occurrences}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF7: PDF metadata sets CreationDate and ModDate to literal 'D:19700101000000Z' (Determinism #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody";
      const deck = compiler.parse(md);
      const pdf: Uint8Array = await compiler.renderPdf(deck, {}, md);

      const text = Buffer.from(pdf).toString("latin1");
      const literal = "D:19700101000000Z";
      const occurrences = (
        text.match(new RegExp(literal.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g")) || []
      ).length;
      if (occurrences < 2)
        throw new Error(
          `expected at least 2 occurrences of '${literal}' in PDF bytes (one for CreationDate, one for ModDate); got ${occurrences}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF8: PDF Pages tree /Count equals the number of parsed slides (Rendering #5, #6)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = [
        "# Alpha Title",
        "alpha body line",
        "![alpha pic](alpha.png)",
        "```ts",
        "const alphaCode = 1;",
        "```",
        ":::notes",
        "alpha speaker remark",
        ":::",
        "---",
        "# Beta Title",
        "beta body line",
        "![beta pic](beta.png)",
        "```py",
        "beta_code = 2",
        "```",
        ":::notes",
        "beta speaker remark",
        ":::",
      ].join("\n");

      const deck = compiler.parse(md);
      const pdf: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const rawText = Buffer.from(pdf).toString("latin1");

      // Pages tree /Count must equal slide count.
      const countM = rawText.match(/\/Count\s+(\d+)/);
      if (!countM)
        throw new Error("Pages tree /Count not found in PDF");
      const declaredCount = Number(countM[1]);
      if (declaredCount !== deck.slides.length)
        throw new Error(
          `Pages /Count=${declaredCount} but slide count=${deck.slides.length}`,
        );

      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF9: PDF /ID is derived from the SHA-256 of the UTF-8 byte sequence of markdownSource - non-ASCII input distinguishes UTF-8 from Latin-1 encoding (Deterministic #4, Input format: UTF-8)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const { createHash } = await import("node:crypto");

      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# 日本語\nbody text";
      const deck = compiler.parse(md);
      const pdf: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const raw = Buffer.from(pdf).toString("latin1");

      // Compute the expected /ID from UTF-8 bytes (the encoding mandated by the prompt).
      const expected = createHash("sha256")
        .update(Buffer.from(md, "utf8"))
        .digest("hex")
        .slice(0, 32);

      // The PDF /ID array contains two hex strings; both must equal `expected`.
      const idRe = /\/ID\s*\[\s*<([0-9a-fA-F]{32,64})>\s*<([0-9a-fA-F]{32,64})>/;
      const idM = raw.match(idRe);
      if (!idM)
        throw new Error("PDF /ID array with two hex entries not found in raw output");

      const id1 = idM[1].slice(0, 32).toLowerCase();
      const id2 = idM[2].slice(0, 32).toLowerCase();

      if (id1 !== expected)
        throw new Error(
          `PDF /ID[0]="${id1}" does not match SHA-256 of UTF-8 bytes "${expected}"`,
        );
      if (id1 !== id2)
        throw new Error(`PDF /ID entries are not identical: "${id1}" vs "${id2}"`);

      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});