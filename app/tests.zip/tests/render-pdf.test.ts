// Tests for the PDF Rendering Contract (Rendering #5–#6, Determinism #4).

import { describe, it, expect } from "vitest";
import { createHash } from "node:crypto";
import { loadModule, defaultTheme, bytesEqual } from "./helpers";

describe("SlideDeckCompiler.renderPdf — PDF Rendering Contract", () => {
  it("PDF1: returns a Uint8Array (Rendering #5, Interface)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody";
      const deck = compiler.parse(md);
      const pdf = await compiler.renderPdf(deck, {}, md);
      if (!(pdf instanceof Uint8Array))
        throw new Error(`not Uint8Array, got ${Object.prototype.toString.call(pdf)}`);
      if (pdf.length === 0) throw new Error("empty Uint8Array");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF2: bytes begin with the literal `%PDF-` header (Rendering #5)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody";
      const deck = compiler.parse(md);
      const pdf: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const header = String.fromCharCode(...pdf.slice(0, 5));
      if (header !== "%PDF-")
        throw new Error(`first 5 bytes: ${JSON.stringify(header)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF3: byte-identical output for repeated calls with equal inputs (Determinism #1, #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# Slide One\nbody one\n---\n# Slide Two\nbody two";
      const deck = compiler.parse(md);
      const a: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const b: Uint8Array = await compiler.renderPdf(deck, {}, md);
      if (!bytesEqual(a, b))
        throw new Error(
          `pdf bytes differ across calls (lenA=${a.length}, lenB=${b.length})`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF4: differing markdown sources produce differing PDF bytes (sanity for Rendering #6 / Determinism #4)", async () => {
    // Two markdown sources that differ in content must produce different PDF
    // bytes — both because the rendered slides differ AND because the /ID
    // value (derived from the SHA-256 of the source) differs.
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const mdA = "# Alpha\nbody A";
      const mdB = "# Beta\nbody B different content here";
      const deckA = compiler.parse(mdA);
      const deckB = compiler.parse(mdB);
      const a: Uint8Array = await compiler.renderPdf(deckA, {}, mdA);
      const b: Uint8Array = await compiler.renderPdf(deckB, {}, mdB);
      if (bytesEqual(a, b))
        throw new Error("different markdown sources produced identical PDFs");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF5: differing themes produce differing PDF bytes for the same markdown (Theme #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody";
      const deck = compiler.parse(md);
      const a: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const b: Uint8Array = await compiler.renderPdf(
        deck,
        { backgroundColor: "#000000", textColor: "#ffffff", slidePaddingPx: 64 },
        md,
      );
      if (bytesEqual(a, b))
        throw new Error("different themes produced identical PDFs");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF6: /ID array contains the first 32 lowercase hex chars of SHA-256(UTF-8 markdown source) (Determinism #4)", async () => {
    // The prompt requires the PDF /ID array to contain "two identical
    // 32-character lowercase hexadecimal strings derived from the SHA-256
    // digest of the UTF-8 bytes of the markdown source (first 32 hex
    // characters of the digest)." We assert the literal hex value the
    // prompt prescribes appears in the PDF byte stream at least twice
    // (once per array entry). We do not assume any specific PDF
    // serialization beyond what is observable in the bytes.
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# Hello\nbody text for id derivation";
      const deck = compiler.parse(md);
      const pdf: Uint8Array = await compiler.renderPdf(deck, {}, md);

      const expectedHex = createHash("sha256")
        .update(Buffer.from(md, "utf8"))
        .digest("hex")
        .slice(0, 32);

      // Search the raw PDF byte stream (latin1 is a 1:1 byte->char mapping)
      // for the 32-char lowercase hex digest.
      const text = Buffer.from(pdf).toString("latin1");
      const occurrences = (
        text.match(new RegExp(expectedHex, "g")) || []
      ).length;
      if (occurrences < 2)
        throw new Error(
          `expected at least 2 occurrences of SHA-256[:32]="${expectedHex}" in PDF bytes (one per /ID entry); got ${occurrences}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF7: PDF metadata sets CreationDate and ModDate to literal 'D:19700101000000Z' (Determinism #4)", async () => {
    // The prompt mandates these EXACT literal PDF date strings:
    //   CreationDate MUST equal `D:19700101000000Z`
    //   ModDate      MUST equal `D:19700101000000Z`
    // We verify both literal occurrences appear in the PDF bytes.
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody";
      const deck = compiler.parse(md);
      const pdf: Uint8Array = await compiler.renderPdf(deck, {}, md);

      const text = Buffer.from(pdf).toString("latin1");
      const literal = "D:19700101000000Z";
      const occurrences = (
        text.match(new RegExp(literal.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g")) || []
      ).length;
      if (occurrences < 2)
        throw new Error(
          `expected at least 2 occurrences of '${literal}' in PDF bytes (one for CreationDate, one for ModDate); got ${occurrences}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("PDF8: PDF Pages tree /Count equals slide count and each slide's title/body/image/code/notes content is represented in the PDF byte stream (Rendering #5, #6)", async () => {
    // Observable consequence of the prompt's structural requirement that
    // the PDF declares one Page object per slide (with /Count equal to the
    // slide count) AND that the same content categories present in the HTML
    // render — title, body, images, code, speaker notes — are each
    // represented in the PDF for every slide.
    //
    // Content streams in a valid PDF may be compressed (e.g., FlateDecode).
    // We therefore decompress every stream before searching for content
    // substrings, making the test robust to any PDF library that uses
    // default stream compression.
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const { inflateSync } = await import("node:zlib");

      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = [
        "# Alpha Title",
        "alpha body line",
        "![alpha pic](alpha.png)",
        "```ts",
        "const alphaCode = 1;",
        "```",
        ":::notes",
        "alpha speaker remark",
        ":::",
        "---",
        "# Beta Title",
        "beta body line",
        "![beta pic](beta.png)",
        "```py",
        "beta_code = 2",
        "```",
        ":::notes",
        "beta speaker remark",
        ":::",
      ].join("\n");

      const deck = compiler.parse(md);
      const pdf: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const raw = Buffer.from(pdf);

      // ── 1. Decode all content streams, both compressed and plain ──────────
      // Walk raw bytes as latin1 text, extract every stream…endstream block,
      // attempt FlateDecode decompression, and accumulate all decoded text.
      // This is robust to any PDF library that uses stream compression.
      const rawText = raw.toString("latin1");
      const streamRe = /stream\r?\n([\s\S]*?)\r?\nendstream/g;
      // Always include the full raw text (covers cross-reference table,
      // object headers, and any uncompressed streams).
      let decodedAll = rawText;
      let m: RegExpExecArray | null;
      while ((m = streamRe.exec(rawText)) !== null) {
        const streamBytes = Buffer.from(m[1], "latin1");
        try {
          decodedAll += "\n" + inflateSync(streamBytes).toString("utf8");
        } catch {
          // Stream is not deflate-compressed; its bytes are already
          // present in rawText / decodedAll — no action needed.
        }
      }

      // ── 2. Pages tree /Count must equal slide count ───────────────────────
      // /Count appears in the uncompressed cross-reference / object-header
      // section of the PDF, so searching rawText is reliable here.
      const countM = rawText.match(/\/Count\s+(\d+)/);
      if (!countM)
        throw new Error("Pages tree /Count not found in PDF");
      const declaredCount = Number(countM[1]);
      if (declaredCount !== deck.slides.length)
        throw new Error(
          `Pages /Count=${declaredCount} but slide count=${deck.slides.length}`,
        );

      // ── 3. Every content category must appear somewhere in the decoded
      //       byte stream (compressed or plain) ──────────────────────────────
      //
      // Textually required tokens (titles, body, code, speaker notes) must
      // appear literally in the decoded stream — these are always text.
      const textTokens = [
        "Alpha Title",
        "Beta Title",
        "alpha body line",
        "beta body line",
        "alphaCode",
        "beta_code",
        "alpha speaker remark",
        "beta speaker remark",
      ];
      const missing = textTokens.filter((tok) => !decodedAll.includes(tok));
      if (missing.length > 0)
        throw new Error(
          `expected slide content not found in PDF ` +
          `(checked raw + decompressed streams): ${missing.join(", ")}`,
        );

      // Image category: the prompt requires images to be "represented" in
      // the PDF (Rendering Contract #6) but does not mandate HOW. A valid
      // implementation may embed actual PNG bytes (no filename in the stream),
      // render the alt text as a label, or write the source URL as a
      // reference. We accept EITHER the alt text OR the source filename for
      // each slide's image so that all of these approaches pass.
      const imageChecks = [
        { alt: "alpha pic", src: "alpha.png" },
        { alt: "beta pic",  src: "beta.png"  },
      ];
      for (const { alt, src } of imageChecks) {
        if (!decodedAll.includes(alt) && !decodedAll.includes(src))
          throw new Error(
            `no image marker found in decoded PDF for a slide's image ` +
            `(checked alt text "${alt}" and source "${src}")`,
          );
      }

      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});