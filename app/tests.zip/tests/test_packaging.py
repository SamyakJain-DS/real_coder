"""Verify the packaging artifacts that ship alongside the pipeline."""

import inspect
from importlib import import_module

import pytest


EXPECTED_DEPENDENCIES = frozenset(
    {"pandas==2.2.2", "numpy==1.26.4", "scikit-learn==1.5.0"}
)


def test_requirements_pins_documented_dependencies(repo_root):
    """``requirements.txt`` lists exactly the three pinned dependencies
    mandated by the prompt and contains no extra package lines."""

    text = (repo_root / "requirements.txt").read_text(encoding="utf-8")
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    assert set(lines) == set(EXPECTED_DEPENDENCIES)
    assert len(lines) == len(EXPECTED_DEPENDENCIES)


def test_donor_pipeline_module_imports_and_exposes_class():
    """``src.donor_pipeline`` is importable and exposes ``DonorPipeline``
    as a *class* (not merely a callable) under the documented module
    path. The strict ``inspect.isclass`` check rules out implementations
    that bind ``DonorPipeline`` to a plain function or factory callable,
    which the prompt's "Public class" wording forbids."""

    try:
        module = import_module("src.donor_pipeline")
    except (ImportError, ModuleNotFoundError) as exc:
        pytest.fail(f"Could not import src.donor_pipeline: {exc}")

    assert hasattr(module, "DonorPipeline")
    assert inspect.isclass(module.DonorPipeline), (
        "DonorPipeline must be a class, not a function or other callable."
    )
