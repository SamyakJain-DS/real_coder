"""Tests for the structural guarantees of the ``rank_donors`` output."""

import pandas as pd


EXPECTED_COLUMNS = [
    "donor_id",
    "prob_next_gift",
    "expected_next_gift_amount",
    "expected_next_30_day_revenue",
    "saturation_score",
    "is_over_solicited",
]


EXPECTED_DTYPES = {
    "donor_id": "object",
    "prob_next_gift": "float64",
    "expected_next_gift_amount": "float64",
    "expected_next_30_day_revenue": "float64",
    "saturation_score": "float64",
    "is_over_solicited": "bool",
}


def test_columns_match_documented_names_and_order(ranked):
    """Output columns appear in exactly the documented order with the
    documented names."""

    assert list(ranked.columns) == EXPECTED_COLUMNS


def test_columns_use_documented_dtypes(ranked):
    """Each output column carries the dtype mandated by section 5 of the
    prompt."""

    for column, expected_dtype in EXPECTED_DTYPES.items():
        actual = ranked[column].dtype
        assert actual == expected_dtype, (
            f"{column} has dtype {actual!s}; expected {expected_dtype}"
        )


def test_index_is_default_range_index_starting_at_zero(ranked):
    """The output index is a default ``RangeIndex`` starting at 0 with
    step 1 and stop equal to the row count - i.e. exactly
    ``pd.RangeIndex(len(ranked))``. The full equality check rules out
    pathological RangeIndex variants (non-unit step, non-zero start,
    truncated stop) that the simpler ``start == 0`` check would
    overlook."""

    assert isinstance(ranked.index, pd.RangeIndex)
    assert ranked.index.start == 0
    assert ranked.index.step == 1
    assert ranked.index.stop == len(ranked)
    assert ranked.index.equals(pd.RangeIndex(len(ranked)))


def test_one_row_per_donor_with_first_gift_up_to_as_of_date(
    DonorPipeline, sample_donations, make_donations
):
    """The output contains exactly one row per donor whose first donation
    date is on or before the resolved ``as_of_date``; donors that first
    donate after ``as_of_date`` are excluded."""

    extra = make_donations(
        [
            {
                "donor_id": "LATE_FIRST",
                "donation_amount": 50.0,
                "date": pd.Timestamp("2024-12-15"),
                "campaign": "winter",
                "channel": "email",
            }
        ]
    )
    augmented = pd.concat([sample_donations, extra], ignore_index=True)

    pipeline = DonorPipeline().fit(augmented)
    out = pipeline.rank_donors(augmented)

    as_of_date = augmented["date"].max() - pd.Timedelta(days=30)
    eligible = (
        augmented.groupby("donor_id")["date"].min().loc[lambda s: s <= as_of_date].index.tolist()
    )

    assert sorted(out["donor_id"].tolist()) == sorted(eligible)
    assert "LATE_FIRST" not in out["donor_id"].values


def test_rows_sorted_by_revenue_descending_with_donor_id_tiebreak(ranked):
    """Rows are sorted strictly by ``expected_next_30_day_revenue``
    descending, with ties broken by ``donor_id`` ascending."""

    expected = ranked.sort_values(
        ["expected_next_30_day_revenue", "donor_id"],
        ascending=[False, True],
    ).reset_index(drop=True)

    pd.testing.assert_frame_equal(ranked, expected)


def test_donor_id_breaks_ties_in_ascending_order(
    DonorPipeline, sample_donations, make_donations
):
    """When two donors have identical engineered features they tie on
    ``expected_next_30_day_revenue``; the spec mandates the tie-break
    is ``donor_id`` ascending. ``ZZ_TWIN`` and ``AA_TWIN`` are given
    byte-for-byte identical donation histories so the model produces
    identical predictions and identical revenues; the assertion
    checks that ``AA_TWIN`` appears strictly before ``ZZ_TWIN`` in the
    output. This guards against implementations that omit the
    tie-breaker (since unique-revenue datasets cannot expose that bug)
    or that sort the tie-breaker descending.
    """

    twin_history = [
        {"donation_amount": 25.0, "date": pd.Timestamp("2024-09-01"),
         "campaign": "fall", "channel": "email"},
        {"donation_amount": 40.0, "date": pd.Timestamp("2024-10-15"),
         "campaign": "fall", "channel": "mail"},
        {"donation_amount": 55.0, "date": pd.Timestamp("2024-11-20"),
         "campaign": "winter", "channel": "email"},
    ]
    twin_rows = []
    for donor in ("AA_TWIN", "ZZ_TWIN"):
        for entry in twin_history:
            twin_rows.append({"donor_id": donor, **entry})
    twins = make_donations(twin_rows)
    df = pd.concat([sample_donations, twins], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    aa_revenue = out.loc[out["donor_id"] == "AA_TWIN", "expected_next_30_day_revenue"].iloc[0]
    zz_revenue = out.loc[out["donor_id"] == "ZZ_TWIN", "expected_next_30_day_revenue"].iloc[0]
    assert aa_revenue == zz_revenue, (
        "Twin donors with identical histories must tie on revenue; "
        "without a tie this test cannot exercise the donor_id tie-break."
    )

    aa_pos = out.index[out["donor_id"] == "AA_TWIN"][0]
    zz_pos = out.index[out["donor_id"] == "ZZ_TWIN"][0]
    assert aa_pos < zz_pos, (
        f"Tie-break violated: AA_TWIN at row {aa_pos} should appear "
        f"before ZZ_TWIN at row {zz_pos} (donor_id ascending)."
    )
