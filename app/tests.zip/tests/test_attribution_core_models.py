import pandas as pd
import pytest


def _events(rows: list[dict[str, object]]) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    df["touchpoint_ts"] = pd.to_datetime(df["touchpoint_ts"], utc=True)
    df["touchpoint_index"] = df["touchpoint_index"].astype(int)
    df["converted"] = df["converted"].astype(int)
    return df


def test_first_touch_uses_touchpoint_index_ordering(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T01:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="first_touch")
    row = credits.set_index("journey_id").loc["J1"]
    assert row["Email"] == pytest.approx(1.0)


def test_last_touch_uses_touchpoint_index_ordering(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T01:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="last_touch")
    row = credits.set_index("journey_id").loc["J1"]
    assert row["Search"] == pytest.approx(1.0)


def test_first_touch_assigns_all_credit_to_first_touchpoint_channel_for_converted(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T01:00:00Z",
                "converted": 1,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="first_touch")
    channel_cols = [c for c in credits.columns if c not in {"journey_id", "converted"}]
    row = credits.loc[0, channel_cols].to_dict()
    assert row["Email"] == pytest.approx(1.0)
    assert row["Search"] == pytest.approx(0.0)


def test_first_touch_assigns_all_credit_to_first_touchpoint_channel_for_null(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 0,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T01:00:00Z",
                "converted": 0,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="first_touch")
    channel_cols = [c for c in credits.columns if c not in {"journey_id", "converted"}]
    row = credits.loc[0, channel_cols].to_dict()
    assert row["Email"] == pytest.approx(1.0)
    assert row["Search"] == pytest.approx(0.0)


def test_last_touch_assigns_all_credit_to_last_touchpoint_channel_for_converted(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T01:00:00Z",
                "converted": 1,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="last_touch")
    channel_cols = [c for c in credits.columns if c not in {"journey_id", "converted"}]
    row = credits.loc[0, channel_cols].to_dict()
    assert row["Search"] == pytest.approx(1.0)
    assert row["Email"] == pytest.approx(0.0)


def test_last_touch_assigns_all_credit_to_last_touchpoint_channel_for_null(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 0,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T01:00:00Z",
                "converted": 0,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="last_touch")
    channel_cols = [c for c in credits.columns if c not in {"journey_id", "converted"}]
    row = credits.loc[0, channel_cols].to_dict()
    assert row["Search"] == pytest.approx(1.0)
    assert row["Email"] == pytest.approx(0.0)


def test_linear_assigns_equal_credit_per_touchpoint(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T01:00:00Z",
                "converted": 1,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="linear")
    row = credits.set_index("journey_id").loc["J1"]
    assert row["Email"] == pytest.approx(0.5)
    assert row["Search"] == pytest.approx(0.5)


def test_linear_aggregates_repeated_channel_occurrences(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 0,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-01T01:00:00Z",
                "converted": 0,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 2,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T02:00:00Z",
                "converted": 0,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="linear")
    row = credits.set_index("journey_id").loc["J1"]
    assert row["Search"] == pytest.approx(2.0 / 3.0)
    assert row["Email"] == pytest.approx(1.0 / 3.0)


def test_time_decay_uses_delta_hours_from_journey_end(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 1,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-08T00:00:00Z",
                "converted": 1,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="time_decay", half_life_hours=168.0)
    row = credits.set_index("journey_id").loc["J1"]
    assert row["Search"] == pytest.approx(2.0 / 3.0)
    assert row["Email"] == pytest.approx(1.0 / 3.0)


def test_time_decay_applies_same_definition_to_null_journeys(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {
                "journey_id": "J1",
                "touchpoint_index": 0,
                "channel": "Email",
                "touchpoint_ts": "2026-01-01T00:00:00Z",
                "converted": 0,
            },
            {
                "journey_id": "J1",
                "touchpoint_index": 1,
                "channel": "Search",
                "touchpoint_ts": "2026-01-08T00:00:00Z",
                "converted": 0,
            },
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="time_decay", half_life_hours=168.0)
    row = credits.set_index("journey_id").loc["J1"]
    assert row["Search"] == pytest.approx(2.0 / 3.0)
    assert row["Email"] == pytest.approx(1.0 / 3.0)

