import pandas as pd
import pytest


def _events(rows: list[dict[str, object]]) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    df["touchpoint_ts"] = pd.to_datetime(df["touchpoint_ts"], utc=True)
    df["touchpoint_index"] = df["touchpoint_index"].astype(int)
    df["converted"] = df["converted"].astype(int)
    return df


def _canon_credits(df: pd.DataFrame) -> pd.DataFrame:
    fixed = ["journey_id", "converted"]
    channel_cols = sorted([c for c in df.columns if c not in set(fixed)])
    return df.sort_values("journey_id").reset_index(drop=True).loc[:, fixed + channel_cols]


def test_shapley_single_channel_converted_journeys_produce_shares_proportional_to_counts(import_or_fail):
    attr = import_or_fail("app.attribution")
    train_events = _events(
        [
            # Converted journeys with singleton channel sets:
            {"journey_id": "JA", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
            {"journey_id": "JB", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 1},
            {"journey_id": "JC", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 1},
            {"journey_id": "JD", "touchpoint_index": 0, "channel": "C", "touchpoint_ts": "2026-01-04T00:00:00Z", "converted": 1},
            # One null journey so converted==0 exists in the dataset.
            {"journey_id": "JN", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-05T00:00:00Z", "converted": 0},
        ]
    )
    all_events = pd.concat(
        [
            train_events,
            _events(
                [
                    {"journey_id": "J_mix", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-06T00:00:00Z", "converted": 0},
                    {"journey_id": "J_mix", "touchpoint_index": 1, "channel": "B", "touchpoint_ts": "2026-01-06T01:00:00Z", "converted": 0},
                ]
            ),
        ],
        ignore_index=True,
    )
    credits = attr.compute_journey_channel_credits(
        all_events, model="shapley", train_events=train_events, num_permutations=10, random_seed=0
    )
    row = credits.set_index("journey_id").loc["J_mix"]
    assert row["A"] == pytest.approx(2.0 / 3.0)
    assert row["B"] == pytest.approx(1.0 / 3.0)


def test_shapley_uses_train_events_only_for_global_channel_shares(import_or_fail):
    attr = import_or_fail("app.attribution")
    train_events = _events(
        [
            {"journey_id": "JA", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
            {"journey_id": "JB", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 1},
            {"journey_id": "JN", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 0},
        ]
    )
    all_events = pd.concat(
        [
            train_events,
            _events(
                [
                    {"journey_id": "J_mixed", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-04T00:00:00Z", "converted": 1},
                    {"journey_id": "J_mixed", "touchpoint_index": 1, "channel": "D", "touchpoint_ts": "2026-01-04T01:00:00Z", "converted": 1},
                ]
            ),
        ],
        ignore_index=True,
    )
    credits = attr.compute_journey_channel_credits(
        all_events, model="shapley", train_events=train_events, num_permutations=10, random_seed=0
    )
    row = credits.set_index("journey_id").loc["J_mixed"]
    assert row["A"] == pytest.approx(1.0)
    assert row["D"] == pytest.approx(0.0)


def test_shapley_falls_back_to_uniform_when_total_shapley_value_is_zero(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {"journey_id": "J1", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 0},
            {"journey_id": "J1", "touchpoint_index": 1, "channel": "B", "touchpoint_ts": "2026-01-01T01:00:00Z", "converted": 0},
        ]
    )
    credits = attr.compute_journey_channel_credits(events, model="shapley", num_permutations=10, random_seed=0)
    row = credits.set_index("journey_id").loc["J1"]
    assert row["A"] == pytest.approx(0.5)
    assert row["B"] == pytest.approx(0.5)


def test_shapley_estimation_is_deterministic_for_fixed_random_seed(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {"journey_id": "J1", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
            {"journey_id": "J1", "touchpoint_index": 1, "channel": "B", "touchpoint_ts": "2026-01-01T01:00:00Z", "converted": 1},
            {"journey_id": "J2", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 0},
        ]
    )
    c1 = attr.compute_journey_channel_credits(events, model="shapley", num_permutations=25, random_seed=123)
    c2 = attr.compute_journey_channel_credits(events, model="shapley", num_permutations=25, random_seed=123)
    assert _canon_credits(c1).to_dict(orient="list") == _canon_credits(c2).to_dict(orient="list")


def test_shapley_uses_events_as_global_share_source_when_train_events_is_none(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events(
        [
            {"journey_id": "JA", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
            {"journey_id": "JB", "touchpoint_index": 0, "channel": "B", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 1},
            {"journey_id": "JN", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 0},
        ]
    )
    c1 = attr.compute_journey_channel_credits(events, model="shapley", train_events=None, num_permutations=10, random_seed=0)
    c2 = attr.compute_journey_channel_credits(events, model="shapley", train_events=events, num_permutations=10, random_seed=0)
    assert _canon_credits(c1).to_dict(orient="list") == _canon_credits(c2).to_dict(orient="list")


def test_shapley_falls_back_to_uniform_when_journey_has_no_supported_channels(import_or_fail):
    attr = import_or_fail("app.attribution")
    train_events = _events(
        [
            {"journey_id": "JA", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
            {"journey_id": "JN", "touchpoint_index": 0, "channel": "A", "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 0},
        ]
    )
    eval_events = _events(
        [
            {"journey_id": "J_eval", "touchpoint_index": 0, "channel": "X", "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 1},
            {"journey_id": "J_eval", "touchpoint_index": 1, "channel": "Y", "touchpoint_ts": "2026-01-03T01:00:00Z", "converted": 1},
        ]
    )
    credits = attr.compute_journey_channel_credits(
        eval_events, model="shapley", train_events=train_events, num_permutations=10, random_seed=0
    )
    row = credits.set_index("journey_id").loc["J_eval"]
    assert row["X"] == pytest.approx(0.5)
    assert row["Y"] == pytest.approx(0.5)

def test_shapley_assigns_zero_credit_to_channels_not_in_journey(import_or_fail):
    attr = import_or_fail("app.attribution")
    events = _events([
        {"journey_id": "J1", "touchpoint_index": 0, "channel": "A",
         "touchpoint_ts": "2026-01-01T00:00:00Z", "converted": 1},
        {"journey_id": "J2", "touchpoint_index": 0, "channel": "B",
         "touchpoint_ts": "2026-01-02T00:00:00Z", "converted": 1},
        {"journey_id": "JN", "touchpoint_index": 0, "channel": "A",
         "touchpoint_ts": "2026-01-03T00:00:00Z", "converted": 0},
    ])
    credits = attr.compute_journey_channel_credits(
        events, model="shapley", num_permutations=50, random_seed=0
    )
    row_j1 = credits.set_index("journey_id").loc["J1"]
    row_j2 = credits.set_index("journey_id").loc["J2"]
    # A is in global support but absent from J2; B is in global support but absent from J1
    assert row_j1["B"] == pytest.approx(0.0)
    assert row_j2["A"] == pytest.approx(0.0)