
import os
import sys
import pytest
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _load(sample_data_dir):
    from pipeline import load_and_validate
    return load_and_validate(sample_data_dir)


def _features(sample_data_dir):
    from pipeline import engineer_features
    return engineer_features(_load(sample_data_dir))


def _moratorium(sample_data_dir, **kwargs):
    from pipeline import analyze_moratorium_violations
    loaded = _load(sample_data_dir)
    fdf = _features(sample_data_dir)
    return analyze_moratorium_violations(fdf, loaded, **kwargs)


class TestMoratoriumReturnStructure:
    """Tests the return structure of analyze_moratorium_violations."""

    def test_returns_dataframe(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert isinstance(result, pd.DataFrame)

    def test_has_corridor_column(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert "corridor_name" in result.columns,             "analyze_moratorium_violations must return a 'corridor_name' column"

    def test_has_total_permits_column(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert "total_permits" in result.columns

    def test_has_moratorium_violations_column(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert "moratorium_violations" in result.columns

    def test_has_violation_rate_column(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert "violation_rate" in result.columns

    def test_has_days_since_last_overlay_column(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert "days_since_last_overlay" in result.columns

    def test_has_critical_flag_column(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert "critical_flag" in result.columns


class TestMoratoriumStatistics:
    """Tests for the correctness of moratorium statistics computation."""

    def test_one_row_per_corridor(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        corridor_col = [c for c in result.columns if "corridor" in c.lower()][0]
        assert result[corridor_col].nunique() == len(result)

    def test_violation_rate_is_fraction(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert (result["violation_rate"] >= 0.0).all()
        assert (result["violation_rate"] <= 1.0).all()

    def test_violation_rate_equals_violations_over_permits(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        for _, row in result.iterrows():
            if row["total_permits"] > 0:
                expected = row["moratorium_violations"] / row["total_permits"]
                assert abs(row["violation_rate"] - expected) < 1e-6

    def test_sorted_by_violation_rate_descending(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        rates = result["violation_rate"].tolist()
        assert rates == sorted(rates, reverse=True)

    def test_total_permits_non_negative(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert (result["total_permits"] >= 0).all()

    def test_moratorium_violations_leq_total_permits(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        assert (result["moratorium_violations"] <= result["total_permits"]).all()


class TestCriticalFlag:
    """Tests for the critical flag logic."""

    def test_critical_flag_is_boolean(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        vals = set(result["critical_flag"].dropna().unique())
        assert vals.issubset({True, False, 0, 1})

    def test_critical_flag_false_when_violation_rate_below_threshold(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        below_threshold = result[result["violation_rate"] <= 0.10]
        if len(below_threshold) > 0:
            assert (below_threshold["critical_flag"] == False).all()

    def test_critical_flag_false_when_days_since_overlay_is_nan(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        nan_overlay = result[result["days_since_last_overlay"].isna()]
        if len(nan_overlay) > 0:
            assert (nan_overlay["critical_flag"] == False).all()

    def test_critical_flag_false_when_days_since_overlay_gte_730(self, sample_data_dir):
        result = _moratorium(sample_data_dir)
        old_overlay = result[
            (result["days_since_last_overlay"].notna()) &
            (result["days_since_last_overlay"] >= 730)
        ]
        if len(old_overlay) > 0:
            assert (old_overlay["critical_flag"] == False).all()


class TestMoratoriumQuarterFiltering:
    """Tests that quarter filtering works when start/end are provided."""

    def test_quarter_filtering_produces_results(self, sample_data_dir):
        """Quarter filtering must restrict to EXACTLY the permits whose issue_date falls
        within [quarter_start, quarter_end] — not just any arbitrary subset."""
        qs = pd.Timestamp("2018-01-01")
        qe = pd.Timestamp("2018-03-31")
        feature_df = _features(sample_data_dir)
        filtered = _moratorium(sample_data_dir, quarter_start=qs, quarter_end=qe)
        full = _moratorium(sample_data_dir)
        assert isinstance(filtered, pd.DataFrame)
        # Compute the expected in-quarter permit count directly from feature_df
        in_quarter = feature_df[
            (feature_df["issue_date"] >= qs) & (feature_df["issue_date"] <= qe)
        ]
        expected_count = len(in_quarter)
        assert filtered["total_permits"].sum() == expected_count, (
            f"Filtered analysis must account for exactly {expected_count} permits "
            f"(those with issue_date in Q1-2018), got {filtered['total_permits'].sum()}"
        )
        # Sanity: filtered must also be strictly less than full (fixture has out-of-quarter permits)
        assert filtered["total_permits"].sum() < full["total_permits"].sum(),             "Quarter filtering must strictly reduce total permits vs the full dataset"

    def test_full_dataset_when_no_quarter(self, sample_data_dir):
        """When no quarter filter is applied, the analysis must account for ALL permits."""
        feature_df = _features(sample_data_dir)
        result = _moratorium(sample_data_dir)
        assert len(result) > 0
        assert result["total_permits"].sum() == len(feature_df), (
            f"Full-dataset analysis must account for all {len(feature_df)} permits, "
            f"got {result['total_permits'].sum()}"
        )


class TestCriticalFlagPositiveCase:
    """Tests that critical_flag is True when ALL three conditions are simultaneously met."""

    def test_critical_flag_true_when_all_conditions_met(self, tmp_path):
        """Construct a minimal controlled dataset that guarantees one corridor meets
        all three conditions: violation_rate > 0.10, days_since_last_overlay < 730,
        days_since_last_overlay is not NaN. Assert critical_flag == True."""
        from pipeline import load_and_validate, engineer_features, analyze_moratorium_violations

        data_dir = tmp_path / "critical_data"
        data_dir.mkdir()

        # One segment with a recent overlay and an active moratorium window
        pd.DataFrame({
            "segment_id": ["SEG1"],
            "corridor_name": ["CriticalCorridor"],
            "pavement_install_date": ["2010-01-01"],
            "overlay_date": ["2018-06-01"],      # Recent overlay
            "moratorium_start": ["2019-01-01"],
            "moratorium_end": ["2020-01-01"],
        }).to_csv(data_dir / "street_segments.csv", index=False)

        # 5 permits: P001 falls inside the moratorium window -> violation_rate = 1/5 = 0.20 > 0.10
        # P002-P004 are before the moratorium; P005 is after the overlay so has_overlay=True
        pd.DataFrame({
            "permit_id": ["P001", "P002", "P003", "P004", "P005"],
            "permittee_id": ["PT001"] * 5,
            "street_segment_id": ["SEG1"] * 5,
            "issue_date": ["2019-06-01", "2018-01-01", "2018-03-01", "2018-05-01", "2018-08-01"],
            "excavation_purpose": ["utility_install"] * 5,
            "restoration_scope": ["full"] * 5,
            "traffic_control_plan_adequate": [True] * 5,
            "warranty_start": ["2018-01-01"] * 5,
            "warranty_end": ["2021-01-01"] * 5,
        }).to_csv(data_dir / "permits.csv", index=False)

        pd.DataFrame({
            "permittee_id": ["PT001"], "name": ["TestCo"], "type": ["utility"],
        }).to_csv(data_dir / "permittees.csv", index=False)

        pd.DataFrame({
            "inspection_id": ["I001", "I002", "I003", "I004", "I005"],
            "permit_id": ["P001", "P002", "P003", "P004", "P005"],
            "inspection_date": ["2019-01-15"] * 5,
            "backfill_accepted": [True] * 5,
            "base_course_accepted": [True] * 5,
            "surface_restoration_accepted": [True] * 5,
        }).to_csv(data_dir / "inspections.csv", index=False)

        for fname, cols in [
            ("settlement_failures.csv", ["failure_id", "permit_id", "failure_date", "severity"]),
            ("fee_assessments.csv", ["assessment_id", "permittee_id", "permit_id", "amount", "date"]),
            ("bond_claims.csv", ["claim_id", "permittee_id", "permit_id", "claim_amount", "claim_date", "resolved"]),
            ("coordination_notices.csv", ["notice_id", "permittee_id", "permit_id", "notice_date", "project_start_date"]),
        ]:
            pd.DataFrame(columns=cols).to_csv(data_dir / fname, index=False)

        datasets = load_and_validate(str(data_dir))
        feature_df = engineer_features(datasets)
        result = analyze_moratorium_violations(feature_df, datasets)

        critical = result[result["corridor_name"] == "CriticalCorridor"]
        assert len(critical) == 1, "CriticalCorridor must appear in moratorium analysis"
        row = critical.iloc[0]

        # Verify all three enabling conditions hold (so the assertion is not vacuous)
        assert row["violation_rate"] > 0.10, (
            f"Test setup error: expected violation_rate > 0.10, got {row['violation_rate']}"
        )
        assert not pd.isna(row["days_since_last_overlay"]), (
            "Test setup error: expected non-NaN days_since_last_overlay"
        )
        assert row["days_since_last_overlay"] < 730, (
            f"Test setup error: expected days_since_last_overlay < 730, got {row['days_since_last_overlay']}"
        )

        # The key assertion: all conditions met -> critical_flag must be True
        assert row["critical_flag"] == True, (
            "critical_flag must be True when violation_rate > 0.10 AND "
            "days_since_last_overlay is not NaN AND < 730"
        )


class TestDaysSinceLastOverlayFormula:
    """Tests that days_since_last_overlay is the MEDIAN of days_since_overlay
    for corridor permits with has_overlay == True."""

    def test_days_since_last_overlay_median_formula(self, tmp_path):
        """days_since_last_overlay must equal the median of days_since_overlay
        across permits in the corridor that have has_overlay == True."""
        from pipeline import load_and_validate, engineer_features, analyze_moratorium_violations

        data_dir = tmp_path / "median_test"
        data_dir.mkdir()

        # One segment, overlay 2020-01-01
        # Three permits issued 10, 20, and 50 days after overlay
        # All have has_overlay=True -> days_since_overlay = 10, 20, 50
        # Median = 20.0
        pd.DataFrame({
            "segment_id": ["SEG1"],
            "corridor_name": ["CorA"],
            "pavement_install_date": ["2010-01-01"],
            "overlay_date": ["2020-01-01"],
            "moratorium_start": [None], "moratorium_end": [None],
        }).to_csv(data_dir / "street_segments.csv", index=False)

        pd.DataFrame({
            "permit_id": ["P1", "P2", "P3"],
            "permittee_id": ["PT1"] * 3,
            "street_segment_id": ["SEG1"] * 3,
            "issue_date": ["2020-01-11", "2020-01-21", "2020-02-20"],
            "excavation_purpose": ["utility_install"] * 3,
            "restoration_scope": ["full"] * 3,
            "traffic_control_plan_adequate": [True] * 3,
            "warranty_start": ["2019-01-01"] * 3,
            "warranty_end": ["2023-01-01"] * 3,
        }).to_csv(data_dir / "permits.csv", index=False)

        pd.DataFrame({"permittee_id": ["PT1"], "name": ["Co"], "type": ["utility"]}).to_csv(
            data_dir / "permittees.csv", index=False)
        pd.DataFrame({
            "inspection_id": ["I1", "I2", "I3"],
            "permit_id": ["P1", "P2", "P3"],
            "inspection_date": ["2020-03-01"] * 3,
            "backfill_accepted": [True] * 3,
            "base_course_accepted": [True] * 3,
            "surface_restoration_accepted": [True] * 3,
        }).to_csv(data_dir / "inspections.csv", index=False)

        for fname, cols in [
            ("settlement_failures.csv", ["failure_id", "permit_id", "failure_date", "severity"]),
            ("fee_assessments.csv", ["assessment_id", "permittee_id", "permit_id", "amount", "date"]),
            ("bond_claims.csv", ["claim_id", "permittee_id", "permit_id", "claim_amount", "claim_date", "resolved"]),
            ("coordination_notices.csv", ["notice_id", "permittee_id", "permit_id", "notice_date", "project_start_date"]),
        ]:
            pd.DataFrame(columns=cols).to_csv(data_dir / fname, index=False)

        datasets = load_and_validate(str(data_dir))
        feature_df = engineer_features(datasets)
        result = analyze_moratorium_violations(feature_df, datasets)

        cor_a = result[result["corridor_name"] == "CorA"]
        assert len(cor_a) == 1, "CorA must appear in the moratorium analysis output"

        # All three permits have has_overlay=True; days_since_overlay = 10, 20, 50
        # Median([10, 20, 50]) = 20.0
        actual = cor_a.iloc[0]["days_since_last_overlay"]
        assert abs(actual - 20.0) < 1e-6, (
            f"days_since_last_overlay must be the median 20.0 of [10, 20, 50], got {actual}"
        )


class TestDaysSinceLastOverlayNaN:
    """days_since_last_overlay must be NaN when no permit in the corridor
    has has_overlay == True.
    Prompt: 'If no permits in the corridor have a valid overlay, set to NaN.'
    """

    def test_days_since_last_overlay_nan_when_corridor_has_no_overlay_permits(self, tmp_path):
        """A corridor whose only segment has overlay_date=None yields
        days_since_last_overlay=NaN because every permit has has_overlay=False."""
        from pipeline import load_and_validate, engineer_features, analyze_moratorium_violations

        data_dir = tmp_path / "no_overlay_corridor"
        data_dir.mkdir()

        pd.DataFrame({
            "segment_id": ["S1"], "corridor_name": ["NullOverlayCorridor"],
            "pavement_install_date": ["2010-01-01"],
            "overlay_date": [None],   # no overlay -> all permits get has_overlay=False
            "moratorium_start": [None], "moratorium_end": [None],
        }).to_csv(data_dir / "street_segments.csv", index=False)

        pd.DataFrame({
            "permit_id": ["P1", "P2"],
            "permittee_id": ["PT1", "PT1"],
            "street_segment_id": ["S1", "S1"],
            "issue_date": ["2020-01-01", "2021-01-01"],
            "excavation_purpose": ["utility_install", "utility_install"],
            "restoration_scope": ["full", "full"],
            "traffic_control_plan_adequate": [True, True],
            "warranty_start": ["2019-01-01", "2020-01-01"],
            "warranty_end": ["2023-01-01", "2024-01-01"],
        }).to_csv(data_dir / "permits.csv", index=False)

        pd.DataFrame({"permittee_id": ["PT1"], "name": ["Co"], "type": ["utility"]}).to_csv(
            data_dir / "permittees.csv", index=False)
        pd.DataFrame({
            "inspection_id": ["I1", "I2"],
            "permit_id": ["P1", "P2"],
            "inspection_date": ["2020-03-01", "2021-03-01"],
            "backfill_accepted": [True, True],
            "base_course_accepted": [True, True],
            "surface_restoration_accepted": [True, True],
        }).to_csv(data_dir / "inspections.csv", index=False)

        for fname, cols in [
            ("settlement_failures.csv", ["failure_id", "permit_id", "failure_date", "severity"]),
            ("fee_assessments.csv",     ["assessment_id", "permittee_id", "permit_id", "amount", "date"]),
            ("bond_claims.csv",         ["claim_id", "permittee_id", "permit_id", "claim_amount", "claim_date", "resolved"]),
            ("coordination_notices.csv",["notice_id", "permittee_id", "permit_id", "notice_date", "project_start_date"]),
        ]:
            pd.DataFrame(columns=cols).to_csv(data_dir / fname, index=False)

        datasets = load_and_validate(str(data_dir))
        feature_df = engineer_features(datasets)
        result = analyze_moratorium_violations(feature_df, datasets)

        corridor_row = result[result["corridor_name"] == "NullOverlayCorridor"]
        assert len(corridor_row) == 1, "NullOverlayCorridor must appear in the moratorium analysis"
        assert pd.isna(corridor_row.iloc[0]["days_since_last_overlay"]), (
            "days_since_last_overlay must be NaN when no permits in the corridor "
            "have has_overlay == True"
        )
