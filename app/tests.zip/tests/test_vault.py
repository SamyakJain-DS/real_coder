"""
F2P test suite for the command-line password manager (vault.py).

Every test maps to an explicit or implicit requirement from the prompt.
Tests verify observable behaviour and public interfaces only - no
implementation details, no hardcoded error messages, no private helpers.
"""
import os
import sys
import time
import subprocess
import pytest
from unittest.mock import patch

# -- path setup ----------------------------------------------------------------
_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT_DIR  = os.path.join(_TESTS_DIR, "..")
sys.path.insert(0, _ROOT_DIR)

# -- constants ------------------------------------------------------------------
MASTER_PWD     = "MasterPass123!"
WRONG_PWD      = "WrongPassXYZ9!"
BACKUP_PWD     = "BackupPass456@"
COMMON_PW_PATH = os.path.join(_ROOT_DIR, "data", "common_passwords.txt")


# -- import helper --------------------------------------------------------------
def vault_fn(name: str):
    """
    Return vault.<name>.
    Must only be called from INSIDE a test body (or a helper called from one)
    so that pytest.fail() produces FAILED, not ERROR.
    """
    try:
        import vault as _v
    except ImportError:
        pytest.fail("vault.py could not be imported (module missing or syntax error)")
    fn = getattr(_v, name, None)
    if fn is None:
        pytest.fail(f"vault.{name} is not defined")
    return fn


def _noclip():
    """Suppress real clipboard I/O in headless Docker environments."""
    return patch("pyperclip.copy")


# -- vault setup helpers (plain functions, NOT fixtures) ------------------------
def _vault(tmp_path, populated: bool = False) -> str:
    """
    Create and return the path of an initialised vault.
    Called from test bodies → vault_fn() failures show as FAILED, not ERROR.
    populated=True inserts three standard test entries.
    """
    db = str(tmp_path / "vault.db")
    vault_fn("init_vault")(db, MASTER_PWD)
    if populated:
        add = vault_fn("add_entry")
        add(db, MASTER_PWD, "GitHub", "alice",       "https://github.com",    "GhPass!1abcX")
        add(db, MASTER_PWD, "Gmail",  "alice@x.com", "https://gmail.com",     "GmPass@2xyzY")
        add(db, MASTER_PWD, "AWS",    "admin",       "https://aws.amazon.com","AwsPass#3defZ")
    return db


# -- fixture (safe: never calls vault_fn) --------------------------------------
@pytest.fixture
def tmp_db(tmp_path):
    """Path to a database file that does NOT yet exist."""
    return str(tmp_path / "vault.db")


# ==============================================================================
# init_vault
# ==============================================================================
class TestInitVault:

    def test_creates_database_file(self, tmp_db):
        """init_vault must create a file at db_path."""
        vault_fn("init_vault")(tmp_db, MASTER_PWD)
        assert os.path.exists(tmp_db)

    def test_raises_if_file_already_exists(self, tmp_db):
        """Calling init_vault on an existing path must raise an exception."""
        init = vault_fn("init_vault")
        init(tmp_db, MASTER_PWD)
        with pytest.raises(Exception):
            init(tmp_db, MASTER_PWD)

    def test_wrong_master_password_raises_on_read_operation(self, tmp_path):
        """
        A wrong master password supplied to a read operation (list_entries)
        must raise an exception.
        """
        db = _vault(tmp_path)
        with pytest.raises(Exception):
            vault_fn("list_entries")(db, WRONG_PWD)

    def test_wrong_master_password_raises_on_write_operation(self, tmp_path):
        """
        A wrong master password supplied to a write operation (add_entry)
        must raise an exception.
        """
        db = _vault(tmp_path)
        with pytest.raises(Exception):
            vault_fn("add_entry")(db, WRONG_PWD, "svc", "u", "https://x.com", "P@ss1!")

    def test_wrong_master_password_raises_on_delete_operation(self, tmp_path):
        """
        A wrong master password supplied to a delete operation (remove_entry)
        must raise an exception.
        """
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "delsvc", "u", "https://x.com", "P@ss1!")
        with pytest.raises(Exception):
            vault_fn("remove_entry")(db, WRONG_PWD, "delsvc", confirm=True)


# ==============================================================================
# add_entry
# ==============================================================================
class TestAddEntry:

    def test_stored_entry_is_retrievable(self, tmp_path):
        """An entry added to the vault can be retrieved by service name."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "myservice", "user1", "https://example.com", "Passw0rd!")
        with _noclip():
            entry = vault_fn("get_entry")(db, MASTER_PWD, "myservice", 60)
        assert entry is not None

    def test_autogenerates_password_when_empty_string_supplied(self, tmp_path):
        """When password='', add_entry must store a non-empty auto-generated password."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "autosvc", "bob", "https://auto.com", "")
        with _noclip():
            entry = vault_fn("get_entry")(db, MASTER_PWD, "autosvc", 60)
        assert entry["password"] != ""

    def test_autogenerated_password_is_exactly_16_characters(self, tmp_path):
        """Auto-generated password must be exactly 16 characters long."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "autosvc", "bob", "https://auto.com", "")
        with _noclip():
            entry = vault_fn("get_entry")(db, MASTER_PWD, "autosvc", 60)
        assert len(entry["password"]) == 16

    def test_autogenerated_password_contains_all_four_character_classes(self, tmp_path):
        """Auto-generated password must include upper, lower, digit, and symbol characters."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "autosvc", "bob", "https://auto.com", "")
        with _noclip():
            entry = vault_fn("get_entry")(db, MASTER_PWD, "autosvc", 60)
        pw = entry["password"]
        assert any(c.isupper()     for c in pw), "No uppercase letter in auto-generated password"
        assert any(c.islower()     for c in pw), "No lowercase letter in auto-generated password"
        assert any(c.isdigit()     for c in pw), "No digit in auto-generated password"
        assert any(not c.isalnum() for c in pw), "No symbol in auto-generated password"

    def test_raises_if_service_already_exists(self, tmp_path):
        """add_entry must raise an exception when the service name already exists in the vault."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "dupsvc", "user1", "https://x.com", "Pass1!abc")
        with pytest.raises(Exception):
            vault_fn("add_entry")(db, MASTER_PWD, "dupsvc", "user2", "https://y.com", "Pass2!xyz")


# ==============================================================================
# get_entry
# ==============================================================================
class TestGetEntry:

    def test_returns_dict_with_all_required_keys(self, tmp_path):
        """get_entry must return a dict containing exactly: service, username, url, password."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "svc", "u", "https://svc.com", "Pass1!")
        with _noclip():
            entry = vault_fn("get_entry")(db, MASTER_PWD, "svc", 60)
        assert set(entry.keys()) == {"service", "username", "url", "password"}

    def test_returned_values_match_stored_values(self, tmp_path):
        """get_entry must return the exact values that were stored."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "exactsvc", "alice", "https://exact.io", "ExPass9!")
        with _noclip():
            entry = vault_fn("get_entry")(db, MASTER_PWD, "exactsvc", 60)
        assert entry["service"]  == "exactsvc"
        assert entry["username"] == "alice"
        assert entry["url"]      == "https://exact.io"
        assert entry["password"] == "ExPass9!"

    def test_raises_when_service_name_does_not_exist(self, tmp_path):
        """get_entry must raise an exception for an unknown service name."""
        db = _vault(tmp_path)
        with pytest.raises(Exception):
            with _noclip():
                vault_fn("get_entry")(db, MASTER_PWD, "nonexistent", 60)


# ==============================================================================
# list_entries
# ==============================================================================
class TestListEntries:

    def test_empty_vault_returns_empty_list(self, tmp_path):
        """list_entries returns an empty list when no entries have been added."""
        db = _vault(tmp_path)
        assert vault_fn("list_entries")(db, MASTER_PWD) == []

    def test_each_entry_contains_only_service_and_username(self, tmp_path):
        """Every dict returned by list_entries must have exactly 'service' and 'username' keys."""
        db = _vault(tmp_path, populated=True)
        entries = vault_fn("list_entries")(db, MASTER_PWD)
        assert len(entries) > 0
        for e in entries:
            assert set(e.keys()) == {"service", "username"}

    def test_returns_all_stored_entries(self, tmp_path):
        """list_entries must return one item per stored entry."""
        db  = _vault(tmp_path)
        add = vault_fn("add_entry")
        add(db, MASTER_PWD, "svc1", "u1", "https://s1.com", "Pass1!abc")
        add(db, MASTER_PWD, "svc2", "u2", "https://s2.com", "Pass2!xyz")
        add(db, MASTER_PWD, "svc3", "u3", "https://s3.com", "Pass3!def")
        services = {e["service"] for e in vault_fn("list_entries")(db, MASTER_PWD)}
        assert services == {"svc1", "svc2", "svc3"}


# ==============================================================================
# edit_entry
# ==============================================================================
class TestEditEntry:

    def test_updates_a_provided_field(self, tmp_path):
        """edit_entry changes the fields supplied with non-empty strings."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "editsvc", "olduser", "https://old.com", "OldPass1!")
        vault_fn("edit_entry")(db, MASTER_PWD, "editsvc", "newuser", "", "")
        with _noclip():
            entry = vault_fn("get_entry")(db, MASTER_PWD, "editsvc", 60)
        assert entry["username"] == "newuser"

    def test_empty_string_fields_are_left_unchanged(self, tmp_path):
        """Fields passed as '' to edit_entry must retain their original values."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "editsvc", "alice", "https://orig.com", "OrigPass1!")
        vault_fn("edit_entry")(db, MASTER_PWD, "editsvc", "", "", "NewPass2!")
        with _noclip():
            entry = vault_fn("get_entry")(db, MASTER_PWD, "editsvc", 60)
        assert entry["username"] == "alice"             # unchanged
        assert entry["url"]      == "https://orig.com"  # unchanged
        assert entry["password"] == "NewPass2!"         # changed

    def test_all_empty_strings_changes_nothing(self, tmp_path):
        """edit_entry with all empty-string arguments must not modify any field."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "editsvc", "bob", "https://bob.com", "BobPass1!")
        vault_fn("edit_entry")(db, MASTER_PWD, "editsvc", "", "", "")
        with _noclip():
            entry = vault_fn("get_entry")(db, MASTER_PWD, "editsvc", 60)
        assert entry["username"] == "bob"
        assert entry["url"]      == "https://bob.com"
        assert entry["password"] == "BobPass1!"

    def test_raises_when_service_not_found(self, tmp_path):
        """edit_entry must raise an exception for an unknown service name."""
        db = _vault(tmp_path)
        with pytest.raises(Exception):
            vault_fn("edit_entry")(db, MASTER_PWD, "ghost", "u", "https://x.com", "P!")


# ==============================================================================
# remove_entry
# ==============================================================================
class TestRemoveEntry:

    def test_confirm_true_removes_entry(self, tmp_path):
        """remove_entry with confirm=True must delete the entry."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "tosvc", "u", "https://t.com", "ToPass1!")
        vault_fn("remove_entry")(db, MASTER_PWD, "tosvc", confirm=True)
        services = [e["service"] for e in vault_fn("list_entries")(db, MASTER_PWD)]
        assert "tosvc" not in services

    def test_confirm_false_does_not_remove_entry(self, tmp_path):
        """remove_entry with confirm=False must leave the entry intact."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "keepsvc", "u", "https://k.com", "KeepPass1!")
        vault_fn("remove_entry")(db, MASTER_PWD, "keepsvc", confirm=False)
        services = [e["service"] for e in vault_fn("list_entries")(db, MASTER_PWD)]
        assert "keepsvc" in services

    def test_raises_when_confirm_true_and_service_not_found(self, tmp_path):
        """remove_entry(confirm=True) must raise when the service does not exist."""
        db = _vault(tmp_path)
        with pytest.raises(Exception):
            vault_fn("remove_entry")(db, MASTER_PWD, "ghost", confirm=True)

    def test_confirm_false_nonexistent_service_does_not_raise(self, tmp_path):
        """remove_entry(confirm=False) must return silently even for a non-existent service."""
        db = _vault(tmp_path)
        vault_fn("remove_entry")(db, MASTER_PWD, "ghost", confirm=False)


# ==============================================================================
# generate_password
# ==============================================================================
class TestGeneratePassword:

    def test_returns_exact_length(self):
        """generate_password must return a string of exactly 'length' characters."""
        gen = vault_fn("generate_password")
        for length in (8, 16, 24, 32):
            pw = gen(length, True, True, True, True, False)
            assert len(pw) == length, f"Expected {length} chars, got {len(pw)}"

    def test_pronounceable_returns_exact_length(self):
        """Pronounceable mode must still return exactly 'length' characters."""
        gen = vault_fn("generate_password")
        for length in (10, 20, 30):
            pw = gen(length, False, False, False, False, True)
            assert len(pw) == length, f"Expected {length} chars, got {len(pw)}"

    def test_raises_valueerror_when_all_flags_false_and_not_pronounceable(self):
        """Must raise ValueError when pronounceable=False and every character class is disabled."""
        with pytest.raises(ValueError):
            vault_fn("generate_password")(12, False, False, False, False, False)

    def test_only_uppercase_when_use_upper_is_the_sole_enabled_class(self):
        """With only use_upper=True, every character must be an uppercase letter."""
        pw = vault_fn("generate_password")(30, True, False, False, False, False)
        assert all(c.isupper() for c in pw), f"Non-uppercase chars found: {pw!r}"

    def test_only_lowercase_when_use_lower_is_the_sole_enabled_class(self):
        """With only use_lower=True, every character must be a lowercase letter."""
        pw = vault_fn("generate_password")(30, False, True, False, False, False)
        assert all(c.islower() for c in pw), f"Non-lowercase chars found: {pw!r}"

    def test_only_digits_when_use_digits_is_the_sole_enabled_class(self):
        """With only use_digits=True, every character must be a decimal digit."""
        pw = vault_fn("generate_password")(30, False, False, True, False, False)
        assert all(c.isdigit() for c in pw), f"Non-digit chars found: {pw!r}"

    def test_only_symbols_when_use_symbols_is_the_sole_enabled_class(self):
        """With only use_symbols=True, no character may be alphanumeric."""
        pw = vault_fn("generate_password")(30, False, False, False, True, False)
        assert all(not c.isalnum() for c in pw), f"Alphanumeric chars found: {pw!r}"

    def test_multiple_enabled_classes_uses_only_those_classes(self):
        """
        With use_upper=True and use_digits=True only, the password must
        contain no lowercase letters and no symbol characters.
        """
        pw = vault_fn("generate_password")(50, True, False, True, False, False)
        assert len(pw) == 50
        for c in pw:
            assert c.isupper() or c.isdigit(), (
                f"Unexpected character {c!r} - only uppercase + digits expected"
            )

    def test_pronounceable_mode_ignores_character_class_flags(self):
        """
        When pronounceable=True, passing any combination of character class
        flags must not raise an exception and must still return a string of
        the correct length - the flags are ignored.
        """
        gen = vault_fn("generate_password")
        # All four flags True alongside pronounceable=True - must not crash
        pw = gen(20, True, True, True, True, True)
        assert isinstance(pw, str)
        assert len(pw) == 20


# ==============================================================================
# search_entries
# ==============================================================================
class TestSearchEntries:

    def test_returns_matching_entry(self, tmp_path):
        """search_entries must return the entry whose service name matches the query."""
        db = _vault(tmp_path, populated=True)
        results = vault_fn("search_entries")(db, MASTER_PWD, "GitHub")
        assert any(r["service"] == "GitHub" for r in results)

    def test_match_is_case_insensitive(self, tmp_path):
        """search_entries must match regardless of query letter case."""
        db     = _vault(tmp_path, populated=True)
        search = vault_fn("search_entries")
        for query in ("github", "GITHUB", "GitHuB"):
            results = search(db, MASTER_PWD, query)
            assert any(r["service"] == "GitHub" for r in results), (
                f"Query {query!r} did not match 'GitHub'"
            )

    def test_partial_substring_returns_all_matching_entries(self, tmp_path):
        """search_entries must return all entries whose service name contains the query."""
        db       = _vault(tmp_path, populated=True)
        results  = vault_fn("search_entries")(db, MASTER_PWD, "g")
        services = {r["service"] for r in results}
        assert "GitHub" in services
        assert "Gmail"  in services

    def test_no_match_returns_empty_list(self, tmp_path):
        """search_entries must return an empty list when no service name matches."""
        db = _vault(tmp_path, populated=True)
        assert vault_fn("search_entries")(db, MASTER_PWD, "zzznomatch999") == []

    def test_each_result_contains_only_service_and_username(self, tmp_path):
        """Each dict returned by search_entries must have exactly service and username keys."""
        db      = _vault(tmp_path, populated=True)
        results = vault_fn("search_entries")(db, MASTER_PWD, "git")
        assert len(results) > 0
        for r in results:
            assert set(r.keys()) == {"service", "username"}


# ==============================================================================
# export_vault / import_vault
# ==============================================================================
class TestExportVault:

    def test_export_creates_backup_file(self, tmp_path):
        """export_vault must create a file at the given backup_path."""
        db     = _vault(tmp_path, populated=True)
        backup = str(tmp_path / "backup.db")
        vault_fn("export_vault")(db, MASTER_PWD, backup, BACKUP_PWD)
        assert os.path.exists(backup)

    def test_wrong_master_password_raises_on_export(self, tmp_path):
        """export_vault must raise an exception when the master password is incorrect."""
        db     = _vault(tmp_path, populated=True)
        backup = str(tmp_path / "backup.db")
        with pytest.raises(Exception):
            vault_fn("export_vault")(db, WRONG_PWD, backup, BACKUP_PWD)

    def test_wrong_backup_password_raises_on_import(self, tmp_path):
        """import_vault must raise an exception when the wrong backup_password is supplied."""
        db     = _vault(tmp_path, populated=True)
        backup = str(tmp_path / "backup.db")
        vault_fn("export_vault")(db, MASTER_PWD, backup, BACKUP_PWD)
        with pytest.raises(Exception):
            vault_fn("import_vault")(db, MASTER_PWD, backup, "totallywrong!")

    def test_wrong_vault_master_password_raises_on_import(self, tmp_path):
        """import_vault must raise when the destination vault's master password is incorrect."""
        db      = _vault(tmp_path, populated=True)
        backup  = str(tmp_path / "backup.db")
        dest_db = str(tmp_path / "dest.db")
        vault_fn("export_vault")(db, MASTER_PWD, backup, BACKUP_PWD)
        vault_fn("init_vault")(dest_db, MASTER_PWD)
        with pytest.raises(Exception):
            vault_fn("import_vault")(dest_db, WRONG_PWD, backup, BACKUP_PWD)


class TestImportVault:

    def test_import_restores_all_exported_entries(self, tmp_path):
        """
        After export + import into a fresh vault, every original service must
        be present in the destination vault.
        """
        db      = _vault(tmp_path, populated=True)
        backup  = str(tmp_path / "backup.db")
        dest_db = str(tmp_path / "dest.db")

        original_services = {
            e["service"]
            for e in vault_fn("list_entries")(db, MASTER_PWD)
        }
        assert len(original_services) > 0

        vault_fn("export_vault")(db, MASTER_PWD, backup, BACKUP_PWD)
        vault_fn("init_vault")(dest_db, MASTER_PWD)
        vault_fn("import_vault")(dest_db, MASTER_PWD, backup, BACKUP_PWD)

        dest_services = {
            e["service"]
            for e in vault_fn("list_entries")(dest_db, MASTER_PWD)
        }
        assert original_services == dest_services

    def test_imported_entry_fields_match_original(self, tmp_path):
        """Imported entries must contain the exact same credential data as the originals."""
        db      = _vault(tmp_path)
        backup  = str(tmp_path / "backup.db")
        dest_db = str(tmp_path / "dest.db")

        vault_fn("add_entry")(db, MASTER_PWD, "importsvc", "carol", "https://imp.io", "ImpPass1!")
        vault_fn("export_vault")(db, MASTER_PWD, backup, BACKUP_PWD)
        vault_fn("init_vault")(dest_db, MASTER_PWD)
        vault_fn("import_vault")(dest_db, MASTER_PWD, backup, BACKUP_PWD)

        with _noclip():
            entry = vault_fn("get_entry")(dest_db, MASTER_PWD, "importsvc", 60)
        assert entry["username"] == "carol"
        assert entry["url"]      == "https://imp.io"
        assert entry["password"] == "ImpPass1!"

    def test_import_overwrites_existing_entry_with_same_service(self, tmp_path):
        """
        When the backup contains a service name already present in the destination
        vault, import_vault must overwrite the existing entry with the imported values.
        """
        db      = _vault(tmp_path)
        backup  = str(tmp_path / "backup.db")
        dest_db = str(tmp_path / "dest.db")

        # Source vault: "conflictsvc" with the values that should win after import
        vault_fn("add_entry")(db, MASTER_PWD, "conflictsvc", "imported_user",
                              "https://imported.io", "ImportedPass1!")
        vault_fn("export_vault")(db, MASTER_PWD, backup, BACKUP_PWD)

        # Destination vault: same service name but different values
        vault_fn("init_vault")(dest_db, MASTER_PWD)
        vault_fn("add_entry")(dest_db, MASTER_PWD, "conflictsvc", "old_user",
                              "https://old.io", "OldPass1!")

        # Import must overwrite the existing destination entry
        vault_fn("import_vault")(dest_db, MASTER_PWD, backup, BACKUP_PWD)

        with _noclip():
            entry = vault_fn("get_entry")(dest_db, MASTER_PWD, "conflictsvc", 60)
        assert entry["username"] == "imported_user"
        assert entry["url"]      == "https://imported.io"
        assert entry["password"] == "ImportedPass1!"


# ==============================================================================
# audit_passwords
# ==============================================================================
class TestAuditPasswords:

    def test_no_weak_entries_returns_empty_list(self, tmp_path):
        """
        When every stored password is strong (>=12 chars, >=3 classes, not common),
        audit_passwords must return an empty list.
        """
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "strongsvc", "u", "https://s.io", "Str0ng!Pass#X")
        assert vault_fn("audit_passwords")(db, MASTER_PWD) == []

    def test_flags_password_shorter_than_12_characters(self, tmp_path):
        """audit_passwords must flag an entry whose password has fewer than 12 chars."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "shortsvc", "u", "https://x.com", "Ab1!")
        flagged = [e["service"] for e in vault_fn("audit_passwords")(db, MASTER_PWD)]
        assert "shortsvc" in flagged

    def test_flags_password_with_fewer_than_three_character_classes(self, tmp_path):
        """
        A 12-char password with only lowercase letters (1 class) must be flagged
        for low character diversity.
        """
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "lowdiv", "u", "https://x.com", "abcdefghijkl")
        flagged = [e["service"] for e in vault_fn("audit_passwords")(db, MASTER_PWD)]
        assert "lowdiv" in flagged

    def test_flags_password_present_in_common_passwords_file(self, tmp_path):
        """A password found in data/common_passwords.txt must appear in audit results."""
        if not os.path.exists(COMMON_PW_PATH):
            pytest.fail("data/common_passwords.txt not found")
        with open(COMMON_PW_PATH) as fh:
            lines = [ln.strip() for ln in fh if ln.strip()]
        if not lines:
            pytest.fail("data/common_passwords.txt is empty")
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "commonsvc", "u", "https://x.com", lines[0])
        flagged = [e["service"] for e in vault_fn("audit_passwords")(db, MASTER_PWD)]
        assert "commonsvc" in flagged

    def test_result_dicts_contain_required_keys(self, tmp_path):
        """Every dict returned by audit_passwords must have service, username, reasons."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "weaksvc", "u", "https://x.com", "short")
        results = vault_fn("audit_passwords")(db, MASTER_PWD)
        assert len(results) > 0
        for entry in results:
            assert "service"  in entry
            assert "username" in entry
            assert "reasons"  in entry

    def test_reasons_is_a_non_empty_list_of_strings(self, tmp_path):
        """The 'reasons' field for each flagged entry must be a non-empty list of strings."""
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "weaksvc", "u", "https://x.com", "short")
        results = vault_fn("audit_passwords")(db, MASTER_PWD)
        assert len(results) > 0
        for entry in results:
            assert isinstance(entry["reasons"], list)
            assert len(entry["reasons"]) >= 1
            assert all(isinstance(r, str) for r in entry["reasons"])

    def test_multiple_conditions_produce_multiple_reasons(self, tmp_path):
        """
        A password that fails more than one check must list one reason per failure.
        'abc' is short AND low-diversity → at least 2 reasons expected.
        """
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "multiweak", "u", "https://x.com", "abc")
        results = vault_fn("audit_passwords")(db, MASTER_PWD)
        flagged = [e for e in results if e["service"] == "multiweak"]
        assert len(flagged) == 1
        assert len(flagged[0]["reasons"]) >= 2


# ==============================================================================
# clipboard behaviour (get_entry)
# ==============================================================================
class TestClipboard:

    def test_get_entry_copies_password_to_clipboard(self, tmp_path):
        """
        get_entry must call pyperclip.copy with the retrieved password
        before returning.
        """
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "clipsvc", "u", "https://clip.io", "ClipPass1!")
        copied = []
        with patch("pyperclip.copy", side_effect=lambda v: copied.append(v)):
            vault_fn("get_entry")(db, MASTER_PWD, "clipsvc", clipboard_timeout=60)
        assert "ClipPass1!" in copied, "Password was not copied to the clipboard"

    def test_clipboard_is_cleared_after_timeout(self, tmp_path):
        """
        After clipboard_timeout seconds, pyperclip.copy must be called again
        with a value that is not the original password (i.e. the clipboard
        is cleared).

        Timing note: clipboard_timeout=2 and a 4-second poll window give
        generous headroom for thread scheduling variance without making the
        test meaningfully slower.
        """
        db = _vault(tmp_path)
        vault_fn("add_entry")(db, MASTER_PWD, "clipsvc2", "u", "https://clip2.io", "ClipPass2!")
        copied = []
        with patch("pyperclip.copy", side_effect=lambda v: copied.append(v)):
            vault_fn("get_entry")(db, MASTER_PWD, "clipsvc2", clipboard_timeout=2)
            # Poll until the clearing write arrives or the deadline passes.
            deadline = time.monotonic() + 4.0
            while time.monotonic() < deadline:
                if len(copied) >= 2:
                    break
                time.sleep(0.1)

        assert len(copied) >= 2, (
            f"Expected ≥2 clipboard writes (set + clear), got {len(copied)}: {copied}"
        )
        assert copied[-1] != "ClipPass2!", (
            "Clipboard still contains the password after timeout - it was not cleared"
        )


# ==============================================================================
# bundled data files
# ==============================================================================
class TestDataFiles:

    def test_common_passwords_file_exists(self):
        """data/common_passwords.txt must be present in the repository."""
        assert os.path.exists(COMMON_PW_PATH), (
            f"Expected data/common_passwords.txt at {COMMON_PW_PATH} - file not found"
        )

    def test_common_passwords_file_has_at_least_100_entries(self):
        """data/common_passwords.txt must contain at least 100 non-blank lines."""
        if not os.path.exists(COMMON_PW_PATH):
            pytest.fail(f"data/common_passwords.txt not found at {COMMON_PW_PATH}")
        with open(COMMON_PW_PATH) as fh:
            lines = [ln.strip() for ln in fh if ln.strip()]
        assert len(lines) >= 100, (
            f"Expected ≥100 entries in common_passwords.txt, found {len(lines)}"
        )



# ==============================================================================
# encryption on disk
# ==============================================================================
class TestEncryption:

    def test_credential_data_is_not_stored_in_plaintext_on_disk(self, tmp_path):
        """
        The raw vault database file must not contain any credential data in
        plaintext. The entire file must be opaque without the correct master
        password - schema, row count, and all credential data remain encrypted.

        Basis: "the entire database file is opaque without the correct master
        password - schema, row count, and all credential data remain encrypted
        on disk" and "No credential data is ever written to disk in plaintext"
        """
        db = _vault(tmp_path)
        vault_fn("add_entry")(
            db, MASTER_PWD, "encryptsvc", "encryptuser",
            "https://encrypt.io", "EncryptPass1!"
        )
        with open(db, "rb") as fh:
            raw = fh.read()
        assert b"encryptsvc"      not in raw, "Service name found in plaintext on disk"
        assert b"encryptuser"     not in raw, "Username found in plaintext on disk"
        assert b"https://encrypt" not in raw, "URL found in plaintext on disk"
        assert b"EncryptPass1!"   not in raw, "Password found in plaintext on disk"


# ==============================================================================
# idle timeout  (subprocess-level: tests CLI behaviour across invocations)
# ==============================================================================
class TestIdleTimeout:
    """
    The prompt specifies that the CLI reads the master password via an
    interactive stdin prompt (getpass or equivalent) before executing any
    command that requires vault access.  That contract makes the password-
    delivery mechanism determinate, so these tests are not over-specified.

    We use --timeout 1 so the timeout expires within the test's sleep window.

    No vault_fn() calls are made here, so the fixture-vs-body issue does
    not apply to this class.  On an empty/missing vault.py the first
    subprocess call exits non-zero and the assertion fails → FAILED.
    """

    @staticmethod
    def _run(args, stdin_text="", timeout=15):
        """Run vault.py as a subprocess and return the CompletedProcess."""
        vault_py = os.path.join(_ROOT_DIR, "vault.py")
        return subprocess.run(
            [sys.executable, vault_py] + args,
            input=stdin_text,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

    def test_command_within_timeout_succeeds_without_reentry(self, tmp_path):
        """
        Within the --timeout window the CLI must NOT re-prompt for the master
        password; the active session is sufficient.

        Steps:
          1. Init vault (password supplied via stdin).
          2. Run 'list' with the master password - session starts, --timeout 3.
          3. Immediately run 'list' with NO stdin input.
          4. Assert step 3 exits successfully (session still active).

        Timing note: --timeout 3 gives subprocess startup overhead plenty of
        room so the second invocation never accidentally lands outside the
        window on a slow CI machine.
        """
        db = str(tmp_path / "vault.db")

        r0 = self._run(["--db", db, "init"], stdin_text=f"{MASTER_PWD}\n")
        assert r0.returncode == 0, f"Vault init failed:\n{r0.stderr}"

        r1 = self._run(
            ["--db", db, "--timeout", "3", "list"],
            stdin_text=f"{MASTER_PWD}\n",
        )
        assert r1.returncode == 0, f"First list command failed:\n{r1.stderr}"

        r2 = self._run(
            ["--db", db, "--timeout", "3", "list"],
            stdin_text="",
        )
        assert r2.returncode == 0, (
            "Command issued within the timeout window should succeed without "
            "re-entering the master password."
        )

    def test_command_after_timeout_fails_without_password(self, tmp_path):
        """
        After the --timeout window expires the CLI must re-prompt for the
        master password via stdin; omitting it must cause a non-zero exit.

        Steps:
          1. Init vault and run 'list' with password (session starts, --timeout 2).
          2. Sleep 3.0 s so the 2-second timeout expires with headroom for
             subprocess startup overhead on slow machines.
          3. Run 'list' with NO stdin input.
          4. Assert step 3 exits with a non-zero code.
        """
        db = str(tmp_path / "vault.db")

        r0 = self._run(["--db", db, "init"], stdin_text=f"{MASTER_PWD}\n")
        assert r0.returncode == 0, f"Vault init failed:\n{r0.stderr}"

        r1 = self._run(
            ["--db", db, "--timeout", "2", "list"],
            stdin_text=f"{MASTER_PWD}\n",
        )
        assert r1.returncode == 0, f"Session-establishing list command failed:\n{r1.stderr}"

        time.sleep(3.0)

        r2 = self._run(
            ["--db", db, "--timeout", "2", "list"],
            stdin_text="",
        )
        assert r2.returncode != 0, (
            "Command issued after the idle timeout expired should require the "
            "master password to be re-entered via stdin, but it succeeded without one."
        )