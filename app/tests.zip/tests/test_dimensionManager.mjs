/**
 * Tests for dimensionManager.js
 * Covers: convertUnit named export
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';

const MODULE_PATH = new URL('../dimensionManager.js', import.meta.url).href;

async function loadModule() {
  try {
    return await import(MODULE_PATH);
  } catch {
    return null;
  }
}

// ─── Same-unit identity ───────────────────────────────────────────────────────

test('dimensionManager: convertUnit returns value unchanged when fromUnit === toUnit (inches)', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('dimensionManager.js has not been implemented');
  assert.equal(mod.convertUnit(7, 'inches', 'inches'), 7);
});

test('dimensionManager: convertUnit returns value unchanged when fromUnit === toUnit (centimeters)', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('dimensionManager.js has not been implemented');
  assert.equal(mod.convertUnit(7, 'centimeters', 'centimeters'), 7);
});

// ─── Conversion accuracy ──────────────────────────────────────────────────────

test('dimensionManager: convertUnit converts 1 inch to 2.54 centimeters', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('dimensionManager.js has not been implemented');
  assert.equal(mod.convertUnit(1, 'inches', 'centimeters'), 2.54);
});

test('dimensionManager: convertUnit scales linearly inches to centimeters', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('dimensionManager.js has not been implemented');
  const result = mod.convertUnit(10, 'inches', 'centimeters');
  assert.ok(Math.abs(result - 25.4) < 0.0001, `Expected 25.4, got ${result}`);
});

test('dimensionManager: convertUnit converts 2.54 centimeters to 1 inch', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('dimensionManager.js has not been implemented');
  const result = mod.convertUnit(2.54, 'centimeters', 'inches');
  assert.ok(Math.abs(result - 1) < 0.0001, `Expected ~1, got ${result}`);
});

test('dimensionManager: convertUnit cm-to-inches is inverse of inches-to-cm', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('dimensionManager.js has not been implemented');
  const original = 12.5;
  const toCm = mod.convertUnit(original, 'inches', 'centimeters');
  const backToInches = mod.convertUnit(toCm, 'centimeters', 'inches');
  assert.ok(Math.abs(backToInches - original) < 0.0001,
    `Round-trip failed: ${original} -> ${toCm} -> ${backToInches}`);
});

// ─── Error cases ──────────────────────────────────────────────────────────────

test('dimensionManager: convertUnit throws RangeError for invalid fromUnit', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('dimensionManager.js has not been implemented');
  assert.throws(
    () => mod.convertUnit(1, 'meters', 'inches'),
    (err) => err instanceof RangeError
  );
});

test('dimensionManager: convertUnit throws RangeError for invalid toUnit', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('dimensionManager.js has not been implemented');
  assert.throws(
    () => mod.convertUnit(1, 'inches', 'meters'),
    (err) => err instanceof RangeError
  );
});

test('dimensionManager: convertUnit RangeError message is exactly "Invalid unit"', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('dimensionManager.js has not been implemented');
  try {
    mod.convertUnit(1, 'bad', 'inches');
    assert.fail('Expected RangeError to be thrown');
  } catch (err) {
    assert.ok(err instanceof RangeError);
    assert.equal(err.message, 'Invalid unit');
  }
});
