"""Tests for TaxAdministrationPlatform.process_return."""

from __future__ import annotations

from decimal import Decimal

import pytest

from _helpers import build_platform, default_rate_table


def _line(state: str, local: str, taxable: str, exempt: str = "0.00") -> dict:
    return {
        "destination_state_code": state,
        "destination_local_code": local,
        "taxable_sales_usd": Decimal(taxable),
        "exempt_sales_usd": Decimal(exempt),
    }


# --------------------------------------------------------------------------- #
# Test ID: RET-01
# Requirement: Return Processing #5 (return-level output keys) and #1
#   (filer_id, filer_category, filing_period propagation).
# Test Description: Verify the result dict contains every required top-level
#   key and propagates the input identity fields unchanged.
# --------------------------------------------------------------------------- #
def test_process_return_output_includes_required_keys():
    try:
        platform = build_platform()
        result = platform.process_return({
            "filer_id": "F-RET-01",
            "filer_category": "IN_STATE_RETAILER",
            "filing_period": "2024-01",
            "line_items": [_line("CA", "LA", "100.00", "0.00")],
        })

        for key in (
            "filer_id",
            "filer_category",
            "filing_period",
            "total_taxable_sales_usd",
            "total_exempt_sales_usd",
            "total_tax_due_usd",
            "jurisdiction_breakdown",
        ):
            assert key in result, f"missing key {key!r}"
        assert result["filer_id"] == "F-RET-01"
        assert result["filer_category"] == "IN_STATE_RETAILER"
        assert result["filing_period"] == "2024-01"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-02
# Requirement: Return Processing #4 (line-level tax formula with
#   ROUND_HALF_UP, combined_rate = state_rate + local_rate).
# Test Description: For a single line item, line_tax_due_usd equals
#   ROUND_HALF_UP(taxable_sales_usd * (state_rate + local_rate), 2).
# --------------------------------------------------------------------------- #
def test_process_return_line_tax_due_formula_round_half_up():
    try:
        platform = build_platform()
        # CA / LA: state 0.06 + local 0.025 = 0.085
        # 123.45 * 0.085 = 10.49325 -> ROUND_HALF_UP to 2 -> 10.49
        result = platform.process_return({
            "filer_id": "F-RET-02",
            "filer_category": "REMOTE_SELLER",
            "filing_period": "2024-02",
            "line_items": [_line("CA", "LA", "123.45")],
        })

        breakdown = result["jurisdiction_breakdown"]
        assert len(breakdown) == 1
        assert Decimal(breakdown[0]["line_tax_due_usd"]) == Decimal("10.49")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-03
# Requirement: Return Processing #4 (ROUND_HALF_UP, distinguishes from
#   banker's rounding).
# Test Description: A taxable line that produces a half-cent value must be
#   rounded UP, not to even.
# --------------------------------------------------------------------------- #
def test_process_return_round_half_up_at_half_cent():
    try:
        platform = build_platform()
        result = platform.process_return({
            "filer_id": "F-RET-03",
            "filer_category": "REMOTE_SELLER",
            "filing_period": "2024-02",
            "line_items": [_line("CA", "LA", "1.00")],
        })

        breakdown = result["jurisdiction_breakdown"]
        assert len(breakdown) == 1
        assert Decimal(breakdown[0]["line_tax_due_usd"]) == Decimal("0.09")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-04
# Requirement: Return Processing #5 (totals = sums across line items).
# Test Description: total_taxable_sales_usd, total_exempt_sales_usd and
#   total_tax_due_usd equal sums across all line items.
# --------------------------------------------------------------------------- #
def test_process_return_totals_match_sums():
    try:
        platform = build_platform()
        line_items = [
            _line("CA", "LA", "100.00", "10.00"),
            _line("CA", "SF", "200.00", "20.00"),
            _line("NY", "NYC", "300.00", "30.00"),
        ]
        result = platform.process_return({
            "filer_id": "F-RET-04",
            "filer_category": "REMOTE_SELLER",
            "filing_period": "2024-03",
            "line_items": line_items,
        })

        assert Decimal(result["total_taxable_sales_usd"]) == Decimal("600.00")
        assert Decimal(result["total_exempt_sales_usd"]) == Decimal("60.00")

        # Sum of line taxes:
        # CA/LA: 100 * 0.085 = 8.50
        # CA/SF: 200 * (0.06 + 0.0125) = 200 * 0.0725 = 14.50
        # NY/NYC: 300 * (0.04 + 0.045) = 300 * 0.085 = 25.50
        # Total = 48.50
        assert Decimal(result["total_tax_due_usd"]) == Decimal("48.50")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-05
# Requirement: Return Processing #6 (one breakdown entry per distinct
#   (state, local) key with aggregated sums).
# Test Description: Two line items with the same jurisdiction key produce a
#   single breakdown entry whose taxable_sales_usd and line_tax_due_usd equal
#   the sum across those line items.
# --------------------------------------------------------------------------- #
def test_process_return_aggregates_duplicate_jurisdictions():
    try:
        platform = build_platform()
        line_items = [
            _line("CA", "LA", "100.00"),
            _line("CA", "LA", "50.00"),
            _line("NY", "NYC", "200.00"),
        ]
        result = platform.process_return({
            "filer_id": "F-RET-05",
            "filer_category": "REMOTE_SELLER",
            "filing_period": "2024-04",
            "line_items": line_items,
        })

        breakdown = result["jurisdiction_breakdown"]
        assert len(breakdown) == 2

        ca_la = next(
            entry for entry in breakdown
            if entry["destination_state_code"] == "CA"
            and entry["destination_local_code"] == "LA"
        )
        assert Decimal(ca_la["taxable_sales_usd"]) == Decimal("150.00")
        # 150 * 0.085 = 12.75
        assert Decimal(ca_la["line_tax_due_usd"]) == Decimal("12.75")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-06
# Requirement: Return Processing #7 (sorting: state asc then local asc).
# Test Description: Verify breakdown entries appear in ascending order by
#   destination_state_code, then by destination_local_code.
# --------------------------------------------------------------------------- #
def test_process_return_breakdown_sorted_state_then_local():
    try:
        platform = build_platform()
        line_items = [
            _line("NY", "NYC", "10.00"),
            _line("CA", "SF", "10.00"),
            _line("CA", "LA", "10.00"),
            _line("TX", "AUS", "10.00"),
        ]
        result = platform.process_return({
            "filer_id": "F-RET-06",
            "filer_category": "REMOTE_SELLER",
            "filing_period": "2024-05",
            "line_items": line_items,
        })

        keys = [
            (e["destination_state_code"], e["destination_local_code"])
            for e in result["jurisdiction_breakdown"]
        ]
        assert keys == sorted(keys)
        assert keys == [("CA", "LA"), ("CA", "SF"), ("NY", "NYC"), ("TX", "AUS")]
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-07
# Requirement: Return Processing #8 (per-jurisdiction entry keys).
# Test Description: Each breakdown entry contains exactly the documented
#   keys: destination_state_code, destination_local_code, state_rate,
#   local_rate, taxable_sales_usd, line_tax_due_usd.
# --------------------------------------------------------------------------- #
def test_process_return_breakdown_entry_keys():
    try:
        platform = build_platform()
        result = platform.process_return({
            "filer_id": "F-RET-07",
            "filer_category": "REMOTE_SELLER",
            "filing_period": "2024-05",
            "line_items": [_line("CA", "LA", "100.00")],
        })

        entry = result["jurisdiction_breakdown"][0]
        for key in (
            "destination_state_code",
            "destination_local_code",
            "state_rate",
            "local_rate",
            "taxable_sales_usd",
            "line_tax_due_usd",
        ):
            assert key in entry, f"missing key {key!r} in jurisdiction entry"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-08
# Requirement: Validation #6 (empty line_items -> zero totals + empty
#   breakdown).
# Test Description: When line_items is empty, totals are zero and
#   jurisdiction_breakdown is an empty list.
# --------------------------------------------------------------------------- #
def test_process_return_empty_line_items():
    try:
        platform = build_platform()
        result = platform.process_return({
            "filer_id": "F-RET-08",
            "filer_category": "USE_TAX_FILER",
            "filing_period": "2024-06",
            "line_items": [],
        })

        assert Decimal(result["total_taxable_sales_usd"]) == Decimal("0.00")
        assert Decimal(result["total_exempt_sales_usd"]) == Decimal("0.00")
        assert Decimal(result["total_tax_due_usd"]) == Decimal("0.00")
        assert result["jurisdiction_breakdown"] == []
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-09
# Requirement: Validation #3 (rate lookup miss -> ValueError with the exact
#   jurisdiction key).
# Test Description: An unknown (state, local) combination raises ValueError
#   referencing the missing key.
# --------------------------------------------------------------------------- #
def test_process_return_missing_jurisdiction_raises_valueerror():
    try:
        platform = build_platform()
        with pytest.raises(ValueError) as ei:
            platform.process_return({
                "filer_id": "F-RET-09",
                "filer_category": "REMOTE_SELLER",
                "filing_period": "2024-07",
                "line_items": [_line("ZZ", "NONE", "10.00")],
            })

        # Validation #3: ValueError must surface the exact jurisdiction key
        # (state and local components). We check substring presence rather
        # than a fixed message format to remain implementation-neutral.
        message = str(ei.value)
        assert "ZZ" in message, f"missing state code in error message: {message!r}"
        assert "NONE" in message, f"missing local code in error message: {message!r}"
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-10
# Requirement: Validation #7 (duplicate rate-table entries: last wins).
# Test Description: When the rate table contains two entries for the same
#   (state, local) key, subsequent lookups use the rates of the entry
#   appearing last in the input order.
# --------------------------------------------------------------------------- #
def test_process_return_duplicate_rate_table_last_wins():
    try:
        from tax_administration import TaxAdministrationPlatform

        rate_table = [
            {
                "destination_state_code": "CA",
                "destination_local_code": "LA",
                "state_rate": Decimal("0.10"),
                "local_rate": Decimal("0.10"),
            },
            {
                "destination_state_code": "CA",
                "destination_local_code": "LA",
                "state_rate": Decimal("0.01"),
                "local_rate": Decimal("0.01"),
            },
        ]
        platform = TaxAdministrationPlatform(rate_table=rate_table)
        result = platform.process_return({
            "filer_id": "F-RET-10",
            "filer_category": "REMOTE_SELLER",
            "filing_period": "2024-07",
            "line_items": [_line("CA", "LA", "100.00")],
        })

        # Last-wins combined rate: 0.01 + 0.01 = 0.02 -> 100 * 0.02 = 2.00
        assert Decimal(result["total_tax_due_usd"]) == Decimal("2.00")
        entry = result["jurisdiction_breakdown"][0]
        assert Decimal(entry["state_rate"]) == Decimal("0.01")
        assert Decimal(entry["local_rate"]) == Decimal("0.01")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-11
# Requirement: Return Processing #3 (rate lookup uses the (state, local) key
#   pair so a state-only match with a different local must miss).
# Test Description: A line item that uses a known state code but an unknown
#   local code raises ValueError (key is the pair, not just the state).
# --------------------------------------------------------------------------- #
def test_process_return_state_match_local_miss_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError):
            platform.process_return({
                "filer_id": "F-RET-11",
                "filer_category": "REMOTE_SELLER",
                "filing_period": "2024-08",
                "line_items": [_line("CA", "UNKNOWN", "10.00")],
            })
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Test ID: RET-12
# Requirement: Aggregate Decimal sums quantized to two fractional digits via
#   ROUND_HALF_UP (top-of-prompt aggregate-quantization rule, applied to
#   total_taxable_sales_usd, total_exempt_sales_usd, total_tax_due_usd).
# Test Description: When summed taxable / exempt sales produce a third
#   fractional digit at the half boundary, the aggregate is rounded UP.
# --------------------------------------------------------------------------- #
def test_process_return_aggregate_quantization_round_half_up():
    try:
        platform = build_platform()
        # Two lines summing to 0.025 -> ROUND_HALF_UP to 0.03.
        line_items = [
            _line("CA", "LA", "0.005", "0.005"),
            _line("CA", "LA", "0.020", "0.020"),
        ]
        result = platform.process_return({
            "filer_id": "F-RET-12",
            "filer_category": "REMOTE_SELLER",
            "filing_period": "2024-09",
            "line_items": line_items,
        })

        assert Decimal(result["total_taxable_sales_usd"]) == Decimal("0.03")
        assert Decimal(result["total_exempt_sales_usd"]) == Decimal("0.03")
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


