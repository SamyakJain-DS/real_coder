"""Tests for the cross-cutting Validation and Edge-Case Contract.

These tests cover the explicit prompt rules:
- Each public workflow MUST raise ValueError when required input fields
  are missing.
- Each public workflow MUST raise ValueError when an enum-typed input
  field contains a value outside its declared enum set
  (filer_category, refund_category, audit_status, action).
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from _helpers import build_platform


# --------------------------------------------------------------------------- #
# Missing-required-field tests (Validation #1)
# --------------------------------------------------------------------------- #


# Test ID: VAL-01
# Requirement: Validation #1 applied to register_filer.
def test_register_filer_missing_required_field_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError) as ei:
            platform.register_filer({
                # filer_id missing
                "filer_category": "REMOTE_SELLER",
                "annual_gross_sales_usd": Decimal("1.00"),
                "annual_transaction_count": 1,
                "nexus_threshold_sales_usd": Decimal("1.00"),
                "nexus_threshold_transaction_count": 1,
                "registration_date": "2024-01-01",
            })

        # Validation #1: ValueError must include "field-level missing-field
        # details" -- assert the missing field name is referenced in the
        # error message (substring match keeps wording flexible).
        assert "filer_id" in str(ei.value), (
            f"missing field name not referenced in error: {str(ei.value)!r}"
        )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")


# Test ID: VAL-02
# Requirement: Validation #1 applied to process_return.
def test_process_return_missing_required_field_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError) as ei:
            platform.process_return({
                "filer_id": "F-1",
                # filer_category missing
                "filing_period": "2024-01",
                "line_items": [],
            })

        assert "filer_category" in str(ei.value), (
            f"missing field name not referenced in error: {str(ei.value)!r}"
        )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# Test ID: VAL-03
# Requirement: Validation #1 applied to a line item missing its declared
#   fields.
def test_process_return_line_item_missing_required_field_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError) as ei:
            platform.process_return({
                "filer_id": "F-1",
                "filer_category": "REMOTE_SELLER",
                "filing_period": "2024-01",
                "line_items": [
                    {
                        "destination_state_code": "CA",
                        # destination_local_code missing
                        "taxable_sales_usd": Decimal("1.00"),
                        "exempt_sales_usd": Decimal("0.00"),
                    }
                ],
            })

        assert "destination_local_code" in str(ei.value), (
            f"missing field name not referenced in error: {str(ei.value)!r}"
        )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# Test ID: VAL-04
# Requirement: Validation #1 applied to an audit candidate.
def test_select_audit_cases_candidate_missing_required_field_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError) as ei:
            platform.select_audit_cases(
                [
                    {
                        # filer_id missing
                        "risk_score": Decimal("0.5"),
                        "unpaid_liability_usd": Decimal("10.00"),
                        "last_return_period": "2024-01",
                    }
                ],
                target_case_count=1,
            )

        assert "filer_id" in str(ei.value), (
            f"missing field name not referenced in error: {str(ei.value)!r}"
        )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"select_audit_cases raised unexpected exception: {exc!r}")


# Test ID: VAL-05
# Requirement: Validation #1 applied to transition_audit_case.
def test_transition_audit_case_missing_required_field_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError) as ei:
            platform.transition_audit_case(
                {
                    "filer_id": "F-1",
                    # audit_status missing
                    "examiner_id": "E-1",
                    "findings_summary": "n/a",
                },
                action="BEGIN_EXAM",
            )

        assert "audit_status" in str(ei.value), (
            f"missing field name not referenced in error: {str(ei.value)!r}"
        )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"transition_audit_case raised unexpected exception: {exc!r}")


# Test ID: VAL-06
# Requirement: Validation #1 applied to build_collection_actions.
def test_build_collection_actions_missing_required_field_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError) as ei:
            platform.build_collection_actions(
                [
                    {
                        # filer_id missing
                        "unpaid_liability_usd": Decimal("10.00"),
                        "days_past_due": 1,
                    }
                ]
            )

        assert "filer_id" in str(ei.value), (
            f"missing field name not referenced in error: {str(ei.value)!r}"
        )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"build_collection_actions raised unexpected exception: {exc!r}")


# Test ID: VAL-07
# Requirement: Validation #1 applied to process_refund_claim.
def test_process_refund_claim_missing_required_field_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError) as ei:
            platform.process_refund_claim({
                "claim_id": "C-1",
                # filer_id missing
                "refund_category": "OVERPAYMENT",
                "claim_amount_usd": Decimal("10.00"),
                "outstanding_liability_usd": Decimal("0.00"),
            })

        assert "filer_id" in str(ei.value), (
            f"missing field name not referenced in error: {str(ei.value)!r}"
        )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_refund_claim raised unexpected exception: {exc!r}")


# --------------------------------------------------------------------------- #
# Enum-out-of-set tests (Validation #2)
# --------------------------------------------------------------------------- #


# Test ID: VAL-08
# Requirement: Validation #2 applied to filer_category in register_filer.
def test_register_filer_invalid_filer_category_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError):
            platform.register_filer({
                "filer_id": "F-1",
                "filer_category": "NOT_A_CATEGORY",
                "annual_gross_sales_usd": Decimal("1.00"),
                "annual_transaction_count": 1,
                "nexus_threshold_sales_usd": Decimal("1.00"),
                "nexus_threshold_transaction_count": 1,
                "registration_date": "2024-01-01",
            })
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"register_filer raised unexpected exception: {exc!r}")


# Test ID: VAL-09
# Requirement: Validation #2 applied to filer_category in process_return.
def test_process_return_invalid_filer_category_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError):
            platform.process_return({
                "filer_id": "F-1",
                "filer_category": "NOT_A_CATEGORY",
                "filing_period": "2024-01",
                "line_items": [],
            })
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_return raised unexpected exception: {exc!r}")


# Test ID: VAL-10
# Requirement: Validation #2 applied to refund_category.
def test_process_refund_claim_invalid_refund_category_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError):
            platform.process_refund_claim({
                "claim_id": "C-1",
                "filer_id": "F-1",
                "refund_category": "NOT_A_REFUND_CATEGORY",
                "claim_amount_usd": Decimal("10.00"),
                "outstanding_liability_usd": Decimal("0.00"),
            })
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"process_refund_claim raised unexpected exception: {exc!r}")


# Test ID: VAL-11
# Requirement: Validation #2 applied to audit_status in transition_audit_case.
def test_transition_audit_case_invalid_audit_status_raises():
    try:
        platform = build_platform()
        with pytest.raises(ValueError):
            platform.transition_audit_case(
                {
                    "filer_id": "F-1",
                    "audit_status": "NOT_A_STATUS",
                    "examiner_id": "E-1",
                    "findings_summary": "n/a",
                },
                action="BEGIN_EXAM",
            )
    except AssertionError:
        raise
    except Exception as exc:  # pragma: no cover
        pytest.fail(f"transition_audit_case raised unexpected exception: {exc!r}")