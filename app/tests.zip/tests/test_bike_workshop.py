"""
F2P test suite for the Community Bike Repair Workshop Management System.

Tests verify observable behavior via public API endpoints only.
"""

import re
import time

import pytest


# ---------------------------------------------------------------------------
# Seed data constants (mirrors the prompt's Seed Parts Data interface entry)
# ---------------------------------------------------------------------------

SEED_PARTS = {
    "Inner Tube":     {"stock": 20, "low_stock_threshold": 5},
    "Brake Cable":    {"stock": 3,  "low_stock_threshold": 5},
    "Chain":          {"stock": 8,  "low_stock_threshold": 3},
    "Tire Patch Kit": {"stock": 15, "low_stock_threshold": 4},
    "Gear Cable":     {"stock": 2,  "low_stock_threshold": 5},
}


# ---------------------------------------------------------------------------
# Fixture - yields None on import failure, NEVER raises
# ---------------------------------------------------------------------------

@pytest.fixture
def client(tmp_path):
    """
    Yields an isolated Flask test client backed by a fresh temporary database,
    or yields None when app.py cannot be imported.
    The fixture itself never raises so that _require() can produce FAILED
    (not ERROR) from inside each test body.

    The fixture sets app.config["DATABASE"] to a per-test temporary SQLite
    file path, then calls the app's own init_db() (if present) within an
    app_context so the app creates its schema and seed data in the test DB.
    This is the standard Flask SQLite testing pattern (see Flask docs on
    testing). Implementations must read the database path from
    app.config["DATABASE"] at request time for per-test isolation.
    """
    try:
        from app import app as flask_app
    except Exception:
        yield None
        return

    flask_app.config["TESTING"] = True
    flask_app.config["DATABASE"] = str(tmp_path / "test_workshop.db")

    with flask_app.app_context():
        try:
            from app import init_db
            init_db()
        except ImportError:
            pass

    with flask_app.test_client() as c:
        yield c


# ---------------------------------------------------------------------------
# Guard - call as FIRST LINE of every test body
# ---------------------------------------------------------------------------

def _require(client):
    """
    Raises pytest.Failed (status = FAILED, not ERROR) when the app could not
    be imported. Must be the first statement in every test function body.
    """
    if client is None:
        pytest.fail("app module could not be imported - repository is empty")


# ---------------------------------------------------------------------------
# Request helpers
# ---------------------------------------------------------------------------

def _checkin(client, name="Alice", problem="Flat tyre"):
    return client.post(
        "/checkin",
        json={"visitor_name": name, "problem_description": problem},
    )


def _claim(client, job_id, volunteer="Bob"):
    return client.post(
        f"/jobs/{job_id}/claim",
        json={"volunteer_name": volunteer},
    )


def _complete(client, job_id, work_log="Fixed it", parts_used=None):
    return client.post(
        f"/jobs/{job_id}/complete",
        json={
            "work_log": work_log,
            "parts_used": [] if parts_used is None else parts_used,
        },
    )


def _job_id(response):
    return response.get_json()["job_id"]


def _inventory_map(client):
    return {p["part_name"]: p for p in client.get("/inventory").get_json()}


def _stats(client):
    return client.get("/dashboard/stats").get_json()

# ---------------------------------------------------------------------------
# POST /checkin
# ---------------------------------------------------------------------------

class TestCheckin:

    def test_returns_201_on_valid_input(self, client):
        _require(client)
        assert _checkin(client).status_code == 201

    def test_job_id_is_integer(self, client):
        _require(client)
        assert isinstance(_job_id(_checkin(client)), int)

    def test_status_is_pending(self, client):
        _require(client)
        assert _checkin(client).get_json()["status"] == "pending"

    def test_missing_visitor_name_returns_400(self, client):
        _require(client)
        resp = client.post("/checkin", json={"problem_description": "Flat tyre"})
        assert resp.status_code == 400

    def test_empty_visitor_name_returns_400(self, client):
        _require(client)
        resp = client.post("/checkin", json={"visitor_name": "", "problem_description": "Flat tyre"})
        assert resp.status_code == 400

    def test_missing_problem_description_returns_400(self, client):
        _require(client)
        resp = client.post("/checkin", json={"visitor_name": "Alice"})
        assert resp.status_code == 400

    def test_empty_problem_description_returns_400(self, client):
        _require(client)
        resp = client.post("/checkin", json={"visitor_name": "Alice", "problem_description": ""})
        assert resp.status_code == 400

    def test_created_job_appears_in_pending_queue(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        ids = [j["job_id"] for j in client.get("/queue").get_json()]
        assert job_id in ids


# ---------------------------------------------------------------------------
# GET /queue
# ---------------------------------------------------------------------------

class TestGetQueue:

    def test_empty_list_when_no_pending_jobs(self, client):
        _require(client)
        assert client.get("/queue").get_json() == []

    def test_queue_jobs_include_submitted_visitor_and_problem(self, client):
        # Verifies that visitor_name and problem_description are stored and
        # returned correctly - fields not exercised by any other queue test.
        _require(client)
        _checkin(client, name="QueueFieldVisitor", problem="squeaky brakes")
        jobs = client.get("/queue").get_json()
        job = next((j for j in jobs if j.get("visitor_name") == "QueueFieldVisitor"), None)
        assert job is not None
        assert job["visitor_name"] == "QueueFieldVisitor"
        assert job["problem_description"] == "squeaky brakes"

    def test_only_pending_jobs_are_returned(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _checkin(client, name="Carol")
        for job in client.get("/queue").get_json():
            assert job["status"] == "pending"

    def test_completed_jobs_excluded_from_queue(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id)
        ids = [j["job_id"] for j in client.get("/queue").get_json()]
        assert job_id not in ids

    def test_jobs_ordered_by_created_at_ascending(self, client):
        # time.sleep(1.5) ensures distinct second-level timestamps so the
        # ordering assertion is non-trivial (not vacuously true on equal values).
        _require(client)
        _checkin(client, name="First")
        time.sleep(1.5)
        _checkin(client, name="Second")
        time.sleep(1.5)
        _checkin(client, name="Third")
        timestamps = [j["created_at"] for j in client.get("/queue").get_json()]
        assert len(set(timestamps)) == 3, (
            "All three created_at values must be distinct for the ordering "
            "assertion to be meaningful"
        )
        assert timestamps == sorted(timestamps)

    def test_created_at_matches_iso8601_format(self, client):
        _require(client)
        _checkin(client)
        created_at = client.get("/queue").get_json()[0]["created_at"]
        assert re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$", created_at)


# ---------------------------------------------------------------------------
# POST /jobs/{job_id}/claim
# ---------------------------------------------------------------------------

class TestClaimJob:

    def test_status_becomes_in_progress(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        resp = _claim(client, job_id)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["status"] == "in_progress"
        assert isinstance(data["job_id"], int)

    def test_claimed_job_no_longer_in_queue(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        ids = [j["job_id"] for j in client.get("/queue").get_json()]
        assert job_id not in ids

    def test_nonexistent_job_returns_404(self, client):
        _require(client)
        assert _claim(client, 99999).status_code == 404

    def test_already_in_progress_job_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        assert _claim(client, job_id).status_code == 400

    def test_completed_job_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id)
        assert _claim(client, job_id).status_code == 400

    def test_missing_volunteer_name_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        assert client.post(f"/jobs/{job_id}/claim", json={}).status_code == 400

    def test_empty_volunteer_name_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        resp = client.post(f"/jobs/{job_id}/claim", json={"volunteer_name": ""})
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# POST /jobs/{job_id}/complete
# ---------------------------------------------------------------------------

class TestCompleteJob:

    def test_status_becomes_completed(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        resp = _complete(client, job_id)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["status"] == "completed"
        assert isinstance(data["job_id"], int)

    def test_nonexistent_job_returns_404(self, client):
        _require(client)
        resp = client.post("/jobs/99999/complete", json={"work_log": "Done", "parts_used": []})
        assert resp.status_code == 404

    def test_pending_job_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        assert _complete(client, job_id).status_code == 400

    def test_already_completed_job_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id)
        assert _complete(client, job_id).status_code == 400

    def test_missing_work_log_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        resp = client.post(f"/jobs/{job_id}/complete", json={"parts_used": []})
        assert resp.status_code == 400

    def test_empty_work_log_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        resp = client.post(f"/jobs/{job_id}/complete", json={"work_log": "", "parts_used": []})
        assert resp.status_code == 400

    def test_missing_parts_used_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        resp = client.post(f"/jobs/{job_id}/complete", json={"work_log": "Fixed"})
        assert resp.status_code == 400

    def test_parts_used_not_a_list_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        resp = client.post(
            f"/jobs/{job_id}/complete",
            json={"work_log": "Fixed", "parts_used": "Inner Tube"},
        )
        assert resp.status_code == 400

    def test_zero_quantity_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        assert _complete(
            client, job_id,
            parts_used=[{"part_name": "Inner Tube", "quantity": 0}],
        ).status_code == 400

    def test_negative_quantity_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        assert _complete(
            client, job_id,
            parts_used=[{"part_name": "Inner Tube", "quantity": -1}],
        ).status_code == 400

    def test_unknown_part_name_returns_404(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        assert _complete(
            client, job_id,
            parts_used=[{"part_name": "NonExistentPart_XYZ", "quantity": 1}],
        ).status_code == 404

    def test_unknown_part_leaves_job_in_progress(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id, parts_used=[{"part_name": "NonExistentPart_XYZ", "quantity": 1}])
        assert _complete(client, job_id).status_code == 200

    def test_unknown_part_causes_no_inventory_change(self, client):
        _require(client)
        inv_before = _inventory_map(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id, parts_used=[
            {"part_name": "Inner Tube", "quantity": 1},
            {"part_name": "NonExistentPart_XYZ", "quantity": 1},
        ])
        inv_after = _inventory_map(client)
        assert inv_after["Inner Tube"]["stock"] == inv_before["Inner Tube"]["stock"]

    def test_quantity_exceeding_stock_returns_400(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        assert _complete(
            client, job_id,
            parts_used=[{"part_name": "Inner Tube", "quantity": 9999}],
        ).status_code == 400

    def test_quantity_exceeding_stock_leaves_job_in_progress(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id, parts_used=[{"part_name": "Inner Tube", "quantity": 9999}])
        assert _complete(client, job_id).status_code == 200

    def test_quantity_exceeding_stock_causes_no_inventory_change(self, client):
        _require(client)
        inv_before = _inventory_map(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id, parts_used=[{"part_name": "Inner Tube", "quantity": 9999}])
        inv_after = _inventory_map(client)
        assert inv_after["Inner Tube"]["stock"] == inv_before["Inner Tube"]["stock"]

    def test_existence_check_before_stock_check(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        resp = _complete(client, job_id, parts_used=[
            {"part_name": "Inner Tube", "quantity": 9999},
            {"part_name": "NonExistentPart_XYZ", "quantity": 1},
        ])
        assert resp.status_code == 404

    def test_empty_parts_used_completes_successfully(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        assert _complete(client, job_id, parts_used=[]).status_code == 200

    def test_stock_is_deducted_on_completion(self, client):
        _require(client)
        inv_before = _inventory_map(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id, parts_used=[{"part_name": "Inner Tube", "quantity": 3}])
        inv_after = _inventory_map(client)
        assert inv_after["Inner Tube"]["stock"] == inv_before["Inner Tube"]["stock"] - 3

    def test_multiple_parts_all_deducted(self, client):
        _require(client)
        inv_before = _inventory_map(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id, parts_used=[
            {"part_name": "Inner Tube", "quantity": 2},
            {"part_name": "Chain", "quantity": 1},
        ])
        inv_after = _inventory_map(client)
        assert inv_after["Inner Tube"]["stock"] == inv_before["Inner Tube"]["stock"] - 2
        assert inv_after["Chain"]["stock"] == inv_before["Chain"]["stock"] - 1

    def test_duplicate_part_names_each_deducted_independently(self, client):
        _require(client)
        inv_before = _inventory_map(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        resp = _complete(client, job_id, parts_used=[
            {"part_name": "Chain", "quantity": 2},
            {"part_name": "Chain", "quantity": 3},
        ])
        assert resp.status_code == 200
        inv_after = _inventory_map(client)
        assert inv_after["Chain"]["stock"] == inv_before["Chain"]["stock"] - 5
    
    def test_sequential_stock_check_for_duplicate_parts(self, client):
        _require(client)
        # Chain stock: 8. Two entries of quantity 5 each.
        # Sequential: first deducts 5 (stock becomes 3), second checks 5 > 3 → HTTP 400.
        # Parallel (wrong): both check against original 8, both pass erroneously.
        inv_before = _inventory_map(client)
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        resp = _complete(client, job_id, parts_used=[
            {"part_name": "Chain", "quantity": 5},
            {"part_name": "Chain", "quantity": 5},
        ])
        assert resp.status_code == 400
        inv_after = _inventory_map(client)
        assert inv_after["Chain"]["stock"] == inv_before["Chain"]["stock"]


# ---------------------------------------------------------------------------
# GET /dashboard/stats
# ---------------------------------------------------------------------------

class TestDashboardStats:

    def test_queue_count_reflects_all_pending_jobs(self, client):
        _require(client)
        before = _stats(client)["queue_count"]
        _checkin(client, name="Visitor1")
        _checkin(client, name="Visitor2")
        assert _stats(client)["queue_count"] == before + 2

    def test_queue_count_decreases_when_job_claimed(self, client):
        _require(client)
        job_id = _job_id(_checkin(client))
        before = _stats(client)["queue_count"]
        _claim(client, job_id)
        assert _stats(client)["queue_count"] == before - 1

    def test_completed_today_increments_on_job_completion(self, client):
        _require(client)
        before = _stats(client)["completed_today"]
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id)
        assert _stats(client)["completed_today"] == before + 1

    def test_parts_used_today_increments_by_quantity_on_completion(self, client):
        _require(client)
        before = _stats(client)["parts_used_today"]
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id, parts_used=[{"part_name": "Inner Tube", "quantity": 4}])
        assert _stats(client)["parts_used_today"] == before + 4

    def test_parts_used_today_sums_across_multiple_parts(self, client):
        _require(client)
        before = _stats(client)["parts_used_today"]
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id, parts_used=[
            {"part_name": "Inner Tube", "quantity": 2},
            {"part_name": "Chain", "quantity": 3},
        ])
        assert _stats(client)["parts_used_today"] == before + 5

    def test_parts_used_today_unchanged_when_no_parts_consumed(self, client):
        _require(client)
        before = _stats(client)["parts_used_today"]
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id, parts_used=[])
        assert _stats(client)["parts_used_today"] == before

    def test_bikes_fixed_this_month_increments_on_completion(self, client):
        _require(client)
        before = _stats(client)["bikes_fixed_this_month"]
        job_id = _job_id(_checkin(client))
        _claim(client, job_id)
        _complete(client, job_id)
        assert _stats(client)["bikes_fixed_this_month"] == before + 1


# ---------------------------------------------------------------------------
# GET /inventory
# ---------------------------------------------------------------------------

class TestGetInventory:

    def test_response_objects_contain_required_fields(self, client):
        _require(client)
        items = client.get("/inventory").get_json()
        assert len(items) > 0
        for field in ("part_id", "part_name", "stock", "low_stock_threshold", "is_low_stock"):
            assert field in items[0]

    def test_is_low_stock_true_when_stock_below_threshold(self, client):
        _require(client)
        assert _inventory_map(client)["Brake Cable"]["is_low_stock"] is True

    def test_is_low_stock_true_when_stock_equals_threshold(self, client):
        _require(client)
        client.post("/inventory/restock", json={"part_name": "Gear Cable", "quantity": 3})
        part = _inventory_map(client)["Gear Cable"]
        assert part["stock"] == part["low_stock_threshold"]
        assert part["is_low_stock"] is True

    def test_is_low_stock_false_when_stock_above_threshold(self, client):
        _require(client)
        assert _inventory_map(client)["Inner Tube"]["is_low_stock"] is False

    def test_all_five_seed_parts_are_present(self, client):
        _require(client)
        parts = client.get("/inventory").get_json()
        names = {p["part_name"] for p in parts}
        assert set(SEED_PARTS.keys()).issubset(names)
        assert len(parts) == 5

    def test_seed_parts_have_correct_initial_stock(self, client):
        _require(client)
        inv = _inventory_map(client)
        for name, values in SEED_PARTS.items():
            assert inv[name]["stock"] == values["stock"]

    def test_seed_parts_have_correct_low_stock_thresholds(self, client):
        _require(client)
        inv = _inventory_map(client)
        for name, values in SEED_PARTS.items():
            assert inv[name]["low_stock_threshold"] == values["low_stock_threshold"]


# ---------------------------------------------------------------------------
# POST /inventory/restock
# ---------------------------------------------------------------------------

class TestRestockPart:

    def test_response_contains_required_fields(self, client):
        _require(client)
        data = client.post(
            "/inventory/restock",
            json={"part_name": "Inner Tube", "quantity": 5},
        ).get_json()
        for field in ("part_id", "part_name", "stock"):
            assert field in data

    def test_stock_is_incremented_correctly(self, client):
        _require(client)
        before = _inventory_map(client)["Inner Tube"]["stock"]
        client.post("/inventory/restock", json={"part_name": "Inner Tube", "quantity": 5})
        after = _inventory_map(client)["Inner Tube"]["stock"]
        assert after == before + 5

    def test_response_reflects_updated_stock(self, client):
        _require(client)
        before = _inventory_map(client)["Inner Tube"]["stock"]
        data = client.post(
            "/inventory/restock",
            json={"part_name": "Inner Tube", "quantity": 5},
        ).get_json()
        assert data["stock"] == before + 5

    def test_missing_part_name_returns_400(self, client):
        _require(client)
        resp = client.post("/inventory/restock", json={"quantity": 5})
        assert resp.status_code == 400

    def test_empty_part_name_returns_400(self, client):
        _require(client)
        resp = client.post("/inventory/restock", json={"part_name": "", "quantity": 5})
        assert resp.status_code == 400

    def test_nonexistent_part_name_returns_404(self, client):
        _require(client)
        resp = client.post(
            "/inventory/restock",
            json={"part_name": "NonExistentPart_XYZ", "quantity": 5},
        )
        assert resp.status_code == 404

    def test_zero_quantity_returns_400(self, client):
        _require(client)
        resp = client.post("/inventory/restock", json={"part_name": "Inner Tube", "quantity": 0})
        assert resp.status_code == 400

    def test_negative_quantity_returns_400(self, client):
        _require(client)
        resp = client.post("/inventory/restock", json={"part_name": "Inner Tube", "quantity": -3})
        assert resp.status_code == 400

    def test_restock_makes_previously_low_stock_part_not_low(self, client):
        _require(client)
        client.post("/inventory/restock", json={"part_name": "Brake Cable", "quantity": 10})
        assert _inventory_map(client)["Brake Cable"]["is_low_stock"] is False