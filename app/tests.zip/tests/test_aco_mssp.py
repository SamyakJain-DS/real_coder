import os
import random
import uuid
from datetime import date, datetime, timedelta, timezone

import pytest
import requests

# ---------------------------------------------------------------------------
# Base URL - override with ACO_BASE_URL env var
# ---------------------------------------------------------------------------
BASE_URL = os.environ.get("ACO_BASE_URL", "http://localhost:5000")

# ---------------------------------------------------------------------------
# Performance-year constants (kept disjoint to prevent cross-test interference)
# ---------------------------------------------------------------------------
# Attribution + Quality tests share 2024; quality is per-provider so no clash.
ATTR_YEAR  = 2024   # service dates in 2024 are safely in the past  
QUAL_YEAR  = 2024   # per-provider isolation; OK to share with ATTR_YEAR

# CMS report tests need attributed beneficiaries -> service dates must be past.
CMS_YEAR   = 2023   # service dates "2023-xx-xx" are past as of 2026  

# State-health report counts are global (no service dates needed).
STATE_YEAR = 2088   # arbitrary; echoed in response, does not filter

# Settlement tests need no service dates -> future years are fine.
SETTLE_YEAR_BASE = 2080


# ============================================================
# Infrastructure
# ============================================================

def api(path: str) -> str:
    return f"{BASE_URL.rstrip('/')}{path}"


def safe_request(method: str, url: str, **kwargs) -> requests.Response:
    """
    Wraps requests.*; converts all connection/transport exceptions into
    pytest.fail() so tests register as FAILED (not ERROR) on an empty repo.

    pytest.fail() raises _pytest.outcomes.Failed which is a BaseException,
    NOT an Exception, so it is never silently swallowed by downstream
    except-Exception blocks.
    """
    try:
        kwargs.setdefault("timeout", 10)
        return getattr(requests, method)(url, **kwargs)
    except Exception as exc:                       # ConnectionError, Timeout, …
        pytest.fail(f"HTTP {method.upper()} {url} - {type(exc).__name__}: {exc}")


def assert_error_body(body: dict) -> None:
    """Global Error Contract: every error response must be EXACTLY { 'error': string }.
    Prompt: 'the exact shape { "error": string }' - no extra keys are permitted.
    This catches default ASP.NET Core ProblemDetails responses that add traceId, type, etc."""
    assert "error" in body, f"Expected 'error' key in response body: {body}"
    assert isinstance(body["error"], str),         f"Expected 'error' value to be a string, got: {type(body['error'])}"
    assert set(body.keys()) == {"error"},         f"Error body must contain ONLY the 'error' key; got keys: {set(body.keys())}"


# ============================================================
# Unique-value generators
# ============================================================

def unique_medicare_id() -> str:
    """Exactly 11 alphanumeric characters (satisfies the 11-char constraint)."""
    return uuid.uuid4().hex[:11].upper()


def unique_npi() -> str:
    """Exactly 10 ASCII digits (satisfies the NPI constraint)."""
    return "".join(str(random.randint(0, 9)) for _ in range(10))


def today_iso() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def future_iso(days: int = 30) -> str:
    return (date.today() + timedelta(days=days)).isoformat()


def date_in_year(year: int, month: int = 6, day: int = 15) -> str:
    """Return an ISO date string that falls inside *year*."""
    return f"{year}-{month:02d}-{day:02d}"


# ============================================================
# Entity-creation helpers (each uses safe_request internally)
# ============================================================

def create_beneficiary(**overrides) -> requests.Response:
    payload = {
        "medicareId":        unique_medicare_id(),
        "firstName":         "Test",
        "lastName":          "Patient",
        "dateOfBirth":       "1950-06-01",
        "hccRiskScore":      1.2,
        "enrollmentStartDate": "2018-01-01",
        **overrides,
    }
    return safe_request("post", api("/api/beneficiaries"), json=payload)


def create_provider(provider_type: str = "PrimaryCare", **overrides) -> requests.Response:
    payload = {
        "npi":          unique_npi(),
        "name":         "Test Provider",
        "providerType": provider_type,
        "taxId":        "111222333",
        **overrides,
    }
    return safe_request("post", api("/api/providers"), json=payload)


def create_service(
    beneficiary_id: int,
    provider_id:    int,
    service_date:   str,
    allowed_amount: float = 500.0,
) -> requests.Response:
    return safe_request("post", api("/api/services"), json={
        "beneficiaryId": beneficiary_id,
        "providerId":    provider_id,
        "serviceDate":   service_date,
        "allowedAmount": allowed_amount,
    })


def run_attribution(year: int) -> requests.Response:
    return safe_request("post", api("/api/attribution/run"),
                        json={"performanceYear": year})


def record_measure(
    provider_id:  int,
    year:         int,
    percentile:   float,
    numerator:    int   = 8,
    denominator:  int   = 10,
) -> requests.Response:
    return safe_request("post", api("/api/quality/measures"), json={
        "providerId":           provider_id,
        "measureCode":          f"M{uuid.uuid4().hex[:6].upper()}",
        "performanceYear":      year,
        "numerator":            numerator,
        "denominator":          denominator,
        "percentilePerformance": percentile,
    })


def open_episode(
    beneficiary_id: int,
    episode_type:   str = "ChronicDiseaseManagement",
    start_date:     str = None,
) -> requests.Response:
    return safe_request("post", api("/api/care-coordination/episodes"), json={
        "beneficiaryId": beneficiary_id,
        "episodeType":   episode_type,
        "startDate":     start_date or date_in_year(2024),
    })


def patch_episode(episode_id: int, target_status: str, end_date) -> requests.Response:
    return safe_request(
        "patch",
        api(f"/api/care-coordination/episodes/{episode_id}"),
        json={"targetStatus": target_status, "endDate": end_date},
    )


def create_settlement(
    provider_id:          int,
    year:                 int,
    track:                str,
    benchmark_expenditure: float,
    actual_expenditure:   float,
    final_quality_score:  float,
) -> requests.Response:
    return safe_request("post", api("/api/savings/settlement"), json={
        "performanceYear":      year,
        "providerId":           provider_id,
        "track":                track,
        "benchmarkExpenditure": benchmark_expenditure,
        "actualExpenditure":    actual_expenditure,
        "finalQualityScore":    final_quality_score,
    })


# ============================================================
# POST /api/beneficiaries
# ============================================================

class TestCreateBeneficiary:

    def test_success_201_correct_shape(self):
        mid = unique_medicare_id()
        r = create_beneficiary(medicareId=mid)
        assert r.status_code == 201
        b = r.json()
        assert isinstance(b["id"], int)
        assert b["medicareId"] == mid
        assert isinstance(b["firstName"], str)
        assert isinstance(b["lastName"], str)
        assert isinstance(b["dateOfBirth"], str)
        assert isinstance(b["hccRiskScore"], (int, float))
        assert isinstance(b["enrollmentStartDate"], str)
        assert b["enrollmentEndDate"] is None  # prompt specifies string | null; fresh create -> null

    def test_enrollment_end_date_null_on_create(self):
        r = create_beneficiary()
        assert r.status_code == 201
        assert r.json()["enrollmentEndDate"] is None


    def test_high_precision_hcc_risk_score_preserved_in_response(self):
        """M1: POST /api/beneficiaries must echo hccRiskScore back with exact value
        equality, not just the correct type. Tests that the field is not truncated,
        rounded, or altered between request and response.
        Prompt: 'preserving exact C# decimal arithmetic end-to-end'"""
        precision_score = 1.2345678901
        r = create_beneficiary(hccRiskScore=precision_score)
        assert r.status_code == 201
        assert r.json()["hccRiskScore"] == pytest.approx(precision_score, abs=1e-6)

    def test_duplicate_medicare_id_returns_409(self):
        mid = unique_medicare_id()
        assert create_beneficiary(medicareId=mid).status_code == 201
        r = create_beneficiary(medicareId=mid)
        assert r.status_code == 409
        assert_error_body(r.json())

    def test_medicare_id_too_short_returns_400(self):
        r = create_beneficiary(medicareId="ABCDE12345")   # 10 chars
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_medicare_id_too_long_returns_400(self):
        r = create_beneficiary(medicareId="ABCDE1234567")  # 12 chars
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_future_enrollment_start_date_returns_400(self):
        r = create_beneficiary(enrollmentStartDate=future_iso())
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_today_enrollment_start_date_is_valid(self):
        r = create_beneficiary(enrollmentStartDate=today_iso())
        assert r.status_code == 201

    def test_missing_required_field_returns_400(self):
        r = safe_request("post", api("/api/beneficiaries"), json={
            "firstName":         "Test",
            "lastName":          "User",
            "dateOfBirth":       "1950-01-01",
            "hccRiskScore":      1.0,
            "enrollmentStartDate": "2020-01-01",
            # medicareId intentionally omitted
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_wrong_json_type_for_field_returns_400(self):
        """Req 84: a field with the wrong JSON type (e.g. integer for a string
        property) must return HTTP 400 with the standard error body."""
        r = safe_request("post", api("/api/beneficiaries"), json={
            "medicareId":        12345678901,   # integer instead of the required string
            "firstName":         "Test",
            "lastName":          "User",
            "dateOfBirth":       "1950-01-01",
            "hccRiskScore":      1.0,
            "enrollmentStartDate": "2020-01-01",
        })
        assert r.status_code == 400
        assert_error_body(r.json())


    def test_invalid_date_format_for_date_field_returns_400(self):
        """Gap 12.1: Global Error Contract explicitly lists 'date format' as a validation
        category that must return HTTP 400.
        Prompt: 'fails a documented validation rule (including … date format …) returns HTTP 400'"""
        r = create_beneficiary(dateOfBirth="not-a-date")
        assert r.status_code == 400
        assert_error_body(r.json())


# ============================================================
# POST /api/providers
# ============================================================

class TestCreateProvider:

    def test_success_201_correct_shape(self):
        npi = unique_npi()
        r = create_provider(npi=npi)
        assert r.status_code == 201
        p = r.json()
        assert isinstance(p["id"], int)
        assert p["npi"] == npi
        assert isinstance(p["name"], str)
        assert p["providerType"] in ("PrimaryCare", "Specialist", "Hospital")
        assert isinstance(p["taxId"], str)

    def test_all_three_provider_types_accepted(self):
        for pt in ("PrimaryCare", "Specialist", "Hospital"):
            r = create_provider(provider_type=pt)
            assert r.status_code == 201
            assert r.json()["providerType"] == pt

    def test_duplicate_npi_returns_409(self):
        npi = unique_npi()
        assert create_provider(npi=npi).status_code == 201
        r = create_provider(npi=npi)
        assert r.status_code == 409
        assert_error_body(r.json())

    def test_npi_too_short_returns_400(self):
        r = create_provider(npi="12345")        # 5 digits
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_npi_too_long_returns_400(self):
        r = create_provider(npi="12345678901")  # 11 digits
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_npi_with_non_digit_character_returns_400(self):
        r = create_provider(npi="123456789A")   # letter in NPI
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_invalid_provider_type_returns_400(self):
        r = safe_request("post", api("/api/providers"), json={
            "npi":          unique_npi(),
            "name":         "Test",
            "providerType": "Dentist",           # not in allowed enum
            "taxId":        "111222333",
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_missing_required_field_returns_400(self):
        r = safe_request("post", api("/api/providers"), json={
            "name":         "Test",
            "providerType": "PrimaryCare",
            "taxId":        "111222333",
            # npi intentionally omitted
        })
        assert r.status_code == 400
        assert_error_body(r.json())


    def test_wrong_json_type_for_npi_returns_400(self):
        """Gap 1: Global Error Contract - wrong JSON type must return 400 on every endpoint."""
        r = safe_request("post", api("/api/providers"), json={
            "npi":          1234567890,   # integer instead of required string
            "name":         "Test",
            "providerType": "PrimaryCare",
            "taxId":        "111222333",
        })
        assert r.status_code == 400
        assert_error_body(r.json())


# ============================================================
# POST /api/services
# ============================================================

class TestCreateService:

    def test_success_201_correct_shape(self):
        b = create_beneficiary()
        p = create_provider()
        assert b.status_code == 201 and p.status_code == 201
        r = create_service(b.json()["id"], p.json()["id"], date_in_year(2024))
        assert r.status_code == 201
        s = r.json()
        assert isinstance(s["id"], int)
        assert s["beneficiaryId"] == b.json()["id"]
        assert s["providerId"]    == p.json()["id"]
        assert isinstance(s["serviceDate"],    str)
        assert isinstance(s["allowedAmount"],  (int, float))

    def test_nonexistent_beneficiary_returns_404(self):
        p = create_provider()
        assert p.status_code == 201
        r = create_service(99999999, p.json()["id"], date_in_year(2024))
        assert r.status_code == 404
        assert_error_body(r.json())

    def test_nonexistent_provider_returns_404(self):
        b = create_beneficiary()
        assert b.status_code == 201
        r = create_service(b.json()["id"], 99999999, date_in_year(2024))
        assert r.status_code == 404
        assert_error_body(r.json())

    def test_negative_allowed_amount_returns_400(self):
        b = create_beneficiary()
        p = create_provider()
        assert b.status_code == 201 and p.status_code == 201
        r = create_service(b.json()["id"], p.json()["id"],
                           date_in_year(2024), allowed_amount=-1.0)
        assert r.status_code == 400
        assert_error_body(r.json())



    def test_high_precision_allowed_amount_preserved_in_response(self):
        """M1: POST /api/services must echo allowedAmount back with exact value
        equality. Tests monetary decimal preservation end-to-end.
        Prompt: 'preserving exact C# decimal arithmetic end-to-end'"""
        b = create_beneficiary()
        p = create_provider()
        assert b.status_code == 201 and p.status_code == 201
        precision_amount = 123.456789
        r = create_service(b.json()["id"], p.json()["id"],
                           date_in_year(2024), allowed_amount=precision_amount)
        assert r.status_code == 201
        assert r.json()["allowedAmount"] == precision_amount

    def test_today_service_date_is_valid(self):
        """Req #2: Prompt: 'HTTP 400 if serviceDate is after the server clock date (UTC)'.
        Strict 'after': serviceDate == today must be accepted (HTTP 201).
        The analogous enrollmentStartDate rule has test_today_enrollment_start_date_is_valid;
        serviceDate deserves the symmetric positive boundary test."""
        b = create_beneficiary()
        p = create_provider()
        assert b.status_code == 201 and p.status_code == 201
        r = create_service(b.json()["id"], p.json()["id"], today_iso())
        assert r.status_code == 201

    def test_future_service_date_returns_400(self):
        b = create_beneficiary()
        p = create_provider()
        assert b.status_code == 201 and p.status_code == 201
        r = create_service(b.json()["id"], p.json()["id"], future_iso())
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_missing_required_field_returns_400(self):
        b = create_beneficiary()
        p = create_provider()
        assert b.status_code == 201 and p.status_code == 201
        r = safe_request("post", api("/api/services"), json={
            "beneficiaryId": b.json()["id"],
            "providerId":    p.json()["id"],
            "serviceDate":   date_in_year(2024),
            # allowedAmount intentionally omitted
        })
        assert r.status_code == 400
        assert_error_body(r.json())


    def test_wrong_json_type_for_field_returns_400(self):
        """Gap 1: Global Error Contract - wrong JSON type must return 400 on every endpoint."""
        b = create_beneficiary()
        p = create_provider()
        assert b.status_code == 201 and p.status_code == 201
        r = safe_request("post", api("/api/services"), json={
            "beneficiaryId": b.json()["id"],
            "providerId":    p.json()["id"],
            "serviceDate":   date_in_year(2024),
            "allowedAmount": "five hundred",   # string instead of required number
        })
        assert r.status_code == 400
        assert_error_body(r.json())


    def test_invalid_date_format_for_service_date_returns_400(self):
        """Gap 12.1: Global Error Contract - malformed serviceDate string must return 400."""
        b = create_beneficiary()
        p = create_provider()
        assert b.status_code == 201 and p.status_code == 201
        r = safe_request("post", api("/api/services"), json={
            "beneficiaryId": b.json()["id"],
            "providerId":    p.json()["id"],
            "serviceDate":   "not-a-date",
            "allowedAmount": 500.0,
        })
        assert r.status_code == 400
        assert_error_body(r.json())


# ============================================================
# POST /api/attribution/run  +  GET /api/attribution/{beneficiaryId}
# ============================================================

class TestAttribution:

    # -- Run endpoint ------------------------------------------

    def test_run_returns_200_with_correct_shape(self):
        r = run_attribution(ATTR_YEAR)
        assert r.status_code == 200
        body = r.json()
        assert body["performanceYear"] == ATTR_YEAR
        assert isinstance(body["step1Count"],       int) and body["step1Count"]       >= 0
        assert isinstance(body["step2Count"],       int) and body["step2Count"]       >= 0
        assert isinstance(body["unassignedCount"],  int) and body["unassignedCount"]  >= 0


    def test_pcp_service_with_zero_allowed_amount_does_not_trigger_step1(self):
        """Gap #5: Prompt: 'If the total is greater than zero, assign …'
        allowedAmount=0 is not rejected by validation (only negatives are), but
        a sum of zero is NOT greater than zero - Step 1 must NOT fire.
        The beneficiary must fall through to Step 2 / Unassigned."""
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid = b.json()["id"]
        # Legal allowedAmount=0 - passes POST /api/services validation
        create_service(bid, pc.json()["id"], date_in_year(ATTR_YEAR), allowed_amount=0.0)
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignmentStep"]     == "Unassigned"
        assert r.json()["assignedProviderId"] is None


    def test_specialist_service_with_zero_allowed_amount_does_not_trigger_step2(self):
        """Req #2: Prompt: 'repeat the same selection over providers with ProviderType=Specialist'.
        'The same selection' inherits the 'total greater than zero' precondition from Step 1.
        A Specialist service with allowedAmount=0 gives total=0, which is NOT > 0,
        so Step 2 must NOT fire - the beneficiary must be Unassigned."""
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        sp = create_provider(provider_type="Specialist")
        assert b.status_code == 201 and sp.status_code == 201
        bid = b.json()["id"]
        create_service(bid, sp.json()["id"], date_in_year(ATTR_YEAR), allowed_amount=0.0)
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignmentStep"]     == "Unassigned"
        assert r.json()["assignedProviderId"] is None

    def test_year_below_2012_returns_400(self):
        r = run_attribution(2011)
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_year_above_2100_returns_400(self):
        r = run_attribution(2101)
        assert r.status_code == 400
        assert_error_body(r.json())

    # -- Step-1 PCP assignment ---------------------------------

    def test_step1_pcp_assigned_when_pcp_service_exists(self):
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid, pcid = b.json()["id"], pc.json()["id"]
        create_service(bid, pcid, date_in_year(ATTR_YEAR))
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        body = r.json()
        assert body["assignedProviderId"] == pcid
        assert body["assignmentStep"]     == "Step1Pcp"

    # -- Step-2 Specialist assignment --------------------------

    def test_step2_specialist_assigned_when_no_pcp_services(self):
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        sp = create_provider(provider_type="Specialist")
        assert b.status_code == 201 and sp.status_code == 201
        bid, spid = b.json()["id"], sp.json()["id"]
        create_service(bid, spid, date_in_year(ATTR_YEAR))
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        body = r.json()
        assert body["assignedProviderId"] == spid
        assert body["assignmentStep"]     == "Step2Specialist"

    def test_step2_plurality_selects_specialist_with_highest_allowed_amount_sum(self):
        """
        Req A (part 1): Step 2 uses the same plurality rule as Step 1 - the Specialist
        with the highest total AllowedAmount sum is selected when no PCP services exist.
        Prompt: 'Step 2: ... repeat the same selection over providers with
        ProviderType = Specialist.'
        """
        b   = create_beneficiary(enrollmentStartDate="2020-01-01")
        sp1 = create_provider(provider_type="Specialist")
        sp2 = create_provider(provider_type="Specialist")
        assert b.status_code == 201 and sp1.status_code == 201 and sp2.status_code == 201
        bid, spid1, spid2 = b.json()["id"], sp1.json()["id"], sp2.json()["id"]
        create_service(bid, spid1, date_in_year(ATTR_YEAR, month=3), allowed_amount=200.0)
        create_service(bid, spid2, date_in_year(ATTR_YEAR, month=6), allowed_amount=800.0)
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignedProviderId"] == spid2   # higher sum wins
        assert r.json()["assignmentStep"]     == "Step2Specialist"

    def test_step2_tiebreak_most_recent_service_date_wins(self):
        """
        Req A (part 2): When two Specialists have equal AllowedAmount sums, Step 2
        assigns to the one with the most recent ServiceDate - same tiebreak as Step 1.
        Prompt: 'repeat the same selection over providers with ProviderType = Specialist'
        """
        b   = create_beneficiary(enrollmentStartDate="2020-01-01")
        sp1 = create_provider(provider_type="Specialist")
        sp2 = create_provider(provider_type="Specialist")
        assert b.status_code == 201 and sp1.status_code == 201 and sp2.status_code == 201
        bid, spid1, spid2 = b.json()["id"], sp1.json()["id"], sp2.json()["id"]
        # Equal amounts; sp2 has the more recent service date
        create_service(bid, spid1, date_in_year(ATTR_YEAR, month=3), allowed_amount=300.0)
        create_service(bid, spid2, date_in_year(ATTR_YEAR, month=9), allowed_amount=300.0)
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignedProviderId"] == spid2   # most recent date wins
        assert r.json()["assignmentStep"]     == "Step2Specialist"

    def test_step2_tiebreak_lowest_provider_id_wins_when_date_also_tied(self):
        """
        Req A (part 3): When two Specialists have equal sums AND equal most-recent
        ServiceDate, Step 2 assigns to the lowest ProviderId - same final tiebreak
        as Step 1.
        Prompt: 'repeat the same selection over providers with ProviderType = Specialist'
        """
        b   = create_beneficiary(enrollmentStartDate="2020-01-01")
        sp1 = create_provider(provider_type="Specialist")   # created first -> lower ID
        sp2 = create_provider(provider_type="Specialist")
        assert b.status_code == 201 and sp1.status_code == 201 and sp2.status_code == 201
        bid, spid1, spid2 = b.json()["id"], sp1.json()["id"], sp2.json()["id"]
        same_date = date_in_year(ATTR_YEAR, month=6)
        create_service(bid, spid1, same_date, allowed_amount=300.0)
        create_service(bid, spid2, same_date, allowed_amount=300.0)
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignedProviderId"] == spid1   # lowest ProviderId wins
        assert r.json()["assignmentStep"]     == "Step2Specialist"

    # -- Unassigned --------------------------------------------

    def test_unassigned_when_no_in_year_services(self):
        b = create_beneficiary(enrollmentStartDate="2020-01-01")
        assert b.status_code == 201
        bid = b.json()["id"]
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        body = r.json()
        assert body["assignedProviderId"] is None
        assert body["assignmentStep"]     == "Unassigned"

    # -- Enrollment boundary -----------------------------------

    def test_beneficiary_not_enrolled_in_year_not_attributed(self):
        # enrollmentStartDate is after the performance year -> not enrolled
        b = create_beneficiary(enrollmentStartDate=f"{ATTR_YEAR + 2}-01-01")
        assert b.status_code == 201
        bid = b.json()["id"]
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 404

    def test_enrollment_start_date_dec31_of_year_is_inclusive_boundary(self):
        """
        Req B: EnrollmentStartDate = December 31 of the performance year is the
        inclusive boundary - the beneficiary IS enrolled and IS attributed.
        Prompt: 'EnrollmentStartDate <= December 31 of performanceYear'
        """
        b  = create_beneficiary(enrollmentStartDate=f"{ATTR_YEAR}-12-31")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid, pcid = b.json()["id"], pc.json()["id"]
        create_service(bid, pcid, date_in_year(ATTR_YEAR))
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignedProviderId"] == pcid
        assert r.json()["assignmentStep"]     == "Step1Pcp"

    # -- Services outside the performance year not counted -----

    def test_out_of_year_services_produce_unassigned(self):
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid, pcid = b.json()["id"], pc.json()["id"]
        # Service is one year before the performance year
        create_service(bid, pcid, date_in_year(ATTR_YEAR - 1))
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignmentStep"] == "Unassigned"

    # -- PCP priority over Specialist --------------------------

    def test_pcp_takes_priority_over_specialist_regardless_of_amount(self):
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        sp = create_provider(provider_type="Specialist")
        assert b.status_code == 201 and pc.status_code == 201 and sp.status_code == 201
        bid, pcid, spid = b.json()["id"], pc.json()["id"], sp.json()["id"]
        # PCP has lower amount but must still win Step 1
        create_service(bid, pcid, date_in_year(ATTR_YEAR, month=3), allowed_amount=100.0)
        create_service(bid, spid, date_in_year(ATTR_YEAR, month=6), allowed_amount=900.0)
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignedProviderId"] == pcid
        assert r.json()["assignmentStep"]     == "Step1Pcp"

    # -- Plurality: highest allowed-amount sum wins ------------

    def test_plurality_selects_pcp_with_highest_allowed_amount_sum(self):
        b   = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc1 = create_provider(provider_type="PrimaryCare")
        pc2 = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc1.status_code == 201 and pc2.status_code == 201
        bid, pcid1, pcid2 = b.json()["id"], pc1.json()["id"], pc2.json()["id"]
        create_service(bid, pcid1, date_in_year(ATTR_YEAR, month=3), allowed_amount=200.0)
        create_service(bid, pcid2, date_in_year(ATTR_YEAR, month=6), allowed_amount=800.0)
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignedProviderId"] == pcid2  # higher sum wins

    def test_tiebreak_most_recent_service_date_wins(self):
        """
        Req 26 (part 1): when two PrimaryCare providers have equal AllowedAmount
        sums, the beneficiary is assigned to the one with the most recent ServiceDate.
        """
        b   = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc1 = create_provider(provider_type="PrimaryCare")
        pc2 = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc1.status_code == 201 and pc2.status_code == 201
        bid, pcid1, pcid2 = b.json()["id"], pc1.json()["id"], pc2.json()["id"]
        # Identical amounts; pc2 has the more recent service date
        create_service(bid, pcid1, date_in_year(ATTR_YEAR, month=3), allowed_amount=300.0)
        create_service(bid, pcid2, date_in_year(ATTR_YEAR, month=9), allowed_amount=300.0)
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignedProviderId"] == pcid2  # most recent date wins

    def test_tiebreak_lowest_provider_id_wins_when_date_also_tied(self):
        """
        Req 26 (part 2): when two PrimaryCare providers have equal AllowedAmount
        sums AND equal most-recent ServiceDates, the one with the lowest ProviderId
        is selected.
        """
        b   = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc1 = create_provider(provider_type="PrimaryCare")
        pc2 = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc1.status_code == 201 and pc2.status_code == 201
        bid, pcid1, pcid2 = b.json()["id"], pc1.json()["id"], pc2.json()["id"]
        # pc1 was created before pc2, so pcid1 < pcid2 (auto-increment)
        same_date = date_in_year(ATTR_YEAR, month=6)
        create_service(bid, pcid1, same_date, allowed_amount=300.0)
        create_service(bid, pcid2, same_date, allowed_amount=300.0)
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignedProviderId"] == pcid1  # lowest ProviderId wins

    # -- Idempotency -------------------------------------------

    def test_run_is_idempotent(self):
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid, pcid = b.json()["id"], pc.json()["id"]
        create_service(bid, pcid, date_in_year(ATTR_YEAR))
        run_attribution(ATTR_YEAR)
        r1 = safe_request("get", api(f"/api/attribution/{bid}"),
                          params={"performanceYear": ATTR_YEAR})
        run_attribution(ATTR_YEAR)
        r2 = safe_request("get", api(f"/api/attribution/{bid}"),
                          params={"performanceYear": ATTR_YEAR})
        assert r1.status_code == 200 and r2.status_code == 200
        assert r1.json()["assignedProviderId"] == r2.json()["assignedProviderId"]
        assert r1.json()["assignmentStep"]     == r2.json()["assignmentStep"]

    # -- Re-run replaces prior rows (does not append) ----------

    def test_rerun_replaces_prior_rows_not_appends(self):
        """
        After one PCP-attributed beneficiary is run, adding a second and re-running
        should increase step1Count by exactly 1.  If rows were appended instead of
        replaced the increment would be larger than 1.
        """
        b1 = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b1.status_code == 201 and pc.status_code == 201
        create_service(b1.json()["id"], pc.json()["id"], date_in_year(ATTR_YEAR))
        r1 = run_attribution(ATTR_YEAR)
        assert r1.status_code == 200
        count_before = r1.json()["step1Count"]

        b2 = create_beneficiary(enrollmentStartDate="2020-01-01")
        assert b2.status_code == 201
        create_service(b2.json()["id"], pc.json()["id"], date_in_year(ATTR_YEAR))
        r2 = run_attribution(ATTR_YEAR)
        assert r2.status_code == 200
        assert r2.json()["step1Count"] == count_before + 1

    # -- GET endpoint ------------------------------------------

    def test_get_attribution_response_shape(self):
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid, pcid = b.json()["id"], pc.json()["id"]
        create_service(bid, pcid, date_in_year(ATTR_YEAR))
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        body = r.json()
        assert body["beneficiaryId"]   == bid
        assert body["performanceYear"] == ATTR_YEAR
        assert "assignedProviderId" in body
        assert body["assignedProviderId"] is None or isinstance(body["assignedProviderId"], int)
        assert body["assignmentStep"] in ("Step1Pcp", "Step2Specialist", "Unassigned")

    def test_get_attribution_not_found_returns_404(self):
        r = safe_request("get", api("/api/attribution/99999999"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 404
        assert_error_body(r.json())


    def test_wrong_json_type_for_performance_year_returns_400(self):
        """Gap 1: Global Error Contract - wrong JSON type on /api/attribution/run."""
        r = safe_request("post", api("/api/attribution/run"), json={
            "performanceYear": "2024",   # string instead of required number
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_missing_performance_year_returns_400(self):
        """Gap 2: Global Error Contract - missing required field on /api/attribution/run."""
        r = safe_request("post", api("/api/attribution/run"), json={})
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_year_2012_is_valid_lower_boundary(self):
        """Gap 4: performanceYear=2012 must be accepted (< 2012 returns 400, not ≤ 2012)."""
        r = run_attribution(2012)
        assert r.status_code == 200

    def test_year_2100_is_valid_upper_boundary(self):
        """Gap 4: performanceYear=2100 must be accepted (> 2100 returns 400, not ≥ 2100)."""
        r = run_attribution(2100)
        assert r.status_code == 200

    def test_service_on_jan1_of_performance_year_is_counted(self):
        """Gap 5: Prompt: 'ServiceDate falls inside the performance year (January 1 ... inclusive)'.
        A service dated exactly January 1 of the year must be counted in Step 1."""
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid, pcid = b.json()["id"], pc.json()["id"]
        create_service(bid, pcid, f"{ATTR_YEAR}-01-01")   # exactly Jan 1
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignmentStep"] == "Step1Pcp"

    def test_service_on_dec31_of_performance_year_is_counted(self):
        """Gap 5: Prompt: 'ServiceDate falls inside the performance year (... December 31 inclusive)'.
        A service dated exactly December 31 of the year must be counted in Step 1."""
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid, pcid = b.json()["id"], pc.json()["id"]
        create_service(bid, pcid, f"{ATTR_YEAR}-12-31")   # exactly Dec 31
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignmentStep"] == "Step1Pcp"

    def test_service_on_jan1_of_next_year_is_not_counted(self):
        """Gap 5: A service dated January 1 of the year AFTER the performance year must
        NOT be counted - the range is closed at December 31 of performanceYear."""
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid, pcid = b.json()["id"], pc.json()["id"]
        create_service(bid, pcid, f"{ATTR_YEAR + 1}-01-01")   # Jan 1 of FOLLOWING year
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignmentStep"] == "Unassigned"


    def test_hospital_provider_services_excluded_from_attribution(self):
        """Gap 11.1: Hospital is not PrimaryCare (Step 1) nor Specialist (Step 2).
        A beneficiary whose only in-year services come from a Hospital provider must be Unassigned.
        Prompt: 'Step 1: … providers with ProviderType = PrimaryCare'
                'Step 2: … providers with ProviderType = Specialist'"""
        b = create_beneficiary(enrollmentStartDate="2020-01-01")
        h = create_provider(provider_type="Hospital")
        assert b.status_code == 201 and h.status_code == 201
        bid = b.json()["id"]
        create_service(bid, h.json()["id"], date_in_year(ATTR_YEAR))
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 200
        assert r.json()["assignedProviderId"] is None
        assert r.json()["assignmentStep"] == "Unassigned"

    def test_rerun_for_one_year_preserves_other_year_records(self):
        """Gap 11.3: Prompt: 'replace any prior attribution rows for the same performanceYear'.
        'For the same performanceYear' means rows for OTHER years must not be touched.
        """
        YEAR_A = ATTR_YEAR    # 2024
        YEAR_B = 2022         # a different past year; no other test uses 2022 for attribution
        b  = create_beneficiary(enrollmentStartDate="2020-01-01")
        pc = create_provider(provider_type="PrimaryCare")
        assert b.status_code == 201 and pc.status_code == 201
        bid, pcid = b.json()["id"], pc.json()["id"]
        create_service(bid, pcid, date_in_year(YEAR_A))
        create_service(bid, pcid, f"{YEAR_B}-06-15")
        run_attribution(YEAR_A)   # writes record for YEAR_A
        run_attribution(YEAR_B)   # writes record for YEAR_B
        run_attribution(YEAR_A)   # re-runs YEAR_A - must NOT delete YEAR_B record
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": YEAR_B})
        assert r.status_code == 200          # YEAR_B record still exists
        assert r.json()["assignmentStep"] == "Step1Pcp"

    def test_enrollment_start_date_jan1_of_next_year_is_not_enrolled(self):
        """Gap 12.7: January 1 of (performanceYear + 1) is the exact exclusive boundary.
        Prompt: 'EnrollmentStartDate <= December 31 of performanceYear'
        2025-01-01 > 2024-12-31, so the beneficiary must NOT be attributed in 2024."""
        b = create_beneficiary(enrollmentStartDate=f"{ATTR_YEAR + 1}-01-01")
        assert b.status_code == 201
        bid = b.json()["id"]
        run_attribution(ATTR_YEAR)
        r = safe_request("get", api(f"/api/attribution/{bid}"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 404   # not enrolled -> no record


    def test_non_integer_beneficiary_id_in_route_returns_404(self):
        """Gap #4: Prompt specifies [HttpGet("{beneficiaryId:int}")].
        With the :int constraint, a non-numeric path segment does not match the route
        and must return HTTP 404 (route mismatch), not 400 (model binding failure)."""
        r = safe_request("get", api("/api/attribution/abc"),
                         params={"performanceYear": ATTR_YEAR})
        assert r.status_code == 404


# ============================================================
# POST /api/quality/measures  +  GET /api/quality/score/{providerId}
# ============================================================

class TestQuality:

    # -- POST /api/quality/measures ----------------------------

    def test_record_measure_success_201_correct_shape(self):
        p = create_provider()
        assert p.status_code == 201
        pid = p.json()["id"]
        r = record_measure(pid, QUAL_YEAR, percentile=0.75)
        assert r.status_code == 201
        body = r.json()
        assert isinstance(body["id"],                  int)
        assert body["providerId"]                     == pid
        assert isinstance(body["measureCode"],         str)
        assert body["performanceYear"]                == QUAL_YEAR
        assert isinstance(body["numerator"],           int)
        assert isinstance(body["denominator"],         int)
        assert isinstance(body["percentilePerformance"], (int, float))

    def test_record_measure_nonexistent_provider_returns_404(self):
        r = record_measure(99999999, QUAL_YEAR, percentile=0.5)
        assert r.status_code == 404
        assert_error_body(r.json())

    def test_record_measure_zero_denominator_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/quality/measures"), json={
            "providerId": p.json()["id"], "measureCode": "M001",
            "performanceYear": QUAL_YEAR,
            "numerator": 0, "denominator": 0,
            "percentilePerformance": 0.5,
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_record_measure_negative_denominator_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/quality/measures"), json={
            "providerId": p.json()["id"], "measureCode": "M001",
            "performanceYear": QUAL_YEAR,
            "numerator": 5, "denominator": -1,
            "percentilePerformance": 0.5,
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_record_measure_negative_numerator_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/quality/measures"), json={
            "providerId": p.json()["id"], "measureCode": "M001",
            "performanceYear": QUAL_YEAR,
            "numerator": -1, "denominator": 10,
            "percentilePerformance": 0.5,
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_record_measure_numerator_exceeds_denominator_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/quality/measures"), json={
            "providerId": p.json()["id"], "measureCode": "M001",
            "performanceYear": QUAL_YEAR,
            "numerator": 11, "denominator": 10,
            "percentilePerformance": 0.5,
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_record_measure_percentile_below_zero_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/quality/measures"), json={
            "providerId": p.json()["id"], "measureCode": "M001",
            "performanceYear": QUAL_YEAR,
            "numerator": 5, "denominator": 10,
            "percentilePerformance": -0.01,
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_record_measure_percentile_above_one_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/quality/measures"), json={
            "providerId": p.json()["id"], "measureCode": "M001",
            "performanceYear": QUAL_YEAR,
            "numerator": 5, "denominator": 10,
            "percentilePerformance": 1.01,
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    # -- GET /api/quality/score/{providerId} -------------------

    def test_quality_score_is_unweighted_mean_rounded_to_4dp(self):
        p = create_provider()
        assert p.status_code == 201
        pid = p.json()["id"]
        record_measure(pid, QUAL_YEAR, percentile=0.8)
        record_measure(pid, QUAL_YEAR, percentile=0.4)
        # mean = (0.8 + 0.4) / 2 = 0.6000
        r = safe_request("get", api(f"/api/quality/score/{pid}"),
                         params={"performanceYear": QUAL_YEAR})
        assert r.status_code == 200
        body = r.json()
        assert body["providerId"]     == pid
        assert body["performanceYear"] == QUAL_YEAR
        assert body["qualityScore"]   == pytest.approx(0.6, abs=1e-4)
        assert body["measureCount"]   == 2

    def test_quality_score_rounded_to_exactly_4_decimal_places(self):
        """
        mean of (1.0 + 0.0 + 0.0) / 3 = 1/3 ≈ 0.3333 when rounded to 4 d.p.
        """
        p = create_provider()
        assert p.status_code == 201
        pid = p.json()["id"]
        record_measure(pid, QUAL_YEAR, percentile=1.0, numerator=10, denominator=10)
        record_measure(pid, QUAL_YEAR, percentile=0.0, numerator=0,  denominator=10)
        record_measure(pid, QUAL_YEAR, percentile=0.0, numerator=0,  denominator=10)
        r = safe_request("get", api(f"/api/quality/score/{pid}"),
                         params={"performanceYear": QUAL_YEAR})
        assert r.status_code == 200
        score = r.json()["qualityScore"]
        expected_4dp = round(1 / 3, 4)          # = 0.3333
        assert score == pytest.approx(expected_4dp, abs=1e-5)

    def test_quality_score_zero_and_count_zero_when_no_measures(self):
        p = create_provider()
        assert p.status_code == 201
        pid = p.json()["id"]
        r = safe_request("get", api(f"/api/quality/score/{pid}"),
                         params={"performanceYear": QUAL_YEAR})
        assert r.status_code == 200
        body = r.json()
        assert body["qualityScore"]  == 0.0
        assert body["measureCount"]  == 0

    def test_quality_score_nonexistent_provider_returns_404(self):
        r = safe_request("get", api("/api/quality/score/99999999"),
                         params={"performanceYear": QUAL_YEAR})
        assert r.status_code == 404
        assert_error_body(r.json())

    def test_quality_score_measure_count_correct(self):
        p = create_provider()
        assert p.status_code == 201
        pid = p.json()["id"]
        record_measure(pid, QUAL_YEAR, percentile=0.5)
        record_measure(pid, QUAL_YEAR, percentile=0.7)
        record_measure(pid, QUAL_YEAR, percentile=0.3)
        r = safe_request("get", api(f"/api/quality/score/{pid}"),
                         params={"performanceYear": QUAL_YEAR})
        assert r.status_code == 200
        assert r.json()["measureCount"] == 3

    def test_quality_score_scoped_to_requested_performance_year(self):
        """Measures from a different year must not pollute the score."""
        p = create_provider()
        assert p.status_code == 201
        pid = p.json()["id"]
        record_measure(pid, QUAL_YEAR,     percentile=0.9)
        record_measure(pid, QUAL_YEAR + 1, percentile=0.1)   # different year
        r = safe_request("get", api(f"/api/quality/score/{pid}"),
                         params={"performanceYear": QUAL_YEAR})
        assert r.status_code == 200
        body = r.json()
        assert body["measureCount"] == 1
        assert body["qualityScore"] == pytest.approx(0.9, abs=1e-4)


    def test_wrong_json_type_for_field_returns_400(self):
        """Gap 1: Global Error Contract - wrong JSON type on /api/quality/measures."""
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/quality/measures"), json={
            "providerId":            p.json()["id"],
            "measureCode":           "M001",
            "performanceYear":       QUAL_YEAR,
            "numerator":             5,
            "denominator":           "ten",   # string instead of required number
            "percentilePerformance": 0.5,
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_missing_required_field_returns_400(self):
        """Gap 2: Global Error Contract - missing required field on /api/quality/measures."""
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/quality/measures"), json={
            "providerId":            p.json()["id"],
            "performanceYear":       QUAL_YEAR,
            "numerator":             5,
            "denominator":           10,
            "percentilePerformance": 0.5,
            # measureCode intentionally omitted
        })
        assert r.status_code == 400
        assert_error_body(r.json())



    def test_numerator_equal_to_denominator_is_accepted(self):
        """Req #3: Prompt: 'HTTP 400 if numerator is … greater than denominator'.
        Strict '>': numerator == denominator must be accepted (HTTP 201).
        The > case is covered; this covers the inclusive boundary numerator == denominator."""
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/quality/measures"), json={
            "providerId":            p.json()["id"],
            "measureCode":           "M_EQ",
            "performanceYear":       QUAL_YEAR,
            "numerator":             10,
            "denominator":           10,
            "percentilePerformance": 1.0,
        })
        assert r.status_code == 201

    def test_percentile_performance_zero_is_accepted(self):
        """Gap 11.5: percentilePerformance=0.0 is the inclusive lower bound and must be accepted.
        Prompt: 'HTTP 400 if … percentilePerformance is outside [0.0, 1.0]'"""
        p = create_provider()
        assert p.status_code == 201
        r = record_measure(p.json()["id"], QUAL_YEAR, percentile=0.0,
                           numerator=0, denominator=10)
        assert r.status_code == 201

    def test_percentile_performance_one_is_accepted(self):
        """Gap 11.5: percentilePerformance=1.0 is the inclusive upper bound and must be accepted."""
        p = create_provider()
        assert p.status_code == 201
        r = record_measure(p.json()["id"], QUAL_YEAR, percentile=1.0,
                           numerator=10, denominator=10)
        assert r.status_code == 201



    def test_high_precision_percentile_performance_preserved_in_response(self):
        """Gap #9: Prompt: 'preserving exact C# decimal arithmetic end-to-end.'
        PercentilePerformance is a ratio decimal property and must round-trip exactly.
        A REAL (double) SQLite column would lose precision; TEXT must be used."""
        precision_percentile = 0.1234567891
        p = create_provider()
        assert p.status_code == 201
        r = record_measure(p.json()["id"], QUAL_YEAR, percentile=precision_percentile,
                           numerator=1, denominator=10)
        assert r.status_code == 201
        assert r.json()["percentilePerformance"] == pytest.approx(precision_percentile, abs=1e-6)

    def test_non_integer_provider_id_in_route_returns_404(self):
        """Gap #4: Prompt specifies [HttpGet("score/{providerId:int}")].
        With the :int constraint, a non-numeric path segment must return HTTP 404."""
        r = safe_request("get", api("/api/quality/score/abc"),
                         params={"performanceYear": QUAL_YEAR})
        assert r.status_code == 404


# ============================================================
# POST /api/care-coordination/episodes
# PATCH /api/care-coordination/episodes/{id}
# ============================================================

class TestCareCoordination:

    # -- POST (open episode) -----------------------------------

    def test_open_episode_success_201_correct_shape(self):
        b = create_beneficiary()
        assert b.status_code == 201
        bid = b.json()["id"]
        r = open_episode(bid, "ChronicDiseaseManagement")
        assert r.status_code == 201
        body = r.json()
        assert isinstance(body["id"],          int)
        assert body["beneficiaryId"]          == bid
        assert body["episodeType"]            == "ChronicDiseaseManagement"
        assert isinstance(body["startDate"],  str)
        assert body["endDate"]                is None
        assert body["status"]                 == "Open"

    def test_open_episode_status_open_end_date_null_on_create(self):
        b = create_beneficiary()
        assert b.status_code == 201
        r = open_episode(b.json()["id"], "PostAcuteTransition")
        assert r.status_code == 201
        assert r.json()["status"]  == "Open"
        assert r.json()["endDate"] is None

    def test_open_episode_nonexistent_beneficiary_returns_404(self):
        r = open_episode(99999999)
        assert r.status_code == 404
        assert_error_body(r.json())

    def test_open_duplicate_same_type_returns_409(self):
        b = create_beneficiary()
        assert b.status_code == 201
        bid = b.json()["id"]
        assert open_episode(bid, "ChronicDiseaseManagement").status_code == 201
        r = open_episode(bid, "ChronicDiseaseManagement")
        assert r.status_code == 409
        assert_error_body(r.json())

    def test_open_two_different_episode_types_both_allowed(self):
        b = create_beneficiary()
        assert b.status_code == 201
        bid = b.json()["id"]
        r1 = open_episode(bid, "ChronicDiseaseManagement")
        r2 = open_episode(bid, "PostAcuteTransition")
        assert r1.status_code == 201
        assert r2.status_code == 201

    # -- PATCH (update episode) --------------------------------


    def test_open_duplicate_post_acute_transition_episode_returns_409(self):
        """Obs #2: The duplicate-open 409 rule is defined for 'a given EpisodeType',
        so it must apply symmetrically to PostAcuteTransition as well as
        ChronicDiseaseManagement. Only CDM is exercised by the existing 409 test."""
        b = create_beneficiary()
        assert b.status_code == 201
        bid = b.json()["id"]
        assert open_episode(bid, "PostAcuteTransition").status_code == 201
        r = open_episode(bid, "PostAcuteTransition")
        assert r.status_code == 409
        assert_error_body(r.json())

    def test_update_open_to_closed_with_valid_end_date(self):
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-01-01")
        assert e.status_code == 201
        r = patch_episode(e.json()["id"], "Closed", "2024-06-01")
        assert r.status_code == 200
        body = r.json()
        assert body["status"]  == "Closed"
        assert body["endDate"] == "2024-06-01"

    def test_update_open_to_escalated_with_null_end_date(self):
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement")
        assert e.status_code == 201
        r = patch_episode(e.json()["id"], "Escalated", None)
        assert r.status_code == 200
        body = r.json()
        assert body["status"]  == "Escalated"
        assert body["endDate"] is None

    def test_update_escalated_to_closed_with_valid_end_date(self):
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-01-01")
        assert e.status_code == 201
        eid = e.json()["id"]
        patch_episode(eid, "Escalated", None)
        r = patch_episode(eid, "Closed", "2024-06-01")
        assert r.status_code == 200
        assert r.json()["status"] == "Closed"

    def test_update_response_contains_all_required_fields(self):
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-01-01")
        assert e.status_code == 201
        r = patch_episode(e.json()["id"], "Closed", "2024-06-01")
        assert r.status_code == 200
        body = r.json()
        for field in ("id", "beneficiaryId", "episodeType", "startDate", "endDate", "status"):
            assert field in body

    def test_update_nonexistent_episode_returns_404(self):
        r = patch_episode(99999999, "Closed", today_iso())
        assert r.status_code == 404
        assert_error_body(r.json())

    def test_update_already_closed_episode_returns_409(self):
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-01-01")
        assert e.status_code == 201
        eid = e.json()["id"]
        patch_episode(eid, "Closed", "2024-06-01")
        r = patch_episode(eid, "Closed", "2024-07-01")     # already Closed
        assert r.status_code == 409
        assert_error_body(r.json())


    def test_closed_to_escalated_transition_returns_409(self):
        """Prompt: 'Every other requested transition (including any update against an
        episode already in Closed) returns HTTP 409 Conflict.'
        The existing test covers Closed->Closed. This covers the symmetric Closed->Escalated."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-01-01")
        assert e.status_code == 201
        eid = e.json()["id"]
        assert patch_episode(eid, "Closed", "2024-06-01").status_code == 200
        r = patch_episode(eid, "Escalated", None)   # already Closed -> 409
        assert r.status_code == 409
        assert_error_body(r.json())

    def test_escalate_with_non_null_end_date_returns_409(self):
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement")
        assert e.status_code == 201
        r = patch_episode(e.json()["id"], "Escalated", today_iso())
        assert r.status_code == 409
        assert_error_body(r.json())

    def test_close_with_null_end_date_returns_409(self):
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement")
        assert e.status_code == 201
        r = patch_episode(e.json()["id"], "Closed", None)
        assert r.status_code == 409
        assert_error_body(r.json())

    def test_close_with_end_date_before_start_date_returns_409(self):
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-06-01")
        assert e.status_code == 201
        r = patch_episode(e.json()["id"], "Closed", "2024-01-01")   # before startDate
        assert r.status_code == 409
        assert_error_body(r.json())

    def test_episode_unchanged_after_rejected_transition(self):
        """
        After a 409 the episode must still be in its prior state.
        We verify by succeeding with the previously rejected valid operation.
        """
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement")
        assert e.status_code == 201
        eid = e.json()["id"]
        bad = patch_episode(eid, "Escalated", today_iso())  # rejected: non-null endDate
        assert bad.status_code == 409
        # Episode must still be Open -> valid escalation must succeed
        good = patch_episode(eid, "Escalated", None)
        assert good.status_code == 200
        assert good.json()["status"] == "Escalated"

    def test_escalated_to_escalated_returns_409(self):
        """Escalated -> Escalated is not in the three allowed pairs."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement")
        assert e.status_code == 201
        eid = e.json()["id"]
        patch_episode(eid, "Escalated", None)
        r = patch_episode(eid, "Escalated", None)     # second escalate
        assert r.status_code == 409
        assert_error_body(r.json())



    def test_duplicate_open_episode_creates_no_new_row(self):
        """Ep-1: Prompt: 'returns HTTP 409 Conflict and creates no new row.'
        The 'creates no new row' clause is a distinct observable side-effect.
        A buggy implementation could insert the row first, then return 409."""
        r0 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r0.status_code == 200
        before = r0.json()["openChronicDiseaseEpisodes"]

        b = create_beneficiary()
        assert b.status_code == 201
        bid = b.json()["id"]
        assert open_episode(bid, "ChronicDiseaseManagement").status_code == 201

        # Baseline + 1 after first open
        r1 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r1.json()["openChronicDiseaseEpisodes"] == before + 1

        # Duplicate -> 409
        dup = open_episode(bid, "ChronicDiseaseManagement")
        assert dup.status_code == 409

        # Count must remain baseline + 1 (not + 2)
        r2 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r2.json()["openChronicDiseaseEpisodes"] == before + 1


    def test_escalated_to_closed_with_null_end_date_returns_409(self):
        """Ep-2: Prompt: 'An update with targetStatus=Closed and either endDate=null …
        returns HTTP 409'. This applies from BOTH Open AND Escalated states.
        test_close_with_null_end_date_returns_409 only exercises Open; this tests Escalated."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement", start_date="2024-01-01")
        assert e.status_code == 201
        eid = e.json()["id"]
        patch_episode(eid, "Escalated", None)           # now Escalated
        r = patch_episode(eid, "Closed", None)           # null endDate -> 409
        assert r.status_code == 409
        assert_error_body(r.json())
        # Episode must still be Escalated - confirm by successfully closing with valid endDate
        ok = patch_episode(eid, "Closed", "2024-06-01")
        assert ok.status_code == 200


    def test_escalated_to_closed_with_end_date_before_start_date_returns_409(self):
        """Ep-3: Prompt: 'An update with targetStatus=Closed and … endDate < StartDate
        returns HTTP 409'. This applies from BOTH Open AND Escalated states.
        test_close_with_end_date_before_start_date_returns_409 only exercises Open."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-06-01")
        assert e.status_code == 201
        eid = e.json()["id"]
        patch_episode(eid, "Escalated", None)            # now Escalated
        r = patch_episode(eid, "Closed", "2024-01-01")   # endDate < startDate -> 409
        assert r.status_code == 409
        assert_error_body(r.json())
        # Episode must still be Escalated - confirm by successfully closing with valid endDate
        ok = patch_episode(eid, "Closed", "2024-06-01")
        assert ok.status_code == 200

    def test_wrong_json_type_for_open_episode_field_returns_400(self):
        """Gap 1: Global Error Contract - wrong JSON type on POST /api/care-coordination/episodes."""
        r = safe_request("post", api("/api/care-coordination/episodes"), json={
            "beneficiaryId": "not-a-number",   # string instead of required number
            "episodeType":   "ChronicDiseaseManagement",
            "startDate":     date_in_year(2024),
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_missing_required_field_for_open_episode_returns_400(self):
        """Gap 2: Global Error Contract - missing required field on POST /api/care-coordination/episodes."""
        b = create_beneficiary()
        assert b.status_code == 201
        r = safe_request("post", api("/api/care-coordination/episodes"), json={
            "beneficiaryId": b.json()["id"],
            "startDate":     date_in_year(2024),
            # episodeType intentionally omitted
        })
        assert r.status_code == 400
        assert_error_body(r.json())


    def test_patch_episode_invalid_end_date_format_returns_400(self):
        """Gap #1: Global Error Contract - 'date format' failures return HTTP 400.
        Malformed startDate on POST /api/care-coordination/episodes is already tested;
        malformed endDate on PATCH has the same contract but was not covered."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"])
        assert e.status_code == 201
        r = safe_request("patch",
                         api(f"/api/care-coordination/episodes/{e.json()['id']}"),
                         json={"targetStatus": "Closed", "endDate": "not-a-date"})
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_wrong_json_type_for_patch_field_returns_400(self):
        """Gap 1: Global Error Contract - wrong JSON type on PATCH /api/care-coordination/episodes/{id}."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"])
        assert e.status_code == 201
        r = safe_request("patch", api(f"/api/care-coordination/episodes/{e.json()['id']}"), json={
            "targetStatus": 1,   # integer instead of required string
            "endDate": None,
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_missing_target_status_in_patch_returns_400(self):
        """Gap 2: Global Error Contract - missing required field on PATCH /api/care-coordination/episodes/{id}."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"])
        assert e.status_code == 201
        r = safe_request("patch", api(f"/api/care-coordination/episodes/{e.json()['id']}"), json={
            "endDate": None,
            # targetStatus intentionally omitted
        })
        assert r.status_code == 400
        assert_error_body(r.json())


    def test_invalid_start_date_format_returns_400(self):
        """Gap 12.1: Global Error Contract - malformed startDate string must return 400."""
        b = create_beneficiary()
        assert b.status_code == 201
        r = safe_request("post", api("/api/care-coordination/episodes"), json={
            "beneficiaryId": b.json()["id"],
            "episodeType":   "ChronicDiseaseManagement",
            "startDate":     "not-a-date",
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_open_same_type_episode_allowed_after_previous_is_closed(self):
        """Gap 12.3: The 409 duplicate-open rule is scoped to Status=Open only.
        Once the prior episode is Closed, a new one of the same type must succeed (201).
        Prompt: 'already has an episode of that same type in Status = Open returns HTTP 409'"""
        b = create_beneficiary()
        assert b.status_code == 201
        bid = b.json()["id"]
        e1 = open_episode(bid, "ChronicDiseaseManagement", start_date="2024-01-01")
        assert e1.status_code == 201
        patch_episode(e1.json()["id"], "Closed", "2024-06-01")
        e2 = open_episode(bid, "ChronicDiseaseManagement")
        assert e2.status_code == 201

    def test_open_same_type_episode_allowed_when_prior_is_escalated(self):
        """Gap 12.4: The 409 rule is explicitly scoped to 'Status = Open'.
        An Escalated episode is NOT Open, so opening a new same-type episode must
        return 201, not 409.
        Prompt: 'already has an episode of that same type in Status = Open returns HTTP 409'"""
        b = create_beneficiary()
        assert b.status_code == 201
        bid = b.json()["id"]
        e1 = open_episode(bid, "ChronicDiseaseManagement")
        assert e1.status_code == 201
        patch_episode(e1.json()["id"], "Escalated", None)   # now Escalated, not Open
        e2 = open_episode(bid, "ChronicDiseaseManagement")
        assert e2.status_code == 201   # must be allowed; prior is Escalated, not Open

    def test_invalid_episode_type_enum_returns_400(self):
        """Gap 12.5: Global Error Contract requires HTTP 400 for invalid enum values.
        episodeType is an enum - any value outside {'ChronicDiseaseManagement','PostAcuteTransition'}
        must return 400."""
        b = create_beneficiary()
        assert b.status_code == 201
        r = safe_request("post", api("/api/care-coordination/episodes"), json={
            "beneficiaryId": b.json()["id"],
            "episodeType":   "InvalidType",
            "startDate":     date_in_year(2024),
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_invalid_target_status_enum_returns_400(self):
        """Gap 12.6: targetStatus is an enum {'Closed','Escalated'}. A valid-typed but
        out-of-range string like 'Reopened' must return 400 (not 409).
        Prompt: global error contract - 'enum value' failures return HTTP 400."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"])
        assert e.status_code == 201
        r = safe_request("patch",
                         api(f"/api/care-coordination/episodes/{e.json()['id']}"),
                         json={"targetStatus": "Reopened", "endDate": None})
        assert r.status_code == 400
        assert_error_body(r.json())


    def test_non_integer_episode_id_in_patch_route_returns_404(self):
        """Gap #4: Prompt specifies [HttpPatch("{id:int}")].
        With the :int constraint, a non-numeric path segment must return HTTP 404."""
        r = safe_request("patch", api("/api/care-coordination/episodes/abc"),
                         json={"targetStatus": "Closed", "endDate": "2024-06-01"})
        assert r.status_code == 404


    def test_close_with_end_date_equal_to_start_date_succeeds(self):
        """Req #1: Prompt: 'endDate on or after startDate' - 'on' means endDate == startDate
        is the inclusive lower boundary and MUST succeed with HTTP 200.
        Every existing close test uses an endDate strictly later than startDate."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-06-01")
        assert e.status_code == 201
        r = patch_episode(e.json()["id"], "Closed", "2024-06-01")   # same as startDate
        assert r.status_code == 200
        body = r.json()
        assert body["status"]  == "Closed"
        assert body["endDate"] == "2024-06-01"

    def test_escalated_to_closed_with_end_date_equal_to_start_date_succeeds(self):
        """Req #1: The same 'on or after' inclusive boundary applies to the
        Escalated -> Closed transition path."""
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-06-01")
        assert e.status_code == 201
        eid = e.json()["id"]
        patch_episode(eid, "Escalated", None)
        r = patch_episode(eid, "Closed", "2024-06-01")   # endDate == startDate
        assert r.status_code == 200
        assert r.json()["status"] == "Closed"


# ============================================================
# POST /api/savings/settlement
# ============================================================

class TestSharedSavingsSettlement:
    """
    Test values - benchmark = 1,000,000:
      ACTUAL_SAVINGS = 950,000  ->  grossDiff =  50,000, ratio =  5.0% ≥ 2% MSR -> savings
      ACTUAL_LOSS    = 1,030,000 -> grossDiff = -30,000, ratio = -3.0% ≤ -2% MLR -> loss
      ACTUAL_BELOW   = 995,000  ->  grossDiff =   5,000, ratio =  0.5% < 2% MSR  -> neither
    """

    BENCHMARK     = 1_000_000.0
    ACTUAL_SAVINGS = 950_000.0     # triggers savings
    ACTUAL_LOSS    = 1_030_000.0   # triggers loss
    ACTUAL_BELOW   = 995_000.0     # below MSR; no savings, no loss

    def _new_provider_settlement(self, track: str, actual: float, quality: float = 1.0):
        p = create_provider()
        assert p.status_code == 201
        year = random.randint(2082, 2089)
        return create_settlement(p.json()["id"], year, track,
                                 self.BENCHMARK, actual, quality)

    # -- Shape ------------------------------------------------

    def test_success_returns_201_with_correct_shape(self):
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2081, "BasicA",
                              self.BENCHMARK, self.ACTUAL_SAVINGS, 1.0)
        assert r.status_code == 201
        body = r.json()
        assert isinstance(body["id"],                    int)
        assert body["track"]                            == "BasicA"
        assert body["providerId"]                       == p.json()["id"]
        assert isinstance(body["earnedSavings"],        (int, float))
        assert isinstance(body["earnedLosses"],         (int, float))
        assert isinstance(body["finalQualityScore"],    (int, float))
        assert isinstance(body["benchmarkExpenditure"], (int, float))
        assert isinstance(body["actualExpenditure"],    (int, float))
        assert body["performanceYear"]                == 2081        # Req #1: must be present in response

    # -- Per-track savings rates -------------------------------

    def test_basic_a_savings_rate_25_percent(self):
        # earnedSavings = 50_000 × 0.25 × 1.0 = 12_500
        r = self._new_provider_settlement("BasicA", self.ACTUAL_SAVINGS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(12_500.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,       abs=0.01)

    def test_basic_b_savings_rate_30_percent(self):
        # earnedSavings = 50_000 × 0.30 × 1.0 = 15_000
        r = self._new_provider_settlement("BasicB", self.ACTUAL_SAVINGS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(15_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,       abs=0.01)

    def test_basic_c_savings_rate_40_percent(self):
        # earnedSavings = 50_000 × 0.40 × 1.0 = 20_000
        r = self._new_provider_settlement("BasicC", self.ACTUAL_SAVINGS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(20_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,       abs=0.01)

    def test_basic_d_savings_rate_50_percent(self):
        # earnedSavings = 50_000 × 0.50 × 1.0 = 25_000
        r = self._new_provider_settlement("BasicD", self.ACTUAL_SAVINGS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(25_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,       abs=0.01)

    def test_basic_e_savings_rate_60_percent(self):
        # earnedSavings = 50_000 × 0.60 × 1.0 = 30_000
        r = self._new_provider_settlement("BasicE", self.ACTUAL_SAVINGS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(30_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,       abs=0.01)

    def test_enhanced_savings_rate_75_percent(self):
        # earnedSavings = 50_000 × 0.75 × 1.0 = 37_500
        r = self._new_provider_settlement("Enhanced", self.ACTUAL_SAVINGS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(37_500.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,       abs=0.01)

    # -- Per-track loss rates (two-sided only) -----------------

    def test_basic_d_loss_rate_30_percent(self):
        # earnedLosses = 30_000 × 0.30 = 9_000
        r = self._new_provider_settlement("BasicD", self.ACTUAL_LOSS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0,     abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(9_000.0, abs=0.01)

    def test_basic_e_loss_rate_30_percent(self):
        # earnedLosses = 30_000 × 0.30 = 9_000
        r = self._new_provider_settlement("BasicE", self.ACTUAL_LOSS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0,     abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(9_000.0, abs=0.01)

    def test_enhanced_loss_rate_40_percent(self):
        # earnedLosses = 30_000 × 0.40 = 12_000
        r = self._new_provider_settlement("Enhanced", self.ACTUAL_LOSS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0,      abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(12_000.0, abs=0.01)

    # -- Below MSR -> both zero ---------------------------------

    def test_below_msr_both_earned_savings_and_losses_are_zero(self):
        r = self._new_provider_settlement("BasicD", self.ACTUAL_BELOW, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0, abs=0.01)

    # -- One-sided tracks never generate losses ----------------

    def test_basic_a_one_sided_no_loss_even_above_mlr(self):
        r = self._new_provider_settlement("BasicA", self.ACTUAL_LOSS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0, abs=0.01)

    def test_basic_b_one_sided_no_loss(self):
        r = self._new_provider_settlement("BasicB", self.ACTUAL_LOSS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0, abs=0.01)

    def test_basic_c_one_sided_no_loss(self):
        r = self._new_provider_settlement("BasicC", self.ACTUAL_LOSS, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0, abs=0.01)

    # -- finalQualityScore multiplied into earnedSavings -------

    def test_final_quality_score_multiplied_into_earned_savings(self):
        # BasicA, quality=0.5: earnedSavings = 50_000 × 0.25 × 0.5 = 6_250
        r = self._new_provider_settlement("BasicA", self.ACTUAL_SAVINGS, quality=0.5)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(6_250.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,      abs=0.01)

    # -- Uniqueness constraint ---------------------------------

    def test_duplicate_year_provider_pair_returns_409(self):
        p = create_provider()
        assert p.status_code == 201
        pid  = p.json()["id"]
        year = 2090
        assert create_settlement(pid, year, "BasicA",
                                 self.BENCHMARK, self.ACTUAL_SAVINGS, 1.0).status_code == 201
        r = create_settlement(pid, year, "BasicB",
                              self.BENCHMARK, self.ACTUAL_SAVINGS, 1.0)
        assert r.status_code == 409
        assert_error_body(r.json())

    def test_same_year_different_providers_both_allowed(self):
        p1 = create_provider()
        p2 = create_provider()
        assert p1.status_code == 201 and p2.status_code == 201
        year = 2091
        r1 = create_settlement(p1.json()["id"], year, "BasicA",
                               self.BENCHMARK, self.ACTUAL_SAVINGS, 1.0)
        r2 = create_settlement(p2.json()["id"], year, "BasicA",
                               self.BENCHMARK, self.ACTUAL_SAVINGS, 1.0)
        assert r1.status_code == 201
        assert r2.status_code == 201

    # -- Validation errors -------------------------------------

    def test_nonexistent_provider_returns_404(self):
        r = create_settlement(99999999, 2092, "BasicA",
                              self.BENCHMARK, self.ACTUAL_SAVINGS, 1.0)
        assert r.status_code == 404
        assert_error_body(r.json())

    def test_benchmark_expenditure_zero_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2093, "BasicA",
                              0.0, self.ACTUAL_SAVINGS, 1.0)
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_benchmark_expenditure_negative_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2093, "BasicA",
                              -1_000.0, self.ACTUAL_SAVINGS, 1.0)
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_negative_actual_expenditure_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2093, "BasicA",
                              self.BENCHMARK, -1.0, 1.0)
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_invalid_track_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2093, "BasicZ",
                              self.BENCHMARK, self.ACTUAL_SAVINGS, 1.0)
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_quality_score_above_1_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2093, "BasicA",
                              self.BENCHMARK, self.ACTUAL_SAVINGS, 1.1)
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_quality_score_below_0_returns_400(self):
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2093, "BasicA",
                              self.BENCHMARK, self.ACTUAL_SAVINGS, -0.1)
        assert r.status_code == 400
        assert_error_body(r.json())



    def test_actual_expenditure_zero_is_accepted_and_earns_savings(self):
        """Obs #1: Prompt: 'HTTP 400 if actualExpenditure < 0'.
        Strict inequality means 0 is valid. With actual=0: grossDiff = benchmark,
        ratio = 100% >> MSR, so savings are earned normally.
        BasicA: earnedSavings = 1_000_000 * 0.25 * 1.0 = 250_000."""
        r = self._new_provider_settlement("BasicA", actual=0.0, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(250_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,        abs=0.01)


    def test_savings_at_exactly_msr_threshold_basic_b(self):
        """M4: BasicB – savings MUST be earned at ratio == +2.0% (>= is inclusive)."""
        r = self._new_provider_settlement("BasicB", actual=980_000.0, quality=1.0)
        assert r.status_code == 201
        # earnedSavings = 20_000 * 0.30 * 1.0 = 6_000
        assert r.json()["earnedSavings"] == pytest.approx(6_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,     abs=0.01)

    def test_savings_at_exactly_msr_threshold_basic_c(self):
        """M4: BasicC – savings MUST be earned at ratio == +2.0%."""
        r = self._new_provider_settlement("BasicC", actual=980_000.0, quality=1.0)
        assert r.status_code == 201
        # earnedSavings = 20_000 * 0.40 * 1.0 = 8_000
        assert r.json()["earnedSavings"] == pytest.approx(8_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,     abs=0.01)

    def test_savings_at_exactly_msr_threshold_basic_e(self):
        """M4: BasicE – savings MUST be earned at ratio == +2.0%."""
        r = self._new_provider_settlement("BasicE", actual=980_000.0, quality=1.0)
        assert r.status_code == 201
        # earnedSavings = 20_000 * 0.60 * 1.0 = 12_000
        assert r.json()["earnedSavings"] == pytest.approx(12_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,      abs=0.01)

    def test_savings_at_exactly_msr_threshold_enhanced(self):
        """M4: Enhanced – savings MUST be earned at ratio == +2.0%."""
        r = self._new_provider_settlement("Enhanced", actual=980_000.0, quality=1.0)
        assert r.status_code == 201
        # earnedSavings = 20_000 * 0.75 * 1.0 = 15_000
        assert r.json()["earnedSavings"] == pytest.approx(15_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,      abs=0.01)

    def test_losses_at_exactly_mlr_threshold_basic_e(self):
        """M4: BasicE – losses MUST be earned at ratio == -2.0% (<= is inclusive).
        benchmark=1_000_000, actual=1_020_000 -> grossDiff=-20_000, ratio=-0.02 exactly."""
        r = self._new_provider_settlement("BasicE", actual=1_020_000.0, quality=1.0)
        assert r.status_code == 201
        # earnedLosses = 20_000 * 0.30 = 6_000
        assert r.json()["earnedSavings"] == pytest.approx(0.0,     abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(6_000.0, abs=0.01)

    def test_losses_at_exactly_mlr_threshold_enhanced(self):
        """M4: Enhanced – losses MUST be earned at ratio == -2.0%."""
        r = self._new_provider_settlement("Enhanced", actual=1_020_000.0, quality=1.0)
        assert r.status_code == 201
        # earnedLosses = 20_000 * 0.40 = 8_000
        assert r.json()["earnedSavings"] == pytest.approx(0.0,     abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(8_000.0, abs=0.01)

    def test_wrong_json_type_for_field_returns_400(self):
        """Gap 1: Global Error Contract - wrong JSON type on /api/savings/settlement."""
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/savings/settlement"), json={
            "performanceYear":      "2080",   # string instead of required number
            "providerId":           p.json()["id"],
            "track":                "BasicA",
            "benchmarkExpenditure": 1_000_000.0,
            "actualExpenditure":    950_000.0,
            "finalQualityScore":    1.0,
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_missing_required_field_returns_400(self):
        """Gap 2: Global Error Contract - missing required field on /api/savings/settlement."""
        p = create_provider()
        assert p.status_code == 201
        r = safe_request("post", api("/api/savings/settlement"), json={
            "performanceYear":      2080,
            "providerId":           p.json()["id"],
            "benchmarkExpenditure": 1_000_000.0,
            "actualExpenditure":    950_000.0,
            "finalQualityScore":    1.0,
            # track intentionally omitted
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_savings_at_exactly_msr_threshold_earns_savings(self):
        """Gap 3: Prompt: 'If grossDifference / benchmarkExpenditure >= MSR'
        The >= is inclusive - ratio exactly equal to MSR (2.0%) MUST earn savings.
        benchmark=1_000_000, actual=980_000 -> grossDiff=20_000 -> ratio=0.02 exactly.
        BasicA: earnedSavings = 20_000 * 0.25 * 1.0 = 5_000.
        """
        r = self._new_provider_settlement("BasicA", actual=980_000.0, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(5_000.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0,     abs=0.01)

    def test_losses_at_exactly_mlr_threshold_earns_losses(self):
        """Gap 3: Prompt: 'If grossDifference / benchmarkExpenditure <= -MLR AND lossRate > 0'
        The <= is inclusive - ratio exactly equal to -MLR (-2.0%) MUST earn losses.
        benchmark=1_000_000, actual=1_020_000 -> grossDiff=-20_000 -> ratio=-0.02 exactly.
        BasicD: earnedLosses = 20_000 * 0.30 = 6_000.
        """
        r = self._new_provider_settlement("BasicD", actual=1_020_000.0, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0,     abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(6_000.0, abs=0.01)


    def test_final_quality_score_zero_is_accepted(self):
        """Gap 11.4: finalQualityScore=0.0 is the inclusive lower bound and must be accepted.
        Prompt: 'HTTP 400 if … finalQualityScore is outside [0.0, 1.0]'
        With quality=0.0, earnedSavings = grossDiff * sharingRate * 0.0 = 0.0."""
        r = self._new_provider_settlement("BasicA", self.ACTUAL_SAVINGS, quality=0.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0, abs=0.01)




    def test_high_precision_actual_expenditure_preserved_in_response(self):
        """Gap #9: Prompt: 'preserving exact C# decimal arithmetic end-to-end.'
        ActualExpenditure is a monetary decimal property and must round-trip exactly."""
        precision_actual = 1_000_000.1234
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2093, "BasicA",
                              2_000_000.0, precision_actual, 1.0)
        assert r.status_code == 201
        assert r.json()["actualExpenditure"] == pytest.approx(precision_actual, abs=1e-4)

    def test_high_precision_benchmark_expenditure_preserved_in_response(self):
        """Gap #9: Prompt: 'preserving exact C# decimal arithmetic end-to-end.'
        BenchmarkExpenditure is a monetary decimal property and must round-trip exactly."""
        precision_benchmark = 1_234_567.8901
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2092, "BasicA",
                              precision_benchmark, 1_000_000.0, 1.0)
        assert r.status_code == 201
        assert r.json()["benchmarkExpenditure"] == pytest.approx(precision_benchmark, abs=1e-4)

    def test_high_precision_final_quality_score_preserved_in_response(self):
        """Gap #9: Prompt: 'preserving exact C# decimal arithmetic end-to-end.'
        FinalQualityScore is a ratio decimal property and must round-trip exactly."""
        precision_quality = 0.1234567891
        p = create_provider()
        assert p.status_code == 201
        r = create_settlement(p.json()["id"], 2091, "BasicA",
                              1_000_000.0, 950_000.0, precision_quality)
        assert r.status_code == 201
        assert r.json()["finalQualityScore"] == pytest.approx(precision_quality, abs=1e-6)

    def test_earned_losses_not_scaled_by_final_quality_score(self):
        """Gap 11.2: Prompt: 'earnedLosses = abs(grossDifference) * lossRate'
        The formula deliberately omits finalQualityScore - only earnedSavings is quality-scaled.
        With quality=0.5 and BasicD in a loss scenario:
          earnedLosses must be 30_000 * 0.30 = 9_000 (NOT 4_500 = 9_000 * 0.5)."""
        r = self._new_provider_settlement("BasicD", self.ACTUAL_LOSS, quality=0.5)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0,     abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(9_000.0, abs=0.01)


    def test_zero_gross_difference_one_sided_track_yields_zero_savings_and_losses(self):
        """Req #3: Prompt: 'grossDifference = benchmarkExpenditure - actualExpenditure'.
        When actualExpenditure == benchmarkExpenditure, grossDifference = 0.
        ratio = 0/benchmark = 0.0%, which is below MSR (2%) - savings do not trigger.
        BasicA is one-sided so losses also cannot trigger.
        'Otherwise' branch: earnedSavings = 0, earnedLosses = 0."""
        r = self._new_provider_settlement("BasicA", actual=self.BENCHMARK, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0, abs=0.01)

    def test_zero_gross_difference_two_sided_track_yields_zero_savings_and_losses(self):
        """Req #3: Same zero-difference edge case on a two-sided track (BasicD).
        ratio = 0.0%: below MSR (+2%) -> savings don't trigger; above MLR (-2%) -> losses
        don't trigger. 'Otherwise' branch: earnedSavings = 0, earnedLosses = 0."""
        r = self._new_provider_settlement("BasicD", actual=self.BENCHMARK, quality=1.0)
        assert r.status_code == 201
        assert r.json()["earnedSavings"] == pytest.approx(0.0, abs=0.01)
        assert r.json()["earnedLosses"]  == pytest.approx(0.0, abs=0.01)


# ============================================================
# POST /api/reports/cms-submission
# ============================================================

class TestCmsReport:
    """
    CMS_YEAR = 2023 so service dates (2023-xx-xx) are safely in the past.
    Delta assertions protect against pre-existing seed data and earlier tests.
    Isolated years (2077-2079) are used for tests that require a clean slate.
    """

    def test_settlements_entries_contain_only_the_three_specified_fields(self):
        """Req #2: Prompt specifies settlement entry shape as EXACTLY
        { track, earnedSavings, earnedLosses } - no other fields.
        A natural over-eager implementation would serialise the full SharedSavingsSettlement
        entity, leaking id, providerId, benchmarkExpenditure, etc."""
        isolated_year = 2062   # untouched by any other test
        p = create_provider()
        assert p.status_code == 201
        create_settlement(p.json()["id"], isolated_year, "BasicA",
                          1_000_000.0, 950_000.0, 1.0)
        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": isolated_year})
        assert r.status_code == 200
        entries = r.json()["settlements"]
        assert len(entries) >= 1
        for entry in entries:
            assert set(entry.keys()) == {"track", "earnedSavings", "earnedLosses"}, \
                f"Settlement entry must contain exactly {{track, earnedSavings, earnedLosses}}; got {set(entry.keys())}"


    def test_cms_report_response_contains_only_the_five_specified_fields(self):
        """Req #3: Prompt specifies CMS response shape as EXACTLY
        { performanceYear, totalAttributedBeneficiaries, totalProviders,
          averageQualityScore, settlements } - no extra keys."""
        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": CMS_YEAR})
        assert r.status_code == 200
        assert set(r.json().keys()) == {
            "performanceYear", "totalAttributedBeneficiaries",
            "totalProviders", "averageQualityScore", "settlements",
        }, f"CMS response must contain exactly these keys; got {set(r.json().keys())}"

    def test_performance_year_echoed_in_response(self):
        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": CMS_YEAR})
        assert r.status_code == 200
        assert r.json()["performanceYear"] == CMS_YEAR

    def test_total_attributed_beneficiaries_counts_step1_and_step2_not_unassigned(self):
        """
        Create 1 Step1Pcp + 1 Step2Specialist + 1 Unassigned beneficiary.
        The count must increase by exactly 2 (not 3).
        Baseline is taken AFTER running attribution so any beneficiaries with 2023
        services created by earlier tests are already reflected in the baseline.
        """
        run_attribution(CMS_YEAR)   # flush any prior-test side-effects into baseline
        r0 = safe_request("post", api("/api/reports/cms-submission"),
                          json={"performanceYear": CMS_YEAR})
        assert r0.status_code == 200
        baseline = r0.json()["totalAttributedBeneficiaries"]

        pc = create_provider(provider_type="PrimaryCare")
        sp = create_provider(provider_type="Specialist")
        b1 = create_beneficiary(enrollmentStartDate=f"{CMS_YEAR - 1}-01-01")
        b2 = create_beneficiary(enrollmentStartDate=f"{CMS_YEAR - 1}-01-01")
        b3 = create_beneficiary(enrollmentStartDate=f"{CMS_YEAR - 1}-01-01")  # Unassigned
        assert all(x.status_code == 201 for x in [pc, sp, b1, b2, b3])

        create_service(b1.json()["id"], pc.json()["id"], date_in_year(CMS_YEAR))  # -> Step1
        create_service(b2.json()["id"], sp.json()["id"], date_in_year(CMS_YEAR))  # -> Step2
        # b3 gets no services -> Unassigned

        run_attribution(CMS_YEAR)

        r1 = safe_request("post", api("/api/reports/cms-submission"),
                          json={"performanceYear": CMS_YEAR})
        assert r1.status_code == 200
        assert r1.json()["totalAttributedBeneficiaries"] == baseline + 2

    def test_total_providers_increases_by_one_when_provider_added(self):
        """totalProviders counts all Provider rows, not scoped by year."""
        r0 = safe_request("post", api("/api/reports/cms-submission"),
                          json={"performanceYear": CMS_YEAR})
        assert r0.status_code == 200
        count_before = r0.json()["totalProviders"]
        create_provider()
        r1 = safe_request("post", api("/api/reports/cms-submission"),
                          json={"performanceYear": CMS_YEAR})
        assert r1.status_code == 200
        assert r1.json()["totalProviders"] == count_before + 1

    def test_average_quality_score_zero_when_no_provider_has_measures_for_year(self):
        """Use a year with no quality data to verify the 0.0 fallback."""
        isolated_year = 2079
        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": isolated_year})
        assert r.status_code == 200
        assert r.json()["averageQualityScore"] == 0.0

    def test_average_quality_score_formula_with_exact_expected_value(self):
        """
        Verifies the averageQualityScore formula using an isolated year (2073) where
        the full provider-with-measures population is known.
        p1: measures 0.8 + 0.6 -> per-provider score = 0.7000
        p2: measure 0.4         -> per-provider score = 0.4000
        Expected average = (0.7 + 0.4) / 2 = 0.5500 exactly.
        Using CMS_YEAR (shared with many tests) made the denominator unknowable,
        causing the previous assertions to be trivially/tautologically satisfied.
        """
        isolated_year = 2073   # untouched by any other test
        p1 = create_provider()
        p2 = create_provider()
        assert p1.status_code == 201 and p2.status_code == 201
        record_measure(p1.json()["id"], isolated_year, percentile=0.8)
        record_measure(p1.json()["id"], isolated_year, percentile=0.6)   # p1 score = 0.7000
        record_measure(p2.json()["id"], isolated_year, percentile=0.4)   # p2 score = 0.4000
        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": isolated_year})
        assert r.status_code == 200
        score = r.json()["averageQualityScore"]
        assert score == pytest.approx(0.55, abs=1e-4)

    def test_average_quality_score_excludes_providers_with_no_measures_for_year(self):
        """
        Req C: averageQualityScore must use ONLY providers that have at least one
        QualityMeasureResult for the requested year as the denominator.

        Prompt: 'taken across all providers that have at least one QualityMeasureResult
        for the year'.

        Setup: two providers with known per-year scores (0.7000 and 0.4000) plus
        one provider with ZERO measures for this year.
        Correct result:   (0.7 + 0.4) / 2 = 0.5500   (denominator = 2)
        Wrong result:     (0.7 + 0.4 + 0.0) / 3 ≈ 0.3667  (denominator = 3)
        """
        isolated_year = 2075   # no other test or seed data uses this year
        p1 = create_provider()
        p2 = create_provider()
        p3 = create_provider()   # deliberately left with no measures for isolated_year
        assert p1.status_code == 201 and p2.status_code == 201 and p3.status_code == 201

        # p1: two measures -> per-provider score = (0.8 + 0.6) / 2 = 0.7000
        record_measure(p1.json()["id"], isolated_year, percentile=0.8)
        record_measure(p1.json()["id"], isolated_year, percentile=0.6)
        # p2: one measure -> per-provider score = 0.4000
        record_measure(p2.json()["id"], isolated_year, percentile=0.4)
        # p3 has no measures for isolated_year

        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": isolated_year})
        assert r.status_code == 200
        score = r.json()["averageQualityScore"]
        # Must be 0.5500, not ~0.3667 (which would indicate p3 was included)
        assert score == pytest.approx(0.55, abs=1e-4)


    def test_average_quality_score_is_rounded_to_4_decimal_places(self):
        """Req #3: The CMS submission averageQualityScore must be rounded to exactly
        4 decimal places. Existing tests use inputs whose mean (0.55) is already
        4-dp clean. This test uses 3 provider scores averaging 1/3 ≈ 0.3333...
        to exercise actual rounding.
        Prompt: 'averageQualityScore … rounded to four decimal places'"""
        isolated_year = 2061   # untouched by any other test
        p1 = create_provider()
        p2 = create_provider()
        p3 = create_provider()
        assert p1.status_code == 201 and p2.status_code == 201 and p3.status_code == 201
        # p1 score = 1.0, p2 score = 0.0, p3 score = 0.0
        # averageQualityScore = (1.0 + 0.0 + 0.0) / 3 = 1/3 -> must be rounded to 0.3333
        record_measure(p1.json()["id"], isolated_year, percentile=1.0,
                       numerator=10, denominator=10)
        record_measure(p2.json()["id"], isolated_year, percentile=0.0,
                       numerator=0, denominator=10)
        record_measure(p3.json()["id"], isolated_year, percentile=0.0,
                       numerator=0, denominator=10)
        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": isolated_year})
        assert r.status_code == 200
        score = r.json()["averageQualityScore"]
        assert score == pytest.approx(round(1 / 3, 4), abs=1e-5)   # 0.3333
        assert score == pytest.approx(round(score, 4), abs=1e-9)   # is rounded

    def test_settlements_empty_array_when_none_exist_for_year(self):
        isolated_year = 2078
        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": isolated_year})
        assert r.status_code == 200
        assert r.json()["settlements"] == []

    def test_settlements_list_contains_required_fields(self):
        p = create_provider()
        assert p.status_code == 201
        create_settlement(p.json()["id"], CMS_YEAR, "BasicA",
                          1_000_000.0, 950_000.0, 1.0)
        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": CMS_YEAR})
        assert r.status_code == 200
        entries = r.json()["settlements"]
        assert len(entries) >= 1
        entry = entries[-1]     # our new entry is last (highest Id in the year)
        assert "track"         in entry
        assert "earnedSavings" in entry
        assert "earnedLosses"  in entry

    def test_settlements_returned_in_ascending_id_order(self):
        """
        Two settlements created sequentially for the same isolated year:
        the one with the lower auto-increment Id (created first -> BasicA) must
        appear before the one with the higher Id (BasicB).
        Uses a delta approach so the test remains correct across repeated runs
        on a non-wiped database (each run adds a new unique provider pair).
        """
        isolated_year = 2077
        r_before = safe_request("post", api("/api/reports/cms-submission"),
                                json={"performanceYear": isolated_year})
        assert r_before.status_code == 200
        baseline_count = len(r_before.json()["settlements"])

        p1 = create_provider()
        p2 = create_provider()
        assert p1.status_code == 201 and p2.status_code == 201
        s1 = create_settlement(p1.json()["id"], isolated_year, "BasicA",
                               1_000_000.0, 950_000.0, 1.0)
        s2 = create_settlement(p2.json()["id"], isolated_year, "BasicB",
                               1_000_000.0, 950_000.0, 1.0)
        assert s1.status_code == 201 and s2.status_code == 201

        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": isolated_year})
        assert r.status_code == 200
        entries = r.json()["settlements"]
        assert len(entries) == baseline_count + 2
        # s1 (BasicA) has the lower Id -> must appear second-to-last
        # s2 (BasicB) has the higher Id -> must appear last
        assert entries[-2]["track"] == "BasicA"
        assert entries[-1]["track"] == "BasicB"


    def test_wrong_json_type_for_performance_year_returns_400(self):
        """Gap 1: Global Error Contract - wrong JSON type on /api/reports/cms-submission."""
        r = safe_request("post", api("/api/reports/cms-submission"), json={
            "performanceYear": "2023",   # string instead of required number
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_missing_performance_year_returns_400(self):
        """Gap 2: Global Error Contract - missing required field on /api/reports/cms-submission."""
        r = safe_request("post", api("/api/reports/cms-submission"), json={})
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_settlements_scoped_to_requested_year_excludes_other_years(self):
        """Gap 7: Prompt: 'settlements lists every SharedSavingsSettlement row whose
        PerformanceYear matches the requested year'. Settlements from a different year
        must NOT appear in the response.
        Uses isolated years 2063 and 2064 (untouched by any other test).
        """
        year_a, year_b = 2063, 2064
        pa = create_provider()
        pb = create_provider()
        assert pa.status_code == 201 and pb.status_code == 201
        sa = create_settlement(pa.json()["id"], year_a, "BasicA",
                               1_000_000.0, 950_000.0, 1.0)
        sb = create_settlement(pb.json()["id"], year_b, "BasicC",
                               1_000_000.0, 950_000.0, 1.0)
        assert sa.status_code == 201 and sb.status_code == 201

        r = safe_request("post", api("/api/reports/cms-submission"),
                         json={"performanceYear": year_a})
        assert r.status_code == 200
        entries  = r.json()["settlements"]
        tracks   = [e["track"] for e in entries]
        assert "BasicA" in  tracks   # year_a settlement present
        assert "BasicC" not in tracks  # year_b settlement must be absent


# ============================================================
# POST /api/reports/state-public-health
# ============================================================

class TestStatePublicHealthReport:

    def test_state_health_report_response_contains_only_the_four_specified_fields(self):
        """Req #3: Prompt specifies state-public-health response shape as EXACTLY
        { performanceYear, openChronicDiseaseEpisodes, openPostAcuteEpisodes,
          escalatedEpisodes } - no extra keys."""
        r = safe_request("post", api("/api/reports/state-public-health"),
                         json={"performanceYear": STATE_YEAR})
        assert r.status_code == 200
        assert set(r.json().keys()) == {
            "performanceYear", "openChronicDiseaseEpisodes",
            "openPostAcuteEpisodes", "escalatedEpisodes",
        }, f"State-health response must contain exactly these keys; got {set(r.json().keys())}"


    def test_episode_type_counts_are_strictly_isolated(self):
        """Req #4: openChronicDiseaseEpisodes and openPostAcuteEpisodes must count
        ONLY their own EpisodeType. A bug that double-counts or swaps the queries
        would still pass the existing single-type increment tests.
        Prompt: 'scoped by EpisodeType and Status as named'"""
        r0 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r0.status_code == 200
        cdm_before = r0.json()["openChronicDiseaseEpisodes"]
        pa_before  = r0.json()["openPostAcuteEpisodes"]

        # Open ONLY a PostAcuteTransition episode
        b1 = create_beneficiary()
        assert b1.status_code == 201
        assert open_episode(b1.json()["id"], "PostAcuteTransition").status_code == 201
        r1 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r1.json()["openPostAcuteEpisodes"]      == pa_before  + 1
        assert r1.json()["openChronicDiseaseEpisodes"] == cdm_before     # must be unchanged

        # Open ONLY a ChronicDiseaseManagement episode
        b2 = create_beneficiary()
        assert b2.status_code == 201
        assert open_episode(b2.json()["id"], "ChronicDiseaseManagement").status_code == 201
        r2 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r2.json()["openChronicDiseaseEpisodes"] == cdm_before + 1
        assert r2.json()["openPostAcuteEpisodes"]      == pa_before  + 1  # unchanged

    def test_performance_year_echoed_in_response(self):
        r = safe_request("post", api("/api/reports/state-public-health"),
                         json={"performanceYear": STATE_YEAR})
        assert r.status_code == 200
        assert r.json()["performanceYear"] == STATE_YEAR

    def test_performance_year_does_not_filter_episode_counts(self):
        """
        Calling the endpoint with two different years must return identical
        counts - performanceYear is echoed only and must not filter data.
        """
        r1 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        r2 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR + 1})
        assert r1.status_code == 200 and r2.status_code == 200
        assert r1.json()["openChronicDiseaseEpisodes"] == r2.json()["openChronicDiseaseEpisodes"]
        assert r1.json()["openPostAcuteEpisodes"]      == r2.json()["openPostAcuteEpisodes"]
        assert r1.json()["escalatedEpisodes"]          == r2.json()["escalatedEpisodes"]

    def test_open_chronic_disease_count_increments_by_one(self):
        r0 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r0.status_code == 200
        before = r0.json()["openChronicDiseaseEpisodes"]
        b = create_beneficiary()
        assert b.status_code == 201
        assert open_episode(b.json()["id"], "ChronicDiseaseManagement").status_code == 201
        r1 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r1.status_code == 200
        assert r1.json()["openChronicDiseaseEpisodes"] == before + 1

    def test_open_post_acute_count_increments_by_one(self):
        r0 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r0.status_code == 200
        before = r0.json()["openPostAcuteEpisodes"]
        b = create_beneficiary()
        assert b.status_code == 201
        assert open_episode(b.json()["id"], "PostAcuteTransition").status_code == 201
        r1 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r1.status_code == 200
        assert r1.json()["openPostAcuteEpisodes"] == before + 1

    def test_escalated_count_increments_by_one(self):
        r0 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r0.status_code == 200
        before = r0.json()["escalatedEpisodes"]
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement")
        assert e.status_code == 201
        patch_episode(e.json()["id"], "Escalated", None)
        r1 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r1.status_code == 200
        assert r1.json()["escalatedEpisodes"] == before + 1

    def test_closed_episodes_not_counted_in_open_chronic(self):
        r0 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r0.status_code == 200
        before = r0.json()["openChronicDiseaseEpisodes"]
        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement",
                         start_date="2024-01-01")
        assert e.status_code == 201
        patch_episode(e.json()["id"], "Closed", "2024-06-01")
        r1 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r1.status_code == 200
        # Closed episode must NOT increase the Open count
        assert r1.json()["openChronicDiseaseEpisodes"] == before

    def test_escalated_episodes_counted_across_both_episode_types(self):
        """Both ChronicDiseaseManagement and PostAcuteTransition escalations counted."""
        r0 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r0.status_code == 200
        before = r0.json()["escalatedEpisodes"]
        b1 = create_beneficiary()
        b2 = create_beneficiary()
        assert b1.status_code == 201 and b2.status_code == 201
        e1 = open_episode(b1.json()["id"], "ChronicDiseaseManagement")
        e2 = open_episode(b2.json()["id"], "PostAcuteTransition")
        assert e1.status_code == 201 and e2.status_code == 201
        patch_episode(e1.json()["id"], "Escalated", None)
        patch_episode(e2.json()["id"], "Escalated", None)
        r1 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r1.status_code == 200
        assert r1.json()["escalatedEpisodes"] == before + 2

    def test_wrong_json_type_for_performance_year_returns_400(self):
        """Gap 1: Global Error Contract - wrong JSON type on /api/reports/state-public-health."""
        r = safe_request("post", api("/api/reports/state-public-health"), json={
            "performanceYear": "2088",   # string instead of required number
        })
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_missing_performance_year_returns_400(self):
        """Gap 2: Global Error Contract - missing required field on /api/reports/state-public-health."""
        r = safe_request("post", api("/api/reports/state-public-health"), json={})
        assert r.status_code == 400
        assert_error_body(r.json())

    def test_escalated_then_closed_episode_not_counted_in_escalated(self):
        """Gap 8: Prompt: 'currently escalated episodes (any type) across the entire CareEpisode table'.
        An episode that transitions Open -> Escalated -> Closed must NOT appear in escalatedEpisodes;
        only currently-escalated (not yet closed) episodes are counted.
        """
        r0 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r0.status_code == 200
        before = r0.json()["escalatedEpisodes"]

        b = create_beneficiary()
        assert b.status_code == 201
        e = open_episode(b.json()["id"], "ChronicDiseaseManagement", start_date="2024-01-01")
        assert e.status_code == 201
        eid = e.json()["id"]
        patch_episode(eid, "Escalated", None)     # now Escalated
        patch_episode(eid, "Closed", "2024-06-01") # now Closed

        r1 = safe_request("post", api("/api/reports/state-public-health"),
                          json={"performanceYear": STATE_YEAR})
        assert r1.status_code == 200
        # Episode ended as Closed, not Escalated - count must be unchanged
        assert r1.json()["escalatedEpisodes"] == before