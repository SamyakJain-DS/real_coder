import { describe, it, expect } from "vitest";
import { loadModule, defaultTheme, FENCE, fenceBlock } from "./helpers";

function captureError(fn: () => any): { thrown: boolean; isError: boolean; message: string } {
  try {
    fn();
    return { thrown: false, isError: false, message: "" };
  } catch (e: any) {
    return {
      thrown: true,
      isError: e instanceof Error,
      message: e instanceof Error ? e.message : String(e),
    };
  }
}

describe("Parse errors - Deterministic Behavior Contract #2", () => {
  it("E1: throws Error with message MARKDOWN_INPUT_EMPTY when input is empty", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const r = captureError(() => compiler.parse(""));
      if (!r.thrown) throw new Error("did not throw on empty input");
      if (!r.isError) throw new Error("thrown value is not Error instance");
      if (r.message !== "MARKDOWN_INPUT_EMPTY")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E2: throws MARKDOWN_INPUT_EMPTY when input is whitespace-only", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const r = captureError(() => compiler.parse("   \n\t  \n   "));
      if (!r.thrown) throw new Error("did not throw on whitespace-only input");
      if (!r.isError) throw new Error("thrown value is not Error instance");
      if (r.message !== "MARKDOWN_INPUT_EMPTY")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E3: throws SLIDE_TITLE_MISSING when a slide lacks a level-1 heading", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const r = captureError(() =>
        compiler.parse("just some body text without a heading"),
      );
      if (!r.thrown) throw new Error("did not throw");
      if (!r.isError) throw new Error("thrown value is not Error instance");
      if (r.message !== "SLIDE_TITLE_MISSING")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E4: throws SPEAKER_NOTES_BLOCK_UNCLOSED when `:::notes` has no matching `:::`", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const r = captureError(() =>
        compiler.parse("# T\nbody\n:::notes\nopen but never closed"),
      );
      if (!r.thrown) throw new Error("did not throw");
      if (!r.isError) throw new Error("thrown value is not Error instance");
      if (r.message !== "SPEAKER_NOTES_BLOCK_UNCLOSED")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E5: throws SPEAKER_NOTES_BLOCK_DUPLICATE when a slide has more than one `:::notes` block", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = [
        "# T",
        ":::notes",
        "first",
        ":::",
        "body",
        ":::notes",
        "second",
        ":::",
      ].join("\n");
      const r = captureError(() => compiler.parse(md));
      if (!r.thrown) throw new Error("did not throw");
      if (!r.isError) throw new Error("thrown value is not Error instance");
      if (r.message !== "SPEAKER_NOTES_BLOCK_DUPLICATE")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E6: throws CODE_BLOCK_LANGUAGE_MISSING when an opening fence has no language tag", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = `# T\n${FENCE}\nconst x = 1;\n${FENCE}`;
      const r = captureError(() => compiler.parse(md));
      if (!r.thrown) throw new Error("did not throw");
      if (!r.isError) throw new Error("thrown value is not Error instance");
      if (r.message !== "CODE_BLOCK_LANGUAGE_MISSING")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E7: priority - empty input wins over title missing (Deterministic #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const r = captureError(() => compiler.parse("\n\n\n"));
      if (r.message !== "MARKDOWN_INPUT_EMPTY")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E8: priority - title missing wins over notes/code violations on the same slide", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = [
        "no title here",
        ":::notes",
        "left open",
        FENCE,
        "x",
        FENCE,
      ].join("\n");
      const r = captureError(() => compiler.parse(md));
      if (r.message !== "SLIDE_TITLE_MISSING")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E9: priority - notes-unclosed wins over notes-duplicate / langless fence on the same slide", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = [
        "# T",
        ":::notes",
        "open but never closed",
        FENCE,
        "x",
        FENCE,
      ].join("\n");
      const r = captureError(() => compiler.parse(md));
      if (r.message !== "SPEAKER_NOTES_BLOCK_UNCLOSED")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E10: priority - notes-duplicate wins over langless fence on the same slide", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = [
        "# T",
        ":::notes",
        "a",
        ":::",
        ":::notes",
        "b",
        ":::",
        FENCE,
        "x",
        FENCE,
      ].join("\n");
      const r = captureError(() => compiler.parse(md));
      if (r.message !== "SPEAKER_NOTES_BLOCK_DUPLICATE")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("E11: priority - earlier-source slide's error wins over a later slide's error", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = [
        "no title for slide one",
        "---",
        "# Slide Two",
        FENCE,
        "x",
        FENCE,
      ].join("\n");
      const r = captureError(() => compiler.parse(md));
      if (r.message !== "SLIDE_TITLE_MISSING")
        throw new Error(`message: ${JSON.stringify(r.message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});
