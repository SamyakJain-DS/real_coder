import json
import os
import sys
import time
from datetime import datetime, timedelta

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _now_iso():
    return datetime.utcnow().isoformat()


def _get_client():
    try:
        from app import create_app
    except ImportError:
        pytest.fail("Could not import create_app from app module")
    app = create_app()
    app.config["TESTING"] = True
    return app.test_client()


def _create_rule(client, expression, window_seconds=60, threshold=1, cooldown_seconds=0):
    return client.post("/rules", json={
        "expression": expression,
        "window_seconds": window_seconds,
        "threshold": threshold,
        "cooldown_seconds": cooldown_seconds,
    })


def _send_event(client, user_id, payload, timestamp=None):
    body = {"user_id": user_id, "timestamp": timestamp or _now_iso()}
    body.update(payload)
    return client.post("/events", json=body)


@pytest.fixture(autouse=True)
def _cleanup_firings_log():
    if os.path.exists("firings.log"):
        os.remove("firings.log")
    yield
    if os.path.exists("firings.log"):
        os.remove("firings.log")



# ===================================================================
# 2. POST /rules
# ===================================================================

class TestPostRules:

    def test_create_rule_returns_201(self):
        client = _get_client()
        resp = _create_rule(client, "action = 'login_failed'")
        assert resp.status_code == 201

    def test_create_rule_response_contains_rule_object(self):
        client = _get_client()
        resp = _create_rule(
            client, "action = 'login_failed'",
            window_seconds=120, threshold=5, cooldown_seconds=60
        )
        data = resp.get_json()
        rule = data["rule"]
        assert "rule_id" in rule
        assert rule["expression"] == "action = 'login_failed'"
        assert rule["window_seconds"] == 120
        assert rule["threshold"] == 5
        assert rule["cooldown_seconds"] == 60

    def test_create_rule_assigns_unique_rule_id(self):
        import uuid
        client = _get_client()
        resp1 = _create_rule(client, "action = 'login_failed'")
        resp2 = _create_rule(client, "action = 'login_success'")
        id1 = resp1.get_json()["rule"]["rule_id"]
        id2 = resp2.get_json()["rule"]["rule_id"]
        assert id1 != id2
        # Both must be valid UUID strings
        uuid.UUID(id1)
        uuid.UUID(id2)

    def test_create_rule_invalid_expression_returns_400(self):
        client = _get_client()
        resp = _create_rule(client, "=== INVALID ===")
        assert resp.status_code == 400
        data = resp.get_json()
        assert data.get("error") == "invalid expression"


# ===================================================================
# 3. GET /rules
# ===================================================================

class TestGetRules:

    def test_get_rules_initially_empty(self):
        client = _get_client()
        resp = client.get("/rules")
        assert resp.status_code == 200
        data = resp.get_json()
        assert "rules" in data
        assert isinstance(data["rules"], list)
        assert len(data["rules"]) == 0

    def test_get_rules_returns_created_rules(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'")
        _create_rule(client, "status != 'ok'")
        resp = client.get("/rules")
        data = resp.get_json()
        assert len(data["rules"]) == 2


# ===================================================================
# 4. DELETE /rules/<rule_id>
# ===================================================================

class TestDeleteRules:

    def test_delete_existing_rule_returns_200(self):
        client = _get_client()
        create_resp = _create_rule(client, "action = 'login_failed'")
        rule_id = create_resp.get_json()["rule"]["rule_id"]
        resp = client.delete(f"/rules/{rule_id}")
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["deleted"] == rule_id

    def test_delete_nonexistent_rule_returns_404(self):
        client = _get_client()
        resp = client.delete("/rules/nonexistent-id-12345")
        assert resp.status_code == 404
        assert resp.get_json().get("error") == "not found"

    def test_delete_rule_removes_it_from_list(self):
        client = _get_client()
        create_resp = _create_rule(client, "action = 'login_failed'")
        rule_id = create_resp.get_json()["rule"]["rule_id"]
        client.delete(f"/rules/{rule_id}")
        resp = client.get("/rules")
        ids = [r["rule_id"] for r in resp.get_json()["rules"]]
        assert rule_id not in ids


# ===================================================================
# 5. POST /events - ingestion basics
# ===================================================================

class TestPostEvents:

    def test_ingest_event_returns_200(self):
        client = _get_client()
        resp = _send_event(client, "user1", {"action": "login_failed"})
        assert resp.status_code == 200

    def test_ingest_event_response_contains_status_and_firings(self):
        client = _get_client()
        resp = _send_event(client, "user1", {"action": "login_failed"})
        data = resp.get_json()
        assert data.get("status") == "ok"
        assert "firings" in data
        assert isinstance(data["firings"], list)

    def test_ingest_event_past_timestamp_skew_rejected(self):
        client = _get_client()
        far_past = (datetime.utcnow() - timedelta(seconds=600)).isoformat()
        resp = _send_event(client, "user1", {"action": "login_failed"}, timestamp=far_past)
        assert resp.status_code == 422
        data = resp.get_json()
        assert "error" in data

    def test_ingest_event_past_timestamp_skew_error_message(self):
        client = _get_client()
        far_past = (datetime.utcnow() - timedelta(seconds=600)).isoformat()
        resp = _send_event(client, "user1", {"action": "login_failed"}, timestamp=far_past)
        assert resp.status_code == 422
        # Prompt mandates this exact error body
        assert resp.get_json().get("error") == "timestamp skew exceeds 300s"

    def test_ingest_event_future_timestamp_skew_rejected(self):
        client = _get_client()
        far_future = (datetime.utcnow() + timedelta(seconds=600)).isoformat()
        resp = _send_event(client, "user1", {"action": "login_failed"}, timestamp=far_future)
        assert resp.status_code == 422

    def test_ingest_event_within_skew_accepted(self):
        client = _get_client()
        within_skew = (datetime.utcnow() - timedelta(seconds=100)).isoformat()
        resp = _send_event(client, "user1", {"action": "login_failed"}, timestamp=within_skew)
        assert resp.status_code == 200


# ===================================================================
# 6. Rule evaluation
# ===================================================================

class TestRuleEvaluation:

    def test_rule_fires_when_threshold_exceeded(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=2, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        resp = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) > 0

    def test_rule_does_not_fire_below_threshold(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=5, cooldown_seconds=0)
        resp = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) == 0

    def test_non_matching_events_do_not_count(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=2, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_success"})
        _send_event(client, "user1", {"action": "login_success"})
        resp = _send_event(client, "user1", {"action": "login_success"})
        assert len(resp.get_json()["firings"]) == 0

    def test_different_users_have_separate_counts(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=2, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        resp = _send_event(client, "user2", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) == 0

    def test_firing_response_contains_expected_fields(self):
        client = _get_client()
        resp_rule = _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        rule_id = resp_rule.get_json()["rule"]["rule_id"]
        _send_event(client, "user1", {"action": "login_failed"})
        resp = _send_event(client, "user1", {"action": "login_failed"})
        data = resp.get_json()
        assert len(data["firings"]) > 0
        firing = data["firings"][0]
        assert firing["rule_id"] == rule_id
        assert firing["user_id"] == "user1"
        assert "fired_at" in firing
        assert "matched_count" in firing

    def test_newly_created_rule_evaluates_existing_events(self):
        client = _get_client()
        for _ in range(4):
            _send_event(client, "user1", {"action": "login_failed"})
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=3, cooldown_seconds=0)
        resp = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) > 0

    def test_and_binds_more_tightly_than_or(self):
        # Expression: "a = '1' OR b = '2' AND c = '3'"
        # Correct (AND > OR): a='1' OR (b='2' AND c='3')
        #   Event: a='1', b='2', c='x' -> True OR (True AND False) = True -> fires
        # Wrong (left-to-right OR first): (a='1' OR b='2') AND c='3'
        #   Event: a='1', b='2', c='x' -> (True OR True) AND False = False -> no fire
        client = _get_client()
        _create_rule(client, "a = '1' OR b = '2' AND c = '3'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"a": "1", "b": "2", "c": "x"})
        resp = _send_event(client, "user1", {"a": "1", "b": "2", "c": "x"})
        assert len(resp.get_json()["firings"]) > 0

    def test_non_castable_numeric_rhs_evaluates_to_false(self):
        client = _get_client()
        # RHS 'abc' cannot be cast to float - expression must evaluate to False
        _create_rule(client, "response_time > 'abc'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"response_time": 9999})
        resp = _send_event(client, "user1", {"response_time": 9999})
        assert len(resp.get_json()["firings"]) == 0

    def test_string_equality_is_case_sensitive(self):
        client = _get_client()
        _create_rule(client, "action = 'Login_Failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        resp = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) == 0

    def test_like_operator_matches_events(self):
        client = _get_client()
        _create_rule(client, "path LIKE '/api/%'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"path": "/api/users"})
        resp = _send_event(client, "user1", {"path": "/api/users"})
        assert len(resp.get_json()["firings"]) > 0

    def test_like_operator_non_matching_does_not_fire(self):
        client = _get_client()
        _create_rule(client, "path LIKE '/api/%'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"path": "/home"})
        resp = _send_event(client, "user1", {"path": "/home"})
        assert len(resp.get_json()["firings"]) == 0

    def test_like_operator_leading_wildcard(self):
        client = _get_client()
        _create_rule(client, "msg LIKE '%error'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"msg": "critical_error"})
        resp = _send_event(client, "user1", {"msg": "critical_error"})
        assert len(resp.get_json()["firings"]) > 0

    def test_like_operator_interior_wildcard(self):
        client = _get_client()
        _create_rule(client, "code LIKE 'err%code'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"code": "err_timeout_code"})
        resp = _send_event(client, "user1", {"code": "err_timeout_code"})
        assert len(resp.get_json()["firings"]) > 0

    def test_like_operator_is_case_sensitive(self):
        client = _get_client()
        _create_rule(client, "path LIKE 'API%'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"path": "/api/users"})
        resp = _send_event(client, "user1", {"path": "/api/users"})
        assert len(resp.get_json()["firings"]) == 0

    def test_absent_field_in_expression_evaluates_to_false(self):
        client = _get_client()
        _create_rule(client, "missing_field = 'value'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})  # missing_field absent
        resp = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) == 0

    def test_parenthetical_grouping_overrides_default_precedence(self):
        client = _get_client()
        # (a = '1' OR b = '2') AND c = '3'
        # With parens: (True OR True) AND False = False -> no fire
        # Without parens (AND > OR): True OR (True AND False) = True -> fire
        _create_rule(client, "(a = '1' OR b = '2') AND c = '3'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"a": "1", "b": "2", "c": "x"})
        resp = _send_event(client, "user1", {"a": "1", "b": "2", "c": "x"})
        assert len(resp.get_json()["firings"]) == 0

    def test_rule_does_not_fire_when_count_equals_threshold(self):
        client = _get_client()
        # Threshold is strict: count must EXCEED threshold, not merely equal it
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=3, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        resp = _send_event(client, "user1", {"action": "login_failed"})
        # count == threshold (3 == 3) must NOT fire
        assert len(resp.get_json()["firings"]) == 0


# ===================================================================
# 7. DSL operator correctness
# ===================================================================

class TestDSLOperators:

    def test_inequality_fires_for_differing_values(self):
        client = _get_client()
        _create_rule(client, "status != 'ok'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"status": "error"})
        resp = _send_event(client, "user1", {"status": "error"})
        assert len(resp.get_json()["firings"]) > 0

    def test_inequality_does_not_fire_for_equal_values(self):
        client = _get_client()
        _create_rule(client, "status != 'ok'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"status": "ok"})
        resp = _send_event(client, "user1", {"status": "ok"})
        assert len(resp.get_json()["firings"]) == 0

    def test_greater_than_fires_when_value_exceeds_rhs(self):
        client = _get_client()
        _create_rule(client, "response_time > 5000", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"response_time": 6000})
        resp = _send_event(client, "user1", {"response_time": 6000})
        assert len(resp.get_json()["firings"]) > 0

    def test_greater_than_does_not_fire_when_value_below_rhs(self):
        client = _get_client()
        _create_rule(client, "response_time > 5000", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"response_time": 4000})
        resp = _send_event(client, "user1", {"response_time": 4000})
        assert len(resp.get_json()["firings"]) == 0

    def test_less_than_fires_when_value_below_rhs(self):
        client = _get_client()
        _create_rule(client, "count < 10", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"count": 5})
        resp = _send_event(client, "user1", {"count": 5})
        assert len(resp.get_json()["firings"]) > 0

    def test_less_than_does_not_fire_when_value_above_rhs(self):
        client = _get_client()
        _create_rule(client, "count < 10", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"count": 15})
        resp = _send_event(client, "user1", {"count": 15})
        assert len(resp.get_json()["firings"]) == 0

    def test_greater_equal_fires_at_boundary_value(self):
        client = _get_client()
        _create_rule(client, "retries >= 3", window_seconds=300, threshold=1, cooldown_seconds=0)
        # value exactly equal to RHS must fire (>= includes equality)
        _send_event(client, "user1", {"retries": 3})
        resp = _send_event(client, "user1", {"retries": 3})
        assert len(resp.get_json()["firings"]) > 0

    def test_less_equal_fires_at_boundary_value(self):
        client = _get_client()
        _create_rule(client, "value <= 100", window_seconds=300, threshold=1, cooldown_seconds=0)
        # value exactly equal to RHS must fire (<= includes equality)
        _send_event(client, "user1", {"value": 100})
        resp = _send_event(client, "user1", {"value": 100})
        assert len(resp.get_json()["firings"]) > 0


# ===================================================================
# 7. Throttling
# ===================================================================

class TestThrottling:

    def test_throttle_prevents_repeated_firing(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=9999)
        _send_event(client, "user1", {"action": "login_failed"})
        resp1 = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp1.get_json()["firings"]) > 0  # First firing
        resp2 = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp2.get_json()["firings"]) == 0  # Throttled

    def test_throttle_is_per_user(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=9999)
        # user1 fires and is then throttled
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        # user2 has an independent throttle state and should be able to fire
        _send_event(client, "user2", {"action": "login_failed"})
        resp = _send_event(client, "user2", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) > 0

    def test_throttle_zero_cooldown_allows_repeated_firing(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        resp1 = _send_event(client, "user1", {"action": "login_failed"})
        resp2 = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp1.get_json()["firings"]) > 0
        assert len(resp2.get_json()["firings"]) > 0


# ===================================================================
# 8. GET /firings
# ===================================================================

class TestGetFirings:

    def test_get_firings_initially_empty(self):
        client = _get_client()
        resp = client.get("/firings")
        assert resp.status_code == 200
        data = resp.get_json()
        assert "firings" in data
        assert isinstance(data["firings"], list)
        assert len(data["firings"]) == 0

    def test_get_firings_returns_recorded_firings(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        resp = client.get("/firings")
        assert len(resp.get_json()["firings"]) > 0

    def test_firings_entry_contains_required_fields(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        resp = client.get("/firings")
        entry = resp.get_json()["firings"][0]
        assert "rule_id" in entry
        assert "user_id" in entry
        assert "fired_at" in entry
        assert "matched_count" in entry
        assert "window_events" in entry

    def test_firings_window_events_contain_full_event_data(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        resp = client.get("/firings")
        entry = resp.get_json()["firings"][0]
        assert len(entry["window_events"]) > 0
        event = entry["window_events"][0]
        assert "user_id" in event
        assert "timestamp" in event
        assert "ingested_at" in event
        assert "action" in event  # arbitrary payload field must be preserved

    def test_firings_filter_by_rule_id(self):
        client = _get_client()
        resp_r1 = _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _create_rule(client, "status != 'ok'", window_seconds=300, threshold=1, cooldown_seconds=0)
        rule_id_1 = resp_r1.get_json()["rule"]["rule_id"]
        _send_event(client, "user1", {"action": "login_failed", "status": "error"})
        _send_event(client, "user1", {"action": "login_failed", "status": "error"})
        resp = client.get(f"/firings?rule_id={rule_id_1}")
        data = resp.get_json()
        assert len(data["firings"]) > 0
        for f in data["firings"]:
            assert f["rule_id"] == rule_id_1

    def test_firings_filter_by_user_id(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user2", {"action": "login_failed"})
        _send_event(client, "user2", {"action": "login_failed"})
        resp = client.get("/firings?user_id=user1")
        data = resp.get_json()
        assert len(data["firings"]) > 0
        for f in data["firings"]:
            assert f["user_id"] == "user1"

    def test_firings_limit_parameter(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        for _ in range(5):
            _send_event(client, "user1", {"action": "login_failed"})
        resp = client.get("/firings?limit=2")
        assert len(resp.get_json()["firings"]) <= 2

    def test_firings_default_limit_is_50(self):
        # Generate 60 firings (one per user on their 2nd event, threshold=1)
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        for i in range(60):
            _send_event(client, f"user{i}", {"action": "login_failed"})
            _send_event(client, f"user{i}", {"action": "login_failed"})
        resp = client.get("/firings")
        assert len(resp.get_json()["firings"]) == 50

    def test_firings_returned_newest_first(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        # Fire for three separate users with small sleeps so fired_at values are strictly distinct
        for i in range(3):
            _send_event(client, f"user{i}", {"action": "login_failed"})
            _send_event(client, f"user{i}", {"action": "login_failed"})
            time.sleep(0.05)
        resp = client.get("/firings")
        firings = resp.get_json()["firings"]
        assert len(firings) >= 2
        fired_ats = [f["fired_at"] for f in firings]
        # Newest-first: each entry must be strictly >= the next (timestamps are distinct)
        for i in range(len(fired_ats) - 1):
            assert fired_ats[i] >= fired_ats[i + 1]


# ===================================================================
# 9. Firing log persistence
# ===================================================================

class TestFiringLogPersistence:

    def test_firing_is_written_to_log_file(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        assert os.path.exists("firings.log")
        with open("firings.log", "r") as f:
            lines = [line.strip() for line in f if line.strip()]
        assert len(lines) > 0
        record = json.loads(lines[0])
        assert "rule_id" in record
        assert "user_id" in record
        assert "fired_at" in record
        assert "matched_count" in record
        assert "window_events" in record

    def test_firings_log_truncated_on_create_app(self):
        # First app instance: fire a rule to populate firings.log
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        assert os.path.exists("firings.log")
        with open("firings.log") as f:
            assert len(f.read()) > 0
        # Second create_app() invocation must truncate firings.log to zero bytes
        _get_client()
        assert os.path.exists("firings.log")
        assert os.path.getsize("firings.log") == 0


# ===================================================================
# 10. Sliding window behavior
# ===================================================================

class TestSlidingWindow:

    def test_events_outside_window_do_not_count(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=1, threshold=2, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        time.sleep(2)
        resp = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) == 0

    def test_events_inside_window_are_counted(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=5, threshold=2, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        resp = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) > 0

    def test_events_expire_after_window_elapses(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=2, threshold=2, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        time.sleep(3)
        resp = _send_event(client, "user1", {"action": "login_failed"})
        assert len(resp.get_json()["firings"]) == 0


# ===================================================================
# 11. Deleted rule does not fire
# ===================================================================

class TestDeletedRuleNoFiring:

    def test_deleted_rule_does_not_fire(self):
        client = _get_client()
        resp_rule = _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        rule_id = resp_rule.get_json()["rule"]["rule_id"]
        _send_event(client, "user1", {"action": "login_failed"})
        client.delete(f"/rules/{rule_id}")
        resp = _send_event(client, "user1", {"action": "login_failed"})
        fired_ids = [f["rule_id"] for f in resp.get_json()["firings"]]
        assert rule_id not in fired_ids


# ===================================================================
# 12. Multiple rules evaluated simultaneously
# ===================================================================

class TestMultipleRules:

    def test_multiple_rules_can_fire_on_same_event(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _create_rule(client, "region = 'eu'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed", "region": "eu"})
        resp = _send_event(client, "user1", {"action": "login_failed", "region": "eu"})
        assert len(resp.get_json()["firings"]) >= 2


# ===================================================================
# 13. Matched count accuracy
# ===================================================================

class TestMatchedCount:

    def test_matched_count_reflects_matching_events(self):
        client = _get_client()
        _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=2, cooldown_seconds=0)
        _send_event(client, "user1", {"action": "login_failed"})
        _send_event(client, "user1", {"action": "login_failed"})
        resp = _send_event(client, "user1", {"action": "login_failed"})
        data = resp.get_json()
        assert len(data["firings"]) > 0
        assert data["firings"][0]["matched_count"] == 3


# ===================================================================
# 14. Shared timeline
# ===================================================================

class TestSharedTimeline:

    def test_deleting_rule_keeps_events_for_other_rules(self):
        client = _get_client()
        resp_r1 = _create_rule(client, "action = 'login_failed'", window_seconds=300, threshold=1, cooldown_seconds=0)
        _create_rule(client, "action = 'login_failed' AND region = 'eu'", window_seconds=300, threshold=1, cooldown_seconds=0)
        rule_id_1 = resp_r1.get_json()["rule"]["rule_id"]
        _send_event(client, "user1", {"action": "login_failed", "region": "eu"})
        client.delete(f"/rules/{rule_id_1}")
        resp = _send_event(client, "user1", {"action": "login_failed", "region": "eu"})
        assert len(resp.get_json()["firings"]) > 0