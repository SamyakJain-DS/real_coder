import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { loadModule } from "./helpers";

const HERE = dirname(fileURLToPath(import.meta.url));

describe("Public API Surface - Named ESM Exports", () => {

  it("AS2: every required name is reachable from the entry point as a named export", async () => {
    let pass = false;
    let info = "";
    try {
      const { execSync } = await import("node:child_process");
      const { writeFileSync, unlinkSync, existsSync } = await import("node:fs");
      const { join, dirname } = await import("node:path");
      const { fileURLToPath } = await import("node:url");

      const HERE = dirname(fileURLToPath(import.meta.url));

      let projectRoot = "";
      let cur = HERE;
      for (let i = 0; i < 6; i++) {
        if (existsSync(join(cur, "src", "index.ts"))) {
          projectRoot = cur;
          break;
        }
        cur = join(cur, "..");
      }
      if (!projectRoot)
        throw new Error("src/index.ts not found - implementation missing");

      const probePath = join(HERE, "__probe_exports_tmp__.ts");
      const tscfgPath = join(HERE, "__probe_tsconfig_tmp__.json");

      writeFileSync(
        probePath,
        [
          "import type {",
          "  Slide,",
          "  SlideImage,",
          "  SlideCodeBlock,",
          "  SlideDeck,",
          "  DeckTheme,",
          "  DeckArtifacts,",
          '} from "../src/index";',
          'import { SlideDeckCompiler } from "../src/index";',
          "// Reference every name so the compiler cannot prune them as unused.",
          "type _AllTypes = Slide & SlideImage & SlideCodeBlock &",
          "                 SlideDeck & DeckTheme & DeckArtifacts;",
          "declare const _: _AllTypes;",
          "const _cls = SlideDeckCompiler; void _cls;",
        ].join("\n"),
        "utf8",
      );

      writeFileSync(
        tscfgPath,
        JSON.stringify({
          extends: "./tsconfig.json",
          include: ["__probe_exports_tmp__.ts"],
          compilerOptions: { noEmit: true },
        }),
        "utf8",
      );

      try {
        execSync(`npx tsc --project "${tscfgPath}"`, {
          cwd: HERE,
          stdio: "pipe",
        });
        pass = true;
      } catch (e: any) {
        const out = [e.stdout, e.stderr]
          .filter(Boolean)
          .map((b: Buffer) => b.toString())
          .join("\n")
          .slice(0, 1_000);
        throw new Error(
          `tsc compile probe failed - one or more required names not exported:\n${out}`,
        );
      } finally {
        for (const p of [probePath, tscfgPath]) {
          try {
            unlinkSync(p);
          } catch {}
        }
      }
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("AS3: package configuration declares the ECMAScript Modules format", async () => {
    let pass = false;
    let info = "";
    try {
      const inspected: string[] = [];

      const hasEsmExportsCondition = (exportsField: any): boolean => {
        if (!exportsField || typeof exportsField !== "object") return false;
        const queue: any[] = [exportsField];
        while (queue.length > 0) {
          const node = queue.shift();
          if (!node) continue;
          if (typeof node === "string") {
            if (/\.(mjs|esm\.js)$/i.test(node)) return true;
            continue;
          }
          if (Array.isArray(node)) {
            for (const item of node) queue.push(item);
            continue;
          }
          if (typeof node === "object") {
            for (const key of Object.keys(node)) {
              if (key === "import" || key === "module") return true;
              queue.push(node[key]);
            }
          }
        }
        return false;
      };

      const isEsmEntryPath = (p: any): boolean =>
        typeof p === "string" && /\.(mjs|esm\.js)$/i.test(p);

      let cur = HERE;
      let foundEsm = false;
      let foundForm = "";
      for (let i = 0; i < 6; i++) {
        const candidate = join(cur, "..", "package.json");
        try {
          const raw = readFileSync(candidate, "utf8");
          inspected.push(candidate);
          const pkg = JSON.parse(raw);
          if (pkg && typeof pkg === "object") {
            if (pkg.type === "module") {
              foundEsm = true;
              foundForm = `"type": "module" in ${candidate}`;
              break;
            }
            if (typeof pkg.module === "string" && pkg.module.length > 0) {
              foundEsm = true;
              foundForm = `"module" field in ${candidate}`;
              break;
            }
            if (isEsmEntryPath(pkg.main)) {
              foundEsm = true;
              foundForm = `"main" points at ESM build (${pkg.main}) in ${candidate}`;
              break;
            }
            if (hasEsmExportsCondition(pkg.exports)) {
              foundEsm = true;
              foundForm = `"exports" map declares ESM in ${candidate}`;
              break;
            }
          }
        } catch {
          // not a package.json at this level; try one level up
        }
        cur = join(cur, "..");
      }
      if (!foundEsm)
        throw new Error(
          `no ESM declaration found in any reachable package.json (inspected: ${inspected.join(", ") || "<none>"}). Accepted forms: \`"type": "module"\`, \`"module"\` field, \`"main"\` pointing at .mjs/.esm.js, or \`"exports"\` map with an \`import\`/\`module\` condition or .mjs path.`,
        );
      // Sanity: surface which form satisfied the assertion when running with
      // verbose reporters.
      void foundForm;
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

});