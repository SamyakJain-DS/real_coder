// Tests for the public ESM API surface contract.
//
// The prompt requires that the library entry point `src/index.ts` publicly
// exposes `Slide`, `SlideImage`, `SlideCodeBlock`, `SlideDeck`, `DeckTheme`,
// `DeckArtifacts`, and `SlideDeckCompiler` so embedding applications can
// import each by name. These tests dynamically load the entry point and
// assert each symbol resolves as a named ESM export, and that the package
// configuration declares the ECMAScript Modules format.

import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { loadModule } from "./helpers";

const HERE = dirname(fileURLToPath(import.meta.url));

describe("Public API Surface — Named ESM Exports", () => {
  it("AS1: SlideDeckCompiler is a runtime named export of the library entry point", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      if (typeof mod.SlideDeckCompiler !== "function")
        throw new Error(
          `expected SlideDeckCompiler to be a class/function, got ${typeof mod.SlideDeckCompiler}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("AS2: every required name is reachable from the entry point as a named export", async () => {
    // TypeScript interfaces and types are erased at runtime, so they cannot
    // be verified via dynamic import. The correct black-box approach is a
    // tsc compile probe: a small .ts file that imports every required name
    // is compiled with --noEmit; tsc emits TS2305 and exits non-zero if any
    // name is absent from the entry point's exports.
    let pass = false;
    let info = "";
    try {
      const { execSync } = await import("node:child_process");
      const { writeFileSync, unlinkSync, existsSync } = await import("node:fs");
      const { join, dirname } = await import("node:path");
      const { fileURLToPath } = await import("node:url");

      const HERE = dirname(fileURLToPath(import.meta.url));

      // On an empty codebase src/index.ts is absent — the loop below
      // exhausts without setting projectRoot, we throw, the catch block
      // sets info, and the test reports FAILED (not ERRORED). ✓
      let projectRoot = "";
      let cur = HERE;
      for (let i = 0; i < 6; i++) {
        if (existsSync(join(cur, "src", "index.ts"))) {
          projectRoot = cur;
          break;
        }
        cur = join(cur, "..");
      }
      if (!projectRoot)
        throw new Error("src/index.ts not found — implementation missing");

      // Write a TypeScript probe file into the tests/ directory so that
      // the relative import path "../src/index" resolves correctly via the
      // same moduleResolution rules the embedding application would use.
      //
      // "import type" is used for interface/type names: TypeScript will emit
      // TS2305 ("Module has no exported member '…'") if any name is absent,
      // causing tsc to exit non-zero even though these are erased at runtime.
      // SlideDeckCompiler is imported as a value (verified here for tsc;
      // runtime presence is already asserted by AS1/AS4).
      const probePath = join(HERE, "__probe_exports_tmp__.ts");
      const tscfgPath = join(HERE, "__probe_tsconfig_tmp__.json");

      writeFileSync(
        probePath,
        [
          "import type {",
          "  Slide,",
          "  SlideImage,",
          "  SlideCodeBlock,",
          "  SlideDeck,",
          "  DeckTheme,",
          "  DeckArtifacts,",
          '} from "../src/index";',
          'import { SlideDeckCompiler } from "../src/index";',
          "// Reference every name so the compiler cannot prune them as unused.",
          "type _AllTypes = Slide & SlideImage & SlideCodeBlock &",
          "                 SlideDeck & DeckTheme & DeckArtifacts;",
          "declare const _: _AllTypes;",
          "const _cls = SlideDeckCompiler; void _cls;",
        ].join("\n"),
        "utf8",
      );

      // Probe-only tsconfig: extends the existing tests/tsconfig.json
      // (same compiler options and moduleResolution) but includes ONLY
      // the probe file so unrelated test files are not recompiled.
      writeFileSync(
        tscfgPath,
        JSON.stringify({
          extends: "./tsconfig.json",
          include: ["__probe_exports_tmp__.ts"],
          compilerOptions: { noEmit: true },
        }),
        "utf8",
      );

      try {
        execSync(`npx tsc --project "${tscfgPath}"`, {
          cwd: HERE,
          stdio: "pipe",
        });
        pass = true;
      } catch (e: any) {
        const out = [e.stdout, e.stderr]
          .filter(Boolean)
          .map((b: Buffer) => b.toString())
          .join("\n")
          .slice(0, 1_000);
        throw new Error(
          `tsc compile probe failed — one or more required names not exported:\n${out}`,
        );
      } finally {
        for (const p of [probePath, tscfgPath]) {
          try {
            unlinkSync(p);
          } catch {}
        }
      }
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("AS3: package configuration declares the ECMAScript Modules format", async () => {
    // The prompt accepts EITHER form for declaring ESM:
    //   (a) package.json contains `"type": "module"`, OR
    //   (b) an ESM build output is produced (signalled in package.json by an
    //       `exports` map with an `import` condition, a `module` field, or a
    //       `main`/`exports`/`module` entry pointing at a `.mjs`/`.esm.js`
    //       file).
    // We walk upward from the tests directory and accept any package.json
    // that satisfies either form.
    let pass = false;
    let info = "";
    try {
      const inspected: string[] = [];

      const hasEsmExportsCondition = (exportsField: any): boolean => {
        if (!exportsField || typeof exportsField !== "object") return false;
        const queue: any[] = [exportsField];
        while (queue.length > 0) {
          const node = queue.shift();
          if (!node) continue;
          if (typeof node === "string") {
            if (/\.(mjs|esm\.js)$/i.test(node)) return true;
            continue;
          }
          if (Array.isArray(node)) {
            for (const item of node) queue.push(item);
            continue;
          }
          if (typeof node === "object") {
            for (const key of Object.keys(node)) {
              if (key === "import" || key === "module") return true;
              queue.push(node[key]);
            }
          }
        }
        return false;
      };

      const isEsmEntryPath = (p: any): boolean =>
        typeof p === "string" && /\.(mjs|esm\.js)$/i.test(p);

      let cur = HERE;
      let foundEsm = false;
      let foundForm = "";
      for (let i = 0; i < 6; i++) {
        const candidate = join(cur, "..", "package.json");
        try {
          const raw = readFileSync(candidate, "utf8");
          inspected.push(candidate);
          const pkg = JSON.parse(raw);
          if (pkg && typeof pkg === "object") {
            if (pkg.type === "module") {
              foundEsm = true;
              foundForm = `"type": "module" in ${candidate}`;
              break;
            }
            if (typeof pkg.module === "string" && pkg.module.length > 0) {
              foundEsm = true;
              foundForm = `"module" field in ${candidate}`;
              break;
            }
            if (isEsmEntryPath(pkg.main)) {
              foundEsm = true;
              foundForm = `"main" points at ESM build (${pkg.main}) in ${candidate}`;
              break;
            }
            if (hasEsmExportsCondition(pkg.exports)) {
              foundEsm = true;
              foundForm = `"exports" map declares ESM in ${candidate}`;
              break;
            }
          }
        } catch {
          // not a package.json at this level; try one level up
        }
        cur = join(cur, "..");
      }
      if (!foundEsm)
        throw new Error(
          `no ESM declaration found in any reachable package.json (inspected: ${inspected.join(", ") || "<none>"}). Accepted forms: \`"type": "module"\`, \`"module"\` field, \`"main"\` pointing at .mjs/.esm.js, or \`"exports"\` map with an \`import\`/\`module\` condition or .mjs path.`,
        );
      // Sanity: surface which form satisfied the assertion when running with
      // verbose reporters.
      void foundForm;
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("AS4: a fresh ESM import of the entry point exposes SlideDeckCompiler with the expected method shape", async () => {
    // Beyond the existence check in AS1, this test asserts the named export
    // is usable through normal ESM `import` semantics: it can be invoked as
    // a constructor and the resulting instance has the documented methods
    // (`parse`, `renderHtml`, `renderPdf`, `compile`).
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const Ctor = mod.SlideDeckCompiler;
      if (typeof Ctor !== "function")
        throw new Error("SlideDeckCompiler is not a constructor");
      const instance = new Ctor({
        fontFamily: "Helvetica",
        backgroundColor: "#ffffff",
        textColor: "#111111",
        accentColor: "#3366ff",
        codeTheme: "github",
        slidePaddingPx: 32,
      });
      for (const name of ["parse", "renderHtml", "renderPdf", "compile"]) {
        if (typeof (instance as any)[name] !== "function")
          throw new Error(`SlideDeckCompiler missing method: ${name}`);
      }
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});