"""Tests for the saturation metric defined in section 6 of the prompt.

The cases below cover the three branches the prompt prescribes:

* a donor with **exactly one** historical donation,
* a donor whose donations all share a **single date** (so
  ``mean_inter_donation_days`` collapses to 0), and
* the **general** ``recent_count / expected_count`` formula.
"""

import pandas as pd
import pytest


def test_single_donation_saturation_equals_recent_count(
    DonorPipeline, sample_donations, make_donations
):
    """A donor with exactly one historical donation in the recent 90-day
    window receives ``saturation_score == recent_count`` (here 1)."""

    extra = make_donations(
        [
            {
                "donor_id": "SINGLE_DONOR",
                "donation_amount": 75.0,
                "date": pd.Timestamp("2024-10-12"),
                "campaign": "fall",
                "channel": "email",
            }
        ]
    )
    df = pd.concat([sample_donations, extra], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    row = out.loc[out["donor_id"] == "SINGLE_DONOR"].iloc[0]
    assert row["saturation_score"] == pytest.approx(1.0)


def test_same_day_donations_saturation_equals_recent_count(
    DonorPipeline, sample_donations, make_donations
):
    """When every donation of a donor lands on the same date, the mean
    inter-donation distance collapses to zero and ``saturation_score``
    falls back to ``recent_count`` (here 3)."""

    same_day = pd.Timestamp("2024-10-22")
    extras = make_donations(
        [
            {
                "donor_id": "SAMEDAY_DONOR",
                "donation_amount": amount,
                "date": same_day,
                "campaign": "fall",
                "channel": "email",
            }
            for amount in (25.0, 50.0, 75.0)
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    row = out.loc[out["donor_id"] == "SAMEDAY_DONOR"].iloc[0]
    assert row["saturation_score"] == pytest.approx(3.0)


def test_general_saturation_score_matches_formula(
    DonorPipeline, sample_donations, make_donations
):
    """For donors with multiple distinct donation dates,
    ``saturation_score`` equals ``recent_count / (90 / mean_inter_days)``.

    This donor receives donations 89, 59 and 29 days before the default
    ``as_of_date`` (2024-12-01). All three fall inside the recent
    90-day window so ``recent_count == 3``. The two consecutive
    inter-donation gaps are 30 days each, giving
    ``mean_inter_donation_days == 30`` and ``expected_count == 90/30 == 3``.
    The expected score is therefore ``3 / 3 == 1.0``.
    """

    as_of_date = pd.Timestamp("2024-12-01")
    extras = make_donations(
        [
            {
                "donor_id": "GENERAL_DONOR",
                "donation_amount": 50.0,
                "date": as_of_date - pd.Timedelta(days=offset),
                "campaign": "fall",
                "channel": "email",
            }
            for offset in (89, 59, 29)
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    row = out.loc[out["donor_id"] == "GENERAL_DONOR"].iloc[0]
    assert row["saturation_score"] == pytest.approx(1.0)


def test_general_saturation_score_with_nontrivial_ratio(
    DonorPipeline, sample_donations, make_donations
):
    """A second general-formula case with a non-degenerate score.

    Donations land at 75, 60, 45, 30 and 15 days before the default
    ``as_of_date`` (2024-12-01). All five sit inside the half-open
    recent window ``(as_of - 90d, as_of]``, so ``recent_count == 5``.
    The four inter-donation gaps are 15 days each, so
    ``mean_inter_donation_days == 15`` and ``expected_count == 90/15 == 6``.
    The expected score is ``5 / 6``. This guards against
    implementations that hard-code ``saturation_score == 1.0`` for
    general donors or that compute ``mean`` via the wrong reduction.
    """

    as_of_date = pd.Timestamp("2024-12-01")
    extras = make_donations(
        [
            {
                "donor_id": "GENERAL_DONOR_2",
                "donation_amount": 50.0,
                "date": as_of_date - pd.Timedelta(days=offset),
                "campaign": "fall",
                "channel": "email",
            }
            for offset in (75, 60, 45, 30, 15)
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    row = out.loc[out["donor_id"] == "GENERAL_DONOR_2"].iloc[0]
    assert row["saturation_score"] == pytest.approx(5.0 / 6.0)


def test_recent_count_excludes_donation_at_exactly_90_days_before_as_of(
    DonorPipeline, sample_donations, make_donations
):
    """The recent window is half-open: ``(as_of - 90d, as_of]``. A
    single donation at exactly ``as_of - 90d`` is therefore *excluded*
    from ``recent_count``. With the single-donation rule
    ``saturation_score == recent_count``, the expected score is 0.
    Guards against off-by-one implementations that use a closed left
    boundary (``[as_of - 90d, as_of]``).
    """

    as_of_date = pd.Timestamp("2024-12-01")
    extras = make_donations(
        [
            {
                "donor_id": "EDGE_OUT",
                "donation_amount": 50.0,
                "date": as_of_date - pd.Timedelta(days=90),
                "campaign": "fall",
                "channel": "email",
            }
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    row = out.loc[out["donor_id"] == "EDGE_OUT"].iloc[0]
    assert row["saturation_score"] == pytest.approx(0.0)


def test_recent_count_includes_donation_at_89_days_before_as_of(
    DonorPipeline, sample_donations, make_donations
):
    """A single donation at ``as_of - 89d`` lies strictly inside the
    half-open window ``(as_of - 90d, as_of]`` and therefore contributes
    to ``recent_count``. With the single-donation rule the expected
    score is exactly 1.0."""

    as_of_date = pd.Timestamp("2024-12-01")
    extras = make_donations(
        [
            {
                "donor_id": "EDGE_IN",
                "donation_amount": 50.0,
                "date": as_of_date - pd.Timedelta(days=89),
                "campaign": "fall",
                "channel": "email",
            }
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    row = out.loc[out["donor_id"] == "EDGE_IN"].iloc[0]
    assert row["saturation_score"] == pytest.approx(1.0)


def test_saturation_score_recomputed_from_rank_donors_donations(
    DonorPipeline, sample_donations, make_donations
):
    """req 38: ``saturation_score`` is computed from the donations
    DataFrame passed to ``rank_donors`` at call time, not from
    donations cached at fit time.

    Strategy: fit on ``sample_donations``, capture donor ``F001``'s
    baseline saturation, then re-rank with augmented donations that
    add three same-day donations for ``F001`` inside the recent
    90-day window. The new donations change ``F001``'s
    ``recent_count`` and ``mean_inter_donation_days``, so the
    saturation score must change. An implementation that uses
    fit-cached donations for saturation would yield the unchanged
    baseline, failing this first assertion.

    The second assertion pins the *correctness* of the recomputed
    value: the new score must match the hand-computed
    ``recent_count / (90 / mean_inter_donation_days)``. An
    implementation that recomputes from rank-time data using a wrong
    formula (e.g. dropping the same-day donations from the gap
    sequence, or using a different window) would change the score
    away from the baseline yet still fail this exact check.
    """

    pipeline = DonorPipeline().fit(sample_donations)
    out_baseline = pipeline.rank_donors(sample_donations)
    baseline_sat = (
        out_baseline.loc[out_baseline["donor_id"] == "F001", "saturation_score"]
        .iloc[0]
    )

    same_day = pd.Timestamp("2024-10-22")
    extras = make_donations(
        [
            {
                "donor_id": "F001",
                "donation_amount": amount,
                "date": same_day,
                "campaign": "fall",
                "channel": "email",
            }
            for amount in (5.0, 10.0, 15.0)
        ]
    )
    augmented = pd.concat([sample_donations, extras], ignore_index=True)

    out_augmented = pipeline.rank_donors(augmented)
    augmented_sat = (
        out_augmented.loc[out_augmented["donor_id"] == "F001", "saturation_score"]
        .iloc[0]
    )

    assert augmented_sat != pytest.approx(baseline_sat), (
        "F001's saturation_score must change when extra donations in the "
        "recent window are passed at rank-time. An implementation that "
        "caches donations from fit would emit the unchanged baseline value."
    )

    as_of = sample_donations["date"].max() - pd.Timedelta(days=30)
    f001_dates = sorted(
        augmented.loc[augmented["donor_id"] == "F001", "date"].tolist()
    )
    historical = [d for d in f001_dates if d <= as_of]
    recent = [
        d for d in historical if d > as_of - pd.Timedelta(days=90)
    ]
    recent_count = len(recent)
    gaps = [
        (historical[i] - historical[i - 1]).days
        for i in range(1, len(historical))
    ]
    if not gaps:
        expected_sat = float(recent_count)
    else:
        mean_inter = sum(gaps) / len(gaps)
        if mean_inter == 0:
            expected_sat = float(recent_count)
        else:
            expected_sat = recent_count / (90 / mean_inter)

    assert augmented_sat == pytest.approx(expected_sat), (
        f"F001's recomputed saturation_score is {augmented_sat}, but the "
        f"correct hand-computed value is {expected_sat} "
        f"(recent_count={recent_count}, gaps={gaps})."
    )


def test_recent_count_includes_donation_at_exactly_as_of_date(
    DonorPipeline, sample_donations, make_donations
):
    """The recent window ``(as_of - 90d, as_of]`` is **closed** at the
    right edge: a donation that lands exactly on ``as_of_date`` must be
    counted in ``recent_count``. Combined with the single-donation rule
    this means ``saturation_score == 1.0``. Guards against off-by-one
    implementations that use a half-open right boundary
    (``(as_of - 90d, as_of)``).
    """

    as_of_date = pd.Timestamp("2024-12-01")
    extras = make_donations(
        [
            {
                "donor_id": "EDGE_RIGHT",
                "donation_amount": 50.0,
                "date": as_of_date,
                "campaign": "fall",
                "channel": "email",
            }
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    row = out.loc[out["donor_id"] == "EDGE_RIGHT"].iloc[0]
    assert row["saturation_score"] == pytest.approx(1.0)


def test_mean_inter_donation_uses_arithmetic_mean_with_non_uniform_gaps(
    DonorPipeline, sample_donations, make_donations
):
    """req 43: ``mean_inter_donation_days`` is the **arithmetic mean** of
    the consecutive day differences, not the median, mode, geometric
    mean, or any other reduction.

    The existing general-formula tests use uniform inter-donation gaps
    (``[30, 30]`` and ``[15, 15, 15, 15]``) where the arithmetic mean
    equals the median, so they cannot distinguish the two. This test
    introduces non-uniform, non-symmetric gaps so only the arithmetic
    mean reproduces the expected value.

    Donor ``NU`` donates at offsets ``(90, 70, 20, 0)`` from
    ``as_of_date == 2024-12-01``:

    * Sorted dates: 2024-09-02, 2024-09-22, 2024-11-11, 2024-12-01.
    * Inter-donation gaps (in order): ``20, 50, 20`` days.
    * Arithmetic mean: ``(20 + 50 + 20) / 3 == 30`` -> ``expected_count == 3``.
    * ``recent_count`` (window ``(2024-09-02, 2024-12-01]``): the
      2024-09-02 donation is on the **open** left edge so it is
      excluded; the other three are inside -> ``recent_count == 3``.
    * Expected ``saturation_score == 3 / 3 == 1.0``.

    The median of ``[20, 50, 20]`` is ``20`` so a median-based
    implementation would yield ``3 / (90 / 20) == 0.667``; the
    geometric mean is ``≈ 27.14`` yielding ``≈ 0.904``. Neither
    matches ``1.0``, so the assertion isolates the arithmetic-mean
    contract.
    """

    as_of_date = pd.Timestamp("2024-12-01")
    extras = make_donations(
        [
            {
                "donor_id": "NU",
                "donation_amount": 50.0,
                "date": as_of_date - pd.Timedelta(days=offset),
                "campaign": "fall",
                "channel": "email",
            }
            for offset in (90, 70, 20, 0)
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    row = out.loc[out["donor_id"] == "NU"].iloc[0]
    assert row["saturation_score"] == pytest.approx(1.0)


def test_mean_inter_donation_uses_full_history_not_recent_window_only(
    DonorPipeline, sample_donations, make_donations
):
    """req 43: ``mean_inter_donation_days`` is computed across the
    donor's **full history** of donations made up to and including
    ``as_of_date`` - not only over donations that fall inside the
    recent 90-day window.

    Every existing general-formula test happens to place all of a
    donor's donations *inside* the recent 90-day window, so an
    implementation that erroneously restricts the mean to the recent
    window would still pass them. This test introduces a donor whose
    history straddles the recent window so the two computations
    diverge.

    Donor ``FH`` donates at offsets ``(300, 100, 30, 0)`` from
    ``as_of_date == 2024-12-01``:

    * Sorted dates: 2024-02-05, 2024-08-23, 2024-11-01, 2024-12-01.
    * Full-history inter-donation gaps: ``200, 70, 30`` -> arithmetic
      mean ``100`` -> ``expected_count == 90 / 100 == 0.9``.
    * ``recent_count`` (window ``(2024-09-02, 2024-12-01]``): only
      2024-11-01 and 2024-12-01 are inside -> ``recent_count == 2``.
    * Expected ``saturation_score == 2 / 0.9 ≈ 2.2222``.

    A "recent-window-only" implementation would see a single gap of
    ``30`` days, ``expected_count == 3``, and ``saturation_score ==
    2 / 3 ≈ 0.667`` - which fails the assertion.
    """

    as_of_date = pd.Timestamp("2024-12-01")
    extras = make_donations(
        [
            {
                "donor_id": "FH",
                "donation_amount": 50.0,
                "date": as_of_date - pd.Timedelta(days=offset),
                "campaign": "fall",
                "channel": "email",
            }
            for offset in (300, 100, 30, 0)
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(df)
    out = pipeline.rank_donors(df)

    row = out.loc[out["donor_id"] == "FH"].iloc[0]
    assert row["saturation_score"] == pytest.approx(2.0 / 0.9)


def test_saturation_uses_resolved_as_of_date_from_constructor(
    DonorPipeline, sample_donations, make_donations
):
    """req 38 combined with req 12: the saturation computation must use
    the resolved ``as_of_date`` persisted at fit time (i.e. the value
    supplied to the constructor when not ``None``), not a value
    silently re-derived from the rank-time donations DataFrame.

    Donor ``AOD_SAT`` has a single donation at 2024-08-15:

    * With **explicit** ``as_of_date == 2024-10-01`` the recent window
      is ``(2024-07-03, 2024-10-01]``, so 2024-08-15 falls inside ->
      ``recent_count == 1`` -> single-donation rule ->
      ``saturation_score == 1.0``.
    * With the **default** ``as_of_date`` (``max - 30d == 2024-12-01``)
      the recent window is ``(2024-09-02, 2024-12-01]`` and 2024-08-15
      is outside -> ``recent_count == 0`` ->
      ``saturation_score == 0.0``.

    A divergent pair of scores between the two pipelines pins that
    saturation respects the constructor-provided ``as_of_date``.
    """

    extras = make_donations(
        [
            {
                "donor_id": "AOD_SAT",
                "donation_amount": 50.0,
                "date": "2024-08-15",
                "campaign": "fall",
                "channel": "email",
            }
        ]
    )
    df = pd.concat([sample_donations, extras], ignore_index=True)

    explicit_as_of = pd.Timestamp("2024-10-01")
    out_explicit = (
        DonorPipeline(as_of_date=explicit_as_of).fit(df).rank_donors(df)
    )
    explicit_row = out_explicit.loc[out_explicit["donor_id"] == "AOD_SAT"].iloc[0]
    assert explicit_row["saturation_score"] == pytest.approx(1.0), (
        "With explicit as_of_date=2024-10-01, donation at 2024-08-15 falls "
        "inside the recent window; saturation_score must equal 1.0."
    )

    out_default = DonorPipeline().fit(df).rank_donors(df)
    default_row = out_default.loc[out_default["donor_id"] == "AOD_SAT"].iloc[0]
    assert default_row["saturation_score"] == pytest.approx(0.0), (
        "With default as_of_date=2024-12-01, donation at 2024-08-15 falls "
        "outside the recent window; saturation_score must equal 0.0."
    )
