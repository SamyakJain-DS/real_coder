import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;

public class ObjectDiffLibraryTest {

    // -------------------------------------------------------------------------
    // Reflection helpers
    // -------------------------------------------------------------------------

    private static Class<?> loadClass(String name) {
        try {
            return Class.forName(name);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    private static Object invoke(Object target, String method, Class<?>[] params, Object[] args)
            throws Exception {
        return target.getClass().getMethod(method, params).invoke(target, args);
    }

    private static Object invokeStatic(Class<?> clazz, String method, Class<?>[] params, Object[] args)
            throws Exception {
        return clazz.getMethod(method, params).invoke(null, args);
    }

    /**
     * Constructs ObjectDiffer(null) via the documented constructor signature
     * ObjectDiffer(ComparatorRegistry), passing null for no custom comparators.
     */
    private static Object newDiffer(Class<?> differClass, Class<?> registryClass) throws Exception {
        Constructor<?> ctor = differClass.getConstructor(registryClass);
        return ctor.newInstance((Object) null);
    }

    /** Loads a ChangeType enum constant by name; returns null if missing. */
    private static Object changeTypeConstant(String name) {
        try {
            Class<?> ct = Class.forName("com.objectdiff.ChangeType");
            return Enum.valueOf((Class<? extends Enum>) ct, name);
        } catch (Exception e) {
            return null;
        }
    }

    // -------------------------------------------------------------------------
    // Test model classes - no dependency on implementation package
    // -------------------------------------------------------------------------

    static class SimplePerson {
        public String name;
        public Integer age;
        public SimplePerson() {}
        public SimplePerson(String name, Integer age) { this.name = name; this.age = age; }
    }

    static class Address {
        public String city;
        public String country;
        public Address() {}
        public Address(String city, String country) { this.city = city; this.country = country; }
    }

    static class PersonWithAddress {
        public String name;
        public Address address;
        public PersonWithAddress() {}
        public PersonWithAddress(String name, Address address) {
            this.name = name; this.address = address;
        }
    }

    static class PersonWithList {
        public List<String> tags;
        public PersonWithList() {}
        public PersonWithList(List<String> tags) { this.tags = tags; }
    }

    static class PersonWithSet {
        public Set<String> roles;
        public PersonWithSet() {}
        public PersonWithSet(Set<String> roles) { this.roles = roles; }
    }

    static class PersonWithMap {
        public Map<String, String> phoneNumbers;
        public PersonWithMap() {}
        public PersonWithMap(Map<String, String> phoneNumbers) { this.phoneNumbers = phoneNumbers; }
    }

    static class NodeWithCycle {
        public String value;
        public NodeWithCycle next;
        public NodeWithCycle() {}
        public NodeWithCycle(String value) { this.value = value; }
    }

    static class CustomType {
        public double amount;
        public CustomType() {}
        public CustomType(double amount) { this.amount = amount; }
    }

    static class ContainerWithCustomType {
        public CustomType score;
        public ContainerWithCustomType() {}
        public ContainerWithCustomType(CustomType score) { this.score = score; }
    }

    static class PersonWithMemberList {
        public List<SimplePerson> members;
        public PersonWithMemberList() {}
        public PersonWithMemberList(List<SimplePerson> members) { this.members = members; }
    }

    // =========================================================================
    // 1. ChangeType
    // =========================================================================

    @Nested
    @DisplayName("ChangeType")
    class ChangeTypeTests {

        private Class<?> changeTypeClass;

        @BeforeEach
        void setup() {
            changeTypeClass = loadClass("com.objectdiff.ChangeType");
            assertNotNull(changeTypeClass, "com.objectdiff.ChangeType must exist");
        }

        @Test
        @DisplayName("ChangeType declares all seven required enum constants")
        void allRequiredConstantsExist() {
            Set<String> names = new HashSet<>();
            for (Object ct : changeTypeClass.getEnumConstants()) {
                names.add(((Enum<?>) ct).name());
            }
            assertTrue(names.contains("VALUE_CHANGED"));
            assertTrue(names.contains("VALUE_ADDED"));
            assertTrue(names.contains("VALUE_REMOVED"));
            assertTrue(names.contains("COLLECTION_ELEMENT_INSERTED"));
            assertTrue(names.contains("COLLECTION_ELEMENT_REMOVED"));
            assertTrue(names.contains("MAP_ENTRY_ADDED"));
            assertTrue(names.contains("MAP_ENTRY_REMOVED"));
        }
    }

    // =========================================================================
    // 2. ExcludeFromDiff Annotation
    // =========================================================================

    @Nested
    @DisplayName("ExcludeFromDiff Annotation")
    class ExcludeFromDiffAnnotationTests {

        private Class<?> annotationClass;

        @BeforeEach
        void setup() {
            annotationClass = loadClass("com.objectdiff.ExcludeFromDiff");
            assertNotNull(annotationClass, "com.objectdiff.ExcludeFromDiff must exist");
        }

        @Test
        @DisplayName("ExcludeFromDiff has @Retention(RUNTIME) so it is visible via reflection at runtime")
        void hasRuntimeRetention() {
            Retention retention = (Retention) annotationClass.getAnnotation(Retention.class);
            assertNotNull(retention, "ExcludeFromDiff must declare @Retention");
            assertEquals(RetentionPolicy.RUNTIME, retention.value());
        }

        @Test
        @DisplayName("ExcludeFromDiff targets ElementType.FIELD")
        void targetsField() {
            Target target = (Target) annotationClass.getAnnotation(Target.class);
            assertNotNull(target, "ExcludeFromDiff must declare @Target");
            boolean hasField = Arrays.asList(target.value()).contains(ElementType.FIELD);
            assertTrue(hasField, "ExcludeFromDiff must include ElementType.FIELD in its @Target");
        }

    }

    // =========================================================================
    // 3. ObjectDiffer
    // =========================================================================

    @Nested
    @DisplayName("ObjectDiffer")
    class ObjectDifferTests {

        private Class<?> differClass;
        private Class<?> registryClass;
        private Object differ;

        @BeforeEach
        void setup() throws Exception {
            differClass   = loadClass("com.objectdiff.ObjectDiffer");
            registryClass = loadClass("com.objectdiff.ComparatorRegistry");
            assertNotNull(differClass,   "com.objectdiff.ObjectDiffer must exist");
            assertNotNull(registryClass, "com.objectdiff.ComparatorRegistry must exist");
            differ = newDiffer(differClass, registryClass);
        }

        private List<?> diff(Object base, Object target) throws Exception {
            return (List<?>) invoke(differ, "diff",
                    new Class[]{Object.class, Object.class}, new Object[]{base, target});
        }

        private Object changeType(Object record) throws Exception {
            return invoke(record, "getChangeType", new Class[0], new Object[0]);
        }

        private String path(Object record) throws Exception {
            return (String) invoke(record, "getPath", new Class[0], new Object[0]);
        }

        // -- 3.1 Structural equality --

        @Test
        @DisplayName("diff returns empty list when objects are structurally equal")
        void diffEmptyForEqualObjects() throws Exception {
            assertTrue(diff(new SimplePerson("Alice", 30), new SimplePerson("Alice", 30)).isEmpty());
        }

        // -- 3.2 VALUE_CHANGED --

        @Test
        @DisplayName("diff produces VALUE_CHANGED when a field value changes")
        void diffProducesValueChanged() throws Exception {
            List<?> records = diff(new SimplePerson("Alice", 30), new SimplePerson("Alice", 31));
            Object expected = changeTypeConstant("VALUE_CHANGED");
            assertNotNull(expected, "VALUE_CHANGED constant must exist");
            assertTrue(records.stream().anyMatch(r -> {
                try { return expected.equals(changeType(r)); } catch (Exception e) { return false; }
            }));
        }

        @Test
        @DisplayName("VALUE_CHANGED record has correct old and new values")
        void valueChangedHasCorrectOldAndNewValues() throws Exception {
            List<?> records = diff(new SimplePerson("Alice", 30), new SimplePerson("Bob", 30));
            Object expected = changeTypeConstant("VALUE_CHANGED");
            assertNotNull(expected);
            Optional<?> opt = records.stream()
                    .filter(r -> { try { return expected.equals(changeType(r)); } catch (Exception e) { return false; } })
                    .findFirst();
            assertTrue(opt.isPresent()); // guard
            assertEquals("Alice", invoke(opt.get(), "getOldValue", new Class[0], new Object[0]));
            assertEquals("Bob",   invoke(opt.get(), "getNewValue", new Class[0], new Object[0]));
        }

        // -- 3.3 VALUE_ADDED --

        @Test
        @DisplayName("diff produces VALUE_ADDED when field changes from null to non-null")
        void diffProducesValueAdded() throws Exception {
            List<?> records = diff(new SimplePerson(null, 30), new SimplePerson("Alice", 30));
            Object expected = changeTypeConstant("VALUE_ADDED");
            assertNotNull(expected);
            assertTrue(records.stream().anyMatch(r -> {
                try { return expected.equals(changeType(r)); } catch (Exception e) { return false; }
            }));
        }

        // -- 3.4 VALUE_REMOVED --

        @Test
        @DisplayName("diff produces VALUE_REMOVED when field changes from non-null to null")
        void diffProducesValueRemoved() throws Exception {
            List<?> records = diff(new SimplePerson("Alice", 30), new SimplePerson(null, 30));
            Object expected = changeTypeConstant("VALUE_REMOVED");
            assertNotNull(expected);
            assertTrue(records.stream().anyMatch(r -> {
                try { return expected.equals(changeType(r)); } catch (Exception e) { return false; }
            }));
        }

        // -- 3.5 Path representation --

        @Test
        @DisplayName("diff path uses dot notation for nested field: address.city")
        void pathDotNotationForNestedField() throws Exception {
            List<?> records = diff(
                    new PersonWithAddress("Alice", new Address("Paris", "France")),
                    new PersonWithAddress("Alice", new Address("Lyon",  "France")));
            assertTrue(records.stream().anyMatch(r -> {
                try { return "address.city".equals(path(r)); } catch (Exception e) { return false; }
            }));
        }

        @Test
        @DisplayName("diff path uses bracket notation for list index: tags[1]")
        void pathBracketNotationForListIndex() throws Exception {
            List<?> records = diff(
                    new PersonWithList(Arrays.asList("a", "b")),
                    new PersonWithList(Arrays.asList("a", "c")));
            assertTrue(records.stream().anyMatch(r -> {
                try { String p = path(r); return p != null && p.contains("[1]"); }
                catch (Exception e) { return false; }
            }));
        }

        @Test
        @DisplayName("diff path uses bracket notation for map key: phoneNumbers[mobile]")
        void pathBracketNotationForMapKey() throws Exception {
            Map<String, String> baseMap   = new HashMap<>(); baseMap.put("mobile", "123");
            Map<String, String> targetMap = new HashMap<>(); targetMap.put("mobile", "456");
            List<?> records = diff(new PersonWithMap(baseMap), new PersonWithMap(targetMap));
            assertTrue(records.stream().anyMatch(r -> {
                try { String p = path(r); return p != null && p.contains("[mobile]"); }
                catch (Exception e) { return false; }
            }));
        }

        // -- 3.6 Recursive nested traversal --

        @Test
        @DisplayName("diff traverses nested objects recursively")
        void diffTraversesNestedObjects() throws Exception {
            List<?> records = diff(
                    new PersonWithAddress("Alice", new Address("Paris", "France")),
                    new PersonWithAddress("Alice", new Address("Paris", "Germany")));
            assertFalse(records.isEmpty());
            assertTrue(records.stream().anyMatch(r -> {
                try { String p = path(r); return p != null && p.contains("address"); }
                catch (Exception e) { return false; }
            }));
        }

        // -- 3.7 List element-by-element --

        @Test
        @DisplayName("diff List produces insertion record when element added")
        void listProducesInsertionRecord() throws Exception {
            List<?> records = diff(
                    new PersonWithList(Arrays.asList("a")),
                    new PersonWithList(Arrays.asList("a", "b")));
            Object inserted = changeTypeConstant("COLLECTION_ELEMENT_INSERTED");
            Object added    = changeTypeConstant("VALUE_ADDED");
            assertTrue(records.stream().anyMatch(r -> {
                try {
                    Object ct = changeType(r);
                    return (inserted != null && inserted.equals(ct)) || (added != null && added.equals(ct));
                } catch (Exception e) { return false; }
            }));
        }

        @Test
        @DisplayName("diff List produces removal record when element removed")
        void listProducesRemovalRecord() throws Exception {
            List<?> records = diff(
                    new PersonWithList(Arrays.asList("a", "b")),
                    new PersonWithList(Arrays.asList("a")));
            Object removed  = changeTypeConstant("COLLECTION_ELEMENT_REMOVED");
            Object valueRem = changeTypeConstant("VALUE_REMOVED");
            assertTrue(records.stream().anyMatch(r -> {
                try {
                    Object ct = changeType(r);
                    return (removed != null && removed.equals(ct)) || (valueRem != null && valueRem.equals(ct));
                } catch (Exception e) { return false; }
            }));
        }

        // -- 3.8 Set comparison --

        @Test
        @DisplayName("diff Set produces VALUE_ADDED when element added")
        void setProducesValueAdded() throws Exception {
            List<?> records = diff(
                    new PersonWithSet(new HashSet<>(Arrays.asList("admin"))),
                    new PersonWithSet(new HashSet<>(Arrays.asList("admin", "editor"))));
            Object expected = changeTypeConstant("VALUE_ADDED");
            assertNotNull(expected);
            assertTrue(records.stream().anyMatch(r -> {
                try { return expected.equals(changeType(r)); } catch (Exception e) { return false; }
            }));
        }

        @Test
        @DisplayName("diff Set produces VALUE_REMOVED when element removed")
        void setProducesValueRemoved() throws Exception {
            List<?> records = diff(
                    new PersonWithSet(new HashSet<>(Arrays.asList("admin", "editor"))),
                    new PersonWithSet(new HashSet<>(Arrays.asList("admin"))));
            Object expected = changeTypeConstant("VALUE_REMOVED");
            assertNotNull(expected);
            assertTrue(records.stream().anyMatch(r -> {
                try { return expected.equals(changeType(r)); } catch (Exception e) { return false; }
            }));
        }

        // -- 3.9 Map comparison --

        @Test
        @DisplayName("diff Map produces MAP_ENTRY_ADDED when key added")
        void mapProducesEntryAdded() throws Exception {
            Map<String, String> baseMap   = new HashMap<>(); baseMap.put("home", "111");
            Map<String, String> targetMap = new HashMap<>();
            targetMap.put("home", "111"); targetMap.put("mobile", "222");
            List<?> records = diff(new PersonWithMap(baseMap), new PersonWithMap(targetMap));
            Object expected = changeTypeConstant("MAP_ENTRY_ADDED");
            assertNotNull(expected);
            assertTrue(records.stream().anyMatch(r -> {
                try { return expected.equals(changeType(r)); } catch (Exception e) { return false; }
            }));
        }

        @Test
        @DisplayName("diff Map produces MAP_ENTRY_REMOVED when key removed")
        void mapProducesEntryRemoved() throws Exception {
            Map<String, String> baseMap   = new HashMap<>();
            baseMap.put("home", "111"); baseMap.put("mobile", "222");
            Map<String, String> targetMap = new HashMap<>(); targetMap.put("home", "111");
            List<?> records = diff(new PersonWithMap(baseMap), new PersonWithMap(targetMap));
            Object expected = changeTypeConstant("MAP_ENTRY_REMOVED");
            assertNotNull(expected);
            assertTrue(records.stream().anyMatch(r -> {
                try { return expected.equals(changeType(r)); } catch (Exception e) { return false; }
            }));
        }

        // -- 3.10 Circular reference --

        @Test
        @DisplayName("diff does not throw or hang on circular references and produces no records for identical cycles")
        void circularReferenceDoesNotThrow() {
            NodeWithCycle a = new NodeWithCycle("x"); a.next = a;
            NodeWithCycle b = new NodeWithCycle("x"); b.next = b;
            assertDoesNotThrow(() -> {
                List<?> records = diff(a, b);
                // Identical self-referencing objects must yield no change records.
                assertTrue(records.isEmpty(),
                        "Identical cyclic objects must produce an empty diff");
            });
        }

        // -- 3.11 withListIdentity --

        @Test
        @DisplayName("withListIdentity enables detecting moves as COLLECTION_ELEMENT_REMOVED and COLLECTION_ELEMENT_INSERTED pairs")
        void withListIdentityDetectsMoves() throws Exception {
            Function<Object, Object> identityFn = obj -> {
                try { return obj.getClass().getField("name").get(obj); }
                catch (Exception e) { return obj; }
            };
            differClass.getMethod("withListIdentity", String.class, Function.class)
                    .invoke(differ, "members", identityFn);

            List<?> records = diff(
                    new PersonWithMemberList(
                            Arrays.asList(new SimplePerson("Alice", 30), new SimplePerson("Bob", 25))),
                    new PersonWithMemberList(
                            Arrays.asList(new SimplePerson("Bob", 25), new SimplePerson("Alice", 30))));

            Object removed  = changeTypeConstant("COLLECTION_ELEMENT_REMOVED");
            Object inserted = changeTypeConstant("COLLECTION_ELEMENT_INSERTED");
            assertNotNull(removed);
            assertNotNull(inserted);
            assertTrue(records.stream().anyMatch(r -> { try { return removed.equals(changeType(r)); } catch (Exception e) { return false; } }));
            assertTrue(records.stream().anyMatch(r -> { try { return inserted.equals(changeType(r)); } catch (Exception e) { return false; } }));
        }

        @Test
        @DisplayName("withListIdentity returns this for chaining")
        void withListIdentityReturnsThis() throws Exception {
            Function<Object, Object> fn = obj -> obj;
            Object result = differClass.getMethod("withListIdentity", String.class, Function.class)
                    .invoke(differ, "items", fn);
            assertSame(differ, result, "withListIdentity must return this");
        }
    }

    // =========================================================================
    // 4. ComparatorRegistry
    // =========================================================================

    @Nested
    @DisplayName("ComparatorRegistry")
    class ComparatorRegistryTests {

        private Class<?> registryClass;
        private Class<?> differClass;

        @BeforeEach
        void setup() {
            registryClass = loadClass("com.objectdiff.ComparatorRegistry");
            differClass   = loadClass("com.objectdiff.ObjectDiffer");
            assertNotNull(registryClass, "com.objectdiff.ComparatorRegistry must exist");
            assertNotNull(differClass,   "com.objectdiff.ObjectDiffer must exist");
        }

        private Object differWithRegistry(Object registry) throws Exception {
            return differClass.getConstructor(registryClass).newInstance(registry);
        }

        private List<?> diff(Object differ, Object base, Object target) throws Exception {
            return (List<?>) invoke(differ, "diff",
                    new Class[]{Object.class, Object.class}, new Object[]{base, target});
        }

        @Test
        @DisplayName("Comparator returning 0 causes no records to be produced for that type")
        void comparatorTreatsTypesAsEqual() throws Exception {
            Object registry = registryClass.getConstructor().newInstance();
            registryClass.getMethod("register", Class.class, Comparator.class)
                    .invoke(registry, CustomType.class, (Comparator<Object>) (a, b) -> 0);
            Object differ = differWithRegistry(registry);

            List<?> records = diff(differ,
                    new ContainerWithCustomType(new CustomType(1.0)),
                    new ContainerWithCustomType(new CustomType(2.0)));
            assertTrue(records.isEmpty(),
                    "No diff records expected when comparator returns 0 (equal)");
        }

        @Test
        @DisplayName("Comparator returning non-zero produces a record for that field")
        void comparatorDetectsInequality() throws Exception {
            Object registry = registryClass.getConstructor().newInstance();
            registryClass.getMethod("register", Class.class, Comparator.class)
                    .invoke(registry, CustomType.class, (Comparator<Object>) (a, b) -> -1);
            Object differ = differWithRegistry(registry);

            List<?> records = diff(differ,
                    new ContainerWithCustomType(new CustomType(1.0)),
                    new ContainerWithCustomType(new CustomType(1.0)));
            assertTrue(records.stream().anyMatch(r -> {
                try {
                    Object p = r.getClass().getMethod("getPath").invoke(r);
                    return p instanceof String && ((String) p).contains("score");
                } catch (Exception e) { return false; }
            }), "A record for 'score' must be produced when comparator returns non-zero");
        }
    }

    // =========================================================================
    // 5. PatchApplier
    // =========================================================================

    @Nested
    @DisplayName("PatchApplier")
    class PatchApplierTests {

        private Class<?> patchClass;
        private Object differ;

        @BeforeEach
        void setup() throws Exception {
            patchClass = loadClass("com.objectdiff.PatchApplier");
            assertNotNull(patchClass, "com.objectdiff.PatchApplier must exist");
            Class<?> differClass   = loadClass("com.objectdiff.ObjectDiffer");
            Class<?> registryClass = loadClass("com.objectdiff.ComparatorRegistry");
            assertNotNull(differClass,   "com.objectdiff.ObjectDiffer must exist");
            assertNotNull(registryClass, "com.objectdiff.ComparatorRegistry must exist");
            differ = newDiffer(differClass, registryClass);
        }

        private List<?> diff(Object base, Object target) throws Exception {
            return (List<?>) invoke(differ, "diff",
                    new Class[]{Object.class, Object.class}, new Object[]{base, target});
        }

        private Object apply(Object base, List<?> records) throws Exception {
            return invokeStatic(patchClass, "apply",
                    new Class[]{Object.class, List.class}, new Object[]{base, records});
        }

        @Test
        @DisplayName("apply replays diff to produce object matching target")
        void applyProducesObjectMatchingTarget() throws Exception {
            SimplePerson base   = new SimplePerson("Alice", 30);
            SimplePerson target = new SimplePerson("Bob",   31);
            List<?> records = diff(base, target);
            assertFalse(records.isEmpty()); // guard
            Object patched = apply(base, records);
            assertNotNull(patched);          // guard: fails gracefully if apply returns null
            assertEquals("Bob", patched.getClass().getField("name").get(patched));
            assertEquals(31,    patched.getClass().getField("age").get(patched));
        }

        @Test
        @DisplayName("apply does not mutate the base object")
        void applyDoesNotMutateBase() throws Exception {
            SimplePerson base   = new SimplePerson("Alice", 30);
            SimplePerson target = new SimplePerson("Bob",   31);
            List<?> records = diff(base, target);
            assertFalse(records.isEmpty()); // guard
            Object patched = apply(base, records);
            assertNotNull(patched);          // guard
            assertEquals("Alice", base.name,  "base.name must be unchanged after apply");
            assertEquals(30,      base.age,   "base.age must be unchanged after apply");
        }

        @Test
        @DisplayName("apply with empty diff returns copy matching base")
        void applyEmptyDiffReturnsCopyMatchingBase() throws Exception {
            SimplePerson base   = new SimplePerson("Alice", 30);
            Object patched = apply(base, Collections.emptyList());
            assertNotNull(patched); // guard: fails gracefully if apply returns null
            assertEquals("Alice", patched.getClass().getField("name").get(patched));
            assertEquals(30,      patched.getClass().getField("age").get(patched));
        }
    }

    // =========================================================================
    // 6. DiffMerger
    // =========================================================================

    @Nested
    @DisplayName("DiffMerger")
    class DiffMergerTests {

        private Class<?> mergerClass;
        private Object differ;

        @BeforeEach
        void setup() throws Exception {
            mergerClass = loadClass("com.objectdiff.DiffMerger");
            assertNotNull(mergerClass, "com.objectdiff.DiffMerger must exist");
            Class<?> differClass   = loadClass("com.objectdiff.ObjectDiffer");
            Class<?> registryClass = loadClass("com.objectdiff.ComparatorRegistry");
            assertNotNull(differClass,   "com.objectdiff.ObjectDiffer must exist");
            assertNotNull(registryClass, "com.objectdiff.ComparatorRegistry must exist");
            differ = newDiffer(differClass, registryClass);
        }

        private List<?> diff(Object base, Object target) throws Exception {
            return (List<?>) invoke(differ, "diff",
                    new Class[]{Object.class, Object.class}, new Object[]{base, target});
        }

        private Object merge(List<?> diff1, List<?> diff2) throws Exception {
            return invokeStatic(mergerClass, "merge",
                    new Class[]{List.class, List.class}, new Object[]{diff1, diff2});
        }

        private List<?> mergedRecords(Object result) throws Exception {
            return (List<?>) invoke(result, "getMergedRecords", new Class[0], new Object[0]);
        }

        private List<?> conflicts(Object result) throws Exception {
            return (List<?>) invoke(result, "getConflicts", new Class[0], new Object[0]);
        }

        @Test
        @DisplayName("merge places non-conflicting records from both diffs into mergedRecords")
        void mergeNonConflictingRecords() throws Exception {
            SimplePerson base = new SimplePerson("Alice", 30);
            List<?> diff1 = diff(base, new SimplePerson("Bob",   30)); // name change
            List<?> diff2 = diff(base, new SimplePerson("Alice", 31)); // age change
            assertFalse(diff1.isEmpty()); // guard
            assertFalse(diff2.isEmpty()); // guard
            Object result = merge(diff1, diff2);
            assertTrue(conflicts(result).isEmpty());
            assertEquals(diff1.size() + diff2.size(), mergedRecords(result).size());
        }

        @Test
        @DisplayName("merge reports a conflict when both diffs modify the same path")
        void mergeSamePathReportedAsConflict() throws Exception {
            SimplePerson base = new SimplePerson("Alice", 30);
            Object result = merge(
                    diff(base, new SimplePerson("Bob",     30)),
                    diff(base, new SimplePerson("Charlie", 30)));
            assertFalse(conflicts(result).isEmpty());
        }

        @Test
        @DisplayName("merge excludes conflicting records from mergedRecords")
        void mergeConflictingExcludedFromMerged() throws Exception {
            SimplePerson base = new SimplePerson("Alice", 30);
            Object result = merge(
                    diff(base, new SimplePerson("Bob",     30)),
                    diff(base, new SimplePerson("Charlie", 30)));
            List<?> conflictList = conflicts(result);
            assertFalse(conflictList.isEmpty()); // guard
            Set<String> conflictPaths = new HashSet<>();
            for (Object cr : conflictList) {
                conflictPaths.add((String) invoke(cr, "getPath", new Class[0], new Object[0]));
            }
            for (Object mr : mergedRecords(result)) {
                String p = (String) invoke(mr, "getPath", new Class[0], new Object[0]);
                assertFalse(conflictPaths.contains(p),
                        "Conflicting path must not appear in mergedRecords");
            }
        }

        @Test
        @DisplayName("ConflictRecord exposes getPath, getFromDiff1, getFromDiff2 pointing to the conflicting records")
        void conflictRecordGettersExposeCorrectFields() throws Exception {
            SimplePerson base = new SimplePerson("Alice", 30);
            Object result = merge(
                    diff(base, new SimplePerson("Bob",     30)),
                    diff(base, new SimplePerson("Charlie", 30)));
            List<?> conflictList = conflicts(result);
            assertFalse(conflictList.isEmpty()); // guard
            Object conflict = conflictList.get(0);
            String conflictPath = (String) invoke(conflict, "getPath",     new Class[0], new Object[0]);
            Object fromDiff1    =          invoke(conflict, "getFromDiff1", new Class[0], new Object[0]);
            Object fromDiff2    =          invoke(conflict, "getFromDiff2", new Class[0], new Object[0]);
            assertNotNull(conflictPath);
            assertNotNull(fromDiff1);
            assertNotNull(fromDiff2);
            assertEquals(conflictPath, invoke(fromDiff1, "getPath", new Class[0], new Object[0]));
            assertEquals(conflictPath, invoke(fromDiff2, "getPath", new Class[0], new Object[0]));
        }
    }

    // =========================================================================
    // 7. DiffFormatter
    // =========================================================================

    @Nested
    @DisplayName("DiffFormatter")
    class DiffFormatterTests {

        private Class<?> formatterClass;
        private Object differ;

        @BeforeEach
        void setup() throws Exception {
            formatterClass = loadClass("com.objectdiff.DiffFormatter");
            assertNotNull(formatterClass, "com.objectdiff.DiffFormatter must exist");
            Class<?> differClass   = loadClass("com.objectdiff.ObjectDiffer");
            Class<?> registryClass = loadClass("com.objectdiff.ComparatorRegistry");
            assertNotNull(differClass,   "com.objectdiff.ObjectDiffer must exist");
            assertNotNull(registryClass, "com.objectdiff.ComparatorRegistry must exist");
            differ = newDiffer(differClass, registryClass);
        }

        private List<?> diff(Object base, Object target) throws Exception {
            return (List<?>) invoke(differ, "diff",
                    new Class[]{Object.class, Object.class}, new Object[]{base, target});
        }

        private String toText(List<?> records) throws Exception {
            return (String) invokeStatic(formatterClass, "toText",
                    new Class[]{List.class}, new Object[]{records});
        }

        private String toJson(List<?> records) throws Exception {
            return (String) invokeStatic(formatterClass, "toJson",
                    new Class[]{List.class}, new Object[]{records});
        }

        /** Finds the first VALUE_CHANGED record in a list, or returns empty. */
        private Optional<?> firstValueChanged(List<?> records) {
            Object expected = changeTypeConstant("VALUE_CHANGED");
            if (expected == null) return Optional.empty();
            return records.stream().filter(r -> {
                try {
                    return expected.equals(invoke(r, "getChangeType", new Class[0], new Object[0]));
                } catch (Exception e) { return false; }
            }).findFirst();
        }

        // -- 7.1 toText --

        @Test
        @DisplayName("toText output contains the path and change type name for each record")
        void toTextContainsPathAndChangeTypeName() throws Exception {
            List<?> records = diff(new SimplePerson("Alice", 30), new SimplePerson("Bob", 30));
            assertFalse(records.isEmpty()); // guard
            Optional<?> opt = firstValueChanged(records);
            assertTrue(opt.isPresent()); // guard
            Object record = opt.get();
            String text = toText(records);
            assertNotNull(text); // guard: fails gracefully if toText returns null
            String recordPath = (String) invoke(record, "getPath", new Class[0], new Object[0]);
            assertTrue(text.contains(recordPath), "toText must include the record path");
            assertTrue(text.contains("VALUE_CHANGED"), "toText must include the change type name");
        }

        @Test
        @DisplayName("toText includes old and new values in the output for VALUE_CHANGED records")
        void toTextContainsOldAndNewValues() throws Exception {
            List<?> records = diff(new SimplePerson("Alice", 30), new SimplePerson("Bob", 30));
            assertFalse(records.isEmpty()); // guard
            Optional<?> opt = firstValueChanged(records);
            assertTrue(opt.isPresent()); // guard
            Object record = opt.get();
            String text = toText(records);
            assertNotNull(text); // guard
            Object oldVal = invoke(record, "getOldValue", new Class[0], new Object[0]);
            Object newVal = invoke(record, "getNewValue", new Class[0], new Object[0]);
            assertTrue(text.contains(String.valueOf(oldVal)), "toText must include the old value");
            assertTrue(text.contains(String.valueOf(newVal)), "toText must include the new value");
        }

        @Test
        @DisplayName("toText with empty list returns a non-null string")
        void toTextEmptyListReturnsNonNull() throws Exception {
            assertNotNull(toText(Collections.emptyList()));
        }

        // -- 7.2 toJson --

        @Test
        @DisplayName("toJson returns a valid JSON array")
        void toJsonReturnsValidJsonArray() throws Exception {
            List<?> records = diff(new SimplePerson("Alice", 30), new SimplePerson("Bob", 30));
            String json = toJson(records);
            assertNotNull(json); // guard: fails gracefully if toJson returns null
            assertTrue(new ObjectMapper().readTree(json).isArray());
        }

        @Test
        @DisplayName("toJson each element has keys: path, changeType, oldValue, newValue")
        void toJsonElementsHaveRequiredKeys() throws Exception {
            List<?> records = diff(new SimplePerson("Alice", 30), new SimplePerson("Bob", 30));
            assertFalse(records.isEmpty()); // guard
            String json = toJson(records);
            assertNotNull(json); // guard
            JsonNode array = new ObjectMapper().readTree(json);
            assertTrue(array.isArray());
            assertFalse(array.isEmpty()); // guard: non-empty so the per-element key checks execute
            for (JsonNode element : array) {
                assertTrue(element.has("path"));
                assertTrue(element.has("changeType"));
                assertTrue(element.has("oldValue"));
                assertTrue(element.has("newValue"));
            }
        }

        @Test
        @DisplayName("toJson with empty list returns an empty JSON array")
        void toJsonEmptyListReturnsEmptyArray() throws Exception {
            String json = toJson(Collections.emptyList());
            assertNotNull(json); // guard
            JsonNode node = new ObjectMapper().readTree(json);
            assertTrue(node.isArray());
            assertEquals(0, node.size());
        }
    }
}