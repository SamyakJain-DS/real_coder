import dataclasses
import inspect
import tempfile
from pathlib import Path

import numpy as np
import pytest

# ---------------------------------------------------------------------------
# Safe top-level import - on an empty repo all names become None and
# _IMPORT_OK = False. Every test calls _require() first in its body which
# calls pytest.fail() -> FAILED (not ERROR) status.
# ---------------------------------------------------------------------------
try:
    from online_ml import (
        FeatureSpec,
        FeatureSchema,
        BaseEstimator,
        OnlineLinearRegressor,
        OnlineGBTRegressor,
        OnlineLogisticClassifier,
        OnlineNaiveBayes,
        OnlineRandomForest,
        IncrementalKMeans,
        OnlineDBSCAN,
        HalfSpaceTrees,
        OnlineQuantileDetector,
        RollingMetrics,
        DriftAlert,
        DriftDetector,
        SnapshotManager,
        ChampionChallenger,
    )
    import online_ml as _online_ml_mod
    _IMPORT_OK = True
except Exception:
    (
        FeatureSpec, FeatureSchema, BaseEstimator,
        OnlineLinearRegressor, OnlineGBTRegressor,
        OnlineLogisticClassifier, OnlineNaiveBayes, OnlineRandomForest,
        IncrementalKMeans, OnlineDBSCAN,
        HalfSpaceTrees, OnlineQuantileDetector,
        RollingMetrics, DriftAlert, DriftDetector,
        SnapshotManager, ChampionChallenger,
        _online_ml_mod,
    ) = (None,) * 18
    _IMPORT_OK = False


def _require():
    """Call first in every test body. Produces FAILED (not ERROR) on empty repo."""
    if not _IMPORT_OK:
        pytest.fail("online_ml package could not be imported")


# ---------------------------------------------------------------------------
# Data helpers - use only numpy, no online_ml objects
# ---------------------------------------------------------------------------

def _schema(*name_dtype_pairs):
    return FeatureSchema([FeatureSpec(n, d) for n, d in name_dtype_pairs])


def _X(n, f, seed=0):
    return np.random.default_rng(seed).standard_normal((n, f))


def _y_reg(n, seed=1):
    return np.random.default_rng(seed).standard_normal(n)


def _y_cls(n, n_classes, seed=2):
    return np.random.default_rng(seed).integers(0, n_classes, n).astype(np.int64)


# ===========================================================================
# 1. Package-level imports and __all__
# ===========================================================================

class TestPackageImports:

    def test_all_list_equals_required_names(self):
        _require()
        required = {
            "FeatureSpec", "FeatureSchema", "BaseEstimator",
            "OnlineLinearRegressor", "OnlineGBTRegressor",
            "OnlineLogisticClassifier", "OnlineNaiveBayes", "OnlineRandomForest",
            "IncrementalKMeans", "OnlineDBSCAN",
            "HalfSpaceTrees", "OnlineQuantileDetector",
            "RollingMetrics", "DriftAlert", "DriftDetector",
            "SnapshotManager", "ChampionChallenger",
        }
        assert hasattr(_online_ml_mod, "__all__"), "online_ml must define __all__"
        assert set(_online_ml_mod.__all__) == required


# ===========================================================================
# 2. FeatureSpec
# ===========================================================================

class TestFeatureSpec:

    def test_name_field(self):
        _require()
        assert FeatureSpec("age", "numeric").name == "age"

    def test_dtype_field_numeric(self):
        _require()
        assert FeatureSpec("age", "numeric").dtype == "numeric"

    def test_dtype_field_categorical(self):
        _require()
        assert FeatureSpec("color", "categorical").dtype == "categorical"

    def test_is_dataclass(self):
        _require()
        assert dataclasses.is_dataclass(FeatureSpec)


# ===========================================================================
# 3. FeatureSchema
# ===========================================================================

class TestFeatureSchema:

    def test_n_features_count(self):
        _require()
        schema = _schema(("a", "numeric"), ("b", "numeric"), ("c", "categorical"))
        assert schema.n_features == 3
        with pytest.raises(AttributeError):
            schema.n_features = 999

    def test_feature_names_order(self):
        _require()
        schema = _schema(("x", "numeric"), ("y", "categorical"))
        assert schema.feature_names == ["x", "y"]
        with pytest.raises(AttributeError):
            schema.feature_names = []

    def test_single_feature(self):
        _require()
        schema = _schema(("v", "numeric"))
        assert schema.n_features == 1
        assert schema.feature_names == ["v"]
        with pytest.raises(AttributeError):
            schema.n_features = 0
        with pytest.raises(AttributeError):
            schema.feature_names = []


# ===========================================================================
# 4. BaseEstimator - all nine concrete estimators must be instances
# ===========================================================================

class TestBaseEstimatorInheritance:

    def test_online_linear_regressor(self):
        _require()
        assert isinstance(OnlineLinearRegressor(schema=_schema(("a", "numeric"))), BaseEstimator)

    def test_online_gbt_regressor(self):
        _require()
        assert isinstance(OnlineGBTRegressor(schema=_schema(("a", "numeric"))), BaseEstimator)

    def test_online_logistic_classifier(self):
        _require()
        assert isinstance(OnlineLogisticClassifier(schema=_schema(("a", "numeric")), n_classes=3), BaseEstimator)

    def test_online_naive_bayes(self):
        _require()
        assert isinstance(OnlineNaiveBayes(schema=_schema(("a", "numeric")), n_classes=3), BaseEstimator)

    def test_online_random_forest(self):
        _require()
        assert isinstance(OnlineRandomForest(schema=_schema(("a", "numeric")), n_classes=3), BaseEstimator)

    def test_incremental_kmeans(self):
        _require()
        assert isinstance(
            IncrementalKMeans(schema=_schema(("a", "numeric")), n_clusters=3,
                              split_variance_threshold=10.0, merge_distance_threshold=0.01),
            BaseEstimator,
        )

    def test_online_dbscan(self):
        _require()
        assert isinstance(
            OnlineDBSCAN(schema=_schema(("a", "numeric")), eps=0.5, min_samples=5, window_size=100),
            BaseEstimator,
        )

    def test_half_space_trees(self):
        _require()
        assert isinstance(
            HalfSpaceTrees(schema=_schema(("a", "numeric")), n_trees=10, window_size=100),
            BaseEstimator,
        )

    def test_online_quantile_detector(self):
        _require()
        assert isinstance(
            OnlineQuantileDetector(schema=_schema(("a", "numeric")), quantile=0.95, window_size=100),
            BaseEstimator,
        )

    def test_default_constructor_values(self):
        """Default parameter values must match the Expected Interface specification exactly."""
        _require()
        # OnlineLinearRegressor: learning_rate default = 0.01
        lr_params = inspect.signature(OnlineLinearRegressor).parameters
        assert lr_params["learning_rate"].default == pytest.approx(0.01)
        # OnlineGBTRegressor: n_estimators default = 10, learning_rate default = 0.1
        gbt_params = inspect.signature(OnlineGBTRegressor).parameters
        assert gbt_params["n_estimators"].default == 10
        assert gbt_params["learning_rate"].default == pytest.approx(0.1)
        # OnlineLogisticClassifier: learning_rate default = 0.01, calibration_window default = 200
        logistic_params = inspect.signature(OnlineLogisticClassifier).parameters
        assert logistic_params["learning_rate"].default == pytest.approx(0.01)
        assert logistic_params["calibration_window"].default == 200
        # OnlineRandomForest: n_trees default = 10
        rf_params = inspect.signature(OnlineRandomForest).parameters
        assert rf_params["n_trees"].default == 10

    def test_schema_accepted_as_first_positional_argument(self):
        """Every estimator constructor must accept schema as its first positional argument."""
        _require()
        schema = _schema(("a", "numeric"), ("b", "numeric"))
        # Call each constructor with schema as a positional arg (no keyword)
        assert OnlineLinearRegressor(schema) is not None
        assert OnlineGBTRegressor(schema) is not None
        assert OnlineLogisticClassifier(schema, 3) is not None
        assert OnlineNaiveBayes(schema, 3) is not None
        assert OnlineRandomForest(schema, 3) is not None
        assert IncrementalKMeans(schema, 3, 10.0, 0.01) is not None
        assert OnlineDBSCAN(schema, 0.5, 5, 100) is not None
        assert HalfSpaceTrees(schema, 10, 100) is not None
        assert OnlineQuantileDetector(schema, 0.95, 100) is not None


# ===========================================================================
# 5. Regression estimators
# ===========================================================================

class TestRegressionEstimators:
    """
    All data created inside test bodies after _require() to guarantee FAILED
    (not ERROR) status on empty repo.
    """

    def _data(self):
        schema = _schema(("a", "numeric"), ("b", "numeric"))
        return schema, _X(60, 2, 10), _y_reg(60, 11), _X(15, 2, 12)

    # --- OnlineLinearRegressor ---

    def test_linear_partial_fit_returns_none(self):
        _require()
        schema, Xtr, ytr, _ = self._data()
        assert OnlineLinearRegressor(schema=schema).partial_fit(Xtr, ytr) is None

    def test_linear_predict_shape(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        est = OnlineLinearRegressor(schema=schema)
        est.partial_fit(Xtr, ytr)
        out = est.predict(Xte)
        assert isinstance(out, np.ndarray) and out.shape == (15,)
        assert np.issubdtype(out.dtype, np.floating)

    def test_linear_predict_proba_shape_and_nonneg(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        est = OnlineLinearRegressor(schema=schema)
        est.partial_fit(Xtr, ytr)
        out = est.predict_proba(Xte)
        assert isinstance(out, np.ndarray) and out.shape == (15,)
        assert (out >= 0).all()

    def test_linear_multiple_partial_fit_calls(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        est = OnlineLinearRegressor(schema=schema)
        for _ in range(3):
            assert est.partial_fit(Xtr[:20], ytr[:20]) is None
        assert est.predict(Xte).shape == (15,)

    # --- OnlineGBTRegressor ---

    def test_gbt_partial_fit_returns_none(self):
        _require()
        schema, Xtr, ytr, _ = self._data()
        assert OnlineGBTRegressor(schema=schema).partial_fit(Xtr, ytr) is None

    def test_gbt_predict_shape(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        est = OnlineGBTRegressor(schema=schema)
        est.partial_fit(Xtr, ytr)
        out = est.predict(Xte)
        assert isinstance(out, np.ndarray) and out.shape == (15,)
        assert np.issubdtype(out.dtype, np.floating)

    def test_gbt_predict_proba_shape_and_nonneg(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        est = OnlineGBTRegressor(schema=schema)
        est.partial_fit(Xtr, ytr)
        out = est.predict_proba(Xte)
        assert isinstance(out, np.ndarray) and out.shape == (15,)
        assert (out >= 0).all()

    def test_gbt_multiple_partial_fit_calls(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        est = OnlineGBTRegressor(schema=schema)
        for _ in range(3):
            assert est.partial_fit(Xtr[:20], ytr[:20]) is None
        assert est.predict(Xte).shape == (15,)


# ===========================================================================
# 6. Classification estimators
# ===========================================================================

class TestClassificationEstimators:

    N_CLASSES = 3

    def _data(self):
        schema = _schema(("a", "numeric"), ("b", "numeric"))
        return schema, _X(60, 2, 20), _y_cls(60, self.N_CLASSES, 21), _X(12, 2, 22)

    def _check_predict(self, est, Xtr, ytr, Xte):
        est.partial_fit(Xtr, ytr)
        out = est.predict(Xte)
        assert isinstance(out, np.ndarray) and out.shape == (12,)
        assert np.issubdtype(out.dtype, np.integer)
        assert (out >= 0).all() and (out < self.N_CLASSES).all()

    def _check_proba(self, est, Xtr, ytr, Xte):
        est.partial_fit(Xtr, ytr)
        out = est.predict_proba(Xte)
        assert isinstance(out, np.ndarray) and out.shape == (12, self.N_CLASSES)
        assert np.allclose(out.sum(axis=1), 1.0, atol=1e-6)

    # --- OnlineLogisticClassifier ---

    def test_logistic_partial_fit_returns_none(self):
        _require()
        schema, Xtr, ytr, _ = self._data()
        assert OnlineLogisticClassifier(schema=schema, n_classes=self.N_CLASSES).partial_fit(Xtr, ytr) is None

    def test_logistic_predict_shape_dtype_range(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        self._check_predict(OnlineLogisticClassifier(schema=schema, n_classes=self.N_CLASSES), Xtr, ytr, Xte)

    def test_logistic_predict_proba_shape_and_sum(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        self._check_proba(OnlineLogisticClassifier(schema=schema, n_classes=self.N_CLASSES), Xtr, ytr, Xte)

    def test_logistic_predict_equals_argmax_of_predict_proba(self):
        """predict labels must equal argmax of predict_proba rows (temperature scaling preserves argmax)."""
        _require()
        schema, Xtr, ytr, Xte = self._data()
        est = OnlineLogisticClassifier(schema=schema, n_classes=self.N_CLASSES)
        est.partial_fit(Xtr, ytr)
        labels = est.predict(Xte)
        proba = est.predict_proba(Xte)
        assert np.array_equal(labels, np.argmax(proba, axis=1))

    # --- OnlineNaiveBayes ---

    def test_naive_bayes_partial_fit_returns_none(self):
        _require()
        schema, Xtr, ytr, _ = self._data()
        assert OnlineNaiveBayes(schema=schema, n_classes=self.N_CLASSES).partial_fit(Xtr, ytr) is None

    def test_naive_bayes_predict_shape_dtype_range(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        self._check_predict(OnlineNaiveBayes(schema=schema, n_classes=self.N_CLASSES), Xtr, ytr, Xte)

    def test_naive_bayes_predict_proba_shape_and_sum(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        self._check_proba(OnlineNaiveBayes(schema=schema, n_classes=self.N_CLASSES), Xtr, ytr, Xte)

    # --- OnlineRandomForest ---

    def test_random_forest_partial_fit_returns_none(self):
        _require()
        schema, Xtr, ytr, _ = self._data()
        assert OnlineRandomForest(schema=schema, n_classes=self.N_CLASSES).partial_fit(Xtr, ytr) is None

    def test_random_forest_predict_shape_dtype_range(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        self._check_predict(OnlineRandomForest(schema=schema, n_classes=self.N_CLASSES), Xtr, ytr, Xte)

    def test_random_forest_predict_proba_shape_and_sum(self):
        _require()
        schema, Xtr, ytr, Xte = self._data()
        self._check_proba(OnlineRandomForest(schema=schema, n_classes=self.N_CLASSES), Xtr, ytr, Xte)


# ===========================================================================
# 7. Clustering estimators
# ===========================================================================

class TestClusteringEstimators:

    def _schema(self):
        return _schema(("a", "numeric"), ("b", "numeric"))

    # --- IncrementalKMeans ---

    def _km(self, schema):
        return IncrementalKMeans(schema=schema, n_clusters=3,
                                 split_variance_threshold=10.0, merge_distance_threshold=0.01)

    def test_kmeans_partial_fit_returns_none(self):
        _require()
        schema = self._schema()
        assert self._km(schema).partial_fit(_X(80, 2, 30), np.zeros(80)) is None

    def test_kmeans_accepts_arbitrary_y(self):
        _require()
        schema = self._schema()
        y_arb = np.random.default_rng(99).standard_normal(80)
        assert self._km(schema).partial_fit(_X(80, 2, 30), y_arb) is None

    def test_kmeans_predict_shape_and_dtype(self):
        _require()
        schema = self._schema()
        km = self._km(schema)
        km.partial_fit(_X(80, 2, 30), np.zeros(80))
        out = km.predict(_X(20, 2, 31))
        assert isinstance(out, np.ndarray) and out.shape == (20,)
        assert np.issubdtype(out.dtype, np.integer)

    def test_kmeans_predict_proba_2d_rows_sum_to_one(self):
        _require()
        schema = self._schema()
        km = self._km(schema)
        Xtr, Xte = _X(80, 2, 30), _X(20, 2, 31)
        km.partial_fit(Xtr, np.zeros(80))
        labels = km.predict(Xte)
        out = km.predict_proba(Xte)
        assert isinstance(out, np.ndarray) and out.ndim == 2 and out.shape[0] == 20
        assert out.shape[1] >= 1
        assert np.allclose(out.sum(axis=1), 1.0, atol=1e-6)
        # All cluster labels from predict must be valid column indices in predict_proba
        valid_labels = labels[labels >= 0]  # exclude noise (-1) if any
        if len(valid_labels) > 0:
            assert valid_labels.max() < out.shape[1]

    def test_kmeans_multiple_partial_fit_calls(self):
        _require()
        schema = self._schema()
        km = self._km(schema)
        Xtr = _X(80, 2, 30)
        for _ in range(4):
            km.partial_fit(Xtr[:20], np.zeros(20))
        assert km.predict(_X(20, 2, 31)).shape == (20,)

    # --- OnlineDBSCAN ---

    def _db(self, schema):
        return OnlineDBSCAN(schema=schema, eps=0.5, min_samples=5, window_size=200)

    def test_dbscan_partial_fit_returns_none(self):
        _require()
        schema = self._schema()
        assert self._db(schema).partial_fit(_X(80, 2, 32), np.zeros(80)) is None

    def test_dbscan_accepts_arbitrary_y(self):
        _require()
        schema = self._schema()
        y_arb = np.random.default_rng(88).standard_normal(80)
        assert self._db(schema).partial_fit(_X(80, 2, 32), y_arb) is None

    def test_dbscan_predict_shape_and_dtype(self):
        _require()
        schema = self._schema()
        db = self._db(schema)
        db.partial_fit(_X(80, 2, 32), np.zeros(80))
        out = db.predict(_X(20, 2, 33))
        assert isinstance(out, np.ndarray) and out.shape == (20,)
        assert np.issubdtype(out.dtype, np.integer)

    def test_dbscan_predict_labels_geq_minus_one(self):
        _require()
        schema = self._schema()
        db = self._db(schema)
        db.partial_fit(_X(80, 2, 32), np.zeros(80))
        out = db.predict(_X(20, 2, 33))
        assert (out >= -1).all()

    def test_dbscan_predict_proba_shape_and_range(self):
        _require()
        schema = self._schema()
        db = self._db(schema)
        db.partial_fit(_X(80, 2, 32), np.zeros(80))
        out = db.predict_proba(_X(20, 2, 33))
        assert isinstance(out, np.ndarray) and out.shape == (20, 1)
        assert (out >= 0.0).all() and (out <= 1.0).all()

    def test_dbscan_multiple_partial_fit_calls(self):
        _require()
        schema = self._schema()
        db = self._db(schema)
        Xtr = _X(80, 2, 32)
        for _ in range(3):
            db.partial_fit(Xtr[:20], np.zeros(20))
        assert db.predict(_X(20, 2, 33)).shape == (20,)

    # --- IncrementalKMeans split/merge behavior ---

    def test_kmeans_split_triggers_on_high_variance(self):
        """Cluster intra-variance far above split_variance_threshold must produce more clusters."""
        _require()
        schema = self._schema()
        # split_variance_threshold near-zero forces every cluster to split;
        # merge_distance_threshold near-zero prevents any merges masking the splits.
        km = IncrementalKMeans(
            schema=schema, n_clusters=2,
            split_variance_threshold=1e-6,
            merge_distance_threshold=1e-9,
        )
        # Highly spread data: points at [-100, 0] and [100, 0] - intra-cluster
        # variance vastly exceeds 1e-6, so both clusters must split.
        rng = np.random.default_rng(200)
        X_spread = np.vstack([
            rng.standard_normal((30, 2)) * 0.01 + np.array([-100.0, 0.0]),
            rng.standard_normal((30, 2)) * 0.01 + np.array([100.0, 0.0]),
        ])
        km.partial_fit(X_spread, np.zeros(60))
        out = km.predict_proba(X_spread[:10])
        assert out.shape[1] > 2, (
            f"Expected more than 2 clusters after split, got {out.shape[1]}"
        )

    def test_kmeans_merge_triggers_on_close_centroids(self):
        """Centroids closer than merge_distance_threshold must be merged."""
        _require()
        schema = self._schema()
        # merge_distance_threshold=1e6 (near-infinite) merges every pair of centroids;
        # split_variance_threshold=1e12 (near-infinite) prevents any splits.
        km = IncrementalKMeans(
            schema=schema, n_clusters=5,
            split_variance_threshold=1e12,
            merge_distance_threshold=1e6,
        )
        # All points at the same location: all 5 centroids converge to [0, 0],
        # distance between any two == 0 << 1e6, forcing merges.
        X_single = np.zeros((50, 2))
        km.partial_fit(X_single, np.zeros(50))
        out = km.predict_proba(X_single[:10])
        assert out.shape[1] < 5, (
            f"Expected fewer than 5 clusters after merge, got {out.shape[1]}"
        )

    # --- OnlineDBSCAN window eviction ---

    def test_dbscan_window_eviction(self):
        """OnlineDBSCAN must remain functional when fed more than window_size points."""
        _require()
        schema = self._schema()
        window_size = 10
        db = OnlineDBSCAN(schema=schema, eps=0.5, min_samples=3, window_size=window_size)
        rng = np.random.default_rng(210)
        # Feed 5× window_size points in batches - eviction must keep storage bounded
        # and the estimator must remain functional throughout.
        for _ in range(5):
            db.partial_fit(rng.standard_normal((window_size, 2)) * 0.1, np.zeros(window_size))
        out = db.predict(rng.standard_normal((10, 2)) * 0.1)
        assert isinstance(out, np.ndarray) and out.shape == (10,)
        assert np.issubdtype(out.dtype, np.integer) and (out >= -1).all()

    def test_dbscan_labels_isolated_point_as_noise(self):
        """A point that cannot satisfy min_samples within eps must receive label -1."""
        _require()
        schema = self._schema()
        # Tight cluster at origin - 20 points within eps=0.5 of each other, satisfying min_samples=5.
        db = OnlineDBSCAN(schema=schema, eps=0.5, min_samples=5, window_size=200)
        X_cluster = np.random.default_rng(220).standard_normal((20, 2)) * 0.1
        db.partial_fit(X_cluster, np.zeros(20))
        # A point 1000 units away has no neighbours within eps - it must be noise.
        pred = db.predict(np.full((1, 2), 1000.0))
        assert pred[0] == -1, (
            "A point isolated 1000 units from all training data must be labeled noise (-1)"
        )


# ===========================================================================
# 8. Anomaly detection estimators
# ===========================================================================

class TestAnomalyDetectionEstimators:

    def _schema(self):
        return _schema(("a", "numeric"), ("b", "numeric"))

    def _check_predict_binary(self, est, Xtr, Xte):
        est.partial_fit(Xtr, np.zeros(len(Xtr)))
        out = est.predict(Xte)
        assert isinstance(out, np.ndarray) and out.shape == (len(Xte),)
        assert np.issubdtype(out.dtype, np.integer)
        assert set(out).issubset({0, 1})

    def _check_proba(self, est, Xtr, Xte):
        est.partial_fit(Xtr, np.zeros(len(Xtr)))
        out = est.predict_proba(Xte)
        assert isinstance(out, np.ndarray) and out.shape == (len(Xte),)
        assert (out >= 0.0).all() and (out <= 1.0).all()

    # --- HalfSpaceTrees ---

    def test_hst_partial_fit_returns_none(self):
        _require()
        schema = self._schema()
        hst = HalfSpaceTrees(schema=schema, n_trees=10, window_size=100)
        assert hst.partial_fit(_X(100, 2, 40), np.zeros(100)) is None

    def test_hst_accepts_arbitrary_y(self):
        _require()
        schema = self._schema()
        hst = HalfSpaceTrees(schema=schema, n_trees=10, window_size=100)
        y_arb = np.random.default_rng(77).standard_normal(100)
        assert hst.partial_fit(_X(100, 2, 40), y_arb) is None

    def test_hst_predict_binary(self):
        _require()
        schema = self._schema()
        Xtr, Xte = _X(100, 2, 40), _X(10, 2, 41)
        self._check_predict_binary(HalfSpaceTrees(schema=schema, n_trees=10, window_size=100), Xtr, Xte)

    def test_hst_predict_proba_shape_and_range(self):
        _require()
        schema = self._schema()
        Xtr, Xte = _X(100, 2, 40), _X(10, 2, 41)
        self._check_proba(HalfSpaceTrees(schema=schema, n_trees=10, window_size=100), Xtr, Xte)

    def test_hst_multiple_partial_fit_calls(self):
        _require()
        schema = self._schema()
        hst = HalfSpaceTrees(schema=schema, n_trees=10, window_size=100)
        Xtr = _X(100, 2, 40)
        for _ in range(3):
            hst.partial_fit(Xtr[:30], np.zeros(30))
        assert hst.predict(_X(10, 2, 41)).shape == (10,)

    # --- OnlineQuantileDetector ---

    def test_oqd_partial_fit_returns_none(self):
        _require()
        schema = self._schema()
        oqd = OnlineQuantileDetector(schema=schema, quantile=0.95, window_size=100)
        assert oqd.partial_fit(_X(100, 2, 42), np.zeros(100)) is None

    def test_oqd_accepts_arbitrary_y(self):
        _require()
        schema = self._schema()
        oqd = OnlineQuantileDetector(schema=schema, quantile=0.95, window_size=100)
        y_arb = np.random.default_rng(66).standard_normal(100)
        assert oqd.partial_fit(_X(100, 2, 42), y_arb) is None

    def test_oqd_predict_binary(self):
        _require()
        schema = self._schema()
        Xtr, Xte = _X(100, 2, 42), _X(10, 2, 43)
        self._check_predict_binary(OnlineQuantileDetector(schema=schema, quantile=0.95, window_size=100), Xtr, Xte)

    def test_oqd_predict_proba_shape_and_range(self):
        _require()
        schema = self._schema()
        Xtr, Xte = _X(100, 2, 42), _X(10, 2, 43)
        self._check_proba(OnlineQuantileDetector(schema=schema, quantile=0.95, window_size=100), Xtr, Xte)

    def test_oqd_flags_extreme_outliers_as_anomalous(self):
        """Samples 1000 std-devs from training mean must receive predict=1."""
        _require()
        schema = self._schema()
        oqd = OnlineQuantileDetector(schema=schema, quantile=0.5, window_size=200)
        oqd.partial_fit(np.random.default_rng(50).standard_normal((200, 2)), np.zeros(200))
        preds = oqd.predict(np.full((5, 2), 1000.0))
        assert (preds == 1).all(), "Extreme outliers must be flagged as anomalous"

    def test_oqd_multiple_partial_fit_calls(self):
        _require()
        schema = self._schema()
        oqd = OnlineQuantileDetector(schema=schema, quantile=0.95, window_size=100)
        Xtr = _X(100, 2, 42)
        for _ in range(3):
            oqd.partial_fit(Xtr[:30], np.zeros(30))
        assert oqd.predict(_X(10, 2, 43)).shape == (10,)


# ===========================================================================
# 9. RollingMetrics
# ===========================================================================

class TestRollingMetrics:

    def test_update_returns_none(self):
        _require()
        rm = RollingMetrics(window_size=50, task="regression")
        assert rm.update(np.array([1.0, 2.0]), np.array([1.0, 2.0])) is None

    def test_regression_metric_keys(self):
        _require()
        rm = RollingMetrics(window_size=50, task="regression")
        rm.update(np.array([1.0, 2.0, 3.0]), np.array([1.0, 2.0, 3.0]))
        m = rm.get_metrics()
        assert set(m.keys()) == {"mse", "mae"}
        assert isinstance(m["mse"], float) and isinstance(m["mae"], float)

    def test_regression_mse_correct(self):
        _require()
        rm = RollingMetrics(window_size=100, task="regression")
        rm.update(np.zeros(4), np.ones(4))   # error=1 per sample -> mse=1.0
        assert rm.get_metrics()["mse"] == pytest.approx(1.0, abs=1e-6)

    def test_regression_mae_correct(self):
        _require()
        rm = RollingMetrics(window_size=100, task="regression")
        rm.update(np.zeros(4), np.full(4, 2.0))  # error=2 per sample -> mae=2.0
        assert rm.get_metrics()["mae"] == pytest.approx(2.0, abs=1e-6)

    def test_classification_metric_keys(self):
        _require()
        rm = RollingMetrics(window_size=50, task="classification")
        rm.update(np.array([0, 1, 2, 0]), np.array([0, 1, 2, 1]))
        m = rm.get_metrics()
        assert set(m.keys()) == {"accuracy", "f1"}
        assert isinstance(m["accuracy"], float) and isinstance(m["f1"], float)

    def test_classification_accuracy_perfect(self):
        _require()
        rm = RollingMetrics(window_size=100, task="classification")
        y = np.array([0, 1, 2, 0, 1])
        rm.update(y, y)
        assert rm.get_metrics()["accuracy"] == pytest.approx(1.0, abs=1e-6)

    def test_clustering_metric_keys(self):
        _require()
        rm = RollingMetrics(window_size=50, task="clustering")
        rm.update(np.array([0, 1, 2, 0, 1]), np.array([0, 1, 2, 0, 1]))
        m = rm.get_metrics()
        assert set(m.keys()) == {"label_entropy"}
        assert isinstance(m["label_entropy"], float)

    def test_clustering_label_entropy_nonnegative(self):
        _require()
        rm = RollingMetrics(window_size=100, task="clustering")
        rm.update(np.zeros(10, dtype=int), np.array([0, 1, 0, 1, 2, 2, 0, 1, 2, 0]))
        assert rm.get_metrics()["label_entropy"] >= 0.0

    def test_anomaly_metric_keys(self):
        _require()
        rm = RollingMetrics(window_size=50, task="anomaly")
        rm.update(np.array([0, 1, 0, 1]), np.array([0, 1, 0, 1]))
        m = rm.get_metrics()
        assert set(m.keys()) == {"precision", "recall"}
        assert isinstance(m["precision"], float) and isinstance(m["recall"], float)

    def test_anomaly_perfect_precision_recall(self):
        _require()
        rm = RollingMetrics(window_size=100, task="anomaly")
        y = np.array([0, 0, 1, 1])
        rm.update(y, y)
        m = rm.get_metrics()
        assert m["precision"] == pytest.approx(1.0, abs=1e-6)
        assert m["recall"] == pytest.approx(1.0, abs=1e-6)

    def test_window_discards_old_samples(self):
        """After the window is fully replaced, old samples must not affect metrics."""
        _require()
        rm = RollingMetrics(window_size=4, task="regression")
        rm.update(np.zeros(4), np.full(4, 10.0))   # error=10, mse=100
        rm.update(np.zeros(4), np.zeros(4))          # error=0; old 4 discarded
        assert rm.get_metrics()["mse"] == pytest.approx(0.0, abs=1e-6)


# ===========================================================================
# 10. DriftAlert
# ===========================================================================

class TestDriftAlert:

    def test_alert_type_field(self):
        _require()
        assert DriftAlert(alert_type="error", feature_name=None, p_value=0.05).alert_type == "error"

    def test_feature_name_field(self):
        _require()
        assert DriftAlert(alert_type="feature", feature_name="temp", p_value=0.01).feature_name == "temp"

    def test_feature_name_none_for_error_alert(self):
        _require()
        assert DriftAlert(alert_type="error", feature_name=None, p_value=0.03).feature_name is None

    def test_p_value_field(self):
        _require()
        assert DriftAlert(alert_type="feature", feature_name="x", p_value=0.02).p_value == pytest.approx(0.02)

    def test_is_dataclass(self):
        _require()
        assert dataclasses.is_dataclass(DriftAlert)


# ===========================================================================
# 11. DriftDetector
# ===========================================================================

class TestDriftDetector:

    def _schema(self):
        return _schema(("x", "numeric"), ("y", "numeric"))

    def test_update_returns_none(self):
        _require()
        det = DriftDetector(schema=self._schema(), error_window=100, feature_window=100)
        assert det.update(_X(10, 2), np.zeros(10)) is None

    def test_get_alerts_returns_list(self):
        _require()
        det = DriftDetector(schema=self._schema(), error_window=200, feature_window=200)
        rng = np.random.default_rng(60)
        det.update(rng.standard_normal((200, 2)), np.zeros(200))
        det.update(rng.standard_normal((200, 2)) + 1000.0, np.zeros(200))
        result = det.get_alerts()
        assert isinstance(result, list)
        assert all(isinstance(a, DriftAlert) for a in result)

    def test_feature_drift_detected_on_extreme_shift(self):
        _require()
        schema = self._schema()
        det = DriftDetector(schema=schema, error_window=200, feature_window=200)
        rng = np.random.default_rng(61)
        det.update(rng.standard_normal((200, 2)), np.zeros(200))
        det.update(rng.standard_normal((200, 2)) + 1000.0, np.zeros(200))
        feature_alerts = [a for a in det.get_alerts() if a.alert_type == "feature"]
        assert len(feature_alerts) >= 1, (
            "Expected at least one feature-type alert after extreme distribution shift"
        )
        for alert in feature_alerts:
            assert alert.feature_name in schema.feature_names

    def test_feature_alert_name_in_schema(self):
        _require()
        schema = self._schema()
        det = DriftDetector(schema=schema, error_window=200, feature_window=200)
        rng = np.random.default_rng(62)
        det.update(rng.standard_normal((200, 2)), np.zeros(200))
        det.update(rng.standard_normal((200, 2)) + 1000.0, np.zeros(200))
        for alert in det.get_alerts():
            if alert.alert_type == "feature":
                assert alert.feature_name in schema.feature_names
            else:
                assert alert.feature_name is None

    def test_error_drift_detected_on_extreme_shift(self):
        _require()
        det = DriftDetector(schema=self._schema(), error_window=200, feature_window=200)
        stable_X = np.random.default_rng(63).standard_normal((200, 2))
        det.update(stable_X, np.zeros(200))
        det.update(stable_X, np.full(200, 10_000.0))
        error_alerts = [a for a in det.get_alerts() if a.alert_type == "error"]
        assert len(error_alerts) >= 1, (
            f"Expected at least one error-type alert for the introduced shift, got {len(error_alerts)}"
        )

    def test_error_alert_feature_name_is_none(self):
        _require()
        det = DriftDetector(schema=self._schema(), error_window=200, feature_window=200)
        rng = np.random.default_rng(64)
        det.update(rng.standard_normal((200, 2)), np.zeros(200))
        det.update(rng.standard_normal((200, 2)), np.full(200, 10_000.0))
        for alert in det.get_alerts():
            if alert.alert_type == "error":
                assert alert.feature_name is None

    def test_p_value_is_float(self):
        _require()
        det = DriftDetector(schema=self._schema(), error_window=200, feature_window=200)
        rng = np.random.default_rng(65)
        det.update(rng.standard_normal((200, 2)), np.zeros(200))
        det.update(rng.standard_normal((200, 2)) + 1000.0, np.zeros(200))
        for alert in det.get_alerts():
            assert isinstance(alert.p_value, float)


# ===========================================================================
# 12. SnapshotManager
#     Uses tempfile.mkdtemp() instead of pytest tmp_path fixture so that
#     all setup stays inside the test body - guaranteeing FAILED not ERROR.
# ===========================================================================

class TestSnapshotManager:

    def _setup(self):
        """Returns (mgr, est, X_test, tmp_dir). Call only after _require()."""
        tmp_dir = tempfile.mkdtemp()
        schema = _schema(("a", "numeric"), ("b", "numeric"))
        est = OnlineLinearRegressor(schema=schema)
        est.partial_fit(_X(50, 2, 70), _y_reg(50, 71))
        mgr = SnapshotManager(directory=tmp_dir, schedule_interval=5)
        X_te = _X(10, 2, 72)
        return mgr, est, X_te, tmp_dir

    def test_save_returns_string(self):
        _require()
        mgr, est, _, _ = self._setup()
        path = mgr.save(est, "t1")
        assert isinstance(path, str)
        assert Path(path).is_absolute()

    def test_save_creates_pkl_file(self):
        _require()
        mgr, est, _, _ = self._setup()
        path = mgr.save(est, "t2")
        assert Path(path).exists()

    def test_save_path_ends_with_pkl(self):
        _require()
        mgr, est, _, _ = self._setup()
        assert mgr.save(est, "t3").endswith(".pkl")

    def test_save_load_roundtrip_identical_predictions(self):
        _require()
        mgr, est, X_te, _ = self._setup()
        preds_before = est.predict(X_te)
        mgr.save(est, "t5")
        assert np.allclose(preds_before, mgr.load("t5").predict(X_te))

    def test_checkpoint_returns_path_at_multiple_of_interval(self):
        _require()
        mgr, est, _, _ = self._setup()
        result = mgr.checkpoint(est, step=5)
        assert isinstance(result, str)
        assert Path(result).is_absolute()
        assert Path(result).exists()

    def test_checkpoint_returns_none_between_multiples(self):
        _require()
        mgr, est, _, _ = self._setup()
        for step in [1, 2, 3, 4, 6, 7, 8, 9, 11]:
            assert mgr.checkpoint(est, step=step) is None, f"Expected None at step {step}"

    def test_checkpoint_path_contains_step_number(self):
        _require()
        mgr, est, _, _ = self._setup()
        mgr2 = SnapshotManager(directory=tempfile.mkdtemp(), schedule_interval=10)
        path = mgr2.checkpoint(est, step=10)
        assert Path(path).name == "checkpoint_10.pkl"

    def test_checkpoint_at_step_zero_saves(self):
        _require()
        mgr, est, _, _ = self._setup()
        result = mgr.checkpoint(est, step=0)
        assert isinstance(result, str)
        assert Path(result).is_absolute()
        assert Path(result).exists()


# ===========================================================================
# 13. ChampionChallenger
# ===========================================================================

class TestChampionChallenger:

    def _schema(self):
        return _schema(("a", "numeric"), ("b", "numeric"))

    def test_feed_returns_none(self):
        _require()
        schema = self._schema()
        cc = ChampionChallenger(
            champion=OnlineLinearRegressor(schema=schema),
            challenger=OnlineGBTRegressor(schema=schema),
            window_size=50, task="regression",
        )
        assert cc.feed(_X(40, 2, 80), _y_reg(40, 81)) is None

    def test_get_comparison_top_level_keys(self):
        _require()
        schema = self._schema()
        cc = ChampionChallenger(
            champion=OnlineLinearRegressor(schema=schema),
            challenger=OnlineGBTRegressor(schema=schema),
            window_size=50, task="regression",
        )
        cc.feed(_X(40, 2, 80), _y_reg(40, 81))
        comp = cc.get_comparison()
        assert set(comp.keys()) == {"champion", "challenger"}

    def test_get_comparison_regression_metric_keys(self):
        _require()
        schema = self._schema()
        cc = ChampionChallenger(
            champion=OnlineLinearRegressor(schema=schema),
            challenger=OnlineGBTRegressor(schema=schema),
            window_size=50, task="regression",
        )
        cc.feed(_X(40, 2, 80), _y_reg(40, 81))
        comp = cc.get_comparison()
        for side in ("champion", "challenger"):
            assert set(comp[side].keys()) == {"mse", "mae"}

    def test_get_comparison_classification_metric_keys(self):
        _require()
        schema = self._schema()
        cc = ChampionChallenger(
            champion=OnlineLogisticClassifier(schema=schema, n_classes=3),
            challenger=OnlineNaiveBayes(schema=schema, n_classes=3),
            window_size=50, task="classification",
        )
        cc.feed(_X(40, 2, 80), _y_cls(40, 3, 82))
        comp = cc.get_comparison()
        for side in ("champion", "challenger"):
            assert set(comp[side].keys()) == {"accuracy", "f1"}

    def test_get_comparison_anomaly_metric_keys(self):
        _require()
        schema = self._schema()
        y_binary = (_y_reg(40, 81) > 0).astype(int)
        cc = ChampionChallenger(
            champion=HalfSpaceTrees(schema=schema, n_trees=5, window_size=50),
            challenger=OnlineQuantileDetector(schema=schema, quantile=0.9, window_size=50),
            window_size=50, task="anomaly",
        )
        cc.feed(_X(40, 2, 80), y_binary)
        comp = cc.get_comparison()
        for side in ("champion", "challenger"):
            assert set(comp[side].keys()) == {"precision", "recall"}

    def test_get_comparison_clustering_metric_keys(self):
        _require()
        schema = self._schema()
        cc = ChampionChallenger(
            champion=IncrementalKMeans(
                schema=schema, n_clusters=3,
                split_variance_threshold=10.0, merge_distance_threshold=0.01,
            ),
            challenger=OnlineDBSCAN(schema=schema, eps=0.5, min_samples=5, window_size=100),
            window_size=50, task="clustering",
        )
        cc.feed(_X(40, 2, 84), np.zeros(40, dtype=int))
        comp = cc.get_comparison()
        for side in ("champion", "challenger"):
            assert set(comp[side].keys()) == {"label_entropy"}
            assert isinstance(comp[side]["label_entropy"], float)

    def test_get_comparison_values_are_floats(self):
        _require()
        schema = self._schema()
        cc = ChampionChallenger(
            champion=OnlineLinearRegressor(schema=schema),
            challenger=OnlineGBTRegressor(schema=schema),
            window_size=50, task="regression",
        )
        cc.feed(_X(40, 2, 80), _y_reg(40, 81))
        for side in ("champion", "challenger"):
            for v in cc.get_comparison()[side].values():
                assert isinstance(v, float)

    def test_feed_trains_both_estimators(self):
        """feed must call partial_fit on both champion and challenger."""
        _require()
        schema = self._schema()
        champ = OnlineLinearRegressor(schema=schema)
        chall = OnlineGBTRegressor(schema=schema)
        cc = ChampionChallenger(
            champion=champ, challenger=chall, window_size=50, task="regression",
        )
        champ_fit_calls = [0]
        chall_fit_calls = [0]
        orig_champ_fit = champ.partial_fit
        orig_chall_fit = chall.partial_fit

        def spy_champ_fit(X, y):
            champ_fit_calls[0] += 1
            return orig_champ_fit(X, y)

        def spy_chall_fit(X, y):
            chall_fit_calls[0] += 1
            return orig_chall_fit(X, y)

        champ.partial_fit = spy_champ_fit
        chall.partial_fit = spy_chall_fit
        cc.feed(_X(20, 2, 80), _y_reg(20, 81))
        assert champ_fit_calls[0] >= 1, "champion.partial_fit was not called by feed"
        assert chall_fit_calls[0] >= 1, "challenger.partial_fit was not called by feed"

    def test_multiple_feed_calls_accumulate_metrics(self):
        _require()
        schema = self._schema()
        cc = ChampionChallenger(
            champion=OnlineLinearRegressor(schema=schema),
            challenger=OnlineGBTRegressor(schema=schema),
            window_size=50, task="regression",
        )
        Xb, yb = _X(8, 2, 80), _y_reg(8, 81)
        for _ in range(5):
            cc.feed(Xb, yb)
        comp = cc.get_comparison()
        assert set(comp.keys()) == {"champion", "challenger"}
        for side in ("champion", "challenger"):
            assert np.isfinite(comp[side]["mse"]), f"{side} mse is not finite after feed"
            assert np.isfinite(comp[side]["mae"]), f"{side} mae is not finite after feed"

    def test_feed_uses_pretrain_predictions(self):
        """feed must call predict on both estimators BEFORE calling partial_fit on both."""
        _require()
        schema = self._schema()
        champ = OnlineLinearRegressor(schema=schema)
        chall = OnlineGBTRegressor(schema=schema)
        cc = ChampionChallenger(
            champion=champ, challenger=chall, window_size=50, task="regression",
        )
        call_log = []
        orig_champ_predict = champ.predict
        orig_champ_fit = champ.partial_fit
        orig_chall_predict = chall.predict
        orig_chall_fit = chall.partial_fit

        def spy_champ_predict(X):
            call_log.append("champ_predict")
            return orig_champ_predict(X)

        def spy_champ_fit(X, y):
            call_log.append("champ_fit")
            return orig_champ_fit(X, y)

        def spy_chall_predict(X):
            call_log.append("chall_predict")
            return orig_chall_predict(X)

        def spy_chall_fit(X, y):
            call_log.append("chall_fit")
            return orig_chall_fit(X, y)

        champ.predict = spy_champ_predict
        champ.partial_fit = spy_champ_fit
        chall.predict = spy_chall_predict
        chall.partial_fit = spy_chall_fit

        cc.feed(np.ones((5, 2)), _y_reg(5, 80))

        for name in ("champ_predict", "champ_fit", "chall_predict", "chall_fit"):
            assert name in call_log, f"{name} was not called during feed"
        assert call_log.index("champ_predict") < call_log.index("champ_fit"), (
            "champion predict must be called before champion partial_fit"
        )
        assert call_log.index("chall_predict") < call_log.index("chall_fit"), (
            "challenger predict must be called before challenger partial_fit"
        )