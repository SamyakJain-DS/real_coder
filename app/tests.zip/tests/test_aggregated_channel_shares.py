import pandas as pd
import pytest


def test_aggregated_channel_shares_equals_mean_credit_across_converted_journeys(import_or_fail):
    attr = import_or_fail("app.attribution")
    journey_credits = pd.DataFrame(
        [
            {"journey_id": "J1", "converted": 1, "A": 0.25, "B": 0.75},
            {"journey_id": "J2", "converted": 0, "A": 0.9, "B": 0.1},
        ]
    )
    shares = attr.compute_aggregated_channel_shares(journey_credits)
    assert shares["A"] == pytest.approx(0.25)
    assert shares["B"] == pytest.approx(0.75)


def test_aggregated_channel_shares_sum_to_one_when_converted_journeys_exist(import_or_fail):
    attr = import_or_fail("app.attribution")
    journey_credits = pd.DataFrame(
        [
            {"journey_id": "J1", "converted": 1, "A": 1.0, "B": 0.0},
            {"journey_id": "J2", "converted": 1, "A": 0.0, "B": 1.0},
        ]
    )
    shares = attr.compute_aggregated_channel_shares(journey_credits)
    assert float(shares.sum()) == pytest.approx(1.0)


def test_aggregated_channel_shares_are_all_zero_when_no_converted_journeys(import_or_fail):
    attr = import_or_fail("app.attribution")
    journey_credits = pd.DataFrame(
        [
            {"journey_id": "J1", "converted": 0, "A": 0.5, "B": 0.5},
            {"journey_id": "J2", "converted": 0, "A": 0.5, "B": 0.5},
        ]
    )
    shares = attr.compute_aggregated_channel_shares(journey_credits)
    assert shares["A"] == pytest.approx(0.0)
    assert shares["B"] == pytest.approx(0.0)

def test_aggregated_channel_shares_retains_zero_credit_channel_in_index(import_or_fail):
    attr = import_or_fail("app.attribution")
    journey_credits = pd.DataFrame(
        [
            {"journey_id": "J1", "converted": 1, "A": 1.0, "B": 0.0},
            {"journey_id": "J2", "converted": 1, "A": 1.0, "B": 0.0},
        ]
    )
    shares = attr.compute_aggregated_channel_shares(journey_credits)
    assert "B" in shares.index
    assert shares["B"] == pytest.approx(0.0)