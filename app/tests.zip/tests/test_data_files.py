import pytest
import os
import pandas as pd

def test_receipts_csv_has_required_columns(project_root):
    path = os.path.join(project_root, "data", "receipts.csv")
    if not os.path.isfile(path):
        pytest.fail("data/receipts.csv not found")
    df = pd.read_csv(path, nrows=0)
    expected_cols = {"isbn", "store", "price", "arrival_date", "sell_date"}
    assert set(df.columns) == expected_cols


def test_receipts_csv_distinct_stores(project_root):
    path = os.path.join(project_root, "data", "receipts.csv")
    if not os.path.isfile(path):
        pytest.fail("data/receipts.csv not found")
    df = pd.read_csv(path)
    assert df["store"].nunique() == 5


def test_receipts_csv_distinct_isbns(project_root):
    path = os.path.join(project_root, "data", "receipts.csv")
    if not os.path.isfile(path):
        pytest.fail("data/receipts.csv not found")
    df = pd.read_csv(path)
    assert df["isbn"].nunique() == 50


def test_receipts_csv_date_years(project_root):
    path = os.path.join(project_root, "data", "receipts.csv")
    if not os.path.isfile(path):
        pytest.fail("data/receipts.csv not found")
    df = pd.read_csv(path)
    dates = pd.to_datetime(df["arrival_date"])
    years = set(dates.dt.year.unique())
    assert years == {2022, 2023, 2024}, (
        f"Dataset must span exactly years 2022, 2023, and 2024; got {years}"
    )


def test_receipts_csv_sold_ratio(project_root):
    path = os.path.join(project_root, "data", "receipts.csv")
    if not os.path.isfile(path):
        pytest.fail("data/receipts.csv not found")
    df = pd.read_csv(path, keep_default_na=False)
    total = len(df)
    sold = (df["sell_date"].str.strip().str.len() > 0).sum()
    assert 5 * int(sold) == 3 * total, f"Exactly 60% of rows must have sell_date populated, got {sold}/{total}"


def test_receipts_csv_date_format(project_root):
    path = os.path.join(project_root, "data", "receipts.csv")
    if not os.path.isfile(path):
        pytest.fail("data/receipts.csv not found")
    import re
    df = pd.read_csv(path, keep_default_na=False)
    pattern = re.compile(r"^\d{4}-\d{2}-\d{2}$")
    for val in df["arrival_date"]:
        assert pattern.match(str(val)), (
            f"arrival_date value {val!r} does not match YYYY-MM-DD format"
        )
    for val in df["sell_date"]:
        if str(val).strip():
            assert pattern.match(str(val).strip()), (
                f"sell_date value {val!r} does not match YYYY-MM-DD format"
            )