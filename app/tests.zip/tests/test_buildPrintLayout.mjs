/**
 * Tests for printManager.js - buildPrintLayout
 * Covers: buildPrintLayout named export
 * Requires jsdom (installed via tests/package.json).
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';

const MODULE_PATH = new URL('../printManager.js', import.meta.url).href;

async function loadModule() {
  try {
    return await import(MODULE_PATH);
  } catch {
    return null;
  }
}

/**
 * Set up a fresh jsdom environment, patch canvas getContext, and return
 * { document, container, sourceCanvas }.
 */
async function setupDom() {
  const { JSDOM } = await import('jsdom');
  const dom = new JSDOM('<!DOCTYPE html><html><head></head><body></body></html>');

  // Patch HTMLCanvasElement so drawImage calls don't throw
  dom.window.HTMLCanvasElement.prototype.getContext = function (_type) {
    return { drawImage: () => {} };
  };

  // Expose a global document that buildPrintLayout will use
  global.document = dom.window.document;

  const container = dom.window.document.createElement('div');
  dom.window.document.body.appendChild(container);

  // Mock source canvas (only needs to exist; drawImage is no-op)
  const sourceCanvas = {
    getContext: () => ({ drawImage: () => {} }),
    width: 750,
    height: 1000,
  };

  return { dom, document: dom.window.document, container, sourceCanvas };
}

/**
 * Same as setupDom but captures all drawImage calls made on tile canvases.
 * Returns an additional drawImageCalls array.
 */
async function setupDomWithCapture() {
  const { JSDOM } = await import('jsdom');
  const dom = new JSDOM('<!DOCTYPE html><html><head></head><body></body></html>');

  const drawImageCalls = [];
  dom.window.HTMLCanvasElement.prototype.getContext = function (_type) {
    return { drawImage: (...args) => drawImageCalls.push(args) };
  };

  global.document = dom.window.document;

  const container = dom.window.document.createElement('div');
  dom.window.document.body.appendChild(container);

  const sourceCanvas = {
    getContext: () => ({ drawImage: () => {} }),
    width: 750,
    height: 1000,
  };

  return { dom, document: dom.window.document, container, sourceCanvas, drawImageCalls };
}

/** A single-tile region for portrait orientation (7.5 × 10 in). */
const ONE_TILE = [
  { col: 0, row: 0, sx: 0, sy: 0, sw: 750, sh: 1000, widthInches: 7.5, heightInches: 10.0 },
];

/** Two-tile region with distinct widthInches so we can verify ordering. */
const TWO_TILES = [
  { col: 0, row: 0, sx: 0,   sy: 0, sw: 750, sh: 1000, widthInches: 7.5, heightInches: 10.0 },
  { col: 1, row: 0, sx: 750, sy: 0, sw: 250, sh: 1000, widthInches: 2.5, heightInches: 10.0 },
];

// --- Container population -----------------------------------------------------

test('buildPrintLayout: clears container before adding tiles', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { document, container, sourceCanvas } = await setupDom();

  // Pre-populate with a sentinel child
  const sentinel = document.createElement('span');
  container.appendChild(sentinel);
  assert.equal(container.childNodes.length, 1);

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'portrait', container);

  // Sentinel must be gone
  assert.ok(!container.contains(sentinel), 'Container was not cleared before populating');
});

test('buildPrintLayout: creates one .print-tile element per tile region', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, TWO_TILES, false, 'portrait', container);

  const tiles = container.querySelectorAll('.print-tile');
  assert.equal(tiles.length, 2);
});

test('buildPrintLayout: each .print-tile contains exactly one canvas child', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'portrait', container);

  const tile = container.querySelector('.print-tile');
  assert.ok(tile, '.print-tile not found');
  const canvases = tile.querySelectorAll('canvas');
  assert.equal(canvases.length, 1, 'Expected exactly one canvas inside .print-tile');
});

test('buildPrintLayout: child canvas has correct pixel dimensions from tile region', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'portrait', container);

  const canvas = container.querySelector('.print-tile canvas');
  assert.ok(canvas);
  assert.equal(Number(canvas.getAttribute('width')),  ONE_TILE[0].sw);
  assert.equal(Number(canvas.getAttribute('height')), ONE_TILE[0].sh);
});

test('buildPrintLayout: .print-tile has correct inline width and height in inches', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'portrait', container);

  const tile = container.querySelector('.print-tile');
  assert.ok(tile, '.print-tile not found');

  // Parse the numeric part and check the unit - avoids fragility around "10" vs "10.0"
  const widthVal  = parseFloat(tile.style.width);
  const heightVal = parseFloat(tile.style.height);
  assert.ok(
    Math.abs(widthVal - ONE_TILE[0].widthInches) < 0.001,
    `Expected inline width ≈ ${ONE_TILE[0].widthInches}in, got "${tile.style.width}"`
  );
  assert.ok(
    tile.style.width.endsWith('in'),
    `Expected inline width unit to be "in", got "${tile.style.width}"`
  );
  assert.ok(
    Math.abs(heightVal - ONE_TILE[0].heightInches) < 0.001,
    `Expected inline height ≈ ${ONE_TILE[0].heightInches}in, got "${tile.style.height}"`
  );
  assert.ok(
    tile.style.height.endsWith('in'),
    `Expected inline height unit to be "in", got "${tile.style.height}"`
  );
  assert.equal(tile.style.pageBreakAfter, 'always',
    `Expected page-break-after "always", got "${tile.style.pageBreakAfter}"`);
  assert.equal(tile.style.position, 'relative',
    `Expected position "relative", got "${tile.style.position}"`);
  assert.equal(tile.style.overflow, 'hidden',
    `Expected overflow "hidden", got "${tile.style.overflow}"`);
});

test('buildPrintLayout: child canvas has correct inline width, height, and display:block', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'portrait', container);

  const canvas = container.querySelector('.print-tile canvas');
  assert.ok(canvas, 'canvas not found');

  const widthVal  = parseFloat(canvas.style.width);
  const heightVal = parseFloat(canvas.style.height);
  assert.ok(
    Math.abs(widthVal - ONE_TILE[0].widthInches) < 0.001,
    `Expected canvas inline width ≈ ${ONE_TILE[0].widthInches}in, got "${canvas.style.width}"`
  );
  assert.ok(
    canvas.style.width.endsWith('in'),
    `Expected canvas inline width unit to be "in", got "${canvas.style.width}"`
  );
  assert.ok(
    Math.abs(heightVal - ONE_TILE[0].heightInches) < 0.001,
    `Expected canvas inline height ≈ ${ONE_TILE[0].heightInches}in, got "${canvas.style.height}"`
  );
  assert.ok(
    canvas.style.height.endsWith('in'),
    `Expected canvas inline height unit to be "in", got "${canvas.style.height}"`
  );
  assert.equal(
    canvas.style.display, 'block',
    `Expected canvas inline display to be "block", got "${canvas.style.display}"`
  );
});

test('buildPrintLayout: tiles are appended in the same order as the input array', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, TWO_TILES, false, 'portrait', container);

  const tiles = container.querySelectorAll('.print-tile');
  assert.equal(tiles.length, 2);

  // Use parseFloat to avoid fragility around trailing zeros
  const tile0Width = parseFloat(tiles[0].style.width);
  const tile1Width = parseFloat(tiles[1].style.width);
  assert.ok(
    Math.abs(tile0Width - TWO_TILES[0].widthInches) < 0.001,
    `First tile width should be ${TWO_TILES[0].widthInches}in, got "${tiles[0].style.width}"`
  );
  assert.ok(
    Math.abs(tile1Width - TWO_TILES[1].widthInches) < 0.001,
    `Second tile width should be ${TWO_TILES[1].widthInches}in, got "${tiles[1].style.width}"`
  );
});

test('buildPrintLayout: drawImage is called with correct source region arguments per tile', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas, drawImageCalls } = await setupDomWithCapture();

  mod.buildPrintLayout(sourceCanvas, TWO_TILES, false, 'portrait', container);

  assert.equal(drawImageCalls.length, 2, 'Expected one drawImage call per tile');

  // Tile 0: drawImage(sourceCanvas, sx, sy, sw, sh, 0, 0, sw, sh)
  const [src0, sx0, sy0, sw0, sh0, dx0, dy0, dw0, dh0] = drawImageCalls[0];
  assert.equal(src0, sourceCanvas, 'drawImage first arg should be sourceCanvas');
  assert.equal(sx0, TWO_TILES[0].sx);
  assert.equal(sy0, TWO_TILES[0].sy);
  assert.equal(sw0, TWO_TILES[0].sw);
  assert.equal(sh0, TWO_TILES[0].sh);
  assert.equal(dx0, 0);
  assert.equal(dy0, 0);
  assert.equal(dw0, TWO_TILES[0].sw);
  assert.equal(dh0, TWO_TILES[0].sh);

  // Tile 1: drawImage(sourceCanvas, sx, sy, sw, sh, 0, 0, sw, sh)
  const [src1, sx1, sy1, sw1, sh1, dx1, dy1, dw1, dh1] = drawImageCalls[1];
  assert.equal(src1, sourceCanvas, 'drawImage first arg should be sourceCanvas');
  assert.equal(sx1, TWO_TILES[1].sx);
  assert.equal(sy1, TWO_TILES[1].sy);
  assert.equal(sw1, TWO_TILES[1].sw);
  assert.equal(sh1, TWO_TILES[1].sh);
  assert.equal(dx1, 0);
  assert.equal(dy1, 0);
  assert.equal(dw1, TWO_TILES[1].sw);
  assert.equal(dh1, TWO_TILES[1].sh);
});

// --- @page style injection ----------------------------------------------------

test('buildPrintLayout: injects a <style id="print-page-style"> into document.head', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { document, container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'portrait', container);

  const style = document.head.querySelector('#print-page-style');
  assert.ok(style, '<style id="print-page-style"> not found in document.head');
  assert.strictEqual(style.parentNode, document.head,
    'Style element should be a direct child of document.head');
  assert.equal(style.tagName.toLowerCase(), 'style');
});

test('buildPrintLayout: portrait @page style content is correct', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { document, container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'portrait', container);

  const style = document.getElementById('print-page-style');
  assert.ok(style);
  // Exact equality - no .trim() - the spec says textContent "equals" this string
  assert.equal(style.textContent, '@page { size: letter portrait; margin: 0.5in; }');
});

test('buildPrintLayout: landscape @page style content is correct', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { document, container, sourceCanvas } = await setupDom();

  const landscapeTile = [
    { col: 0, row: 0, sx: 0, sy: 0, sw: 1000, sh: 750, widthInches: 10.0, heightInches: 7.5 },
  ];
  mod.buildPrintLayout(sourceCanvas, landscapeTile, false, 'landscape', container);

  const style = document.getElementById('print-page-style');
  assert.ok(style);
  // Exact equality - no .trim()
  assert.equal(style.textContent, '@page { size: letter landscape; margin: 0.5in; }');
});

test('buildPrintLayout: replaces pre-existing print-page-style on repeated calls', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { document, container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'portrait', container);
  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'landscape', container);

  const styles = document.querySelectorAll('#print-page-style');
  assert.equal(styles.length, 1, 'Expected exactly one #print-page-style after second call');
  assert.ok(styles[0].textContent.includes('landscape'));
});

// --- Registration marks -------------------------------------------------------

test('buildPrintLayout: no .registration-mark elements when includeRegistrationMarks is false', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'portrait', container);

  const marks = container.querySelectorAll('.registration-mark');
  assert.equal(marks.length, 0);
});

test('buildPrintLayout: exactly 4 .registration-mark elements per tile when includeRegistrationMarks is true', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, true, 'portrait', container);

  const marks = container.querySelectorAll('.print-tile .registration-mark');
  assert.equal(marks.length, 4);
});

test('buildPrintLayout: each .registration-mark has exactly 2 direct child div elements', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, ONE_TILE, true, 'portrait', container);

  const marks = container.querySelectorAll('.registration-mark');
  for (const mark of marks) {
    // Use direct children only (not all descendants via querySelectorAll)
    const directDivChildren = Array.from(mark.children).filter(
      el => el.tagName === 'DIV'
    );
    assert.equal(directDivChildren.length, 2,
      `Expected 2 direct div children in .registration-mark, got ${directDivChildren.length}`);
  }
});

test('buildPrintLayout: 4 registration marks per tile × multiple tiles', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  mod.buildPrintLayout(sourceCanvas, TWO_TILES, true, 'portrait', container);

  const marks = container.querySelectorAll('.registration-mark');
  assert.equal(marks.length, 8, 'Expected 4 marks × 2 tiles = 8 total');
});

// --- Error cases --------------------------------------------------------------

test('buildPrintLayout: throws RangeError for invalid orientation', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  assert.throws(
    () => mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'diagonal', container),
    (err) => err instanceof RangeError
  );
});

test('buildPrintLayout: RangeError message is exactly "Invalid orientation"', async () => {
  const mod = await loadModule();
  if (!mod) assert.fail('printManager.js has not been implemented');
  const { container, sourceCanvas } = await setupDom();

  try {
    mod.buildPrintLayout(sourceCanvas, ONE_TILE, false, 'bad', container);
    assert.fail('Expected RangeError');
  } catch (err) {
    assert.ok(err instanceof RangeError);
    assert.equal(err.message, 'Invalid orientation');
  }
});
