
import os
import sys
import subprocess
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class TestCLIEntryPoint:
    """Tests for the command-line interface."""

    def test_pipeline_runs_end_to_end(self, sample_data_dir, output_dir):
        result = subprocess.run(
            [
                sys.executable, "pipeline.py",
                "--quarter", "Q1-2018",
                "--output-dir", output_dir,
                "--data-dir", sample_data_dir,
            ],
            capture_output=True,
            text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
            timeout=120,
        )
        assert result.returncode == 0, f"Pipeline failed: {result.stderr}"
        # Prompt: "prints a summary line to stdout confirming report paths"
        assert result.stdout.strip(), "Pipeline must print a summary to stdout"
        assert "director" in result.stdout.lower(), \
            "stdout must reference the director report path"
        assert "inspector" in result.stdout.lower(), \
            "stdout must reference the inspector report path"
        # Prompt mandates exact output filenames
        assert os.path.isfile(os.path.join(output_dir, "director_report_Q1-2018.html")), \
            "Pipeline must produce director_report_Q1-2018.html"
        assert os.path.isfile(os.path.join(output_dir, "inspector_report.html")), \
            "Pipeline must produce inspector_report.html"

    def test_different_quarter_works(self, sample_data_dir, output_dir):
        result = subprocess.run(
            [
                sys.executable, "pipeline.py",
                "--quarter", "Q3-2019",
                "--output-dir", output_dir,
                "--data-dir", sample_data_dir,
            ],
            capture_output=True,
            text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
            timeout=120,
        )
        assert result.returncode == 0, f"Pipeline failed with Q3-2019: {result.stderr}"

    @pytest.mark.parametrize("bad_quarter", [
        "Q0-2024",   # Q0 is outside Q<1-4> range
        "Q5-2024",   # Q5 is outside Q<1-4> range
        "Q1-24",     # year is not 4-digit YYYY
        "2024-Q1",   # wrong order
        "Q1-ABCD",   # non-numeric year
    ])
    def test_invalid_quarter_formats_exit_with_error(self, bad_quarter, sample_data_dir, output_dir):
        """CLI must reject all inputs not matching Q<1-4>-YYYY.
        Prompt: '--quarter (required, e.g., Q1-2024, format Q<1-4>-YYYY)'
        Guard ensures the test FAILs (not trivially PASSes) on an empty repo."""
        pipeline_path = os.path.join(os.path.dirname(__file__), "..", "pipeline.py")
        if not os.path.isfile(pipeline_path):
            pytest.fail("pipeline.py not found — cannot validate quarter format rejection")

        result = subprocess.run(
            [sys.executable, "pipeline.py",
             "--quarter", bad_quarter,
             "--output-dir", output_dir,
             "--data-dir", sample_data_dir],
            capture_output=True, text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
            timeout=30,
        )
        assert result.returncode != 0, (
            f"CLI must exit with non-zero return code for invalid quarter '{bad_quarter}'"
        )

    def test_missing_quarter_argument_exits_with_error(self, output_dir):
        """--quarter is a required argument; omitting it must produce a non-zero exit code.
        Prompt Expected Interface: '--quarter (required, e.g., Q1-2024)'"""
        pipeline_path = os.path.join(os.path.dirname(__file__), "..", "pipeline.py")
        if not os.path.isfile(pipeline_path):
            pytest.fail("pipeline.py not found — cannot validate required argument behaviour")

        result = subprocess.run(
            [sys.executable, "pipeline.py", "--output-dir", output_dir],
            capture_output=True, text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
            timeout=30,
        )
        assert result.returncode != 0,             "CLI must exit with non-zero return code when --quarter is omitted"

    def test_missing_output_dir_argument_exits_with_error(self, sample_data_dir):
        """--output-dir is a required argument; omitting it must produce a non-zero exit code.
        Prompt Expected Interface: '--output-dir (required, directory path for HTML reports)'"""
        pipeline_path = os.path.join(os.path.dirname(__file__), "..", "pipeline.py")
        if not os.path.isfile(pipeline_path):
            pytest.fail("pipeline.py not found — cannot validate required argument behaviour")

        result = subprocess.run(
            [sys.executable, "pipeline.py", "--quarter", "Q1-2018", "--data-dir", sample_data_dir],
            capture_output=True, text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
            timeout=30,
        )
        assert result.returncode != 0,             "CLI must exit with non-zero return code when --output-dir is omitted"

    def test_default_data_dir(self, output_dir):
        if not os.path.isdir(os.path.join(os.path.dirname(__file__), "..", "data")):
            pytest.fail("No default data/ directory present")
        result = subprocess.run(
            [
                sys.executable, "pipeline.py",
                "--quarter", "Q1-2018",
                "--output-dir", output_dir,
            ],
            capture_output=True,
            text=True,
            cwd=os.path.join(os.path.dirname(__file__), ".."),
            timeout=120,
        )
        assert result.returncode == 0, f"Pipeline failed with default data dir: {result.stderr}"
