
import os
import sys
import pytest
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _load(sample_data_dir):
    from pipeline import load_and_validate
    return load_and_validate(sample_data_dir)


class TestLoadAndValidateReturnStructure:
    """Tests that load_and_validate returns the correct dictionary structure."""

    def test_contains_all_eight_dataset_keys(self, sample_data_dir):
        result = _load(sample_data_dir)
        expected_keys = {
            "permits", "inspections", "permittees", "street_segments",
            "settlement_failures", "fee_assessments", "bond_claims",
            "coordination_notices",
        }
        for key in expected_keys:
            assert key in result, f"Missing dataset key: {key}"

    def test_contains_validation_summary_key(self, sample_data_dir):
        result = _load(sample_data_dir)
        assert "validation_summary" in result

    def test_dataset_values_are_dataframes(self, sample_data_dir):
        result = _load(sample_data_dir)
        dataset_keys = [
            "permits", "inspections", "permittees", "street_segments",
            "settlement_failures", "fee_assessments", "bond_claims",
            "coordination_notices",
        ]
        for key in dataset_keys:
            assert isinstance(result[key], pd.DataFrame), f"{key} should be a DataFrame"

    def test_validation_summary_is_dict(self, sample_data_dir):
        result = _load(sample_data_dir)
        assert isinstance(result["validation_summary"], dict)


class TestLoadAndValidateDateParsing:
    """Tests that date columns are parsed to datetime types."""

    def test_validation_summary_values_are_int(self, sample_data_dir):
        """validation_summary must be dict[str, int] — all values must be int type.
        Prompt Expected Interface: 'validation_summary maps to a dict[str, int] of
        dataset name to dropped-row count.'"""
        result = _load(sample_data_dir)
        summary = result["validation_summary"]
        non_int = {k: type(v).__name__ for k, v in summary.items() if not isinstance(v, int)}
        assert not non_int, (
            f"validation_summary values must all be int; found non-int types: {non_int}"
        )


    def test_permits_issue_date_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["permits"]
        assert pd.api.types.is_datetime64_any_dtype(df["issue_date"])

    def test_permits_warranty_start_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["permits"]
        assert pd.api.types.is_datetime64_any_dtype(df["warranty_start"])

    def test_permits_warranty_end_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["permits"]
        assert pd.api.types.is_datetime64_any_dtype(df["warranty_end"])

    def test_inspections_date_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["inspections"]
        assert pd.api.types.is_datetime64_any_dtype(df["inspection_date"])

    def test_segments_pavement_install_date_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["street_segments"]
        assert pd.api.types.is_datetime64_any_dtype(df["pavement_install_date"])

    def test_failures_date_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["settlement_failures"]
        assert pd.api.types.is_datetime64_any_dtype(df["failure_date"])

    def test_fee_date_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["fee_assessments"]
        assert pd.api.types.is_datetime64_any_dtype(df["date"])

    def test_bond_claims_date_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["bond_claims"]
        assert pd.api.types.is_datetime64_any_dtype(df["claim_date"])

    def test_coordination_notice_date_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["coordination_notices"]
        assert pd.api.types.is_datetime64_any_dtype(df["notice_date"])

    def test_coordination_project_start_date_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["coordination_notices"]
        assert pd.api.types.is_datetime64_any_dtype(df["project_start_date"])

    def test_segments_overlay_date_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["street_segments"]
        assert pd.api.types.is_datetime64_any_dtype(df["overlay_date"]), \
            "Column overlay_date must be parsed to datetime64 (even when all-null, dtype must be datetime)"

    def test_segments_moratorium_start_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["street_segments"]
        assert pd.api.types.is_datetime64_any_dtype(df["moratorium_start"]), \
            "Column moratorium_start must be parsed to datetime64 (even when all-null, dtype must be datetime)"

    def test_segments_moratorium_end_is_datetime(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["street_segments"]
        assert pd.api.types.is_datetime64_any_dtype(df["moratorium_end"]), \
            "Column moratorium_end must be parsed to datetime64 (even when all-null, dtype must be datetime)"


class TestLoadAndValidateBooleanCoercion:
    """Tests that boolean columns are properly coerced."""

    def test_traffic_control_plan_adequate_is_bool(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["permits"]
        assert df["traffic_control_plan_adequate"].dtype == bool or \
               pd.api.types.is_bool_dtype(df["traffic_control_plan_adequate"])

    def test_backfill_accepted_is_bool(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["inspections"]
        assert df["backfill_accepted"].dtype == bool or \
               pd.api.types.is_bool_dtype(df["backfill_accepted"])

    def test_base_course_accepted_is_bool(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["inspections"]
        assert df["base_course_accepted"].dtype == bool or \
               pd.api.types.is_bool_dtype(df["base_course_accepted"])

    def test_surface_restoration_accepted_is_bool(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["inspections"]
        assert df["surface_restoration_accepted"].dtype == bool or \
               pd.api.types.is_bool_dtype(df["surface_restoration_accepted"])

    def test_bond_resolved_is_bool(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        df = loaded_datasets["bond_claims"]
        assert df["resolved"].dtype == bool or \
               pd.api.types.is_bool_dtype(df["resolved"])


class TestLoadAndValidateNullPKRejection:
    """Tests that rows with null primary keys are dropped."""

    @pytest.mark.parametrize("csv_file,pk_col,dataset_key", [
        ("permits.csv",              "permit_id",     "permits"),
        ("inspections.csv",          "inspection_id", "inspections"),
        ("permittees.csv",           "permittee_id",  "permittees"),
        ("street_segments.csv",      "segment_id",    "street_segments"),
        ("settlement_failures.csv",  "failure_id",    "settlement_failures"),
        ("fee_assessments.csv",      "assessment_id", "fee_assessments"),
        ("bond_claims.csv",          "claim_id",      "bond_claims"),
        ("coordination_notices.csv", "notice_id",     "coordination_notices"),
    ])
    def test_null_pk_rows_are_dropped(self, sample_data_dir, csv_file, pk_col, dataset_key):
        csv_path = os.path.join(sample_data_dir, csv_file)
        df = pd.read_csv(csv_path)
        original_count = len(df)
        bad_row = df.iloc[0:1].copy()
        bad_row[pk_col] = None
        df = pd.concat([df, bad_row], ignore_index=True)
        df.to_csv(csv_path, index=False)

        result = _load(sample_data_dir)
        assert result[dataset_key][pk_col].notna().all(),             f"{dataset_key}: all {pk_col} values must be non-null after loading"
        assert len(result[dataset_key]) == original_count, \
            f"{dataset_key}: exactly the 1 null-PK row must be dropped, valid rows preserved"

    def test_validation_summary_tracks_dropped_rows(self, sample_data_dir):
        permits_path = os.path.join(sample_data_dir, "permits.csv")
        permits_df = pd.read_csv(permits_path)
        bad_row = permits_df.iloc[0:1].copy()
        bad_row["permit_id"] = None
        permits_df = pd.concat([permits_df, bad_row], ignore_index=True)
        permits_df.to_csv(permits_path, index=False)

        result = _load(sample_data_dir)
        summary = result["validation_summary"]
        # Dropped permit row must be tracked
        assert "permits" in summary
        assert summary["permits"] >= 1
        # All 8 datasets must have a key in the summary (prompt: "log dropped rows for all")
        all_keys = [
            "permits", "inspections", "permittees", "street_segments",
            "settlement_failures", "fee_assessments", "bond_claims", "coordination_notices",
        ]
        for key in all_keys:
            assert key in summary,                 f"validation_summary must contain key for every dataset, missing: '{key}'"


class TestLoadAndValidateDataIntegrity:
    """Tests that valid data is loaded correctly without loss."""

    def test_permits_no_rows_lost(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        expected = len(pd.read_csv(os.path.join(sample_data_dir, "permits.csv")))
        assert len(loaded_datasets["permits"]) == expected, \
            f"All {expected} valid permits must be preserved"

    def test_permittees_no_rows_lost(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        expected = len(pd.read_csv(os.path.join(sample_data_dir, "permittees.csv")))
        assert len(loaded_datasets["permittees"]) == expected, \
            f"All {expected} valid permittees must be preserved"

    def test_segments_no_rows_lost(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        expected = len(pd.read_csv(os.path.join(sample_data_dir, "street_segments.csv")))
        assert len(loaded_datasets["street_segments"]) == expected, \
            f"All {expected} valid street segments must be preserved"

    @pytest.mark.parametrize("csv_file,dataset_key", [
        ("inspections.csv",          "inspections"),
        ("settlement_failures.csv",  "settlement_failures"),
        ("fee_assessments.csv",      "fee_assessments"),
        ("bond_claims.csv",          "bond_claims"),
        ("coordination_notices.csv", "coordination_notices"),
    ])
    def test_no_valid_rows_lost(self, sample_data_dir, csv_file, dataset_key):
        """All valid rows in every dataset must be preserved after loading."""
        import pandas as _pd
        expected = len(_pd.read_csv(os.path.join(sample_data_dir, csv_file)))
        loaded_datasets = _load(sample_data_dir)
        assert len(loaded_datasets[dataset_key]) == expected, (
            f"All {expected} valid {dataset_key} rows must be preserved, "
            f"got {len(loaded_datasets[dataset_key])}"
        )

    @pytest.mark.parametrize("dataset_key,required_cols", [
        ("permittees",           {"permittee_id", "name", "type"}),
        ("street_segments",      {"segment_id", "corridor_name", "pavement_install_date",
                                  "overlay_date", "moratorium_start", "moratorium_end"}),
        ("settlement_failures",  {"failure_id", "permit_id", "failure_date", "severity"}),
        ("fee_assessments",      {"assessment_id", "permittee_id", "permit_id", "amount", "date"}),
        ("bond_claims",          {"claim_id", "permittee_id", "permit_id",
                                  "claim_amount", "claim_date", "resolved"}),
        ("coordination_notices", {"notice_id", "permittee_id", "permit_id",
                                  "notice_date", "project_start_date"}),
    ])
    def test_dataset_has_expected_columns(self, sample_data_dir, dataset_key, required_cols):
        """Each dataset must contain all columns specified in the prompt schema."""
        loaded_datasets = _load(sample_data_dir)
        actual_cols = set(loaded_datasets[dataset_key].columns)
        missing = required_cols - actual_cols
        assert not missing, f"{dataset_key} is missing required columns: {missing}"

    def test_permits_has_expected_columns(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        expected = {"permit_id", "permittee_id", "street_segment_id", "issue_date",
                    "excavation_purpose", "restoration_scope",
                    "traffic_control_plan_adequate", "warranty_start", "warranty_end"}
        assert expected.issubset(set(loaded_datasets["permits"].columns))

    def test_inspections_has_expected_columns(self, sample_data_dir):
        loaded_datasets = _load(sample_data_dir)
        expected = {"inspection_id", "permit_id", "inspection_date",
                    "backfill_accepted", "base_course_accepted",
                    "surface_restoration_accepted"}
        assert expected.issubset(set(loaded_datasets["inspections"].columns))
