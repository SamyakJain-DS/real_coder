import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import path from 'node:path'

// Vite/Vitest config used by run.sh to execute the test suite.
// Tests live under /eval_assets/tests and import the agent's source
// code from /app/src/ using absolute paths.
export default defineConfig({
  plugins: [react()],
  root: path.resolve(__dirname),
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: [path.resolve(__dirname, 'setup.ts')],
    include: [path.resolve(__dirname, '**/*.test.{ts,tsx}')],
    deps: {
      // Allow vitest to transform .tsx/.ts files from /app/src
      inline: [/\/app\/src\//],
    },
    server: {
      deps: {
        inline: [/\/app\/src\//],
      },
    },
  },
  resolve: {
    alias: {
      '@app': path.resolve('/app/src'),
    },
  },
  // Make sure /app is part of the file watcher so file resolution works.
  // /usr/lib/node_modules is the real path behind the /node_modules symlink
  // created in the Dockerfile; Vite resolves symlinks before checking this list.
  server: {
    fs: {
      allow: ['/app', '/eval_assets', '/usr/lib/node_modules'],
    },
  },
})
