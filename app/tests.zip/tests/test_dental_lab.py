import os
import sys
import tempfile
from datetime import date

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from lab import DentalLab
except Exception:

    class DentalLab:  # type: ignore[no-redef]
        """Fallback that produces clean FAIL (not ERROR) when lab.py is absent."""

        def __init__(self, db_path: str) -> None:
            pass

        # Called during fixture setup — return None so fixtures complete without ERROR.
        def add_dentist(self, name, practice, phone):  # type: ignore[return]
            return None

        def add_patient(self, first_name, last_name, dob):  # type: ignore[return]
            return None

        def add_technician(self, name):  # type: ignore[return]
            return None

        # All other methods are invoked from test bodies → FAILED via pytest.fail().
        def __getattr__(self, name):
            def _missing(*args, **kwargs):
                pytest.fail(
                    "Cannot import DentalLab from lab.py — "
                    "ensure lab.py exists and defines the DentalLab class."
                )
            return _missing


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def lab():
    """Bare DentalLab instance backed by a fresh temp database."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    instance = DentalLab(db_path)
    yield instance
    try:
        os.unlink(db_path)
    except OSError:
        pass


@pytest.fixture
def base(lab):
    """Pre-populated lab with one dentist, one patient, and one technician."""
    dentist_id = lab.add_dentist("Dr. Adams", "Adams Dental", "555-0001")
    patient_id = lab.add_patient("Maria", "Lopez", "1985-07-20")
    tech_id = lab.add_technician("Sam")
    return lab, dentist_id, patient_id, tech_id


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_case(lab, dentist_id, patient_id, restoration_types=None, seat_date="2026-09-01"):
    """Create a case with one or more restoration types (defaults to a single crown)."""
    if restoration_types is None:
        restoration_types = ["crown"]
    restorations = [
        {"type": rt, "shade": "A2", "material": "zirconia"}
        for rt in restoration_types
    ]
    return lab.create_case(dentist_id, patient_id, restorations, seat_date)


def run_full_workflow(lab, case_id, tech_id, second_station="milling"):
    """Drive a case through the complete four-station workflow."""
    lab.advance_station(case_id, "design", tech_id)
    lab.complete_station(case_id, "design")
    lab.advance_station(case_id, second_station, tech_id)
    lab.complete_station(case_id, second_station)
    lab.advance_station(case_id, "finishing", tech_id)
    lab.complete_station(case_id, "finishing")
    lab.advance_station(case_id, "quality_check", tech_id)
    lab.complete_station(case_id, "quality_check")


# ---------------------------------------------------------------------------
# DentalLab initialisation
# ---------------------------------------------------------------------------

class TestDentalLabInit:
    def test_reinitialisation_preserves_existing_data(self):
        """
        Re-opening the same db_path must NOT drop existing data.
        Verified by checking that the auto-increment counter carries over:
        a second instance must assign a new (different) dentist_id rather
        than resetting back to 1.
        """
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            lab1 = DentalLab(db_path)
            id_from_first = lab1.add_dentist("Dr. Reopen", "Reopen Practice", "555-7777")
            lab2 = DentalLab(db_path)
            id_from_second = lab2.add_dentist("Dr. Second", "Second Practice", "555-8888")
            # If lab2 had dropped and recreated tables, id_from_second would equal
            # id_from_first (both would be 1).  Persistence means it is strictly greater.
            assert isinstance(id_from_first, int)
            assert isinstance(id_from_second, int)
            assert id_from_second != id_from_first
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass

    def test_second_open_can_use_entities_from_first_open(self):
        """
        Entities created via lab1 must be usable by lab2 on the same database.
        """
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            lab1 = DentalLab(db_path)
            dentist_id = lab1.add_dentist("Dr. Reopen", "Reopen Practice", "555-7777")
            patient_id = lab1.add_patient("Test", "Persist", "2000-01-01")
            lab2 = DentalLab(db_path)
            case_id = lab2.create_case(
                dentist_id, patient_id,
                [{"type": "crown", "shade": "A2", "material": "zirconia"}],
                "2026-12-01",
            )
            assert isinstance(case_id, int)
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass


# ---------------------------------------------------------------------------
# add_dentist
# ---------------------------------------------------------------------------

class TestAddDentist:
    def test_returns_integer(self, lab):
        result = lab.add_dentist("Dr. Jones", "Jones Practice", "555-1234")
        assert isinstance(result, int)

    def test_multiple_dentists_have_unique_ids(self, lab):
        id1 = lab.add_dentist("Dr. Jones", "Jones Practice", "555-1234")
        id2 = lab.add_dentist("Dr. Park", "Park Dental", "555-5678")
        assert id1 != id2


# ---------------------------------------------------------------------------
# add_patient
# ---------------------------------------------------------------------------

class TestAddPatient:
    def test_returns_integer(self, lab):
        result = lab.add_patient("Alice", "Chen", "1990-03-12")
        assert isinstance(result, int)

    def test_multiple_patients_have_unique_ids(self, lab):
        id1 = lab.add_patient("Alice", "Chen", "1990-03-12")
        id2 = lab.add_patient("Bob", "Taylor", "1978-11-25")
        assert id1 != id2


# ---------------------------------------------------------------------------
# add_technician
# ---------------------------------------------------------------------------

class TestAddTechnician:
    def test_returns_integer(self, lab):
        result = lab.add_technician("Jordan")
        assert isinstance(result, int)

    def test_multiple_technicians_have_unique_ids(self, lab):
        id1 = lab.add_technician("Jordan")
        id2 = lab.add_technician("Casey")
        assert id1 != id2


# ---------------------------------------------------------------------------
# create_case
# ---------------------------------------------------------------------------

class TestCreateCase:
    def test_returns_integer(self, base):
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id)
        assert isinstance(case_id, int)

    def test_multiple_cases_have_unique_ids(self, base):
        lab, dentist_id, patient_id, _ = base
        id1 = make_case(lab, dentist_id, patient_id)
        id2 = make_case(lab, dentist_id, patient_id)
        assert id1 != id2

    def test_accepts_all_four_restoration_types(self, base):
        """create_case must accept all four valid restoration types."""
        lab, dentist_id, patient_id, _ = base
        for rt in ["crown", "bridge", "denture", "night_guard"]:
            case_id = make_case(lab, dentist_id, patient_id, [rt])
            assert isinstance(case_id, int)

    def test_accepts_multiple_restorations_in_one_case(self, base):
        """A prescription with multiple restorations must be accepted."""
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id, ["crown", "bridge"])
        assert isinstance(case_id, int)
    
    def test_invalid_restoration_type_raises_value_error(self, base):
        lab, dentist_id, patient_id, _ = base
        with pytest.raises(ValueError):
            lab.create_case(
                dentist_id, patient_id,
                [{"type": "veneer", "shade": "A2", "material": "porcelain"}],
                "2026-09-01",
            )


# ---------------------------------------------------------------------------
# record_handoff
# ---------------------------------------------------------------------------

class TestRecordHandoff:
    def test_impression_returns_none(self, base):
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id)
        result = lab.record_handoff(case_id, "TRAY-001", "impression")
        assert result is None

    def test_intraoral_scan_returns_none(self, base):
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id)
        result = lab.record_handoff(case_id, "TRAY-002", "intraoral_scan")
        assert result is None
    
    def test_invalid_handoff_type_raises_value_error(self, base):
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id)
        with pytest.raises(ValueError):
            lab.record_handoff(case_id, "TRAY-001", "digital_scan")


# ---------------------------------------------------------------------------
# advance_station
# ---------------------------------------------------------------------------

class TestAdvanceStation:
    def test_returns_none(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        result = lab.advance_station(case_id, "design", tech_id)
        assert result is None

    def test_design_is_valid_first_station(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        status = lab.get_case_status(case_id)
        assert status["current_station"] == "design"
        assert status["technician_id"] == tech_id

    def test_opening_non_design_first_raises_value_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        with pytest.raises(ValueError):
            lab.advance_station(case_id, "finishing", tech_id)

    def test_skipping_milling_pressing_slot_raises_value_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        with pytest.raises(ValueError):
            lab.advance_station(case_id, "finishing", tech_id)

    def test_skipping_finishing_raises_value_error(self, base):
        """After design+milling, jumping to quality_check is out of sequence."""
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        with pytest.raises(ValueError):
            lab.advance_station(case_id, "quality_check", tech_id)

    def test_opening_next_station_while_current_active_raises_value_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        with pytest.raises(ValueError):
            lab.advance_station(case_id, "milling", tech_id)

    def test_reopening_completed_station_raises_value_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        with pytest.raises(ValueError):
            lab.advance_station(case_id, "design", tech_id)

    def test_cannot_assign_both_milling_and_pressing(self, base):
        """Exactly one of milling/pressing per case; assigning both must raise."""
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        with pytest.raises(ValueError):
            lab.advance_station(case_id, "pressing", tech_id)

    def test_cannot_assign_milling_after_pressing(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "pressing", tech_id)
        lab.complete_station(case_id, "pressing")
        with pytest.raises(ValueError):
            lab.advance_station(case_id, "milling", tech_id)

    def test_milling_path_completes_without_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id, second_station="milling")
        assert lab.get_case_status(case_id)["completed"] is True

    def test_pressing_path_completes_without_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id, second_station="pressing")
        assert lab.get_case_status(case_id)["completed"] is True

    def test_advance_after_full_completion_raises_value_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        with pytest.raises(ValueError):
            lab.advance_station(case_id, "design", tech_id)

    def test_technician_id_reflects_current_station(self, base):
        lab, dentist_id, patient_id, tech_id = base
        tech2_id = lab.add_technician("Riley")
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech2_id)
        status = lab.get_case_status(case_id)
        assert status["current_station"] == "milling"
        assert status["technician_id"] == tech2_id

    def test_pressing_station_shows_assigned_technician(self, base):
        lab, dentist_id, patient_id, tech_id = base
        tech2_id = lab.add_technician("Casey")
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "pressing", tech2_id)
        status = lab.get_case_status(case_id)
        assert status["current_station"] == "pressing"
        assert status["technician_id"] == tech2_id
    
    def test_invalid_station_name_raises_value_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        with pytest.raises(ValueError):
            lab.advance_station(case_id, "polishing", tech_id)


# ---------------------------------------------------------------------------
# complete_station
# ---------------------------------------------------------------------------

class TestCompleteStation:
    def test_returns_none_on_success(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        result = lab.complete_station(case_id, "design")
        assert result is None

    def test_completing_non_active_station_raises_value_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        with pytest.raises(ValueError):
            lab.complete_station(case_id, "milling")

    def test_completing_station_before_any_opened_raises_value_error(self, base):
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id)
        with pytest.raises(ValueError):
            lab.complete_station(case_id, "design")

    def test_quality_check_without_any_fee_raises_value_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        lab.advance_station(case_id, "finishing", tech_id)
        lab.complete_station(case_id, "finishing")
        lab.advance_station(case_id, "quality_check", tech_id)
        with pytest.raises(ValueError):
            lab.complete_station(case_id, "quality_check")

    def test_quality_check_with_only_partial_fees_raises_value_error(self, base):
        """A missing fee for ANY restoration on the case must block completion."""
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id, ["crown", "bridge"])
        lab.set_fee("crown", 150.0)
        # bridge fee deliberately omitted
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        lab.advance_station(case_id, "finishing", tech_id)
        lab.complete_station(case_id, "finishing")
        lab.advance_station(case_id, "quality_check", tech_id)
        with pytest.raises(ValueError):
            lab.complete_station(case_id, "quality_check")

    def test_quality_check_failure_leaves_station_incomplete(self, base):
        """When quality_check raises ValueError, the case must remain incomplete."""
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        lab.advance_station(case_id, "finishing", tech_id)
        lab.complete_station(case_id, "finishing")
        lab.advance_station(case_id, "quality_check", tech_id)
        try:
            lab.complete_station(case_id, "quality_check")
        except ValueError:
            pass
        assert lab.get_case_status(case_id)["completed"] is False

    def test_quality_check_succeeds_after_fee_set_retroactively(self, base):
        """
        The station remains open after the ValueError so the caller can set
        the missing fee and retry — the prompt says it 'leaves the station
        incomplete'.
        """
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        lab.advance_station(case_id, "finishing", tech_id)
        lab.complete_station(case_id, "finishing")
        lab.advance_station(case_id, "quality_check", tech_id)
        with pytest.raises(ValueError):
            lab.complete_station(case_id, "quality_check")
        lab.set_fee("crown", 150.0)
        lab.complete_station(case_id, "quality_check")
        assert lab.get_case_status(case_id)["completed"] is True

    def test_complete_after_full_completion_raises_value_error(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        with pytest.raises(ValueError):
            lab.complete_station(case_id, "quality_check")


# ---------------------------------------------------------------------------
# get_case_status
# ---------------------------------------------------------------------------

class TestGetCaseStatus:
    def test_returns_required_keys(self, base):
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id)
        status = lab.get_case_status(case_id)
        for key in ("current_station", "technician_id", "completed", "last_completed_station"):
            assert key in status

    def test_pristine_case(self, base):
        """No station ever opened: all three status fields are None / False."""
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id)
        status = lab.get_case_status(case_id)
        assert status["current_station"] is None
        assert status["technician_id"] is None
        assert status["completed"] is False
        assert status["last_completed_station"] is None

    def test_active_design_station(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        status = lab.get_case_status(case_id)
        assert status["current_station"] == "design"
        assert status["technician_id"] == tech_id
        assert status["completed"] is False
        assert status["last_completed_station"] is None

    def test_between_design_and_milling(self, base):
        """
        After design completes and before the next station opens:
        current_station must be None but last_completed_station must NOT be None.
        """
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        status = lab.get_case_status(case_id)
        assert status["current_station"] is None
        assert status["technician_id"] is None
        assert status["completed"] is False
        assert status["last_completed_station"] == "design"

    def test_between_milling_and_finishing(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        status = lab.get_case_status(case_id)
        assert status["current_station"] is None
        assert status["technician_id"] is None
        assert status["completed"] is False
        assert status["last_completed_station"] == "milling"

    def test_between_pressing_and_finishing(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "pressing", tech_id)
        lab.complete_station(case_id, "pressing")
        status = lab.get_case_status(case_id)
        assert status["current_station"] is None
        assert status["technician_id"] is None
        assert status["completed"] is False
        assert status["last_completed_station"] == "pressing"

    def test_between_finishing_and_quality_check(self, base):
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        lab.advance_station(case_id, "finishing", tech_id)
        lab.complete_station(case_id, "finishing")
        status = lab.get_case_status(case_id)
        assert status["current_station"] is None
        assert status["technician_id"] is None
        assert status["completed"] is False
        assert status["last_completed_station"] == "finishing"

    def test_fully_completed_case(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        status = lab.get_case_status(case_id)
        assert status["current_station"] is None
        assert status["technician_id"] is None
        assert status["completed"] is True
        assert status["last_completed_station"] == "quality_check"


# ---------------------------------------------------------------------------
# set_fee
# ---------------------------------------------------------------------------

class TestSetFee:
    def test_returns_none(self, lab):
        result = lab.set_fee("crown", 150.0)
        assert result is None

    def test_replaces_existing_fee(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 100.0)
        lab.set_fee("crown", 250.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        entry = next(c for c in stmt["cases"] if c["case_id"] == case_id)
        assert entry["amount"] == pytest.approx(250.0)

    def test_all_four_restoration_types_accepted_by_fee_schedule(self, base):
        """set_fee must work for all four restoration types without raising."""
        lab, dentist_id, patient_id, tech_id = base
        for rt, fee in [("crown", 100.0), ("bridge", 200.0), ("denture", 300.0), ("night_guard", 50.0)]:
            lab.set_fee(rt, fee)
        case_id = make_case(lab, dentist_id, patient_id, ["crown", "bridge", "denture", "night_guard"])
        run_full_workflow(lab, case_id, tech_id)
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        entry = next(c for c in stmt["cases"] if c["case_id"] == case_id)
        assert entry["amount"] == pytest.approx(650.0)
    
    def test_invalid_restoration_type_raises_value_error(self, lab):
        with pytest.raises(ValueError):
            lab.set_fee("implant", 500.0)


# ---------------------------------------------------------------------------
# get_case_turnaround
# ---------------------------------------------------------------------------

class TestGetCaseTurnaround:
    def test_returns_required_keys(self, base):
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id, seat_date="2026-10-01")
        result = lab.get_case_turnaround(case_id)
        for key in ("case_id", "seat_date", "completion_date", "elapsed_days"):
            assert key in result

    def test_case_id_echoed(self, base):
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id, seat_date="2026-10-01")
        assert lab.get_case_turnaround(case_id)["case_id"] == case_id

    def test_seat_date_stored_correctly(self, base):
        lab, dentist_id, patient_id, _ = base
        seat_date = "2026-10-15"
        case_id = make_case(lab, dentist_id, patient_id, seat_date=seat_date)
        assert lab.get_case_turnaround(case_id)["seat_date"] == seat_date

    def test_incomplete_case_has_null_completion_and_elapsed(self, base):
        lab, dentist_id, patient_id, _ = base
        case_id = make_case(lab, dentist_id, patient_id)
        result = lab.get_case_turnaround(case_id)
        assert result["completion_date"] is None
        assert result["elapsed_days"] is None

    def test_completion_date_is_today_after_quality_check(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        assert lab.get_case_turnaround(case_id)["completion_date"] == date.today().isoformat()

    def test_elapsed_days_is_integer_and_zero_when_same_day(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        elapsed = lab.get_case_turnaround(case_id)["elapsed_days"]
        assert isinstance(elapsed, int)
        assert elapsed == 0

    def test_completion_date_set_only_after_quality_check(self, base):
        """Completing finishing (not quality_check) must not set the completion date."""
        lab, dentist_id, patient_id, tech_id = base
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        lab.advance_station(case_id, "finishing", tech_id)
        lab.complete_station(case_id, "finishing")
        result = lab.get_case_turnaround(case_id)
        assert result["completion_date"] is None
        assert result["elapsed_days"] is None

    def test_pressing_path_completion_date_recorded(self, base):
        """Completion via pressing workflow must also record completion date."""
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id, second_station="pressing")
        result = lab.get_case_turnaround(case_id)
        assert result["completion_date"] == date.today().isoformat()
        assert result["elapsed_days"] == 0


# ---------------------------------------------------------------------------
# generate_statement
# ---------------------------------------------------------------------------

class TestGenerateStatement:
    def test_returns_required_keys(self, base):
        lab, dentist_id, _, _ = base
        stmt = lab.generate_statement(dentist_id, 2026, 1)
        for key in ("dentist_id", "year", "month", "cases", "total"):
            assert key in stmt

    def test_echoes_dentist_id_year_month(self, base):
        lab, dentist_id, _, _ = base
        stmt = lab.generate_statement(dentist_id, 2026, 3)
        assert stmt["dentist_id"] == dentist_id
        assert stmt["year"] == 2026
        assert stmt["month"] == 3

    def test_empty_month_returns_empty_cases_and_zero_total(self, base):
        lab, dentist_id, _, _ = base
        stmt = lab.generate_statement(dentist_id, 2020, 1)
        assert stmt["cases"] == []
        assert stmt["total"] == pytest.approx(0.0)

    def test_completed_case_appears_in_correct_month(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        assert any(c["case_id"] == case_id for c in stmt["cases"])

    def test_case_entry_has_required_keys(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        entry = next(c for c in stmt["cases"] if c["case_id"] == case_id)
        assert "case_id" in entry
        assert "amount" in entry

    def test_case_amount_equals_snapshotted_fee(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 175.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        entry = next(c for c in stmt["cases"] if c["case_id"] == case_id)
        assert entry["amount"] == pytest.approx(175.0)

    def test_multi_restoration_case_amount_sums_all_fees(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        lab.set_fee("bridge", 300.0)
        case_id = make_case(lab, dentist_id, patient_id, ["crown", "bridge"])
        run_full_workflow(lab, case_id, tech_id)
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        entry = next(c for c in stmt["cases"] if c["case_id"] == case_id)
        assert entry["amount"] == pytest.approx(450.0)

    def test_total_equals_sum_of_case_amounts(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case1 = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case1, tech_id)
        case2 = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case2, tech_id)
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        expected = sum(c["amount"] for c in stmt["cases"])
        assert stmt["total"] == pytest.approx(expected)

    def test_live_fee_change_after_completion_does_not_alter_amount(self, base):
        """Billed amount uses the snapshotted fee, not the live schedule."""
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        lab.set_fee("crown", 999.0)
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        entry = next(c for c in stmt["cases"] if c["case_id"] == case_id)
        assert entry["amount"] == pytest.approx(150.0)

    def test_fee_at_quality_check_time_is_snapshotted(self, base):
        """
        Fee changed between case creation and quality_check completion:
        the snapshotted amount must be the fee active at quality_check time.
        """
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 100.0)
        case_id = make_case(lab, dentist_id, patient_id)
        lab.advance_station(case_id, "design", tech_id)
        lab.complete_station(case_id, "design")
        lab.advance_station(case_id, "milling", tech_id)
        lab.complete_station(case_id, "milling")
        lab.advance_station(case_id, "finishing", tech_id)
        lab.complete_station(case_id, "finishing")
        lab.advance_station(case_id, "quality_check", tech_id)
        lab.set_fee("crown", 200.0)  # updated just before quality_check completes
        lab.complete_station(case_id, "quality_check")
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        entry = next(c for c in stmt["cases"] if c["case_id"] == case_id)
        assert entry["amount"] == pytest.approx(200.0)

    def test_cases_from_different_month_excluded(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        today = date.today()
        other_month = (today.month % 12) + 1
        other_year = today.year if other_month != 1 else today.year + 1
        stmt = lab.generate_statement(dentist_id, other_year, other_month)
        assert not any(c["case_id"] == case_id for c in stmt["cases"])

    def test_cases_for_other_dentist_excluded(self, base):
        lab, dentist_id, patient_id, tech_id = base
        other_dentist_id = lab.add_dentist("Dr. Other", "Other Clinic", "555-9999")
        lab.set_fee("crown", 150.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id)
        today = date.today()
        stmt = lab.generate_statement(other_dentist_id, today.year, today.month)
        assert not any(c["case_id"] == case_id for c in stmt["cases"])

    def test_incomplete_case_not_in_statement(self, base):
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 150.0)
        completed_case = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, completed_case, tech_id)
        incomplete_case = make_case(lab, dentist_id, patient_id)
        lab.advance_station(incomplete_case, "design", tech_id)
        lab.complete_station(incomplete_case, "design")
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        ids = [c["case_id"] for c in stmt["cases"]]
        assert completed_case in ids
        assert incomplete_case not in ids

    def test_pressing_path_case_billed_correctly(self, base):
        """End-to-end billing must work identically for the pressing path."""
        lab, dentist_id, patient_id, tech_id = base
        lab.set_fee("crown", 180.0)
        case_id = make_case(lab, dentist_id, patient_id)
        run_full_workflow(lab, case_id, tech_id, second_station="pressing")
        today = date.today()
        stmt = lab.generate_statement(dentist_id, today.year, today.month)
        entry = next(c for c in stmt["cases"] if c["case_id"] == case_id)
        assert entry["amount"] == pytest.approx(180.0)

    def test_two_dentists_statements_independent(self, base):
        """Each dentist's statement contains only their own completed cases."""
        lab, dentist1_id, patient_id, tech_id = base
        dentist2_id = lab.add_dentist("Dr. Second", "Second Practice", "555-2222")
        lab.set_fee("crown", 150.0)
        case1 = make_case(lab, dentist1_id, patient_id)
        run_full_workflow(lab, case1, tech_id)
        case2 = make_case(lab, dentist2_id, patient_id)
        run_full_workflow(lab, case2, tech_id)
        today = date.today()
        stmt1 = lab.generate_statement(dentist1_id, today.year, today.month)
        stmt2 = lab.generate_statement(dentist2_id, today.year, today.month)
        assert any(c["case_id"] == case1 for c in stmt1["cases"])
        assert not any(c["case_id"] == case2 for c in stmt1["cases"])
        assert any(c["case_id"] == case2 for c in stmt2["cases"])
        assert not any(c["case_id"] == case1 for c in stmt2["cases"])
