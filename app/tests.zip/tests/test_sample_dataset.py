from pathlib import Path

import pandas as pd


def _sample_path(project_root: Path) -> Path:
    return project_root / "app" / "data" / "sample_journey_events.csv"


def test_sample_dataset_loads_with_loader(import_or_fail, project_root):
    io = import_or_fail("app.io")
    events = io.load_journey_events_csv(str(_sample_path(project_root)))
    assert set(events.columns.tolist()) == {
        "journey_id",
        "touchpoint_index",
        "channel",
        "touchpoint_ts",
        "converted",
    }
    assert pd.api.types.is_datetime64tz_dtype(events["touchpoint_ts"])
    assert str(events["touchpoint_ts"].dt.tz) == "UTC"


def test_sample_dataset_has_at_least_three_distinct_channels(import_or_fail, project_root):
    io = import_or_fail("app.io")
    events = io.load_journey_events_csv(str(_sample_path(project_root)))
    assert int(events["channel"].nunique()) >= 3


def test_sample_dataset_has_at_least_ten_converted_journeys(import_or_fail, project_root):
    io = import_or_fail("app.io")
    events = io.load_journey_events_csv(str(_sample_path(project_root)))
    journey_labels = events.groupby("journey_id", sort=False)["converted"].first().astype(int)
    assert int((journey_labels == 1).sum()) >= 10


def test_sample_dataset_has_at_least_ten_null_journeys(import_or_fail, project_root):
    io = import_or_fail("app.io")
    events = io.load_journey_events_csv(str(_sample_path(project_root)))
    journey_labels = events.groupby("journey_id", sort=False)["converted"].first().astype(int)
    assert int((journey_labels == 0).sum()) >= 10


def test_sample_dataset_has_at_least_two_journeys_with_repeated_channel_touchpoints(import_or_fail, project_root):
    io = import_or_fail("app.io")
    events = io.load_journey_events_csv(str(_sample_path(project_root)))
    repeated = 0
    for _, grp in events.groupby("journey_id", sort=False):
        if int(grp["channel"].value_counts().max()) > 1:
            repeated += 1
    assert repeated >= 2
