import os
import sys
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class TestReportGeneratorReturnValues:
    """generate_director_report and generate_inspector_report must both return
    a str pointing to the written HTML file.
    Prompt Expected Interface: 'Output: str (file path of the generated HTML report)'
    """

    def test_generate_director_report_returns_file_path_string(
        self, sample_data_dir, output_dir
    ):
        """generate_director_report must return a str (not None, not a Path object)
        that points to an existing HTML file."""
        from pipeline import (
            load_and_validate, engineer_features, train_models,
            analyze_moratorium_violations, generate_director_report,
        )
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        model_results = train_models(feature_df)
        quarter_start = pd.Timestamp("2018-01-01")
        quarter_end = pd.Timestamp("2018-03-31")
        corridor_df = analyze_moratorium_violations(
            feature_df, datasets, quarter_start, quarter_end
        )

        result = generate_director_report(
            "Q1-2018", quarter_start, quarter_end,
            feature_df, model_results, corridor_df, datasets, output_dir,
        )

        assert isinstance(result, str), (
            f"generate_director_report must return a str file path; got {type(result).__name__}"
        )
        assert os.path.isfile(result), (
            "generate_director_report must return a path to an existing HTML file"
        )

    def test_generate_inspector_report_returns_file_path_string(
        self, sample_data_dir, output_dir
    ):
        """generate_inspector_report must return a str (not None, not a Path object)
        that points to an existing HTML file."""
        from pipeline import (
            load_and_validate, engineer_features, train_models,
            generate_inspector_report,
        )
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        model_results = train_models(feature_df)

        result = generate_inspector_report(feature_df, model_results, datasets, output_dir)

        assert isinstance(result, str), (
            f"generate_inspector_report must return a str file path; got {type(result).__name__}"
        )
        assert os.path.isfile(result), (
            "generate_inspector_report must return a path to an existing HTML file"
        )
