import pytest
from conftest import create_insurer, create_filing, unique_naic_code


class TestInsurerReport:
    def test_insurer_report_basic(self, client):
        insurer = create_insurer(client).json()
        resp = client.get(f"/api/reports/insurer/{insurer['insurer_id']}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["insurer_id"] == insurer["insurer_id"]
        assert data["company_name"] == insurer["company_name"]
        assert "total_rate_filings" in data
        assert "rate_filing_status_counts" in data
        assert "total_form_filings" in data
        assert "form_filing_status_counts" in data
        assert "total_exams" in data
        assert "avg_claim_handling_score" in data
        assert "avg_network_adequacy_score" in data
        assert "total_reconciliation_records" in data
        assert "net_risk_adjustment_amount" in data
        assert "total_public_comments" in data

    def test_insurer_report_counts_rate_filings(self, client):
        insurer = create_insurer(client).json()
        create_filing(client, insurer["insurer_id"])
        create_filing(client, insurer["insurer_id"])
        resp = client.get(f"/api/reports/insurer/{insurer['insurer_id']}")
        data = resp.json()
        assert data["total_rate_filings"] == 2

    def test_insurer_report_counts_rate_filing_statuses(self, client):
        insurer = create_insurer(client).json()
        create_filing(client, insurer["insurer_id"])
        create_filing(client, insurer["insurer_id"])
        resp = client.get(f"/api/reports/insurer/{insurer['insurer_id']}")
        data = resp.json()
        assert isinstance(data["rate_filing_status_counts"], dict)
        assert data["rate_filing_status_counts"].get("received", 0) == 2

    def test_insurer_report_avg_scores_null_when_no_completed_exams(self, client):
        insurer = create_insurer(client).json()
        resp = client.get(f"/api/reports/insurer/{insurer['insurer_id']}")
        data = resp.json()
        assert data["avg_claim_handling_score"] is None
        assert data["avg_network_adequacy_score"] is None

    def test_insurer_report_avg_scores_with_completed_exam(self, client):
        insurer = create_insurer(client).json()
        exam = client.post(
            "/api/examinations",
            json={
                "insurer_id": insurer["insurer_id"],
                "exam_type": "comprehensive",
                "scheduled_date": "2025-01-01",
            },
        ).json()
        client.post(
            f"/api/examinations/{exam['exam_id']}/complete",
            json={
                "claim_handling_score": 80.0,
                "network_adequacy_score": 90.0,
            },
        )
        resp = client.get(f"/api/reports/insurer/{insurer['insurer_id']}")
        data = resp.json()
        assert data["avg_claim_handling_score"] == 80.0
        assert data["avg_network_adequacy_score"] == 90.0

    def test_insurer_report_net_risk_adjustment(self, client):
        insurer = create_insurer(client).json()
        client.post(
            "/api/reconciliation",
            json={
                "insurer_id": insurer["insurer_id"],
                "plan_year": 2024,
                "risk_adjustment_transfer_amount": 100000.0,
                "notes": None,
            },
        )
        client.post(
            "/api/reconciliation",
            json={
                "insurer_id": insurer["insurer_id"],
                "plan_year": 2023,
                "risk_adjustment_transfer_amount": -30000.0,
                "notes": None,
            },
        )
        resp = client.get(f"/api/reports/insurer/{insurer['insurer_id']}")
        data = resp.json()
        assert data["total_reconciliation_records"] == 2
        assert data["net_risk_adjustment_amount"] == 70000.0

    def test_insurer_report_counts_public_comments(self, client):
        insurer = create_insurer(client).json()
        filing = create_filing(client, insurer["insurer_id"]).json()
        client.post(
            f"/api/filings/{filing['filing_id']}/comments",
            json={
                "commenter_name": "A",
                "commenter_email": "a@test.com",
                "comment_text": "Comment one.",
            },
        )
        client.post(
            f"/api/filings/{filing['filing_id']}/comments",
            json={
                "commenter_name": "B",
                "commenter_email": "b@test.com",
                "comment_text": "Comment two.",
            },
        )
        resp = client.get(f"/api/reports/insurer/{insurer['insurer_id']}")
        data = resp.json()
        assert data["total_public_comments"] == 2

    def test_insurer_report_form_filing_status_counts(self, client):
        insurer = create_insurer(client).json()
        all_benefits = {
            "mental_health_parity": True, "maternity_coverage": True,
            "preventive_care": True, "prescription_drug": True,
            "emergency_services": True, "pediatric_dental": True,
            "pediatric_vision": True, "rehabilitative_services": True,
            "laboratory_services": True, "chronic_disease_management": True,
        }
        missing_one = {k: v for k, v in all_benefits.items() if k != "preventive_care"}
        form1 = client.post("/api/form-filings", json={
            "insurer_id": insurer["insurer_id"], "form_type": "policy",
            "product_type": "individual", "submission_date": "2024-06-01",
            "mandated_benefits_checklist": all_benefits,
        }).json()
        form2 = client.post("/api/form-filings", json={
            "insurer_id": insurer["insurer_id"], "form_type": "policy",
            "product_type": "individual", "submission_date": "2024-06-01",
            "mandated_benefits_checklist": missing_one,
        }).json()
        client.post("/api/form-filings", json={
            "insurer_id": insurer["insurer_id"], "form_type": "certificate",
            "product_type": "individual", "submission_date": "2024-06-01",
            "mandated_benefits_checklist": all_benefits,
        })
        # Review form1 (all compliant -> approved) and form2 (missing benefit -> rejected).
        # Third form filing remains "received".
        client.post(f"/api/form-filings/{form1['form_filing_id']}/review")
        client.post(f"/api/form-filings/{form2['form_filing_id']}/review")
        resp = client.get(f"/api/reports/insurer/{insurer['insurer_id']}")
        data = resp.json()
        assert data["total_form_filings"] == 3
        counts = data["form_filing_status_counts"]
        assert counts.get("approved", 0) == 1
        assert counts.get("rejected", 0) == 1
        assert counts.get("received", 0) == 1

    def test_insurer_report_avg_scores_uses_completed_exams_only(self, client):
        insurer = create_insurer(client).json()
        # Complete one exam with known scores
        completed = client.post("/api/examinations", json={
            "insurer_id": insurer["insurer_id"],
            "exam_type": "comprehensive",
            "scheduled_date": "2025-01-01",
        }).json()
        client.post(f"/api/examinations/{completed['exam_id']}/complete", json={
            "claim_handling_score": 70.0,
            "network_adequacy_score": 85.0,
        })
        # Also create a scheduled (non-completed) exam - must not affect the averages
        client.post("/api/examinations", json={
            "insurer_id": insurer["insurer_id"],
            "exam_type": "claim_handling",
            "scheduled_date": "2025-06-01",
        })
        resp = client.get(f"/api/reports/insurer/{insurer['insurer_id']}")
        data = resp.json()
        assert data["total_exams"] == 2
        assert data["avg_claim_handling_score"] == 70.0
        assert data["avg_network_adequacy_score"] == 85.0


    def test_insurer_report_not_found(self, client):
        resp = client.get("/api/reports/insurer/nonexistent-id")
        assert resp.status_code == 404


class TestSerffSummaryReport:
    def test_serff_summary_returns_list(self, client):
        resp = client.get("/api/reports/serff-summary")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_serff_summary_includes_insurers_with_filings(self, client):
        naic1 = unique_naic_code()
        naic2 = unique_naic_code()
        ins1 = create_insurer(client, naic_code=naic1, company_name=f"Alpha {naic1}").json()
        ins2 = create_insurer(client, naic_code=naic2, company_name=f"Beta {naic2}").json()
        create_filing(client, ins1["insurer_id"])
        create_filing(client, ins1["insurer_id"])
        create_filing(client, ins2["insurer_id"])
        resp = client.get("/api/reports/serff-summary")
        data = resp.json()
        naic_codes = {entry["naic_code"] for entry in data}
        assert naic1 in naic_codes
        assert naic2 in naic_codes

    def test_serff_summary_excludes_insurers_without_filings(self, client):
        naic_with = unique_naic_code()
        naic_without = unique_naic_code()
        ins_with = create_insurer(client, naic_code=naic_with).json()
        create_insurer(client, naic_code=naic_without)
        create_filing(client, ins_with["insurer_id"])
        resp = client.get("/api/reports/serff-summary")
        data = resp.json()
        naic_codes = {entry["naic_code"] for entry in data}
        assert naic_with in naic_codes
        assert naic_without not in naic_codes

    def test_serff_summary_contains_required_fields(self, client):
        naic = unique_naic_code()
        insurer = create_insurer(client, naic_code=naic, company_name=f"Epsilon {naic}").json()
        create_filing(client, insurer["insurer_id"])
        resp = client.get("/api/reports/serff-summary")
        data = resp.json()
        matching = [e for e in data if e["naic_code"] == naic]
        assert len(matching) >= 1
        entry = matching[0]
        assert "naic_code" in entry
        assert "company_name" in entry
        assert "total_filings" in entry
        assert "status_counts" in entry
        assert isinstance(entry["status_counts"], dict)
