"""Tests for end-to-end reproducibility (section 7 of the prompt)."""

import pandas as pd
import pytest


@pytest.mark.parametrize(
    "kwargs",
    [
        {},
        {"random_state": 7},
        {"saturation_threshold": 2.5},
        {"as_of_date": pd.Timestamp("2024-11-15")},
        {
            "as_of_date": pd.Timestamp("2024-10-15"),
            "saturation_threshold": 0.5,
            "random_state": 100,
        },
    ],
)
def test_two_pipeline_runs_produce_equal_dataframes(
    DonorPipeline, sample_donations, kwargs
):
    """Two independent ``fit`` followed by ``rank_donors`` invocations on
    the same DataFrame with the same constructor arguments produce
    DataFrames that compare equal under ``pandas.DataFrame.equals``.

    Parametrised across constructor-argument combinations so the
    "with the same constructor arguments" clause of section 7 is
    exercised for the default config *and* for custom values of
    every constructor argument (``as_of_date``,
    ``saturation_threshold``, ``random_state``). An implementation
    that introduces hidden non-determinism only under custom
    configurations would pass the default-only check but fail here.
    """

    out1 = DonorPipeline(**kwargs).fit(sample_donations).rank_donors(sample_donations)
    out2 = DonorPipeline(**kwargs).fit(sample_donations).rank_donors(sample_donations)

    assert out1.equals(out2)
