"""
Test suite for the `blink_tree` Rust crate.

Single-file pytest module driven by `cargo test`: a session-scoped helper
materialises a tiny runner crate that path-depends on the user's
`blink_tree` crate, drops one Rust integration file with many `#[test]`
functions exercising the documented public API and concurrency contracts,
runs `cargo test` once, parses per-test outcomes, and each Python test
asserts that one specific Rust test passed.

On an empty repository every test fails gracefully: the runner cannot
link against a non-existent `blink_tree` crate, so the per-test result
mapping is empty and each `assert status == "ok"` fails with a clear
message (no ERROR, no SKIPPED, no stub files required).

The crate location can be overridden with the `BLINK_TREE_CRATE`
environment variable; it defaults to `/app`, which is the conventional
mount point used by the evaluation harness.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest


CRATE_PATH = Path(os.environ.get("BLINK_TREE_CRATE", "/app")).resolve()


# ---------------------------------------------------------------------------
# Rust integration-test source
# ---------------------------------------------------------------------------

INTEGRATION_RS = r"""
use blink_tree::{BLinkTree, RwLockBTreeMap};
use std::sync::Arc;
use std::thread;

fn assert_send<T: Send>() {}
fn assert_sync<T: Sync>() {}

#[test]
fn new_creates_empty_tree() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    assert_eq!(t.len(), 0);
    assert!(t.is_empty());
}

#[test]
fn default_equivalent_to_new() {
    let t: BLinkTree<u64, u64> = BLinkTree::default();
    assert_eq!(t.len(), 0);
    assert!(t.is_empty());
}

#[test]
fn insert_new_key_returns_none() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    assert_eq!(t.insert(1, 10), None);
    assert_eq!(t.insert(2, 20), None);
    assert_eq!(t.insert(3, 30), None);
}

#[test]
fn insert_existing_key_returns_previous_and_keeps_len() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    t.insert(1, 10);
    let len_before = t.len();
    assert_eq!(t.insert(1, 99), Some(10));
    assert_eq!(t.len(), len_before);
    assert_eq!(t.get(&1), Some(99));
}

#[test]
fn get_present_returns_value_clone() {
    let t: BLinkTree<u64, String> = BLinkTree::new();
    t.insert(42, String::from("hello"));
    assert_eq!(t.get(&42), Some(String::from("hello")));
    // Calling get again must continue to return the same value (clone, not move).
    assert_eq!(t.get(&42), Some(String::from("hello")));
}

#[test]
fn get_absent_returns_none() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    assert_eq!(t.get(&999), None);
    t.insert(1, 1);
    assert_eq!(t.get(&999), None);
}

#[test]
fn contains_key_matches_get() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    t.insert(7, 70);
    assert_eq!(t.contains_key(&7), t.get(&7).is_some());
    assert_eq!(t.contains_key(&8), t.get(&8).is_some());
    assert!(t.contains_key(&7));
    assert!(!t.contains_key(&8));
}

#[test]
fn remove_present_returns_value_and_clears_mapping() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    t.insert(5, 50);
    assert_eq!(t.remove(&5), Some(50));
    assert_eq!(t.get(&5), None);
    assert!(!t.contains_key(&5));
}

#[test]
fn remove_absent_returns_none() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    assert_eq!(t.remove(&123), None);
    t.insert(1, 1);
    assert_eq!(t.remove(&999), None);
    // A second remove of a previously removed key is also None.
    t.remove(&1);
    assert_eq!(t.remove(&1), None);
}

#[test]
fn len_tracks_inserts_and_removes() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    assert_eq!(t.len(), 0);
    for i in 0..50u64 { t.insert(i, i); }
    assert_eq!(t.len(), 50);
    for i in 0..25u64 { assert_eq!(t.remove(&i), Some(i)); }
    assert_eq!(t.len(), 25);
}

#[test]
fn is_empty_reflects_len_zero() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    assert!(t.is_empty());
    t.insert(1, 1);
    assert!(!t.is_empty());
    t.remove(&1);
    assert!(t.is_empty());
    assert_eq!(t.is_empty(), t.len() == 0);
}

#[test]
fn range_collect_inclusive_bounds() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    for i in 0..20u64 { t.insert(i, i * 10); }
    let r = t.range_collect(&5, &10);
    let keys: Vec<u64> = r.iter().map(|(k, _)| *k).collect();
    assert_eq!(keys, vec![5, 6, 7, 8, 9, 10]);
    for (k, v) in r { assert_eq!(v, k * 10); }
}

#[test]
fn range_collect_sorted_ascending_by_key() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    let inserts = [50u64, 5, 30, 2, 99, 17, 8, 70, 11, 23, 100, 0, 64];
    for &k in inserts.iter() { t.insert(k, k); }
    let r = t.range_collect(&0, &100);
    let keys: Vec<u64> = r.iter().map(|(k, _)| *k).collect();
    let mut expected = inserts.to_vec();
    expected.sort();
    assert_eq!(keys, expected);
}

#[test]
fn range_collect_empty_when_no_keys_in_range() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    for i in 100..110u64 { t.insert(i, i); }
    let r = t.range_collect(&0, &50);
    assert!(r.is_empty());
}

#[test]
fn range_collect_empty_on_empty_tree() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    let r = t.range_collect(&0, &u64::MAX);
    assert!(r.is_empty());
}

#[test]
fn range_collect_full_range_returns_all() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    for i in 0..30u64 { t.insert(i, i + 1000); }
    let r = t.range_collect(&u64::MIN, &u64::MAX);
    assert_eq!(r.len(), 30);
    for (k, v) in r { assert_eq!(v, k + 1000); }
}

#[test]
fn send_sync_marker_traits_are_implemented() {
    assert_send::<BLinkTree<u64, u64>>();
    assert_sync::<BLinkTree<u64, u64>>();
    assert_send::<RwLockBTreeMap<u64, u64>>();
    assert_sync::<RwLockBTreeMap<u64, u64>>();
}

#[test]
fn arc_shared_across_threads_inserts_and_reads() {
    let t = Arc::new(BLinkTree::<u64, u64>::new());
    let mut handles = Vec::new();
    for tid in 0..4u64 {
        let t = Arc::clone(&t);
        handles.push(thread::spawn(move || {
            for i in 0..100u64 {
                let k = tid * 1000 + i;
                t.insert(k, k);
            }
        }));
    }
    for h in handles { h.join().unwrap(); }
    assert_eq!(t.len(), 4 * 100);
    for tid in 0..4u64 {
        for i in 0..100u64 {
            let k = tid * 1000 + i;
            assert_eq!(t.get(&k), Some(k));
        }
    }
}

#[test]
fn concurrent_inserts_all_visible_after_join() {
    let t = Arc::new(BLinkTree::<u64, u64>::new());
    let n_threads: u64 = 4;
    let per_thread: u64 = 250;
    let mut handles = Vec::new();
    for tid in 0..n_threads {
        let t = Arc::clone(&t);
        handles.push(thread::spawn(move || {
            for i in 0..per_thread {
                let k = tid * per_thread + i;
                t.insert(k, k.wrapping_mul(7));
            }
        }));
    }
    for h in handles { h.join().unwrap(); }
    let total = n_threads * per_thread;
    assert_eq!(t.len() as u64, total);
    for k in 0..total {
        assert_eq!(t.get(&k), Some(k.wrapping_mul(7)), "missing key {}", k);
    }
}

#[test]
fn concurrent_readers_observe_stable_prefix_under_writer() {
    let t = Arc::new(BLinkTree::<u64, u64>::new());
    for i in 0..200u64 { t.insert(i, i); }
    let mut handles = Vec::new();
    // Reader threads: continuously look up the pre-populated keys; each one
    // must always be visible because writers only mutate a disjoint range.
    for _ in 0..2 {
        let t = Arc::clone(&t);
        handles.push(thread::spawn(move || {
            for _ in 0..100 {
                for k in 0..200u64 {
                    assert_eq!(t.get(&k), Some(k));
                }
            }
        }));
    }
    // Writer thread: insert and remove a disjoint key range repeatedly.
    {
        let t = Arc::clone(&t);
        handles.push(thread::spawn(move || {
            for cycle in 0..10u64 {
                for k in 200..400u64 { t.insert(k, k.wrapping_add(cycle)); }
                for k in 200..400u64 { t.remove(&k); }
            }
        }));
    }
    for h in handles { h.join().unwrap(); }
    for k in 0..200u64 {
        assert_eq!(t.get(&k), Some(k), "pre-populated key {} corrupted", k);
    }
    assert_eq!(t.len(), 200);
}

#[test]
fn many_inserts_round_trip_under_splits() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    let n: u64 = 5000;
    for i in 0..n { t.insert(i, i + 1); }
    assert_eq!(t.len() as u64, n);
    for i in 0..n {
        assert_eq!(t.get(&i), Some(i + 1));
        assert!(t.contains_key(&i));
    }
    let r = t.range_collect(&0, &(n - 1));
    let keys: Vec<u64> = r.iter().map(|(k, _)| *k).collect();
    let expected: Vec<u64> = (0..n).collect();
    assert_eq!(keys, expected);
}

#[test]
fn random_order_inserts_are_searchable() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    // Deterministic non-monotonic key order (LCG-style) to exercise
    // splits on non-sequential inputs.
    let mut x: u64 = 1;
    let mut keys: Vec<u64> = Vec::new();
    for _ in 0..1000 {
        x = x.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        let k = x % 10_000;
        keys.push(k);
    }
    for &k in keys.iter() { t.insert(k, k.wrapping_mul(3)); }
    for &k in keys.iter() { assert_eq!(t.get(&k), Some(k.wrapping_mul(3))); }
}

#[test]
fn remove_then_reinsert_preserves_consistency() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    for i in 0..100u64 { t.insert(i, i); }
    for i in 0..50u64 { assert_eq!(t.remove(&i), Some(i)); }
    assert_eq!(t.len(), 50);
    for i in 0..50u64 { assert_eq!(t.insert(i, i + 1000), None); }
    assert_eq!(t.len(), 100);
    for i in 0..50u64 { assert_eq!(t.get(&i), Some(i + 1000)); }
    for i in 50..100u64 { assert_eq!(t.get(&i), Some(i)); }
}

#[test]
fn remove_until_empty_then_reuse() {
    let t: BLinkTree<u64, u64> = BLinkTree::new();
    for i in 0..200u64 { t.insert(i, i); }
    for i in 0..200u64 { assert_eq!(t.remove(&i), Some(i)); }
    assert!(t.is_empty());
    assert_eq!(t.len(), 0);
    // Reuse the empty tree.
    for i in 0..50u64 { t.insert(i, i + 7); }
    assert_eq!(t.len(), 50);
    for i in 0..50u64 { assert_eq!(t.get(&i), Some(i + 7)); }
}

#[test]
fn range_collect_during_concurrent_in_range_inserts_keeps_pre_keys() {
    use std::collections::HashSet;
    use std::sync::atomic::{AtomicBool, Ordering};

    let t = Arc::new(BLinkTree::<u64, u64>::new());

    // Pre-populate even keys in [0, 2*PRE). These are never removed,
    // so every range_collect over [0, 2*PRE] must include all of them
    // even while a writer concurrently inserts new keys *inside* the
    // same range, forcing splits that the reader must follow via the
    // leaf-level right-link chain.
    let pre: u64 = 800;
    let high: u64 = 2 * pre;
    for i in 0..pre {
        t.insert(i * 2, i * 2);
    }

    let stop = Arc::new(AtomicBool::new(false));
    let mut handles = Vec::new();

    // Writer: insert odd keys cycling through (1, 3, 5, ..., high-1)
    // to keep producing splits in the same range the reader scans.
    {
        let t = Arc::clone(&t);
        let stop = Arc::clone(&stop);
        handles.push(thread::spawn(move || {
            let mut k: u64 = 1;
            while !stop.load(Ordering::Relaxed) {
                t.insert(k, k);
                k += 2;
                if k >= high { k = 1; }
            }
        }));
    }

    let mut iterations: u32 = 0;
    while iterations < 200 {
        let r = t.range_collect(&0, &high);

        // The returned vec must be sorted strictly ascending by key.
        for w in r.windows(2) {
            assert!(w[0].0 < w[1].0,
                "range_collect produced non-strictly-ascending keys: {} >= {}",
                w[0].0, w[1].0);
        }
        // Every returned key must lie in [0, high].
        for &(k, _) in r.iter() {
            assert!(k <= high, "range_collect returned key {} > high {}", k, high);
        }
        // Every never-removed pre-populated key must still be present.
        let observed: HashSet<u64> = r.iter().map(|(k, _)| *k).collect();
        for i in 0..pre {
            let target = i * 2;
            assert!(observed.contains(&target),
                "range_collect missed pre-populated key {} during concurrent splits", target);
        }
        iterations += 1;
    }

    stop.store(true, Ordering::Relaxed);
    for h in handles { h.join().unwrap(); }
}

#[test]
fn rwlockbtreemap_basic_crud() {
    let m: RwLockBTreeMap<u64, u64> = RwLockBTreeMap::new();
    assert_eq!(m.get(&1), None);
    assert_eq!(m.insert(1, 10), None);
    assert_eq!(m.get(&1), Some(10));
    assert_eq!(m.insert(1, 11), Some(10));
    assert_eq!(m.get(&1), Some(11));
    assert_eq!(m.remove(&1), Some(11));
    assert_eq!(m.get(&1), None);
    assert_eq!(m.remove(&1), None);
}

#[test]
fn rwlockbtreemap_arc_shared_across_threads() {
    let m = Arc::new(RwLockBTreeMap::<u64, u64>::new());
    let mut handles = Vec::new();
    for tid in 0..4u64 {
        let m = Arc::clone(&m);
        handles.push(thread::spawn(move || {
            for i in 0..50u64 {
                let k = tid * 100 + i;
                m.insert(k, k);
            }
        }));
    }
    for h in handles { h.join().unwrap(); }
    for tid in 0..4u64 {
        for i in 0..50u64 {
            let k = tid * 100 + i;
            assert_eq!(m.get(&k), Some(k));
        }
    }
}
"""


# ---------------------------------------------------------------------------
# Session-scoped helper: run cargo test once and collect per-test results
# ---------------------------------------------------------------------------

_TEST_LINE_RE = re.compile(
    r"^test\s+([A-Za-z0-9_:]+)\s+\.\.\.\s+(ok|FAILED|ignored)\s*$"
)


def _build_runner_dir(tmp_path: Path) -> Path:
    runner = tmp_path / "blink_tree_runner"
    runner.mkdir(parents=True, exist_ok=True)
    crate_path_str = str(CRATE_PATH).replace("\\", "/")
    (runner / "Cargo.toml").write_text(
        "[package]\n"
        'name = "blink_tree_runner"\n'
        'version = "0.0.1"\n'
        'edition = "2021"\n'
        "\n"
        "[lib]\n"
        'path = "src/lib.rs"\n'
        "\n"
        "[dependencies]\n"
        f'blink_tree = {{ path = "{crate_path_str}" }}\n'
        "\n"
        "[[test]]\n"
        'name = "blink_integration"\n'
        'path = "tests/blink_integration.rs"\n',
        encoding="utf-8",
    )
    (runner / "src").mkdir(exist_ok=True)
    (runner / "src" / "lib.rs").write_text("", encoding="utf-8")
    (runner / "tests").mkdir(exist_ok=True)
    (runner / "tests" / "blink_integration.rs").write_text(
        INTEGRATION_RS, encoding="utf-8"
    )
    return runner


def _collect_results(stdout: str, stderr: str) -> dict[str, str]:
    """Map short test name -> 'ok' | 'FAILED' | 'ignored'."""
    results: dict[str, str] = {}
    for chunk in (stdout, stderr):
        for line in chunk.splitlines():
            m = _TEST_LINE_RE.match(line.strip())
            if not m:
                continue
            name, status = m.group(1), m.group(2)
            short = name.split("::")[-1]
            results[short] = status
    return results


@pytest.fixture(scope="session")
def cargo_test_results(tmp_path_factory) -> dict[str, str]:
    """Run cargo test once against the user's crate; return per-test outcomes.

    Returns an empty mapping on any environmental failure (missing crate,
    missing cargo, build failure, timeout). Individual tests then fail with
    a clear message instead of erroring out.
    """
    if not (CRATE_PATH / "Cargo.toml").exists():
        return {}
    if shutil.which("cargo") is None:
        return {}

    runner = _build_runner_dir(tmp_path_factory.mktemp("blink_runner_root"))
    try:
        proc = subprocess.run(
            ["cargo", "test", "--no-fail-fast", "--", "--test-threads=1"],
            cwd=str(runner),
            capture_output=True,
            text=True,
            timeout=900,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return {}

    return _collect_results(proc.stdout or "", proc.stderr or "")


def _assert_rust_test_passed(results: dict[str, str], name: str) -> None:
    status = results.get(name)
    assert status == "ok", (
        f"Rust integration test '{name}' did not pass "
        f"(status={status!r}); cargo test produced no PASS line for it. "
        "This usually means the crate failed to build or the requirement "
        "is unmet."
    )


# ---------------------------------------------------------------------------
# Session-scoped helper: list the user's Criterion benches by full ID.
#
# Running `cargo bench --bench bench -- --list` compiles and invokes the
# user's bench binary in Criterion's "list" mode, which enumerates every
# registered benchmark ID without running any iteration. This is fully
# functional: the bench binary, Criterion dev-dep, [[bench]] registration,
# and the keyset-loading code that runs at registration time must all
# work for the listing to succeed. No source files are scanned.
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def cargo_bench_listing(tmp_path_factory) -> str:
    """Combined stdout+stderr of `cargo bench --bench bench -- --list`.

    Returns an empty string on any environmental failure (missing crate,
    missing cargo, build failure, timeout). Tests that depend on this
    fixture then fail naturally on their assertion rather than erroring.
    """
    if not (CRATE_PATH / "Cargo.toml").exists():
        return ""
    if shutil.which("cargo") is None:
        return ""

    try:
        proc = subprocess.run(
            ["cargo", "bench", "--bench", "bench", "--", "--list"],
            cwd=str(CRATE_PATH),
            capture_output=True,
            text=True,
            timeout=1200,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return ""

    if proc.returncode != 0:
        return ""
    return (proc.stdout or "") + "\n" + (proc.stderr or "")


@pytest.fixture(scope="session")
def cargo_bench_test_mode_run(cargo_bench_listing) -> tuple:
    """Run `cargo bench --bench bench -- --test` end-to-end.

    Criterion's `--test` mode invokes each registered benchmark function
    once without timing, so this exercises the full iteration body of
    every workload against both implementations using the committed data
    file. Depending on `cargo_bench_listing` keeps the bench binary
    compiled in the cargo cache.

    Returns `(returncode, combined_output)`. On any environmental failure
    (missing crate, missing cargo, build failure, timeout) returns
    `(1, "")` so the dependent test fails naturally on its assertion
    rather than erroring.
    """
    if not (CRATE_PATH / "Cargo.toml").exists():
        return (1, "")
    if shutil.which("cargo") is None:
        return (1, "")

    try:
        proc = subprocess.run(
            ["cargo", "bench", "--bench", "bench", "--", "--test"],
            cwd=str(CRATE_PATH),
            capture_output=True,
            text=True,
            timeout=1200,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return (1, "")

    return (proc.returncode, (proc.stdout or "") + "\n" + (proc.stderr or ""))


# ===========================================================================
# Functional tests (delegated to cargo test)
# ===========================================================================

# Covers BLinkTree::new and the empty-tree state of len/is_empty.
def test_blink_tree_new_creates_empty_tree(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "new_creates_empty_tree")


# Covers `impl Default for BLinkTree` returning an empty tree like new().
def test_blink_tree_default_equivalent_to_new(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "default_equivalent_to_new")


# Covers BLinkTree::insert returning None for previously absent keys.
def test_blink_tree_insert_new_key_returns_none(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "insert_new_key_returns_none")


# Covers BLinkTree::insert returning Some(old) for present keys with no len change.
def test_blink_tree_insert_existing_key_returns_previous_value(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "insert_existing_key_returns_previous_and_keeps_len"
    )


# Covers BLinkTree::get returning a clone of the current value when present.
def test_blink_tree_get_present_returns_value(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "get_present_returns_value_clone")


# Covers BLinkTree::get returning None when the key is absent.
def test_blink_tree_get_absent_returns_none(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "get_absent_returns_none")


# Covers BLinkTree::contains_key being equivalent to get(...).is_some().
def test_blink_tree_contains_key_matches_get(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "contains_key_matches_get")


# Covers BLinkTree::remove returning Some(value) and clearing the mapping.
def test_blink_tree_remove_present_returns_value(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "remove_present_returns_value_and_clears_mapping"
    )


# Covers BLinkTree::remove returning None for absent keys.
def test_blink_tree_remove_absent_returns_none(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "remove_absent_returns_none")


# Covers BLinkTree::len updating consistently across inserts and removes.
def test_blink_tree_len_tracks_inserts_and_removes(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "len_tracks_inserts_and_removes")


# Covers BLinkTree::is_empty mirroring len() == 0.
def test_blink_tree_is_empty_reflects_len_zero(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "is_empty_reflects_len_zero")


# Covers BLinkTree::range_collect using inclusive [low, high] bounds.
def test_blink_tree_range_collect_inclusive_bounds(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "range_collect_inclusive_bounds")


# Covers BLinkTree::range_collect returning entries sorted ascending by key.
def test_blink_tree_range_collect_sorted_ascending(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "range_collect_sorted_ascending_by_key"
    )


# Covers BLinkTree::range_collect returning empty when no keys lie in range.
def test_blink_tree_range_collect_empty_when_no_keys_in_range(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "range_collect_empty_when_no_keys_in_range"
    )


# Covers BLinkTree::range_collect on an empty tree returning empty.
def test_blink_tree_range_collect_empty_on_empty_tree(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "range_collect_empty_on_empty_tree")


# Covers BLinkTree::range_collect returning every entry across the full domain.
def test_blink_tree_range_collect_full_range_returns_all(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "range_collect_full_range_returns_all")


# Covers BLinkTree and RwLockBTreeMap implementing Send and Sync.
def test_send_sync_marker_traits_are_implemented(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "send_sync_marker_traits_are_implemented"
    )


# Covers Arc<BLinkTree> being shareable across threads via &self mutation.
def test_arc_shared_across_threads_inserts_and_reads(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "arc_shared_across_threads_inserts_and_reads"
    )


# Covers concurrent inserts: every key written by any thread is visible after join.
def test_concurrent_inserts_all_visible_after_join(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "concurrent_inserts_all_visible_after_join"
    )


# Covers concurrency correctness: readers never observe corrupted state when
# writers operate on a disjoint key range concurrently.
def test_concurrent_readers_observe_stable_prefix_under_writer(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "concurrent_readers_observe_stable_prefix_under_writer"
    )


# Covers the implicit requirement that the tree behaves correctly under
# enough inserts to force splits and tree-height growth.
def test_many_inserts_round_trip_under_splits(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "many_inserts_round_trip_under_splits")


# Covers correctness of inserts in non-monotonic key order.
def test_random_order_inserts_are_searchable(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "random_order_inserts_are_searchable")


# Covers remove + reinsert preserving the post-state correctly (stresses merges).
def test_remove_then_reinsert_preserves_consistency(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "remove_then_reinsert_preserves_consistency"
    )


# Covers shrinking the tree to empty and reusing it (root-collapse path).
def test_remove_until_empty_then_reuse(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "remove_until_empty_then_reuse")


# Covers the prompt's range_collect snapshot guarantee: under concurrent
# in-range inserts that force splits at the leaf level, every key that
# was present in the tree for the duration of the scan must appear in
# the returned vec (which must remain sorted and within bounds), because
# the scan follows the leaf-level right-link chain.
#
# Note: the strict-ascending check is the prompt's "sorted ascending"
# combined with the map's per-key uniqueness invariant (insert replaces
# instead of duplicating), so equal adjacent keys would already violate
# the documented contract.
def test_range_collect_during_concurrent_in_range_inserts(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results,
        "range_collect_during_concurrent_in_range_inserts_keeps_pre_keys",
    )


# Covers the four documented inherent methods on RwLockBTreeMap (new/insert/get/remove).
def test_rwlockbtreemap_basic_crud(cargo_test_results):
    _assert_rust_test_passed(cargo_test_results, "rwlockbtreemap_basic_crud")


# Covers RwLockBTreeMap being shareable through Arc across threads.
def test_rwlockbtreemap_arc_shared_across_threads(cargo_test_results):
    _assert_rust_test_passed(
        cargo_test_results, "rwlockbtreemap_arc_shared_across_threads"
    )


# ---------------------------------------------------------------------------
# Benchmark harness verification (functional, via `cargo bench -- --list`)
# ---------------------------------------------------------------------------

# Covers, in a single execution-driven check:
#   - benches/bench.rs is registered correctly under [[bench]] in Cargo.toml
#     (otherwise `cargo bench --bench bench` cannot resolve the target),
#   - criterion is actually a usable dev-dependency (otherwise the bench
#     binary fails to compile),
#   - the Criterion benchmark group name is `concurrent_map`,
#   - all six bench IDs `concurrent_map/<workload>/<impl>` are registered
#     for the three workloads against both implementations,
#   - the bench binary's keyset-loading code that runs at registration
#     time succeeds under cargo's default environment (the only path
#     that consistently locates `data/keys.txt` is via CARGO_MANIFEST_DIR,
#     which cargo always sets for benches).
def test_bench_lists_all_six_concurrent_map_ids(cargo_bench_listing):
    expected_ids = [
        "concurrent_map/insert_only/blink",
        "concurrent_map/insert_only/rwlock_btreemap",
        "concurrent_map/read_heavy/blink",
        "concurrent_map/read_heavy/rwlock_btreemap",
        "concurrent_map/mixed_concurrent/blink",
        "concurrent_map/mixed_concurrent/rwlock_btreemap",
    ]
    assert cargo_bench_listing, (
        "`cargo bench --bench bench -- --list` produced no usable output. "
        "Either the bench target is not registered in Cargo.toml, the bench "
        "binary failed to compile, or the keyset failed to load."
    )
    missing = [bid for bid in expected_ids if bid not in cargo_bench_listing]
    assert not missing, (
        "Bench listing is missing the following Criterion IDs: "
        f"{missing}. Got listing:\n{cargo_bench_listing}"
    )


# Covers the prompt's end-to-end execution requirement for the bench binary:
#   "The binary runs end-to-end with `cargo bench --bench bench` using only
#    the committed data file."
#
# Criterion's `--test` mode invokes each registered benchmark function once
# without timing, so this verifies that every workload's iteration body
# (insert_only, read_heavy, mixed_concurrent against both BLinkTree and
# RwLockBTreeMap) actually runs to completion against the committed keyset
# rather than only registering successfully.
def test_bench_binary_runs_each_workload_end_to_end(cargo_bench_test_mode_run):
    returncode, output = cargo_bench_test_mode_run
    assert returncode == 0, (
        "`cargo bench --bench bench -- --test` did not exit cleanly. At "
        "least one Criterion-registered workload failed to run end-to-end. "
        f"Exit code: {returncode}. Output:\n{output}"
    )
