"""
F2P test suite for the simplified Zanzibar authorization system.

Every test maps to an explicit or implicit requirement from the prompt.
Tests verify observable behavior and public interfaces only.
"""

import os
import tempfile
import pytest

# ---------------------------------------------------------------------------
# Guarded import - yields None on empty repo so tests FAIL not ERROR
# ---------------------------------------------------------------------------

@pytest.fixture
def zanzibar_module():
    """
    Yields the zanzibar module, or None when it cannot be imported.
    The fixture itself NEVER raises - only _require() raises inside test bodies.
    """
    try:
        import zanzibar as _z
        yield _z
    except ImportError:
        yield None

def _require(module):
    """
    Call as the FIRST LINE of every test body.
    Raises pytest.Failed (FAILED, not ERROR) when zanzibar is not found.
    """
    if module is None:
        pytest.fail("zanzibar module not found - empty repository")

# ---------------------------------------------------------------------------
# Store fixture - depends on guarded module
# ---------------------------------------------------------------------------

@pytest.fixture
def store(zanzibar_module):
    """Provide a fresh ZanzibarStore backed by a temporary file for each test.
    Yields None when the module is absent - the fixture itself never raises.
    _require() in each test body is responsible for producing a clean FAILED."""
    if zanzibar_module is None:
        yield None
        return
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    s = zanzibar_module.ZanzibarStore(db_path)
    yield s
    os.unlink(db_path)

# ---------------------------------------------------------------------------
# ZanzibarStore initialisation
# ---------------------------------------------------------------------------

class TestInitialisation:
    def test_instantiation_succeeds(self, zanzibar_module, tmp_path):
        _require(zanzibar_module)
        db_path = str(tmp_path / "z.db")
        s = zanzibar_module.ZanzibarStore(db_path)
        assert s.check("alice", "owner", "doc:readme") is False

# ---------------------------------------------------------------------------
# add_tuple
# ---------------------------------------------------------------------------

class TestAddTuple:
    def test_add_tuple_returns_none(self, zanzibar_module, store):
        _require(zanzibar_module)
        result = store.add_tuple("alice", "owner", "doc:readme")
        assert result is None

    def test_add_duplicate_tuple_is_noop(self, zanzibar_module, store):
        """Duplicate add must not raise and the tuple must still be present."""
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_tuple("alice", "owner", "doc:readme")  # must not raise
        assert store.check("alice", "owner", "doc:readme") is True

    def test_distinct_tuples_stored_independently(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_tuple("bob", "viewer", "doc:readme")
        assert store.check("alice", "owner", "doc:readme") is True
        assert store.check("bob", "viewer", "doc:readme") is True
        assert store.check("alice", "viewer", "doc:readme") is False

# ---------------------------------------------------------------------------
# remove_tuple
# ---------------------------------------------------------------------------

class TestRemoveTuple:
    def test_remove_tuple_returns_none(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        result = store.remove_tuple("alice", "owner", "doc:readme")
        assert result is None

    def test_remove_nonexistent_tuple_is_noop(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.remove_tuple("ghost", "owner", "doc:readme")  # must not raise

    def test_removed_tuple_no_longer_grants_permission(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "viewer", "doc:readme")
        assert store.check("alice", "viewer", "doc:readme") is True
        store.remove_tuple("alice", "viewer", "doc:readme")
        assert store.check("alice", "viewer", "doc:readme") is False

    def test_remove_does_not_affect_other_tuples(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_tuple("bob", "viewer", "doc:readme")
        store.remove_tuple("alice", "owner", "doc:readme")
        assert store.check("bob", "viewer", "doc:readme") is True

# ---------------------------------------------------------------------------
# add_rule
# ---------------------------------------------------------------------------

class TestAddRule:
    def test_add_rule_returns_none(self, zanzibar_module, store):
        _require(zanzibar_module)
        result = store.add_rule("owner", "editor")
        assert result is None

    def test_add_duplicate_rule_is_noop(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_rule("owner", "editor")
        store.add_rule("owner", "editor")  # must not raise

    def test_rule_is_directional(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "editor", "doc:readme")
        store.add_rule("owner", "editor")
        assert store.check("alice", "owner", "doc:readme") is False

# ---------------------------------------------------------------------------
# check - direct and transitive
# ---------------------------------------------------------------------------

class TestCheckDirect:
    def test_direct_permission_granted(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "viewer", "doc:readme")
        assert store.check("alice", "viewer", "doc:readme") is True

    def test_no_tuple_returns_false(self, zanzibar_module, store):
        _require(zanzibar_module)
        assert store.check("alice", "viewer", "doc:readme") is False

    def test_wrong_user_returns_false(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "viewer", "doc:readme")
        assert store.check("bob", "viewer", "doc:readme") is False

    def test_wrong_permission_returns_false(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "viewer", "doc:readme")
        assert store.check("alice", "editor", "doc:readme") is False

    def test_wrong_object_returns_false(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "viewer", "doc:readme")
        assert store.check("alice", "viewer", "doc:other") is False

class TestCheckTransitive:
    def test_single_hop_implication(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_rule("owner", "editor")
        assert store.check("alice", "editor", "doc:readme") is True

    def test_two_hop_implication(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_rule("owner", "editor")
        store.add_rule("editor", "viewer")
        assert store.check("alice", "viewer", "doc:readme") is True

    def test_three_hop_implication(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "admin", "doc:readme")
        store.add_rule("admin", "owner")
        store.add_rule("owner", "editor")
        store.add_rule("editor", "viewer")
        assert store.check("alice", "viewer", "doc:readme") is True

    def test_unrelated_rule_does_not_grant_permission(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "viewer", "doc:readme")
        store.add_rule("owner", "editor")
        assert store.check("alice", "editor", "doc:readme") is False

    def test_implication_scoped_to_same_object(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_rule("owner", "editor")
        assert store.check("alice", "editor", "doc:other") is False

class TestCheckCyclicRules:
    def test_cyclic_rules_do_not_cause_infinite_loop(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_rule("owner", "editor")
        store.add_rule("editor", "owner")
        result = store.check("alice", "owner", "doc:readme")
        assert result is False

    def test_cyclic_rules_still_grant_direct_permission(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_rule("owner", "editor")
        store.add_rule("editor", "owner")
        assert store.check("alice", "editor", "doc:readme") is True

# ---------------------------------------------------------------------------
# check - group membership (single-level)
# ---------------------------------------------------------------------------

class TestCheckGroupMembership:
    def test_group_member_inherits_relation(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:eng#member", "editor", "doc:readme")
        store.add_tuple("alice", "member", "group:eng")
        assert store.check("alice", "editor", "doc:readme") is True

    def test_non_member_does_not_inherit_relation(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:eng#member", "editor", "doc:readme")
        store.add_tuple("alice", "member", "group:eng")
        assert store.check("bob", "editor", "doc:readme") is False

    def test_group_relation_combined_with_rule_implication(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:admins#member", "owner", "doc:readme")
        store.add_tuple("alice", "member", "group:admins")
        store.add_rule("owner", "editor")
        assert store.check("alice", "editor", "doc:readme") is True

    def test_multiple_groups_independent(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:eng#member", "editor", "doc:readme")
        store.add_tuple("group:ops#member", "viewer", "doc:readme")
        store.add_tuple("alice", "member", "group:eng")
        store.add_tuple("bob", "member", "group:ops")
        assert store.check("alice", "editor", "doc:readme") is True
        assert store.check("bob", "viewer", "doc:readme") is True
        assert store.check("alice", "viewer", "doc:readme") is False
        assert store.check("bob", "editor", "doc:readme") is False

# ---------------------------------------------------------------------------
# check - nested group membership
# ---------------------------------------------------------------------------

class TestCheckNestedGroupMembership:
    def test_nested_group_member_inherits_relation(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:eng#member", "editor", "doc:readme")
        store.add_tuple("group:backend#member", "member", "group:eng")
        store.add_tuple("alice", "member", "group:backend")
        assert store.check("alice", "editor", "doc:readme") is True

    def test_nested_group_non_member_does_not_inherit(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:eng#member", "editor", "doc:readme")
        store.add_tuple("group:backend#member", "member", "group:eng")
        store.add_tuple("alice", "member", "group:backend")
        assert store.check("bob", "editor", "doc:readme") is False

    def test_cyclic_group_membership_does_not_infinite_loop(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:a#member", "editor", "doc:readme")
        store.add_tuple("group:b#member", "member", "group:a")
        store.add_tuple("group:a#member", "member", "group:b")
        result = store.check("alice", "editor", "doc:readme")
        assert result is False

    def test_nested_group_combined_with_rule_implication(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:eng#member", "owner", "doc:readme")
        store.add_tuple("group:backend#member", "member", "group:eng")
        store.add_tuple("alice", "member", "group:backend")
        store.add_rule("owner", "viewer")
        assert store.check("alice", "viewer", "doc:readme") is True

# ---------------------------------------------------------------------------
# expand
# ---------------------------------------------------------------------------

class TestExpand:
    def test_expand_empty_when_no_tuples(self, zanzibar_module, store):
        _require(zanzibar_module)
        assert store.expand("viewer", "doc:readme") == []

    def test_expand_direct_users(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "viewer", "doc:readme")
        store.add_tuple("bob", "viewer", "doc:readme")
        result = store.expand("viewer", "doc:readme")
        assert set(result) == {"alice", "bob"}

    def test_expand_via_rule_implication(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_rule("owner", "viewer")
        result = store.expand("viewer", "doc:readme")
        assert "alice" in result

    def test_expand_transitive_chain(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_rule("owner", "editor")
        store.add_rule("editor", "viewer")
        result = store.expand("viewer", "doc:readme")
        assert "alice" in result

    def test_expand_resolves_group_members(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:eng#member", "viewer", "doc:readme")
        store.add_tuple("alice", "member", "group:eng")
        store.add_tuple("bob", "member", "group:eng")
        result = store.expand("viewer", "doc:readme")
        assert "alice" in result
        assert "bob" in result

    def test_expand_excludes_group_references(self, zanzibar_module, store):
        """Group reference strings are excluded from expand output for both
        flat and nested group resolution."""
        _require(zanzibar_module)
        # Flat group: group:eng -> alice
        store.add_tuple("group:eng#member", "viewer", "doc:readme")
        store.add_tuple("alice", "member", "group:eng")
        # Nested group: group:backend -> group:eng -> bob
        store.add_tuple("group:backend#member", "member", "group:eng")
        store.add_tuple("bob", "member", "group:backend")
        result = store.expand("viewer", "doc:readme")
        assert "alice" in result
        assert "bob" in result
        for entry in result:
            assert not entry.startswith("group:")

    def test_expand_deduplicates_users(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_tuple("alice", "editor", "doc:readme")
        store.add_rule("owner", "viewer")
        store.add_rule("editor", "viewer")
        result = store.expand("viewer", "doc:readme")
        assert result.count("alice") == 1

    def test_expand_scoped_to_object(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "viewer", "doc:readme")
        store.add_tuple("bob", "viewer", "doc:other")
        result = store.expand("viewer", "doc:readme")
        assert "alice" in result
        assert "bob" not in result

    def test_expand_cyclic_rules_terminate(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("alice", "owner", "doc:readme")
        store.add_rule("owner", "editor")
        store.add_rule("editor", "owner")
        result = store.expand("editor", "doc:readme")
        assert isinstance(result, list)
        assert "alice" in result

    def test_expand_group_combined_with_rule(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:admins#member", "owner", "doc:readme")
        store.add_tuple("alice", "member", "group:admins")
        store.add_rule("owner", "viewer")
        result = store.expand("viewer", "doc:readme")
        assert "alice" in result
        for entry in result:
            assert not entry.startswith("group:")

    def test_expand_resolves_nested_group_members(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:eng#member", "viewer", "doc:readme")
        store.add_tuple("group:backend#member", "member", "group:eng")
        store.add_tuple("alice", "member", "group:backend")
        result = store.expand("viewer", "doc:readme")
        assert "alice" in result

    def test_expand_cyclic_group_membership_terminates(self, zanzibar_module, store):
        _require(zanzibar_module)
        store.add_tuple("group:a#member", "viewer", "doc:readme")
        store.add_tuple("group:b#member", "member", "group:a")
        store.add_tuple("group:a#member", "member", "group:b")
        store.add_tuple("alice", "member", "group:a")
        result = store.expand("viewer", "doc:readme")
        assert isinstance(result, list)
        assert "alice" in result

# ---------------------------------------------------------------------------
# Persistence across instances
# ---------------------------------------------------------------------------

class TestPersistence:
    def test_tuples_persist_across_instances(self, zanzibar_module, tmp_path):
        _require(zanzibar_module)
        db_path = str(tmp_path / "z.db")
        s1 = zanzibar_module.ZanzibarStore(db_path)
        s1.add_tuple("alice", "owner", "doc:readme")
        s1.add_rule("owner", "editor")

        s2 = zanzibar_module.ZanzibarStore(db_path)
        assert s2.check("alice", "owner", "doc:readme") is True
        assert s2.check("alice", "editor", "doc:readme") is True