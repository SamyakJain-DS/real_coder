// Tests for the Theme Override Contract.
// All assertions go through `renderHtml`'s observable :root declarations,
// because the merged theme is not a directly exposed value.

import { describe, it, expect } from "vitest";
import { loadModule, defaultTheme } from "./helpers";

function rootDeclarations(html: string): Record<string, string> {
  const styleM = html.match(/<style[^>]*>([\s\S]*?)<\/style>/);
  if (!styleM) return {};
  const css = styleM[1];
  const rootM = css.match(/:root\s*\{([\s\S]*?)\}/);
  if (!rootM) return {};
  const out: Record<string, string> = {};
  const decls = rootM[1].split(";");
  for (const d of decls) {
    const trimmed = d.trim();
    if (!trimmed) continue;
    const colon = trimmed.indexOf(":");
    if (colon < 0) continue;
    const k = trimmed.slice(0, colon).trim();
    const v = trimmed.slice(colon + 1).trim();
    out[k] = v;
  }
  return out;
}

describe("Theme Override Contract", () => {
  it("T1: a present override key replaces the default value (Theme #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const deck = compiler.parse("# T\nbody");
      const html: string = compiler.renderHtml(deck, {
        accentColor: "#ff00ff",
      });
      const decls = rootDeclarations(html);
      if (decls["--accent-color"] !== "#ff00ff")
        throw new Error(`--accent-color: ${decls["--accent-color"]}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("T2: a missing override key falls back to the constructor default (Theme #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const dt = defaultTheme();
      const compiler = new mod.SlideDeckCompiler(dt);
      const deck = compiler.parse("# T\nbody");
      const html: string = compiler.renderHtml(deck, {
        accentColor: "#ff00ff",
      });
      const decls = rootDeclarations(html);
      if (decls["--font-family"] !== dt.fontFamily)
        throw new Error(`--font-family: ${decls["--font-family"]}`);
      if (decls["--background-color"] !== dt.backgroundColor)
        throw new Error(`--background-color: ${decls["--background-color"]}`);
      if (decls["--text-color"] !== dt.textColor)
        throw new Error(`--text-color: ${decls["--text-color"]}`);
      if (decls["--code-theme"] !== dt.codeTheme)
        throw new Error(`--code-theme: ${decls["--code-theme"]}`);
      if (decls["--slide-padding"] !== `${dt.slidePaddingPx}px`)
        throw new Error(`--slide-padding: ${decls["--slide-padding"]}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("T3: all six DeckTheme keys flow through to the rendered :root (Theme #3, Rendering #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const theme = {
        fontFamily: "Georgia",
        backgroundColor: "#101010",
        textColor: "#f0f0f0",
        accentColor: "#00ffaa",
        codeTheme: "monokai",
        slidePaddingPx: 48,
      };
      const compiler = new mod.SlideDeckCompiler(theme);
      const deck = compiler.parse("# T\nbody");
      const html: string = compiler.renderHtml(deck, {});
      const decls = rootDeclarations(html);
      const expected: Record<string, string> = {
        "--font-family": "Georgia",
        "--background-color": "#101010",
        "--text-color": "#f0f0f0",
        "--accent-color": "#00ffaa",
        "--code-theme": "monokai",
        "--slide-padding": "48px",
      };
      for (const [k, v] of Object.entries(expected)) {
        if (decls[k] !== v)
          throw new Error(`${k} expected ${v}, got ${decls[k]}`);
      }
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("T4: the same merged theme drives both HTML and PDF for the same deck (Theme #4)", async () => {
    // Observable consequence: changing the override for one render call must
    // produce different bytes from a render call with the original theme.
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody";
      const deck = compiler.parse(md);

      const htmlA: string = compiler.renderHtml(deck, {});
      const htmlB: string = compiler.renderHtml(deck, { accentColor: "#abcdef" });
      const declsA = rootDeclarations(htmlA);
      const declsB = rootDeclarations(htmlB);
      if (declsA["--accent-color"] === declsB["--accent-color"])
        throw new Error("HTML accent color did not change with override");

      const pdfA: Uint8Array = await compiler.renderPdf(deck, {}, md);
      const pdfB: Uint8Array = await compiler.renderPdf(
        deck,
        { accentColor: "#abcdef" },
        md,
      );
      if (pdfA.length === pdfB.length) {
        let same = true;
        for (let i = 0; i < pdfA.length; i++)
          if (pdfA[i] !== pdfB[i]) {
            same = false;
            break;
          }
        if (same) throw new Error("PDF bytes did not change with theme override");
      }
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});
