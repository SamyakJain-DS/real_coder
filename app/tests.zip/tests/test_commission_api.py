from decimal import Decimal

from conftest import create_commission, inlay_points, money, request_json, valid_commission


def test_create_commission_returns_all_fields_and_billing(api_base_url):
    """Creating a commission returns all submitted fields and computes billing correctly."""
    payload = valid_commission(
        agreedQuote=3199.99,
        depositPaid=1200.00,
        plannedSetCount=3,
        caseMaterial="leather",
    )

    status, body = request_json(api_base_url, "POST", "/api/commissions", payload)

    assert status == 201, body
    assert isinstance(body.get("id"), int)
    assert body["customerName"] == payload["customerName"]
    assert body["accountType"] == payload["accountType"]
    assert body["caseMaterial"] == "leather"
    assert body["plannedSetCount"] == 3
    assert money(body["agreedQuote"]) == money(payload["agreedQuote"])
    assert money(body["depositPaid"]) == money(payload["depositPaid"])
    assert money(body["billing"]["outstandingBalance"]) == money(
        money(payload["agreedQuote"]) - money(payload["depositPaid"])
    )
    assert money(body["billing"]["agreedQuote"]) == money(payload["agreedQuote"])
    assert money(body["billing"]["depositPaid"]) == money(payload["depositPaid"])
    assert isinstance(body.get("inlayPoints"), list)
    assert len(body["inlayPoints"]) == 24
    assert body.get("workshopSessions") == []


def test_create_commission_persists_twenty_four_inlay_points(api_base_url):
    """All 24 inlay points are persisted with id, pointNumber, color, and material."""
    status, body = request_json(api_base_url, "POST", "/api/commissions", valid_commission())

    assert status == 201, body
    points = sorted(body["inlayPoints"], key=lambda p: p["pointNumber"])
    assert [p["pointNumber"] for p in points] == list(range(1, 25))
    for point in points:
        assert isinstance(point.get("id"), int), "Each inlayPoint must include an id field"
        assert "color" in point
        assert "material" in point


def test_commission_is_retrievable_after_creation(api_base_url):
    """A commission can be retrieved by ID via GET with all top-level fields and billing."""
    created = create_commission(api_base_url, agreedQuote=4000.00, depositPaid=1500.00)

    status, detail = request_json(
        api_base_url, "GET", f"/api/commissions/{created['id']}"
    )

    assert status == 200, detail
    assert detail["id"] == created["id"]
    assert detail["customerName"] == created["customerName"]
    assert detail["accountType"] == created["accountType"]
    assert detail["caseMaterial"] == created["caseMaterial"]
    assert detail["plannedSetCount"] == created["plannedSetCount"]
    assert money(detail["agreedQuote"]) == money(4000.00)
    assert money(detail["depositPaid"]) == money(1500.00)
    assert len(detail["inlayPoints"]) == 24
    assert isinstance(detail.get("workshopSessions"), list)
    assert money(detail["billing"]["outstandingBalance"]) == money(2500.00)
    assert money(detail["billing"]["agreedQuote"]) == money(4000.00)
    assert money(detail["billing"]["depositPaid"]) == money(1500.00)


def test_commission_validates_blank_required_string_fields(api_base_url):
    """customerName, accountType, and caseMaterial must not be blank strings."""
    for field in ("customerName", "accountType", "caseMaterial"):
        status, body = request_json(
            api_base_url,
            "POST",
            "/api/commissions",
            valid_commission(**{field: ""}),
        )
        assert status == 400, f"Expected 400 for blank {field}, got {status}: {body}"
        assert body["status"] == 400
        assert body["error"] == "Bad Request"
        assert isinstance(body.get("messages"), list) and body["messages"], body


def test_commission_validates_negative_money_amounts(api_base_url):
    """agreedQuote and depositPaid must be non-negative."""
    for case in (
        valid_commission(agreedQuote=-0.01),
        valid_commission(depositPaid=-1),
    ):
        status, body = request_json(api_base_url, "POST", "/api/commissions", case)
        assert status == 400, body
        assert body["status"] == 400
        assert body["error"] == "Bad Request"
        assert isinstance(body.get("messages"), list) and body["messages"], body


def test_commission_validates_deposit_does_not_exceed_quote(api_base_url):
    """depositPaid greater than agreedQuote returns HTTP 400."""
    status, body = request_json(
        api_base_url,
        "POST",
        "/api/commissions",
        valid_commission(agreedQuote=100.00, depositPaid=100.01),
    )

    assert status == 400, body
    assert isinstance(body.get("messages"), list) and body["messages"], body


def test_commission_validates_planned_set_count_minimum(api_base_url):
    """plannedSetCount below 1 returns HTTP 400."""
    for count in (0, -1):
        status, body = request_json(
            api_base_url,
            "POST",
            "/api/commissions",
            valid_commission(plannedSetCount=count),
        )
        assert status == 400, body
        assert isinstance(body.get("messages"), list) and body["messages"], body


def test_commission_validates_inlay_point_count(api_base_url):
    """Fewer or more than 24 inlay points returns HTTP 400."""
    for bad_points in (
        inlay_points()[:-1],                       # 23 points
        inlay_points() + inlay_points()[:1],       # 25 points
    ):
        status, body = request_json(
            api_base_url,
            "POST",
            "/api/commissions",
            valid_commission(inlayPoints=bad_points),
        )
        assert status == 400, body
        assert isinstance(body.get("messages"), list) and body["messages"], body


def test_commission_validates_inlay_point_uniqueness_and_range(api_base_url):
    """Duplicate pointNumbers or pointNumbers outside the valid range 1–24 return HTTP 400.
    Tests both the upper boundary (25) and the lower boundary (0)."""
    duplicate_points = inlay_points()
    duplicate_points[-1] = {"pointNumber": 1, "color": "red", "material": "jasper"}

    upper_bound_points = [
        {"pointNumber": n, "color": "ivory", "material": "holly"}
        for n in list(range(1, 24)) + [25]   # pointNumber 25 is above the maximum of 24
    ]

    lower_bound_points = [
        {"pointNumber": n, "color": "ivory", "material": "holly"}
        for n in [0] + list(range(2, 25))    # pointNumber 0 is below the minimum of 1
    ]

    for bad_points in (duplicate_points, upper_bound_points, lower_bound_points):
        status, body = request_json(
            api_base_url,
            "POST",
            "/api/commissions",
            valid_commission(inlayPoints=bad_points),
        )
        assert status == 400, body
        assert isinstance(body.get("messages"), list) and body["messages"], body


def test_commission_validation_collects_multiple_failures(api_base_url):
    """Multiple distinct validation failures are all returned in a single HTTP 400 response."""
    status, body = request_json(
        api_base_url,
        "POST",
        "/api/commissions",
        valid_commission(
            customerName="",
            agreedQuote=-1,
            plannedSetCount=0,
        ),
    )

    assert status == 400, body
    assert isinstance(body.get("messages"), list)
    assert len(body["messages"]) >= 3, (
        f"Expected at least 3 failure messages (blank customerName, negative agreedQuote, "
        f"plannedSetCount=0), got: {body['messages']}"
    )


def test_commission_accepts_zero_money_amounts(api_base_url):
    """agreedQuote=0 and depositPaid=0 are non-negative and must be accepted (HTTP 201).
    An implementation using > 0 instead of >= 0 would incorrectly reject them."""
    status, body = request_json(
        api_base_url,
        "POST",
        "/api/commissions",
        valid_commission(agreedQuote=0.00, depositPaid=0.00),
    )

    assert status == 201, body
    assert money(body["billing"]["outstandingBalance"]) == money(0.00)


def test_get_unknown_commission_returns_not_found(api_base_url):
    """GET /api/commissions/{id} with an unknown id returns HTTP 404 with ErrorResponse
    containing exactly one not-found message."""
    status, body = request_json(api_base_url, "GET", "/api/commissions/99999999")

    assert status == 404, body
    assert body["status"] == 404
    assert body["error"] == "Not Found"
    assert isinstance(body.get("messages"), list) and body["messages"], body
    assert len(body["messages"]) == 1, (
        f"404 ErrorResponse must contain exactly one message, got: {body['messages']}"
    )


def test_billing_outstanding_balance_applies_half_up_rounding(api_base_url):
    """outstandingBalance is rounded to 2 decimal places using half-up rounding.
    agreedQuote=100.015, depositPaid=0.010 -> difference=100.005:
    HALF_UP yields 100.01; HALF_EVEN (banker's rounding) would yield 100.00."""
    status, body = request_json(
        api_base_url,
        "POST",
        "/api/commissions",
        valid_commission(agreedQuote=100.015, depositPaid=0.010),
    )

    assert status == 201, body
    actual = Decimal(str(body["billing"]["outstandingBalance"]))
    assert actual == Decimal("100.01"), (
        f"Expected 100.01 (half-up rounding of 100.005), got {actual}"
    )


def test_create_commission_validates_absent_required_fields(api_base_url):
    """Omitting any required field entirely from the JSON payload returns HTTP 400,
    not a 500 server error from an unhandled null reference."""
    base = valid_commission()

    for field in (
        "customerName",
        "accountType",
        "caseMaterial",
        "agreedQuote",
        "depositPaid",
        "plannedSetCount",
        "inlayPoints",
    ):
        payload = {k: v for k, v in base.items() if k != field}
        status, body = request_json(api_base_url, "POST", "/api/commissions", payload)
        assert status == 400, (
            f"Expected 400 when '{field}' is absent, got {status}: {body}"
        )
        assert isinstance(body.get("messages"), list) and body["messages"], body


def test_commission_accepts_deposit_equal_to_agreed_quote(api_base_url):
    """depositPaid exactly equal to agreedQuote is valid (prompt forbids only
    'greater than', not 'equal to'). outstandingBalance must be 0.00."""
    status, body = request_json(
        api_base_url,
        "POST",
        "/api/commissions",
        valid_commission(agreedQuote=500.00, depositPaid=500.00),
    )

    assert status == 201, body
    assert money(body["billing"]["outstandingBalance"]) == money(0.00)


def test_billing_half_up_rounding_consistent_across_get_and_summary(api_base_url):
    """Half-up rounding on outstandingBalance applies consistently to the GET
    commission detail and production summary responses, not only on creation."""
    commission = create_commission(api_base_url, agreedQuote=100.015, depositPaid=0.010)

    status, detail = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}"
    )
    assert status == 200, detail
    assert Decimal(str(detail["billing"]["outstandingBalance"])) == Decimal("100.01"), (
        f"GET commission: expected 100.01 (half-up), got {detail['billing']['outstandingBalance']}"
    )

    status, summary = request_json(
        api_base_url, "GET", f"/api/commissions/{commission['id']}/production-summary"
    )
    assert status == 200, summary
    assert Decimal(str(summary["billing"]["outstandingBalance"])) == Decimal("100.01"), (
        f"Production summary: expected 100.01 (half-up), got {summary['billing']['outstandingBalance']}"
    )
