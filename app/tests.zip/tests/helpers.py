def _fixed(value, length, label):
    if not isinstance(value, str):
        raise TypeError(f"{label} must be str, got {type(value).__name__}")
    if len(value) != length:
        raise AssertionError(
            f"{label} must be {length} chars, got {len(value)}: {value!r}"
        )
    return value


def _zpad(value, length):
    if isinstance(value, int):
        return str(value).rjust(length, "0")
    return value


# ---------------------------------------------------------------------------
# Single-record line builders
# ---------------------------------------------------------------------------

def file_header_line(
    priority_code="01",
    immediate_destination=" 071000000",
    immediate_origin=" 071000001",
    file_creation_date="240115",
    file_creation_time="0900",
    file_id_modifier="A",
    record_size="094",
    blocking_factor="10",
    format_code="1",
    immediate_destination_name="BANK NAME              ",
    immediate_origin_name="COMPANY NAME           ",
    reference_code="        ",
):
    line = (
        "1"
        + _fixed(priority_code, 2, "priority_code")
        + _fixed(immediate_destination, 10, "immediate_destination")
        + _fixed(immediate_origin, 10, "immediate_origin")
        + _fixed(file_creation_date, 6, "file_creation_date")
        + _fixed(file_creation_time, 4, "file_creation_time")
        + _fixed(file_id_modifier, 1, "file_id_modifier")
        + _fixed(record_size, 3, "record_size")
        + _fixed(blocking_factor, 2, "blocking_factor")
        + _fixed(format_code, 1, "format_code")
        + _fixed(immediate_destination_name, 23, "immediate_destination_name")
        + _fixed(immediate_origin_name, 23, "immediate_origin_name")
        + _fixed(reference_code, 8, "reference_code")
    )
    assert len(line) == 94, f"file_header_line: {len(line)}"
    return line


def batch_header_line(
    service_class_code="200",
    company_name="COMPANY NAME    ",
    company_discretionary_data="                    ",
    company_identification="1234567890",
    sec_code="PPD",
    company_entry_description="PAYROLL   ",
    company_descriptive_date="240115",
    effective_entry_date="240116",
    settlement_date="   ",
    originator_status_code="1",
    originating_dfi_identification="07100000",
    batch_number="0000001",
):
    line = (
        "5"
        + _fixed(service_class_code, 3, "service_class_code")
        + _fixed(company_name, 16, "company_name")
        + _fixed(company_discretionary_data, 20, "company_discretionary_data")
        + _fixed(company_identification, 10, "company_identification")
        + _fixed(sec_code, 3, "sec_code")
        + _fixed(company_entry_description, 10, "company_entry_description")
        + _fixed(company_descriptive_date, 6, "company_descriptive_date")
        + _fixed(effective_entry_date, 6, "effective_entry_date")
        + _fixed(settlement_date, 3, "settlement_date")
        + _fixed(originator_status_code, 1, "originator_status_code")
        + _fixed(originating_dfi_identification, 8, "originating_dfi_identification")
        + _fixed(batch_number, 7, "batch_number")
    )
    assert len(line) == 94, f"batch_header_line: {len(line)}"
    return line


def entry_detail_line(
    transaction_code="22",
    receiving_dfi_identification="07100000",
    check_digit="0",
    dfi_account_number="ACCT123456789    ",
    amount=10000,
    individual_identification_number="ID12345        ",
    individual_name="JOHN DOE              ",
    discretionary_data="  ",
    addenda_record_indicator="0",
    trace_number="071000000000001",
):
    amount_str = _zpad(amount, 10)
    line = (
        "6"
        + _fixed(transaction_code, 2, "transaction_code")
        + _fixed(receiving_dfi_identification, 8, "receiving_dfi_identification")
        + _fixed(check_digit, 1, "check_digit")
        + _fixed(dfi_account_number, 17, "dfi_account_number")
        + _fixed(amount_str, 10, "amount")
        + _fixed(individual_identification_number, 15, "individual_identification_number")
        + _fixed(individual_name, 22, "individual_name")
        + _fixed(discretionary_data, 2, "discretionary_data")
        + _fixed(addenda_record_indicator, 1, "addenda_record_indicator")
        + _fixed(trace_number, 15, "trace_number")
    )
    assert len(line) == 94, f"entry_detail_line: {len(line)}"
    return line


def addenda_line(
    addenda_type_code="05",
    payload=None,
    addenda_sequence_number="0001",
    entry_detail_sequence_number="0000001",
):
    if payload is None:
        payload = " " * 80
    line = (
        "7"
        + _fixed(addenda_type_code, 2, "addenda_type_code")
        + _fixed(payload, 80, "payload")
        + _fixed(addenda_sequence_number, 4, "addenda_sequence_number")
        + _fixed(entry_detail_sequence_number, 7, "entry_detail_sequence_number")
    )
    assert len(line) == 94, f"addenda_line: {len(line)}"
    return line


def batch_control_line(
    service_class_code="200",
    entry_addenda_count=1,
    entry_hash=7100000,
    total_debit=0,
    total_credit=10000,
    company_identification="1234567890",
    message_authentication_code="                   ",
    reserved="      ",
    originating_dfi_identification="07100000",
    batch_number="0000001",
):
    eac = _zpad(entry_addenda_count, 6)
    if isinstance(entry_hash, int):
        eh = str(entry_hash % 10**10).rjust(10, "0")
    else:
        eh = entry_hash
    td = _zpad(total_debit, 12)
    tc = _zpad(total_credit, 12)
    line = (
        "8"
        + _fixed(service_class_code, 3, "service_class_code")
        + _fixed(eac, 6, "entry_addenda_count")
        + _fixed(eh, 10, "entry_hash")
        + _fixed(td, 12, "total_debit")
        + _fixed(tc, 12, "total_credit")
        + _fixed(company_identification, 10, "company_identification")
        + _fixed(message_authentication_code, 19, "message_authentication_code")
        + _fixed(reserved, 6, "reserved")
        + _fixed(originating_dfi_identification, 8, "originating_dfi_identification")
        + _fixed(batch_number, 7, "batch_number")
    )
    assert len(line) == 94, f"batch_control_line: {len(line)}"
    return line


def file_control_line(
    batch_count=1,
    block_count=1,
    entry_addenda_count=1,
    entry_hash=7100000,
    total_debit=0,
    total_credit=10000,
    reserved=None,
):
    if reserved is None:
        reserved = " " * 39
    bc = _zpad(batch_count, 6)
    blc = _zpad(block_count, 6)
    eac = _zpad(entry_addenda_count, 8)
    if isinstance(entry_hash, int):
        eh = str(entry_hash % 10**10).rjust(10, "0")
    else:
        eh = entry_hash
    td = _zpad(total_debit, 12)
    tc = _zpad(total_credit, 12)
    line = (
        "9"
        + _fixed(bc, 6, "batch_count")
        + _fixed(blc, 6, "block_count")
        + _fixed(eac, 8, "entry_addenda_count")
        + _fixed(eh, 10, "entry_hash")
        + _fixed(td, 12, "total_debit")
        + _fixed(tc, 12, "total_credit")
        + _fixed(reserved, 39, "reserved")
    )
    assert len(line) == 94, f"file_control_line: {len(line)}"
    return line


def padding_line():
    return "9" * 94


# ---------------------------------------------------------------------------
# Aggregate helpers
# ---------------------------------------------------------------------------

DEBIT_CODES = {"27", "28", "37", "38"}
CREDIT_CODES = {"22", "23", "32", "33"}


def entry_hash_for(routing_prefixes):
    """Compute the NACHA entry hash from 8-digit RDFI routing prefixes."""
    total = sum(int(p) for p in routing_prefixes)
    return total % 10**10


def build_batch_lines(
    entries,
    sec_code="PPD",
    service_class_code="200",
    company_identification="1234567890",
    originating_dfi="07100000",
    batch_number=1,
    control_overrides=None,
):
    """Build all lines for a batch and return them as a list.

    `entries` is a list of dicts with keys:
        rdfi_routing (8 chars), check_digit (1 char), transaction_code (2),
        amount (int cents), addenda (optional list of (type_code, payload_str)),
        addenda_indicator (optional '0' or '1'; auto-derived from addenda len)
    `control_overrides` lets a caller force-set values on the batch control
    line (e.g. to inject a deliberately wrong count for validation tests).
    """
    bnum = str(batch_number).rjust(7, "0")
    lines = [batch_header_line(
        service_class_code=service_class_code,
        company_identification=company_identification,
        sec_code=sec_code,
        originating_dfi_identification=originating_dfi,
        batch_number=bnum,
    )]
    routing_prefixes = []
    total_debit = 0
    total_credit = 0
    count = 0
    for i, e in enumerate(entries, start=1):
        addenda_specs = e.get("addenda", [])
        ind = e.get("addenda_indicator")
        if ind is None:
            ind = "1" if addenda_specs else "0"
        trace = originating_dfi + str(i).rjust(7, "0")
        edl = entry_detail_line(
            transaction_code=e.get("transaction_code", "22"),
            receiving_dfi_identification=e["rdfi_routing"],
            check_digit=e.get("check_digit", "0"),
            amount=e.get("amount", 0),
            addenda_record_indicator=ind,
            trace_number=trace,
        )
        lines.append(edl)
        routing_prefixes.append(e["rdfi_routing"])
        tc = e.get("transaction_code", "22")
        if tc in DEBIT_CODES:
            total_debit += e.get("amount", 0)
        elif tc in CREDIT_CODES:
            total_credit += e.get("amount", 0)
        count += 1
        for seq, spec in enumerate(addenda_specs, start=1):
            type_code, payload = spec
            adl = addenda_line(
                addenda_type_code=type_code,
                payload=payload.ljust(80, " ")[:80],
                addenda_sequence_number=str(seq).rjust(4, "0"),
                entry_detail_sequence_number=str(i).rjust(7, "0"),
            )
            lines.append(adl)
            count += 1
    ctrl_kwargs = dict(
        service_class_code=service_class_code,
        entry_addenda_count=count,
        entry_hash=entry_hash_for(routing_prefixes),
        total_debit=total_debit,
        total_credit=total_credit,
        company_identification=company_identification,
        originating_dfi_identification=originating_dfi,
        batch_number=bnum,
    )
    if control_overrides:
        ctrl_kwargs.update(control_overrides)
    lines.append(batch_control_line(**ctrl_kwargs))
    return lines, routing_prefixes, total_debit, total_credit, count


def build_file_text(
    batches,
    line_terminator="\n",
    pad_to_block=True,
    trailing_terminator=True,
    file_header_overrides=None,
    file_control_overrides=None,
):
    """Build a full NACHA file as a single text string.

    `batches` is a list of dicts passed to build_batch_lines (less the
    `batch_number` which is filled in automatically).
    """
    fh_kwargs = file_header_overrides or {}
    lines = [file_header_line(**fh_kwargs)]
    all_routing_prefixes = []
    total_debit_all = 0
    total_credit_all = 0
    total_count = 0
    for i, b in enumerate(batches, start=1):
        b_copy = dict(b)
        b_copy.setdefault("batch_number", i)
        batch_lines, rps, td, tc, cnt = build_batch_lines(**b_copy)
        lines.extend(batch_lines)
        all_routing_prefixes.extend(rps)
        total_debit_all += td
        total_credit_all += tc
        total_count += cnt
    # File control: count lines so far + 1 file control line; padding rounds up.
    n_records = len(lines) + 1
    if pad_to_block:
        rem = n_records % 10
        padding_count = (10 - rem) if rem else 0
    else:
        padding_count = 0
    block_count_value = (n_records + padding_count) // 10 if pad_to_block else 0
    if not pad_to_block:
        # When the file is not padded, set block count to ceil(n_records / 10).
        block_count_value = (n_records + 9) // 10
    fc_kwargs = dict(
        batch_count=len(batches),
        block_count=block_count_value,
        entry_addenda_count=total_count,
        entry_hash=entry_hash_for(all_routing_prefixes),
        total_debit=total_debit_all,
        total_credit=total_credit_all,
    )
    if file_control_overrides:
        fc_kwargs.update(file_control_overrides)
    lines.append(file_control_line(**fc_kwargs))
    for _ in range(padding_count):
        lines.append(padding_line())
    text = line_terminator.join(lines)
    if trailing_terminator:
        text += line_terminator
    return text


# ---------------------------------------------------------------------------
# Per-SEC-code addenda helpers
# ---------------------------------------------------------------------------

IAT_REQUIRED_TYPES = ("10", "11", "12", "13", "14", "15", "16")


def make_iat_addenda(extra=()):
    """Build the 7 mandatory IAT addenda + optional ('17',) or ('17','18')."""
    result = [(t, " ") for t in IAT_REQUIRED_TYPES]
    for t in extra:
        result.append((t, " "))
    return result


def simple_credit_entry(amount=10000, rdfi_routing="07100000", check_digit="0"):
    return dict(
        rdfi_routing=rdfi_routing,
        check_digit=check_digit,
        transaction_code="22",
        amount=amount,
    )


def simple_debit_entry(amount=5000, rdfi_routing="07200001", check_digit="1"):
    return dict(
        rdfi_routing=rdfi_routing,
        check_digit=check_digit,
        transaction_code="27",
        amount=amount,
    )
