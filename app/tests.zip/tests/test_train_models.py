import os
import sys
import pytest
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

try:
    from sklearn.pipeline import Pipeline as SklearnPipeline
except ImportError:
    SklearnPipeline = None


def _load(sample_data_dir):
    from pipeline import load_and_validate
    return load_and_validate(sample_data_dir)


def _features(sample_data_dir):
    from pipeline import engineer_features
    return engineer_features(_load(sample_data_dir))


def _models(sample_data_dir):
    from pipeline import train_models
    return train_models(_features(sample_data_dir))


# ---------------------------------------------------------------------------
# Return structure
# ---------------------------------------------------------------------------

class TestTrainModelsReturnStructure:
    """Tests the return structure of train_models - three-model architecture."""

    def test_returns_dict(self, sample_data_dir):
        result = _models(sample_data_dir)
        assert isinstance(result, dict)

    def test_has_craftsmanship_model_key(self, sample_data_dir):
        assert "craftsmanship_model" in _models(sample_data_dir)

    def test_has_subgrade_model_key(self, sample_data_dir):
        assert "subgrade_model" in _models(sample_data_dir)

    def test_has_combined_model_key(self, sample_data_dir):
        assert "combined_model" in _models(sample_data_dir)

    def test_has_craftsmanship_metrics_key(self, sample_data_dir):
        assert "craftsmanship_metrics" in _models(sample_data_dir)

    def test_has_subgrade_metrics_key(self, sample_data_dir):
        assert "subgrade_metrics" in _models(sample_data_dir)

    def test_has_combined_metrics_key(self, sample_data_dir):
        assert "combined_metrics" in _models(sample_data_dir)

    def test_has_roc_auc_delta_combined_vs_craft_key(self, sample_data_dir):
        assert "roc_auc_delta_combined_vs_craft" in _models(sample_data_dir)

    def test_has_roc_auc_delta_combined_vs_subgrade_key(self, sample_data_dir):
        assert "roc_auc_delta_combined_vs_subgrade" in _models(sample_data_dir)

    def test_has_roc_auc_delta_subgrade_vs_craft_key(self, sample_data_dir):
        assert "roc_auc_delta_subgrade_vs_craft" in _models(sample_data_dir)

    def test_has_eval_predictions_key(self, sample_data_dir):
        assert "eval_predictions" in _models(sample_data_dir)

    def test_has_feature_names_key(self, sample_data_dir):
        assert "feature_names" in _models(sample_data_dir)

    def test_has_craftsmanship_feature_names_key(self, sample_data_dir):
        assert "craftsmanship_feature_names" in _models(sample_data_dir)

    def test_has_subgrade_feature_names_key(self, sample_data_dir):
        assert "subgrade_feature_names" in _models(sample_data_dir)


# ---------------------------------------------------------------------------
# Model pipeline objects
# ---------------------------------------------------------------------------

class TestModelPipelines:
    """Tests that all three models are proper sklearn Pipelines with imputation."""

    def test_craftsmanship_model_is_pipeline(self, sample_data_dir):
        model = _models(sample_data_dir)["craftsmanship_model"]
        if SklearnPipeline is not None:
            assert isinstance(model, SklearnPipeline)

    def test_subgrade_model_is_pipeline(self, sample_data_dir):
        model = _models(sample_data_dir)["subgrade_model"]
        if SklearnPipeline is not None:
            assert isinstance(model, SklearnPipeline)

    def test_combined_model_is_pipeline(self, sample_data_dir):
        model = _models(sample_data_dir)["combined_model"]
        if SklearnPipeline is not None:
            assert isinstance(model, SklearnPipeline)

    def test_craftsmanship_pipeline_handles_nan_input(self, sample_data_dir):
        """Pipeline must handle NaN without error and use -9999 as the sentinel value."""
        feature_df = _features(sample_data_dir)
        model_results = _models(sample_data_dir)
        model = model_results["craftsmanship_model"]
        craft_features = model_results["craftsmanship_feature_names"]
        available = [f for f in craft_features if f in feature_df.columns]
        X_sample = feature_df[available].head(3).copy()
        X_sample.iloc[0, 0] = np.nan
        probs = model.predict_proba(X_sample)
        assert probs.shape[0] == len(X_sample)
        # Verify the imputer uses the required -9999 sentinel
        imputer = model.steps[0][1]
        assert hasattr(imputer, "fill_value"), "First pipeline step must be a constant imputer"
        assert imputer.fill_value == -9999,             f"Imputer sentinel must be -9999, got {imputer.fill_value}"

    def test_subgrade_pipeline_handles_nan_input(self, sample_data_dir):
        """Subgrade pipeline must handle NaN without error and use -9999 as the sentinel value."""
        feature_df = _features(sample_data_dir)
        model_results = _models(sample_data_dir)
        model = model_results["subgrade_model"]
        subgrade_features = model_results["subgrade_feature_names"]
        available = [f for f in subgrade_features if f in feature_df.columns]
        X_sample = feature_df[available].head(3).copy()
        X_sample.iloc[0, 0] = np.nan
        probs = model.predict_proba(X_sample)
        assert probs.shape[0] == len(X_sample)
        imputer = model.steps[0][1]
        assert hasattr(imputer, "fill_value"), "First pipeline step must be a constant imputer"
        assert imputer.fill_value == -9999,             f"Imputer sentinel must be -9999, got {imputer.fill_value}"

    def test_combined_pipeline_handles_nan_input(self, sample_data_dir):
        """Combined pipeline must handle NaN without error and use -9999 as the sentinel value."""
        feature_df = _features(sample_data_dir)
        model_results = _models(sample_data_dir)
        model = model_results["combined_model"]
        feature_names = model_results["feature_names"]
        X_sample = feature_df[feature_names].head(3).copy()
        X_sample.iloc[0, 0] = np.nan
        probs = model.predict_proba(X_sample)
        assert probs.shape[0] == len(X_sample)
        imputer = model.steps[0][1]
        assert hasattr(imputer, "fill_value"), "First pipeline step must be a constant imputer"
        assert imputer.fill_value == -9999,             f"Imputer sentinel must be -9999, got {imputer.fill_value}"

    def test_all_models_can_predict_probabilities(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        model_results = _models(sample_data_dir)
        for model_key, feature_key in [
            ("craftsmanship_model", "craftsmanship_feature_names"),
            ("subgrade_model", "subgrade_feature_names"),
            ("combined_model", "feature_names"),
        ]:
            model = model_results[model_key]
            names = model_results[feature_key]
            X = feature_df[names].head(5)
            probs = model.predict_proba(X)
            assert probs.shape[0] == 5
            assert probs.shape[1] == 2


# ---------------------------------------------------------------------------
# Metrics dictionaries - all three models
# ---------------------------------------------------------------------------

class TestMetricsDictionaries:
    """Tests for the contents of all three metrics dictionaries."""

    @pytest.mark.parametrize("metrics_key", [
        "craftsmanship_metrics", "subgrade_metrics", "combined_metrics"
    ])
    def test_metrics_has_accuracy(self, sample_data_dir, metrics_key):
        assert "accuracy" in _models(sample_data_dir)[metrics_key]

    @pytest.mark.parametrize("metrics_key", [
        "craftsmanship_metrics", "subgrade_metrics", "combined_metrics"
    ])
    def test_metrics_has_precision(self, sample_data_dir, metrics_key):
        assert "precision" in _models(sample_data_dir)[metrics_key]

    @pytest.mark.parametrize("metrics_key", [
        "craftsmanship_metrics", "subgrade_metrics", "combined_metrics"
    ])
    def test_metrics_has_recall(self, sample_data_dir, metrics_key):
        assert "recall" in _models(sample_data_dir)[metrics_key]

    @pytest.mark.parametrize("metrics_key", [
        "craftsmanship_metrics", "subgrade_metrics", "combined_metrics"
    ])
    def test_metrics_has_f1(self, sample_data_dir, metrics_key):
        assert "f1" in _models(sample_data_dir)[metrics_key]

    @pytest.mark.parametrize("metrics_key", [
        "craftsmanship_metrics", "subgrade_metrics", "combined_metrics"
    ])
    def test_metrics_has_roc_auc(self, sample_data_dir, metrics_key):
        assert "roc_auc" in _models(sample_data_dir)[metrics_key]

    @pytest.mark.parametrize("metrics_key", [
        "craftsmanship_metrics", "subgrade_metrics", "combined_metrics"
    ])
    def test_metrics_has_cv_roc_auc_mean(self, sample_data_dir, metrics_key):
        assert "cv_roc_auc_mean" in _models(sample_data_dir)[metrics_key]

    @pytest.mark.parametrize("metrics_key", [
        "craftsmanship_metrics", "subgrade_metrics", "combined_metrics"
    ])
    def test_metrics_values_are_numeric(self, sample_data_dir, metrics_key):
        model_results = _models(sample_data_dir)
        for key, value in model_results[metrics_key].items():
            assert isinstance(value, (int, float, np.floating)), \
                f"{metrics_key}[{key}] should be numeric, got {type(value)}"

    @pytest.mark.parametrize("metrics_key", [
        "craftsmanship_metrics", "subgrade_metrics", "combined_metrics"
    ])
    def test_accuracy_in_valid_range(self, sample_data_dir, metrics_key):
        acc = _models(sample_data_dir)[metrics_key]["accuracy"]
        assert 0.0 <= acc <= 1.0

    @pytest.mark.parametrize("metrics_key", [
        "craftsmanship_metrics", "subgrade_metrics", "combined_metrics"
    ])
    def test_roc_auc_in_valid_range(self, sample_data_dir, metrics_key):
        auc = _models(sample_data_dir)[metrics_key]["roc_auc"]
        assert 0.0 <= auc <= 1.0


# ---------------------------------------------------------------------------
# Three pairwise ROC-AUC deltas
# ---------------------------------------------------------------------------

class TestThreeModelPairwiseDeltas:
    """Tests for the three pairwise ROC-AUC deltas required by the prompt."""

    @pytest.mark.parametrize("delta_key", [
        "roc_auc_delta_combined_vs_craft",
        "roc_auc_delta_combined_vs_subgrade",
        "roc_auc_delta_subgrade_vs_craft",
    ])
    def test_delta_is_numeric(self, sample_data_dir, delta_key):
        delta = _models(sample_data_dir)[delta_key]
        assert isinstance(delta, (int, float, np.floating))

    def test_combined_vs_craft_delta_equals_difference(self, sample_data_dir):
        model_results = _models(sample_data_dir)
        combined_auc = model_results["combined_metrics"]["roc_auc"]
        craft_auc = model_results["craftsmanship_metrics"]["roc_auc"]
        expected = combined_auc - craft_auc
        actual = model_results["roc_auc_delta_combined_vs_craft"]
        assert abs(actual - expected) < 1e-6

    def test_combined_vs_subgrade_delta_equals_difference(self, sample_data_dir):
        model_results = _models(sample_data_dir)
        combined_auc = model_results["combined_metrics"]["roc_auc"]
        subgrade_auc = model_results["subgrade_metrics"]["roc_auc"]
        expected = combined_auc - subgrade_auc
        actual = model_results["roc_auc_delta_combined_vs_subgrade"]
        assert abs(actual - expected) < 1e-6

    def test_subgrade_vs_craft_delta_equals_difference(self, sample_data_dir):
        model_results = _models(sample_data_dir)
        subgrade_auc = model_results["subgrade_metrics"]["roc_auc"]
        craft_auc = model_results["craftsmanship_metrics"]["roc_auc"]
        expected = subgrade_auc - craft_auc
        actual = model_results["roc_auc_delta_subgrade_vs_craft"]
        assert abs(actual - expected) < 1e-6


# ---------------------------------------------------------------------------
# eval_predictions - three prediction columns
# ---------------------------------------------------------------------------

class TestEvalPredictions:
    """Tests for the eval_predictions DataFrame - must carry all three model scores."""

    def test_eval_predictions_is_dataframe(self, sample_data_dir):
        assert isinstance(_models(sample_data_dir)["eval_predictions"], pd.DataFrame)

    def test_eval_predictions_has_combined_predicted_risk(self, sample_data_dir):
        assert "combined_predicted_risk" in _models(sample_data_dir)["eval_predictions"].columns

    def test_eval_predictions_has_craftsmanship_predicted_risk(self, sample_data_dir):
        assert "craftsmanship_predicted_risk" in _models(sample_data_dir)["eval_predictions"].columns

    def test_eval_predictions_has_subgrade_predicted_risk(self, sample_data_dir):
        assert "subgrade_predicted_risk" in _models(sample_data_dir)["eval_predictions"].columns

    @pytest.mark.parametrize("col", [
        "combined_predicted_risk", "craftsmanship_predicted_risk", "subgrade_predicted_risk"
    ])
    def test_predicted_risk_in_valid_range(self, sample_data_dir, col):
        preds = _models(sample_data_dir)["eval_predictions"][col]
        assert (preds >= 0.0).all() and (preds <= 1.0).all()

    def test_eval_predictions_size_is_20_percent(self, sample_data_dir):
        feature_df = _features(sample_data_dir)
        eval_size = len(_models(sample_data_dir)["eval_predictions"])
        expected_size = int(len(feature_df) * 0.2)
        assert abs(eval_size - expected_size) <= 1


# ---------------------------------------------------------------------------
# Feature name lists
# ---------------------------------------------------------------------------

class TestFeatureNames:
    """Tests for the three feature name lists."""

    def test_feature_names_is_list(self, sample_data_dir):
        assert isinstance(_models(sample_data_dir)["feature_names"], list)

    def test_craftsmanship_feature_names_is_list(self, sample_data_dir):
        assert isinstance(_models(sample_data_dir)["craftsmanship_feature_names"], list)

    def test_subgrade_feature_names_is_list(self, sample_data_dir):
        assert isinstance(_models(sample_data_dir)["subgrade_feature_names"], list)

    def test_feature_names_not_empty(self, sample_data_dir):
        assert len(_models(sample_data_dir)["feature_names"]) > 0

    def test_craftsmanship_feature_names_contains_all_10_features(self, sample_data_dir):
        """Craftsmanship Model must use ONLY the 10 specified per-permittee features."""
        names = _models(sample_data_dir)["craftsmanship_feature_names"]
        required = [
            "craft_backfill_rate", "craft_base_course_rate",
            "craft_surface_rate", "craft_overall_pass_rate",
            "total_fees_assessed", "avg_fee_per_permit",
            "fee_to_bond_ratio", "bond_claim_count",
            "bond_claim_rate", "avg_coordination_lead_days",
        ]
        for f in required:
            assert f in names, f"Craftsmanship model craftsmanship_feature_names must include {f}"
        assert len(names) == 10,             f"Craftsmanship model must use exactly 10 features (prompt says 'only'), got {len(names)}"

    def test_subgrade_feature_names_contains_all_5_features(self, sample_data_dir):
        """Subgrade-Only Model must use ONLY the 5 specified non-leaky subgrade features."""
        names = _models(sample_data_dir)["subgrade_feature_names"]
        required = [
            "cumulative_cut_density", "avg_pavement_age_at_cut",
            "recent_overlay_flag", "cut_density_trend_slope",
            "recent_year_cut_density",
        ]
        for f in required:
            assert f in names, f"Subgrade-Only model subgrade_feature_names must include {f}"
        assert len(names) == 5,             f"Subgrade-Only model must use exactly 5 features (prompt says 'only'), got {len(names)}"

    def test_feature_names_includes_craftsmanship_features(self, sample_data_dir):
        names = _models(sample_data_dir)["feature_names"]
        # All 10 per-permittee craftsmanship features must appear in the Combined Model
        craft_features = [
            "craft_backfill_rate", "craft_base_course_rate",
            "craft_surface_rate", "craft_overall_pass_rate",
            "total_fees_assessed", "avg_fee_per_permit",
            "fee_to_bond_ratio", "bond_claim_count",
            "bond_claim_rate", "avg_coordination_lead_days",
        ]
        for f in craft_features:
            assert f in names, f"Combined model feature_names must include {f}"

    def test_feature_names_includes_non_leaky_subgrade_features(self, sample_data_dir):
        """Combined model must include the non-leaky subgrade features."""
        names = _models(sample_data_dir)["feature_names"]
        non_leaky_subgrade = ["cumulative_cut_density", "avg_pavement_age_at_cut",
                              "recent_overlay_flag", "cut_density_trend_slope",
                              "recent_year_cut_density"]
        for f in non_leaky_subgrade:
            assert f in names, f"Combined model feature_names should include non-leaky subgrade feature {f}"

    def test_leaky_features_not_in_combined_model_features(self, sample_data_dir):
        """segment_failure_rate, failure_rate_trend_slope, recent_year_failure_rate
        are leaky (target-derived) and must be excluded from all model feature sets."""
        names = _models(sample_data_dir)["feature_names"]
        leaky = ["segment_failure_rate", "failure_rate_trend_slope", "recent_year_failure_rate"]
        for f in leaky:
            assert f not in names, \
                f"Leaky feature {f} must not appear in Combined Model feature_names"

    def test_leaky_features_not_in_subgrade_model_features(self, sample_data_dir):
        names = _models(sample_data_dir)["subgrade_feature_names"]
        leaky = ["segment_failure_rate", "failure_rate_trend_slope", "recent_year_failure_rate"]
        for f in leaky:
            assert f not in names, \
                f"Leaky feature {f} must not appear in Subgrade Model feature_names"

    def test_combined_model_uses_more_features_than_craftsmanship(self, sample_data_dir):
        model_results = _models(sample_data_dir)
        craft_names = model_results["craftsmanship_feature_names"]
        combined_names = model_results["feature_names"]
        assert len(combined_names) > len(craft_names), \
            "Combined model should use more features than the Craftsmanship model"

    def test_subgrade_model_uses_fewer_features_than_combined(self, sample_data_dir):
        model_results = _models(sample_data_dir)
        subgrade_names = model_results["subgrade_feature_names"]
        combined_names = model_results["feature_names"]
        assert len(combined_names) > len(subgrade_names), \
            "Combined model should use more features than the Subgrade-Only model"


class TestCombinedModelPermitLevelFeatures:
    """Verify the Combined Model's feature_names includes all non-leaky permit-level
    derived columns, traffic_control_plan_adequate, and one-hot encoded columns.
    Prompt: 'Combined Model: uses all non-leaky features - craftsmanship, subgrade,
    permit-level derived, and categorical - as predictors.'
    """

    def test_combined_model_includes_all_permit_level_derived_columns(self, sample_data_dir):
        """The 7 permit-level derived columns must appear in feature_names."""
        from pipeline import load_and_validate, engineer_features, train_models
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        model_results = train_models(feature_df)
        names = model_results["feature_names"]

        permit_derived = [
            "pavement_age_at_cut_days", "warranty_overlap", "warranty_remaining_days",
            "moratorium_violated", "has_overlay", "days_since_overlay", "coordination_lead_days",
        ]
        for col in permit_derived:
            assert col in names, (
                f"Combined model feature_names must include permit-level derived column '{col}'"
            )

    def test_combined_model_includes_traffic_control_and_ohe_columns(self, sample_data_dir):
        """traffic_control_plan_adequate and at least one column per OHE group must be
        in feature_names. Prompt: 'traffic_control_plan_adequate ... one-hot encoded
        columns for excavation_purpose, restoration_scope, and permittee_type.'"""
        from pipeline import load_and_validate, engineer_features, train_models
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        model_results = train_models(feature_df)
        names = model_results["feature_names"]

        assert "traffic_control_plan_adequate" in names, \
            "Combined model feature_names must include traffic_control_plan_adequate"

        assert any(c.startswith("excavation_purpose_") for c in names), \
            "Combined model feature_names must include at least one excavation_purpose_ OHE column"
        assert any(c.startswith("restoration_scope_") for c in names), \
            "Combined model feature_names must include at least one restoration_scope_ OHE column"
        assert any(c.startswith("permittee_type_") for c in names), \
            "Combined model feature_names must include at least one permittee_type_ OHE column"


class TestModelDeterminism:
    """Verify train_models produces identical eval splits across runs, confirming
    the train_test_split uses a fixed random_state=42 as specified in the prompt."""

    def test_train_models_eval_split_is_deterministic(self, sample_data_dir):
        """Calling train_models twice on the same input must yield identical
        eval predictions, confirming a fixed random_state=42 is used.
        Prompt: 'Use an 80/20 train-evaluation split with a fixed random seed of 42
        for reproducibility.'"""
        from pipeline import load_and_validate, engineer_features, train_models
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)

        r1 = train_models(feature_df)
        r2 = train_models(feature_df)

        assert len(r1["eval_predictions"]) == len(r2["eval_predictions"]), \
            "Eval set size must be consistent across runs (fixed random_state=42)"

        preds1 = sorted(r1["eval_predictions"]["combined_predicted_risk"].tolist())
        preds2 = sorted(r2["eval_predictions"]["combined_predicted_risk"].tolist())
        for p1, p2 in zip(preds1, preds2):
            assert abs(p1 - p2) < 1e-10, (
                "Combined model predictions must be identical across runs - "
                "requires fixed random_state=42 in train_test_split"
            )


class TestImputerStrategy:
    """The SimpleImputer in each pipeline must use strategy='constant'.
    Prompt: 'each model pipeline must begin with a constant imputation preprocessing step
    using a SimpleImputer(strategy="constant", fill_value=-9999)'
    Existing tests assert fill_value == -9999 but not strategy == 'constant'.
    A SimpleImputer(strategy='mean') ignores fill_value, making this a distinct check.
    """

    @pytest.mark.parametrize("model_key", [
        "craftsmanship_model", "subgrade_model", "combined_model",
    ])
    def test_imputer_strategy_is_constant(self, sample_data_dir, model_key):
        """All three pipelines must use strategy='constant' for NaN-as-meaningful-absence
        sentinel imputation. strategy='mean' would silently replace NaN with feature means
        instead of the required -9999 sentinel."""
        from pipeline import load_and_validate, engineer_features, train_models
        datasets = load_and_validate(sample_data_dir)
        feature_df = engineer_features(datasets)
        model_results = train_models(feature_df)

        imputer = model_results[model_key].steps[0][1]
        assert imputer.strategy == "constant", (
            f"{model_key}: SimpleImputer strategy must be 'constant', got '{imputer.strategy}'. "
            f"strategy='mean' ignores fill_value and would use mean-imputation instead of "
            f"the required -9999 sentinel."
        )
