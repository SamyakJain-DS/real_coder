import pytest

from nacha import parse_file, validate_file
from nacha.rules import OdfiRuleSet, ValidationIssue

from tests.helpers import (
    build_file_text,
    simple_credit_entry,
    simple_debit_entry,
    make_iat_addenda,
    entry_hash_for,
)


# Permissive rule set with the actual fixture values allowlisted.
def _permissive_rules():
    return OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
    )


# ---------------------------------------------------------------------------
# ODFI-scoped rules
# ---------------------------------------------------------------------------

def test_validate_valid_file_returns_empty_list():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    assert validate_file(parsed, _permissive_rules()) == []




def test_validate_flags_permitted_origin():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    rules = OdfiRuleSet(
        permitted_immediate_origins=[" 099999999"],  # doesn't match fixture
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
    )
    issues = validate_file(parsed, rules)
    names = {i.rule for i in issues}
    assert "odfi.permitted_origin" in names


def test_validate_flags_permitted_destination():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    rules = OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 099999999"],  # doesn't match
        permitted_company_ids=["1234567890"],
    )
    issues = validate_file(parsed, rules)
    names = {i.rule for i in issues}
    assert "odfi.permitted_destination" in names


def test_validate_flags_permitted_company_id():
    text = build_file_text([
        {"sec_code": "PPD",
         "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    rules = OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["9999999999"],  # doesn't match
    )
    issues = validate_file(parsed, rules)
    names = {i.rule for i in issues}
    assert "odfi.permitted_company_id" in names


# ---------------------------------------------------------------------------
# Control-field rules
# ---------------------------------------------------------------------------

def _entry_with_addenda():
    return {**simple_credit_entry(),
            "addenda_indicator": "1",
            "addenda": [("05", "REMIT")]}


def test_validate_flags_batch_entry_addenda_count_mismatch():
    # Build a valid file, then mangle the batch control entry_addenda_count
    # by re-emitting raw text with an injected wrong value via overrides.
    from tests.helpers import (
        file_header_line, batch_header_line, entry_detail_line,
        batch_control_line, file_control_line, padding_line,
    )
    # 1 entry (count should be 1), but we say 5 in the batch control.
    fh = file_header_line()
    bh = batch_header_line()
    ed = entry_detail_line()
    bc = batch_control_line(entry_addenda_count=5)  # wrong
    fc = file_control_line(entry_addenda_count=1, block_count=1)
    lines = [fh, bh, ed, bc, fc] + [padding_line()] * 5
    text = "\n".join(lines) + "\n"
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "control.batch_entry_addenda_count" in {i.rule for i in issues}


def test_validate_flags_batch_entry_hash_mismatch():
    from tests.helpers import (
        file_header_line, batch_header_line, entry_detail_line,
        batch_control_line, file_control_line, padding_line,
    )
    fh = file_header_line()
    bh = batch_header_line()
    ed = entry_detail_line()
    bc = batch_control_line(entry_hash=9999999999)  # wrong
    fc = file_control_line(entry_hash=7100000, block_count=1)
    lines = [fh, bh, ed, bc, fc] + [padding_line()] * 5
    text = "\n".join(lines) + "\n"
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "control.batch_entry_hash" in {i.rule for i in issues}


def test_validate_flags_batch_total_debit_mismatch():
    from tests.helpers import (
        file_header_line, batch_header_line, entry_detail_line,
        batch_control_line, file_control_line, padding_line,
    )
    fh = file_header_line()
    bh = batch_header_line()
    # One credit entry; batch_control says there's a debit.
    ed = entry_detail_line(transaction_code="22", amount=10000)
    bc = batch_control_line(total_debit=10000, total_credit=10000)  # wrong debit
    fc = file_control_line(total_debit=10000, total_credit=10000, block_count=1)
    lines = [fh, bh, ed, bc, fc] + [padding_line()] * 5
    text = "\n".join(lines) + "\n"
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "control.batch_total_debit" in {i.rule for i in issues}


def test_validate_flags_batch_total_credit_mismatch():
    from tests.helpers import (
        file_header_line, batch_header_line, entry_detail_line,
        batch_control_line, file_control_line, padding_line,
    )
    fh = file_header_line()
    bh = batch_header_line()
    ed = entry_detail_line(transaction_code="22", amount=10000)
    bc = batch_control_line(total_credit=99999)  # wrong
    fc = file_control_line(total_credit=10000, block_count=1)
    lines = [fh, bh, ed, bc, fc] + [padding_line()] * 5
    text = "\n".join(lines) + "\n"
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "control.batch_total_credit" in {i.rule for i in issues}


def test_validate_flags_file_control_mismatches():
    # File control values all wrong while batch control is correct.
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry(amount=10000)]}],
        file_control_overrides={
            "batch_count": 9,
            "entry_addenda_count": 99,
            "entry_hash": "0099999999",
            "total_debit": 99,
            "total_credit": 99,
        },
    )
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    names = {i.rule for i in issues}
    assert "control.file_batch_count" in names
    assert "control.file_entry_addenda_count" in names
    assert "control.file_entry_hash" in names
    assert "control.file_total_debit" in names
    assert "control.file_total_credit" in names


# ---------------------------------------------------------------------------
# Per-SEC-code addenda content rules
# ---------------------------------------------------------------------------

def test_validate_flags_iat_addenda_sequence_when_missing_required_type():
    # Provide IAT addenda 10..15 only (missing 16).
    bad = [(t, " ") for t in ("10", "11", "12", "13", "14", "15")]
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(), "addenda": bad}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.iat_addenda_sequence" in {i.rule for i in issues}


def test_validate_iat_with_correct_sequence_has_no_iat_issue():
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(),
                      "addenda": make_iat_addenda()}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.iat_addenda_sequence" not in {i.rule for i in issues}


def test_validate_iat_with_17_only_extension_has_no_issue():
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(),
                      "addenda": make_iat_addenda(extra=("17",))}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.iat_addenda_sequence" not in {i.rule for i in issues}


def test_validate_iat_with_17_then_18_has_no_issue():
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(),
                      "addenda": make_iat_addenda(extra=("17", "18"))}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.iat_addenda_sequence" not in {i.rule for i in issues}


def test_validate_flags_ctx_addenda_type_when_non_05():
    # CTX entry carries an addenda with type 10 (not 05) — must fire.
    text = build_file_text([
        {"sec_code": "CTX",
         "entries": [{**simple_credit_entry(),
                      "addenda": [("05", "ok"), ("10", "bad")]}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.ctx_addenda_type" in {i.rule for i in issues}


@pytest.mark.parametrize("sec_code", ["PPD", "CCD", "WEB", "TEL"])
def test_validate_flags_simple_sec_with_indicator_1_but_zero_addenda(sec_code):
    text = build_file_text([
        {"sec_code": sec_code,
         "entries": [{**simple_credit_entry(),
                      "addenda_indicator": "1"}]},  # indicator 1, no addenda
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.ppd_ccd_web_tel_addenda" in {i.rule for i in issues}


@pytest.mark.parametrize("sec_code", ["PPD", "CCD", "WEB", "TEL"])
def test_validate_flags_simple_sec_with_indicator_0_but_one_addenda(sec_code):
    text = build_file_text([
        {"sec_code": sec_code,
         "entries": [{**simple_credit_entry(),
                      "addenda_indicator": "0",
                      "addenda": [("05", "X")]}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.ppd_ccd_web_tel_addenda" in {i.rule for i in issues}


@pytest.mark.parametrize("sec_code", ["ARC", "BOC", "POP", "RCK"])
def test_validate_flags_no_addenda_sec_codes_with_addenda(sec_code):
    text = build_file_text([
        {"sec_code": sec_code,
         "entries": [{**simple_debit_entry(),
                      "addenda_indicator": "1",
                      "addenda": [("05", "BAD")]}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.arc_boc_pop_rck_addenda" in {i.rule for i in issues}


# ---------------------------------------------------------------------------
# enforce_* flag toggles
# ---------------------------------------------------------------------------

def test_validate_enforce_control_fields_false_suppresses_control_issues():
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry(amount=10000)]}],
        file_control_overrides={"total_credit": 999},  # wrong
    )
    parsed = parse_file(text)
    rules_on = OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
        enforce_control_fields=True,
    )
    rules_off = OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
        enforce_control_fields=False,
    )
    on_names = {i.rule for i in validate_file(parsed, rules_on)}
    off_names = {i.rule for i in validate_file(parsed, rules_off)}
    # At least one control.* rule fires with enforcement on.
    assert any(r.startswith("control.") for r in on_names)
    # No control.* rule fires with enforcement off.
    assert not any(r.startswith("control.") for r in off_names)


def test_validate_enforce_sec_addenda_false_suppresses_sec_issues():
    text = build_file_text([
        {"sec_code": "CTX",
         "entries": [{**simple_credit_entry(),
                      "addenda": [("10", "bad")]}]},
    ])
    parsed = parse_file(text)
    rules_on = OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
        enforce_sec_addenda_content=True,
    )
    rules_off = OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
        enforce_sec_addenda_content=False,
    )
    on_names = {i.rule for i in validate_file(parsed, rules_on)}
    off_names = {i.rule for i in validate_file(parsed, rules_off)}
    assert any(r.startswith("sec.") for r in on_names)
    assert not any(r.startswith("sec.") for r in off_names)


# ---------------------------------------------------------------------------
# ValidationIssue contract
# ---------------------------------------------------------------------------

def test_validation_issue_carries_required_fields():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    rules = OdfiRuleSet(
        permitted_immediate_origins=[" 099999999"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
    )
    issues = validate_file(parsed, rules)
    assert len(issues) >= 1
    for issue in issues:
        assert isinstance(issue, ValidationIssue)
        assert isinstance(issue.rule, str) and issue.rule
        assert isinstance(issue.message, str) and issue.message
        assert isinstance(issue.line_number, int) and issue.line_number >= 1
        assert issue.record_type in {"1", "5", "6", "7", "8", "9"}


def test_validation_issue_for_origin_rule_points_to_file_header():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    rules = OdfiRuleSet(
        permitted_immediate_origins=[" 099999999"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
    )
    issues = [i for i in validate_file(parsed, rules)
              if i.rule == "odfi.permitted_origin"]
    assert issues
    assert issues[0].record_type == "1"
    assert issues[0].line_number == 1


# ---------------------------------------------------------------------------
# Gap 1: enforce_structural=False suppresses structural.* issues
# ---------------------------------------------------------------------------

def test_validate_enforce_structural_false_suppresses_structural_issues():
    # Build a valid file, parse it, then introduce a structural violation by
    # mutating the file header's record_type_code so validate_file would fire
    # structural.file_starts_with_header when enforcement is on.
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    parsed.file_header.record_type_code = "X"  # not "1" — structural violation
    rules_on = OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
        enforce_structural=True,
    )
    rules_off = OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["1234567890"],
        enforce_structural=False,
    )
    on_names = {i.rule for i in validate_file(parsed, rules_on)}
    off_names = {i.rule for i in validate_file(parsed, rules_off)}
    # At least one structural.* rule fires with enforcement on.
    assert any(r.startswith("structural.") for r in on_names)
    # No structural.* rule fires with enforcement off.
    assert not any(r.startswith("structural.") for r in off_names)


# ---------------------------------------------------------------------------
# Structural rules — direct firing tests for each rule identifier
# ---------------------------------------------------------------------------

def test_validate_flags_file_ends_with_control():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    parsed.file_control.record_type_code = "X"  # not "9"
    issues = validate_file(parsed, _permissive_rules())
    assert "structural.file_ends_with_control" in {i.rule for i in issues}


def test_validate_flags_batch_starts_with_header():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    parsed.batches[0].batch_header.record_type_code = "X"  # not "5"
    issues = validate_file(parsed, _permissive_rules())
    assert "structural.batch_starts_with_header" in {i.rule for i in issues}


def test_validate_flags_batch_ends_with_control():
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    parsed.batches[0].batch_control.record_type_code = "X"  # not "8"
    issues = validate_file(parsed, _permissive_rules())
    assert "structural.batch_ends_with_control" in {i.rule for i in issues}


def test_validate_flags_addenda_orphan():
    from tests.helpers import (
        file_header_line, batch_header_line, entry_detail_line,
        addenda_line, batch_control_line, file_control_line, padding_line,
    )
    fh = file_header_line()
    bh = batch_header_line()
    orphan = addenda_line()  # no parent entry precedes it in this batch
    ed = entry_detail_line()
    bc = batch_control_line(entry_addenda_count=2)
    fc = file_control_line(entry_addenda_count=2, block_count=1)
    lines = [fh, bh, orphan, ed, bc, fc] + [padding_line()] * 4
    text = "\n".join(lines) + "\n"
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "structural.addenda_orphan" in {i.rule for i in issues}


# ---------------------------------------------------------------------------
# Gap 3: IAT addenda sequence — additional invalid-sequence cases
# ---------------------------------------------------------------------------

def test_validate_flags_iat_addenda_sequence_when_required_types_out_of_order():
    # Mandatory addenda types present but not in the required 10-16 order.
    bad = [(t, " ") for t in ("11", "10", "12", "13", "14", "15", "16")]
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(), "addenda": bad}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.iat_addenda_sequence" in {i.rule for i in issues}


def test_validate_flags_iat_addenda_sequence_when_type_18_without_preceding_17():
    # 7 mandatory addenda followed by type 18 alone (no 17 preceding it).
    bad = make_iat_addenda(extra=("18",))
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(), "addenda": bad}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.iat_addenda_sequence" in {i.rule for i in issues}


def test_validate_flags_iat_addenda_sequence_when_18_appears_before_17():
    # 7 mandatory addenda followed by 18 then 17 (reversed order).
    bad = make_iat_addenda(extra=("18", "17"))
    text = build_file_text([
        {"sec_code": "IAT",
         "entries": [{**simple_credit_entry(), "addenda": bad}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.iat_addenda_sequence" in {i.rule for i in issues}


# ---------------------------------------------------------------------------
# Gap 4: PPD/CCD/WEB/TEL — indicator=1 with one addenda of wrong type code
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("sec_code", ["PPD", "CCD", "WEB", "TEL"])
def test_validate_flags_simple_sec_with_indicator_1_and_wrong_addenda_type(sec_code):
    # Indicator 1 present, exactly one addenda, but type code is not "05".
    text = build_file_text([
        {"sec_code": sec_code,
         "entries": [{**simple_credit_entry(),
                      "addenda_indicator": "1",
                      "addenda": [("10", "X")]}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.ppd_ccd_web_tel_addenda" in {i.rule for i in issues}


# ---------------------------------------------------------------------------
# D7-1: PPD/CCD/WEB/TEL indicator=1 with MORE THAN ONE type-05 addenda
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("sec_code", ["PPD", "CCD", "WEB", "TEL"])
def test_validate_flags_simple_sec_indicator_1_with_multiple_type_05_addenda(sec_code):
    # "exactly one type 05 addenda" — two type-05 addenda must also fire the rule.
    text = build_file_text([
        {"sec_code": sec_code,
         "entries": [{**simple_credit_entry(),
                      "addenda_indicator": "1",
                      "addenda": [("05", "FIRST"), ("05", "SECOND")]}]},
    ])
    parsed = parse_file(text)
    issues = validate_file(parsed, _permissive_rules())
    assert "sec.ppd_ccd_web_tel_addenda" in {i.rule for i in issues}


# ---------------------------------------------------------------------------
# D8-4: ValidationIssue.record_type is correct for multiple rule families
# ---------------------------------------------------------------------------

def test_validation_issue_record_type_for_company_id_rule():
    # odfi.permitted_company_id fires on a batch header — record_type must be "5".
    text = build_file_text([
        {"sec_code": "PPD", "entries": [simple_credit_entry()]},
    ])
    parsed = parse_file(text)
    rules = OdfiRuleSet(
        permitted_immediate_origins=[" 071000001"],
        permitted_immediate_destinations=[" 071000000"],
        permitted_company_ids=["9999999999"],  # doesn't match fixture "1234567890"
    )
    issues = [i for i in validate_file(parsed, rules)
              if i.rule == "odfi.permitted_company_id"]
    assert issues
    assert issues[0].record_type == "5"


def test_validation_issue_record_type_for_batch_control_rule():
    from tests.helpers import (
        file_header_line, batch_header_line, entry_detail_line,
        batch_control_line, file_control_line, padding_line,
    )
    # control.batch_total_credit fires on a batch control — record_type must be "8".
    fh = file_header_line()
    bh = batch_header_line()
    ed = entry_detail_line(transaction_code="22", amount=10000)
    bc = batch_control_line(total_credit=99999)  # wrong
    fc = file_control_line(total_credit=10000, block_count=1)
    lines = [fh, bh, ed, bc, fc] + [padding_line()] * 5
    text = "\n".join(lines) + "\n"
    parsed = parse_file(text)
    issues = [i for i in validate_file(parsed, _permissive_rules())
              if i.rule == "control.batch_total_credit"]
    assert issues
    assert issues[0].record_type == "8"


def test_validation_issue_record_type_for_file_control_rule():
    # control.file_batch_count fires on the file control — record_type must be "9".
    text = build_file_text(
        [{"sec_code": "PPD", "entries": [simple_credit_entry()]}],
        file_control_overrides={"batch_count": 99},  # wrong
    )
    parsed = parse_file(text)
    issues = [i for i in validate_file(parsed, _permissive_rules())
              if i.rule == "control.file_batch_count"]
    assert issues
    assert issues[0].record_type == "9"


# ---------------------------------------------------------------------------
# D8-5: ValidationIssue.line_number is correct for non-file-header rules
# ---------------------------------------------------------------------------

def test_validation_issue_line_number_for_batch_control_violation():
    from tests.helpers import (
        file_header_line, batch_header_line, entry_detail_line,
        batch_control_line, file_control_line, padding_line,
    )
    fh = file_header_line()
    bh = batch_header_line()
    ed = entry_detail_line(transaction_code="22", amount=10000)
    bc = batch_control_line(total_credit=99999)  # wrong; at line 4
    fc = file_control_line(total_credit=10000, block_count=1)
    lines = [fh, bh, ed, bc, fc] + [padding_line()] * 5
    text = "\n".join(lines) + "\n"
    parsed = parse_file(text)
    issues = [i for i in validate_file(parsed, _permissive_rules())
              if i.rule == "control.batch_total_credit"]
    assert issues
    assert issues[0].line_number == 4


# ---------------------------------------------------------------------------
# Gap #1: ValidationIssue.record_type == "6" for an entry-detail violation
# Gap #2: ValidationIssue.line_number correct for an entry-detail violation
# ---------------------------------------------------------------------------

def test_validation_issue_record_type_for_entry_detail_rule():
    from tests.helpers import (
        file_header_line, batch_header_line, entry_detail_line,
        batch_control_line, file_control_line, padding_line,
    )
    # Line 3 carries the entry with indicator=1 but no following addenda.
    fh = file_header_line()
    bh = batch_header_line(sec_code="PPD")
    ed = entry_detail_line(addenda_record_indicator="1")  # no addenda follow
    bc = batch_control_line()
    fc = file_control_line(block_count=1)
    lines = [fh, bh, ed, bc, fc] + [padding_line()] * 5
    text = "\n".join(lines) + "\n"
    parsed = parse_file(text)
    issues = [i for i in validate_file(parsed, _permissive_rules())
              if i.rule == "sec.ppd_ccd_web_tel_addenda"]
    assert issues
    assert issues[0].record_type == "6"


def test_validation_issue_line_number_for_entry_detail_violation():
    from tests.helpers import (
        file_header_line, batch_header_line, entry_detail_line,
        batch_control_line, file_control_line, padding_line,
    )
    fh = file_header_line()
    bh = batch_header_line(sec_code="PPD")
    ed = entry_detail_line(addenda_record_indicator="1")  # no addenda follow
    bc = batch_control_line()
    fc = file_control_line(block_count=1)
    lines = [fh, bh, ed, bc, fc] + [padding_line()] * 5
    text = "\n".join(lines) + "\n"
    parsed = parse_file(text)
    issues = [i for i in validate_file(parsed, _permissive_rules())
              if i.rule == "sec.ppd_ccd_web_tel_addenda"]
    assert issues
    assert issues[0].line_number == 3
