// Shared helpers for the F2P test suite.
//
// All tests dynamically import the implementation so that, in the absence of
// `src/index.ts`, the test FAILS (with a captured assertion message) instead
// of erroring out at module-load time. Every test body uses a try/catch +
// `expect(pass, info).toBe(true)` pattern so the empty-codebase run shows the
// test as FAILED, never ERRORED.

let cachedMod: any = undefined;

// Build the import path at runtime so Vite/Vitest does not try to statically
// resolve `../src/index.ts` during test collection. Without this indirection,
// a missing source file would cause the test files themselves to fail to
// load, masking the F2P "fail-not-error" guarantee.
function srcPath(ext: string): string {
  return ["..", "src", "index"].join("/") + ext;
}

export async function loadModule(): Promise<any | null> {
  if (cachedMod !== undefined) return cachedMod;
  for (const ext of [".ts", ".js", ".mjs"]) {
    try {
      const path = srcPath(ext);
      cachedMod = await import(/* @vite-ignore */ path);
      return cachedMod;
    } catch {
      // try next extension
    }
  }
  cachedMod = null;
  return cachedMod;
}

export function defaultTheme() {
  return {
    fontFamily: "Helvetica",
    backgroundColor: "#ffffff",
    textColor: "#111111",
    accentColor: "#3366ff",
    codeTheme: "github",
    slidePaddingPx: 32,
  };
}

// Triple-backtick fence used by tests when constructing markdown sources at
// runtime. Built via String.fromCharCode so the test source itself does not
// confuse editor/markdown tooling.
export const FENCE = String.fromCharCode(96, 96, 96);

// Convenience: build a markdown code fence block.
export function fenceBlock(language: string, code: string): string {
  return `${FENCE}${language}\n${code}\n${FENCE}`;
}

// Decode the standard HTML entities listed in the prompt.
export function decodeEntities(html: string): string {
  return html
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&");
}

// Strip all HTML tags, returning textual content only.
export function stripTags(html: string): string {
  return html.replace(/<[^>]*>/g, "");
}

// Find the index of every literal occurrence of `needle` in `haystack`.
export function indicesOf(haystack: string, needle: string): number[] {
  const out: number[] = [];
  let i = 0;
  while (true) {
    const idx = haystack.indexOf(needle, i);
    if (idx < 0) return out;
    out.push(idx);
    i = idx + 1;
  }
}

// Returns true if `arr` is strictly increasing (each element > previous).
export function strictlyIncreasing(arr: number[]): boolean {
  for (let i = 1; i < arr.length; i++) {
    if (!(arr[i] > arr[i - 1])) return false;
  }
  return true;
}

// Compare two byte sequences for equality.
export function bytesEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}
