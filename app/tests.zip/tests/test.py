import glob
import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import date, timedelta

import pytest


# -----------------------------------------------------------------------------
# HTTP helpers (stdlib-only so the suite has no third-party runtime deps)
# -----------------------------------------------------------------------------

_JSON_HEADERS = {"Content-Type": "application/json", "Accept": "application/json"}


def _http(method, url, body=None, timeout=10):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers=_JSON_HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8")
    except (urllib.error.URLError, OSError, Exception) as exc:
        # Raise as a test failure (not an error) so the result is FAILED, not ERROR.
        pytest.fail("Cannot reach application at {}: {}".format(url, exc))


def _post_json(url, body, timeout=10):
    return _http("POST", url, body=body, timeout=timeout)


def _get(url, timeout=10):
    return _http("GET", url, body=None, timeout=timeout)


def _parse_json(text):
    if text is None or text == "":
        return None
    return json.loads(text)


# -----------------------------------------------------------------------------
# Date-value normalizer: Spring/Jackson may serialize java.time.LocalDate as an
# ISO-8601 string ("YYYY-MM-DD"), as a [Y, M, D] array, or as an epoch-day
# integer. All three are valid; tests must handle every shape uniformly.
# -----------------------------------------------------------------------------

def _normalize_local_date(value):
    """Return a canonical 'YYYY-MM-DD' string for any supported LocalDate shape."""
    if isinstance(value, str):
        return value[:10]
    if isinstance(value, list) and len(value) >= 3:
        y, m, d = int(value[0]), int(value[1]), int(value[2])
        return "{:04d}-{:02d}-{:02d}".format(y, m, d)
    if isinstance(value, int):
        epoch = date(1970, 1, 1) + timedelta(days=int(value))
        return epoch.isoformat()
    raise AssertionError("Unsupported LocalDate JSON shape: {!r}".format(value))


# -----------------------------------------------------------------------------
# Instant-value normalizer: Spring/Jackson may serialize java.time.Instant as
# an ISO-8601 UTC string ("2024-01-15T10:30:00.123Z"), as a
# [epochSecond, nanoAdjustment] array, or as a plain epoch-second number.
# All three shapes are normalised to a float (epoch seconds with sub-second
# precision) so ordering comparisons work uniformly.
# -----------------------------------------------------------------------------

def _instant_comparable(value):
    """Return a float (epoch-seconds) for any supported Instant JSON shape."""
    import re as _re
    if isinstance(value, str):
        m = _re.match(
            r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?'
            r'(?:Z|[+-]\d{2}:?\d{2})?$',
            value.strip(),
        )
        if not m:
            raise AssertionError("Cannot parse Instant string: {!r}".format(value))
        from datetime import datetime as _dt, timezone as _tz
        y, mo, d, h, mi, s = (int(m.group(i)) for i in range(1, 7))
        frac_str = m.group(7) or "0"
        frac_sec = int((frac_str + "000000000")[:9]) / 1e9
        base = _dt(y, mo, d, h, mi, s, tzinfo=_tz.utc).timestamp()
        return base + frac_sec
    if isinstance(value, list):
        secs = int(value[0]) if len(value) >= 1 else 0
        nanos = int(value[1]) if len(value) >= 2 else 0
        return secs + nanos / 1e9
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    raise AssertionError("Unsupported Instant JSON shape: {!r}".format(value))


# -----------------------------------------------------------------------------
# Session-scoped server fixture.
#
# If BASE_URL is set in the environment, tests reuse an externally-managed
# server. Otherwise the fixture builds the Maven project at APP_DIR (default:
# the directory containing this test file) and launches the resulting fat JAR
# on an ephemeral port.
# -----------------------------------------------------------------------------

# A URL guaranteed to be unreachable: port 1 is reserved and never open.
_DEAD_URL = "http://127.0.0.1:1"


def _find_free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_http_listener(base_url, timeout=180):
    """Poll until the server responds or the timeout elapses. Returns True on success."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(base_url + "/", timeout=2)
            return True
        except urllib.error.HTTPError:
            return True
        except Exception:
            time.sleep(1)
    return False


@pytest.fixture(scope="session")
def base_url():
    env_url = os.environ.get("BASE_URL")
    if env_url:
        url = env_url.rstrip("/")
        _wait_for_http_listener(url, timeout=int(os.environ.get("WAIT_TIMEOUT", "60")))
        yield url
        return

    app_dir = os.environ.get("APP_DIR") or os.path.dirname(os.path.abspath(__file__))
    pom = os.path.join(app_dir, "pom.xml")
    if not os.path.isfile(pom):
        # No project to build - yield an unreachable URL so tests get FAILED, not ERROR.
        yield _DEAD_URL
        return

    try:
        build = subprocess.run(
            ["mvn", "-f", pom, "clean", "package", "-DskipTests"],
            capture_output=True,
            text=True,
        )
    except OSError:
        # mvn not installed or not on PATH
        yield _DEAD_URL
        return
    if build.returncode != 0:
        yield _DEAD_URL
        return

    target = os.path.join(app_dir, "target")
    candidates = [
        j for j in glob.glob(os.path.join(target, "*.jar"))
        if not j.endswith("-sources.jar") and not j.endswith("-javadoc.jar")
    ]
    if not candidates:
        yield _DEAD_URL
        return
    jar = candidates[0]

    port = _find_free_port()
    url = "http://127.0.0.1:{}".format(port)

    try:
        proc = subprocess.Popen(
            [
                "java",
                "-jar", jar,
                "--server.port={}".format(port),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
    except OSError:
        # java not installed or not on PATH
        yield _DEAD_URL
        return
    try:
        ready = _wait_for_http_listener(url, timeout=180)
        if not ready:
            # Server never started - yield dead URL so tests fail in their bodies.
            yield _DEAD_URL
        else:
            yield url
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()


# -----------------------------------------------------------------------------
# Test-data builders. All identifiers are UUID-derived so each test is isolated
# from every other test's in-memory state (registry, lineage store, trajectory).
# -----------------------------------------------------------------------------

ALL_CHECK_TYPES = ["NULL_RATE", "FRESHNESS", "VOLUME", "DISTRIBUTION_DRIFT"]

# DefaultStageExecutor produces synthetic metric values in [0.0, 0.099], so a
# threshold strictly above 0.099 guarantees every rule passes.
ALWAYS_PASS_THRESHOLD = 0.5


def _uid(prefix):
    return "{}-{}".format(prefix, uuid.uuid4().hex[:12])


def _rule(check_type, column, threshold=ALWAYS_PASS_THRESHOLD):
    return {"checkType": check_type, "columnName": column, "threshold": threshold}


def _stage(stage_id, columns, check_types=("NULL_RATE",), threshold=ALWAYS_PASS_THRESHOLD):
    rules = []
    for col in columns:
        for ct in check_types:
            rules.append(_rule(ct, col, threshold))
    schema = {col: "string" for col in columns}
    return {
        "stageId": stage_id,
        "transformationLogic": "select * from {}".format(stage_id),
        "qualityRules": rules,
        "schema": schema,
    }


def _declaration(pipeline_id, source, sink, stages):
    return {
        "pipelineId": pipeline_id,
        "sourceDatasetId": source,
        "sinkDatasetId": sink,
        "stages": stages,
    }


def _register(base_url, declaration):
    status, _ = _post_json(base_url + "/pipelines", declaration)
    assert status == 201, "Pipeline registration expected HTTP 201, got {}".format(status)


def _run(base_url, pipeline_id):
    status, body = _post_json(base_url + "/pipelines/{}/run".format(pipeline_id), {})
    assert status == 200, "Run expected HTTP 200, got {} body={}".format(status, body)
    return _parse_json(body)


def _backfill(base_url, pipeline_id, from_date, to_date):
    payload = {"fromDate": from_date.isoformat(), "toDate": to_date.isoformat()}
    status, body = _post_json(
        base_url + "/pipelines/{}/backfill".format(pipeline_id), payload
    )
    return status, _parse_json(body) if status == 200 else body


def _admin_runtime(base_url, pipeline_id):
    status, body = _get(base_url + "/admin/pipelines/{}/runtime".format(pipeline_id))
    assert status == 200, "Admin runtime expected HTTP 200, got {} body={}".format(status, body)
    return _parse_json(body)


def _trajectory(base_url, dataset_id):
    status, body = _get(
        base_url + "/admin/datasets/{}/quality-score/trajectory".format(dataset_id)
    )
    assert status == 200, "Trajectory expected HTTP 200, got {} body={}".format(status, body)
    parsed = _parse_json(body)
    assert isinstance(parsed, list), "Trajectory must be a JSON array, got {!r}".format(parsed)
    return parsed


# =============================================================================
# Feature 1 - Pipeline Registration (Req-1)
# =============================================================================

class TestPipelineRegistration:

    def test_post_pipelines_accepts_declaration_and_returns_201(self, base_url):
        """Req-1: POST /pipelines accepts a PipelineDeclaration JSON body and returns HTTP 201 with no body."""
        pipeline_id = _uid("pipe")
        decl = _declaration(
            pipeline_id,
            source=_uid("src"),
            sink=_uid("sink"),
            stages=[_stage(_uid("stage"), columns=[_uid("col")])],
        )
        status, resp_body = _post_json(base_url + "/pipelines", decl)
        assert status == 201
        assert resp_body is None or resp_body.strip() == "", (
            "POST /pipelines must return HTTP 201 with no body; got {!r}".format(resp_body)
        )


# =============================================================================
# Feature 2 - Single-run Execution (Req-2, 3, 4, 5)
# =============================================================================

class TestSinglePipelineRun:

    def _decl_with_two_stages(self):
        pipeline_id = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        s1, s2 = _uid("stageA"), _uid("stageB")
        col_a, col_b = _uid("colA"), _uid("colB")
        decl = _declaration(
            pipeline_id, source, sink,
            stages=[
                _stage(s1, columns=[col_a]),
                _stage(s2, columns=[col_b]),
            ],
        )
        return pipeline_id, source, sink, [s1, s2], decl

    def test_run_runtime_has_all_required_fields(self, base_url):
        """Req-2: PipelineRuntime exposes pipelineId, startedAt, completedAt, status, stageRuntimes."""
        pid, _src, _sink, _stages, decl = self._decl_with_two_stages()
        _register(base_url, decl)
        runtime = _run(base_url, pid)
        for field in ("pipelineId", "startedAt", "completedAt", "status", "stageRuntimes"):
            assert field in runtime, "PipelineRuntime missing field {!r}".format(field)
        assert runtime["pipelineId"] == pid
        assert runtime["startedAt"] is not None
        assert runtime["completedAt"] is not None
        # A pipeline cannot have started after it completed.
        assert _instant_comparable(runtime["startedAt"]) <= _instant_comparable(runtime["completedAt"]), (
            "startedAt ({}) must not be after completedAt ({})".format(
                runtime["startedAt"], runtime["completedAt"])
        )
        assert isinstance(runtime["stageRuntimes"], dict)

    def test_run_status_completed_for_default_executor(self, base_url):
        """Req-3: With DefaultStageExecutor (echoes schema), the single-run status is exactly 'COMPLETED'."""
        pid, _src, _sink, _stages, decl = self._decl_with_two_stages()
        _register(base_url, decl)
        runtime = _run(base_url, pid)
        assert runtime["status"] == "COMPLETED"

    def test_stage_runtimes_contains_every_declared_stage(self, base_url):
        """Req-4: stageRuntimes contains an entry for every executed stage ID in the declaration."""
        pid, _src, _sink, stage_ids, decl = self._decl_with_two_stages()
        _register(base_url, decl)
        runtime = _run(base_url, pid)
        stage_runtimes = runtime["stageRuntimes"]
        for sid in stage_ids:
            assert sid in stage_runtimes, "stageRuntimes missing key {!r}".format(sid)

    def test_stage_runtimes_values_are_non_negative_numbers(self, base_url):
        """Req-4: stageRuntimes values are non-negative integer elapsed-millisecond measurements (Map<String,Long>)."""
        pid, _src, _sink, stage_ids, decl = self._decl_with_two_stages()
        _register(base_url, decl)
        runtime = _run(base_url, pid)
        for sid in stage_ids:
            value = runtime["stageRuntimes"][sid]
            assert isinstance(value, int) and not isinstance(value, bool), (
                "stageRuntimes value for stage {!r} must be an integer (Long), got {!r}".format(
                    sid, type(value)
                )
            )
            assert value >= 0

    def test_run_persists_runtime_visible_via_admin_endpoint(self, base_url):
        """Req-5: After /run, GET /admin/pipelines/{id}/runtime returns the runtime that was just persisted."""
        pid, _src, _sink, _stages, decl = self._decl_with_two_stages()
        _register(base_url, decl)
        run_runtime = _run(base_url, pid)
        admin_runtime = _admin_runtime(base_url, pid)
        assert admin_runtime is not None
        assert admin_runtime["pipelineId"] == pid
        assert admin_runtime["status"] == run_runtime["status"]
        assert set(admin_runtime["stageRuntimes"].keys()) == set(run_runtime["stageRuntimes"].keys())


# =============================================================================
# Feature 3 - Admin endpoint not-found behaviour (Req-5 extension)
# =============================================================================

class TestAdminEndpoints:

    def test_admin_runtime_returns_404_for_unknown_pipeline(self, base_url):
        """GET /admin/pipelines/{pipelineId}/runtime returns HTTP 404 when no runtime
        has been stored for the pipeline."""
        status, _ = _get(
            base_url + "/admin/pipelines/{}/runtime".format(_uid("never-run"))
        )
        assert status == 404, (
            "Expected HTTP 404 for pipeline with no stored runtime; got {}".format(status)
        )

    def test_store_runtime_overwrites_previous_runtime(self, base_url):
        """storeRuntime overwrites the prior runtime for the same pipelineId;
        GET /admin/pipelines/{id}/runtime always returns the most recently stored runtime."""
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        decl = _declaration(pid, source, sink, [_stage(_uid("stage"), columns=[_uid("col")])])
        _register(base_url, decl)

        run1 = _run(base_url, pid)
        # 500 ms sleep ensures run2 starts at a strictly later wall-clock instant even on
        # systems with coarse clock granularity (e.g., 10–15 ms tick on some JVMs/OSes).
        time.sleep(0.5)
        run2 = _run(base_url, pid)

        # run2 must have started after run1 (monotonic time)
        assert _instant_comparable(run2["startedAt"]) > _instant_comparable(run1["startedAt"]), (
            "Second run's startedAt must be strictly after first run's startedAt after 0.1s sleep."
        )

        admin = _admin_runtime(base_url, pid)

        # Admin must return the SECOND (later) runtime, not the first.
        # If admin showed run1, its startedAt would be < run2's startedAt.
        assert _instant_comparable(admin["startedAt"]) >= _instant_comparable(run2["startedAt"]) - 0.001, (
            "After two runs, GET /admin/pipelines/{}/runtime must return the second (latest) "
            "runtime. Got startedAt={} but expected ~{}.".format(
                pid, admin["startedAt"], run2["startedAt"]
            )
        )


# =============================================================================
# Feature 4 - Lineage recorded during pipeline execution (Req-6)
# =============================================================================

class TestRunRecordsLineage:

    def test_run_records_lineage_for_stage_columns(self, base_url):
        """Req-6: Pipeline execution records ColumnLineage entries for EVERY column in the
        stage's declared schema via two recordLineage calls per column.
        Sink side: upstreamColumns = [sourceDatasetId::columnName], downstreamColumns = [].
        Source side: upstreamColumns = [], downstreamColumns = [sinkDatasetId::columnName].
        Uses a three-column stage to verify all columns receive individual entries."""
        pid = _uid("pipe")
        source = _uid("src")
        sink = _uid("sink")
        # Three-column schema to verify every column gets its own lineage entry.
        cols = [_uid("colA"), _uid("colB"), _uid("colC")]
        decl = _declaration(pid, source, sink, stages=[_stage(_uid("stage"), columns=cols)])
        _register(base_url, decl)
        _run(base_url, pid)

        for col in cols:
            expected_sink_up = "{}::{}".format(source, col)
            expected_src_down = "{}::{}".format(sink, col)

            # -- Sink side: upstream must be [sourceDatasetId::columnName] ----
            status, body = _get(base_url + "/lineage/{}/{}/upstream".format(sink, col))
            assert status == 200, (
                "GET sink upstream for column {!r} expected HTTP 200, got {}".format(col, status)
            )
            upstream = _parse_json(body)
            assert upstream == [expected_sink_up], (
                "Sink upstreamColumns for column {!r} must be ['{}']; "
                "got {!r}".format(col, expected_sink_up, upstream)
            )

            # -- Sink side: downstreamColumns must be empty -------------------
            status, body = _get(base_url + "/lineage/{}/{}/downstream".format(sink, col))
            assert status == 200, (
                "GET sink downstream for column {!r} expected HTTP 200, got {}".format(col, status)
            )
            downstream = _parse_json(body)
            assert downstream == [], (
                "Sink downstreamColumns for column {!r} must be []; "
                "got {!r}".format(col, downstream)
            )

            # -- Source side: upstreamColumns must be empty -------------------
            status, body = _get(base_url + "/lineage/{}/{}/upstream".format(source, col))
            assert status == 200, (
                "GET source upstream for column {!r} expected HTTP 200, got {}".format(col, status)
            )
            src_upstream = _parse_json(body)
            assert src_upstream == [], (
                "Source upstreamColumns for column {!r} must be []; "
                "got {!r}".format(col, src_upstream)
            )

            # -- Source side: downstream must be [sinkDatasetId::columnName] -
            status, body = _get(base_url + "/lineage/{}/{}/downstream".format(source, col))
            assert status == 200, (
                "GET source downstream for column {!r} expected HTTP 200, got {}".format(col, status)
            )
            src_downstream = _parse_json(body)
            assert src_downstream == [expected_src_down], (
                "Source downstreamColumns for column {!r} must be ['{}']; "
                "got {!r}".format(col, expected_src_down, src_downstream)
            )


# =============================================================================
# Feature 5 - Lineage REST API (Req-7, 8, 9)
# =============================================================================

class TestLineageController:

    def test_post_lineage_returns_201(self, base_url):
        """Req-7: POST /lineage accepts a ColumnLineage JSON body and returns HTTP 201 with no body."""
        body = {
            "datasetId": _uid("ds"),
            "columnName": _uid("col"),
            "upstreamColumns": [_uid("up1"), _uid("up2")],
            "downstreamColumns": [_uid("down1")],
        }
        status, resp_body = _post_json(base_url + "/lineage", body)
        assert status == 201
        assert resp_body is None or resp_body.strip() == "", (
            "POST /lineage must return HTTP 201 with no body; got {!r}".format(resp_body)
        )

    def test_get_upstream_returns_empty_list_for_unknown_key(self, base_url):
        """Req-8: GET upstream returns HTTP 200 with an empty JSON list when no lineage record exists for the key."""
        status, body = _get(
            base_url + "/lineage/{}/{}/upstream".format(_uid("ds"), _uid("col"))
        )
        assert status == 200
        result = _parse_json(body)
        assert result == []

    def test_get_downstream_returns_empty_list_for_unknown_key(self, base_url):
        """Req-9: GET downstream returns HTTP 200 with an empty JSON list when no lineage record exists for the key."""
        status, body = _get(
            base_url + "/lineage/{}/{}/downstream".format(_uid("ds"), _uid("col"))
        )
        assert status == 200
        result = _parse_json(body)
        assert result == []

    def test_get_upstream_returns_stored_upstream_columns(self, base_url):
        """Req-8: GET upstream returns the upstreamColumns list previously persisted via POST /lineage."""
        ds, col = _uid("ds"), _uid("col")
        upstream = [_uid("u1"), _uid("u2"), _uid("u3")]
        downstream = [_uid("d1")]
        lineage = {
            "datasetId": ds, "columnName": col,
            "upstreamColumns": upstream, "downstreamColumns": downstream,
        }
        status, _ = _post_json(base_url + "/lineage", lineage)
        assert status == 201

        status, body = _get(base_url + "/lineage/{}/{}/upstream".format(ds, col))
        assert status == 200
        assert _parse_json(body) == upstream

    def test_get_downstream_returns_stored_downstream_columns(self, base_url):
        """Req-9: GET downstream returns the downstreamColumns list previously persisted via POST /lineage."""
        ds, col = _uid("ds"), _uid("col")
        upstream = [_uid("u1")]
        downstream = [_uid("d1"), _uid("d2")]
        lineage = {
            "datasetId": ds, "columnName": col,
            "upstreamColumns": upstream, "downstreamColumns": downstream,
        }
        status, _ = _post_json(base_url + "/lineage", lineage)
        assert status == 201

        status, body = _get(base_url + "/lineage/{}/{}/downstream".format(ds, col))
        assert status == 200
        assert _parse_json(body) == downstream

    def test_post_lineage_overwrites_prior_record_for_same_key(self, base_url):
        """Req-26: recordLineage overwrites any prior ColumnLineage for the same (datasetId, columnName) key."""
        ds, col = _uid("ds"), _uid("col")

        first_lineage = {
            "datasetId": ds, "columnName": col,
            "upstreamColumns": [_uid("up-first")],
            "downstreamColumns": [_uid("down-first")],
        }
        status, _ = _post_json(base_url + "/lineage", first_lineage)
        assert status == 201

        second_upstream = [_uid("up-second-a"), _uid("up-second-b")]
        second_downstream = [_uid("down-second")]
        second_lineage = {
            "datasetId": ds, "columnName": col,
            "upstreamColumns": second_upstream,
            "downstreamColumns": second_downstream,
        }
        status, _ = _post_json(base_url + "/lineage", second_lineage)
        assert status == 201

        status, body = _get(base_url + "/lineage/{}/{}/upstream".format(ds, col))
        assert status == 200
        assert _parse_json(body) == second_upstream, (
            "After a second recordLineage call for the same key, GET upstream must "
            "return only the latest upstreamColumns (overwrite semantics)."
        )

        status, body = _get(base_url + "/lineage/{}/{}/downstream".format(ds, col))
        assert status == 200
        assert _parse_json(body) == second_downstream, (
            "After a second recordLineage call for the same key, GET downstream must "
            "return only the latest downstreamColumns (overwrite semantics)."
        )


# =============================================================================
# Feature 6 - Quality evaluation & trajectory (Req-10..16, 25)
# =============================================================================

class TestQualityEvaluation:

    def _decl_with_n_stages(self, n_stages=2, columns_per_stage=1,
                            check_types=("NULL_RATE",), threshold=ALWAYS_PASS_THRESHOLD):
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        stages = []
        for i in range(n_stages):
            cols = [_uid("col{}_{}".format(i, j)) for j in range(columns_per_stage)]
            stages.append(_stage(_uid("stage{}".format(i)),
                                 columns=cols,
                                 check_types=check_types,
                                 threshold=threshold))
        return pid, source, sink, _declaration(pid, source, sink, stages)

    def test_quality_entry_evaluated_at_reflects_wall_clock_time(self, base_url):
        """evaluatedAt is set to Instant.now() at evaluation time, not a constant or
        partition-derived value. It must fall within the wall-clock window of the request."""
        pid, _src, sink, decl = self._decl_with_n_stages(n_stages=1)
        _register(base_url, decl)

        before = time.time()
        _run(base_url, pid)
        after = time.time()

        traj = _trajectory(base_url, sink)
        assert len(traj) >= 1

        for entry in traj:
            evaluated_at = _instant_comparable(entry["evaluatedAt"])
            assert evaluated_at >= before - 1, (
                "evaluatedAt ({}) must not predate the request (before={:.3f}); "
                "suggests a constant or epoch-derived value.".format(
                    entry["evaluatedAt"], before)
            )
            assert evaluated_at <= after + 30, (
                "evaluatedAt ({}) must not significantly postdate the request (after={:.3f}).".format(
                    entry["evaluatedAt"], after)
            )

    def test_trajectory_is_empty_for_unknown_dataset(self, base_url):
        """Req-16: getQualityScoreTrajectory returns an empty list for a dataset with no recorded evaluations."""
        result = _trajectory(base_url, _uid("ds-never-evaluated"))
        assert result == []

    def test_single_run_partition_date_matches_today(self, base_url):
        """Req-27: POST /pipelines/{id}/run uses LocalDate.now(); the resulting QualityScoreEntry.partitionDate is today."""
        pid, _src, sink, decl = self._decl_with_n_stages(n_stages=1)
        _register(base_url, decl)
        _run(base_url, pid)

        traj = _trajectory(base_url, sink)
        assert len(traj) >= 1
        today = date.today()
        acceptable = {
            (today + timedelta(days=delta)).isoformat() for delta in (-1, 0, 1)
        }
        actual = _normalize_local_date(traj[0]["partitionDate"])
        assert actual in acceptable, (
            "Expected partitionDate in {!r}, got {!r}".format(sorted(acceptable), actual)
        )

    def test_run_appends_one_quality_entry_per_stage(self, base_url):
        """Req-10: A single pipeline run appends exactly one QualityScoreEntry per stage to the sink dataset trajectory."""
        pid, _src, sink, decl = self._decl_with_n_stages(n_stages=3)
        _register(base_url, decl)
        _run(base_url, pid)

        traj = _trajectory(base_url, sink)
        assert len(traj) == 3

    def test_quality_entry_has_all_required_fields(self, base_url):
        """Req-11: Each QualityScoreEntry exposes datasetId, partitionDate, evaluatedAt, score, ruleResults - all non-null with valid types."""
        pid, _src, sink, decl = self._decl_with_n_stages(n_stages=1)
        _register(base_url, decl)
        _run(base_url, pid)

        traj = _trajectory(base_url, sink)
        assert len(traj) >= 1
        entry = traj[0]
        for field in ("datasetId", "partitionDate", "evaluatedAt", "score", "ruleResults"):
            assert field in entry, "QualityScoreEntry missing field {!r}".format(field)
        assert entry["datasetId"] == sink
        assert entry["partitionDate"] is not None, "partitionDate must not be null"
        _normalize_local_date(entry["partitionDate"])   # raises AssertionError if unparseable
        assert entry["evaluatedAt"] is not None, "evaluatedAt must not be null"
        _instant_comparable(entry["evaluatedAt"])       # raises AssertionError if unparseable
        score = entry["score"]
        assert isinstance(score, (int, float)) and not isinstance(score, bool), (
            "score must be a numeric value (double), got {!r}".format(type(score))
        )
        assert 0.0 <= float(score) <= 1.0, (
            "score must be in [0.0, 1.0], got {}".format(score)
        )
        assert isinstance(entry["ruleResults"], dict)

    def test_quality_score_is_one_when_every_threshold_above_synthetic(self, base_url):
        """Req-13: With DefaultStageExecutor (synthetic <= 0.099) and every threshold > 0.099, every rule passes so score == 1.0."""
        pid, _src, sink, decl = self._decl_with_n_stages(
            n_stages=1, columns_per_stage=2,
            check_types=("NULL_RATE", "FRESHNESS"),
            threshold=ALWAYS_PASS_THRESHOLD,
        )
        _register(base_url, decl)
        _run(base_url, pid)

        traj = _trajectory(base_url, sink)
        assert len(traj) >= 1
        for entry in traj:
            assert abs(float(entry["score"]) - 1.0) < 1e-9
            # Every per-rule outcome is the "passing" boolean.
            for rule_key, outcome in entry["ruleResults"].items():
                assert type(outcome) is bool
                assert outcome is True, "Expected rule {!r} to pass, got {!r}".format(rule_key, outcome)

    def test_rule_results_use_composite_column_check_type_key(self, base_url):
        """Req-14: ruleResults keys are exactly 'columnName::CHECKTYPE' (uppercase enum name) with boolean values."""
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        col_x, col_y = _uid("colX"), _uid("colY")
        stage = {
            "stageId": _uid("stage"),
            "transformationLogic": "tx",
            "qualityRules": [
                _rule("NULL_RATE", col_x),
                _rule("FRESHNESS", col_x),
                _rule("VOLUME", col_y),
            ],
            "schema": {col_x: "string", col_y: "string"},
        }
        decl = _declaration(pid, source, sink, [stage])
        _register(base_url, decl)
        _run(base_url, pid)

        traj = _trajectory(base_url, sink)
        assert len(traj) >= 1
        rule_results = traj[-1]["ruleResults"]

        expected_keys = {
            "{}::NULL_RATE".format(col_x),
            "{}::FRESHNESS".format(col_x),
            "{}::VOLUME".format(col_y),
        }
        assert set(rule_results.keys()) == expected_keys, (
            "ruleResults must contain exactly the declared rules as keys; "
            "expected {} but got {}".format(expected_keys, set(rule_results.keys()))
        )
        for k in expected_keys:
            assert type(rule_results[k]) is bool

    def test_all_four_quality_check_types_round_trip_through_trajectory(self, base_url):
        """Req-15: A stage declaring rules with every QualityCheckType produces all four composite-key entries in ruleResults."""
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        col = _uid("col")
        rules = [_rule(ct, col) for ct in ALL_CHECK_TYPES]
        stage = {
            "stageId": _uid("stage"),
            "transformationLogic": "tx",
            "qualityRules": rules,
            "schema": {col: "string"},
        }
        decl = _declaration(pid, source, sink, [stage])
        _register(base_url, decl)
        _run(base_url, pid)

        traj = _trajectory(base_url, sink)
        assert len(traj) >= 1
        rule_results = traj[-1]["ruleResults"]

        expected_keys = {"{}::{}".format(col, ct) for ct in ALL_CHECK_TYPES}
        assert set(rule_results.keys()) == expected_keys, (
            "ruleResults must contain exactly the four composite keys for the "
            "declared rules; expected {} but got {}".format(
                sorted(expected_keys), sorted(rule_results.keys()))
        )


# =============================================================================
# Feature 7 - Backfill (Req-17..22)
# =============================================================================

class TestBackfill:

    def _simple_decl(self):
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        decl = _declaration(pid, source, sink, [_stage(_uid("stage"), columns=[_uid("col")])])
        return pid, source, sink, decl

    def test_backfill_aggregate_runtime_has_all_required_fields(self, base_url):
        """Req-18: Aggregate PipelineRuntime exposes pipelineId, startedAt, completedAt, status, stageRuntimes."""
        pid, _src, _sink, decl = self._simple_decl()
        _register(base_url, decl)
        status, runtime = _backfill(
            base_url, pid,
            from_date=date(2024, 1, 10), to_date=date(2024, 1, 12),
        )
        assert status == 200
        for field in ("pipelineId", "startedAt", "completedAt", "status", "stageRuntimes"):
            assert field in runtime, "Aggregate PipelineRuntime missing {!r}".format(field)
        assert runtime["pipelineId"] == pid
        assert runtime["startedAt"] is not None, "startedAt must not be null"
        assert runtime["completedAt"] is not None, "completedAt must not be null"
        assert _instant_comparable(runtime["startedAt"]) <= _instant_comparable(runtime["completedAt"]), (
            "startedAt ({}) must not be after completedAt ({}) in the aggregate "
            "PipelineRuntime".format(runtime["startedAt"], runtime["completedAt"])
        )
        assert isinstance(runtime["stageRuntimes"], dict)

    def test_backfill_aggregate_status_completed_when_all_days_succeed(self, base_url):
        """Req-19: Aggregate status is exactly 'COMPLETED' when every per-day status is 'COMPLETED'."""
        pid, _src, _sink, decl = self._simple_decl()
        _register(base_url, decl)
        status, runtime = _backfill(
            base_url, pid,
            from_date=date(2024, 1, 10), to_date=date(2024, 1, 13),
        )
        assert status == 200
        assert runtime["status"] == "COMPLETED"

    def test_backfill_with_from_after_to_returns_http_error(self, base_url):
        """Req-20: When fromDate is strictly after toDate, BackfillService rejects the request
        with HTTP >= 400 AND must not execute any pipeline run."""
        pid, _src, sink, decl = self._simple_decl()
        _register(base_url, decl)
        status, _body = _backfill(
            base_url, pid,
            from_date=date(2024, 1, 12), to_date=date(2024, 1, 10),
        )
        assert status >= 400, "Inverted backfill range must produce an HTTP error, got {}".format(status)

        traj = _trajectory(base_url, sink)
        assert traj == [], (
            "BackfillService must not execute any pipeline run when fromDate > toDate; "
            "expected empty trajectory but got {} entries.".format(len(traj))
        )

    def test_backfill_with_single_day_range_succeeds(self, base_url):
        """Req-21: Backfill executes the inclusive range; a same-day request (fromDate == toDate) is valid."""
        pid, _src, _sink, decl = self._simple_decl()
        _register(base_url, decl)
        day = date(2024, 3, 15)
        status, runtime = _backfill(base_url, pid, from_date=day, to_date=day)
        assert status == 200
        assert runtime["status"] == "COMPLETED"
        assert runtime["pipelineId"] == pid

    def test_backfill_persists_aggregate_runtime_for_admin_endpoint(self, base_url):
        """Req-22: BackfillService calls storeRuntime once with the aggregate; admin endpoint returns it."""
        pid, _src, _sink, decl = self._simple_decl()
        _register(base_url, decl)
        status, aggregate = _backfill(
            base_url, pid,
            from_date=date(2024, 2, 5), to_date=date(2024, 2, 7),
        )
        assert status == 200

        admin_runtime = _admin_runtime(base_url, pid)
        assert admin_runtime is not None
        assert admin_runtime["pipelineId"] == pid
        assert admin_runtime["status"] == aggregate["status"]
        assert set(admin_runtime["stageRuntimes"].keys()) == set(aggregate["stageRuntimes"].keys())


# =============================================================================
# Feature 8 - Backfill propagates per-day replayDate to the trajectory (Req-23, 24)
# =============================================================================

class TestBackfillReplayDateAndOrdering:

    def test_backfill_produces_one_partition_date_entry_per_calendar_day(self, base_url):
        """Req-23: Backfill propagates a distinct replayDate per calendar day; the trajectory carries one partitionDate per day in [from, to]."""
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        decl = _declaration(pid, source, sink, [_stage(_uid("stage"), columns=[_uid("col")])])
        _register(base_url, decl)

        from_date = date(2024, 4, 1)
        to_date = date(2024, 4, 5)
        expected_days = [
            (from_date + timedelta(days=i)).isoformat()
            for i in range((to_date - from_date).days + 1)
        ]

        status, _runtime = _backfill(base_url, pid, from_date=from_date, to_date=to_date)
        assert status == 200

        traj = _trajectory(base_url, sink)
        assert len(traj) == len(expected_days), (
            "Expected exactly {} trajectory entries (1 stage x {} days), "
            "got {}".format(len(expected_days), len(expected_days), len(traj))
        )
        partition_dates = sorted({_normalize_local_date(e["partitionDate"]) for e in traj})
        assert partition_dates == expected_days

    def test_trajectory_is_ordered_by_partition_date_ascending(self, base_url):
        """Req-24: getQualityScoreTrajectory returns entries in partitionDate-ascending order,
        and entries that share the same partitionDate are further ordered by evaluatedAt ascending."""
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        decl = _declaration(pid, source, sink, [_stage(_uid("stage"), columns=[_uid("col")])])
        _register(base_url, decl)

        # -- Primary sort: partitionDate ascending -----------------------------
        status, _ = _backfill(base_url, pid, from_date=date(2024, 6, 10), to_date=date(2024, 6, 12))
        assert status == 200
        status, _ = _backfill(base_url, pid, from_date=date(2024, 1, 1), to_date=date(2024, 1, 3))
        assert status == 200
        status, _ = _backfill(base_url, pid, from_date=date(2024, 3, 5), to_date=date(2024, 3, 7))
        assert status == 200

        traj = _trajectory(base_url, sink)
        returned_dates = [_normalize_local_date(e["partitionDate"]) for e in traj]
        assert returned_dates == sorted(returned_dates), (
            "Trajectory entries must be in partitionDate-ascending order; got {!r}".format(
                returned_dates
            )
        )

        # -- Secondary sort: same partitionDate -> earlier evaluatedAt first ----
        tie_pid = _uid("pipe")
        tie_sink = _uid("sink")
        tie_decl = _declaration(
            tie_pid, _uid("src"), tie_sink,
            [_stage(_uid("stage"), columns=[_uid("col")])],
        )
        _register(base_url, tie_decl)

        tie_day = date(2024, 5, 15)

        _backfill(base_url, tie_pid, from_date=tie_day, to_date=tie_day)
        # 500 ms sleep is generous relative to any realistic JVM clock granularity,
        # ensuring the two same-day backfills produce distinguishably ordered evaluatedAt instants.
        time.sleep(0.5)
        _backfill(base_url, tie_pid, from_date=tie_day, to_date=tie_day)

        tie_traj = _trajectory(base_url, tie_sink)
        same_day_entries = [
            e for e in tie_traj
            if _normalize_local_date(e["partitionDate"]) == tie_day.isoformat()
        ]
        assert len(same_day_entries) >= 2, (
            "Expected >= 2 trajectory entries for partitionDate={} after two "
            "same-day backfills; got {}.".format(tie_day.isoformat(), len(same_day_entries))
        )

        for i in range(len(same_day_entries) - 1):
            ea = _instant_comparable(same_day_entries[i]["evaluatedAt"])
            eb = _instant_comparable(same_day_entries[i + 1]["evaluatedAt"])
            assert ea <= eb, (
                "Trajectory entries sharing partitionDate={} must be ordered by "
                "evaluatedAt ascending (earlier evaluatedAt first); "
                "entry[{}].evaluatedAt ({}) is after entry[{}].evaluatedAt ({}).".format(
                    tie_day.isoformat(), i, ea, i + 1, eb,
                )
            )

    def test_trajectory_merges_single_run_and_backfill_entries_in_order(self, base_url):
        """getQualityScoreTrajectory merges entries from single runs and backfill runs into
        the same partitionDate-ascending sequence without segregating by source."""
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        decl = _declaration(pid, source, sink, [_stage(_uid("stage"), columns=[_uid("col")])])
        _register(base_url, decl)

        # Backfill three historical dates well in the past
        backfill_from = date(2022, 6, 1)
        backfill_to = date(2022, 6, 3)
        status, _ = _backfill(base_url, pid, from_date=backfill_from, to_date=backfill_to)
        assert status == 200

        # Single run produces a partitionDate of today (always after the 2022 dates)
        _run(base_url, pid)

        traj = _trajectory(base_url, sink)

        # At least 4 entries: 3 backfill days + 1 from single run
        assert len(traj) >= 4, (
            "Trajectory must contain entries from both backfill (3 days) and single run; "
            "got {} entries.".format(len(traj))
        )

        # All entries remain sorted by partitionDate ascending regardless of source
        returned_dates = [_normalize_local_date(e["partitionDate"]) for e in traj]
        assert returned_dates == sorted(returned_dates), (
            "Merged single-run and backfill entries must be sorted by partitionDate "
            "ascending; got {!r}".format(returned_dates)
        )

        # Every historical backfill date must be present in the merged trajectory
        for i in range((backfill_to - backfill_from).days + 1):
            expected = (backfill_from + timedelta(days=i)).isoformat()
            assert any(_normalize_local_date(e["partitionDate"]) == expected for e in traj), (
                "Backfill entry for partitionDate={!r} must appear in merged "
                "trajectory.".format(expected)
            )


# =============================================================================
# Feature 9 - Quality rule pass/fail logic and score calculation (Req-13 ext.)
# =============================================================================

class TestQualityRulePassFail:

    _DATE_062 = date(2020, 1, 1)  # metric = (18262 % 100) / 1000.0 = 0.062
    _DATE_000 = date(1970, 1, 1)  # metric = (0 % 100) / 1000.0 = 0.000

    def _decl_for_quality(self, rules, col=None):
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        if col is None:
            col = _uid("col")
        stage = {
            "stageId": _uid("stage"),
            "transformationLogic": "tx",
            "qualityRules": rules,
            "schema": {col: "string"},
        }
        return pid, source, sink, col, _declaration(pid, source, sink, [stage])

    def test_quality_rule_fails_when_metric_exceeds_threshold(self, base_url):
        """Rule FAILS when measured value > threshold; score < 1.0 for the failing rule."""
        # metric(2020-01-01) = 0.062 > threshold=0.05 -> FAIL
        col = _uid("col")
        pid, source, sink, col, decl = self._decl_for_quality(
            rules=[{"checkType": "NULL_RATE", "columnName": col, "threshold": 0.05}],
            col=col,
        )
        _register(base_url, decl)
        status, _ = _backfill(base_url, pid,
                               from_date=self._DATE_062, to_date=self._DATE_062)
        assert status == 200

        traj = _trajectory(base_url, sink)
        matching = [e for e in traj
                    if _normalize_local_date(e["partitionDate"]) == self._DATE_062.isoformat()]
        assert len(matching) >= 1, "Expected a trajectory entry for {}".format(self._DATE_062)
        entry = matching[0]

        assert abs(float(entry["score"]) - 0.0) < 1e-9, (
            "score must be exactly 0.0 when the only rule fails "
            "(0 passing / 1 total); got {}".format(entry["score"])
        )
        rule_key = "{}::NULL_RATE".format(col)
        assert rule_key in entry["ruleResults"]
        assert entry["ruleResults"][rule_key] is False, (
            "ruleResults[{!r}] must be False when metric > threshold".format(rule_key)
        )

    def test_quality_score_is_zero_when_all_rules_fail(self, base_url):
        """score = 0.0 when every rule's metric exceeds its threshold."""
        # metric(2020-01-01) = 0.062; both thresholds = 0.05 -> both FAIL
        col = _uid("col")
        pid, source, sink, col, decl = self._decl_for_quality(
            rules=[
                {"checkType": "NULL_RATE",  "columnName": col, "threshold": 0.05},
                {"checkType": "FRESHNESS",  "columnName": col, "threshold": 0.05},
            ],
            col=col,
        )
        _register(base_url, decl)
        _backfill(base_url, pid, from_date=self._DATE_062, to_date=self._DATE_062)

        traj = _trajectory(base_url, sink)
        matching = [e for e in traj
                    if _normalize_local_date(e["partitionDate"]) == self._DATE_062.isoformat()]
        assert len(matching) >= 1
        entry = matching[0]
        assert abs(float(entry["score"]) - 0.0) < 1e-9, (
            "score must be 0.0 when all rules fail; got {}".format(entry["score"])
        )

    def test_quality_score_is_half_when_one_of_two_rules_passes(self, base_url):
        """score = 0.5 when exactly 1 of 2 rules passes (passing / total)."""
        # metric(2020-01-01) = 0.062
        # threshold=0.5  -> 0.062 <= 0.5  -> PASS
        # threshold=0.05 -> 0.062 > 0.05  -> FAIL
        col = _uid("col")
        pid, source, sink, col, decl = self._decl_for_quality(
            rules=[
                {"checkType": "NULL_RATE", "columnName": col, "threshold": 0.5},
                {"checkType": "FRESHNESS", "columnName": col, "threshold": 0.05},
            ],
            col=col,
        )
        _register(base_url, decl)
        _backfill(base_url, pid, from_date=self._DATE_062, to_date=self._DATE_062)

        traj = _trajectory(base_url, sink)
        matching = [e for e in traj
                    if _normalize_local_date(e["partitionDate"]) == self._DATE_062.isoformat()]
        assert len(matching) >= 1
        entry = matching[0]
        assert abs(float(entry["score"]) - 0.5) < 1e-9, (
            "score must be 0.5 when exactly 1 of 2 rules passes; got {}".format(entry["score"])
        )

        col_key_pass = "{}::NULL_RATE".format(col)
        col_key_fail = "{}::FRESHNESS".format(col)
        assert entry["ruleResults"][col_key_pass] is True
        assert entry["ruleResults"][col_key_fail] is False

    def test_quality_rule_passes_at_exact_threshold_boundary(self, base_url):
        """A rule whose measured value equals the threshold must PASS (<= semantics, not strict <)."""
        # metric("1970-01-01") = 0.0 ; threshold = 0.0 -> 0.0 == 0.0 -> PASS -> score = 1.0
        col = _uid("col")
        pid, source, sink, col, decl = self._decl_for_quality(
            rules=[{"checkType": "NULL_RATE", "columnName": col, "threshold": 0.0}],
            col=col,
        )
        _register(base_url, decl)
        _backfill(base_url, pid, from_date=self._DATE_000, to_date=self._DATE_000)

        traj = _trajectory(base_url, sink)
        matching = [e for e in traj
                    if _normalize_local_date(e["partitionDate"]) == self._DATE_000.isoformat()]
        assert len(matching) >= 1
        entry = matching[0]
        assert abs(float(entry["score"]) - 1.0) < 1e-9, (
            "A rule where measured == threshold must PASS; expected score 1.0, got {}".format(
                entry["score"])
        )
        rule_key = "{}::NULL_RATE".format(col)
        assert entry["ruleResults"][rule_key] is True, (
            "ruleResults[{!r}] must be True when metric equals threshold".format(rule_key)
        )

    def test_quality_rule_failure_does_not_change_pipeline_status_to_failed(self, base_url):
        """Quality-rule failures reduce the quality score but must NOT set PipelineRuntime.status
        to 'FAILED'; only SchemaValidationException changes the status away from 'COMPLETED'."""
        col = _uid("col")
        pid, source, sink, col, decl = self._decl_for_quality(
            rules=[{"checkType": "NULL_RATE", "columnName": col, "threshold": 0.05}],
            col=col,
        )
        _register(base_url, decl)
        # metric(2020-01-01) = 0.062 > threshold 0.05 -> rule FAILS, score = 0.0
        bf_status, runtime = _backfill(base_url, pid,
                                       from_date=self._DATE_062, to_date=self._DATE_062)
        assert bf_status == 200

        assert runtime["status"] == "COMPLETED", (
            "A quality-rule failure must not set PipelineRuntime.status to 'FAILED'; "
            "only SchemaValidationException changes status away from 'COMPLETED'. "
            "Got status={!r}".format(runtime["status"])
        )


# =============================================================================
# Feature 10 - Backfill aggregate stageRuntimes contains all declared stage IDs
# =============================================================================

class TestBackfillStageRuntimes:

    def test_backfill_aggregate_stage_runtimes_contains_declared_stage_ids(self, base_url):
        """stageRuntimes in the aggregate PipelineRuntime must include every declared
        stage ID as a non-negative integer (Long ms).

        Structural contract verified here:
          - every declared stage ID is present as a key
          - every value is a non-negative integer (Map<String, Long>)

        Sum-semantics contract (last-write-wins is disallowed per the prompt):
          Verifying that aggregate = sum(per-day elapsed ms) - rather than the last
          day's value - requires a deterministic, non-zero elapsed-time source.
          DefaultStageExecutor's trivial in-memory computation completes in ~0 ms,
          making sum and last-write-wins indistinguishable via HTTP-only observation.
          Sum semantics MUST be covered by a rubric criterion inspecting the
          BackfillService implementation directly.
        """
        pid = _uid("pipe")
        source, sink = _uid("src"), _uid("sink")
        stage_id_a = _uid("stageA")
        stage_id_b = _uid("stageB")
        col_a, col_b = _uid("colA"), _uid("colB")
        stages = [
            _stage(stage_id_a, columns=[col_a]),
            _stage(stage_id_b, columns=[col_b]),
        ]
        decl = _declaration(pid, source, sink, stages)
        _register(base_url, decl)

        # -- 3-day aggregate ---------------------------------------------------
        status, runtime = _backfill(base_url, pid,
                                    from_date=date(2024, 5, 1),
                                    to_date=date(2024, 5, 3))
        assert status == 200
        stage_runtimes = runtime["stageRuntimes"]

        assert stage_id_a in stage_runtimes, (
            "Backfill aggregate stageRuntimes must contain declared stage {!r}; "
            "actual keys: {!r}".format(stage_id_a, list(stage_runtimes.keys()))
        )
        assert stage_id_b in stage_runtimes, (
            "Backfill aggregate stageRuntimes must contain declared stage {!r}; "
            "actual keys: {!r}".format(stage_id_b, list(stage_runtimes.keys()))
        )

        agg_a = stage_runtimes[stage_id_a]
        agg_b = stage_runtimes[stage_id_b]
        assert isinstance(agg_a, int) and not isinstance(agg_a, bool) and agg_a >= 0, (
            "stageRuntimes[{!r}] must be a non-negative integer (Long); "
            "got {!r}".format(stage_id_a, agg_a)
        )
        assert isinstance(agg_b, int) and not isinstance(agg_b, bool) and agg_b >= 0, (
            "stageRuntimes[{!r}] must be a non-negative integer (Long); "
            "got {!r}".format(stage_id_b, agg_b)
        )