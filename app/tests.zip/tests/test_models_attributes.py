"""Verify the persisted estimator attributes after ``fit``."""

from sklearn.linear_model import LinearRegression, LogisticRegression


def test_probability_model_is_fitted_logistic_regression(fitted_pipeline):
    """The probability model is persisted as a fitted
    ``LogisticRegression`` on the documented ``probability_model``
    attribute."""

    model = fitted_pipeline.probability_model
    assert isinstance(model, LogisticRegression)
    assert hasattr(model, "coef_")


def test_amount_model_is_fitted_linear_regression(fitted_pipeline):
    """The amount model is persisted as a fitted ``LinearRegression`` on
    the documented ``amount_model`` attribute."""

    model = fitted_pipeline.amount_model
    assert isinstance(model, LinearRegression)
    assert hasattr(model, "coef_")


def test_probability_model_random_state_matches_pipeline(
    DonorPipeline, sample_donations
):
    """The ``LogisticRegression`` is constructed with ``random_state``
    equal to the pipeline's own ``random_state`` argument."""

    pipeline = DonorPipeline(random_state=7).fit(sample_donations)

    assert pipeline.probability_model.random_state == 7


def test_probability_model_uses_default_constructor_arguments_except_random_state(
    DonorPipeline, sample_donations
):
    """All ``LogisticRegression`` constructor parameters other than
    ``random_state`` match the scikit-learn defaults — every parameter
    must agree exactly with ``LogisticRegression(random_state=42)``.
    This pins requirement 25's "otherwise default" clause across the
    full ``get_params()`` surface (``C``, ``penalty``, ``solver``,
    ``max_iter``, ``fit_intercept``, ``class_weight`` …)."""

    pipeline = DonorPipeline(random_state=42).fit(sample_donations)
    expected = LogisticRegression(random_state=42).get_params()
    actual = pipeline.probability_model.get_params()

    assert actual == expected, (
        "LogisticRegression constructor params drifted from defaults. "
        f"Differences: { {k: (actual.get(k), expected.get(k)) for k in set(actual) | set(expected) if actual.get(k) != expected.get(k)} }"
    )


def test_amount_model_uses_default_constructor_arguments(fitted_pipeline):
    """All ``LinearRegression`` constructor parameters match the
    scikit-learn defaults — every parameter must agree exactly with
    ``LinearRegression()``. This pins requirement 28's "entirely with
    default scikit-learn constructor values" clause."""

    expected = LinearRegression().get_params()
    actual = fitted_pipeline.amount_model.get_params()

    assert actual == expected, (
        "LinearRegression constructor params drifted from defaults. "
        f"Differences: { {k: (actual.get(k), expected.get(k)) for k in set(actual) | set(expected) if actual.get(k) != expected.get(k)} }"
    )
