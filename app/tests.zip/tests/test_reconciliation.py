import uuid
import pytest
from conftest import create_insurer


def create_reconciliation(client, insurer_id, **overrides):
    payload = {
        "insurer_id": insurer_id,
        "plan_year": 2024,
        "risk_adjustment_transfer_amount": 150000.0,
        "notes": "Initial reconciliation entry",
    }
    payload.update(overrides)
    return client.post("/api/reconciliation", json=payload)


class TestCreateReconciliation:
    def test_create_reconciliation_success(self, client):
        insurer = create_insurer(client).json()
        resp = create_reconciliation(client, insurer["insurer_id"])
        assert resp.status_code == 201

    def test_create_reconciliation_returns_fields(self, client):
        insurer = create_insurer(client).json()
        resp = create_reconciliation(client, insurer["insurer_id"])
        data = resp.json()
        assert "reconciliation_id" in data
        assert isinstance(data["reconciliation_id"], str)
        uuid.UUID(data["reconciliation_id"])  # raises ValueError if not a valid UUID
        assert data["cciio_submission_status"] == "pending"
        assert data["submission_date"] is None
        assert data["insurer_id"] == insurer["insurer_id"]
        assert data["plan_year"] == 2024
        assert data["risk_adjustment_transfer_amount"] == 150000.0

    def test_create_reconciliation_negative_transfer(self, client):
        insurer = create_insurer(client).json()
        resp = create_reconciliation(
            client, insurer["insurer_id"],
            risk_adjustment_transfer_amount=-50000.0,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["risk_adjustment_transfer_amount"] == -50000.0

    def test_create_reconciliation_nonexistent_insurer(self, client):
        resp = create_reconciliation(client, "nonexistent-id")
        assert resp.status_code == 404


class TestSubmitReconciliation:
    def test_submit_reconciliation_success(self, client):
        insurer = create_insurer(client).json()
        rec = create_reconciliation(client, insurer["insurer_id"]).json()
        resp = client.post(f"/api/reconciliation/{rec['reconciliation_id']}/submit")
        assert resp.status_code == 200
        data = resp.json()
        assert data["cciio_submission_status"] == "submitted"
        assert data["submission_date"] is not None

    def test_submit_reconciliation_already_submitted(self, client):
        insurer = create_insurer(client).json()
        rec = create_reconciliation(client, insurer["insurer_id"]).json()
        client.post(f"/api/reconciliation/{rec['reconciliation_id']}/submit")
        resp = client.post(f"/api/reconciliation/{rec['reconciliation_id']}/submit")
        assert resp.status_code == 400

    def test_submit_reconciliation_not_found(self, client):
        resp = client.post("/api/reconciliation/nonexistent-id/submit")
        assert resp.status_code == 404


class TestGetReconciliation:
    def test_get_all_reconciliation(self, client):
        insurer = create_insurer(client).json()
        create_reconciliation(client, insurer["insurer_id"])
        resp = client.get("/api/reconciliation")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)
        assert len(resp.json()) >= 1

    def test_get_reconciliation_by_insurer(self, client):
        ins1 = create_insurer(client).json()
        ins2 = create_insurer(client).json()
        create_reconciliation(client, ins1["insurer_id"])
        create_reconciliation(client, ins2["insurer_id"])
        resp = client.get(f"/api/reconciliation?insurer_id={ins1['insurer_id']}")
        assert resp.status_code == 200
        recs = resp.json()
        assert len(recs) == 1
        assert recs[0]["insurer_id"] == ins1["insurer_id"]
