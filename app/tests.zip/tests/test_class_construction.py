"""Verify the public constructor surface of ``DonorPipeline``."""

import pandas as pd


def test_default_constructor_stores_documented_attributes(DonorPipeline):
    """The default constructor stores the three configuration values on
    the documented instance attributes."""

    pipeline = DonorPipeline()

    assert pipeline.as_of_date is None
    assert pipeline.saturation_threshold == 1.5
    assert pipeline.random_state == 42


def test_constructor_accepts_and_stores_custom_arguments(DonorPipeline):
    """Custom values supplied by keyword are retained verbatim on the
    matching instance attributes."""

    custom_date = pd.Timestamp("2024-06-15")
    pipeline = DonorPipeline(
        as_of_date=custom_date,
        saturation_threshold=2.5,
        random_state=7,
    )

    assert pipeline.as_of_date == custom_date
    assert pipeline.saturation_threshold == 2.5
    assert pipeline.random_state == 7
