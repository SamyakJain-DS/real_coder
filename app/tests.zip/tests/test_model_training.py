"""Tests for the probability and amount target semantics defined in
section 4 of the prompt.

The strategy: locate the persisted feature matrix, hand-compute the
expected targets from the donations DataFrame, refit a fresh
``LogisticRegression`` / ``LinearRegression`` with identical
hyperparameters on the same X and our reconstructed y, then compare
the persisted estimator's coefficients and intercept against the
reference. Any deviation in the target definition or in the training
subset (positives-only for the amount model) produces a different
fit and therefore different coefficients, so the comparison strictly
pins requirements 26, 27, 29 and 30 simultaneously.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from sklearn.linear_model import LinearRegression, LogisticRegression


def _hand_computed_targets(donations: pd.DataFrame, donor_ids: list):
    """Return ``(prob_target, amount_target)`` aligned to ``donor_ids``.

    ``prob_target[i]`` equals 1 iff donor ``donor_ids[i]`` made at least
    one donation in ``(as_of_date, as_of_date + 30 days]``.
    ``amount_target[i]`` equals the sum of ``donation_amount`` made by
    that donor in the same window.
    """

    as_of = donations["date"].max() - pd.Timedelta(days=30)
    upper = as_of + pd.Timedelta(days=30)

    in_window = donations[
        (donations["date"] > as_of) & (donations["date"] <= upper)
    ]
    positives = set(in_window["donor_id"].unique())
    amount_by_donor = (
        in_window.groupby("donor_id")["donation_amount"].sum().to_dict()
    )

    prob_target = np.array(
        [1 if d in positives else 0 for d in donor_ids], dtype=int
    )
    amount_target = np.array(
        [amount_by_donor.get(d, 0.0) for d in donor_ids], dtype=float
    )
    return prob_target, amount_target


def test_probability_target_matches_window_membership(
    DonorPipeline,
    deterministic_donations,
    locate_feature_matrix,
    feature_donor_ids,
    feature_only,
):
    """The probability target equals 1 for donors with at least one
    donation in ``(as_of_date, as_of_date + 30 days]`` and 0 otherwise.

    Verified by refitting a fresh ``LogisticRegression(random_state=42)``
    on the persisted feature matrix with hand-computed targets and
    comparing coefficients and intercept against the persisted
    ``probability_model``. Identical hyperparameters + identical X +
    identical y -> identical (deterministic LBFGS) fit, so any deviation
    in the target definition produces a coefficient mismatch.

    This simultaneously pins requirement 27 (the model is trained on
    the engineered feature matrix) because the reference is fit on
    exactly that matrix.
    """

    pipeline = DonorPipeline().fit(deterministic_donations)
    fm = locate_feature_matrix(pipeline)
    donor_ids = feature_donor_ids(fm)
    X = feature_only(fm).to_numpy()

    prob_target, _ = _hand_computed_targets(deterministic_donations, donor_ids)

    reference = LogisticRegression(random_state=42)
    reference.fit(X, prob_target)

    np.testing.assert_allclose(
        pipeline.probability_model.coef_,
        reference.coef_,
        rtol=1e-6,
        atol=1e-6,
    )
    np.testing.assert_allclose(
        pipeline.probability_model.intercept_,
        reference.intercept_,
        rtol=1e-6,
        atol=1e-6,
    )


def test_amount_target_and_positives_only_training_subset(
    DonorPipeline,
    deterministic_donations,
    locate_feature_matrix,
    feature_donor_ids,
    feature_only,
):
    """The amount target equals the sum of ``donation_amount`` in
    ``(as_of_date, as_of_date + 30 days]`` *and* the amount model is
    fit on the subset of donors whose probability target equals 1.

    Verified by refitting a fresh ``LinearRegression()`` on the
    positives-only slice of the persisted feature matrix with
    hand-computed amount targets and comparing coefficients / intercept
    against the persisted ``amount_model``. ``LinearRegression`` is
    deterministic, so any deviation in either the target definition or
    the training subset produces a coefficient mismatch.
    """

    pipeline = DonorPipeline().fit(deterministic_donations)
    fm = locate_feature_matrix(pipeline)
    donor_ids = feature_donor_ids(fm)
    X = feature_only(fm).to_numpy()

    prob_target, amount_target = _hand_computed_targets(
        deterministic_donations, donor_ids
    )
    positive_mask = prob_target == 1

    assert positive_mask.sum() >= 1, (
        "Fixture invariant: at least one donor must be a positive."
    )

    reference = LinearRegression()
    reference.fit(X[positive_mask], amount_target[positive_mask])

    np.testing.assert_allclose(
        pipeline.amount_model.coef_,
        reference.coef_,
        rtol=1e-6,
        atol=1e-6,
    )
    np.testing.assert_allclose(
        pipeline.amount_model.intercept_,
        reference.intercept_,
        rtol=1e-6,
        atol=1e-6,
    )


def test_amount_target_sums_multiple_future_donations_per_donor(
    DonorPipeline,
    deterministic_donations,
    make_donations,
    locate_feature_matrix,
    feature_donor_ids,
    feature_only,
):
    """req 29: the amount target equals the **sum** of ``donation_amount``
    across the donor's donations in ``(as_of_date, as_of_date + 30 days]``,
    not the mean, max, or last value.

    In the base ``deterministic_donations`` fixture every positive donor
    has exactly **one** future donation, so ``sum == mean == max`` and
    those three reductions are indistinguishable. This test augments
    the universe with a second future donation for donor ``A`` so that
    ``sum (50 + 80 = 130)`` differs from ``mean (65)``, ``max (80)`` and
    ``count (2)``. A reference ``LinearRegression`` fit with sum
    targets matches the persisted ``amount_model``; one fit with any
    other reduction would yield different coefficients.
    """

    extras = make_donations(
        [
            {
                "donor_id": "A",
                "donation_amount": 80.0,
                "date": pd.Timestamp("2024-11-25"),
                "campaign": "c1",
                "channel": "email",
            }
        ]
    )
    augmented = pd.concat([deterministic_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(augmented)
    fm = locate_feature_matrix(pipeline)
    donor_ids = feature_donor_ids(fm)
    X = feature_only(fm).to_numpy()

    prob_target, amount_target = _hand_computed_targets(augmented, donor_ids)
    a_idx = donor_ids.index("A")
    assert prob_target[a_idx] == 1
    assert amount_target[a_idx] == pytest.approx(50.0 + 80.0), (
        "Hand-computed amount target must be the SUM (130.0), not the mean "
        "(65.0), max (80.0) or count (2)."
    )

    positive_mask = prob_target == 1
    reference = LinearRegression()
    reference.fit(X[positive_mask], amount_target[positive_mask])

    np.testing.assert_allclose(
        pipeline.amount_model.coef_, reference.coef_, rtol=1e-6, atol=1e-6
    )
    np.testing.assert_allclose(
        pipeline.amount_model.intercept_,
        reference.intercept_,
        rtol=1e-6,
        atol=1e-6,
    )


def test_donation_at_exactly_as_of_plus_30_days_is_a_future_positive(
    DonorPipeline,
    deterministic_donations,
    make_donations,
    locate_feature_matrix,
    feature_donor_ids,
    feature_only,
):
    """req 26 / 29: the future window ``(as_of_date, as_of_date + 30
    days]`` is **closed** at the right edge — a donation that lands
    exactly on ``as_of_date + 30 days`` MUST contribute to the
    probability target (and to the amount target) for that donor.

    This is the symmetric partner to
    ``test_donation_at_exactly_as_of_date_is_not_a_future_positive``,
    which pins the open *left* edge. Together they pin the
    half-open ``(left, right]`` interval at full precision.

    Strategy: add donor ``EDGE_RIGHT_HIST`` whose only window-eligible
    donation lands exactly at ``as_of_date + 30 days``. Hand-compute
    the targets with the half-open ``(as_of, as_of + 30d]`` window and
    refit reference estimators on the persisted feature matrix; any
    implementation using a strict ``< as_of + 30d`` upper bound would
    omit ``EDGE_RIGHT_HIST`` from the positives, change the training
    set for ``amount_model``, and produce mismatching coefficients.
    """

    as_of = deterministic_donations["date"].max() - pd.Timedelta(days=30)
    upper = as_of + pd.Timedelta(days=30)
    extras = make_donations(
        [
            {
                "donor_id": "EDGE_RIGHT_HIST",
                "donation_amount": 100.0,
                "date": "2024-06-01",
                "campaign": "c1",
                "channel": "email",
            },
            {
                "donor_id": "EDGE_RIGHT_HIST",
                "donation_amount": 60.0,
                "date": upper,
                "campaign": "c1",
                "channel": "email",
            },
        ]
    )
    augmented = pd.concat([deterministic_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(augmented)
    fm = locate_feature_matrix(pipeline)
    donor_ids = feature_donor_ids(fm)
    X = feature_only(fm).to_numpy()

    prob_target, amount_target = _hand_computed_targets(augmented, donor_ids)

    edge_idx = donor_ids.index("EDGE_RIGHT_HIST")
    assert prob_target[edge_idx] == 1, (
        "Hand-computed targets must treat a donation at exactly "
        "as_of + 30 days as a future positive (right edge of the "
        "future window is closed)."
    )
    assert amount_target[edge_idx] == pytest.approx(60.0)

    ref_prob = LogisticRegression(random_state=42).fit(X, prob_target)
    np.testing.assert_allclose(
        pipeline.probability_model.coef_, ref_prob.coef_, rtol=1e-6, atol=1e-6
    )
    np.testing.assert_allclose(
        pipeline.probability_model.intercept_,
        ref_prob.intercept_,
        rtol=1e-6,
        atol=1e-6,
    )

    positive_mask = prob_target == 1
    ref_amount = LinearRegression().fit(
        X[positive_mask], amount_target[positive_mask]
    )
    np.testing.assert_allclose(
        pipeline.amount_model.coef_, ref_amount.coef_, rtol=1e-6, atol=1e-6
    )
    np.testing.assert_allclose(
        pipeline.amount_model.intercept_,
        ref_amount.intercept_,
        rtol=1e-6,
        atol=1e-6,
    )


def test_donation_at_exactly_as_of_date_is_not_a_future_positive(
    DonorPipeline,
    deterministic_donations,
    make_donations,
    locate_feature_matrix,
    feature_donor_ids,
    feature_only,
):
    """The future window ``(as_of_date, as_of_date + 30 days]`` is
    **open** at the left edge: a donation that lands exactly on
    ``as_of_date`` must NOT contribute to the probability target. So
    a donor whose only donation is at ``as_of_date`` itself receives
    ``prob_target == 0`` and never enters the positives-only training
    subset for the amount model.

    Verified end-to-end: we add such a donor (``EDGE_LEFT``) to the
    deterministic donations, hand-compute the targets on that augmented
    universe with the half-open ``(as_of, as_of + 30d]`` window, and
    refit reference ``LogisticRegression`` / ``LinearRegression``
    estimators on the persisted feature matrix. Coefficient mismatches
    against the persisted models would expose any implementation that
    uses a closed left boundary (``[as_of, as_of + 30d]``).
    """

    as_of = deterministic_donations["date"].max() - pd.Timedelta(days=30)
    extras = make_donations(
        [
            {
                "donor_id": "EDGE_LEFT",
                "donation_amount": 50.0,
                "date": as_of,
                "campaign": "c1",
                "channel": "email",
            }
        ]
    )
    augmented = pd.concat([deterministic_donations, extras], ignore_index=True)

    pipeline = DonorPipeline().fit(augmented)
    fm = locate_feature_matrix(pipeline)
    donor_ids = feature_donor_ids(fm)
    X = feature_only(fm).to_numpy()

    prob_target, amount_target = _hand_computed_targets(augmented, donor_ids)

    edge_idx = donor_ids.index("EDGE_LEFT")
    assert prob_target[edge_idx] == 0, (
        "Hand-computed targets must treat a donation at exactly as_of_date "
        "as historical (the future window is open at the left edge)."
    )
    assert amount_target[edge_idx] == 0.0

    ref_prob = LogisticRegression(random_state=42).fit(X, prob_target)
    np.testing.assert_allclose(
        pipeline.probability_model.coef_, ref_prob.coef_, rtol=1e-6, atol=1e-6
    )
    np.testing.assert_allclose(
        pipeline.probability_model.intercept_,
        ref_prob.intercept_,
        rtol=1e-6,
        atol=1e-6,
    )

    positive_mask = prob_target == 1
    ref_amount = LinearRegression().fit(
        X[positive_mask], amount_target[positive_mask]
    )
    np.testing.assert_allclose(
        pipeline.amount_model.coef_, ref_amount.coef_, rtol=1e-6, atol=1e-6
    )
    np.testing.assert_allclose(
        pipeline.amount_model.intercept_,
        ref_amount.intercept_,
        rtol=1e-6,
        atol=1e-6,
    )
