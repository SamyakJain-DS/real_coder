import uuid
import pytest
from conftest import create_insurer


def create_exam(client, insurer_id, **overrides):
    payload = {
        "insurer_id": insurer_id,
        "exam_type": "comprehensive",
        "scheduled_date": "2025-06-15",
    }
    payload.update(overrides)
    return client.post("/api/examinations", json=payload)


class TestCreateExamination:
    def test_create_exam_success(self, client):
        insurer = create_insurer(client).json()
        resp = create_exam(client, insurer["insurer_id"])
        assert resp.status_code == 201

    def test_create_exam_returns_fields(self, client):
        insurer = create_insurer(client).json()
        resp = create_exam(client, insurer["insurer_id"])
        data = resp.json()
        assert "exam_id" in data
        assert isinstance(data["exam_id"], str)
        uuid.UUID(data["exam_id"])  # raises ValueError if not a valid UUID
        assert data["status"] == "scheduled"
        assert data["scheduled_date"] == "2025-06-15"
        assert data["claim_handling_score"] is None
        assert data["network_adequacy_score"] is None
        assert data["insurer_id"] == insurer["insurer_id"]
        assert data["exam_type"] == "comprehensive"

    def test_create_exam_nonexistent_insurer(self, client):
        resp = create_exam(client, "nonexistent-id")
        assert resp.status_code == 404


class TestCompleteExamination:
    def test_complete_exam_success(self, client):
        insurer = create_insurer(client).json()
        exam = create_exam(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/examinations/{exam['exam_id']}/complete",
            json={
                "claim_handling_score": 85.5,
                "network_adequacy_score": 92.0,
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "completed"
        assert data["claim_handling_score"] == 85.5
        assert data["network_adequacy_score"] == 92.0

    def test_complete_exam_boundary_scores_zero(self, client):
        insurer = create_insurer(client).json()
        exam = create_exam(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/examinations/{exam['exam_id']}/complete",
            json={
                "claim_handling_score": 0.0,
                "network_adequacy_score": 0.0,
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["claim_handling_score"] == 0.0
        assert data["network_adequacy_score"] == 0.0

    def test_complete_exam_boundary_scores_100(self, client):
        insurer = create_insurer(client).json()
        exam = create_exam(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/examinations/{exam['exam_id']}/complete",
            json={
                "claim_handling_score": 100.0,
                "network_adequacy_score": 100.0,
            },
        )
        assert resp.status_code == 200

    def test_complete_exam_score_out_of_range(self, client):
        insurer = create_insurer(client).json()
        exam = create_exam(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/examinations/{exam['exam_id']}/complete",
            json={
                "claim_handling_score": 105.0,
                "network_adequacy_score": 50.0,
            },
        )
        assert resp.status_code == 400

    def test_complete_exam_negative_score(self, client):
        insurer = create_insurer(client).json()
        exam = create_exam(client, insurer["insurer_id"]).json()
        resp = client.post(
            f"/api/examinations/{exam['exam_id']}/complete",
            json={
                "claim_handling_score": -1.0,
                "network_adequacy_score": 50.0,
            },
        )
        assert resp.status_code == 400

    def test_complete_exam_not_found(self, client):
        resp = client.post(
            "/api/examinations/nonexistent-id/complete",
            json={
                "claim_handling_score": 50.0,
                "network_adequacy_score": 50.0,
            },
        )
        assert resp.status_code == 404


class TestGetExaminations:
    def test_get_all_examinations(self, client):
        insurer = create_insurer(client).json()
        create_exam(client, insurer["insurer_id"])
        resp = client.get("/api/examinations")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)
        assert len(resp.json()) >= 1

    def test_get_examinations_by_insurer(self, client):
        ins1 = create_insurer(client).json()
        ins2 = create_insurer(client).json()
        create_exam(client, ins1["insurer_id"])
        create_exam(client, ins2["insurer_id"])
        resp = client.get(f"/api/examinations?insurer_id={ins1['insurer_id']}")
        assert resp.status_code == 200
        exams = resp.json()
        assert len(exams) == 1
        assert exams[0]["insurer_id"] == ins1["insurer_id"]
