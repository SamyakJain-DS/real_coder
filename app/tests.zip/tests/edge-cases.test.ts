import { describe, it, expect } from "vitest";
import { loadModule, defaultTheme, fenceBlock } from "./helpers";

function rootDeclarations(html: string): Record<string, string> {
  const styleM = html.match(/<style[^>]*>([\s\S]*?)<\/style>/);
  if (!styleM) return {};
  const css = styleM[1];
  const rootMatches = css.match(/:root\s*\{[\s\S]*?\}/g) || [];
  if (rootMatches.length === 0) return {};
  const merged = rootMatches
    .map((block) => { const m = block.match(/\{([\s\S]*)\}/); return m ? m[1] : ""; })
    .join(";");
  const out: Record<string, string> = {};
  for (const d of merged.split(";")) {
    const trimmed = d.trim();
    if (!trimmed) continue;
    const colon = trimmed.indexOf(":");
    if (colon < 0) continue;
    out[trimmed.slice(0, colon).trim()] = trimmed.slice(colon + 1).trim();
  }
  return out;
}

describe("Edge Case Contract", () => {
  it("EC1: bodyContent is `\"\"` when no non-blank lines remain after removal (Edge #1)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md =
        "# T\n\n![a](a.png)\n\n" +
        fenceBlock("ts", "x") +
        "\n\n:::notes\nn\n:::\n\n";
      const deck = compiler.parse(md);
      if (deck.slides[0].bodyContent !== "")
        throw new Error(
          `bodyContent: ${JSON.stringify(deck.slides[0].bodyContent)}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC2: when a slide has multiple level-1 headings, the first is the title and the rest stay verbatim in bodyContent (Edge #2)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# First\nintro\n# Second\noutro\n# Third";
      const deck = compiler.parse(md);
      const s = deck.slides[0];
      if (s.title !== "First")
        throw new Error(`title: ${JSON.stringify(s.title)}`);
      if (!s.bodyContent.includes("# Second"))
        throw new Error(`# Second missing from body: ${JSON.stringify(s.bodyContent)}`);
      if (!s.bodyContent.includes("# Third"))
        throw new Error(`# Third missing from body: ${JSON.stringify(s.bodyContent)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC3: two consecutive `---` lines produce SLIDE_TITLE_MISSING (Edge #3)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# A\nbody\n---\n---\n# B\nbody";
      let thrown = false;
      let isError = false;
      let message = "";
      try {
        compiler.parse(md);
      } catch (e: any) {
        thrown = true;
        isError = e instanceof Error;
        message = e instanceof Error ? e.message : String(e);
      }
      if (!thrown) throw new Error("did not throw");
      if (!isError) throw new Error("thrown value is not Error instance");
      if (message !== "SLIDE_TITLE_MISSING")
        throw new Error(`message: ${JSON.stringify(message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC4: when the first non-blank line is `---`, parser throws SLIDE_TITLE_MISSING (Edge #4)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "\n\n---\n# A\nbody";
      let thrown = false;
      let message = "";
      try {
        compiler.parse(md);
      } catch (e: any) {
        thrown = true;
        message = e instanceof Error ? e.message : String(e);
      }
      if (!thrown) throw new Error("did not throw");
      if (message !== "SLIDE_TITLE_MISSING")
        throw new Error(`message: ${JSON.stringify(message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC5: when the final non-blank line is `---`, parser throws SLIDE_TITLE_MISSING (Edge #5)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# A\nbody\n---\n\n";
      let thrown = false;
      let message = "";
      try {
        compiler.parse(md);
      } catch (e: any) {
        thrown = true;
        message = e instanceof Error ? e.message : String(e);
      }
      if (!thrown) throw new Error("did not throw");
      if (message !== "SLIDE_TITLE_MISSING")
        throw new Error(`message: ${JSON.stringify(message)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC6: a `:::notes` block whose content is whitespace-only yields speakerNotes = `\"\"` (Edge #6)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody\n:::notes\n   \n\t\n  \n:::";
      const deck = compiler.parse(md);
      if (deck.slides[0].speakerNotes !== "")
        throw new Error(
          `speakerNotes: ${JSON.stringify(deck.slides[0].speakerNotes)}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC7: a themeOverride entry whose value is `undefined` is treated as absent (Edge #7)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const dt = defaultTheme();
      const compiler = new mod.SlideDeckCompiler(dt);
      const deck = compiler.parse("# T\nbody");
      const html: string = compiler.renderHtml(deck, {
        accentColor: undefined,
      });
      const decls = rootDeclarations(html);
      if (decls["--accent-color"] !== dt.accentColor)
        throw new Error(
          `--accent-color expected ${dt.accentColor}, got ${decls["--accent-color"]}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC8: `![](src)` produces a SlideImage whose altText is `\"\"` (Edge #8)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const deck = compiler.parse("# T\n![](pic.png)");
      const img = deck.slides[0].images[0];
      if (!img) throw new Error("no image extracted");
      if (img.altText !== "")
        throw new Error(`altText: ${JSON.stringify(img.altText)}`);
      if (img.source !== "pic.png")
        throw new Error(`source: ${JSON.stringify(img.source)}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC9: a non-alphanumeric language tag (e.g. `c++`) passes through verbatim (Edge #9)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\n" + fenceBlock("c++", "int main() { return 0; }");
      const deck = compiler.parse(md);
      const cb = deck.slides[0].codeBlocks[0];
      if (cb.language !== "c++")
        throw new Error(`language: ${JSON.stringify(cb.language)}`);
      const m = cb.highlightedHtml.match(
        /<code\b[^>]*\bclass\s*=\s*"([^"]*)"/,
      );
      if (!m) throw new Error("no class on <code>");
      if (!m[1].includes("language-c++"))
        throw new Error(`class missing 'language-c++': ${m[1]}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC10: a themeOverride key that is not in DeckTheme is ignored during merge (Edge #10)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const dt = defaultTheme();
      const compiler = new mod.SlideDeckCompiler(dt);
      const deck = compiler.parse("# T\nbody");
      const sentinel = "BOGUS_SENTINEL_VALUE_xY7Q";
      const html: string = compiler.renderHtml(deck, {
        bogus: sentinel,
        anotherBogus: 999,
      });
      if (html.includes(sentinel))
        throw new Error("unknown key value leaked into rendered HTML");
      const decls = rootDeclarations(html);
      const expected: Record<string, string> = {
        "--font-family": dt.fontFamily,
        "--background-color": dt.backgroundColor,
        "--text-color": dt.textColor,
        "--accent-color": dt.accentColor,
        "--code-theme": dt.codeTheme,
        "--slide-padding": `${dt.slidePaddingPx}px`,
      };
      for (const [k, v] of Object.entries(expected)) {
        if (decls[k] !== v)
          throw new Error(`expected ${k}=${v}, got ${decls[k]}`);
      }
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("EC11: non-ASCII UTF-8 characters are preserved verbatim in all five slide fields (Input format: UTF-8 markdown text)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = [
        "# 日本語タイトル",
        "— em dash in body —",
        "![ñ alt text](π.png)",
        fenceBlock("py", "résumé = '日本語'"),
        ":::notes",
        "Ñoño speaker notes",
        ":::",
      ].join("\n");
      const deck = compiler.parse(md);
      if (!deck.slides[0]) throw new Error("no slides parsed");
      const s = deck.slides[0];

      if (s.title !== "日本語タイトル")
        throw new Error(`title: expected "日本語タイトル", got ${JSON.stringify(s.title)}`);

      if (s.bodyContent !== "— em dash in body —")
        throw new Error(`bodyContent: expected "— em dash in body —", got ${JSON.stringify(s.bodyContent)}`);

      if (s.images[0]?.altText !== "ñ alt text")
        throw new Error(`images[0].altText: expected "ñ alt text", got ${JSON.stringify(s.images[0]?.altText)}`);

      if (s.images[0]?.source !== "π.png")
        throw new Error(`images[0].source: expected "π.png", got ${JSON.stringify(s.images[0]?.source)}`);

      if (s.codeBlocks[0]?.rawCode !== "résumé = '日本語'")
        throw new Error(`codeBlocks[0].rawCode: expected "résumé = '日本語'", got ${JSON.stringify(s.codeBlocks[0]?.rawCode)}`);

      if (s.speakerNotes !== "Ñoño speaker notes")
        throw new Error(`speakerNotes: expected "Ñoño speaker notes", got ${JSON.stringify(s.speakerNotes)}`);

      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});