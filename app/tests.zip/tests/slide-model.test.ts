// Tests for the Typed Slide Model contract — specifically the structural and
// semantic guarantees of `highlightedHtml` (Slide Model #7).

import { describe, it, expect } from "vitest";
import {
  loadModule,
  defaultTheme,
  fenceBlock,
  decodeEntities,
  stripTags,
} from "./helpers";

describe("Typed Slide Model — highlightedHtml properties", () => {
  it("M1: every parsed slide exposes the six required fields (Slide Model #1)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\nbody\n![a](b.png)\n" + fenceBlock("ts", "x");
      const deck = compiler.parse(md);
      const s = deck.slides[0];
      const required = [
        "title",
        "bodyContent",
        "images",
        "codeBlocks",
        "speakerNotes",
        "order",
      ];
      for (const k of required) {
        if (!(k in s)) throw new Error(`missing field: ${k}`);
      }
      if (typeof s.title !== "string") throw new Error("title not string");
      if (typeof s.bodyContent !== "string")
        throw new Error("bodyContent not string");
      if (!Array.isArray(s.images)) throw new Error("images not array");
      if (!Array.isArray(s.codeBlocks)) throw new Error("codeBlocks not array");
      if (typeof s.speakerNotes !== "string")
        throw new Error("speakerNotes not string");
      if (typeof s.order !== "number") throw new Error("order not number");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("M2: `highlightedHtml` is a non-empty string (Slide Model #7)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\n" + fenceBlock("ts", "const x = 1;");
      const deck = compiler.parse(md);
      const html = deck.slides[0].codeBlocks[0].highlightedHtml;
      if (typeof html !== "string") throw new Error("not a string");
      if (html.length === 0) throw new Error("empty string");
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("M3: outermost element is exactly one `<pre>` wrapping exactly one `<code>` (Slide Model #7)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\n" + fenceBlock("ts", "const x = 1;");
      const deck = compiler.parse(md);
      const html: string = deck.slides[0].codeBlocks[0].highlightedHtml.trim();
      if (!/^<pre[\s\S]*<\/pre>\s*$/.test(html))
        throw new Error(`outermost not <pre>: ${html.slice(0, 80)}`);
      const preOpens = (html.match(/<pre[\s>]/g) || []).length;
      const preCloses = (html.match(/<\/pre>/g) || []).length;
      if (preOpens !== 1 || preCloses !== 1)
        throw new Error(`<pre> count: opens=${preOpens} closes=${preCloses}`);
      const codeOpens = (html.match(/<code[\s>]/g) || []).length;
      const codeCloses = (html.match(/<\/code>/g) || []).length;
      if (codeOpens !== 1 || codeCloses !== 1)
        throw new Error(`<code> count: opens=${codeOpens} closes=${codeCloses}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("M4: `<code>` carries a class containing the literal `language-<language>` token (Slide Model #7)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\n" + fenceBlock("ts", "const x = 1;");
      const deck = compiler.parse(md);
      const cb = deck.slides[0].codeBlocks[0];
      const html: string = cb.highlightedHtml;
      const m = html.match(/<code\b[^>]*\bclass\s*=\s*"([^"]*)"/);
      if (!m)
        throw new Error(`no class on <code>: ${html.slice(0, 100)}`);
      const classValue = m[1];
      const expectedToken = `language-${cb.language}`;
      if (!classValue.includes(expectedToken))
        throw new Error(`class "${classValue}" missing token "${expectedToken}"`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("M5: `<code>` contains at least one `<span>` (Slide Model #7)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const md = "# T\n" + fenceBlock("ts", "const x = 1;");
      const deck = compiler.parse(md);
      const html: string = deck.slides[0].codeBlocks[0].highlightedHtml;
      const spanOpens = (html.match(/<span[\s>]/g) || []).length;
      if (spanOpens < 1)
        throw new Error(`expected ≥1 <span>, got ${spanOpens}`);
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });

  it("M6: decoded textual content of `<code>` equals `rawCode` byte-for-byte (Slide Model #7)", async () => {
    let pass = false;
    let info = "";
    try {
      const mod = await loadModule();
      if (!mod) throw new Error("Module not loadable");
      const compiler = new mod.SlideDeckCompiler(defaultTheme());
      const code = ['const s = "x" + \'y\';', "if (a < b && b > c) {}", "}"].join(
        "\n",
      );
      const md = "# T\n" + fenceBlock("ts", code);
      const deck = compiler.parse(md);
      const cb = deck.slides[0].codeBlocks[0];
      const html: string = cb.highlightedHtml;
      const inner = html
        .replace(/^[\s\S]*?<code\b[^>]*>/, "")
        .replace(/<\/code>[\s\S]*$/, "");
      const text = decodeEntities(stripTags(inner));
      if (text !== cb.rawCode)
        throw new Error(
          `decoded text != rawCode\nexpected=${JSON.stringify(cb.rawCode)}\nactual=${JSON.stringify(text)}`,
        );
      pass = true;
    } catch (e: any) {
      info = String(e?.message ?? e);
    }
    expect(pass, info).toBe(true);
  });
});
