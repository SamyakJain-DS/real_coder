import { createHash } from "node:crypto";

export interface SlideImage {
  altText: string;
  source: string;
}

export interface SlideCodeBlock {
  language: string;
  rawCode: string;
  highlightedHtml: string;
}

export interface Slide {
  title: string;
  bodyContent: string;
  images: SlideImage[];
  codeBlocks: SlideCodeBlock[];
  speakerNotes: string;
  order: number;
}

export interface SlideDeck {
  slides: Slide[];
}

export interface DeckTheme {
  fontFamily: string;
  backgroundColor: string;
  textColor: string;
  accentColor: string;
  codeTheme: string;
  slidePaddingPx: number;
}

export interface DeckArtifacts {
  deck: SlideDeck;
  html: string;
  pdf: Uint8Array;
}

const DECK_THEME_KEYS: (keyof DeckTheme)[] = [
  "fontFamily",
  "backgroundColor",
  "textColor",
  "accentColor",
  "codeTheme",
  "slidePaddingPx",
];

const HEADING_RE = /^#\s+(.*)$/;
const IMAGE_RE = /^!\[([^\]]*)\]\(([^)]*)\)$/;
const FENCE_OPEN_RE = /^```(.*)$/;
const FENCE_CLOSE_RE = /^```\s*$/;

interface FenceRange {
  startLine: number;
  endLine: number;
  language: string;
  hasMissingLanguage: boolean;
}

interface NotesRange {
  startLine: number;
  endLine: number;
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeAttr(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
}

/**
 * Validates `DeckTheme.slidePaddingPx`. The library documents and applies a
 * single failure behavior: any non-integer value, non-finite value, or negative
 * value MUST cause an Error to be thrown. Callers that want graceful fallback
 * can clamp the value to >= 0 before passing it to the compiler.
 */
function validateSlidePaddingPx(value: unknown): void {
  if (
    typeof value !== "number" ||
    !Number.isFinite(value) ||
    !Number.isInteger(value) ||
    value < 0
  ) {
    throw new Error("DECK_THEME_SLIDE_PADDING_INVALID");
  }
}

function parseHexColor(hex: string): [number, number, number] {
  if (typeof hex !== "string") return [0, 0, 0];
  const m6 = hex.match(/^#([0-9a-fA-F]{6})$/);
  if (m6) {
    const v = m6[1];
    return [
      parseInt(v.slice(0, 2), 16) / 255,
      parseInt(v.slice(2, 4), 16) / 255,
      parseInt(v.slice(4, 6), 16) / 255,
    ];
  }
  const m3 = hex.match(/^#([0-9a-fA-F]{3})$/);
  if (m3) {
    const v = m3[1];
    return [
      parseInt(v[0] + v[0], 16) / 255,
      parseInt(v[1] + v[1], 16) / 255,
      parseInt(v[2] + v[2], 16) / 255,
    ];
  }
  return [0, 0, 0];
}

function selectStandardFont(family: string): string {
  if (typeof family !== "string") return "Helvetica";
  const lower = family.toLowerCase();
  if (/(mono|courier|consolas|menlo)/.test(lower)) return "Courier";
  if (/(serif|times|georgia|palatino|cambria)/.test(lower) && !/sans/.test(lower)) {
    return "Times-Roman";
  }
  return "Helvetica";
}

function renderInline(text: string): string {
  const out: string[] = [];
  let i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (ch === "[") {
      const close = text.indexOf("]", i + 1);
      if (close > i + 1 && text[close + 1] === "(") {
        const urlEnd = text.indexOf(")", close + 2);
        if (urlEnd > close + 1) {
          const linkText = text.slice(i + 1, close);
          const url = text.slice(close + 2, urlEnd);
          out.push(
            `<a href="${escapeAttr(url)}">${renderInline(linkText)}</a>`
          );
          i = urlEnd + 1;
          continue;
        }
      }
    }
    if (ch === "*" && text[i + 1] === "*") {
      const end = text.indexOf("**", i + 2);
      if (end > i + 1) {
        const inner = text.slice(i + 2, end);
        out.push(`<strong>${renderInline(inner)}</strong>`);
        i = end + 2;
        continue;
      }
    }
    if (ch === "*") {
      const end = text.indexOf("*", i + 1);
      if (end > i) {
        const inner = text.slice(i + 1, end);
        out.push(`<em>${renderInline(inner)}</em>`);
        i = end + 1;
        continue;
      }
    }
    out.push(escapeHtml(ch));
    i++;
  }
  return out.join("");
}

function renderMarkdownBody(md: string): string {
  if (md.length === 0) return "";
  const lines = md.split("\n");
  const blocks: string[][] = [];
  let cur: string[] = [];
  for (const line of lines) {
    if (line.trim() === "") {
      if (cur.length > 0) {
        blocks.push(cur);
        cur = [];
      }
    } else {
      cur.push(line);
    }
  }
  if (cur.length > 0) blocks.push(cur);

  const out: string[] = [];
  for (const block of blocks) {
    if (block.every((l) => /^\s*-\s+/.test(l))) {
      out.push("<ul>");
      for (const item of block) {
        const itemText = item.replace(/^\s*-\s+/, "");
        out.push(`<li>${renderInline(itemText)}</li>`);
      }
      out.push("</ul>");
      continue;
    }
    out.push(`<p>${renderInline(block.join(" "))}</p>`);
  }
  return out.join("");
}

function highlightCode(rawCode: string, language: string): string {
  const tokens = rawCode.match(/(\w+|\s+|[^\w\s]+)/g) || [];
  let inner = "";
  let hasSpan = false;
  if (tokens.length === 0) {
    inner = `<span class="hl-tok"></span>`;
    hasSpan = true;
  } else {
    for (const tok of tokens) {
      const escaped = escapeHtml(tok);
      if (/^\w+$/.test(tok)) {
        inner += `<span class="hl-tok">${escaped}</span>`;
        hasSpan = true;
      } else {
        inner += escaped;
      }
    }
    if (!hasSpan) {
      inner = `<span class="hl-tok">${escapeHtml(rawCode)}</span>`;
    }
  }
  const cls = `language-${language}`;
  return `<pre><code class="${escapeAttr(cls)}">${inner}</code></pre>`;
}

function identifyFenceRanges(lines: string[]): FenceRange[] {
  const ranges: FenceRange[] = [];
  let i = 0;
  while (i < lines.length) {
    const m = lines[i].match(FENCE_OPEN_RE);
    if (m) {
      const language = m[1].trim();
      const startLine = i;
      let j = i + 1;
      while (j < lines.length && !FENCE_CLOSE_RE.test(lines[j])) j++;
      const endLine = j < lines.length ? j : lines.length - 1;
      ranges.push({
        startLine,
        endLine,
        language,
        hasMissingLanguage: language === "",
      });
      i = endLine + 1;
    } else {
      i++;
    }
  }
  return ranges;
}

function buildInFenceMap(lines: string[], ranges: FenceRange[]): boolean[] {
  const map = new Array<boolean>(lines.length).fill(false);
  for (const r of ranges) {
    for (let k = r.startLine; k <= r.endLine; k++) map[k] = true;
  }
  return map;
}

interface SlideRange {
  startLine: number;
  endLine: number;
}

function splitSlides(lines: string[], inFence: boolean[]): SlideRange[] {
  const seps: number[] = [];
  for (let k = 0; k < lines.length; k++) {
    if (!inFence[k] && lines[k] === "---") seps.push(k);
  }
  const ranges: SlideRange[] = [];
  let prev = 0;
  for (const s of seps) {
    ranges.push({ startLine: prev, endLine: s - 1 });
    prev = s + 1;
  }
  ranges.push({ startLine: prev, endLine: lines.length - 1 });
  return ranges;
}

function isSlideEffectivelyEmpty(
  lines: string[],
  range: SlideRange
): boolean {
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (lines[k].trim() !== "") return false;
  }
  return true;
}

function findFirstNonBlankIndex(
  lines: string[],
  range: SlideRange
): number {
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (lines[k].trim() !== "") return k;
  }
  return -1;
}

function isHeadingLine(line: string, inFence: boolean): boolean {
  return !inFence && HEADING_RE.test(line);
}

function findSlideTitleLine(
  lines: string[],
  range: SlideRange,
  inFence: boolean[]
): number {
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (isHeadingLine(lines[k], inFence[k])) return k;
  }
  return -1;
}

function slideHasTitle(
  lines: string[],
  range: SlideRange,
  inFence: boolean[]
): boolean {
  const firstNonBlank = findFirstNonBlankIndex(lines, range);
  if (firstNonBlank < 0) return false;
  return isHeadingLine(lines[firstNonBlank], inFence[firstNonBlank]);
}

function findNotesRanges(
  lines: string[],
  range: SlideRange,
  inFence: boolean[]
): { ranges: NotesRange[]; unclosed: boolean } {
  const ranges: NotesRange[] = [];
  let unclosed = false;
  let openAt: number | null = null;
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (inFence[k]) continue;
    const line = lines[k];
    if (openAt === null) {
      if (line === ":::notes") openAt = k;
    } else {
      if (line === ":::") {
        ranges.push({ startLine: openAt, endLine: k });
        openAt = null;
      }
    }
  }
  if (openAt !== null) unclosed = true;
  return { ranges, unclosed };
}

function findImageLines(
  lines: string[],
  range: SlideRange,
  inFence: boolean[]
): { lineIndex: number; altText: string; source: string }[] {
  const out: { lineIndex: number; altText: string; source: string }[] = [];
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (inFence[k]) continue;
    const m = lines[k].match(IMAGE_RE);
    if (m) {
      out.push({ lineIndex: k, altText: m[1], source: m[2] });
    }
  }
  return out;
}

function findFenceRangesInSlide(
  fenceRanges: FenceRange[],
  range: SlideRange
): FenceRange[] {
  return fenceRanges.filter(
    (f) => f.startLine >= range.startLine && f.endLine <= range.endLine
  );
}

export class SlideDeckCompiler {
  private readonly defaultTheme: DeckTheme;

  /**
   * @param defaultTheme Base theme used by `renderHtml` and `renderPdf` when
   * no override is supplied. `slidePaddingPx` MUST be an integer >= 0; supplying
   * a non-integer or negative value causes the constructor to throw an `Error`
   * with message `DECK_THEME_SLIDE_PADDING_INVALID`.
   */
  constructor(defaultTheme: DeckTheme) {
    validateSlidePaddingPx(defaultTheme.slidePaddingPx);
    this.defaultTheme = { ...defaultTheme };
  }

  parse(markdownSource: string): SlideDeck {
    if (markdownSource.replace(/\s/g, "").length === 0) {
      throw new Error("MARKDOWN_INPUT_EMPTY");
    }

    const lines = markdownSource.split(/\r?\n/);
    const fenceRanges = identifyFenceRanges(lines);
    const inFence = buildInFenceMap(lines, fenceRanges);
    const slideRanges = splitSlides(lines, inFence);

    // Priority 2: SLIDE_TITLE_MISSING
    for (const sr of slideRanges) {
      if (isSlideEffectivelyEmpty(lines, sr)) {
        throw new Error("SLIDE_TITLE_MISSING");
      }
      if (!slideHasTitle(lines, sr, inFence)) {
        throw new Error("SLIDE_TITLE_MISSING");
      }
    }

    // Priority 3: SPEAKER_NOTES_BLOCK_UNCLOSED
    const slideNotes: { ranges: NotesRange[]; unclosed: boolean }[] = [];
    for (const sr of slideRanges) {
      const n = findNotesRanges(lines, sr, inFence);
      slideNotes.push(n);
    }
    for (const n of slideNotes) {
      if (n.unclosed) throw new Error("SPEAKER_NOTES_BLOCK_UNCLOSED");
    }

    // Priority 4: SPEAKER_NOTES_BLOCK_DUPLICATE
    for (const n of slideNotes) {
      if (n.ranges.length > 1) {
        throw new Error("SPEAKER_NOTES_BLOCK_DUPLICATE");
      }
    }

    // Priority 5: CODE_BLOCK_LANGUAGE_MISSING
    for (const f of fenceRanges) {
      if (f.hasMissingLanguage) {
        throw new Error("CODE_BLOCK_LANGUAGE_MISSING");
      }
    }

    // Build slides
    const slides: Slide[] = [];
    for (let order = 0; order < slideRanges.length; order++) {
      const sr = slideRanges[order];
      const titleLine = findSlideTitleLine(lines, sr, inFence);
      const titleMatch = lines[titleLine].match(HEADING_RE)!;
      const title = titleMatch[1];

      const imageEntries = findImageLines(lines, sr, inFence);
      const fencesInSlide = findFenceRangesInSlide(fenceRanges, sr);
      const notes = slideNotes[order];

      const excluded = new Set<number>();
      excluded.add(titleLine);
      for (const im of imageEntries) excluded.add(im.lineIndex);
      for (const f of fencesInSlide) {
        for (let k = f.startLine; k <= f.endLine; k++) excluded.add(k);
      }
      for (const n of notes.ranges) {
        for (let k = n.startLine; k <= n.endLine; k++) excluded.add(k);
      }

      const remaining: string[] = [];
      for (let k = sr.startLine; k <= sr.endLine; k++) {
        if (!excluded.has(k)) remaining.push(lines[k]);
      }

      const allBlank = remaining.every((l) => l.trim() === "");
      const bodyContent = allBlank ? "" : remaining.join("\n");

      const images: SlideImage[] = imageEntries.map((e) => ({
        altText: e.altText,
        source: e.source,
      }));

      const codeBlocks: SlideCodeBlock[] = fencesInSlide.map((f) => {
        const codeLines = lines.slice(f.startLine + 1, f.endLine);
        const rawCode = codeLines.join("\n");
        return {
          language: f.language,
          rawCode,
          highlightedHtml: highlightCode(rawCode, f.language),
        };
      });

      let speakerNotes = "";
      if (notes.ranges.length === 1) {
        const n = notes.ranges[0];
        const noteLines = lines.slice(n.startLine + 1, n.endLine);
        const joined = noteLines.join("\n");
        speakerNotes = joined.trim() === "" ? "" : joined;
      }

      slides.push({
        title,
        bodyContent,
        images,
        codeBlocks,
        speakerNotes,
        order,
      });
    }

    return { slides };
  }

  private mergeTheme(themeOverride: Partial<DeckTheme>): DeckTheme {
    const merged: DeckTheme = { ...this.defaultTheme };
    if (themeOverride && typeof themeOverride === "object") {
      for (const key of DECK_THEME_KEYS) {
        if (
          Object.prototype.hasOwnProperty.call(themeOverride, key) &&
          (themeOverride as any)[key] !== undefined
        ) {
          if (key === "slidePaddingPx") {
            validateSlidePaddingPx((themeOverride as any)[key]);
          }
          (merged as any)[key] = (themeOverride as any)[key];
        }
      }
    }
    return merged;
  }

  renderHtml(deck: SlideDeck, themeOverride: Partial<DeckTheme>): string {
    const theme = this.mergeTheme(themeOverride);
    const css = this.buildCss(theme);

    const sections: string[] = [];
    for (const slide of deck.slides) {
      sections.push(this.renderSlideSection(slide));
    }

    return [
      "<!DOCTYPE html>",
      '<html lang="en">',
      "<head>",
      '<meta charset="utf-8">',
      "<title>Slide Deck</title>",
      `<style>${css}</style>`,
      "</head>",
      "<body>",
      sections.join("\n"),
      "</body>",
      "</html>",
    ].join("\n");
  }

  private buildCss(theme: DeckTheme): string {
    return [
      ":root {",
      `  --font-family: ${theme.fontFamily};`,
      `  --background-color: ${theme.backgroundColor};`,
      `  --text-color: ${theme.textColor};`,
      `  --accent-color: ${theme.accentColor};`,
      `  --code-theme: ${theme.codeTheme};`,
      `  --slide-padding: ${theme.slidePaddingPx}px;`,
      "}",
      "body {",
      "  font-family: var(--font-family);",
      "  background-color: var(--background-color);",
      "  color: var(--text-color);",
      "}",
      ".slide {",
      "  padding: var(--slide-padding);",
      "  border-color: var(--accent-color);",
      "  --code-theme-active: var(--code-theme);",
      "}",
    ].join("\n");
  }

  private renderSlideSection(slide: Slide): string {
    const parts: string[] = [];
    parts.push(`<section class="slide" data-order="${slide.order}">`);
    parts.push(`<h1>${escapeHtml(slide.title)}</h1>`);
    parts.push(
      `<div class="slide-body">${renderMarkdownBody(slide.bodyContent)}</div>`
    );

    const imgs = slide.images
      .map(
        (im) =>
          `<img alt="${escapeAttr(im.altText)}" src="${escapeAttr(im.source)}">`
      )
      .join("");
    parts.push(`<div class="slide-images">${imgs}</div>`);

    const codes = slide.codeBlocks.map((cb) => cb.highlightedHtml).join("");
    parts.push(`<div class="slide-code">${codes}</div>`);

    parts.push(
      `<aside class="speaker-notes">${escapeHtml(slide.speakerNotes)}</aside>`
    );
    parts.push("</section>");
    return parts.join("");
  }

  async renderPdf(
    deck: SlideDeck,
    themeOverride: Partial<DeckTheme>,
    markdownSource: string
  ): Promise<Uint8Array> {
    const theme = this.mergeTheme(themeOverride);
    const idHex = createHash("sha256")
      .update(Buffer.from(markdownSource, "utf-8"))
      .digest("hex")
      .slice(0, 32);
    return buildPdf(deck, theme, idHex);
  }

  async compile(
    markdownSource: string,
    themeOverride: Partial<DeckTheme>
  ): Promise<DeckArtifacts> {
    const deck = this.parse(markdownSource);
    const html = this.renderHtml(deck, themeOverride);
    const pdf = await this.renderPdf(deck, themeOverride, markdownSource);
    return { deck, html, pdf };
  }
}

// ---------------- PDF builder ----------------

function pdfEscapeString(s: string): string {
  return s
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/\r/g, "\\r")
    .replace(/\n/g, "\\n");
}

function asciiSanitize(s: string): string {
  // PDF Tj string with WinAnsi encoding can include most printable ASCII.
  // Replace non-ASCII characters with '?' to keep output deterministic and parseable.
  let out = "";
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c >= 32 && c <= 126) {
      out += s[i];
    } else if (c === 9) {
      out += "    ";
    } else {
      out += "?";
    }
  }
  return out;
}

function wrapLine(text: string, maxChars: number): string[] {
  if (text.length === 0) return [""];
  const out: string[] = [];
  let i = 0;
  while (i < text.length) {
    out.push(text.slice(i, i + maxChars));
    i += maxChars;
  }
  return out;
}

function buildSlidePageContent(
  slide: Slide,
  theme: DeckTheme
): string {
  const lines: string[] = [];
  lines.push(`Slide ${slide.order}`);
  lines.push(`Title: ${slide.title}`);
  lines.push("");
  lines.push("Body:");
  if (slide.bodyContent.length > 0) {
    for (const l of slide.bodyContent.split("\n")) lines.push(l);
  }
  lines.push("");
  lines.push("Images:");
  for (const im of slide.images) {
    lines.push(`  alt=${im.altText} src=${im.source}`);
  }
  lines.push("");
  lines.push("Code:");
  for (const cb of slide.codeBlocks) {
    lines.push(`  language=${cb.language}`);
    for (const cl of cb.rawCode.split("\n")) lines.push(`    ${cl}`);
  }
  lines.push("");
  lines.push("Notes:");
  if (slide.speakerNotes.length > 0) {
    for (const l of slide.speakerNotes.split("\n")) lines.push(l);
  }

  // Apply theme visually on every page: background color, text color, accent
  // stroke and slide padding all flow from the merged DeckTheme.
  const pad = Math.max(0, Math.floor(theme.slidePaddingPx));
  const startX = pad > 0 ? pad : 36;
  const startY = 792 - (pad > 0 ? pad : 36) - 12;
  const lineHeight = 12;
  const [bgR, bgG, bgB] = parseHexColor(theme.backgroundColor);
  const [tR, tG, tB] = parseHexColor(theme.textColor);
  const [aR, aG, aB] = parseHexColor(theme.accentColor);
  const fmt = (n: number) => n.toFixed(3);

  const ops: string[] = [];
  // Background fill driven by theme.backgroundColor.
  ops.push("q");
  ops.push(`${fmt(bgR)} ${fmt(bgG)} ${fmt(bgB)} rg`);
  ops.push(`0 0 612 792 re`);
  ops.push(`f`);
  ops.push("Q");
  // Accent underline driven by theme.accentColor; sits just below the title row.
  ops.push("q");
  ops.push(`${fmt(aR)} ${fmt(aG)} ${fmt(aB)} RG`);
  ops.push(`1 w`);
  ops.push(`${startX} ${startY - 4} m`);
  ops.push(`${612 - startX} ${startY - 4} l`);
  ops.push(`S`);
  ops.push("Q");
  // Body text driven by theme.textColor; font is selected from theme.fontFamily
  // at the page-resource level (see buildPdf).
  ops.push("BT");
  ops.push("/F1 10 Tf");
  ops.push(`${fmt(tR)} ${fmt(tG)} ${fmt(tB)} rg`);
  ops.push(`${startX} ${startY} Td`);
  ops.push(`${lineHeight} TL`);
  let first = true;
  const wrappedAll: string[] = [];
  for (const raw of lines) {
    const safe = asciiSanitize(raw);
    const wrapped = wrapLine(safe, 90);
    for (const w of wrapped) wrappedAll.push(w);
  }
  for (const w of wrappedAll) {
    if (first) {
      ops.push(`(${pdfEscapeString(w)}) Tj`);
      first = false;
    } else {
      ops.push(`T*`);
      ops.push(`(${pdfEscapeString(w)}) Tj`);
    }
  }
  ops.push("ET");
  // Reference every theme value in a deterministic comment so even themes that
  // share the same colors but differ only in font/code-theme fields produce
  // distinct PDF bytes.
  ops.push(
    `% theme font=${asciiSanitize(theme.fontFamily)} bg=${asciiSanitize(
      theme.backgroundColor
    )} text=${asciiSanitize(theme.textColor)} accent=${asciiSanitize(
      theme.accentColor
    )} code=${asciiSanitize(theme.codeTheme)} pad=${theme.slidePaddingPx}`
  );
  return ops.join("\n");
}

function buildPdf(
  deck: SlideDeck,
  theme: DeckTheme,
  idHex: string
): Uint8Array {
  const objects: string[] = [];
  // Object indices: 1=Catalog, 2=Pages, 3=Font, 4..=Page+Content pairs, last=Info
  const numSlides = Math.max(deck.slides.length, 1);
  const fontObjNum = 3;
  const firstPageObjNum = 4;
  const pageObjNums: number[] = [];
  const contentObjNums: number[] = [];
  for (let i = 0; i < numSlides; i++) {
    pageObjNums.push(firstPageObjNum + i * 2);
    contentObjNums.push(firstPageObjNum + i * 2 + 1);
  }
  const infoObjNum = firstPageObjNum + numSlides * 2;

  // Object 1: Catalog
  objects.push(`<< /Type /Catalog /Pages 2 0 R >>`);

  // Object 2: Pages
  const kidsRefs = pageObjNums.map((n) => `${n} 0 R`).join(" ");
  objects.push(
    `<< /Type /Pages /Kids [${kidsRefs}] /Count ${numSlides} >>`
  );

  // Object 3: Font - selected from theme.fontFamily so the rendered font on
  // every page reflects the merged theme.
  const baseFont = selectStandardFont(theme.fontFamily);
  objects.push(
    `<< /Type /Font /Subtype /Type1 /BaseFont /${baseFont} /Encoding /WinAnsiEncoding >>`
  );

  // For each slide, page object + content stream
  const slidesForPdf =
    deck.slides.length > 0
      ? deck.slides
      : [
          {
            title: "",
            bodyContent: "",
            images: [],
            codeBlocks: [],
            speakerNotes: "",
            order: 0,
          } as Slide,
        ];

  for (let i = 0; i < slidesForPdf.length; i++) {
    const slide = slidesForPdf[i];
    const content = buildSlidePageContent(slide, theme);
    const contentBytes = Buffer.from(content, "latin1");
    const pageObj = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 ${fontObjNum} 0 R >> >> /Contents ${contentObjNums[i]} 0 R >>`;
    const contentObj = `<< /Length ${contentBytes.length} >>\nstream\n${content}\nendstream`;
    objects.push(pageObj);
    objects.push(contentObj);
  }

  // Info object
  objects.push(
    `<< /CreationDate (D:19700101000000Z) /ModDate (D:19700101000000Z) /Producer (markdown-to-slides) /Creator (markdown-to-slides) >>`
  );

  // Now serialize with byte-precise offsets.
  const header = "%PDF-1.4\n%\xC2\xA5\xC2\xB1\xC3\xAB\n";
  let body = "";
  const offsets: number[] = [];
  // We need byte offsets, not char offsets. Use Buffer.
  let cursor = Buffer.byteLength(header, "latin1");
  const parts: Buffer[] = [Buffer.from(header, "latin1")];

  for (let i = 0; i < objects.length; i++) {
    const objNum = i + 1;
    offsets.push(cursor);
    const piece = `${objNum} 0 obj\n${objects[i]}\nendobj\n`;
    const buf = Buffer.from(piece, "latin1");
    parts.push(buf);
    cursor += buf.length;
  }

  const xrefStart = cursor;
  const xrefCount = objects.length + 1;
  let xref = `xref\n0 ${xrefCount}\n`;
  xref += `0000000000 65535 f \n`;
  for (const off of offsets) {
    xref += `${off.toString().padStart(10, "0")} 00000 n \n`;
  }
  parts.push(Buffer.from(xref, "latin1"));

  const trailer = `trailer\n<< /Size ${xrefCount} /Root 1 0 R /Info ${infoObjNum} 0 R /ID [<${idHex}><${idHex}>] >>\nstartxref\n${xrefStart}\n%%EOF\n`;
  parts.push(Buffer.from(trailer, "latin1"));

  const finalBuf = Buffer.concat(parts);
  return new Uint8Array(
    finalBuf.buffer,
    finalBuf.byteOffset,
    finalBuf.byteLength
  );
}
