import sqlite3
import json
from flask import Flask, request, jsonify

app = Flask(__name__)

DB_PATH = "faa_platform.db"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS ops_specs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            carrier_id TEXT NOT NULL,
            authorized_operations TEXT NOT NULL,
            aircraft_type_ratings TEXT NOT NULL,
            effective_date TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS inspector_assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            carrier_id TEXT NOT NULL,
            inspector_id TEXT NOT NULL,
            cmo_id TEXT NOT NULL,
            assignment_date TEXT NOT NULL,
            role TEXT NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS surveillance_activities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            carrier_id TEXT NOT NULL,
            activity_type TEXT NOT NULL,
            scheduled_date TEXT NOT NULL,
            inspector_id TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS voluntary_disclosures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            carrier_id TEXT NOT NULL,
            disclosure_date TEXT NOT NULL,
            description TEXT NOT NULL,
            submitted_by TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS enforcement_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            carrier_id TEXT NOT NULL,
            inspector_id TEXT NOT NULL,
            finding_id TEXT NOT NULL,
            action_type TEXT NOT NULL,
            initiated_date TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS emergency_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            carrier_id TEXT NOT NULL,
            action_type TEXT NOT NULL,
            reason TEXT NOT NULL,
            issued_date TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS ad_compliance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            carrier_id TEXT NOT NULL,
            ad_id TEXT NOT NULL,
            compliance_status TEXT NOT NULL,
            due_date TEXT NOT NULL,
            notes TEXT NOT NULL
        )
    """)

    # Seed data for 5 carriers
    carriers = ["AA001", "UA002", "DL003", "SW004", "FX005"]

    # Check if already seeded
    c.execute("SELECT COUNT(*) FROM ops_specs")
    if c.fetchone()[0] == 0:
        # ops_specs seed
        ops_seed = [
            ("AA001", json.dumps(["scheduled_passenger", "domestic"]), json.dumps(["B737", "B777"]), "2023-01-01", "active"),
            ("UA002", json.dumps(["scheduled_passenger", "international"]), json.dumps(["B787", "A320"]), "2023-02-01", "active"),
            ("DL003", json.dumps(["scheduled_passenger", "cargo"]), json.dumps(["B757", "A330"]), "2023-03-01", "active"),
            ("SW004", json.dumps(["scheduled_passenger"]), json.dumps(["B737"]), "2023-04-01", "active"),
            ("FX005", json.dumps(["cargo"]), json.dumps(["B767", "MD11"]), "2023-05-01", "active"),
        ]
        c.executemany(
            "INSERT INTO ops_specs (carrier_id, authorized_operations, aircraft_type_ratings, effective_date, status) VALUES (?,?,?,?,?)",
            ops_seed
        )

        # inspector_assignments seed
        insp_seed = [
            ("AA001", "INS001", "CMO-DFW", "2023-01-15", "Principal Inspector"),
            ("UA002", "INS002", "CMO-ORD", "2023-02-15", "Principal Inspector"),
            ("DL003", "INS003", "CMO-ATL", "2023-03-15", "Assistant Inspector"),
            ("SW004", "INS004", "CMO-DAL", "2023-04-15", "Principal Inspector"),
            ("FX005", "INS005", "CMO-MEM", "2023-05-15", "Principal Inspector"),
        ]
        c.executemany(
            "INSERT INTO inspector_assignments (carrier_id, inspector_id, cmo_id, assignment_date, role) VALUES (?,?,?,?,?)",
            insp_seed
        )

        # surveillance_activities seed
        surv_seed = [
            ("AA001", "Flight Operations", "2023-06-01", "INS001", "completed"),
            ("UA002", "Maintenance", "2023-06-10", "INS002", "scheduled"),
            ("DL003", "Cabin Safety", "2023-06-15", "INS003", "completed"),
            ("SW004", "Flight Operations", "2023-06-20", "INS004", "cancelled"),
            ("FX005", "Cargo Operations", "2023-06-25", "INS005", "scheduled"),
        ]
        c.executemany(
            "INSERT INTO surveillance_activities (carrier_id, activity_type, scheduled_date, inspector_id, status) VALUES (?,?,?,?,?)",
            surv_seed
        )

        # voluntary_disclosures seed
        disc_seed = [
            ("AA001", "2023-07-01", "Incorrect weight and balance procedure used.", "John Smith", "received"),
            ("UA002", "2023-07-05", "MEL item not properly deferred.", "Jane Doe", "under_review"),
            ("DL003", "2023-07-10", "Flight crew exceeded duty time limits.", "Bob Jones", "closed"),
            ("SW004", "2023-07-15", "Checklist deviation on departure.", "Alice Brown", "received"),
            ("FX005", "2023-07-20", "Hazmat documentation error.", "Charlie Davis", "under_review"),
        ]
        c.executemany(
            "INSERT INTO voluntary_disclosures (carrier_id, disclosure_date, description, submitted_by, status) VALUES (?,?,?,?,?)",
            disc_seed
        )

        # enforcement_actions seed
        enf_seed = [
            ("AA001", "INS001", "FIND-001", "Civil Penalty", "2023-08-01", "open"),
            ("UA002", "INS002", "FIND-002", "Certificate Action", "2023-08-05", "pending"),
            ("DL003", "INS003", "FIND-003", "Warning Notice", "2023-08-10", "closed"),
            ("SW004", "INS004", "FIND-004", "Civil Penalty", "2023-08-15", "open"),
            ("FX005", "INS005", "FIND-005", "Letter of Correction", "2023-08-20", "pending"),
        ]
        c.executemany(
            "INSERT INTO enforcement_actions (carrier_id, inspector_id, finding_id, action_type, initiated_date, status) VALUES (?,?,?,?,?,?)",
            enf_seed
        )

        # emergency_actions seed
        emerg_seed = [
            ("AA001", "revocation", "Serious safety violation discovered.", "2023-09-01", "issued"),
            ("UA002", "amendment", "Operations specifications update required.", "2023-09-05", "appealed"),
            ("DL003", "revocation", "Repeated non-compliance findings.", "2023-09-10", "final"),
            ("SW004", "amendment", "Route authorization change.", "2023-09-15", "issued"),
            ("FX005", "revocation", "Maintenance records falsification.", "2023-09-20", "appealed"),
        ]
        c.executemany(
            "INSERT INTO emergency_actions (carrier_id, action_type, reason, issued_date, status) VALUES (?,?,?,?,?)",
            emerg_seed
        )

        # ad_compliance seed
        ad_seed = [
            ("AA001", "AD-2023-001", "compliant", "2023-10-01", "AD applied to all applicable aircraft."),
            ("UA002", "AD-2023-002", "non_compliant", "2023-10-05", "Awaiting parts for compliance."),
            ("DL003", "AD-2023-003", "pending", "2023-10-10", "Review in progress."),
            ("SW004", "AD-2023-004", "compliant", "2023-10-15", "All aircraft updated."),
            ("FX005", "AD-2023-005", "pending", "2023-10-20", "Scheduled for next maintenance cycle."),
        ]
        c.executemany(
            "INSERT INTO ad_compliance (carrier_id, ad_id, compliance_status, due_date, notes) VALUES (?,?,?,?,?)",
            ad_seed
        )

    conn.commit()
    conn.close()


# Initialize DB on module import
init_db()


# --- Ops Specs ---------------------------------------------------------------

@app.route("/api/carriers/<carrier_id>/ops-specs", methods=["POST"])
def create_ops_spec(carrier_id):
    data = request.get_json()
    authorized_operations = json.dumps(data["authorized_operations"])
    aircraft_type_ratings = json.dumps(data["aircraft_type_ratings"])
    effective_date = data["effective_date"]
    status = data["status"]

    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO ops_specs (carrier_id, authorized_operations, aircraft_type_ratings, effective_date, status) VALUES (?,?,?,?,?)",
        (carrier_id, authorized_operations, aircraft_type_ratings, effective_date, status)
    )
    conn.commit()
    row_id = c.lastrowid
    c.execute("SELECT * FROM ops_specs WHERE id=?", (row_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "authorized_operations": json.loads(row["authorized_operations"]),
        "aircraft_type_ratings": json.loads(row["aircraft_type_ratings"]),
        "effective_date": row["effective_date"],
        "status": row["status"]
    }), 201


@app.route("/api/carriers/<carrier_id>/ops-specs", methods=["GET"])
def get_ops_specs(carrier_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM ops_specs WHERE carrier_id=?", (carrier_id,))
    rows = c.fetchall()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "id": row["id"],
            "carrier_id": row["carrier_id"],
            "authorized_operations": json.loads(row["authorized_operations"]),
            "aircraft_type_ratings": json.loads(row["aircraft_type_ratings"]),
            "effective_date": row["effective_date"],
            "status": row["status"]
        })
    return jsonify(result), 200


# --- Inspector Assignments ----------------------------------------------------

@app.route("/api/carriers/<carrier_id>/inspector-assignments", methods=["POST"])
def create_inspector_assignment(carrier_id):
    data = request.get_json()
    inspector_id = data["inspector_id"]
    cmo_id = data["cmo_id"]
    assignment_date = data["assignment_date"]
    role = data["role"]

    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO inspector_assignments (carrier_id, inspector_id, cmo_id, assignment_date, role) VALUES (?,?,?,?,?)",
        (carrier_id, inspector_id, cmo_id, assignment_date, role)
    )
    conn.commit()
    row_id = c.lastrowid
    c.execute("SELECT * FROM inspector_assignments WHERE id=?", (row_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "inspector_id": row["inspector_id"],
        "cmo_id": row["cmo_id"],
        "assignment_date": row["assignment_date"],
        "role": row["role"]
    }), 201


@app.route("/api/carriers/<carrier_id>/inspector-assignments", methods=["GET"])
def get_inspector_assignments(carrier_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM inspector_assignments WHERE carrier_id=?", (carrier_id,))
    rows = c.fetchall()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "id": row["id"],
            "carrier_id": row["carrier_id"],
            "inspector_id": row["inspector_id"],
            "cmo_id": row["cmo_id"],
            "assignment_date": row["assignment_date"],
            "role": row["role"]
        })
    return jsonify(result), 200


# --- Surveillance Activities --------------------------------------------------

@app.route("/api/carriers/<carrier_id>/surveillance", methods=["POST"])
def create_surveillance(carrier_id):
    data = request.get_json()
    activity_type = data["activity_type"]
    scheduled_date = data["scheduled_date"]
    inspector_id = data["inspector_id"]
    status = data["status"]

    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO surveillance_activities (carrier_id, activity_type, scheduled_date, inspector_id, status) VALUES (?,?,?,?,?)",
        (carrier_id, activity_type, scheduled_date, inspector_id, status)
    )
    conn.commit()
    row_id = c.lastrowid
    c.execute("SELECT * FROM surveillance_activities WHERE id=?", (row_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "activity_type": row["activity_type"],
        "scheduled_date": row["scheduled_date"],
        "inspector_id": row["inspector_id"],
        "status": row["status"]
    }), 201


@app.route("/api/carriers/<carrier_id>/surveillance", methods=["GET"])
def get_surveillance(carrier_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM surveillance_activities WHERE carrier_id=?", (carrier_id,))
    rows = c.fetchall()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "id": row["id"],
            "carrier_id": row["carrier_id"],
            "activity_type": row["activity_type"],
            "scheduled_date": row["scheduled_date"],
            "inspector_id": row["inspector_id"],
            "status": row["status"]
        })
    return jsonify(result), 200


@app.route("/api/surveillance/<int:activity_id>", methods=["PATCH"])
def update_surveillance(activity_id):
    data = request.get_json()
    status = data["status"]

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM surveillance_activities WHERE id=?", (activity_id,))
    row = c.fetchone()
    if row is None:
        conn.close()
        return jsonify({"error": "Not found"}), 404

    c.execute("UPDATE surveillance_activities SET status=? WHERE id=?", (status, activity_id))
    conn.commit()
    c.execute("SELECT * FROM surveillance_activities WHERE id=?", (activity_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "activity_type": row["activity_type"],
        "scheduled_date": row["scheduled_date"],
        "inspector_id": row["inspector_id"],
        "status": row["status"]
    }), 200


# --- Voluntary Disclosures ----------------------------------------------------

@app.route("/api/carriers/<carrier_id>/disclosures", methods=["POST"])
def create_disclosure(carrier_id):
    data = request.get_json()
    disclosure_date = data["disclosure_date"]
    description = data["description"]
    submitted_by = data["submitted_by"]
    status = "received"

    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO voluntary_disclosures (carrier_id, disclosure_date, description, submitted_by, status) VALUES (?,?,?,?,?)",
        (carrier_id, disclosure_date, description, submitted_by, status)
    )
    conn.commit()
    row_id = c.lastrowid
    c.execute("SELECT * FROM voluntary_disclosures WHERE id=?", (row_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "disclosure_date": row["disclosure_date"],
        "description": row["description"],
        "submitted_by": row["submitted_by"],
        "status": row["status"]
    }), 201


@app.route("/api/carriers/<carrier_id>/disclosures", methods=["GET"])
def get_disclosures(carrier_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM voluntary_disclosures WHERE carrier_id=?", (carrier_id,))
    rows = c.fetchall()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "id": row["id"],
            "carrier_id": row["carrier_id"],
            "disclosure_date": row["disclosure_date"],
            "description": row["description"],
            "submitted_by": row["submitted_by"],
            "status": row["status"]
        })
    return jsonify(result), 200


# --- Enforcement Actions ------------------------------------------------------

@app.route("/api/carriers/<carrier_id>/enforcement-actions", methods=["POST"])
def create_enforcement_action(carrier_id):
    data = request.get_json()
    inspector_id = data["inspector_id"]
    finding_id = data["finding_id"]
    action_type = data["action_type"]
    initiated_date = data["initiated_date"]
    status = data["status"]

    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO enforcement_actions (carrier_id, inspector_id, finding_id, action_type, initiated_date, status) VALUES (?,?,?,?,?,?)",
        (carrier_id, inspector_id, finding_id, action_type, initiated_date, status)
    )
    conn.commit()
    row_id = c.lastrowid
    c.execute("SELECT * FROM enforcement_actions WHERE id=?", (row_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "inspector_id": row["inspector_id"],
        "finding_id": row["finding_id"],
        "action_type": row["action_type"],
        "initiated_date": row["initiated_date"],
        "status": row["status"]
    }), 201


@app.route("/api/carriers/<carrier_id>/enforcement-actions", methods=["GET"])
def get_enforcement_actions(carrier_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM enforcement_actions WHERE carrier_id=?", (carrier_id,))
    rows = c.fetchall()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "id": row["id"],
            "carrier_id": row["carrier_id"],
            "inspector_id": row["inspector_id"],
            "finding_id": row["finding_id"],
            "action_type": row["action_type"],
            "initiated_date": row["initiated_date"],
            "status": row["status"]
        })
    return jsonify(result), 200


@app.route("/api/enforcement-actions/<int:action_id>", methods=["PATCH"])
def update_enforcement_action(action_id):
    data = request.get_json()
    status = data["status"]

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM enforcement_actions WHERE id=?", (action_id,))
    row = c.fetchone()
    if row is None:
        conn.close()
        return jsonify({"error": "Not found"}), 404

    c.execute("UPDATE enforcement_actions SET status=? WHERE id=?", (status, action_id))
    conn.commit()
    c.execute("SELECT * FROM enforcement_actions WHERE id=?", (action_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "inspector_id": row["inspector_id"],
        "finding_id": row["finding_id"],
        "action_type": row["action_type"],
        "initiated_date": row["initiated_date"],
        "status": row["status"]
    }), 200


# --- Emergency Actions --------------------------------------------------------

@app.route("/api/carriers/<carrier_id>/emergency-actions", methods=["POST"])
def create_emergency_action(carrier_id):
    data = request.get_json()
    action_type = data["action_type"]
    reason = data["reason"]
    issued_date = data["issued_date"]
    status = data["status"]

    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO emergency_actions (carrier_id, action_type, reason, issued_date, status) VALUES (?,?,?,?,?)",
        (carrier_id, action_type, reason, issued_date, status)
    )
    conn.commit()
    row_id = c.lastrowid
    c.execute("SELECT * FROM emergency_actions WHERE id=?", (row_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "action_type": row["action_type"],
        "reason": row["reason"],
        "issued_date": row["issued_date"],
        "status": row["status"]
    }), 201


@app.route("/api/carriers/<carrier_id>/emergency-actions", methods=["GET"])
def get_emergency_actions(carrier_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM emergency_actions WHERE carrier_id=?", (carrier_id,))
    rows = c.fetchall()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "id": row["id"],
            "carrier_id": row["carrier_id"],
            "action_type": row["action_type"],
            "reason": row["reason"],
            "issued_date": row["issued_date"],
            "status": row["status"]
        })
    return jsonify(result), 200


# --- AD Compliance ------------------------------------------------------------

@app.route("/api/carriers/<carrier_id>/ad-compliance", methods=["POST"])
def create_ad_compliance(carrier_id):
    data = request.get_json()
    ad_id = data["ad_id"]
    compliance_status = data["compliance_status"]
    due_date = data["due_date"]
    notes = data["notes"]

    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO ad_compliance (carrier_id, ad_id, compliance_status, due_date, notes) VALUES (?,?,?,?,?)",
        (carrier_id, ad_id, compliance_status, due_date, notes)
    )
    conn.commit()
    row_id = c.lastrowid
    c.execute("SELECT * FROM ad_compliance WHERE id=?", (row_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "ad_id": row["ad_id"],
        "compliance_status": row["compliance_status"],
        "due_date": row["due_date"],
        "notes": row["notes"]
    }), 201


@app.route("/api/carriers/<carrier_id>/ad-compliance", methods=["GET"])
def get_ad_compliance(carrier_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM ad_compliance WHERE carrier_id=?", (carrier_id,))
    rows = c.fetchall()
    conn.close()

    result = []
    for row in rows:
        result.append({
            "id": row["id"],
            "carrier_id": row["carrier_id"],
            "ad_id": row["ad_id"],
            "compliance_status": row["compliance_status"],
            "due_date": row["due_date"],
            "notes": row["notes"]
        })
    return jsonify(result), 200


@app.route("/api/ad-compliance/<int:record_id>", methods=["PATCH"])
def update_ad_compliance(record_id):
    data = request.get_json()
    compliance_status = data["compliance_status"]
    notes = data["notes"]

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM ad_compliance WHERE id=?", (record_id,))
    row = c.fetchone()
    if row is None:
        conn.close()
        return jsonify({"error": "Not found"}), 404

    c.execute(
        "UPDATE ad_compliance SET compliance_status=?, notes=? WHERE id=?",
        (compliance_status, notes, record_id)
    )
    conn.commit()
    c.execute("SELECT * FROM ad_compliance WHERE id=?", (record_id,))
    row = c.fetchone()
    conn.close()

    return jsonify({
        "id": row["id"],
        "carrier_id": row["carrier_id"],
        "ad_id": row["ad_id"],
        "compliance_status": row["compliance_status"],
        "due_date": row["due_date"],
        "notes": row["notes"]
    }), 200


# --- Regulatory Report --------------------------------------------------------

@app.route("/api/carriers/<carrier_id>/report", methods=["GET"])
def get_report(carrier_id):
    conn = get_db()
    c = conn.cursor()

    # Surveillance by status
    surv_statuses = ["scheduled", "completed", "cancelled"]
    surveillance_by_status = {s: 0 for s in surv_statuses}
    c.execute("SELECT status, COUNT(*) as cnt FROM surveillance_activities WHERE carrier_id=? GROUP BY status", (carrier_id,))
    for row in c.fetchall():
        if row["status"] in surveillance_by_status:
            surveillance_by_status[row["status"]] = row["cnt"]
    total_surveillance = sum(surveillance_by_status.values())

    # Enforcement by status
    enf_statuses = ["open", "pending", "closed"]
    enforcement_by_status = {s: 0 for s in enf_statuses}
    c.execute("SELECT status, COUNT(*) as cnt FROM enforcement_actions WHERE carrier_id=? GROUP BY status", (carrier_id,))
    for row in c.fetchall():
        if row["status"] in enforcement_by_status:
            enforcement_by_status[row["status"]] = row["cnt"]
    total_enforcement_actions = sum(enforcement_by_status.values())

    # Disclosures by status
    disc_statuses = ["received", "under_review", "closed"]
    disclosures_by_status = {s: 0 for s in disc_statuses}
    c.execute("SELECT status, COUNT(*) as cnt FROM voluntary_disclosures WHERE carrier_id=? GROUP BY status", (carrier_id,))
    for row in c.fetchall():
        if row["status"] in disclosures_by_status:
            disclosures_by_status[row["status"]] = row["cnt"]
    total_disclosures = sum(disclosures_by_status.values())

    # AD compliance by status
    ad_statuses = ["compliant", "non_compliant", "pending"]
    ad_by_status = {s: 0 for s in ad_statuses}
    c.execute("SELECT compliance_status, COUNT(*) as cnt FROM ad_compliance WHERE carrier_id=? GROUP BY compliance_status", (carrier_id,))
    for row in c.fetchall():
        if row["compliance_status"] in ad_by_status:
            ad_by_status[row["compliance_status"]] = row["cnt"]
    total_ad_compliance = sum(ad_by_status.values())

    conn.close()

    spas_submission_ready = (
        total_surveillance > 0 and
        total_enforcement_actions > 0 and
        total_disclosures > 0 and
        total_ad_compliance > 0
    )

    return jsonify({
        "carrier_id": carrier_id,
        "total_surveillance": total_surveillance,
        "surveillance_by_status": surveillance_by_status,
        "total_enforcement_actions": total_enforcement_actions,
        "enforcement_by_status": enforcement_by_status,
        "total_disclosures": total_disclosures,
        "disclosures_by_status": disclosures_by_status,
        "total_ad_compliance": total_ad_compliance,
        "ad_by_status": ad_by_status,
        "spas_submission_ready": spas_submission_ready,
        "congressional_oversight_scope": "FAA_PART_121"
    }), 200


if __name__ == "__main__":
    app.run(debug=True)