import sqlite3
import os
from datetime import datetime, timezone
from flask import Flask, request, jsonify, g, render_template

app = Flask(__name__)

DEFAULT_DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pottery.db')


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        from flask import current_app
        db_path = current_app.config.get("DATABASE", DEFAULT_DATABASE)
        db = g._database = sqlite3.connect(db_path)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
    return db


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


def init_db():
    try:
        from flask import current_app
        db_path = current_app.config.get("DATABASE", DEFAULT_DATABASE)
    except RuntimeError:
        db_path = DEFAULT_DATABASE
    db = sqlite3.connect(db_path)
    db.execute("PRAGMA foreign_keys = ON")
    cursor = db.cursor()

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            instructor TEXT NOT NULL,
            room TEXT NOT NULL,
            day_of_week TEXT NOT NULL,
            time TEXT NOT NULL,
            capacity INTEGER NOT NULL,
            price REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            class_id INTEGER NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(id),
            FOREIGN KEY (class_id) REFERENCES classes(id),
            UNIQUE (student_id, class_id)
        );

        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            class_id INTEGER NOT NULL,
            session_date TEXT NOT NULL,
            present INTEGER NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(id),
            FOREIGN KEY (class_id) REFERENCES classes(id)
        );

        CREATE TABLE IF NOT EXISTS kiln_loads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            firing_date TEXT NOT NULL,
            completed INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS kiln_pieces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kiln_load_id INTEGER NOT NULL,
            student_id INTEGER NOT NULL,
            label TEXT NOT NULL,
            FOREIGN KEY (kiln_load_id) REFERENCES kiln_loads(id),
            FOREIGN KEY (student_id) REFERENCES students(id)
        );

        CREATE TABLE IF NOT EXISTS pieces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            label TEXT NOT NULL,
            student_id INTEGER NOT NULL,
            class_id INTEGER NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students(id),
            FOREIGN KEY (class_id) REFERENCES classes(id)
        );

        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            material_type TEXT NOT NULL,
            quantity REAL NOT NULL,
            unit TEXT NOT NULL,
            reorder_threshold REAL NOT NULL
        );
    """)
    db.commit()
    db.close()


# ──────────────────────────────────────────────
# CLASSES
# ──────────────────────────────────────────────

@app.route('/api/classes', methods=['POST'])
def create_class():
    data = request.get_json()
    db = get_db()
    cursor = db.execute(
        "INSERT INTO classes (instructor, room, day_of_week, time, capacity, price) VALUES (?, ?, ?, ?, ?, ?)",
        (data['instructor'], data['room'], data['day_of_week'], data['time'], data['capacity'], data['price'])
    )
    db.commit()
    row = db.execute("SELECT * FROM classes WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@app.route('/api/classes', methods=['GET'])
def get_classes():
    db = get_db()
    rows = db.execute("SELECT * FROM classes").fetchall()
    return jsonify([dict(r) for r in rows]), 200


# ──────────────────────────────────────────────
# STUDENTS
# ──────────────────────────────────────────────

@app.route('/api/students', methods=['POST'])
def register_student():
    data = request.get_json()
    db = get_db()
    existing = db.execute("SELECT id FROM students WHERE email = ?", (data['email'],)).fetchone()
    if existing:
        return jsonify({"error": "A student with this email already exists"}), 409
    cursor = db.execute(
        "INSERT INTO students (email, first_name, last_name) VALUES (?, ?, ?)",
        (data['email'], data['first_name'], data['last_name'])
    )
    db.commit()
    row = db.execute("SELECT * FROM students WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@app.route('/api/students', methods=['GET'])
def get_students():
    db = get_db()
    rows = db.execute("SELECT * FROM students").fetchall()
    return jsonify([dict(r) for r in rows]), 200


# ──────────────────────────────────────────────
# ENROLLMENTS
# ──────────────────────────────────────────────

@app.route('/api/enrollments', methods=['POST'])
def enroll_student():
    data = request.get_json()
    student_id = data['student_id']
    class_id = data['class_id']
    db = get_db()

    student = db.execute("SELECT id FROM students WHERE id = ?", (student_id,)).fetchone()
    if not student:
        return jsonify({"error": "Student not found"}), 404

    cls = db.execute("SELECT * FROM classes WHERE id = ?", (class_id,)).fetchone()
    if not cls:
        return jsonify({"error": "Class not found"}), 404

    existing = db.execute(
        "SELECT id FROM enrollments WHERE student_id = ? AND class_id = ?",
        (student_id, class_id)
    ).fetchone()
    if existing:
        return jsonify({"error": "Enrollment already exists"}), 409

    enrolled_count = db.execute(
        "SELECT COUNT(*) as cnt FROM enrollments WHERE class_id = ? AND status = 'enrolled'",
        (class_id,)
    ).fetchone()['cnt']

    status = "enrolled" if enrolled_count < cls['capacity'] else "waitlisted"
    created_at = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'

    cursor = db.execute(
        "INSERT INTO enrollments (student_id, class_id, status, created_at) VALUES (?, ?, ?, ?)",
        (student_id, class_id, status, created_at)
    )
    db.commit()
    row = db.execute("SELECT * FROM enrollments WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@app.route('/api/classes/<int:class_id>/enrollments', methods=['GET'])
def get_class_enrollments(class_id):
    db = get_db()
    cls = db.execute("SELECT id FROM classes WHERE id = ?", (class_id,)).fetchone()
    if not cls:
        return jsonify({"error": "Class not found"}), 404

    enrolled = db.execute(
        "SELECT id, student_id, status, created_at FROM enrollments WHERE class_id = ? AND status = 'enrolled'",
        (class_id,)
    ).fetchall()
    waitlisted = db.execute(
        "SELECT id, student_id, status, created_at FROM enrollments WHERE class_id = ? AND status = 'waitlisted'",
        (class_id,)
    ).fetchall()

    return jsonify({
        "enrolled": [dict(r) for r in enrolled],
        "waitlisted": [dict(r) for r in waitlisted]
    }), 200


# ──────────────────────────────────────────────
# ATTENDANCE
# ──────────────────────────────────────────────

@app.route('/api/attendance', methods=['POST'])
def record_attendance():
    data = request.get_json()
    student_id = data['student_id']
    class_id = data['class_id']
    db = get_db()

    student = db.execute("SELECT id FROM students WHERE id = ?", (student_id,)).fetchone()
    if not student:
        return jsonify({"error": "Student not found"}), 404

    cls = db.execute("SELECT id FROM classes WHERE id = ?", (class_id,)).fetchone()
    if not cls:
        return jsonify({"error": "Class not found"}), 404

    present_val = 1 if data['present'] else 0
    cursor = db.execute(
        "INSERT INTO attendance (student_id, class_id, session_date, present) VALUES (?, ?, ?, ?)",
        (student_id, class_id, data['session_date'], present_val)
    )
    db.commit()
    row = db.execute("SELECT * FROM attendance WHERE id = ?", (cursor.lastrowid,)).fetchone()
    result = dict(row)
    result['present'] = bool(result['present'])
    return jsonify(result), 201


@app.route('/api/classes/<int:class_id>/attendance/<session_date>', methods=['GET'])
def get_session_attendance(class_id, session_date):
    db = get_db()
    cls = db.execute("SELECT id FROM classes WHERE id = ?", (class_id,)).fetchone()
    if not cls:
        return jsonify({"error": "Class not found"}), 404

    rows = db.execute(
        "SELECT * FROM attendance WHERE class_id = ? AND session_date = ?",
        (class_id, session_date)
    ).fetchall()
    results = []
    for r in rows:
        d = dict(r)
        d['present'] = bool(d['present'])
        results.append(d)
    return jsonify(results), 200


# ──────────────────────────────────────────────
# KILN LOADS
# ──────────────────────────────────────────────

def kiln_load_to_dict(db, load_row):
    load = dict(load_row)
    load['completed'] = bool(load['completed'])
    pieces = db.execute(
        "SELECT id, student_id, label FROM kiln_pieces WHERE kiln_load_id = ?",
        (load['id'],)
    ).fetchall()
    load['pieces'] = [dict(p) for p in pieces]
    return load


@app.route('/api/kiln-loads', methods=['POST'])
def create_kiln_load():
    data = request.get_json()
    db = get_db()

    pieces = data.get('pieces', [])
    for piece in pieces:
        student = db.execute("SELECT id FROM students WHERE id = ?", (piece['student_id'],)).fetchone()
        if not student:
            return jsonify({"error": f"Student {piece['student_id']} not found"}), 404

    cursor = db.execute(
        "INSERT INTO kiln_loads (name, firing_date, completed) VALUES (?, ?, 0)",
        (data['name'], data['firing_date'])
    )
    load_id = cursor.lastrowid

    for piece in pieces:
        db.execute(
            "INSERT INTO kiln_pieces (kiln_load_id, student_id, label) VALUES (?, ?, ?)",
            (load_id, piece['student_id'], piece['label'])
        )

    db.commit()
    row = db.execute("SELECT * FROM kiln_loads WHERE id = ?", (load_id,)).fetchone()
    return jsonify(kiln_load_to_dict(db, row)), 201


@app.route('/api/kiln-loads/<int:kiln_load_id>', methods=['PUT'])
def update_kiln_load(kiln_load_id):
    data = request.get_json()
    db = get_db()

    row = db.execute("SELECT * FROM kiln_loads WHERE id = ?", (kiln_load_id,)).fetchone()
    if not row:
        return jsonify({"error": "Kiln load not found"}), 404

    completed_val = 1 if data['completed'] else 0
    db.execute(
        "UPDATE kiln_loads SET completed = ? WHERE id = ?",
        (completed_val, kiln_load_id)
    )
    db.commit()
    row = db.execute("SELECT * FROM kiln_loads WHERE id = ?", (kiln_load_id,)).fetchone()
    return jsonify(kiln_load_to_dict(db, row)), 200


@app.route('/api/kiln-loads', methods=['GET'])
def get_kiln_loads():
    db = get_db()
    rows = db.execute("SELECT * FROM kiln_loads").fetchall()
    return jsonify([kiln_load_to_dict(db, r) for r in rows]), 200


# ──────────────────────────────────────────────
# PIECE LABELS
# ──────────────────────────────────────────────

@app.route('/api/pieces', methods=['POST'])
def create_piece():
    data = request.get_json()
    student_id = data['student_id']
    class_id = data['class_id']
    db = get_db()

    student = db.execute("SELECT id FROM students WHERE id = ?", (student_id,)).fetchone()
    if not student:
        return jsonify({"error": "Student not found"}), 404

    cls = db.execute("SELECT id FROM classes WHERE id = ?", (class_id,)).fetchone()
    if not cls:
        return jsonify({"error": "Class not found"}), 404

    cursor = db.execute(
        "INSERT INTO pieces (label, student_id, class_id) VALUES (?, ?, ?)",
        (data['label'], student_id, class_id)
    )
    db.commit()
    row = db.execute("SELECT * FROM pieces WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@app.route('/api/students/<int:student_id>/pieces', methods=['GET'])
def get_student_pieces(student_id):
    db = get_db()
    student = db.execute("SELECT id FROM students WHERE id = ?", (student_id,)).fetchone()
    if not student:
        return jsonify({"error": "Student not found"}), 404

    rows = db.execute("SELECT * FROM pieces WHERE student_id = ?", (student_id,)).fetchall()
    return jsonify([dict(r) for r in rows]), 200


# ──────────────────────────────────────────────
# INVENTORY
# ──────────────────────────────────────────────

@app.route('/api/inventory', methods=['POST'])
def create_inventory_item():
    data = request.get_json()
    if data.get('material_type') not in ('clay', 'glaze'):
        return jsonify({"error": "material_type must be 'clay' or 'glaze'"}), 400

    db = get_db()
    cursor = db.execute(
        "INSERT INTO inventory (name, material_type, quantity, unit, reorder_threshold) VALUES (?, ?, ?, ?, ?)",
        (data['name'], data['material_type'], data['quantity'], data['unit'], data['reorder_threshold'])
    )
    db.commit()
    row = db.execute("SELECT * FROM inventory WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@app.route('/api/inventory', methods=['GET'])
def get_inventory():
    db = get_db()
    rows = db.execute("SELECT * FROM inventory").fetchall()
    return jsonify([dict(r) for r in rows]), 200


@app.route('/api/inventory/<int:item_id>', methods=['PUT'])
def update_inventory_quantity(item_id):
    data = request.get_json()
    db = get_db()

    row = db.execute("SELECT * FROM inventory WHERE id = ?", (item_id,)).fetchone()
    if not row:
        return jsonify({"error": "Inventory item not found"}), 404

    db.execute("UPDATE inventory SET quantity = ? WHERE id = ?", (data['quantity'], item_id))
    db.commit()
    row = db.execute("SELECT * FROM inventory WHERE id = ?", (item_id,)).fetchone()
    return jsonify(dict(row)), 200


@app.route('/api/inventory/alerts', methods=['GET'])
def get_inventory_alerts():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM inventory WHERE quantity <= reorder_threshold"
    ).fetchall()
    return jsonify([dict(r) for r in rows]), 200


# ──────────────────────────────────────────────
# REVENUE REPORT
# ──────────────────────────────────────────────

@app.route('/api/revenue', methods=['GET'])
def get_revenue():
    db = get_db()
    rows = db.execute("""
        SELECT
            e.class_id,
            c.instructor,
            c.day_of_week,
            c.time,
            strftime('%Y-%m', e.created_at) AS month,
            COUNT(*) * c.price AS revenue
        FROM enrollments e
        JOIN classes c ON e.class_id = c.id
        WHERE e.status = 'enrolled'
        GROUP BY e.class_id, strftime('%Y-%m', e.created_at)
        ORDER BY e.class_id, month
    """).fetchall()
    return jsonify([dict(r) for r in rows]), 200


# ──────────────────────────────────────────────
# FRONTEND
# ──────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
else:
    init_db()