import sqlite3
import os
from datetime import datetime, timezone
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Default DB path; can be overridden via app.config["DATABASE"]
_DEFAULT_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "workshop.db")


def get_db_path():
    return app.config.get("DATABASE", _DEFAULT_DB)


def get_db():
    conn = sqlite3.connect(get_db_path())
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cursor = conn.cursor()
    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS repair_jobs (
            job_id INTEGER PRIMARY KEY AUTOINCREMENT,
            visitor_name TEXT NOT NULL,
            problem_description TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            volunteer_name TEXT,
            work_log TEXT,
            created_at TEXT NOT NULL,
            completed_at TEXT
        );

        CREATE TABLE IF NOT EXISTS parts (
            part_id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_name TEXT NOT NULL UNIQUE,
            stock INTEGER NOT NULL,
            low_stock_threshold INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS parts_used (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL,
            part_name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            used_at TEXT NOT NULL
        );
    """)
    conn.commit()

    cursor.execute("SELECT COUNT(*) FROM parts")
    count = cursor.fetchone()[0]
    if count == 0:
        seed_parts = [
            ("Inner Tube", 20, 5),
            ("Brake Cable", 3, 5),
            ("Chain", 8, 3),
            ("Tire Patch Kit", 15, 4),
            ("Gear Cable", 2, 5),
        ]
        cursor.executemany(
            "INSERT INTO parts (part_name, stock, low_stock_threshold) VALUES (?, ?, ?)",
            seed_parts
        )
        conn.commit()

    conn.close()


init_db()


def utc_now_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


# ──────────────────────────────────────────────
# PAGE ROUTES (Jinja2 templates)
# ──────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/queue-page")
def queue_page():
    return render_template("queue.html")


@app.route("/dashboard")
def dashboard_page():
    return render_template("dashboard.html")


@app.route("/inventory-page")
def inventory_page():
    return render_template("inventory.html")


# ──────────────────────────────────────────────
# API ENDPOINTS
# ──────────────────────────────────────────────

@app.route("/checkin", methods=["POST"])
def checkin():
    data = request.get_json(silent=True) or {}
    visitor_name = data.get("visitor_name", "")
    problem_description = data.get("problem_description", "")

    if not visitor_name or not problem_description:
        return jsonify({"error": "visitor_name and problem_description are required"}), 400

    created_at = utc_now_str()
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO repair_jobs (visitor_name, problem_description, status, created_at) VALUES (?, ?, 'pending', ?)",
        (visitor_name, problem_description, created_at)
    )
    conn.commit()
    job_id = cursor.lastrowid
    conn.close()

    return jsonify({"job_id": job_id, "status": "pending"}), 201


@app.route("/queue", methods=["GET"])
def get_queue():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT job_id, visitor_name, problem_description, status, created_at "
        "FROM repair_jobs WHERE status = 'pending' ORDER BY created_at ASC"
    )
    rows = cursor.fetchall()
    conn.close()

    result = [
        {
            "job_id": row["job_id"],
            "visitor_name": row["visitor_name"],
            "problem_description": row["problem_description"],
            "status": row["status"],
            "created_at": row["created_at"],
        }
        for row in rows
    ]
    return jsonify(result), 200


@app.route("/jobs/<int:job_id>/claim", methods=["POST"])
def claim_job(job_id):
    data = request.get_json(silent=True) or {}
    volunteer_name = data.get("volunteer_name", "")

    if not volunteer_name:
        return jsonify({"error": "volunteer_name is required"}), 400

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM repair_jobs WHERE job_id = ?", (job_id,))
    job = cursor.fetchone()

    if job is None:
        conn.close()
        return jsonify({"error": "Job not found"}), 404

    if job["status"] != "pending":
        conn.close()
        return jsonify({"error": "Job is not in pending status"}), 400

    cursor.execute(
        "UPDATE repair_jobs SET status = 'in_progress', volunteer_name = ? WHERE job_id = ?",
        (volunteer_name, job_id)
    )
    conn.commit()
    conn.close()

    return jsonify({"job_id": job_id, "status": "in_progress"}), 200


@app.route("/jobs/<int:job_id>/complete", methods=["POST"])
def complete_job(job_id):
    data = request.get_json(silent=True) or {}
    work_log = data.get("work_log", "")
    parts_used = data.get("parts_used")

    if not work_log:
        return jsonify({"error": "work_log is required"}), 400

    if parts_used is None or not isinstance(parts_used, list):
        return jsonify({"error": "parts_used must be a list"}), 400

    for entry in parts_used:
        quantity = entry.get("quantity")
        if not isinstance(quantity, int) or quantity <= 0:
            return jsonify({"error": "Each quantity must be a positive integer"}), 400

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM repair_jobs WHERE job_id = ?", (job_id,))
    job = cursor.fetchone()

    if job is None:
        conn.close()
        return jsonify({"error": "Job not found"}), 404

    if job["status"] != "in_progress":
        conn.close()
        return jsonify({"error": "Job is not in in_progress status"}), 400

    # Validate all part names exist first
    for entry in parts_used:
        part_name = entry.get("part_name")
        cursor.execute("SELECT * FROM parts WHERE part_name = ?", (part_name,))
        part = cursor.fetchone()
        if part is None:
            conn.close()
            return jsonify({"error": f"Part '{part_name}' not found"}), 404

    # Check stock levels sequentially with running deduction
    stock_map = {}
    for entry in parts_used:
        part_name = entry.get("part_name")
        if part_name not in stock_map:
            cursor.execute("SELECT stock FROM parts WHERE part_name = ?", (part_name,))
            row = cursor.fetchone()
            stock_map[part_name] = row["stock"]

    running_stock = dict(stock_map)
    for entry in parts_used:
        part_name = entry.get("part_name")
        quantity = entry.get("quantity")
        if quantity > running_stock[part_name]:
            conn.close()
            return jsonify({"error": f"Insufficient stock for part '{part_name}'"}), 400
        running_stock[part_name] -= quantity

    completed_at = utc_now_str()

    for entry in parts_used:
        part_name = entry.get("part_name")
        quantity = entry.get("quantity")
        cursor.execute(
            "INSERT INTO parts_used (job_id, part_name, quantity, used_at) VALUES (?, ?, ?, ?)",
            (job_id, part_name, quantity, completed_at)
        )
        cursor.execute(
            "UPDATE parts SET stock = stock - ? WHERE part_name = ?",
            (quantity, part_name)
        )

    cursor.execute(
        "UPDATE repair_jobs SET status = 'completed', work_log = ?, completed_at = ? WHERE job_id = ?",
        (work_log, completed_at, job_id)
    )
    conn.commit()
    conn.close()

    return jsonify({"job_id": job_id, "status": "completed"}), 200


@app.route("/dashboard/stats", methods=["GET"])
def dashboard_stats():
    today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    month_str = datetime.now(timezone.utc).strftime("%Y-%m")

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM repair_jobs WHERE status = 'pending'")
    queue_count = cursor.fetchone()[0]

    cursor.execute(
        "SELECT COUNT(*) FROM repair_jobs WHERE status = 'completed' AND substr(completed_at, 1, 10) = ?",
        (today_str,)
    )
    completed_today = cursor.fetchone()[0]

    cursor.execute(
        "SELECT COALESCE(SUM(quantity), 0) FROM parts_used WHERE substr(used_at, 1, 10) = ?",
        (today_str,)
    )
    parts_used_today = cursor.fetchone()[0]

    cursor.execute(
        "SELECT COUNT(DISTINCT job_id) FROM repair_jobs WHERE status = 'completed' AND substr(completed_at, 1, 7) = ?",
        (month_str,)
    )
    bikes_fixed_this_month = cursor.fetchone()[0]

    conn.close()

    return jsonify({
        "queue_count": queue_count,
        "completed_today": completed_today,
        "parts_used_today": parts_used_today,
        "bikes_fixed_this_month": bikes_fixed_this_month,
    }), 200


@app.route("/inventory", methods=["GET"])
def get_inventory():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT part_id, part_name, stock, low_stock_threshold FROM parts")
    rows = cursor.fetchall()
    conn.close()

    result = [
        {
            "part_id": row["part_id"],
            "part_name": row["part_name"],
            "stock": row["stock"],
            "low_stock_threshold": row["low_stock_threshold"],
            "is_low_stock": row["stock"] <= row["low_stock_threshold"],
        }
        for row in rows
    ]
    return jsonify(result), 200


@app.route("/inventory/restock", methods=["POST"])
def restock_part():
    data = request.get_json(silent=True) or {}
    part_name = data.get("part_name", "")
    quantity = data.get("quantity")

    if not part_name:
        return jsonify({"error": "part_name is required"}), 400

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM parts WHERE part_name = ?", (part_name,))
    part = cursor.fetchone()

    if part is None:
        conn.close()
        return jsonify({"error": "Part not found"}), 404

    if not isinstance(quantity, int) or quantity <= 0:
        conn.close()
        return jsonify({"error": "quantity must be a positive integer"}), 400

    cursor.execute(
        "UPDATE parts SET stock = stock + ? WHERE part_name = ?",
        (quantity, part_name)
    )
    conn.commit()

    cursor.execute("SELECT part_id, part_name, stock FROM parts WHERE part_name = ?", (part_name,))
    updated = cursor.fetchone()
    conn.close()

    return jsonify({
        "part_id": updated["part_id"],
        "part_name": updated["part_name"],
        "stock": updated["stock"],
    }), 200


if __name__ == "__main__":
    app.run(debug=True)
