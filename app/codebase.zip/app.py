"""
app.py — Community Bike Repair Workshop Management System

Flask application providing:
  - Visitor check-in (POST /checkin)
  - Volunteer job queue (GET /queue, POST /jobs/<id>/claim, POST /jobs/<id>/complete)
  - Workshop dashboard stats (GET /dashboard/stats)
  - Parts inventory and restocking (GET /inventory, POST /inventory/restock)
  - HTML pages served via Jinja2 templates for each of the above workflows

Database: SQLite (via Python's built-in sqlite3 module).
The database file path is read from app.config["DATABASE"] at runtime;
if that key is absent it falls back to workshop.db in the repository root.

Module-level side effects on import:
  - Creates the three database tables if they do not already exist.
  - Seeds the parts table with five default parts if it is currently empty.
"""

import sqlite3
import os
from datetime import datetime, timezone
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Default SQLite file location — can be overridden at runtime via app.config["DATABASE"].
_DEFAULT_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "workshop.db")


# ──────────────────────────────────────────────
# DATABASE HELPERS
# ──────────────────────────────────────────────

def get_db_path():
    """Return the active database file path.

    Checks app.config["DATABASE"] first so that tests and deployments can
    substitute a different file without modifying source code.
    Falls back to _DEFAULT_DB (workshop.db next to this file) when the key
    is not present in the Flask config.
    """
    return app.config.get("DATABASE", _DEFAULT_DB)


def get_db():
    """Open and return a new SQLite connection to the active database.

    Row factory is set to sqlite3.Row so that columns can be accessed by
    name (e.g. row["job_id"]) as well as by index.
    Callers are responsible for closing the connection when finished.
    """
    conn = sqlite3.connect(get_db_path())
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initialise the database schema and seed reference data.

    Creates three tables if they do not already exist:
      - repair_jobs  : one row per visitor check-in / repair job
      - parts        : master list of spare parts with stock levels
      - parts_used   : usage log entries created when a job is completed

    If the parts table is empty after schema creation, inserts the five
    default seed parts so the application is immediately usable.

    Called once at module import time.
    """
    conn = get_db()
    cursor = conn.cursor()

    # Create all tables in a single script; IF NOT EXISTS makes this
    # safe to call on every startup without losing existing data.
    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS repair_jobs (
            job_id INTEGER PRIMARY KEY AUTOINCREMENT,
            visitor_name TEXT NOT NULL,
            problem_description TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            volunteer_name TEXT,
            work_log TEXT,
            created_at TEXT NOT NULL,
            completed_at TEXT
        );

        CREATE TABLE IF NOT EXISTS parts (
            part_id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_name TEXT NOT NULL UNIQUE,
            stock INTEGER NOT NULL,
            low_stock_threshold INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS parts_used (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL,
            part_name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            used_at TEXT NOT NULL
        );
    """)
    conn.commit()

    # Seed the parts table only when it is empty so that repeated
    # restarts do not reset stock levels that have been modified.
    cursor.execute("SELECT COUNT(*) FROM parts")
    count = cursor.fetchone()[0]
    if count == 0:
        seed_parts = [
            ("Inner Tube",     20, 5),
            ("Brake Cable",     3, 5),
            ("Chain",           8, 3),
            ("Tire Patch Kit", 15, 4),
            ("Gear Cable",      2, 5),
        ]
        cursor.executemany(
            "INSERT INTO parts (part_name, stock, low_stock_threshold) VALUES (?, ?, ?)",
            seed_parts
        )
        conn.commit()

    conn.close()


# Initialise schema and seed data at import time.
init_db()


def utc_now_str():
    """Return the current UTC time as an ISO 8601 string (YYYY-MM-DDTHH:MM:SS).

    Used consistently across all endpoints that record timestamps so that
    every stored value is in the same format and timezone.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


# ──────────────────────────────────────────────
# PAGE ROUTES (Jinja2 templates)
# ──────────────────────────────────────────────

@app.route("/")
def index():
    """Serve the visitor check-in page (templates/index.html)."""
    return render_template("index.html")


@app.route("/queue-page")
def queue_page():
    """Serve the volunteer repair queue page (templates/queue.html)."""
    return render_template("queue.html")


@app.route("/dashboard")
def dashboard_page():
    """Serve the workshop dashboard page (templates/dashboard.html)."""
    return render_template("dashboard.html")


@app.route("/inventory-page")
def inventory_page():
    """Serve the parts inventory page (templates/inventory.html)."""
    return render_template("inventory.html")


# ──────────────────────────────────────────────
# API ENDPOINTS
# ──────────────────────────────────────────────

@app.route("/checkin", methods=["POST"])
def checkin():
    """Create a new repair job from a visitor check-in submission.

    Expects a JSON body with:
      visitor_name (str)        : name of the visitor dropping off a bike
      problem_description (str) : free-text description of the fault

    Returns:
      201  {"job_id": int, "status": "pending"}  on success
      400  {"error": ...}  if either field is missing or empty
    """
    data = request.get_json(silent=True) or {}
    visitor_name = data.get("visitor_name", "")
    problem_description = data.get("problem_description", "")

    # Both fields are mandatory; reject the request if either is blank.
    if not visitor_name or not problem_description:
        return jsonify({"error": "visitor_name and problem_description are required"}), 400

    created_at = utc_now_str()
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO repair_jobs (visitor_name, problem_description, status, created_at) VALUES (?, ?, 'pending', ?)",
        (visitor_name, problem_description, created_at)
    )
    conn.commit()
    job_id = cursor.lastrowid
    conn.close()

    return jsonify({"job_id": job_id, "status": "pending"}), 201


@app.route("/queue", methods=["GET"])
def get_queue():
    """Return all pending repair jobs ordered by submission time (oldest first).

    Returns:
      200  JSON array of job objects, each containing:
           job_id, visitor_name, problem_description, status, created_at
    """
    conn = get_db()
    cursor = conn.cursor()
    # Order ascending so the volunteer sees the longest-waiting job first.
    cursor.execute(
        "SELECT job_id, visitor_name, problem_description, status, created_at "
        "FROM repair_jobs WHERE status = 'pending' ORDER BY created_at ASC"
    )
    rows = cursor.fetchall()
    conn.close()

    result = [
        {
            "job_id": row["job_id"],
            "visitor_name": row["visitor_name"],
            "problem_description": row["problem_description"],
            "status": row["status"],
            "created_at": row["created_at"],
        }
        for row in rows
    ]
    return jsonify(result), 200


@app.route("/jobs/<int:job_id>/claim", methods=["POST"])
def claim_job(job_id):
    """Assign a pending job to a volunteer, moving it to in_progress.

    URL parameter:
      job_id (int) : ID of the repair job to claim

    Expects a JSON body with:
      volunteer_name (str) : name of the volunteer taking the job

    Returns:
      200  {"job_id": int, "status": "in_progress"}  on success
      400  {"error": ...}  if volunteer_name is missing or empty
      400  {"error": ...}  if the job is not currently in pending status
      404  {"error": ...}  if no job with the given ID exists
    """
    data = request.get_json(silent=True) or {}
    volunteer_name = data.get("volunteer_name", "")

    # Validate input before hitting the database.
    if not volunteer_name:
        return jsonify({"error": "volunteer_name is required"}), 400

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM repair_jobs WHERE job_id = ?", (job_id,))
    job = cursor.fetchone()

    if job is None:
        conn.close()
        return jsonify({"error": "Job not found"}), 404

    # Only pending jobs may be claimed; reject if already in_progress or completed.
    if job["status"] != "pending":
        conn.close()
        return jsonify({"error": "Job is not in pending status"}), 400

    cursor.execute(
        "UPDATE repair_jobs SET status = 'in_progress', volunteer_name = ? WHERE job_id = ?",
        (volunteer_name, job_id)
    )
    conn.commit()
    conn.close()

    return jsonify({"job_id": job_id, "status": "in_progress"}), 200


@app.route("/jobs/<int:job_id>/complete", methods=["POST"])
def complete_job(job_id):
    """Mark an in-progress job as completed, recording work done and parts consumed.

    Validation is performed in a strict order to match the specified error
    precedence.  No database writes occur unless all checks pass.

    URL parameter:
      job_id (int) : ID of the repair job to complete

    Expects a JSON body with:
      work_log (str)   : description of the work the volunteer performed
      parts_used (list): list of {"part_name": str, "quantity": int} entries;
                         an empty list is valid (job completes with no parts used)

    Stock validation uses a two-phase approach:
      Phase 1 — Existence check: all part names in parts_used are looked up
                before any stock levels are inspected.  This ensures a missing-
                part 404 always takes priority over an insufficient-stock 400.
      Phase 2 — Rolling stock check: stock is checked and mentally deducted
                entry-by-entry in list order, so duplicate part names are handled
                correctly (each entry's check uses the stock remaining after all
                preceding entries have been deducted).

    Returns:
      200  {"job_id": int, "status": "completed"}  on success
      400  {"error": ...}  if work_log is missing or empty
      400  {"error": ...}  if parts_used is missing or not a list
      400  {"error": ...}  if any quantity is not a positive integer
      400  {"error": ...}  if the job is not currently in in_progress status
      400  {"error": ...}  if any quantity exceeds the available stock
      404  {"error": ...}  if no job with the given ID exists
      404  {"error": ...}  if any part_name does not exist in the parts table
    """
    data = request.get_json(silent=True) or {}
    work_log = data.get("work_log", "")
    parts_used = data.get("parts_used")

    # --- Input validation (no DB access yet) ---

    if not work_log:
        return jsonify({"error": "work_log is required"}), 400

    if parts_used is None or not isinstance(parts_used, list):
        return jsonify({"error": "parts_used must be a list"}), 400

    # Reject any non-positive quantity before touching the database.
    for entry in parts_used:
        quantity = entry.get("quantity")
        if not isinstance(quantity, int) or quantity <= 0:
            return jsonify({"error": "Each quantity must be a positive integer"}), 400

    # --- Database validation ---

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM repair_jobs WHERE job_id = ?", (job_id,))
    job = cursor.fetchone()

    if job is None:
        conn.close()
        return jsonify({"error": "Job not found"}), 404

    if job["status"] != "in_progress":
        conn.close()
        return jsonify({"error": "Job is not in in_progress status"}), 400

    # Phase 1: verify every part name exists before checking stock levels.
    # This ensures a missing-part 404 is always returned ahead of a stock 400.
    for entry in parts_used:
        part_name = entry.get("part_name")
        cursor.execute("SELECT * FROM parts WHERE part_name = ?", (part_name,))
        if cursor.fetchone() is None:
            conn.close()
            return jsonify({"error": f"Part '{part_name}' not found"}), 404

    # Phase 2: rolling stock check — seed the map with current DB stock,
    # then simulate each deduction in list order so that duplicate part names
    # are checked against the already-reduced running total, not the original value.
    stock_map = {}
    for entry in parts_used:
        part_name = entry.get("part_name")
        if part_name not in stock_map:
            # Fetch the live stock value once per unique part name.
            cursor.execute("SELECT stock FROM parts WHERE part_name = ?", (part_name,))
            stock_map[part_name] = cursor.fetchone()["stock"]

    running_stock = dict(stock_map)  # mutable copy used for the simulation
    for entry in parts_used:
        part_name = entry.get("part_name")
        quantity = entry.get("quantity")
        if quantity > running_stock[part_name]:
            conn.close()
            return jsonify({"error": f"Insufficient stock for part '{part_name}'"}), 400
        # Deduct from the running total so subsequent duplicate entries see
        # the reduced stock level rather than the original.
        running_stock[part_name] -= quantity

    # --- All checks passed: commit all writes atomically ---

    completed_at = utc_now_str()

    # Insert a usage record and deduct stock for each entry in parts_used.
    # Duplicate part names each get their own usage record and their own deduction.
    for entry in parts_used:
        part_name = entry.get("part_name")
        quantity = entry.get("quantity")
        cursor.execute(
            "INSERT INTO parts_used (job_id, part_name, quantity, used_at) VALUES (?, ?, ?, ?)",
            (job_id, part_name, quantity, completed_at)
        )
        cursor.execute(
            "UPDATE parts SET stock = stock - ? WHERE part_name = ?",
            (quantity, part_name)
        )

    # Mark the job completed and record the timestamp.
    cursor.execute(
        "UPDATE repair_jobs SET status = 'completed', work_log = ?, completed_at = ? WHERE job_id = ?",
        (work_log, completed_at, job_id)
    )
    conn.commit()
    conn.close()

    return jsonify({"job_id": job_id, "status": "completed"}), 200


@app.route("/dashboard/stats", methods=["GET"])
def dashboard_stats():
    """Return four aggregated metrics for the workshop dashboard.

    All date comparisons are performed against UTC timestamps stored in the
    database as ISO 8601 strings.  substr() is used to extract the date or
    year-month prefix rather than SQLite's strftime so that the comparison
    works correctly with the YYYY-MM-DDTHH:MM:SS format we store.

    Returns:
      200  JSON object with:
           queue_count (int)            : jobs currently in pending status
           completed_today (int)        : jobs completed on today's UTC date
           parts_used_today (int)       : total part units consumed today (UTC)
           bikes_fixed_this_month (int) : distinct completed jobs this calendar month
    """
    today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")   # e.g. "2024-06-15"
    month_str = datetime.now(timezone.utc).strftime("%Y-%m")       # e.g. "2024-06"

    conn = get_db()
    cursor = conn.cursor()

    # Count of all jobs currently waiting for a volunteer.
    cursor.execute("SELECT COUNT(*) FROM repair_jobs WHERE status = 'pending'")
    queue_count = cursor.fetchone()[0]

    # Jobs finished today — compare the first 10 characters of completed_at.
    cursor.execute(
        "SELECT COUNT(*) FROM repair_jobs WHERE status = 'completed' AND substr(completed_at, 1, 10) = ?",
        (today_str,)
    )
    completed_today = cursor.fetchone()[0]

    # Sum of all part quantities consumed today; COALESCE returns 0 when no rows match.
    cursor.execute(
        "SELECT COALESCE(SUM(quantity), 0) FROM parts_used WHERE substr(used_at, 1, 10) = ?",
        (today_str,)
    )
    parts_used_today = cursor.fetchone()[0]

    # Distinct jobs completed within the current calendar month.
    cursor.execute(
        "SELECT COUNT(DISTINCT job_id) FROM repair_jobs WHERE status = 'completed' AND substr(completed_at, 1, 7) = ?",
        (month_str,)
    )
    bikes_fixed_this_month = cursor.fetchone()[0]

    conn.close()

    return jsonify({
        "queue_count": queue_count,
        "completed_today": completed_today,
        "parts_used_today": parts_used_today,
        "bikes_fixed_this_month": bikes_fixed_this_month,
    }), 200


@app.route("/inventory", methods=["GET"])
def get_inventory():
    """Return all parts with their current stock levels and low-stock status.

    is_low_stock is computed in Python rather than SQL to keep the logic
    explicit: a part is low-stock when its current stock is less than or
    equal to its configured low_stock_threshold.

    Returns:
      200  JSON array of part objects, each containing:
           part_id, part_name, stock, low_stock_threshold, is_low_stock (bool)
    """
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT part_id, part_name, stock, low_stock_threshold FROM parts")
    rows = cursor.fetchall()
    conn.close()

    result = [
        {
            "part_id": row["part_id"],
            "part_name": row["part_name"],
            "stock": row["stock"],
            "low_stock_threshold": row["low_stock_threshold"],
            # True when stock has fallen to or below the alert threshold.
            "is_low_stock": row["stock"] <= row["low_stock_threshold"],
        }
        for row in rows
    ]
    return jsonify(result), 200


@app.route("/inventory/restock", methods=["POST"])
def restock_part():
    """Add stock to an existing part by name.

    Expects a JSON body with:
      part_name (str) : exact name of the part to restock
      quantity (int)  : number of units to add (must be a positive integer)

    The quantity is added to the part's current stock rather than replacing it.

    Returns:
      200  {"part_id": int, "part_name": str, "stock": int}  reflecting the new total
      400  {"error": ...}  if part_name is missing or empty
      400  {"error": ...}  if quantity is not a positive integer
      404  {"error": ...}  if the part name does not exist in the parts table
    """
    data = request.get_json(silent=True) or {}
    part_name = data.get("part_name", "")
    quantity = data.get("quantity")

    if not part_name:
        return jsonify({"error": "part_name is required"}), 400

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM parts WHERE part_name = ?", (part_name,))
    part = cursor.fetchone()

    if part is None:
        conn.close()
        return jsonify({"error": "Part not found"}), 404

    # Validate quantity after the existence check so that unknown part names
    # return 404 regardless of whether the quantity is also invalid.
    if not isinstance(quantity, int) or quantity <= 0:
        conn.close()
        return jsonify({"error": "quantity must be a positive integer"}), 400

    cursor.execute(
        "UPDATE parts SET stock = stock + ? WHERE part_name = ?",
        (quantity, part_name)
    )
    conn.commit()

    # Re-fetch to return the accurate post-update stock value.
    cursor.execute("SELECT part_id, part_name, stock FROM parts WHERE part_name = ?", (part_name,))
    updated = cursor.fetchone()
    conn.close()

    return jsonify({
        "part_id": updated["part_id"],
        "part_name": updated["part_name"],
        "stock": updated["stock"],
    }), 200


if __name__ == "__main__":
    app.run(debug=True)