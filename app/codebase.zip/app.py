import json
import os
import re
import uuid
from datetime import datetime, timedelta, timezone

from flask import Flask, jsonify, request


FIRINGS_LOG_PATH = "firings.log"
MAX_TIMESTAMP_SKEW_SECONDS = 300
DEFAULT_FIRINGS_LIMIT = 50


_rules = []
_user_timelines = {}
_throttle = {}
_firings = []


_MISSING = object()


def _tokenize(expression):
    tokens = []
    i = 0
    n = len(expression)
    while i < n:
        c = expression[i]
        if c.isspace():
            i += 1
            continue
        if c == "'":
            j = i + 1
            while j < n and expression[j] != "'":
                j += 1
            if j >= n:
                raise ValueError("unterminated string literal")
            tokens.append(("STRING", expression[i + 1:j]))
            i = j + 1
            continue
        if c == "(":
            tokens.append(("LPAREN", "("))
            i += 1
            continue
        if c == ")":
            tokens.append(("RPAREN", ")"))
            i += 1
            continue
        if c == "!":
            if i + 1 < n and expression[i + 1] == "=":
                tokens.append(("OP", "!="))
                i += 2
                continue
            raise ValueError("unexpected character '!'")
        if c == ">":
            if i + 1 < n and expression[i + 1] == "=":
                tokens.append(("OP", ">="))
                i += 2
            else:
                tokens.append(("OP", ">"))
                i += 1
            continue
        if c == "<":
            if i + 1 < n and expression[i + 1] == "=":
                tokens.append(("OP", "<="))
                i += 2
            else:
                tokens.append(("OP", "<"))
                i += 1
            continue
        if c == "=":
            tokens.append(("OP", "="))
            i += 1
            continue
        if c == "-" or c.isdigit():
            j = i + 1
            while j < n and (expression[j].isdigit() or expression[j] == "."):
                j += 1
            number_text = expression[i:j]
            if number_text in ("", "-", "."):
                raise ValueError("invalid numeric literal")
            try:
                value = float(number_text)
            except ValueError as exc:
                raise ValueError("invalid numeric literal") from exc
            tokens.append(("NUMBER", value))
            i = j
            continue
        if c.isalpha() or c == "_":
            j = i + 1
            while j < n and (expression[j].isalnum() or expression[j] == "_"):
                j += 1
            word = expression[i:j]
            upper = word.upper()
            if upper == "AND":
                tokens.append(("AND", "AND"))
            elif upper == "OR":
                tokens.append(("OR", "OR"))
            elif upper == "LIKE":
                tokens.append(("OP", "LIKE"))
            else:
                tokens.append(("IDENT", word))
            i = j
            continue
        raise ValueError("unexpected character: " + c)
    return tokens


class _Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def _peek(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return (None, None)

    def _consume(self):
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def parse(self):
        if not self.tokens:
            raise ValueError("empty expression")
        node = self._parse_or()
        if self.pos != len(self.tokens):
            raise ValueError("trailing tokens after expression")
        return node

    def _parse_or(self):
        left = self._parse_and()
        while self._peek()[0] == "OR":
            self._consume()
            right = self._parse_and()
            left = ("OR", left, right)
        return left

    def _parse_and(self):
        left = self._parse_comparison()
        while self._peek()[0] == "AND":
            self._consume()
            right = self._parse_comparison()
            left = ("AND", left, right)
        return left

    def _parse_comparison(self):
        if self._peek()[0] == "LPAREN":
            self._consume()
            inner = self._parse_or()
            if self._peek()[0] != "RPAREN":
                raise ValueError("expected ')'")
            self._consume()
            return inner
        left = self._parse_atom()
        if self._peek()[0] != "OP":
            raise ValueError("expected comparison operator")
        op = self._consume()[1]
        right = self._parse_atom()
        return ("CMP", op, left, right)

    def _parse_atom(self):
        if self.pos >= len(self.tokens):
            raise ValueError("unexpected end of expression")
        tok_kind, tok_val = self._consume()
        if tok_kind == "IDENT":
            return ("FIELD", tok_val)
        if tok_kind == "STRING":
            return ("STR", tok_val)
        if tok_kind == "NUMBER":
            return ("NUM", tok_val)
        raise ValueError("expected identifier, string, or number")


def _parse_expression(expression):
    tokens = _tokenize(expression)
    return _Parser(tokens).parse()


def _resolve_operand(node, payload):
    kind = node[0]
    if kind == "FIELD":
        if node[1] not in payload:
            return _MISSING
        return payload[node[1]]
    if kind == "STR":
        return node[1]
    if kind == "NUM":
        return node[1]
    return _MISSING


def _like_match(value, pattern):
    regex_parts = []
    for ch in pattern:
        if ch == "%":
            regex_parts.append(".*")
        else:
            regex_parts.append(re.escape(ch))
    return re.fullmatch("".join(regex_parts), value, flags=re.DOTALL) is not None


def _evaluate_node(node, payload):
    kind = node[0]
    if kind == "AND":
        if not _evaluate_node(node[1], payload):
            return False
        return _evaluate_node(node[2], payload)
    if kind == "OR":
        if _evaluate_node(node[1], payload):
            return True
        return _evaluate_node(node[2], payload)
    if kind == "CMP":
        op = node[1]
        left_val = _resolve_operand(node[2], payload)
        right_val = _resolve_operand(node[3], payload)
        if left_val is _MISSING or right_val is _MISSING:
            return False
        if op == "=":
            return left_val == right_val
        if op == "!=":
            return left_val != right_val
        if op == "LIKE":
            return _like_match(str(left_val), str(right_val))
        if op in (">", "<", ">=", "<="):
            try:
                lf = float(left_val)
                rf = float(right_val)
            except (TypeError, ValueError):
                return False
            if op == ">":
                return lf > rf
            if op == "<":
                return lf < rf
            if op == ">=":
                return lf >= rf
            if op == "<=":
                return lf <= rf
        return False
    return False


def _evaluate_expression(ast, payload):
    return bool(_evaluate_node(ast, payload))


def _reset_state():
    _rules.clear()
    _user_timelines.clear()
    _throttle.clear()
    _firings.clear()
    if os.path.exists(FIRINGS_LOG_PATH):
        with open(FIRINGS_LOG_PATH, "w"):
            pass


def _parse_iso(ts_str):
    if not isinstance(ts_str, str):
        raise ValueError("timestamp must be a string")
    normalized = ts_str
    if normalized.endswith("Z") or normalized.endswith("z"):
        normalized = normalized[:-1] + "+00:00"
    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
    return parsed


def _prune_timeline(user_id, now):
    if not _rules:
        return
    longest_window = max(rule["window_seconds"] for rule in _rules)
    cutoff = now - timedelta(seconds=longest_window)
    timeline = _user_timelines.get(user_id)
    if not timeline:
        return
    _user_timelines[user_id] = [
        entry for entry in timeline if entry[1] >= cutoff
    ]


def create_app():
    _reset_state()

    app = Flask(__name__)

    @app.route("/rules", methods=["POST"])
    def create_rule():
        body = request.get_json(silent=True) or {}
        expression = body.get("expression", "")
        try:
            ast = _parse_expression(expression)
        except ValueError:
            return jsonify({"error": "invalid expression"}), 400

        rule = {
            "rule_id": str(uuid.uuid4()),
            "expression": expression,
            "window_seconds": int(body.get("window_seconds", 0)),
            "threshold": int(body.get("threshold", 0)),
            "cooldown_seconds": int(body.get("cooldown_seconds", 0)),
            "_ast": ast,
        }
        _rules.append(rule)
        return jsonify({"rule": _public_rule(rule)}), 201

    @app.route("/rules", methods=["GET"])
    def get_rules():
        return jsonify({"rules": [_public_rule(r) for r in _rules]}), 200

    @app.route("/rules/<rule_id>", methods=["DELETE"])
    def delete_rule(rule_id):
        for idx, rule in enumerate(_rules):
            if rule["rule_id"] == rule_id:
                _rules.pop(idx)
                stale_keys = [key for key in _throttle if key[1] == rule_id]
                for key in stale_keys:
                    _throttle.pop(key, None)
                return jsonify({"deleted": rule_id}), 200
        return jsonify({"error": "not found"}), 404

    @app.route("/events", methods=["POST"])
    def ingest_event():
        body = request.get_json(silent=True) or {}
        user_id = body.get("user_id")
        client_ts_str = body.get("timestamp")

        now = datetime.utcnow()

        try:
            client_ts = _parse_iso(client_ts_str)
        except (TypeError, ValueError):
            return jsonify({"error": "timestamp skew exceeds 300s"}), 422

        skew = abs((now - client_ts).total_seconds())
        if skew > MAX_TIMESTAMP_SKEW_SECONDS:
            return jsonify({"error": "timestamp skew exceeds 300s"}), 422

        ingested_at = datetime.utcnow()
        ingested_at_iso = ingested_at.isoformat()

        event = {"user_id": user_id, "timestamp": client_ts_str}
        for key, value in body.items():
            if key in ("user_id", "timestamp"):
                continue
            event[key] = value
        event["ingested_at"] = ingested_at_iso

        timeline = _user_timelines.setdefault(user_id, [])
        timeline.append((event, ingested_at))

        _prune_timeline(user_id, ingested_at)

        response_firings = []
        for rule in list(_rules):
            window_cutoff = ingested_at - timedelta(seconds=rule["window_seconds"])
            user_events = _user_timelines.get(user_id, [])
            matching_events = []
            for stored_event, stored_at in user_events:
                if stored_at < window_cutoff:
                    continue
                if _evaluate_expression(rule["_ast"], stored_event):
                    matching_events.append(stored_event)

            if len(matching_events) <= rule["threshold"]:
                continue

            throttle_key = (user_id, rule["rule_id"])
            last_fired = _throttle.get(throttle_key)
            fire_time = datetime.utcnow()
            if last_fired is not None:
                elapsed = (fire_time - last_fired).total_seconds()
                if elapsed < rule["cooldown_seconds"]:
                    continue

            _throttle[throttle_key] = fire_time

            firing_record = {
                "rule_id": rule["rule_id"],
                "user_id": user_id,
                "fired_at": fire_time.isoformat(),
                "matched_count": len(matching_events),
                "window_events": [dict(e) for e in matching_events],
            }
            _firings.append(firing_record)

            try:
                with open(FIRINGS_LOG_PATH, "a") as log_file:
                    log_file.write(json.dumps(firing_record) + "\n")
            except OSError:
                pass

            response_firings.append({
                "rule_id": firing_record["rule_id"],
                "user_id": firing_record["user_id"],
                "fired_at": firing_record["fired_at"],
                "matched_count": firing_record["matched_count"],
            })

        return jsonify({"status": "ok", "firings": response_firings}), 200

    @app.route("/firings", methods=["GET"])
    def get_firings():
        rule_id_filter = request.args.get("rule_id")
        user_id_filter = request.args.get("user_id")
        limit_arg = request.args.get("limit")
        try:
            limit = int(limit_arg) if limit_arg is not None else DEFAULT_FIRINGS_LIMIT
        except (TypeError, ValueError):
            limit = DEFAULT_FIRINGS_LIMIT

        ordered = list(reversed(_firings))
        filtered = []
        for entry in ordered:
            if rule_id_filter is not None and entry["rule_id"] != rule_id_filter:
                continue
            if user_id_filter is not None and entry["user_id"] != user_id_filter:
                continue
            filtered.append(entry)
            if len(filtered) >= limit:
                break

        return jsonify({"firings": filtered}), 200

    return app


def _public_rule(rule):
    return {
        "rule_id": rule["rule_id"],
        "expression": rule["expression"],
        "window_seconds": rule["window_seconds"],
        "threshold": rule["threshold"],
        "cooldown_seconds": rule["cooldown_seconds"],
    }


if __name__ == "__main__":
    create_app().run(host="0.0.0.0", port=5000)
