"""Exceptions raised by the nacha library."""


class NachaParseError(Exception):
    """Raised by :func:`parse_file` when the input cannot be parsed.

    Carries the 1-based line index of the offending line in
    :attr:`line_number`.
    """

    def __init__(self, message: str, line_number: int):
        super().__init__(message)
        self.message = message
        self.line_number = line_number
