"""Typed dataclasses for the NACHA record-type catalog and the file-level
container types (NachaFile / Batch / Entry).

Every record dataclass stores the verbatim fixed-width text of each field
as parsed from the source line so that a parse -> serialize cycle is
byte-identical when no field is mutated. The `raw` slot keeps the original
line itself for reference; the serializer always rebuilds each line from
the typed fields so mutations on parsed fields flow through.
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class FileHeader:
    record_type_code: str
    priority_code: str
    immediate_destination: str
    immediate_origin: str
    file_creation_date: str
    file_creation_time: str
    file_id_modifier: str
    record_size: str
    blocking_factor: str
    format_code: str
    immediate_destination_name: str
    immediate_origin_name: str
    reference_code: str
    raw: str


@dataclass
class BatchHeader:
    record_type_code: str
    service_class_code: str
    company_name: str
    company_discretionary_data: str
    company_identification: str
    sec_code: str
    company_entry_description: str
    company_descriptive_date: str
    effective_entry_date: str
    settlement_date: str
    originator_status_code: str
    originating_dfi_identification: str
    batch_number: str
    raw: str


@dataclass
class EntryDetail:
    record_type_code: str
    transaction_code: str
    receiving_dfi_identification: str
    check_digit: str
    dfi_account_number: str
    amount: int
    individual_identification_number: str
    individual_name: str
    discretionary_data: str
    addenda_record_indicator: str
    trace_number: str
    raw: str
    # Standard Entry Class code inherited from the parent batch header.
    # Populated by parse_file; not part of the 94-character record layout
    # (so it never affects serialization) and not compared for equality.
    sec_code: str = field(default="", compare=False)


@dataclass
class Addenda:
    record_type_code: str
    addenda_type_code: str
    payload: str
    addenda_sequence_number: str
    entry_detail_sequence_number: str
    raw: str


@dataclass
class BatchControl:
    record_type_code: str
    service_class_code: str
    entry_addenda_count: int
    entry_hash: str
    total_debit: int
    total_credit: int
    company_identification: str
    message_authentication_code: str
    reserved: str
    originating_dfi_identification: str
    batch_number: str
    raw: str


@dataclass
class FileControl:
    record_type_code: str
    batch_count: int
    block_count: int
    entry_addenda_count: int
    entry_hash: str
    total_debit: int
    total_credit: int
    reserved: str
    raw: str


@dataclass
class Entry:
    entry_detail: EntryDetail
    addenda: List[Addenda]

    @property
    def sec_code(self) -> str:
        """Standard Entry Class code of the parent batch, surfaced on the
        entry for convenience (mirrors ``entry_detail.sec_code``)."""
        return self.entry_detail.sec_code


@dataclass
class Batch:
    batch_header: BatchHeader
    entries: List[Entry]
    batch_control: BatchControl

    @property
    def sec_code(self) -> str:
        """Standard Entry Class code of the batch, surfaced directly on the
        batch for convenience (mirrors ``batch_header.sec_code``)."""
        return self.batch_header.sec_code


@dataclass
class NachaFile:
    file_header: FileHeader
    batches: List[Batch]
    file_control: FileControl
    block_padding: List[str]
    line_terminator: str

    # Internal fields populated by parse_file and used by validate_file.
    # Not part of the public constructor surface.
    _record_sequence: list = field(
        default_factory=list, init=False, repr=False, compare=False
    )
    _has_trailing_terminator: bool = field(
        default=True, init=False, repr=False, compare=False
    )
