"""NACHA ACH file parsing, validation, serialization, and control-field
computation.

Public top-level entry points:

* :func:`parse_file` — text -> :class:`nacha.model.NachaFile`
* :func:`serialize_file` — :class:`nacha.model.NachaFile` -> text
* :func:`validate_file` — run an :class:`nacha.rules.OdfiRuleSet` against
  a parsed file and return a list of
  :class:`nacha.rules.ValidationIssue` objects.
* :func:`compute_controls` — return a new :class:`nacha.model.NachaFile`
  with recomputed batch- and file-level control fields.

The module depends only on the Python standard library and requires
Python 3.10 or newer.
"""

from nacha.controls import compute_controls
from nacha.exceptions import NachaParseError
from nacha.model import (
    Addenda,
    Batch,
    BatchControl,
    BatchHeader,
    Entry,
    EntryDetail,
    FileControl,
    FileHeader,
    NachaFile,
)
from nacha.parser import parse_file
from nacha.rules import OdfiRuleSet, ValidationIssue
from nacha.serializer import serialize_file
from nacha.validator import validate_file

__all__ = [
    "parse_file",
    "serialize_file",
    "validate_file",
    "compute_controls",
    "NachaParseError",
    "NachaFile",
    "Batch",
    "Entry",
    "FileHeader",
    "BatchHeader",
    "EntryDetail",
    "Addenda",
    "BatchControl",
    "FileControl",
    "OdfiRuleSet",
    "ValidationIssue",
]
