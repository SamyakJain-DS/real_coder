"""Serializer for NACHA ACH files.

When the input object was produced by :func:`nacha.parse_file` and no field
of a record has been mutated, the serializer re-emits that record's original
source line verbatim (taken from the ``raw`` slot), so a ``parse -> serialize``
cycle is byte-identical for *every* input the parser accepts -- including
inputs whose numeric fields use non-canonical padding (e.g. space padding
instead of zero fill).

When a field *has* been mutated, the line is rebuilt from the typed fields
while preserving the position-and-width layout of the NACHA specification, so
the caller's change is reflected in the output and surrounding fields keep
their exact bytes.
"""

from nacha.model import (
    Addenda,
    BatchControl,
    BatchHeader,
    EntryDetail,
    FileControl,
    FileHeader,
    NachaFile,
)


# ---------------------------------------------------------------------------
# Verbatim passthrough for unmutated records
# ---------------------------------------------------------------------------

def _verbatim(record):
    """Return ``record.raw`` if it round-trips to a record equal to ``record``
    (i.e. no typed field has been mutated since parsing), else ``None``.

    Comparing against a fresh re-parse of ``raw`` is what lets non-canonical
    numeric padding survive untouched: a space-padded amount parses to the
    same ``int`` it did originally, so the records compare equal and the
    original bytes are re-emitted.
    """
    raw = getattr(record, "raw", None)
    if not isinstance(raw, str) or len(raw) != 94:
        return None
    # Imported lazily to avoid any import-ordering coupling with nacha.parser.
    from nacha import parser as _parser

    try:
        cls = type(record).__name__
        if cls == "FileHeader":
            reference = _parser._parse_file_header(raw)
        elif cls == "BatchHeader":
            reference = _parser._parse_batch_header(raw)
        elif cls == "EntryDetail":
            reference = _parser._parse_entry_detail(raw, 0)
        elif cls == "Addenda":
            reference = _parser._parse_addenda(raw)
        elif cls == "BatchControl":
            reference = _parser._parse_batch_control(raw, 0)
        elif cls == "FileControl":
            reference = _parser._parse_file_control(raw, 0)
        else:  # pragma: no cover - not reachable for known record types
            return None
    except _parser.NachaParseError:
        return None
    return raw if record == reference else None


# ---------------------------------------------------------------------------
# Field-width helpers
# ---------------------------------------------------------------------------

def _str_field(value, width: int, pad_char: str = " ") -> str:
    s = "" if value is None else str(value)
    if len(s) >= width:
        return s[:width]
    return s.ljust(width, pad_char)


def _int_field(value, width: int) -> str:
    try:
        n = int(value)
    except (TypeError, ValueError):
        # Fall back to treating it as a pre-formatted string.
        s = str(value)
        if len(s) >= width:
            return s[:width]
        return s.rjust(width, "0")
    if n < 0:
        n = 0
    s = str(n)
    if len(s) >= width:
        # Use the rightmost ``width`` digits if it overflows.
        return s[-width:]
    return s.rjust(width, "0")


def _hash_field(value, width: int = 10) -> str:
    # Entry hash is stored verbatim as a string slice; keep it that way on
    # output, only padding if a caller assigned a shorter value.
    s = "" if value is None else str(value)
    if len(s) >= width:
        return s[-width:] if s.isdigit() else s[:width]
    return s.rjust(width, "0") if s.isdigit() or s == "" else s.ljust(width)


# ---------------------------------------------------------------------------
# Per-record serializers
# ---------------------------------------------------------------------------

def _serialize_file_header(fh: FileHeader) -> str:
    raw = _verbatim(fh)
    if raw is not None:
        return raw
    line = (
        _str_field(fh.record_type_code, 1)
        + _str_field(fh.priority_code, 2)
        + _str_field(fh.immediate_destination, 10)
        + _str_field(fh.immediate_origin, 10)
        + _str_field(fh.file_creation_date, 6)
        + _str_field(fh.file_creation_time, 4)
        + _str_field(fh.file_id_modifier, 1)
        + _str_field(fh.record_size, 3)
        + _str_field(fh.blocking_factor, 2)
        + _str_field(fh.format_code, 1)
        + _str_field(fh.immediate_destination_name, 23)
        + _str_field(fh.immediate_origin_name, 23)
        + _str_field(fh.reference_code, 8)
    )
    return line[:94].ljust(94)


def _serialize_batch_header(bh: BatchHeader) -> str:
    raw = _verbatim(bh)
    if raw is not None:
        return raw
    line = (
        _str_field(bh.record_type_code, 1)
        + _str_field(bh.service_class_code, 3)
        + _str_field(bh.company_name, 16)
        + _str_field(bh.company_discretionary_data, 20)
        + _str_field(bh.company_identification, 10)
        + _str_field(bh.sec_code, 3)
        + _str_field(bh.company_entry_description, 10)
        + _str_field(bh.company_descriptive_date, 6)
        + _str_field(bh.effective_entry_date, 6)
        + _str_field(bh.settlement_date, 3)
        + _str_field(bh.originator_status_code, 1)
        + _str_field(bh.originating_dfi_identification, 8)
        + _str_field(bh.batch_number, 7)
    )
    return line[:94].ljust(94)


def _serialize_entry_detail(ed: EntryDetail) -> str:
    raw = _verbatim(ed)
    if raw is not None:
        return raw
    line = (
        _str_field(ed.record_type_code, 1)
        + _str_field(ed.transaction_code, 2)
        + _str_field(ed.receiving_dfi_identification, 8)
        + _str_field(ed.check_digit, 1)
        + _str_field(ed.dfi_account_number, 17)
        + _int_field(ed.amount, 10)
        + _str_field(ed.individual_identification_number, 15)
        + _str_field(ed.individual_name, 22)
        + _str_field(ed.discretionary_data, 2)
        + _str_field(ed.addenda_record_indicator, 1)
        + _str_field(ed.trace_number, 15)
    )
    return line[:94].ljust(94)


def _serialize_addenda(ad: Addenda) -> str:
    raw = _verbatim(ad)
    if raw is not None:
        return raw
    line = (
        _str_field(ad.record_type_code, 1)
        + _str_field(ad.addenda_type_code, 2)
        + _str_field(ad.payload, 80)
        + _str_field(ad.addenda_sequence_number, 4)
        + _str_field(ad.entry_detail_sequence_number, 7)
    )
    return line[:94].ljust(94)


def _serialize_batch_control(bc: BatchControl) -> str:
    raw = _verbatim(bc)
    if raw is not None:
        return raw
    line = (
        _str_field(bc.record_type_code, 1)
        + _str_field(bc.service_class_code, 3)
        + _int_field(bc.entry_addenda_count, 6)
        + _hash_field(bc.entry_hash, 10)
        + _int_field(bc.total_debit, 12)
        + _int_field(bc.total_credit, 12)
        + _str_field(bc.company_identification, 10)
        + _str_field(bc.message_authentication_code, 19)
        + _str_field(bc.reserved, 6)
        + _str_field(bc.originating_dfi_identification, 8)
        + _str_field(bc.batch_number, 7)
    )
    return line[:94].ljust(94)


def _serialize_file_control(fc: FileControl) -> str:
    raw = _verbatim(fc)
    if raw is not None:
        return raw
    line = (
        _str_field(fc.record_type_code, 1)
        + _int_field(fc.batch_count, 6)
        + _int_field(fc.block_count, 6)
        + _int_field(fc.entry_addenda_count, 8)
        + _hash_field(fc.entry_hash, 10)
        + _int_field(fc.total_debit, 12)
        + _int_field(fc.total_credit, 12)
        + _str_field(fc.reserved, 39)
    )
    return line[:94].ljust(94)


# ---------------------------------------------------------------------------
# Top-level serialize_file
# ---------------------------------------------------------------------------

def serialize_file(nacha_file: NachaFile) -> str:
    lines = []
    lines.append(_serialize_file_header(nacha_file.file_header))
    for batch in nacha_file.batches:
        lines.append(_serialize_batch_header(batch.batch_header))
        for entry in batch.entries:
            lines.append(_serialize_entry_detail(entry.entry_detail))
            for ad in entry.addenda:
                lines.append(_serialize_addenda(ad))
        lines.append(_serialize_batch_control(batch.batch_control))
    lines.append(_serialize_file_control(nacha_file.file_control))
    for pad in nacha_file.block_padding:
        lines.append(pad)

    terminator = nacha_file.line_terminator or "\n"
    out = terminator.join(lines)
    has_trailing = getattr(nacha_file, "_has_trailing_terminator", True)
    if has_trailing:
        out += terminator
    return out
