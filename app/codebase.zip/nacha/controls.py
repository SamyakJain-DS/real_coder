"""Recompute NACHA batch- and file-level control fields.

``compute_controls`` returns a brand-new ``NachaFile`` whose batch control
and file control records carry recomputed entry/addenda counts, entry
hashes, debit/credit totals, batch count, and block count. The input
``NachaFile`` and every record reachable from it remain untouched, so a
caller still holds a reference to the pre-recompute snapshot.
"""

import copy

from nacha.model import NachaFile


_DEBIT_TRANSACTION_CODES = frozenset({"27", "28", "37", "38"})
_CREDIT_TRANSACTION_CODES = frozenset({"22", "23", "32", "33"})


def _routing_prefix_to_int(value: str) -> int:
    if value is None:
        return 0
    digits = "".join(c for c in str(value) if c.isdigit())
    if not digits:
        return 0
    return int(digits)


def compute_controls(nacha_file: NachaFile) -> NachaFile:
    new_file = copy.deepcopy(nacha_file)

    file_entry_addenda_count = 0
    file_routing_total = 0
    file_total_debit = 0
    file_total_credit = 0

    for batch in new_file.batches:
        batch_entry_addenda_count = 0
        batch_routing_total = 0
        batch_total_debit = 0
        batch_total_credit = 0

        for entry in batch.entries:
            ed = entry.entry_detail
            batch_routing_total += _routing_prefix_to_int(
                ed.receiving_dfi_identification
            )
            batch_entry_addenda_count += 1
            for _ in entry.addenda:
                batch_entry_addenda_count += 1
            tc = ed.transaction_code
            if tc in _DEBIT_TRANSACTION_CODES:
                batch_total_debit += int(ed.amount or 0)
            elif tc in _CREDIT_TRANSACTION_CODES:
                batch_total_credit += int(ed.amount or 0)

        bc = batch.batch_control
        bc.entry_addenda_count = batch_entry_addenda_count
        bc.entry_hash = str(batch_routing_total % 10 ** 10).rjust(10, "0")
        bc.total_debit = batch_total_debit
        bc.total_credit = batch_total_credit

        file_entry_addenda_count += batch_entry_addenda_count
        file_routing_total += batch_routing_total
        file_total_debit += batch_total_debit
        file_total_credit += batch_total_credit

    fc = new_file.file_control
    fc.batch_count = len(new_file.batches)
    fc.entry_addenda_count = file_entry_addenda_count
    fc.entry_hash = str(file_routing_total % 10 ** 10).rjust(10, "0")
    fc.total_debit = file_total_debit
    fc.total_credit = file_total_credit

    total_records = (
        1  # file header
        + sum(
            1  # batch header
            + len(batch.entries)
            + sum(len(entry.addenda) for entry in batch.entries)
            + 1  # batch control
            for batch in new_file.batches
        )
        + 1  # file control
        + len(new_file.block_padding)
    )
    fc.block_count = (total_records + 9) // 10

    return new_file
