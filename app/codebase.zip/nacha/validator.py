"""Validation of parsed NACHA files against an ODFI rule set.

The validator emits :class:`nacha.rules.ValidationIssue` records using the
exact ``rule`` identifiers documented on the prompt. It checks four
families of rules:

* Structural rules — file begins with a 1 record, ends with a 9 record,
  every batch begins with a 5 and ends with an 8, and every record-7
  addenda line is preceded by a record-6 entry or another record-7
  addenda.
* Control-field rules — entry/addenda counts, entry hashes, and debit /
  credit totals on each batch control and the file control match the
  values recomputed from the entries and addenda; the file batch count
  matches the number of batches.
* Per-SEC-code addenda content rules — IAT/CTX/PPD/CCD/WEB/TEL/ARC/BOC/
  POP/RCK entries carry the expected shape of addenda for their SEC code.
* ODFI-scoped allowlist rules — the file header's Immediate Origin and
  Immediate Destination, and each batch header's Company Identification,
  appear in the rule set's permitted lists.
"""

from typing import List

from nacha.model import NachaFile
from nacha.rules import OdfiRuleSet, ValidationIssue


_DEBIT_TRANSACTION_CODES = frozenset({"27", "28", "37", "38"})
_CREDIT_TRANSACTION_CODES = frozenset({"22", "23", "32", "33"})

_IAT_REQUIRED_SEQUENCE = ("10", "11", "12", "13", "14", "15", "16")


# ---------------------------------------------------------------------------
# Line-number plan
# ---------------------------------------------------------------------------

def _line_plan(nacha_file: NachaFile):
    """Compute 1-based line numbers for every record in source order.

    Returns a dict keyed by ``("file_header",)``, ``("file_control",)``,
    ``("batch_header", batch_index)``, ``("batch_control", batch_index)``,
    ``("entry", batch_index, entry_index)``, and
    ``("addenda", batch_index, entry_index, addenda_index)``.
    """
    plan = {}
    line = 1
    plan[("file_header",)] = line
    line += 1
    for bi, batch in enumerate(nacha_file.batches):
        plan[("batch_header", bi)] = line
        line += 1
        for ei, entry in enumerate(batch.entries):
            plan[("entry", bi, ei)] = line
            line += 1
            for ai, _ad in enumerate(entry.addenda):
                plan[("addenda", bi, ei, ai)] = line
                line += 1
        plan[("batch_control", bi)] = line
        line += 1
    plan[("file_control",)] = line
    return plan


# ---------------------------------------------------------------------------
# Structural rules
# ---------------------------------------------------------------------------

def _structural_issues(nacha_file: NachaFile, plan) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []

    if nacha_file.file_header.record_type_code != "1":
        issues.append(ValidationIssue(
            rule="structural.file_starts_with_header",
            message=(
                "File header record_type_code is "
                f"{nacha_file.file_header.record_type_code!r}, expected '1'."
            ),
            line_number=plan[("file_header",)],
            record_type="1",
        ))

    if nacha_file.file_control.record_type_code != "9":
        issues.append(ValidationIssue(
            rule="structural.file_ends_with_control",
            message=(
                "File control record_type_code is "
                f"{nacha_file.file_control.record_type_code!r}, expected '9'."
            ),
            line_number=plan[("file_control",)],
            record_type="9",
        ))

    for bi, batch in enumerate(nacha_file.batches):
        if batch.batch_header.record_type_code != "5":
            issues.append(ValidationIssue(
                rule="structural.batch_starts_with_header",
                message=(
                    f"Batch {bi + 1} header record_type_code is "
                    f"{batch.batch_header.record_type_code!r}, expected '5'."
                ),
                line_number=plan[("batch_header", bi)],
                record_type="5",
            ))
        if batch.batch_control.record_type_code != "8":
            issues.append(ValidationIssue(
                rule="structural.batch_ends_with_control",
                message=(
                    f"Batch {bi + 1} control record_type_code is "
                    f"{batch.batch_control.record_type_code!r}, expected '8'."
                ),
                line_number=plan[("batch_control", bi)],
                record_type="8",
            ))

    # Addenda orphan detection uses the parser's recorded record sequence
    # (1-based line number, record type code). For user-constructed files
    # the sequence is empty and this rule is skipped.
    record_sequence = getattr(nacha_file, "_record_sequence", []) or []
    for i in range(1, len(record_sequence)):
        prev_type = record_sequence[i - 1][1]
        curr_line, curr_type = record_sequence[i]
        if curr_type == "7" and prev_type not in ("6", "7"):
            issues.append(ValidationIssue(
                rule="structural.addenda_orphan",
                message=(
                    f"Addenda record at line {curr_line} is not preceded "
                    "by an entry detail or another addenda record."
                ),
                line_number=curr_line,
                record_type="7",
            ))

    return issues


# ---------------------------------------------------------------------------
# Control-field rules
# ---------------------------------------------------------------------------

def _routing_prefix_to_int(value: str) -> int:
    if value is None:
        return 0
    digits = "".join(c for c in str(value) if c.isdigit())
    if not digits:
        return 0
    return int(digits)


def _control_issues(nacha_file: NachaFile, plan) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []

    file_eac = 0
    file_routing_total = 0
    file_total_debit = 0
    file_total_credit = 0

    for bi, batch in enumerate(nacha_file.batches):
        batch_eac = 0
        batch_routing_total = 0
        batch_total_debit = 0
        batch_total_credit = 0
        for entry in batch.entries:
            ed = entry.entry_detail
            batch_routing_total += _routing_prefix_to_int(
                ed.receiving_dfi_identification
            )
            batch_eac += 1
            for _ in entry.addenda:
                batch_eac += 1
            tc = ed.transaction_code
            if tc in _DEBIT_TRANSACTION_CODES:
                batch_total_debit += int(ed.amount or 0)
            elif tc in _CREDIT_TRANSACTION_CODES:
                batch_total_credit += int(ed.amount or 0)

        bc = batch.batch_control
        bc_line = plan[("batch_control", bi)]

        if int(bc.entry_addenda_count) != batch_eac:
            issues.append(ValidationIssue(
                rule="control.batch_entry_addenda_count",
                message=(
                    f"Batch {bi + 1} entry/addenda count "
                    f"{bc.entry_addenda_count} differs from recomputed "
                    f"value {batch_eac}."
                ),
                line_number=bc_line,
                record_type="8",
            ))
        expected_hash = str(batch_routing_total % 10 ** 10).rjust(10, "0")
        actual_hash = str(bc.entry_hash).rjust(10, "0")
        try:
            if int(actual_hash) != int(expected_hash):
                issues.append(ValidationIssue(
                    rule="control.batch_entry_hash",
                    message=(
                        f"Batch {bi + 1} entry hash {actual_hash!r} "
                        f"differs from recomputed value {expected_hash!r}."
                    ),
                    line_number=bc_line,
                    record_type="8",
                ))
        except ValueError:
            if actual_hash != expected_hash:
                issues.append(ValidationIssue(
                    rule="control.batch_entry_hash",
                    message=(
                        f"Batch {bi + 1} entry hash {actual_hash!r} "
                        f"differs from recomputed value {expected_hash!r}."
                    ),
                    line_number=bc_line,
                    record_type="8",
                ))
        if int(bc.total_debit) != batch_total_debit:
            issues.append(ValidationIssue(
                rule="control.batch_total_debit",
                message=(
                    f"Batch {bi + 1} total debit {bc.total_debit} differs "
                    f"from recomputed value {batch_total_debit}."
                ),
                line_number=bc_line,
                record_type="8",
            ))
        if int(bc.total_credit) != batch_total_credit:
            issues.append(ValidationIssue(
                rule="control.batch_total_credit",
                message=(
                    f"Batch {bi + 1} total credit {bc.total_credit} differs "
                    f"from recomputed value {batch_total_credit}."
                ),
                line_number=bc_line,
                record_type="8",
            ))

        file_eac += batch_eac
        file_routing_total += batch_routing_total
        file_total_debit += batch_total_debit
        file_total_credit += batch_total_credit

    fc = nacha_file.file_control
    fc_line = plan[("file_control",)]
    expected_file_hash = str(file_routing_total % 10 ** 10).rjust(10, "0")
    actual_file_hash = str(fc.entry_hash).rjust(10, "0")

    if int(fc.entry_addenda_count) != file_eac:
        issues.append(ValidationIssue(
            rule="control.file_entry_addenda_count",
            message=(
                f"File entry/addenda count {fc.entry_addenda_count} differs "
                f"from recomputed value {file_eac}."
            ),
            line_number=fc_line,
            record_type="9",
        ))
    try:
        if int(actual_file_hash) != int(expected_file_hash):
            issues.append(ValidationIssue(
                rule="control.file_entry_hash",
                message=(
                    f"File entry hash {actual_file_hash!r} differs from "
                    f"recomputed value {expected_file_hash!r}."
                ),
                line_number=fc_line,
                record_type="9",
            ))
    except ValueError:
        if actual_file_hash != expected_file_hash:
            issues.append(ValidationIssue(
                rule="control.file_entry_hash",
                message=(
                    f"File entry hash {actual_file_hash!r} differs from "
                    f"recomputed value {expected_file_hash!r}."
                ),
                line_number=fc_line,
                record_type="9",
            ))
    if int(fc.total_debit) != file_total_debit:
        issues.append(ValidationIssue(
            rule="control.file_total_debit",
            message=(
                f"File total debit {fc.total_debit} differs from recomputed "
                f"value {file_total_debit}."
            ),
            line_number=fc_line,
            record_type="9",
        ))
    if int(fc.total_credit) != file_total_credit:
        issues.append(ValidationIssue(
            rule="control.file_total_credit",
            message=(
                f"File total credit {fc.total_credit} differs from recomputed "
                f"value {file_total_credit}."
            ),
            line_number=fc_line,
            record_type="9",
        ))
    if int(fc.batch_count) != len(nacha_file.batches):
        issues.append(ValidationIssue(
            rule="control.file_batch_count",
            message=(
                f"File batch count {fc.batch_count} differs from recomputed "
                f"value {len(nacha_file.batches)}."
            ),
            line_number=fc_line,
            record_type="9",
        ))

    return issues


# ---------------------------------------------------------------------------
# Per-SEC-code addenda content rules
# ---------------------------------------------------------------------------

def _is_valid_iat_sequence(type_codes) -> bool:
    if len(type_codes) < 7:
        return False
    if tuple(type_codes[:7]) != _IAT_REQUIRED_SEQUENCE:
        return False
    extras = type_codes[7:]
    if len(extras) == 0:
        return True
    if len(extras) == 1:
        return extras[0] == "17"
    if len(extras) == 2:
        return extras[0] == "17" and extras[1] == "18"
    return False


def _sec_issues(nacha_file: NachaFile, plan) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []
    for bi, batch in enumerate(nacha_file.batches):
        sec = batch.batch_header.sec_code
        for ei, entry in enumerate(batch.entries):
            entry_line = plan[("entry", bi, ei)]
            type_codes = [a.addenda_type_code for a in entry.addenda]
            if sec == "IAT":
                if not _is_valid_iat_sequence(type_codes):
                    issues.append(ValidationIssue(
                        rule="sec.iat_addenda_sequence",
                        message=(
                            f"IAT entry at line {entry_line} addenda sequence "
                            f"{type_codes!r} does not match the mandatory "
                            "IAT layout."
                        ),
                        line_number=entry_line,
                        record_type="6",
                    ))
            elif sec == "CTX":
                bad = [t for t in type_codes if t != "05"]
                if bad:
                    issues.append(ValidationIssue(
                        rule="sec.ctx_addenda_type",
                        message=(
                            f"CTX entry at line {entry_line} carries addenda "
                            f"type codes {bad!r}; CTX addenda must all be '05'."
                        ),
                        line_number=entry_line,
                        record_type="6",
                    ))
            elif sec in ("PPD", "CCD", "WEB", "TEL"):
                indicator = entry.entry_detail.addenda_record_indicator
                if indicator == "1":
                    if len(type_codes) != 1 or type_codes[0] != "05":
                        issues.append(ValidationIssue(
                            rule="sec.ppd_ccd_web_tel_addenda",
                            message=(
                                f"{sec} entry at line {entry_line} with "
                                "addenda record indicator '1' must carry "
                                "exactly one type '05' addenda; got "
                                f"{type_codes!r}."
                            ),
                            line_number=entry_line,
                            record_type="6",
                        ))
                else:
                    if len(type_codes) != 0:
                        issues.append(ValidationIssue(
                            rule="sec.ppd_ccd_web_tel_addenda",
                            message=(
                                f"{sec} entry at line {entry_line} with "
                                "addenda record indicator '0' must carry "
                                f"zero addenda; got {type_codes!r}."
                            ),
                            line_number=entry_line,
                            record_type="6",
                        ))
            elif sec in ("ARC", "BOC", "POP", "RCK"):
                if len(type_codes) != 0:
                    issues.append(ValidationIssue(
                        rule="sec.arc_boc_pop_rck_addenda",
                        message=(
                            f"{sec} entry at line {entry_line} must carry "
                            f"zero addenda; got {type_codes!r}."
                        ),
                        line_number=entry_line,
                        record_type="6",
                    ))
    return issues


# ---------------------------------------------------------------------------
# ODFI allowlist rules
# ---------------------------------------------------------------------------

def _odfi_issues(
    nacha_file: NachaFile, rules: OdfiRuleSet, plan
) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []
    fh = nacha_file.file_header
    fh_line = plan[("file_header",)]

    if fh.immediate_origin not in rules.permitted_immediate_origins:
        issues.append(ValidationIssue(
            rule="odfi.permitted_origin",
            message=(
                f"File header Immediate Origin {fh.immediate_origin!r} is "
                "not in the permitted allowlist."
            ),
            line_number=fh_line,
            record_type="1",
        ))
    if fh.immediate_destination not in rules.permitted_immediate_destinations:
        issues.append(ValidationIssue(
            rule="odfi.permitted_destination",
            message=(
                f"File header Immediate Destination "
                f"{fh.immediate_destination!r} is not in the permitted "
                "allowlist."
            ),
            line_number=fh_line,
            record_type="1",
        ))

    for bi, batch in enumerate(nacha_file.batches):
        cid = batch.batch_header.company_identification
        if cid not in rules.permitted_company_ids:
            issues.append(ValidationIssue(
                rule="odfi.permitted_company_id",
                message=(
                    f"Batch {bi + 1} Company Identification {cid!r} is not "
                    "in the permitted allowlist."
                ),
                line_number=plan[("batch_header", bi)],
                record_type="5",
            ))

    return issues


# ---------------------------------------------------------------------------
# Top-level validate_file
# ---------------------------------------------------------------------------

def validate_file(
    nacha_file: NachaFile, rules: OdfiRuleSet
) -> List[ValidationIssue]:
    plan = _line_plan(nacha_file)
    issues: List[ValidationIssue] = []
    if rules.enforce_structural:
        issues.extend(_structural_issues(nacha_file, plan))
    if rules.enforce_control_fields:
        issues.extend(_control_issues(nacha_file, plan))
    if rules.enforce_sec_addenda_content:
        issues.extend(_sec_issues(nacha_file, plan))
    # ODFI-scoped allowlist rules are always evaluated; they are gated only
    # by the allowlist contents.
    issues.extend(_odfi_issues(nacha_file, rules, plan))
    return issues
