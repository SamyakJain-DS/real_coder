"""Parser for NACHA ACH files.

The parser walks a single in-memory text string, splits it into 94-character
records on either ``\\n`` or ``\\r\\n`` terminators, and produces a typed
:class:`nacha.model.NachaFile` whose nested records preserve every original
byte. Trailing all-9 filler lines are recognised as block padding and kept
separately from the File Control record so they can be re-emitted verbatim.
"""

from typing import List, Tuple

from nacha.exceptions import NachaParseError
from nacha.model import (
    Addenda,
    Batch,
    BatchControl,
    BatchHeader,
    Entry,
    EntryDetail,
    FileControl,
    FileHeader,
    NachaFile,
)


_VALID_RECORD_TYPES = frozenset("156789")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _detect_terminator(text: str) -> str:
    # Prefer CRLF if any record line ends with \r before the \n; otherwise LF.
    return "\r\n" if "\r\n" in text else "\n"


def _split_lines(text: str) -> Tuple[List[str], str, bool]:
    terminator = _detect_terminator(text)
    parts = text.split(terminator)
    has_trailing = bool(parts) and parts[-1] == ""
    if has_trailing:
        parts = parts[:-1]
    return parts, terminator, has_trailing


# ---------------------------------------------------------------------------
# Single-record parsers
# ---------------------------------------------------------------------------

def _parse_file_header(line: str) -> FileHeader:
    return FileHeader(
        record_type_code=line[0:1],
        priority_code=line[1:3],
        immediate_destination=line[3:13],
        immediate_origin=line[13:23],
        file_creation_date=line[23:29],
        file_creation_time=line[29:33],
        file_id_modifier=line[33:34],
        record_size=line[34:37],
        blocking_factor=line[37:39],
        format_code=line[39:40],
        immediate_destination_name=line[40:63],
        immediate_origin_name=line[63:86],
        reference_code=line[86:94],
        raw=line,
    )


def _parse_batch_header(line: str) -> BatchHeader:
    return BatchHeader(
        record_type_code=line[0:1],
        service_class_code=line[1:4],
        company_name=line[4:20],
        company_discretionary_data=line[20:40],
        company_identification=line[40:50],
        sec_code=line[50:53],
        company_entry_description=line[53:63],
        company_descriptive_date=line[63:69],
        effective_entry_date=line[69:75],
        settlement_date=line[75:78],
        originator_status_code=line[78:79],
        originating_dfi_identification=line[79:87],
        batch_number=line[87:94],
        raw=line,
    )


def _parse_entry_detail(
    line: str, line_number: int, sec_code: str = ""
) -> EntryDetail:
    amount_text = line[29:39]
    try:
        amount = int(amount_text)
    except ValueError:
        raise NachaParseError(
            f"line {line_number} entry detail amount is not numeric: "
            f"{amount_text!r}",
            line_number,
        )
    return EntryDetail(
        record_type_code=line[0:1],
        transaction_code=line[1:3],
        receiving_dfi_identification=line[3:11],
        check_digit=line[11:12],
        dfi_account_number=line[12:29],
        amount=amount,
        individual_identification_number=line[39:54],
        individual_name=line[54:76],
        discretionary_data=line[76:78],
        addenda_record_indicator=line[78:79],
        trace_number=line[79:94],
        raw=line,
        sec_code=sec_code,
    )


def _parse_addenda(line: str) -> Addenda:
    return Addenda(
        record_type_code=line[0:1],
        addenda_type_code=line[1:3],
        payload=line[3:83],
        addenda_sequence_number=line[83:87],
        entry_detail_sequence_number=line[87:94],
        raw=line,
    )


def _parse_batch_control(line: str, line_number: int) -> BatchControl:
    try:
        eac = int(line[4:10])
        td = int(line[20:32])
        tc = int(line[32:44])
    except ValueError:
        raise NachaParseError(
            f"line {line_number} batch control numeric field is malformed",
            line_number,
        )
    return BatchControl(
        record_type_code=line[0:1],
        service_class_code=line[1:4],
        entry_addenda_count=eac,
        entry_hash=line[10:20],
        total_debit=td,
        total_credit=tc,
        company_identification=line[44:54],
        message_authentication_code=line[54:73],
        reserved=line[73:79],
        originating_dfi_identification=line[79:87],
        batch_number=line[87:94],
        raw=line,
    )


def _parse_file_control(line: str, line_number: int) -> FileControl:
    try:
        bc = int(line[1:7])
        blc = int(line[7:13])
        eac = int(line[13:21])
        td = int(line[31:43])
        tc = int(line[43:55])
    except ValueError:
        raise NachaParseError(
            f"line {line_number} file control numeric field is malformed",
            line_number,
        )
    return FileControl(
        record_type_code=line[0:1],
        batch_count=bc,
        block_count=blc,
        entry_addenda_count=eac,
        entry_hash=line[21:31],
        total_debit=td,
        total_credit=tc,
        reserved=line[55:94],
        raw=line,
    )


# ---------------------------------------------------------------------------
# Top-level parse_file
# ---------------------------------------------------------------------------

def parse_file(text: str) -> NachaFile:
    if not isinstance(text, str):
        raise NachaParseError("parse_file requires a str input", 1)
    if text == "":
        raise NachaParseError("parse_file received empty input", 1)

    parts, terminator, has_trailing = _split_lines(text)

    if not parts:
        raise NachaParseError("parse_file received empty input", 1)

    # Every line must be exactly 94 characters.
    for idx, line in enumerate(parts, start=1):
        if len(line) != 94:
            raise NachaParseError(
                f"line {idx} has {len(line)} characters, expected 94",
                idx,
            )

    # First line must be a File Header (record type code "1").
    if parts[0][0:1] != "1":
        raise NachaParseError(
            "file does not begin with a record type 1 line",
            1,
        )

    # Every line must carry a recognised record type code.
    for idx, line in enumerate(parts, start=1):
        if line[0:1] not in _VALID_RECORD_TYPES:
            raise NachaParseError(
                f"line {idx} has unrecognised record type code: "
                f"{line[0:1]!r}",
                idx,
            )

    # Identify trailing block padding: contiguous all-9 lines at the end.
    # The File Control line also starts with '9' but contains numeric fields
    # so it will not be all-9 in any realistic input.
    pad_start = len(parts)
    while pad_start > 0 and set(parts[pad_start - 1]) == {"9"}:
        pad_start -= 1
    block_padding = list(parts[pad_start:])
    body = parts[:pad_start]

    record_sequence = [(i + 1, line[0:1]) for i, line in enumerate(parts)]

    # Walk the body in source order to build the typed structure.
    file_header = None
    file_control = None
    batches: List[Batch] = []

    current_batch_header = None
    current_batch_entries: List[Entry] = []
    current_entry = None

    for idx in range(len(body)):
        line = body[idx]
        line_number = idx + 1
        rtype = line[0:1]

        if rtype == "1":
            file_header = _parse_file_header(line)
        elif rtype == "5":
            current_batch_header = _parse_batch_header(line)
            current_batch_entries = []
            current_entry = None
        elif rtype == "6":
            sec = (
                current_batch_header.sec_code
                if current_batch_header is not None
                else ""
            )
            ed = _parse_entry_detail(line, line_number, sec)
            current_entry = Entry(entry_detail=ed, addenda=[])
            current_batch_entries.append(current_entry)
        elif rtype == "7":
            ad = _parse_addenda(line)
            if current_entry is not None:
                current_entry.addenda.append(ad)
            else:
                # Orphan addenda: keep it on the most-recent batch if one
                # exists so it survives a round trip, otherwise attach to
                # the last batch's last entry (best effort). The structural
                # validator inspects record_sequence to flag this case.
                if current_batch_header is not None and current_batch_entries:
                    current_batch_entries[-1].addenda.append(ad)
                # If neither exists, the addenda is dropped from the typed
                # tree; the structural rule still fires because the record
                # appears in record_sequence with a non-6/7 predecessor.
        elif rtype == "8":
            bc = _parse_batch_control(line, line_number)
            # If a batch control appears before a batch header, fabricate a
            # minimal batch header so the validator can still see the
            # structural violation via record_type_code.
            header = current_batch_header
            if header is None:
                header = BatchHeader(
                    record_type_code="",
                    service_class_code=bc.service_class_code,
                    company_name="",
                    company_discretionary_data="",
                    company_identification=bc.company_identification,
                    sec_code="",
                    company_entry_description="",
                    company_descriptive_date="",
                    effective_entry_date="",
                    settlement_date="",
                    originator_status_code="",
                    originating_dfi_identification=(
                        bc.originating_dfi_identification
                    ),
                    batch_number=bc.batch_number,
                    raw="",
                )
            batches.append(Batch(
                batch_header=header,
                entries=current_batch_entries,
                batch_control=bc,
            ))
            current_batch_header = None
            current_batch_entries = []
            current_entry = None
        elif rtype == "9":
            file_control = _parse_file_control(line, line_number)

    # Handle the case where the body ended with an open batch (no batch
    # control record). Attach a placeholder batch_control so validation
    # surfaces the structural violation rather than crashing.
    if current_batch_header is not None:
        placeholder_bc = BatchControl(
            record_type_code="",
            service_class_code=current_batch_header.service_class_code,
            entry_addenda_count=0,
            entry_hash="0" * 10,
            total_debit=0,
            total_credit=0,
            company_identification=(
                current_batch_header.company_identification
            ),
            message_authentication_code=" " * 19,
            reserved=" " * 6,
            originating_dfi_identification=(
                current_batch_header.originating_dfi_identification
            ),
            batch_number=current_batch_header.batch_number,
            raw="",
        )
        batches.append(Batch(
            batch_header=current_batch_header,
            entries=current_batch_entries,
            batch_control=placeholder_bc,
        ))

    # File header is guaranteed by the up-front "starts with record type 1"
    # check; file_control may be missing if the file does not end with a 9
    # record. Provide a placeholder so the typed model is well-formed; the
    # validator's structural rule surfaces the violation through the
    # record_type_code mismatch.
    if file_header is None:  # pragma: no cover - guarded above
        raise NachaParseError("file is missing a file header", 1)

    if file_control is None:
        file_control = FileControl(
            record_type_code="",
            batch_count=len(batches),
            block_count=0,
            entry_addenda_count=0,
            entry_hash="0" * 10,
            total_debit=0,
            total_credit=0,
            reserved=" " * 39,
            raw="",
        )

    nf = NachaFile(
        file_header=file_header,
        batches=batches,
        file_control=file_control,
        block_padding=block_padding,
        line_terminator=terminator,
    )
    nf._record_sequence = record_sequence
    nf._has_trailing_terminator = has_trailing
    return nf
