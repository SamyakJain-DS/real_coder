"""ODFI rule-set configuration and validation-issue data objects."""

from dataclasses import dataclass, field
from typing import List


@dataclass
class OdfiRuleSet:
    permitted_immediate_origins: List[str]
    permitted_immediate_destinations: List[str]
    permitted_company_ids: List[str]
    enforce_structural: bool = True
    enforce_control_fields: bool = True
    enforce_sec_addenda_content: bool = True


@dataclass
class ValidationIssue:
    rule: str
    message: str
    line_number: int
    record_type: str
