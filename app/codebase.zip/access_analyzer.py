import pandas as pd


def identify_access_reduction_patterns(
    claims: pd.DataFrame,
    supplier_bids: pd.DataFrame,
) -> pd.DataFrame:
    # -- Step 1: aggregate claims ---------------------------------------------
    claims_agg = (
        claims
        .groupby(["cba_id", "hcpcs_code", "claim_year"], as_index=False)
        .agg(
            total_claims=("claim_count", "sum"),
            mean_oop_cost_share=("oop_cost_share", "mean"),
        )
    )

    # -- Step 2: year-over-year change in total_claims ------------------------
    claims_yoy_rows = []
    for (cba_id, hcpcs_code), grp in claims_agg.groupby(["cba_id", "hcpcs_code"]):
        grp = grp.sort_values("claim_year").reset_index(drop=True)
        year_to_total = dict(zip(grp["claim_year"], grp["total_claims"]))
        year_to_oop   = dict(zip(grp["claim_year"], grp["mean_oop_cost_share"]))
        for year in grp["claim_year"]:
            prior_year = year - 1
            if prior_year not in year_to_total:
                continue  # no prior-year entry - exclude
            change = year_to_total[year] - year_to_total[prior_year]
            claims_yoy_rows.append({
                "cba_id":             cba_id,
                "hcpcs_code":         hcpcs_code,
                "claim_year":         year,
                "claims_change":      change,
                "mean_oop_cost_share": year_to_oop[year],
            })

    if not claims_yoy_rows:
        return pd.DataFrame(
            columns=["cba_id", "hcpcs_code", "year", "access_pattern", "mean_oop_cost_share"]
        )

    claims_yoy_df = pd.DataFrame(claims_yoy_rows)

    # -- Step 3: active supplier count per (cba_id, hcpcs_code, bid_year) ----
    active_bids = supplier_bids[supplier_bids["contract_status"] == "active"].copy()
    supplier_agg = (
        active_bids
        .groupby(["cba_id", "hcpcs_code", "bid_year"], as_index=False)
        .agg(active_supplier_count=("supplier_id", "nunique"))
    )

    # -- Step 4: year-over-year change in active_supplier_count --------------
    supplier_yoy_rows = []
    for (cba_id, hcpcs_code), grp in supplier_agg.groupby(["cba_id", "hcpcs_code"]):
        grp = grp.sort_values("bid_year").reset_index(drop=True)
        year_to_count = dict(zip(grp["bid_year"], grp["active_supplier_count"]))
        for year in grp["bid_year"]:
            prior_year = year - 1
            if prior_year not in year_to_count:
                continue  # no prior-year entry - exclude
            change = year_to_count[year] - year_to_count[prior_year]
            supplier_yoy_rows.append({
                "cba_id":          cba_id,
                "hcpcs_code":      hcpcs_code,
                "bid_year":        year,
                "supplier_change": change,
            })

    supplier_yoy_df = (
        pd.DataFrame(supplier_yoy_rows)
        if supplier_yoy_rows
        else pd.DataFrame(columns=["cba_id", "hcpcs_code", "bid_year", "supplier_change"])
    )

    # -- Step 5: left-join claims YoY with supplier YoY on year --------------
    # Rename bid_year to claim_year for the merge key.
    supplier_yoy_df = supplier_yoy_df.rename(columns={"bid_year": "claim_year"})

    merged = claims_yoy_df.merge(
        supplier_yoy_df,
        on=["cba_id", "hcpcs_code", "claim_year"],
        how="left",
    )
    # Missing supplier-side entries default to 0
    merged["supplier_change"] = merged["supplier_change"].fillna(0)

    # -- Step 6: flag rows where total_claims change is negative -------------
    access_reduced = merged[merged["claims_change"] < 0].copy()

    if access_reduced.empty:
        return pd.DataFrame(
            columns=["cba_id", "hcpcs_code", "year", "access_pattern", "mean_oop_cost_share"]
        )

    # -- Steps 6 & 7: classify each flagged row -------------------------------
    access_reduced["access_pattern"] = access_reduced["supplier_change"].apply(
        lambda x: "contract_attrition" if x < 0 else "utilization_shift"
    )

    access_reduced = access_reduced.rename(columns={"claim_year": "year"})

    return (
        access_reduced[["cba_id", "hcpcs_code", "year", "access_pattern", "mean_oop_cost_share"]]
        .reset_index(drop=True)
    )