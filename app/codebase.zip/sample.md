# Slide One: H1 Boundary

This slide starts because of the H1 heading above.
No --- separator needed.

# Slide Two: Also H1 Boundary

Each H1 heading automatically starts a new slide.
The previous slide ended the moment this heading was seen.

---

# Slide Three: Separator Then H1

This slide started with a --- separator, followed immediately by an H1.
That combination counts as ONE slide break, not two.

---

Slide Four: Separator Only

This slide has no H1 heading at all.
It started from a plain --- separator line.

NOTE: This is a hidden speaker note on slide four.

# Slide Five: Code Block Protection

The --- and # inside this code block must NOT trigger a new slide:

```go
---
# this is not a heading
fmt.Println("still slide five")
```

Still on slide five after the code block.

# Slide Six: Table

| Boundary Type | Trigger         |
|---------------|-----------------|
| Separator     | --- alone       |
| Heading       | # followed by space |

# Slide Seven: Image

![Sample image](data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjY2NjIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGRvbWluYW50LWJhc2VsaW5lPSJtaWRkbGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtc2l6ZT0iMjQiIGZpbGw9IiM2NjYiPlNhbXBsZSBJbWFnZTwvdGV4dD48L3N2Zz4=)

NOTE: Speaker notes are hidden with display:none in the style block.