import sqlite3


class ZanzibarStore:
    def __init__(self, db_path: str):
        """Initialize the store, opening (or creating) the SQLite database at `db_path` and ensuring the required tables exist."""
        self.db_path = db_path
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._create_tables()

    def _create_tables(self):
        """Create the `tuples` and `rules` tables if they do not already exist."""
        with self._conn:
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS tuples (
                    subject    TEXT NOT NULL,
                    relation   TEXT NOT NULL,
                    object_id  TEXT NOT NULL,
                    PRIMARY KEY (subject, relation, object_id)
                )
            """)
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS rules (
                    parent_relation  TEXT NOT NULL,
                    implied_relation TEXT NOT NULL,
                    PRIMARY KEY (parent_relation, implied_relation)
                )
            """)

    # ------------------------------------------------------------------
    # Tuple management
    # ------------------------------------------------------------------

    def add_tuple(self, subject: str, relation: str, object_id: str) -> None:
        """Insert the tuple `(subject, relation, object_id)` into the database. If the exact tuple already exists, returns without error or duplication."""
        with self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO tuples (subject, relation, object_id) VALUES (?, ?, ?)",
                (subject, relation, object_id),
            )

    def remove_tuple(self, subject: str, relation: str, object_id: str) -> None:
        """Delete the tuple `(subject, relation, object_id)` from the database. If no matching tuple exists, returns without error."""
        with self._conn:
            self._conn.execute(
                "DELETE FROM tuples WHERE subject = ? AND relation = ? AND object_id = ?",
                (subject, relation, object_id),
            )

    # ------------------------------------------------------------------
    # Rule management
    # ------------------------------------------------------------------

    def add_rule(self, parent_relation: str, implied_relation: str) -> None:
        """Store a rule stating that holding `parent_relation` on an object also implies holding `implied_relation` on the same object. If the rule already exists, returns without duplicating it."""
        with self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO rules (parent_relation, implied_relation) VALUES (?, ?)",
                (parent_relation, implied_relation),
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_group_members(self, group_ref: str) -> set:
        """
        Given a group reference of the form "group:name#member", return the set
        of all individual user strings (not group references) that are members of
        that group, resolved transitively. Handles cyclic group membership.
        """
        # group_ref looks like "group:name#member"
        # The group object_id is "group:name"
        visited_groups = set()
        individual_users = set()

        def resolve(ref: str):
            # ref is "group:name#member"
            if ref in visited_groups:
                return
            visited_groups.add(ref)

            # Extract the group object_id: everything before "#member"
            if "#member" not in ref:
                return
            group_object_id = ref[: ref.index("#member")]

            # Find all subjects holding "member" relation on this group object
            cur = self._conn.execute(
                "SELECT subject FROM tuples WHERE relation = ? AND object_id = ?",
                ("member", group_object_id),
            )
            for (subject,) in cur.fetchall():
                if subject.startswith("group:") and "#member" in subject:
                    # Nested group reference - recurse
                    resolve(subject)
                else:
                    individual_users.add(subject)

        resolve(group_ref)
        return individual_users

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check(self, user: str, permission: str, object_id: str) -> bool:
        """
        Returns True if `user` holds `permission` on `object_id` through any
        combination of direct tuples, rule-based transitive implication, or
        group membership resolution.
        """
        # Collect all relations that imply `permission` (i.e. all relations
        # that, if held, would transitively grant `permission`).
        # We need the reverse: which relations can reach `permission` via rules.
        # Build the full reachable-relation set for each relation and check if
        # `permission` is in it.  Equivalently, collect all relations R such
        # that `permission` is in _expand_relations(R).
        #
        # More efficiently: find all relations whose expansion includes `permission`.
        # We do this by walking rules in reverse from `permission`.

        # Gather all relations that transitively imply `permission`
        relations_that_imply = self._relations_implying(permission)

        # For each such relation, check if there's a tuple (subject, relation, object_id)
        # where subject resolves to `user`.
        for relation in relations_that_imply:
            cur = self._conn.execute(
                "SELECT subject FROM tuples WHERE relation = ? AND object_id = ?",
                (relation, object_id),
            )
            for (subject,) in cur.fetchall():
                if subject == user:
                    return True
                # Group reference
                if subject.startswith("group:") and "#member" in subject:
                    members = self._resolve_group_members(subject)
                    if user in members:
                        return True
        return False

    def _relations_implying(self, permission: str) -> set:
        """
        Return the set of all relations R such that holding R implies holding
        `permission` (including `permission` itself). This is the set of
        ancestors of `permission` in the rule DAG.
        Handles cycles.
        """
        # Traverse the rule graph in reverse: find all R where permission is
        # reachable from R.  We do this by building a reverse adjacency and BFS.
        # But since rules table may be large, let's just do it lazily with BFS
        # over the forward graph from every relation, or use reverse BFS.

        # Build reverse map: implied -> set of parents
        cur = self._conn.execute("SELECT parent_relation, implied_relation FROM rules")
        reverse: dict = {}
        for parent, implied in cur.fetchall():
            reverse.setdefault(implied, set()).add(parent)

        visited = set()
        stack = [permission]
        while stack:
            current = stack.pop()
            if current in visited:
                continue
            visited.add(current)
            for parent in reverse.get(current, []):
                if parent not in visited:
                    stack.append(parent)
        return visited

    def expand(self, permission: str, object_id: str) -> list:
        """
        Returns a list of all individual user strings that hold `permission` on
        `object_id`, resolved through rules and group membership. Each user
        appears at most once.
        """
        relations = self._relations_implying(permission)
        individual_users = set()

        for relation in relations:
            cur = self._conn.execute(
                "SELECT subject FROM tuples WHERE relation = ? AND object_id = ?",
                (relation, object_id),
            )
            for (subject,) in cur.fetchall():
                if subject.startswith("group:") and "#member" in subject:
                    members = self._resolve_group_members(subject)
                    individual_users.update(members)
                else:
                    individual_users.add(subject)

        return list(individual_users)