"""
Pipeline entry point for the housing code enforcement analytics pipeline.
Orchestrates dataset generation, analysis, and report generation.
"""
import argparse
import os
import sys


def main():
    """
    Run the full housing code enforcement analytics pipeline.
    Parses --data-dir and --output-dir from sys.argv.
    """
    parser = argparse.ArgumentParser(
        description="Housing Code Enforcement Analytics Pipeline"
    )
    parser.add_argument(
        "--data-dir",
        default="data",
        help="Directory containing or to write CSV data files (default: data)",
    )
    parser.add_argument(
        "--output-dir",
        default="output",
        help="Directory to write the output report (default: output)",
    )
    args = parser.parse_args()

    data_dir = args.data_dir
    output_dir = args.output_dir

    # Step 1: Generate dataset if CSVs are absent
    required_csvs = [
        "properties.csv", "inspections.csv", "violations.csv",
        "landlords.csv", "neighborhoods.csv",
    ]
    csvs_present = all(
        os.path.exists(os.path.join(data_dir, f)) for f in required_csvs
    )

    if not csvs_present:
        from scripts.generate_data import generate_dataset
        generate_dataset(data_dir, seed=42)

    # Step 2: Load data
    from src.data_loader import load_data
    data = load_data(data_dir)

    # Step 3: Classify landlords
    from src.landlord_analyzer import classify_landlord_compliance
    landlord_df = classify_landlord_compliance(data)

    # Step 4: Attribute neighborhood decline
    from src.neighborhood_analyzer import attribute_neighborhood_decline
    neighborhood_df = attribute_neighborhood_decline(data, landlord_df)

    # Step 5: Model enforcement effectiveness
    from src.enforcement_model import model_enforcement_effectiveness
    enforcement_results = model_enforcement_effectiveness(data)

    # Step 6: Generate report
    from src.report_generator import generate_report
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "enforcement_report.html")
    generate_report(landlord_df, neighborhood_df, enforcement_results, output_path)

    sys.exit(0)


if __name__ == "__main__":
    main()
