from __future__ import annotations

from collections import defaultdict

import numpy as np
import pandas as pd
from typing import Optional


def compute_journey_channel_credits(
    events: pd.DataFrame,
    model: str,
    half_life_hours: float = 168.0,
    num_permutations: int = 2000,
    random_seed: int = 0,
    train_events: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """Compute per-journey channel credit vectors for a given attribution model."""
    model = str(model)
    supported_models = {"first_touch", "last_touch", "linear", "time_decay", "markov", "shapley"}
    if model not in supported_models:
        raise ValueError(f"Unknown model {model!r}")

    events = events.copy()
    events["channel"] = events["channel"].astype(str).str.strip()
    events = events.sort_values(["journey_id", "touchpoint_index"], kind="mergesort").reset_index(drop=True)

    if train_events is not None:
        train_events = train_events.copy()
        train_events["channel"] = train_events["channel"].astype(str).str.strip()
        train_events = train_events.sort_values(
            ["journey_id", "touchpoint_index"], kind="mergesort"
        ).reset_index(drop=True)

    events_channels = sorted(pd.unique(events["channel"]).tolist())
    if model in {"markov", "shapley"} and train_events is not None:
        train_channels = sorted(pd.unique(train_events["channel"]).tolist())
        channels: list[str] = sorted(set(events_channels) | set(train_channels))
    else:
        channels = events_channels
    if not channels:
        raise ValueError("No channels observed in events")

    credits_rows = []

    if model == "markov":
        share_source = train_events if train_events is not None else events
        global_shares = _compute_markov_global_channel_shares(share_source)
        global_support = set(global_shares.index[global_shares.to_numpy(dtype=float) > 0.0].tolist())
    elif model == "shapley":
        share_source = train_events if train_events is not None else events
        global_shares = _compute_shapley_global_channel_shares(
            share_source, num_permutations=num_permutations, random_seed=random_seed
        )
        global_support = set(global_shares.index[global_shares.to_numpy(dtype=float) > 0.0].tolist())
    else:
        global_shares = None
        global_support = set()

    for journey_id, grp in events.groupby("journey_id", sort=False):
        journey_id_str = str(journey_id)
        converted = int(grp["converted"].iloc[0])
        grp = grp.sort_values("touchpoint_index", kind="mergesort").reset_index(drop=True)

        channel_credit: dict[str, float]
        if model == "first_touch":
            first_channel = str(grp["channel"].iloc[0])
            channel_credit = {first_channel: 1.0}
        elif model == "last_touch":
            last_channel = str(grp["channel"].iloc[-1])
            channel_credit = {last_channel: 1.0}
        elif model == "linear":
            n_touchpoints = int(len(grp))
            per_touch = 1.0 / float(n_touchpoints)
            channel_counts = grp["channel"].value_counts()
            channel_credit = {str(ch): float(cnt) * per_touch for ch, cnt in channel_counts.items()}
        elif model == "time_decay":
            if half_life_hours <= 0.0:
                raise ValueError("half_life_hours must be > 0.0")
            end_ts = grp["touchpoint_ts"].max()
            delta_hours = (end_ts - grp["touchpoint_ts"]).dt.total_seconds().to_numpy(dtype=float) / 3600.0
            log_raw = np.log(0.5) * (delta_hours / float(half_life_hours))
            log_raw = log_raw - float(np.max(log_raw))
            weights = np.exp(log_raw)
            weights_sum = float(np.sum(weights))
            if weights_sum <= 0.0 or not np.isfinite(weights_sum):
                raise ValueError("Time-decay weights are not finite")
            weights = weights / weights_sum
            weights_by_channel = defaultdict(float)
            for ch, w in zip(grp["channel"].tolist(), weights.tolist()):
                weights_by_channel[str(ch)] += float(w)
            channel_credit = dict(weights_by_channel)
        elif model in {"markov", "shapley"}:
            journey_channels = sorted(set(grp["channel"].tolist()))
            if not journey_channels:
                raise ValueError(f"Journey {journey_id_str!r} contains zero channels")

            supported = [ch for ch in journey_channels if ch in global_support]
            if not supported:
                per_ch = 1.0 / float(len(journey_channels))
                channel_credit = {str(ch): per_ch for ch in journey_channels}
            else:
                vals = np.array([float(global_shares.get(ch, 0.0)) for ch in journey_channels], dtype=float)
                vals_sum = float(vals.sum())
                if vals_sum <= 0.0 or not np.isfinite(vals_sum):
                    per_ch = 1.0 / float(len(journey_channels))
                    channel_credit = {str(ch): per_ch for ch in journey_channels}
                else:
                    vals = vals / vals_sum
                    channel_credit = {str(ch): float(v) for ch, v in zip(journey_channels, vals.tolist())}
        else:
            raise ValueError(f"Unsupported model {model!r}")

        row = {ch: 0.0 for ch in channels}
        for ch, credit in channel_credit.items():
            if ch in row:
                row[ch] = float(credit)
        credits_rows.append(row)
        row_sum = float(sum(row.values()))
        if not np.isfinite(row_sum) or row_sum <= 0.0:
            raise ValueError(f"Non-finite journey credit sum for journey_id={journey_id_str!r}")
        if abs(row_sum - 1.0) > 1e-9:
            for ch in row:
                row[ch] = float(row[ch]) / row_sum

        row["journey_id"] = journey_id_str
        row["converted"] = converted

    journey_credits = pd.DataFrame(credits_rows)
    journey_credits = journey_credits.loc[:, ["journey_id", "converted", *channels]]
    return journey_credits


def compute_aggregated_channel_shares(journey_credits: pd.DataFrame) -> pd.Series:
    """Aggregate journey-level credits across converted journeys into normalized channel shares."""
    if "converted" not in journey_credits.columns:
        raise ValueError("journey_credits must include converted column")
    channel_cols = [c for c in journey_credits.columns if c not in {"journey_id", "converted"}]
    converted_rows = journey_credits.loc[journey_credits["converted"] == 1, channel_cols]
    if converted_rows.shape[0] == 0:
        return pd.Series({ch: 0.0 for ch in channel_cols}, dtype=float)
    shares = converted_rows.mean(axis=0).astype(float)
    total = float(shares.sum())
    if total > 0.0:
        shares = shares / total
    return shares


def _compute_markov_global_channel_shares(events: pd.DataFrame) -> pd.Series:
    channels: list[str] = sorted(pd.unique(events["channel"]).tolist())
    if not channels:
        return pd.Series(dtype=float)

    start_state = "START"
    conv_state = "CONVERSION"
    null_state = "NULL"

    states = [start_state, *channels, conv_state, null_state]
    state_to_idx = {s: i for i, s in enumerate(states)}
    n = len(states)

    counts = np.zeros((n, n), dtype=float)

    for _, grp in events.groupby("journey_id", sort=False):
        grp = grp.sort_values("touchpoint_index", kind="mergesort")
        path = [
            start_state,
            *grp["channel"].tolist(),
            conv_state if int(grp["converted"].iloc[0]) == 1 else null_state,
        ]
        for src, dst in zip(path[:-1], path[1:]):
            counts[state_to_idx[src], state_to_idx[dst]] += 1.0

    P = np.zeros((n, n), dtype=float)
    for s, i in state_to_idx.items():
        if s in {conv_state, null_state}:
            P[i, i] = 1.0
            continue
        row_sum = float(counts[i].sum())
        if row_sum <= 0.0:
            P[i, state_to_idx[null_state]] = 1.0
        else:
            P[i, :] = counts[i, :] / row_sum

    p_base = _markov_absorption_probability(P, states, start_state=start_state, absorb_state=conv_state)

    removal_effects: dict[str, float] = {}
    for ch in channels:
        states_removed = [s for s in states if s != ch]
        keep_idx = [state_to_idx[s] for s in states_removed]
        P_removed = P[np.ix_(keep_idx, keep_idx)].copy()

        removed_state_to_idx = {s: i for i, s in enumerate(states_removed)}
        for s, i in removed_state_to_idx.items():
            if s in {conv_state, null_state}:
                P_removed[i, :] = 0.0
                P_removed[i, i] = 1.0
                continue

            row_sum = float(P_removed[i, :].sum())
            if row_sum <= 0.0:
                P_removed[i, :] = 0.0
                P_removed[i, removed_state_to_idx[null_state]] = 1.0
            else:
                P_removed[i, :] = P_removed[i, :] / row_sum

        p_removed = _markov_absorption_probability(
            P_removed, states_removed, start_state=start_state, absorb_state=conv_state
        )

        if p_base == 0.0:
            removal_effects[ch] = 0.0
        else:
            removal_effects[ch] = float(max(0.0, (p_base - p_removed) / p_base))

    effects = pd.Series(removal_effects, dtype=float).reindex(channels).fillna(0.0)
    total = float(effects.sum())
    if total == 0.0:
        return pd.Series({ch: 1.0 / float(len(channels)) for ch in channels}, dtype=float)
    return (effects / total).astype(float)


def _markov_absorption_probability(
    P: np.ndarray, states: list[str], *, start_state: str, absorb_state: str
) -> float:
    conv_state = absorb_state
    null_state = "NULL"
    transient_states = [s for s in states if s not in {conv_state, null_state}]
    absorbing_states = [conv_state, null_state]

    idx = {s: i for i, s in enumerate(states)}
    t_idx = [idx[s] for s in transient_states]
    a_idx = [idx[s] for s in absorbing_states]

    Q = P[np.ix_(t_idx, t_idx)]
    R = P[np.ix_(t_idx, a_idx)]

    I = np.eye(Q.shape[0], dtype=float)
    N = np.linalg.inv(I - Q)
    B = N @ R

    start_pos = transient_states.index(start_state)
    conv_pos = absorbing_states.index(conv_state)
    p = float(B[start_pos, conv_pos])
    if not np.isfinite(p):
        raise ValueError("Non-finite Markov absorption probability")
    return max(0.0, min(1.0, p))


def _compute_shapley_global_channel_shares(
    events: pd.DataFrame, *, num_permutations: int, random_seed: int
) -> pd.Series:
    channels: list[str] = sorted(pd.unique(events["channel"]).tolist())
    if not channels:
        return pd.Series(dtype=float)

    if num_permutations <= 0:
        raise ValueError("num_permutations must be > 0")

    channel_to_idx = {ch: i for i, ch in enumerate(channels)}
    converted_journey_sets: list[list[int]] = []
    for _, grp in events.groupby("journey_id", sort=False):
        if int(grp["converted"].iloc[0]) != 1:
            continue
        indices = sorted({channel_to_idx[str(ch)] for ch in grp["channel"].tolist()})
        if indices:
            converted_journey_sets.append(indices)

    rng = np.random.default_rng(int(random_seed))
    channels_arr = np.asarray(channels)
    shapley_counts = np.zeros(len(channels), dtype=float)
    for _ in range(int(num_permutations)):
        perm_channels = rng.permutation(channels_arr)
        perm_indices = np.fromiter(
            (channel_to_idx[str(ch)] for ch in perm_channels), dtype=int, count=len(channels)
        )
        pos = np.empty(len(channels), dtype=int)
        pos[perm_indices] = np.arange(len(channels))
        for idxs in converted_journey_sets:
            last = idxs[int(np.argmax(pos[np.array(idxs, dtype=int)]))]
            shapley_counts[last] += 1.0

    shapley_values = shapley_counts / float(num_permutations)
    total = float(np.sum(shapley_values))
    if total == 0.0:
        return pd.Series({ch: 1.0 / float(len(channels)) for ch in channels}, dtype=float)
    return pd.Series(shapley_values, index=channels, dtype=float) / total
