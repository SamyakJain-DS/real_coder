from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.model_selection import train_test_split

from .attribution import compute_aggregated_channel_shares, compute_journey_channel_credits
from .io import load_journey_events_csv


def run_attribution_comparison(
    input_csv_path: str,
    output_dir: str,
    random_seed: int = 0,
    holdout_fraction: float = 0.2,
    n_bootstrap: int = 200,
    half_life_hours: float = 168.0,
    num_permutations: int = 2000,
) -> dict:
    """Run the full local workflow end-to-end and write required outputs."""
    models = ["first_touch", "last_touch", "linear", "time_decay", "markov", "shapley"]
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    if not output_path.is_dir():
        raise ValueError("output_dir must be a directory")

    events = load_journey_events_csv(input_csv_path)

    if int((events["converted"] == 1).sum()) == 0:
        raise ValueError("Dataset contains 0 converted journeys")
    if int((events["converted"] == 0).sum()) == 0:
        raise ValueError("Dataset contains 0 converted == 0 journeys")

    journey_labels = events.groupby("journey_id", sort=False)["converted"].first().astype(int)
    journey_ids = journey_labels.index.to_numpy()
    y = journey_labels.to_numpy()

    train_ids, test_ids = train_test_split(
        journey_ids,
        test_size=float(holdout_fraction),
        random_state=int(random_seed),
        shuffle=True,
        stratify=y,
    )
    train_ids = [str(x) for x in train_ids.tolist()]
    test_ids = [str(x) for x in test_ids.tolist()]

    y_train_split = journey_labels.loc[train_ids]
    y_test_split = journey_labels.loc[test_ids]
    if int(y_train_split.nunique()) < 2:
        raise ValueError("Deterministic holdout train split contains a single class")
    if int(y_test_split.nunique()) < 2:
        raise ValueError("Deterministic holdout test split contains a single class")

    channels = sorted(pd.unique(events["channel"]).tolist())

    per_model_channel_shares: dict[str, pd.Series] = {}
    for model in models:
        journey_credits = compute_journey_channel_credits(
            events,
            model=model,
            half_life_hours=half_life_hours,
            num_permutations=num_permutations,
            random_seed=random_seed,
            train_events=None,
        )
        per_model_channel_shares[model] = compute_aggregated_channel_shares(journey_credits).reindex(channels).fillna(0.0)

    channel_shares = pd.DataFrame(per_model_channel_shares).T
    channel_shares.index.name = "model"
    channel_shares = channel_shares.loc[models, channels]

    boot_records: list[dict[str, object]] = []
    journey_groups = {str(jid): grp.copy() for jid, grp in events.groupby("journey_id", sort=False)}
    unique_journey_ids = list(journey_groups.keys())
    for b in range(int(n_bootstrap)):
        rng = np.random.default_rng(int(random_seed) + int(b))
        sampled = rng.choice(unique_journey_ids, size=len(unique_journey_ids), replace=True).tolist()

        boot_parts = []
        for draw_id, jid in enumerate(sampled):
            part = journey_groups[str(jid)].copy()
            part["journey_id"] = f"{jid}__b{b}__d{draw_id}"
            boot_parts.append(part)
        boot_events = pd.concat(boot_parts, ignore_index=True)

        for model in models:
            credits = compute_journey_channel_credits(
                boot_events,
                model=model,
                half_life_hours=half_life_hours,
                num_permutations=num_permutations,
                random_seed=random_seed,
                train_events=None,
            )
            shares = compute_aggregated_channel_shares(credits).reindex(channels).fillna(0.0)
            rec: dict[str, object] = {"model": model, "bootstrap_id": int(b)}
            rec.update({ch: float(shares.loc[ch]) for ch in channels})
            boot_records.append(rec)

    bootstrap_stability = pd.DataFrame(boot_records)
    bootstrap_stability = bootstrap_stability.loc[:, ["model", "bootstrap_id", *channels]]

    stability_scores: dict[str, float] = {}
    for model in models:
        sub = bootstrap_stability.loc[bootstrap_stability["model"] == model, channels]
        _mean_shares = sub.mean(axis=0).astype(float)
        stds = sub.std(axis=0, ddof=0).astype(float)
        stability_scores[model] = float(stds.mean())
    stability_scores_series = pd.Series(stability_scores, dtype=float).reindex(models)
    stability_scores_series.index.name = "model"

    holdout_metrics_rows = []
    for model in models:
        train_events = events.loc[events["journey_id"].isin(train_ids)].copy()
        if model in {"markov", "shapley"}:
            credits = compute_journey_channel_credits(
                events,
                model=model,
                half_life_hours=half_life_hours,
                num_permutations=num_permutations,
                random_seed=random_seed,
                train_events=train_events,
            )
        else:
            credits = compute_journey_channel_credits(
                events,
                model=model,
                half_life_hours=half_life_hours,
                num_permutations=num_permutations,
                random_seed=random_seed,
                train_events=None,
            )

        credit_indexed = credits.set_index("journey_id")
        feature_cols = [c for c in credits.columns if c not in {"journey_id", "converted"}]
        X_train = credit_indexed.loc[train_ids, feature_cols].to_numpy(dtype=float)
        y_train = credit_indexed.loc[train_ids, "converted"].to_numpy(dtype=int)
        X_test = credit_indexed.loc[test_ids, feature_cols].to_numpy(dtype=float)
        y_test = credit_indexed.loc[test_ids, "converted"].to_numpy(dtype=int)

        clf = LogisticRegression(
            penalty="l2",
            C=1.0,
            solver="liblinear",
            max_iter=1000,
            random_state=int(random_seed),
            fit_intercept=True,
        )
        clf.fit(X_train, y_train)
        prob = clf.predict_proba(X_test)[:, 1]

        roc_auc = float(roc_auc_score(y_test, prob))
        ll = float(log_loss(y_test, prob, labels=[0, 1]))
        holdout_metrics_rows.append({"model": model, "roc_auc": roc_auc, "log_loss": ll})

    holdout_metrics = pd.DataFrame(holdout_metrics_rows).set_index("model").reindex(models)

    recommended_model = _select_recommended_model(holdout_metrics, stability_scores_series)

    written_files: dict[str, str] = {}
    attribution_path = output_path / "attribution_channel_shares.csv"
    channel_shares.to_csv(attribution_path, index=True, index_label="model")
    written_files["attribution_channel_shares.csv"] = str(attribution_path)

    metrics_path = output_path / "holdout_metrics.csv"
    holdout_metrics.to_csv(metrics_path, index=True, index_label="model")
    written_files["holdout_metrics.csv"] = str(metrics_path)

    bootstrap_path = output_path / "bootstrap_stability.csv"
    bootstrap_stability.to_csv(bootstrap_path, index=False)
    written_files["bootstrap_stability.csv"] = str(bootstrap_path)

    rec_md_path = output_path / "recommendation.md"
    rec_md_path.write_text(
        _render_recommendation_md(holdout_metrics, stability_scores_series, recommended_model), encoding="utf-8"
    )
    written_files["recommendation.md"] = str(rec_md_path)

    png_paths = _write_plots(
        output_path=output_path,
        channel_shares=channel_shares,
        stability_scores=stability_scores_series,
        holdout_metrics=holdout_metrics,
    )
    written_files.update(png_paths)

    return {
        "channel_shares": channel_shares,
        "holdout_metrics": holdout_metrics,
        "stability_scores": stability_scores_series,
        "recommended_model": recommended_model,
        "written_files": written_files,
    }


def _select_recommended_model(holdout_metrics: pd.DataFrame, stability_scores: pd.Series) -> str:
    df = holdout_metrics.copy()
    df["stability_score"] = stability_scores.astype(float)
    df["_model_name"] = df.index.astype(str)
    df = df.sort_values(by=["roc_auc", "stability_score", "_model_name"], ascending=[False, True, True])
    return str(df.iloc[0]["_model_name"])


def _render_recommendation_md(
    holdout_metrics: pd.DataFrame, stability_scores: pd.Series, recommended_model: str
) -> str:
    return (
        "# Recommendation\n\n"
        "## Holdout metrics\n\n"
        f"{_df_to_markdown(holdout_metrics.reset_index())}\n\n"
        "## Bootstrap stability\n\n"
        f"{_df_to_markdown(stability_scores.rename('stability_score').reset_index())}\n\n"
        "## Selected model\n\n"
        f"Recommended model: **{recommended_model}**\n\n"
        "Selection rule: highest holdout ROC AUC; break ties by lowest stability score; "
        "break remaining ties by model name alphabetical order.\n"
    )


def _write_plots(
    *,
    output_path: Path,
    channel_shares: pd.DataFrame,
    stability_scores: pd.Series,
    holdout_metrics: pd.DataFrame,
) -> dict[str, str]:
    import os

    os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib")
    os.environ.setdefault("XDG_CACHE_HOME", "/tmp")

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    try:
        import seaborn as sns
    except Exception:
        sns = None

    written: dict[str, str] = {}

    long_shares = channel_shares.reset_index().melt(id_vars="model", var_name="channel", value_name="share")
    fig, ax = plt.subplots(figsize=(10, 5))
    if sns is not None:
        sns.barplot(data=long_shares, x="channel", y="share", hue="model", ax=ax)
    else:
        channels = long_shares["channel"].unique().tolist()
        models = long_shares["model"].unique().tolist()
        x = np.arange(len(channels), dtype=float)
        width = 0.8 / float(len(models))
        for i, m in enumerate(models):
            sub = long_shares.loc[long_shares["model"] == m].set_index("channel").reindex(channels)["share"]
            ax.bar(x + (i - (len(models) - 1) / 2) * width, sub.to_numpy(dtype=float), width=width, label=m)
        ax.set_xticks(x)
        ax.set_xticklabels(channels)
    ax.set_title("Channel Share by Model")
    ax.set_ylabel("Aggregated channel share")
    ax.set_xlabel("Channel")
    ax.legend(title="Model", bbox_to_anchor=(1.02, 1), loc="upper left", borderaxespad=0)
    fig.tight_layout()
    p = output_path / "channel_share_by_model.png"
    fig.savefig(p, dpi=150)
    plt.close(fig)
    written["channel_share_by_model.png"] = str(p)

    fig, ax = plt.subplots(figsize=(8, 4))
    if sns is not None:
        sns.heatmap(channel_shares, cmap="viridis", ax=ax)
    else:
        im = ax.imshow(channel_shares.to_numpy(dtype=float), aspect="auto", cmap="viridis")
        ax.set_xticks(np.arange(channel_shares.shape[1]))
        ax.set_xticklabels(channel_shares.columns.tolist(), rotation=45, ha="right")
        ax.set_yticks(np.arange(channel_shares.shape[0]))
        ax.set_yticklabels(channel_shares.index.tolist())
        fig.colorbar(im, ax=ax)
    ax.set_title("Channel Share Heatmap")
    fig.tight_layout()
    p = output_path / "channel_share_heatmap.png"
    fig.savefig(p, dpi=150)
    plt.close(fig)
    written["channel_share_heatmap.png"] = str(p)

    fig, ax = plt.subplots(figsize=(8, 4))
    if sns is not None:
        sns.barplot(x=stability_scores.index.astype(str), y=stability_scores.to_numpy(dtype=float), ax=ax)
    else:
        ax.bar(stability_scores.index.astype(str).tolist(), stability_scores.to_numpy(dtype=float))
    ax.set_title("Bootstrap Stability (Mean Std Dev Across Channels)")
    ax.set_ylabel("Stability score")
    ax.set_xlabel("Model")
    fig.tight_layout()
    p = output_path / "bootstrap_stability.png"
    fig.savefig(p, dpi=150)
    plt.close(fig)
    written["bootstrap_stability.png"] = str(p)

    fig, ax = plt.subplots(figsize=(8, 4))
    if sns is not None:
        sns.barplot(x=holdout_metrics.index.astype(str), y=holdout_metrics["roc_auc"].to_numpy(dtype=float), ax=ax)
    else:
        ax.bar(holdout_metrics.index.astype(str).tolist(), holdout_metrics["roc_auc"].to_numpy(dtype=float))
    ax.set_title("Holdout ROC AUC by Model")
    ax.set_ylabel("ROC AUC")
    ax.set_xlabel("Model")
    fig.tight_layout()
    p = output_path / "holdout_performance.png"
    fig.savefig(p, dpi=150)
    plt.close(fig)
    written["holdout_performance.png"] = str(p)

    return written


def _df_to_markdown(df: pd.DataFrame) -> str:
    cols = [str(c) for c in df.columns.tolist()]
    rows = df.astype(object).where(pd.notna(df), "").values.tolist()

    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    body_lines = []
    for r in rows:
        body_lines.append("| " + " | ".join(str(x) for x in r) + " |")
    return "\n".join([header, sep, *body_lines])
