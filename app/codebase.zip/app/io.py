from __future__ import annotations

import re

import numpy as np
import pandas as pd


_REQUIRED_COLUMNS: tuple[str, ...] = (
    "journey_id",
    "touchpoint_index",
    "channel",
    "touchpoint_ts",
    "converted",
)

_RFC3339_WITH_TZ_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$"
)


def load_journey_events_csv(csv_path: str) -> pd.DataFrame:
    """
    Load a local journey touchpoint events CSV, validate the required schema and constraints,
    parse touchpoint_ts into UTC datetimes, and return the validated event table sorted by
    (journey_id, touchpoint_index).
    """

    events = pd.read_csv(csv_path)

    missing_cols = [col for col in _REQUIRED_COLUMNS if col not in events.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")

    events = events.loc[:, list(_REQUIRED_COLUMNS)].copy()

    for col in _REQUIRED_COLUMNS:
        if events[col].isna().any():
            raise ValueError(f"Column {col!r} contains missing values")

    events["journey_id"] = events["journey_id"].astype(str)

    events["channel"] = events["channel"].astype(str).str.strip()
    if (events["channel"].str.len() < 1).any():
        raise ValueError("Channel values must have trimmed length at least 1")

    try:
        touchpoint_index = pd.to_numeric(events["touchpoint_index"], errors="raise")
    except Exception as exc:
        raise ValueError("touchpoint_index must be integer") from exc

    if not np.isfinite(touchpoint_index.to_numpy(dtype=float)).all():
        raise ValueError("touchpoint_index must be finite")
    if not np.equal(touchpoint_index.to_numpy(dtype=float), np.floor(touchpoint_index.to_numpy(dtype=float))).all():
        raise ValueError("touchpoint_index must be integer")
    events["touchpoint_index"] = touchpoint_index.astype(int)

    if (events["touchpoint_index"] < 0).any():
        raise ValueError("touchpoint_index must be 0-based (>= 0)")

    try:
        converted = pd.to_numeric(events["converted"], errors="raise")
    except Exception as exc:
        raise ValueError("converted must be integer") from exc

    if not np.isfinite(converted.to_numpy(dtype=float)).all():
        raise ValueError("converted must be finite")
    if not np.equal(converted.to_numpy(dtype=float), np.floor(converted.to_numpy(dtype=float))).all():
        raise ValueError("converted must be integer")
    events["converted"] = converted.astype(int)

    invalid_converted = ~events["converted"].isin([0, 1])
    if invalid_converted.any():
        bad_vals = sorted(set(events.loc[invalid_converted, "converted"].tolist()))
        raise ValueError(f"converted values must be 0 or 1; found {bad_vals}")

    touchpoint_ts_raw = events["touchpoint_ts"].astype(str).str.strip()
    invalid_ts_format = ~touchpoint_ts_raw.str.match(_RFC3339_WITH_TZ_RE)
    if invalid_ts_format.any():
        raise ValueError("touchpoint_ts values must be RFC3339 with explicit timezone offset")

    try:
        events["touchpoint_ts"] = pd.to_datetime(touchpoint_ts_raw, utc=True, errors="raise")
    except Exception as exc:
        raise ValueError("touchpoint_ts parsing failed") from exc

    converted_nunique = events.groupby("journey_id", sort=False)["converted"].nunique(dropna=False)
    inconsistent_converted = converted_nunique[converted_nunique != 1]
    if not inconsistent_converted.empty:
        bad_ids = inconsistent_converted.index.astype(str).tolist()
        raise ValueError(f"journey_id has inconsistent converted values: {bad_ids}")

    for journey_id, grp in events.groupby("journey_id", sort=False):
        idx = grp["touchpoint_index"].to_numpy(dtype=int)
        if idx.size < 1:
            raise ValueError(f"journey_id {journey_id!r} must contain at least 1 touchpoint row")
        if len(set(idx.tolist())) != idx.size:
            raise ValueError(f"journey_id {journey_id!r} has duplicate touchpoint_index values")
        expected = np.arange(idx.size, dtype=int)
        if not np.array_equal(np.sort(idx), expected):
            raise ValueError(
                f"journey_id {journey_id!r} touchpoint_index values must equal {{0, 1, ..., N-1}}"
            )

    events = events.sort_values(["journey_id", "touchpoint_index"], kind="mergesort").reset_index(drop=True)

    return events
