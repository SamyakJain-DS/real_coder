package slides

import (
	"bytes"
	"strings"

	"github.com/yuin/goldmark"
	"github.com/yuin/goldmark/extension"
)

// ParseSlides splits a Markdown document into individual slide content strings.
// Boundary triggers:
//   - A line containing exactly "---" starts a new slide (the separator is consumed).
//   - A line beginning with "# " starts a new slide and is included as its first line.
//
// Lines inside fenced code blocks (delimited by lines beginning with ```) are never
// treated as boundary triggers.
// A "# " line immediately following a "---" line does NOT create an additional break.
// Returned strings are trimmed; empty slides are excluded.
func ParseSlides(content string) []string {
	if content == "" {
		return []string{}
	}

	lines := strings.Split(content, "\n")

	var slides []string
	var current []string
	inFence := false
	prevWasSeparator := false

	for _, line := range lines {
		// Track fenced code blocks
		if strings.HasPrefix(line, "```") {
			inFence = !inFence
			current = append(current, line)
			prevWasSeparator = false
			continue
		}

		if !inFence {
			// Check for "---" separator
			if line == "---" {
				// Save current slide
				trimmed := strings.TrimSpace(strings.Join(current, "\n"))
				if trimmed != "" {
					slides = append(slides, trimmed)
				}
				current = []string{}
				prevWasSeparator = true
				continue
			}

			// Check for "# " heading trigger
			if strings.HasPrefix(line, "# ") {
				if prevWasSeparator {
					// The "# " immediately follows "---" — no extra break, just include line
					current = append(current, line)
					prevWasSeparator = false
					continue
				}
				// Start a new slide
				trimmed := strings.TrimSpace(strings.Join(current, "\n"))
				if trimmed != "" {
					slides = append(slides, trimmed)
				}
				current = []string{line}
				prevWasSeparator = false
				continue
			}
		}

		current = append(current, line)
		prevWasSeparator = false
	}

	// Don't forget the last slide
	trimmed := strings.TrimSpace(strings.Join(current, "\n"))
	if trimmed != "" {
		slides = append(slides, trimmed)
	}

	return slides
}

// ConvertToHTML accepts a slice of Markdown slide content strings and returns
// a complete valid HTML5 document string.
func ConvertToHTML(slides []string) string {
	md := goldmark.New(
		goldmark.WithExtensions(extension.Table),
	)

	var sectionsBuilder strings.Builder
	for _, slide := range slides {
		lines := strings.Split(slide, "\n")
		var noteContent string
		var bodyLines []string
		inFence := false

		for _, line := range lines {
			if strings.HasPrefix(line, "```") {
				inFence = !inFence
				bodyLines = append(bodyLines, line)
				continue
			}
			if !inFence && strings.HasPrefix(line, "NOTE: ") {
				// Extract speaker note (only first one matters per spec "at most one")
				if noteContent == "" {
					noteContent = strings.TrimPrefix(line, "NOTE: ")
				}
				// Remove from slide content — don't add to bodyLines
				continue
			}
			bodyLines = append(bodyLines, line)
		}

		markdownContent := strings.Join(bodyLines, "\n")

		var htmlBuf bytes.Buffer
		if err := md.Convert([]byte(markdownContent), &htmlBuf); err != nil {
			htmlBuf.WriteString("<p>Error rendering slide</p>")
		}

		sectionsBuilder.WriteString("<section>\n")
		sectionsBuilder.WriteString(htmlBuf.String())
		if noteContent != "" {
			sectionsBuilder.WriteString(`<div class="speaker-note">`)
			sectionsBuilder.WriteString(noteContent)
			sectionsBuilder.WriteString("</div>\n")
		}
		sectionsBuilder.WriteString("</section>\n")
	}

	const style = `
    html, body {
      margin: 0;
      padding: 0;
      overflow: hidden;
    }
    .speaker-note { display: none; }
    section {
      width: 100vw;
      height: 100vh;
      overflow: hidden;
      display: none;
    }
    section.active {
      display: block;
    }`

	const script = `
    document.addEventListener('DOMContentLoaded', function() {
      var sections = document.querySelectorAll('section');
      if (sections.length === 0) return;
      sections[0].classList.add('active');

      document.addEventListener('keydown', function(e) {
        var current = document.querySelector('section.active');
        if (!current) return;
        if (e.key === 'ArrowRight') {
          var next = current.nextElementSibling;
          while (next && next.tagName !== 'SECTION') {
            next = next.nextElementSibling;
          }
          if (next) {
            current.classList.remove('active');
            next.classList.add('active');
          }
        } else if (e.key === 'ArrowLeft') {
          var prev = current.previousElementSibling;
          while (prev && prev.tagName !== 'SECTION') {
            prev = prev.previousElementSibling;
          }
          if (prev) {
            current.classList.remove('active');
            prev.classList.add('active');
          }
        }
      });
    });`

	var doc strings.Builder
	doc.WriteString("<!DOCTYPE html>\n")
	doc.WriteString("<html>\n<head>\n")
	doc.WriteString("<meta charset=\"UTF-8\">\n")
	doc.WriteString("<style>")
	doc.WriteString(style)
	doc.WriteString("\n</style>\n")
	doc.WriteString("<script>")
	doc.WriteString(script)
	doc.WriteString("\n</script>\n")
	doc.WriteString("</head>\n<body>\n")
	doc.WriteString(sectionsBuilder.String())
	doc.WriteString("</body>\n</html>\n")

	return doc.String()
}