export function drawGridOverlay(canvas, realWidth, realHeight, cellSize) {
  const context = canvas.getContext("2d");
  context.clearRect(0, 0, canvas.width, canvas.height);
  if (canvas.width === 0 || canvas.height === 0) {
    return;
  }

  context.strokeStyle = "#00aaff";
  context.lineWidth = 1;
  context.globalAlpha = 0.8;

  const verticalLineCount = Math.floor(realWidth / cellSize);
  for (let i = 0; i <= verticalLineCount; i++) {
    const x = Math.round((i * cellSize * canvas.width) / realWidth);
    context.beginPath();
    context.moveTo(x, 0);
    context.lineTo(x, canvas.height);
    context.stroke();
  }

  const horizontalLineCount = Math.floor(realHeight / cellSize);
  for (let j = 0; j <= horizontalLineCount; j++) {
    const y = Math.round((j * cellSize * canvas.height) / realHeight);
    context.beginPath();
    context.moveTo(0, y);
    context.lineTo(canvas.width, y);
    context.stroke();
  }
}
