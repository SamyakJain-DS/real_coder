using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WeddingStudio.Api.Data;
using WeddingStudio.Api.Dtos;
using WeddingStudio.Api.Models;

namespace WeddingStudio.Api.Controllers;

[ApiController]
[Route("api/inventory")]
public class InventoryController : ControllerBase
{
    private readonly AppDbContext _db;

    public InventoryController(AppDbContext db)
    {
        _db = db;
    }

    // POST /api/inventory
    // Returns 201 with the created inventory item including its system-assigned id.
    [HttpPost]
    public async Task<IActionResult> AddInventoryItem([FromBody] CreateInventoryItemRequest request)
    {
        var item = new InventoryItem
        {
            Name = request.Name
        };

        _db.InventoryItems.Add(item);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetAllInventoryItems), null, new
        {
            id = item.Id,
            name = item.Name
        });
    }

    // GET /api/inventory
    // Returns 200 with the full list of inventory items.
    [HttpGet]
    public async Task<IActionResult> GetAllInventoryItems()
    {
        var items = await _db.InventoryItems.ToListAsync();

        var result = items.Select(i => new
        {
            id = i.Id,
            name = i.Name
        });

        return Ok(result);
    }
}
