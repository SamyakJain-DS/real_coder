using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WeddingStudio.Api.Data;
using WeddingStudio.Api.Dtos;
using WeddingStudio.Api.Models;

namespace WeddingStudio.Api.Controllers;

[ApiController]
[Route("api/sessions/{sessionId}/equipment-kits")]
public class EquipmentKitsController : ControllerBase
{
    private readonly AppDbContext _db;

    public EquipmentKitsController(AppDbContext db)
    {
        _db = db;
    }

    // POST /api/sessions/{sessionId}/equipment-kits
    // Returns 201 when sessionId exists and all inventoryItemIds exist.
    // Returns 404 when sessionId does not exist.
    // Returns 422 when sessionId exists but one or more inventoryItemIds do not exist.
    [HttpPost]
    public async Task<IActionResult> AddEquipmentKit(int sessionId, [FromBody] CreateEquipmentKitRequest request)
    {
        var sessionExists = await _db.Sessions.AnyAsync(s => s.Id == sessionId);
        if (!sessionExists)
        {
            return NotFound();
        }

        foreach (var inventoryItemId in request.InventoryItemIds)
        {
            var itemExists = await _db.InventoryItems.AnyAsync(i => i.Id == inventoryItemId);
            if (!itemExists)
            {
                return UnprocessableEntity();
            }
        }

        var kit = new EquipmentKit
        {
            SessionId = sessionId,
            KitName = request.KitName,
            InventoryItemIds = request.InventoryItemIds
        };

        _db.EquipmentKits.Add(kit);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetEquipmentKits), new { sessionId }, new
        {
            id = kit.Id,
            sessionId = kit.SessionId,
            kitName = kit.KitName,
            inventoryItemIds = kit.InventoryItemIds
        });
    }

    // GET /api/sessions/{sessionId}/equipment-kits
    // Returns 200 with array (empty when no kits) when sessionId exists, 404 when it does not.
    [HttpGet]
    public async Task<IActionResult> GetEquipmentKits(int sessionId)
    {
        var sessionExists = await _db.Sessions.AnyAsync(s => s.Id == sessionId);
        if (!sessionExists)
        {
            return NotFound();
        }

        var kits = await _db.EquipmentKits
            .Where(k => k.SessionId == sessionId)
            .ToListAsync();

        var result = kits.Select(k => new
        {
            id = k.Id,
            sessionId = k.SessionId,
            kitName = k.KitName,
            inventoryItemIds = k.InventoryItemIds
        });

        return Ok(result);
    }
}
