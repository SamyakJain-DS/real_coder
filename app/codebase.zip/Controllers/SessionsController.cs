using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WeddingStudio.Api.Data;
using WeddingStudio.Api.Dtos;
using WeddingStudio.Api.Models;

namespace WeddingStudio.Api.Controllers;

[ApiController]
[Route("api/bookings/{bookingId}/sessions")]
public class SessionsController : ControllerBase
{
    private readonly AppDbContext _db;

    public SessionsController(AppDbContext db)
    {
        _db = db;
    }

    // POST /api/bookings/{bookingId}/sessions
    // Returns 201 when bookingId exists, 404 when it does not.
    [HttpPost]
    public async Task<IActionResult> AddSession(int bookingId, [FromBody] CreateSessionRequest request)
    {
        var bookingExists = await _db.Bookings.AnyAsync(b => b.Id == bookingId);
        if (!bookingExists)
        {
            return NotFound();
        }

        var session = new Session
        {
            BookingId = bookingId,
            Location = request.Location,
            ScheduledStartTime = request.ScheduledStartTime,
            Label = request.Label
        };

        _db.Sessions.Add(session);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetSessions), new { bookingId }, new
        {
            id = session.Id,
            bookingId = session.BookingId,
            location = session.Location,
            scheduledStartTime = session.ScheduledStartTime,
            label = session.Label
        });
    }

    // GET /api/bookings/{bookingId}/sessions
    // Returns 200 with array (empty when no sessions) when bookingId exists, 404 when it does not.
    [HttpGet]
    public async Task<IActionResult> GetSessions(int bookingId)
    {
        var bookingExists = await _db.Bookings.AnyAsync(b => b.Id == bookingId);
        if (!bookingExists)
        {
            return NotFound();
        }

        var sessions = await _db.Sessions
            .Where(s => s.BookingId == bookingId)
            .ToListAsync();

        var result = sessions.Select(s => new
        {
            id = s.Id,
            bookingId = s.BookingId,
            location = s.Location,
            scheduledStartTime = s.ScheduledStartTime,
            label = s.Label
        });

        return Ok(result);
    }
}
