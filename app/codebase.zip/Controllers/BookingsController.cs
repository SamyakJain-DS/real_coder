using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WeddingStudio.Api.Data;
using WeddingStudio.Api.Dtos;
using WeddingStudio.Api.Models;

namespace WeddingStudio.Api.Controllers;

[ApiController]
[Route("api/bookings")]
public class BookingsController : ControllerBase
{
    private readonly AppDbContext _db;

    public BookingsController(AppDbContext db)
    {
        _db = db;
    }

    // POST /api/bookings
    // Returns 201 with the created booking including its system-assigned id.
    [HttpPost]
    public async Task<IActionResult> CreateBooking([FromBody] CreateBookingRequest request)
    {
        var booking = new Booking
        {
            Partner1Name = request.Partner1Name,
            Partner2Name = request.Partner2Name,
            VenueName = request.VenueName,
            WeddingDate = request.WeddingDate,
            PackageType = request.PackageType,
            Deliverables = request.Deliverables
        };

        _db.Bookings.Add(booking);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetBookingById), new { id = booking.Id }, new
        {
            id = booking.Id,
            partner1Name = booking.Partner1Name,
            partner2Name = booking.Partner2Name,
            venueName = booking.VenueName,
            weddingDate = booking.WeddingDate,
            packageType = booking.PackageType,
            deliverables = booking.Deliverables
        });
    }

    // GET /api/bookings/{id}
    // Returns 200 when found, 404 when not found.
    [HttpGet("{id}")]
    public async Task<IActionResult> GetBookingById(int id)
    {
        var booking = await _db.Bookings.FindAsync(id);

        if (booking is null)
        {
            return NotFound();
        }

        return Ok(new
        {
            id = booking.Id,
            partner1Name = booking.Partner1Name,
            partner2Name = booking.Partner2Name,
            venueName = booking.VenueName,
            weddingDate = booking.WeddingDate,
            packageType = booking.PackageType,
            deliverables = booking.Deliverables
        });
    }
}
