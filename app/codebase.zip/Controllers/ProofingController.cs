using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WeddingStudio.Api.Data;
using WeddingStudio.Api.Dtos;
using WeddingStudio.Api.Models;

namespace WeddingStudio.Api.Controllers;

[ApiController]
[Route("api/bookings/{bookingId}/proofing")]
public class ProofingController : ControllerBase
{
    private readonly AppDbContext _db;

    public ProofingController(AppDbContext db)
    {
        _db = db;
    }

    // POST /api/bookings/{bookingId}/proofing
    // Returns 201 when bookingId exists and no workflow exists yet.
    // Returns 404 when bookingId does not exist.
    // Returns 409 when a workflow already exists for this booking.
    [HttpPost]
    public async Task<IActionResult> CreateProofingWorkflow(
        int bookingId,
        [FromBody] CreateProofingWorkflowRequest request)
    {
        var bookingExists = await _db.Bookings.AnyAsync(b => b.Id == bookingId);
        if (!bookingExists)
        {
            return NotFound();
        }

        var alreadyExists = await _db.ProofingWorkflows.AnyAsync(w => w.BookingId == bookingId);
        if (alreadyExists)
        {
            return Conflict();
        }

        var workflow = new ProofingWorkflow
        {
            BookingId = bookingId,
            ContractedDeliveryDate = request.ContractedDeliveryDate
        };

        _db.ProofingWorkflows.Add(workflow);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetProofingWorkflow), new { bookingId }, new ProofingWorkflowResponse
        {
            Id = workflow.Id,
            BookingId = workflow.BookingId,
            ContractedDeliveryDate = workflow.ContractedDeliveryDate,
            Rounds = new List<ProofingRoundResponse>(),
            IsWithinDeliveryWindow = null
        });
    }

    // POST /api/bookings/{bookingId}/proofing/rounds
    // Returns 201 when a workflow exists for bookingId.
    // Returns 404 when no workflow exists for bookingId.
    // roundNumber is assigned as 1 for the first round, incrementing by 1 for each subsequent round.
    [HttpPost("rounds")]
    public async Task<IActionResult> AddProofingRound(
        int bookingId,
        [FromBody] AddProofingRoundRequest request)
    {
        var workflow = await _db.ProofingWorkflows
            .FirstOrDefaultAsync(w => w.BookingId == bookingId);

        if (workflow is null)
        {
            return NotFound();
        }

        var maxRoundNumber = await _db.ProofingRounds
            .Where(r => r.ProofingWorkflowId == workflow.Id)
            .Select(r => (int?)r.RoundNumber)
            .MaxAsync();

        var round = new ProofingRound
        {
            ProofingWorkflowId = workflow.Id,
            RoundNumber = (maxRoundNumber ?? 0) + 1,
            SubmittedDate = request.SubmittedDate,
            ImagesSelected = request.ImagesSelected,
            Notes = request.Notes
        };

        _db.ProofingRounds.Add(round);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetProofingWorkflow), new { bookingId }, new ProofingRoundResponse
        {
            Id = round.Id,
            RoundNumber = round.RoundNumber,
            SubmittedDate = round.SubmittedDate,
            ImagesSelected = round.ImagesSelected,
            Notes = round.Notes
        });
    }

    // GET /api/bookings/{bookingId}/proofing
    // Returns 200 with workflow + rounds ordered by roundNumber ascending when a workflow exists.
    // Returns 404 when no workflow exists for bookingId.
    // isWithinDeliveryWindow:
    //   null  — no rounds exist
    //   true  — latest round's submittedDate <= contractedDeliveryDate
    //   false — latest round's submittedDate >  contractedDeliveryDate
    [HttpGet]
    public async Task<IActionResult> GetProofingWorkflow(int bookingId)
    {
        var workflow = await _db.ProofingWorkflows
            .FirstOrDefaultAsync(w => w.BookingId == bookingId);

        if (workflow is null)
        {
            return NotFound();
        }

        var rounds = await _db.ProofingRounds
            .Where(r => r.ProofingWorkflowId == workflow.Id)
            .OrderBy(r => r.RoundNumber)
            .ToListAsync();

        bool? isWithinDeliveryWindow = null;
        if (rounds.Count > 0)
        {
            var latestRound = rounds[rounds.Count - 1]; // already ordered ascending, last = highest roundNumber
            var submittedDate = DateOnly.Parse(latestRound.SubmittedDate);
            var contractedDate = DateOnly.Parse(workflow.ContractedDeliveryDate);
            isWithinDeliveryWindow = submittedDate <= contractedDate;
        }

        var roundResponses = rounds.Select(r => new ProofingRoundResponse
        {
            Id = r.Id,
            RoundNumber = r.RoundNumber,
            SubmittedDate = r.SubmittedDate,
            ImagesSelected = r.ImagesSelected,
            Notes = r.Notes
        }).ToList();

        return Ok(new ProofingWorkflowResponse
        {
            Id = workflow.Id,
            BookingId = workflow.BookingId,
            ContractedDeliveryDate = workflow.ContractedDeliveryDate,
            Rounds = roundResponses,
            IsWithinDeliveryWindow = isWithinDeliveryWindow
        });
    }
}
