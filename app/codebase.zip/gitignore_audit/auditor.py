"""Discovery, classification, audit reporting, and fix-mode rewriting."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

from .matcher import compile_pattern
from .parser import COMMENT, BLANK, PATTERN, Line, parse_lines


@dataclass
class GitignoreFile:
    """All information accumulated about one discovered ``.gitignore`` file."""

    path: Path
    rel: str
    directory: Path
    depth: int
    lines: List[Line] = field(default_factory=list)
    classifications: Dict[int, str] = field(default_factory=dict)
    ancestor_refs: Dict[int, Tuple[str, int]] = field(default_factory=dict)


def discover(root: Path) -> Tuple[List[GitignoreFile], List[Tuple[Path, bool]]]:
    """Walk ``root`` and return the discovered ``.gitignore`` files plus the file tree.

    Directories named ``.git`` at any depth are excluded. ``os.walk`` is used in
    ``topdown`` mode and directory names are sorted in ascending lexicographic
    byte order before descending. The returned ``.gitignore`` list is sorted by
    path depth (shallowest first) then absolute path in ascending byte order.
    The file-tree list contains every regular file and directory beneath ``root``
    as ``(absolute_path, is_directory)``.
    """
    gitignores: List[Path] = []
    paths: List[Tuple[Path, bool]] = []

    for dirpath, dirnames, filenames in os.walk(root, topdown=True):
        dirnames.sort(key=lambda d: d.encode())
        dirnames[:] = [d for d in dirnames if d != ".git"]

        current = Path(dirpath)
        for name in dirnames:
            paths.append((current / name, True))
        for name in sorted(filenames, key=lambda f: f.encode()):
            full = current / name
            paths.append((full, False))
            if name == ".gitignore" and full.is_file():
                gitignores.append(full)

    files: List[GitignoreFile] = []
    for path in gitignores:
        relative = path.relative_to(root)
        files.append(
            GitignoreFile(
                path=path,
                rel=relative.as_posix(),
                directory=path.parent,
                depth=len(relative.parts),
            )
        )

    files.sort(key=lambda f: (f.depth, str(f.path).encode()))
    return files, paths


def candidates_under(directory: Path, paths: List[Tuple[Path, bool]]) -> List[Tuple[Path, str, bool]]:
    """Return ``(absolute_path, posix_relative_path, is_dir)`` for every path under ``directory``."""
    results: List[Tuple[Path, str, bool]] = []
    for absolute, is_dir in paths:
        try:
            relative = absolute.relative_to(directory)
        except ValueError:
            continue
        rel_posix = relative.as_posix()
        if rel_posix == ".":
            continue
        results.append((absolute, rel_posix, is_dir))
    return results


def match_set(line: Line, candidates: List[Tuple[Path, str, bool]]) -> FrozenSet[Path]:
    """Return the absolute paths under ``candidates`` that match ``line``'s pattern."""
    if line.kind != PATTERN:
        return frozenset()
    regex, dir_only = compile_pattern(line.pattern_text)
    if regex is None:
        return frozenset()
    matches: Set[Path] = set()
    for absolute, rel_posix, is_dir in candidates:
        if dir_only and not is_dir:
            continue
        if regex.match(rel_posix):
            matches.add(absolute)
    return frozenset(matches)


def _is_under(path: Path, directory: Path) -> bool:
    try:
        path.relative_to(directory)
        return True
    except ValueError:
        return False


def compute_excluded(
    target: GitignoreFile,
    ancestors: List[GitignoreFile],
    dir_candidates: Dict[Path, List[Tuple[Path, str, bool]]],
) -> Set[Path]:
    """Compute ``Excluded(G)`` for ``target`` by replaying every strict ancestor file.

    Ancestors are processed in ascending depth (the order of ``ancestors``).
    Within each ancestor, pattern lines are processed in ascending source order.
    Non-negated patterns add their match set, restricted to paths under
    ``target.directory``, to the running set; negated patterns remove it.
    """
    excluded: Set[Path] = set()
    for ancestor in ancestors:
        candidates = dir_candidates[ancestor.directory]
        for line in ancestor.lines:
            if line.kind != PATTERN:
                continue
            paths = match_set(line, candidates)
            constrained = {p for p in paths if _is_under(p, target.directory)}
            if line.negated:
                excluded -= constrained
            else:
                excluded |= constrained
    return excluded


def find_ancestor_reference(
    line_match_set: FrozenSet[Path],
    target: GitignoreFile,
    ancestors: List[GitignoreFile],
    dir_candidates: Dict[Path, List[Tuple[Path, str, bool]]],
) -> Optional[Tuple[str, int]]:
    """Return ``(ancestor_relative_path, ancestor_line_number)`` for a shadowed/conflict line.

    The candidate set is every non-negated pattern line in any ancestor of
    ``target`` whose match set, restricted to paths under ``target.directory``,
    intersects ``line_match_set``. The selected candidate is the one with the
    greatest owning-file depth, with ties broken by the greatest 1-based source
    line number inside that ancestor file.
    """
    best: Optional[Tuple[int, int, str]] = None
    for ancestor in ancestors:
        candidates = dir_candidates[ancestor.directory]
        for line in ancestor.lines:
            if line.kind != PATTERN or line.negated:
                continue
            paths = match_set(line, candidates)
            constrained = {p for p in paths if _is_under(p, target.directory)}
            if not (constrained & line_match_set):
                continue
            key = (ancestor.depth, line.line_number)
            if best is None or key > (best[0], best[1]):
                best = (ancestor.depth, line.line_number, ancestor.rel)

    if best is None:
        return None
    return best[2], best[1]


def classify(
    target: GitignoreFile,
    ancestors: List[GitignoreFile],
    dir_candidates: Dict[Path, List[Tuple[Path, str, bool]]],
) -> None:
    """Classify every pattern line of ``target`` and populate its ancestor references."""
    excluded = compute_excluded(target, ancestors, dir_candidates)
    candidates = dir_candidates[target.directory]

    for line in target.lines:
        if line.kind != PATTERN:
            continue
        paths = match_set(line, candidates)

        if not paths:
            target.classifications[line.line_number] = "dead"
            continue
        if line.negated and (paths & excluded):
            target.classifications[line.line_number] = "conflict"
            ref = find_ancestor_reference(paths, target, ancestors, dir_candidates)
            if ref is not None:
                target.ancestor_refs[line.line_number] = ref
            continue
        if (not line.negated) and paths.issubset(excluded):
            target.classifications[line.line_number] = "shadowed"
            ref = find_ancestor_reference(paths, target, ancestors, dir_candidates)
            if ref is not None:
                target.ancestor_refs[line.line_number] = ref
            continue
        target.classifications[line.line_number] = "active"


def render_report(files: List[GitignoreFile]) -> Tuple[str, int, int, int]:
    """Render the audit report. Returns ``(text, total_shadowed, total_dead, total_conflict)``."""
    pieces: List[str] = []
    total_s = total_d = total_c = 0

    for gi in files:
        shadowed: List[Line] = []
        dead: List[Line] = []
        conflict: List[Line] = []
        for line in gi.lines:
            cls = gi.classifications.get(line.line_number)
            if cls == "shadowed":
                shadowed.append(line)
            elif cls == "dead":
                dead.append(line)
            elif cls == "conflict":
                conflict.append(line)

        s, d, c = len(shadowed), len(dead), len(conflict)
        total_s += s
        total_d += d
        total_c += c

        if s == 0 and d == 0 and c == 0:
            continue

        block = [f"=== {gi.rel} ==="]
        if s:
            block.append(f"shadowed: {s}")
            for line in shadowed:
                ref_path, ref_line = gi.ancestor_refs[line.line_number]
                block.append(
                    f"  L{line.line_number}: {line.raw} -> covered by {ref_path}:L{ref_line}"
                )
        if d:
            block.append(f"dead: {d}")
            for line in dead:
                block.append(f"  L{line.line_number}: {line.raw}")
        if c:
            block.append(f"conflict: {c}")
            for line in conflict:
                ref_path, ref_line = gi.ancestor_refs[line.line_number]
                block.append(
                    f"  L{line.line_number}: {line.raw} -> contradicts {ref_path}:L{ref_line}"
                )

        pieces.append("\n".join(block) + "\n")

    pieces.append(f"total: shadowed={total_s} dead={total_d} conflict={total_c}\n")
    return "".join(pieces), total_s, total_d, total_c


def rewrite_file(gi: GitignoreFile) -> None:
    """Rewrite ``gi.path`` in place per the fix-mode rules of the specification."""
    comments: List[str] = []
    nonneg_patterns: List[Line] = []
    neg_patterns: List[Line] = []

    for line in gi.lines:
        if line.kind == COMMENT:
            comments.append(line.raw)
            continue
        if line.kind == BLANK:
            continue
        cls = gi.classifications.get(line.line_number)
        if cls in ("shadowed", "dead"):
            continue
        if cls in ("active", "conflict"):
            if line.negated:
                neg_patterns.append(line)
            else:
                nonneg_patterns.append(line)

    nonneg_patterns.sort(key=lambda line: line.body.encode())
    neg_patterns.sort(key=lambda line: line.body.encode())

    sections: List[List[str]] = []
    if comments:
        sections.append(comments)
    if nonneg_patterns:
        sections.append([line.raw for line in nonneg_patterns])
    if neg_patterns:
        sections.append([line.raw for line in neg_patterns])

    if not sections:
        gi.path.write_bytes(b"")
        return

    output_parts: List[str] = []
    for index, section in enumerate(sections):
        if index > 0:
            output_parts.append("\n")
        output_parts.append("\n".join(section) + "\n")

    gi.path.write_text("".join(output_parts), encoding="utf-8")


def audit(
    root: Path,
) -> Tuple[List[GitignoreFile], Dict[Path, List[Tuple[Path, str, bool]]], str, int, int, int]:
    """Run the full discover/parse/classify/render pipeline on ``root``."""
    files, paths = discover(root)

    for gi in files:
        with open(gi.path, encoding="utf-8", errors="strict", newline="") as fh:
            text = fh.read()
        gi.lines = parse_lines(text)

    dir_candidates: Dict[Path, List[Tuple[Path, str, bool]]] = {}
    for gi in files:
        if gi.directory not in dir_candidates:
            dir_candidates[gi.directory] = candidates_under(gi.directory, paths)

    for index, gi in enumerate(files):
        ancestors = [a for a in files[:index] if a.directory != gi.directory and _is_under(gi.directory, a.directory)]
        classify(gi, ancestors, dir_candidates)

    report, total_s, total_d, total_c = render_report(files)
    return files, dir_candidates, report, total_s, total_d, total_c
