"""Command-line entry point: ``python -m gitignore_audit <ROOT> [--fix]``."""

import sys
from pathlib import Path
from typing import List, Optional, Tuple

from .auditor import audit, rewrite_file


def _parse_argv(argv: List[str]) -> Tuple[Optional[str], bool, bool]:
    """Extract the positional ``ROOT`` argument and the ``--fix`` flag from ``argv``.

    Returns ``(root, fix, valid)`` where ``root`` is ``None`` when absent and
    ``valid`` is ``False`` when any extra positional argument or unrecognised
    flag is encountered.
    """
    fix = False
    root: Optional[str] = None
    valid = True
    for arg in argv:
        if arg == "--fix":
            fix = True
        elif not arg.startswith("-"):
            if root is None:
                root = arg
            else:
                valid = False  # extra positional argument
        else:
            valid = False  # unrecognised flag
    return root, fix, valid


def main(argv: List[str]) -> int:
    """Single entry point invoked by ``python -m gitignore_audit``.

    Parses ``argv`` (program name excluded), performs discovery, parsing,
    inherited-exclusion computation, and classification, prints the audit
    report on stdout encoded as UTF-8, optionally rewrites every discovered
    ``.gitignore`` when ``--fix`` is supplied, and returns the integer exit
    code defined by the specification (``0``, ``1``, or ``2``).
    """
    root_arg, fix, args_valid = _parse_argv(argv)

    if root_arg is None:
        sys.stderr.write("error: ROOT argument required\n")
        return 2

    if not args_valid:
        sys.stderr.write("error: unrecognized argument\n")
        return 2

    resolved = Path(root_arg).resolve(strict=False)
    if not resolved.is_dir():
        sys.stderr.write(f"error: ROOT is not a directory: {root_arg}\n")
        return 2

    files, _, report, total_s, total_d, total_c = audit(resolved)

    sys.stdout.write(report)

    if fix:
        for gi in files:
            rewrite_file(gi)

    return 1 if (total_s + total_d + total_c) > 0 else 0


if __name__ == "__main__":
    import io as _io
    sys.stdout = _io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    sys.exit(main(sys.argv[1:]))
