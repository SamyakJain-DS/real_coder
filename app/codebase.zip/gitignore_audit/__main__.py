"""Command-line entry point: ``python -m gitignore_audit <ROOT> [--fix]``."""

import sys
from pathlib import Path
from typing import List, Optional

from .auditor import audit, rewrite_file


def main(argv: List[str]) -> int:
    """Single entry point invoked by ``python -m gitignore_audit``.

    Parses ``argv`` (program name excluded), performs discovery, parsing,
    inherited-exclusion computation, and classification, prints the audit
    report on stdout encoded as UTF-8, optionally rewrites every discovered
    ``.gitignore`` when ``--fix`` is supplied, and returns the integer exit
    code defined by the specification (``0``, ``1``, or ``2``).
    """
    fix = False
    root_arg: Optional[str] = None
    for arg in argv:
        if arg == "--fix":
            fix = True
        elif not arg.startswith("-") and root_arg is None:
            root_arg = arg

    resolved = Path(root_arg if root_arg is not None else "").resolve(strict=False)
    if not resolved.is_dir():
        sys.stderr.write(f"error: ROOT is not a directory: {resolved}\n")
        return 2

    files, _, report, total_s, total_d, total_c = audit(resolved)

    sys.stdout.write(report)

    if fix:
        for gi in files:
            rewrite_file(gi)

    return 1 if (total_s + total_d + total_c) > 0 else 0


if __name__ == "__main__":
    import io as _io
    sys.stdout = _io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    sys.exit(main(sys.argv[1:]))