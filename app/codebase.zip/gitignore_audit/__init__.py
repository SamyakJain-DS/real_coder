"""gitignore_audit — a .gitignore Auditor CLI."""
