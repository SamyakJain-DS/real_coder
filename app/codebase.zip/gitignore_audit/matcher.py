"""Compile gitignore-style glob patterns into anchored regular expressions.

The compiled regex matches POSIX-style relative paths (``/`` separator) anchored
to the directory that owns the originating ``.gitignore`` file.
"""

import re
from typing import Optional, Tuple


def compile_pattern(pattern_text: str) -> Tuple[Optional[re.Pattern], bool]:
    """Compile ``pattern_text`` into ``(regex, dir_only)``.

    ``pattern_text`` is the body of a pattern with any leading ``!`` already removed.
    The returned ``regex`` matches a POSIX-style relative path string. ``dir_only``
    is ``True`` when the pattern ends with ``/`` and therefore matches only
    directories. ``regex`` is ``None`` when ``pattern_text`` reduces to an empty
    body (e.g. a lone ``/``); such patterns match nothing.
    """
    dir_only = pattern_text.endswith("/")
    body = pattern_text[:-1] if dir_only else pattern_text

    if not body:
        return None, dir_only

    if body.startswith("/"):
        anchored = True
        body = body[1:]
    elif body.startswith("**/"):
        anchored = False
    elif "/" in body:
        anchored = True
    else:
        anchored = False

    if not body:
        return None, dir_only

    leading_double_star = body.startswith("**/")
    if leading_double_star:
        body = body[3:]

    trailing_double_star = body.endswith("/**")
    if trailing_double_star:
        body = body[:-3]
    elif body == "**" and anchored:
        # Pattern was "/**": leading "/" already stripped, leaving "**".
        # Treat as trailing /** with empty directory prefix → matches everything inside root.
        trailing_double_star = True
        body = ""

    body_regex = _glob_body_to_regex(body)

    if leading_double_star or not anchored:
        prefix = "(?:[^/]+/)*"
    else:
        prefix = ""

    if trailing_double_star:
        suffix = "/.+" if body else ".*"
    else:
        suffix = ""

    return re.compile("^" + prefix + body_regex + suffix + "$"), dir_only


def _glob_body_to_regex(body: str) -> str:
    """Translate the literal portion of a glob body into a regex fragment."""
    parts = []
    i = 0
    n = len(body)
    while i < n:
        c = body[i]
        if c == "\\":
            if i + 1 < n:
                parts.append(re.escape(body[i + 1]))
                i += 2
            else:
                parts.append(re.escape(c))
                i += 1
        elif c == "*":
            if i + 1 < n and body[i + 1] == "*":
                preceded_by_slash = bool(parts) and parts[-1] == "/"
                followed_by_slash = i + 2 < n and body[i + 2] == "/"
                if preceded_by_slash and followed_by_slash:
                    # /**/  between two path segments: zero or more intermediate dirs
                    # replace the already-appended "/" with the optional-dir-group
                    parts[-1] = "(?:/[^/]+)*/"
                    i += 3  # consume ** and the following /
                else:
                    # ** not between slashes: no special meaning per spec, treat as *
                    parts.append("[^/]*")
                    i += 2
            else:
                parts.append("[^/]*")
                i += 1
        elif c == "?":
            parts.append("[^/]")
            i += 1
        elif c == "[":
            close = _find_class_close(body, i)
            if close is None:
                parts.append(re.escape(c))
                i += 1
            else:
                content = body[i + 1 : close]
                if content.startswith("!"):
                    content = "^" + content[1:]
                parts.append("[" + content + "]")
                i = close + 1
        else:
            parts.append(re.escape(c))
            i += 1
    return "".join(parts)


def _find_class_close(body: str, start: int) -> Optional[int]:
    """Locate the index of the ``]`` that closes a character class opened at ``start``."""
    j = start + 1
    n = len(body)
    if j < n and body[j] == "!":
        j += 1
    if j < n and body[j] == "]":
        j += 1
    while j < n and body[j] != "]":
        if body[j] == "\\" and j + 1 < n:
            j += 2
        else:
            j += 1
    return j if j < n else None
