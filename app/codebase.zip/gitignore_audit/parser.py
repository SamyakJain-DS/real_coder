"""Line classification and pattern body parsing for .gitignore files."""

from dataclasses import dataclass
from typing import List, Optional


BLANK = "blank"
COMMENT = "comment"
PATTERN = "pattern"


@dataclass
class Line:
    """A classified line from a .gitignore file."""

    kind: str
    line_number: int
    raw: str = ""
    body: str = ""
    negated: bool = False
    dir_only: bool = False
    pattern_text: str = ""


def _strip_trailing_whitespace(raw: str) -> str:
    """Return ``raw`` with trailing whitespace removed unless escaped by a backslash."""
    end = len(raw)
    while end > 0 and raw[end - 1] in " \t":
        if end >= 2 and raw[end - 2] == "\\":
            break
        end -= 1
    return raw[:end]


def parse_lines(text: str) -> List[Line]:
    """Parse the UTF-8 text of a .gitignore file into classified ``Line`` records.

    The text is split on ``\\n`` and each segment is classified following the rules
    from the specification: a single trailing ``\\r`` is stripped, an empty segment
    is ``blank``, a segment whose first non-whitespace character is ``#`` is
    ``comment``, and any other segment is ``pattern``.
    """
    records: List[Line] = []
    for index, raw_line in enumerate(text.split("\n"), start=1):
        if raw_line.endswith("\r"):
            raw_line = raw_line[:-1]

        if raw_line == "":
            records.append(Line(kind=BLANK, line_number=index))
            continue

        if raw_line.lstrip().startswith("#"):
            records.append(Line(kind=COMMENT, line_number=index, raw=raw_line))
            continue

        body = _strip_trailing_whitespace(raw_line)
        negated = body.startswith("!")
        dir_only = body.endswith("/")
        pattern_text = body[1:] if negated else body

        records.append(
            Line(
                kind=PATTERN,
                line_number=index,
                raw=raw_line,
                body=body,
                negated=negated,
                dir_only=dir_only,
                pattern_text=pattern_text,
            )
        )

    return records
