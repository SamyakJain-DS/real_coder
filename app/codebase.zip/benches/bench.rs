//! Criterion microbenchmark harness comparing `BLinkTree<u64, u64>` to the
//! `RwLockBTreeMap<u64, u64>` reference baseline on three workloads:
//! `insert_only`, `read_heavy`, and `mixed_concurrent`.
//!
//! The keyset is loaded from `data/keys.txt` resolved through
//! `CARGO_MANIFEST_DIR` so the binary runs fully offline.

use blink_tree::{BLinkTree, RwLockBTreeMap};
use criterion::{criterion_group, criterion_main, Criterion};
use std::fs;
use std::path::PathBuf;
use std::sync::Arc;
use std::thread;

fn load_keys() -> Vec<u64> {
    let manifest = std::env::var("CARGO_MANIFEST_DIR")
        .expect("CARGO_MANIFEST_DIR must be set by cargo");
    let path: PathBuf = PathBuf::from(manifest).join("data").join("keys.txt");
    let text = fs::read_to_string(&path)
        .unwrap_or_else(|e| panic!("failed to read {}: {}", path.display(), e));
    text.lines()
        .map(|l| l.trim())
        .filter(|l| !l.is_empty())
        .map(|l| l.parse::<u64>().expect("each line must parse as u64"))
        .collect()
}

fn run_insert_only_blink(keys: &[u64]) {
    let m = BLinkTree::<u64, u64>::new();
    for &k in keys {
        m.insert(k, k);
    }
}

fn run_insert_only_rwlock(keys: &[u64]) {
    let m = RwLockBTreeMap::<u64, u64>::new();
    for &k in keys {
        m.insert(k, k);
    }
}

fn run_read_heavy_blink(map: &BLinkTree<u64, u64>, keys: &[u64]) {
    let n = keys.len();
    for op in 0..95usize {
        let k = keys[op % n];
        let _ = map.get(&k);
    }
    for op in 95..100usize {
        let k = keys[op % n];
        map.insert(k, k);
    }
}

fn run_read_heavy_rwlock(map: &RwLockBTreeMap<u64, u64>, keys: &[u64]) {
    let n = keys.len();
    for op in 0..95usize {
        let k = keys[op % n];
        let _ = map.get(&k);
    }
    for op in 95..100usize {
        let k = keys[op % n];
        map.insert(k, k);
    }
}

fn run_mixed_concurrent_blink(keys: &[u64]) {
    let m = Arc::new(BLinkTree::<u64, u64>::new());
    let mut handles = Vec::new();
    for tid in 0..4usize {
        let m = Arc::clone(&m);
        let keys = keys.to_vec();
        handles.push(thread::spawn(move || {
            let n = keys.len();
            for op in 0..50usize {
                let idx = (tid * 100 + op) % n;
                let _ = m.get(&keys[idx]);
            }
            for op in 50..80usize {
                let idx = (tid * 100 + op) % n;
                let k = keys[idx];
                m.insert(k, k);
            }
            for op in 80..100usize {
                let idx = (tid * 100 + op) % n;
                let _ = m.remove(&keys[idx]);
            }
        }));
    }
    for h in handles {
        h.join().unwrap();
    }
}

fn run_mixed_concurrent_rwlock(keys: &[u64]) {
    let m = Arc::new(RwLockBTreeMap::<u64, u64>::new());
    let mut handles = Vec::new();
    for tid in 0..4usize {
        let m = Arc::clone(&m);
        let keys = keys.to_vec();
        handles.push(thread::spawn(move || {
            let n = keys.len();
            for op in 0..50usize {
                let idx = (tid * 100 + op) % n;
                let _ = m.get(&keys[idx]);
            }
            for op in 50..80usize {
                let idx = (tid * 100 + op) % n;
                let k = keys[idx];
                m.insert(k, k);
            }
            for op in 80..100usize {
                let idx = (tid * 100 + op) % n;
                let _ = m.remove(&keys[idx]);
            }
        }));
    }
    for h in handles {
        h.join().unwrap();
    }
}

fn bench_concurrent_map(c: &mut Criterion) {
    let keys: Vec<u64> = load_keys();
    let mut group = c.benchmark_group("concurrent_map");

    // insert_only: insert successive keys into a freshly constructed map.
    {
        let keys_local = keys.clone();
        group.bench_function("insert_only/blink", |b| {
            b.iter(|| run_insert_only_blink(&keys_local));
        });
    }
    {
        let keys_local = keys.clone();
        group.bench_function("insert_only/rwlock_btreemap", |b| {
            b.iter(|| run_insert_only_rwlock(&keys_local));
        });
    }

    // read_heavy: pre-populate, then 95 gets followed by 5 inserts per iter.
    {
        let keys_local = keys.clone();
        let map = BLinkTree::<u64, u64>::new();
        for &k in &keys_local {
            map.insert(k, k);
        }
        group.bench_function("read_heavy/blink", |b| {
            b.iter(|| run_read_heavy_blink(&map, &keys_local));
        });
    }
    {
        let keys_local = keys.clone();
        let map = RwLockBTreeMap::<u64, u64>::new();
        for &k in &keys_local {
            map.insert(k, k);
        }
        group.bench_function("read_heavy/rwlock_btreemap", |b| {
            b.iter(|| run_read_heavy_rwlock(&map, &keys_local));
        });
    }

    // mixed_concurrent: 4 threads, 50 gets, 30 inserts, 20 removes each.
    {
        let keys_local = keys.clone();
        group.bench_function("mixed_concurrent/blink", |b| {
            b.iter(|| run_mixed_concurrent_blink(&keys_local));
        });
    }
    {
        let keys_local = keys.clone();
        group.bench_function("mixed_concurrent/rwlock_btreemap", |b| {
            b.iter(|| run_mixed_concurrent_rwlock(&keys_local));
        });
    }

    group.finish();
}

criterion_group!(benches, bench_concurrent_map);
criterion_main!(benches);
