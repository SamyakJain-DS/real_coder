module go_cli_framework

go 1.21
