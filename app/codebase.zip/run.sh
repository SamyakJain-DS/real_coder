#!/bin/bash
### COMMON SETUP; DO NOT MODIFY ###
set -e

# --- CONFIGURE THIS SECTION ---
# Replace this with your command to run all tests
run_all_tests() {
  echo "Running all tests..."
  if [ -d /eval_assets/tests ]; then
    # Running inside validation container: tests in /eval_assets, code in /app.
    # Symlink /eval_assets/data -> /app/data so that:
    #   - _DEFAULT_CSV_PATH (/eval_assets/data/transactions.csv) resolves correctly
    #   - run_pipeline() default "data/transactions.csv" (relative to CWD) resolves correctly
    ln -sf /app/data /eval_assets/data 2>/dev/null || true
    cd /eval_assets
    PYTHONPATH=/app:${PYTHONPATH:-} python -m pytest tests/ -v --tb=short --no-header -W ignore::RuntimeWarning 2>&1
  elif [ -d /app/tests ]; then
    # Running inside Docker container with full codebase mounted at /app
    cd /app
    python -m pytest tests/ -v --tb=short --no-header -W ignore::RuntimeWarning 2>&1
  else
    # Running locally: use the directory containing this script
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    cd "$SCRIPT_DIR"
    PYTHON=$(command -v python 2>/dev/null || command -v python3)
    $PYTHON -m pytest tests/ -v --tb=short --no-header -W ignore::RuntimeWarning 2>&1
  fi
}
# --- END CONFIGURATION SECTION ---

### COMMON EXECUTION; DO NOT MODIFY ###
run_all_tests