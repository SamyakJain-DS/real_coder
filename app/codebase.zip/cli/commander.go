package cli

// Commander declares the single method that all command structs must implement.
// Every value passed to AddCommand must satisfy this interface.
type Commander interface {
	Execute() error
}