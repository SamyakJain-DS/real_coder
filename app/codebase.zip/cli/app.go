package cli

import (
	"fmt"
	"os"
	"reflect"
	"strconv"
	"strings"
)

// ANSI color escape codes.
// Section headers use cyan; individual flag/argument entries use yellow.
const (
	colorReset  = "\033[0m"
	colorCyan   = "\033[36m"
	colorYellow = "\033[33m"
)

// registeredCommand holds the registration data for a single command.
type registeredCommand struct {
	name        string
	description string
	cmd         Commander
}

// Group represents a named subcommand group that holds its own set of
// registered subcommands. Instances are created exclusively through App.AddGroup.
type Group struct {
	name        string
	description string
	commands    []registeredCommand
}

// AddCommand registers cmd as a subcommand named name under g.
// Returns a non-nil error when a subcommand with the same name is already
// registered within that group.
func (g *Group) AddCommand(name, description string, cmd Commander) error {
	for _, c := range g.commands {
		if c.name == name {
			return fmt.Errorf("subcommand %q already registered in group %q", name, g.name)
		}
	}
	g.commands = append(g.commands, registeredCommand{name: name, description: description, cmd: cmd})
	return nil
}

// App is the top-level application struct that stores the program name, version
// string, registered top-level commands, and registered subcommand groups.
// Instances are created exclusively through New.
type App struct {
	name     string
	version  string
	commands []registeredCommand
	groups   []*Group
}

// New creates and returns a new App configured with the given program name and
// version string. The returned App handles --version automatically in Run.
func New(name, version string) *App {
	return &App{
		name:    name,
		version: version,
	}
}

// AddCommand registers cmd as a top-level command named name with the given
// description. Returns a non-nil error if name matches any existing top-level
// command name or any existing group name.
func (a *App) AddCommand(name, description string, cmd Commander) error {
	for _, c := range a.commands {
		if c.name == name {
			return fmt.Errorf("command %q already registered", name)
		}
	}
	for _, g := range a.groups {
		if g.name == name {
			return fmt.Errorf("name %q conflicts with an existing group", name)
		}
	}
	a.commands = append(a.commands, registeredCommand{name: name, description: description, cmd: cmd})
	return nil
}

// AddGroup creates a subcommand group named name with the given description,
// registers it under the App, and returns a pointer to the new Group and a nil
// error. Returns a nil *Group and a non-nil error if name matches any existing
// group name or any existing top-level command name.
func (a *App) AddGroup(name, description string) (*Group, error) {
	for _, g := range a.groups {
		if g.name == name {
			return nil, fmt.Errorf("group %q already registered", name)
		}
	}
	for _, c := range a.commands {
		if c.name == name {
			return nil, fmt.Errorf("name %q conflicts with an existing command", name)
		}
	}
	g := &Group{name: name, description: description}
	a.groups = append(a.groups, g)
	return g, nil
}

// Run parses args to resolve the matching command or group-subcommand pair,
// populates the command struct via reflection, and calls Execute on it.
//
// Resolution order:
//  1. --help / -h as first arg -> print top-level help, return nil
//  2. First token matches a registered group:
//     a. No further token, or next token is --help / -h -> print group help, return nil
//     b. Next token matches a subcommand:
//     - Next-next token is --help / -h -> print command help, return nil
//     - Otherwise -> run the subcommand
//     c. Next token is unknown -> return non-nil error
//  3. First token matches a top-level command:
//     a. Next token is --help / -h -> print command help, return nil
//     b. Otherwise -> run the command
//  4. --version anywhere in args -> write version string to stdout, return nil
//  5. Otherwise -> return non-nil error
func (a *App) Run(args []string) error {
	// -- 1. Top-level help ----------------------------------------------------
	if len(args) > 0 && (args[0] == "--help" || args[0] == "-h") {
		a.printTopLevelHelp()
		return nil
	}

	if len(args) == 0 {
		return fmt.Errorf("no command specified")
	}

	first := args[0]

	// -- 2. Group dispatch ----------------------------------------------------
	for _, g := range a.groups {
		if g.name == first {
			rest := args[1:]
			// Group help: no subcommand, or explicit help flag
			if len(rest) == 0 || rest[0] == "--help" || rest[0] == "-h" {
				g.printHelp()
				return nil
			}
			subName := rest[0]
			for _, sc := range g.commands {
				if sc.name == subName {
					subRest := rest[1:]
					// Command help
					if len(subRest) > 0 && (subRest[0] == "--help" || subRest[0] == "-h") {
						printCommandHelp(sc.name, sc.description, sc.cmd)
						return nil
					}
					return runCommand(sc.cmd, subRest)
				}
			}
			return fmt.Errorf("unknown subcommand %q in group %q", subName, g.name)
		}
	}

	// -- 3. Top-level command dispatch ----------------------------------------
	for _, c := range a.commands {
		if c.name == first {
			rest := args[1:]
			if len(rest) > 0 && (rest[0] == "--help" || rest[0] == "-h") {
				printCommandHelp(c.name, c.description, c.cmd)
				return nil
			}
			return runCommand(c.cmd, rest)
		}
	}

	// -- 4. --version (no command matched) ------------------------------------
	for _, arg := range args {
		if arg == "--version" {
			fmt.Println(a.version)
			return nil
		}
	}

	// -- 5. No match ----------------------------------------------------------
	return fmt.Errorf("unknown command %q", first)
}

// GenerateCompletion returns a shell completion script for all registered
// commands and subcommands. Supported shells: "bash", "zsh".
// Returns an empty string and a non-nil error for any other shell name.
func (a *App) GenerateCompletion(shell string) (string, error) {
	switch shell {
	case "bash":
		return a.generateBashCompletion(), nil
	case "zsh":
		return a.generateZshCompletion(), nil
	default:
		return "", fmt.Errorf("unsupported shell %q: supported shells are bash and zsh", shell)
	}
}

// -- Completion script generators ---------------------------------------------

func (a *App) generateBashCompletion() string {
	var sb strings.Builder

	// Build the safe function name (replace hyphens with underscores).
	safeName := strings.ReplaceAll(a.name, "-", "_")
	funcName := "_" + safeName + "_completion"

	// Collect all top-level tokens (commands + group names).
	var topLevel []string
	for _, c := range a.commands {
		topLevel = append(topLevel, c.name)
	}
	for _, g := range a.groups {
		topLevel = append(topLevel, g.name)
	}

	sb.WriteString(fmt.Sprintf("%s() {\n", funcName))
	sb.WriteString("    local cur=\"${COMP_WORDS[COMP_CWORD]}\"\n")
	sb.WriteString("    local prev=\"${COMP_WORDS[COMP_CWORD-1]}\"\n")
	sb.WriteString(fmt.Sprintf("    local commands=\"%s\"\n", strings.Join(topLevel, " ")))
	sb.WriteString("\n")

	// Per-group subcommand completion.
	for _, g := range a.groups {
		var subNames []string
		for _, sc := range g.commands {
			subNames = append(subNames, sc.name)
		}
		sb.WriteString(fmt.Sprintf("    if [[ \"${prev}\" == \"%s\" ]]; then\n", g.name))
		sb.WriteString(fmt.Sprintf("        COMPREPLY=($(compgen -W \"%s\" -- \"${cur}\"))\n", strings.Join(subNames, " ")))
		sb.WriteString("        return 0\n")
		sb.WriteString("    fi\n")
	}

	sb.WriteString("    COMPREPLY=($(compgen -W \"${commands}\" -- \"${cur}\"))\n")
	sb.WriteString("}\n")
	sb.WriteString(fmt.Sprintf("complete -F %s %s\n", funcName, a.name))

	return sb.String()
}

func (a *App) generateZshCompletion() string {
	var sb strings.Builder

	safeName := strings.ReplaceAll(a.name, "-", "_")
	funcName := "_" + safeName

	sb.WriteString(fmt.Sprintf("#compdef %s\n\n", a.name))
	sb.WriteString(fmt.Sprintf("%s() {\n", funcName))
	sb.WriteString("    local -a commands\n")
	sb.WriteString("    commands=(\n")
	for _, c := range a.commands {
		// Escape single quotes in the description.
		desc := strings.ReplaceAll(c.description, "'", "'\\''")
		sb.WriteString(fmt.Sprintf("        '%s:%s'\n", c.name, desc))
	}
	for _, g := range a.groups {
		desc := strings.ReplaceAll(g.description, "'", "'\\''")
		sb.WriteString(fmt.Sprintf("        '%s:%s'\n", g.name, desc))
	}
	sb.WriteString("    )\n")
	sb.WriteString("    _describe 'command' commands\n")

	// Per-group subcommand completion.
	for _, g := range a.groups {
		sb.WriteString(fmt.Sprintf("\n    if [[ \"${words[2]}\" == \"%s\" ]]; then\n", g.name))
		sb.WriteString("        local -a subcommands\n")
		sb.WriteString("        subcommands=(\n")
		for _, sc := range g.commands {
			desc := strings.ReplaceAll(sc.description, "'", "'\\''")
			sb.WriteString(fmt.Sprintf("            '%s:%s'\n", sc.name, desc))
		}
		sb.WriteString("        )\n")
		sb.WriteString("        _describe 'subcommand' subcommands\n")
		sb.WriteString("    fi\n")
	}

	sb.WriteString("}\n\n")
	sb.WriteString(fmt.Sprintf("compdef %s %s\n", funcName, a.name))

	return sb.String()
}

// -- Help text printers --------------------------------------------------------

// printTopLevelHelp writes the top-level help text listing all registered
// commands and groups to stdout.
func (a *App) printTopLevelHelp() {
	fmt.Printf("%sUsage:%s %s <command> [options]\n\n", colorCyan, colorReset, a.name)

	if len(a.commands) > 0 {
		fmt.Printf("%sCommands:%s\n", colorCyan, colorReset)
		for _, c := range a.commands {
			fmt.Printf("%s  %-22s%s%s\n", colorYellow, c.name, colorReset, c.description)
		}
		fmt.Println()
	}

	if len(a.groups) > 0 {
		fmt.Printf("%sCommand Groups:%s\n", colorCyan, colorReset)
		for _, g := range a.groups {
			fmt.Printf("%s  %-22s%s%s\n", colorYellow, g.name, colorReset, g.description)
		}
		fmt.Println()
	}

	fmt.Printf("%sGlobal Flags:%s\n", colorCyan, colorReset)
	fmt.Printf("%s  --version%s\tPrint version information\n", colorYellow, colorReset)
	fmt.Printf("%s  --help, -h%s\tShow help for a command\n", colorYellow, colorReset)
}

// printHelp writes the group's help text listing all registered subcommands
// within the group to stdout.
func (g *Group) printHelp() {
	fmt.Printf("%sGroup:%s %s\n", colorCyan, colorReset, g.name)
	fmt.Printf("  %s\n\n", g.description)

	if len(g.commands) > 0 {
		fmt.Printf("%sSubcommands:%s\n", colorCyan, colorReset)
		for _, c := range g.commands {
			fmt.Printf("%s  %-22s%s%s\n", colorYellow, c.name, colorReset, c.description)
		}
		fmt.Println()
	}
}

// printCommandHelp writes the command's help text to stdout.
// Section headers are printed in cyan; individual entries in yellow.
func printCommandHelp(name, description string, cmd Commander) {
	fmt.Printf("%sCommand:%s %s\n", colorCyan, colorReset, name)
	fmt.Printf("  %s\n\n", description)

	v := reflect.ValueOf(cmd)
	if v.Kind() == reflect.Ptr {
		v = v.Elem()
	}
	if v.Kind() != reflect.Struct {
		return
	}
	t := v.Type()

	// Collect flags and positional args by inspecting struct tags.
	type flagEntry struct {
		long, short, help string
		required          bool
	}
	type posEntry struct {
		index int
		name  string
		help  string
		required bool
	}

	var flags []flagEntry
	var positionals []posEntry

	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		if !field.IsExported() {
			continue
		}
		cliTag := field.Tag.Get("cli")
		helpTag := field.Tag.Get("help")
		posTag := field.Tag.Get("pos")
		reqTag := field.Tag.Get("required")

		if posTag != "" {
			posN, err := strconv.Atoi(posTag)
			if err != nil {
				continue
			}
			positionals = append(positionals, posEntry{
				index:    posN,
				name:     field.Name,
				help:     helpTag,
				required: reqTag == "true",
			})
		} else if cliTag != "" {
			parts := strings.SplitN(cliTag, ",", 2)
			long := parts[0]
			short := ""
			if len(parts) > 1 {
				short = parts[1]
			}
			flags = append(flags, flagEntry{
				long:     long,
				short:    short,
				help:     helpTag,
				required: reqTag == "true",
			})
		}
	}

	if len(flags) > 0 {
		fmt.Printf("%sFlags:%s\n", colorCyan, colorReset)
		for _, f := range flags {
			req := ""
			if f.required {
				req = " (required)"
			}
			if f.short != "" {
				fmt.Printf("%s  --%-18s-%s%s\t%s%s\n",
					colorYellow, f.long+", ", f.short, colorReset, f.help, req)
			} else {
				fmt.Printf("%s  --%-21s%s\t%s%s\n",
					colorYellow, f.long, colorReset, f.help, req)
			}
		}
		fmt.Println()
	}

	if len(positionals) > 0 {
		fmt.Printf("%sPositional Arguments:%s\n", colorCyan, colorReset)
		for _, p := range positionals {
			req := ""
			if p.required {
				req = " (required)"
			}
			fmt.Printf("%s  [%d] %-19s%s\t%s%s\n",
				colorYellow, p.index, p.name, colorReset, p.help, req)
		}
		fmt.Println()
	}
}

// -- Command execution ---------------------------------------------------------

// runCommand populates cmd's struct fields from args (flags and positional
// arguments) and from environment variables, then calls Execute.
//
// Processing order:
//  1. Environment variables (fields tagged env:"VAR")
//  2. Flags and positional arguments from args (args values take precedence)
//  3. Validation of required fields
//  4. cmd.Execute()
func runCommand(cmd Commander, args []string) error {
	v := reflect.ValueOf(cmd)
	if v.Kind() != reflect.Ptr {
		return fmt.Errorf("command must be passed as a pointer to a struct")
	}
	v = v.Elem()
	if v.Kind() != reflect.Struct {
		return fmt.Errorf("command must be passed as a pointer to a struct")
	}
	t := v.Type()

	// set tracks which field indices were explicitly populated (env or args).
	set := make(map[int]bool)

	// -- Step 1: Environment variables ----------------------------------------
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		fv := v.Field(i)
		if !fv.CanSet() {
			continue
		}
		envName := field.Tag.Get("env")
		if envName == "" {
			continue
		}
		envVal, exists := os.LookupEnv(envName)
		if !exists || envVal == "" {
			continue
		}
		if err := setField(fv, envVal); err != nil {
			return fmt.Errorf("env var %s: %w", envName, err)
		}
		set[i] = true
	}

	// -- Step 2: Parse args ----------------------------------------------------
	// positionalValues accumulates non-flag argument tokens in order.
	var positionalValues []string

	idx := 0
	for idx < len(args) {
		arg := args[idx]

		if strings.HasPrefix(arg, "--") {
			// Long flag: --name or --name value
			name := arg[2:]
			if name == "" {
				// Bare "--" is not supported; treat as unrecognized.
				return fmt.Errorf("unrecognized flag: --")
			}
			fieldIdx, fv, kind, found := findFieldByLong(t, v, name)
			if !found {
				return fmt.Errorf("unrecognized flag: --%s", name)
			}
			if kind == reflect.Bool {
				// Bool flags require an explicit "true" or "false" value when a
				// next token is present; bare flags (no next token) default to true.
				if idx+1 < len(args) {
					idx++
					if err := setField(fv, args[idx]); err != nil {
						return err
					}
				} else {
					fv.SetBool(true)
				}
			} else {
				idx++
				if idx >= len(args) {
					return fmt.Errorf("flag --%s requires a value", name)
				}
				if err := setField(fv, args[idx]); err != nil {
					return err
				}
			}
			set[fieldIdx] = true

		} else if strings.HasPrefix(arg, "-") {
			// Short flag: -x or -x value
			if len(arg) != 2 {
				return fmt.Errorf("unrecognized flag: %s", arg)
			}
			short := string(arg[1])
			fieldIdx, fv, kind, found := findFieldByShort(t, v, short)
			if !found {
				return fmt.Errorf("unrecognized flag: -%s", short)
			}
			if kind == reflect.Bool {
				if idx+1 < len(args) {
					idx++
					if err := setField(fv, args[idx]); err != nil {
						return err
					}
				} else {
					fv.SetBool(true)
				}
			} else {
				idx++
				if idx >= len(args) {
					return fmt.Errorf("flag -%s requires a value", short)
				}
				if err := setField(fv, args[idx]); err != nil {
					return err
				}
			}
			set[fieldIdx] = true

		} else {
			// Non-flag token: positional argument.
			positionalValues = append(positionalValues, arg)
		}

		idx++
	}

	// -- Step 3: Assign positional arguments ----------------------------------
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		fv := v.Field(i)
		if !fv.CanSet() {
			continue
		}
		posTag := field.Tag.Get("pos")
		if posTag == "" {
			continue
		}
		posN, err := strconv.Atoi(posTag)
		if err != nil {
			return fmt.Errorf("invalid pos tag on field %s: %s", field.Name, posTag)
		}
		if posN < 1 {
			return fmt.Errorf("pos tag on field %s must be >= 1, got %d", field.Name, posN)
		}
		if posN <= len(positionalValues) {
			if err := setField(fv, positionalValues[posN-1]); err != nil {
				return err
			}
			set[i] = true
		}
	}

	// -- Step 4: Validate required fields -------------------------------------
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		if field.Tag.Get("required") != "true" {
			continue
		}
		if set[i] {
			continue
		}
		// Build a descriptive field identifier for the error message.
		if cliTag := field.Tag.Get("cli"); cliTag != "" {
			parts := strings.SplitN(cliTag, ",", 2)
			return fmt.Errorf("required flag --%s not provided", parts[0])
		}
		if posTag := field.Tag.Get("pos"); posTag != "" {
			return fmt.Errorf("required positional argument (pos=%s) not provided", posTag)
		}
		return fmt.Errorf("required field %q not provided", field.Name)
	}

	// -- Step 5: Execute -------------------------------------------------------
	return cmd.Execute()
}

// -- Reflection helpers --------------------------------------------------------

// findFieldByLong searches t/v for an exported field whose cli tag long name
// matches name. Returns the field index, Value, Kind, and whether it was found.
func findFieldByLong(t reflect.Type, v reflect.Value, name string) (int, reflect.Value, reflect.Kind, bool) {
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		fv := v.Field(i)
		if !fv.CanSet() {
			continue
		}
		cliTag := field.Tag.Get("cli")
		if cliTag == "" {
			continue
		}
		parts := strings.SplitN(cliTag, ",", 2)
		if parts[0] == name {
			return i, fv, fv.Kind(), true
		}
	}
	return 0, reflect.Value{}, reflect.Invalid, false
}

// findFieldByShort searches t/v for an exported field whose cli tag shorthand
// matches short. Returns the field index, Value, Kind, and whether it was found.
func findFieldByShort(t reflect.Type, v reflect.Value, short string) (int, reflect.Value, reflect.Kind, bool) {
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		fv := v.Field(i)
		if !fv.CanSet() {
			continue
		}
		cliTag := field.Tag.Get("cli")
		if cliTag == "" {
			continue
		}
		parts := strings.SplitN(cliTag, ",", 2)
		if len(parts) > 1 && parts[1] == short {
			return i, fv, fv.Kind(), true
		}
	}
	return 0, reflect.Value{}, reflect.Invalid, false
}

// setField converts the string s to fv's type and assigns it.
// Supported types: string, int, bool, float64.
// Bool accepts only "true" or "false"; any other value returns a non-nil error.
func setField(fv reflect.Value, s string) error {
	switch fv.Kind() {
	case reflect.String:
		fv.SetString(s)

	case reflect.Int:
		n, err := strconv.ParseInt(s, 10, 64)
		if err != nil {
			return fmt.Errorf("cannot convert %q to int: %v", s, err)
		}
		fv.SetInt(n)

	case reflect.Bool:
		switch s {
		case "true":
			fv.SetBool(true)
		case "false":
			fv.SetBool(false)
		default:
			return fmt.Errorf("cannot convert %q to bool: must be \"true\" or \"false\"", s)
		}

	case reflect.Float64:
		f, err := strconv.ParseFloat(s, 64)
		if err != nil {
			return fmt.Errorf("cannot convert %q to float64: %v", s, err)
		}
		fv.SetFloat(f)

	default:
		return fmt.Errorf("unsupported field type %s", fv.Kind())
	}
	return nil
}