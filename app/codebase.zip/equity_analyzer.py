import pandas as pd


def attribute_health_equity_impact(
    access_patterns: pd.DataFrame,
    cba_classifications: pd.DataFrame,
    beneficiary_enrollment: pd.DataFrame,
) -> pd.DataFrame:
    # -- Step 1: join access_patterns with beneficiary_enrollment on cba_id --
    merged = access_patterns.merge(beneficiary_enrollment, on="cba_id", how="left")

    # -- Step 2: join with cba_classifications on cba_id ---------------------
    merged = merged.merge(cba_classifications, on="cba_id", how="left")

    # -- Denominator: total unique beneficiary_ids per cba_id in enrollment --
    total_bene_per_cba = (
        beneficiary_enrollment
        .groupby("cba_id")["beneficiary_id"]
        .nunique()
        .to_dict()
    )

    # -- Steps 3-6: aggregate per (cba_id, year) ------------------------------
    results = []
    for (cba_id, year), group in merged.groupby(["cba_id", "year"]):
        # Step 3: dual-eligible unique beneficiaries
        dual_count = group.loc[group["dual_eligible"] == 1, "beneficiary_id"].nunique()

        # Step 4: non-dual-eligible unique beneficiaries
        non_dual_count = group.loc[group["dual_eligible"] == 0, "beneficiary_id"].nunique()

        # Step 5: rural/frontier unique beneficiaries
        rural_frontier_mask = (
            (group["rural_classification"] == "rural") |
            (group["rural_flag"] == 1) |
            (group["frontier_flag"] == 1)
        )
        rural_frontier_benes = group.loc[rural_frontier_mask, "beneficiary_id"].nunique()

        total_benes = total_bene_per_cba.get(cba_id, 0)
        rural_frontier_proportion = (
            rural_frontier_benes / total_benes if total_benes > 0 else 0.0
        )

        # Step 6: access_pattern - contract_attrition takes precedence
        if (group["access_pattern"] == "contract_attrition").any():
            access_pattern = "contract_attrition"
        else:
            access_pattern = "utilization_shift"

        results.append({
            "cba_id":                   cba_id,
            "year":                     year,
            "access_pattern":           access_pattern,
            "dual_eligible_count":      dual_count,
            "non_dual_eligible_count":  non_dual_count,
            "rural_frontier_proportion": rural_frontier_proportion,
        })

    return pd.DataFrame(
        results,
        columns=[
            "cba_id",
            "year",
            "access_pattern",
            "dual_eligible_count",
            "non_dual_eligible_count",
            "rural_frontier_proportion",
        ],
    )