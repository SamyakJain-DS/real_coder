"""
Command-line password manager backed by a SQLCipher-encrypted SQLite database.

All vault credential data (service names, usernames, URLs, passwords) is stored
encrypted at the page level using AES-256 via SQLCipher. The master password
drives PBKDF2 key derivation at 600,000 iterations with a random salt that
SQLCipher stores in the first 16 bytes of the database file.
"""

from __future__ import annotations

import json
import os
import secrets
import string
import sys
import time
import threading
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_KDF_ITER: int = 600_000

# Symbol character class used consistently across generation and audit.
# Using the full ASCII punctuation set for comprehensive symbol coverage.
_SYMBOLS: str = string.punctuation  # !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~

# Pronounceable password building blocks
_VOWELS: str = "aeiou"
_CONSONANTS: str = "bcdfghjklmnprstvwyz"

# Session file (plaintext allowed per spec for session management data)
_SESSION_FILE: str = ".vault_session.json"


# ---------------------------------------------------------------------------
# Internal database helpers
# ---------------------------------------------------------------------------

def _escape_pragma_str(value: str) -> str:
    """Escape single quotes for use inside a PRAGMA string literal."""
    return value.replace("'", "''")


def _open_db(db_path: str, master_password: str):
    """
    Open an existing SQLCipher-encrypted vault database and return the
    connection.  Raises ValueError when the master password is incorrect
    (detected on first database access as required by the spec).
    """
    import sqlcipher3  # type: ignore

    conn = sqlcipher3.connect(db_path)
    escaped = _escape_pragma_str(master_password)
    # Key must be set before any other database access.
    conn.execute(f"PRAGMA key = '{escaped}'")
    conn.execute(f"PRAGMA kdf_iter = {_KDF_ITER}")
    # First actual database access – raises an exception if the password is wrong.
    try:
        conn.execute("SELECT count(*) FROM sqlite_master").fetchone()
    except Exception as exc:
        conn.close()
        raise ValueError(
            f"Invalid master password or corrupted vault at '{db_path}'"
        ) from exc
    return conn


# ---------------------------------------------------------------------------
# Public vault functions
# ---------------------------------------------------------------------------

def init_vault(db_path: str, master_password: str) -> None:
    """
    Create a new SQLCipher-encrypted SQLite vault at *db_path* using
    *master_password* for encryption with 600,000 key-derivation iterations.

    Raises FileExistsError when a file already exists at *db_path*.
    """
    import sqlcipher3  # type: ignore

    if os.path.exists(db_path):
        raise FileExistsError(f"Vault already exists at '{db_path}'")

    conn = sqlcipher3.connect(db_path)
    try:
        escaped = _escape_pragma_str(master_password)
        conn.execute(f"PRAGMA key = '{escaped}'")
        conn.execute(f"PRAGMA kdf_iter = {_KDF_ITER}")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS entries (
                service  TEXT PRIMARY KEY NOT NULL,
                username TEXT NOT NULL,
                url      TEXT NOT NULL,
                password TEXT NOT NULL
            )
            """
        )
        conn.commit()
    finally:
        conn.close()


def add_entry(
    db_path: str,
    master_password: str,
    service: str,
    username: str,
    url: str,
    password: str,
) -> None:
    """
    Open the encrypted vault and store a new credential entry.

    When *password* is an empty string a 16-character password is
    auto-generated using all four character classes in non-pronounceable mode.

    Raises ValueError when an entry for *service* already exists.
    Raises ValueError when the master password is incorrect.
    """
    if not password:
        password = generate_password(
            length=16,
            use_upper=True,
            use_lower=True,
            use_digits=True,
            use_symbols=True,
            pronounceable=False,
        )

    conn = _open_db(db_path, master_password)
    try:
        cur = conn.execute(
            "SELECT 1 FROM entries WHERE service = ?", (service,)
        )
        if cur.fetchone() is not None:
            raise ValueError(
                f"An entry for service '{service}' already exists in the vault"
            )
        conn.execute(
            "INSERT INTO entries (service, username, url, password) "
            "VALUES (?, ?, ?, ?)",
            (service, username, url, password),
        )
        conn.commit()
    finally:
        conn.close()


def get_entry(
    db_path: str,
    master_password: str,
    service: str,
    clipboard_timeout: int,
) -> dict:
    """
    Retrieve the entry matching the exact *service* name, copy its password
    to the system clipboard, and clear the clipboard after *clipboard_timeout*
    seconds.  The function blocks until the clipboard has been cleared before
    returning.

    Returns a dict with keys: service, username, url, password.
    Raises KeyError when *service* is not found.
    Raises ValueError when the master password is incorrect.
    """
    import pyperclip  # type: ignore

    conn = _open_db(db_path, master_password)
    try:
        cur = conn.execute(
            "SELECT service, username, url, password "
            "FROM entries WHERE service = ?",
            (service,),
        )
        row = cur.fetchone()
        if row is None:
            raise KeyError(f"No entry found for service '{service}'")
        entry = {
            "service":  row[0],
            "username": row[1],
            "url":      row[2],
            "password": row[3],
        }
    finally:
        conn.close()

    pyperclip.copy(entry["password"])

    # Clear the clipboard after the timeout.  The thread is non-daemon so the
    # process remains active until the clipboard has been cleared before
    # exiting (per spec).  get_entry does NOT join the thread – it returns the
    # entry immediately; keeping the process alive is the responsibility of the
    # non-daemon thread at process-exit time.
    def _clear_clipboard() -> None:
        time.sleep(clipboard_timeout)
        try:
            pyperclip.copy("")
        except Exception:
            pass

    t = threading.Thread(target=_clear_clipboard, daemon=False)
    t.start()

    return entry


def list_entries(db_path: str, master_password: str) -> list[dict]:
    """
    Return all stored entries as a list of dicts containing only
    *service* and *username* keys, ordered alphabetically by service.

    Returns an empty list when the vault contains no entries.
    Raises ValueError when the master password is incorrect.
    """
    conn = _open_db(db_path, master_password)
    try:
        cur = conn.execute(
            "SELECT service, username FROM entries ORDER BY service"
        )
        return [{"service": row[0], "username": row[1]} for row in cur.fetchall()]
    finally:
        conn.close()


def edit_entry(
    db_path: str,
    master_password: str,
    service: str,
    username: str,
    url: str,
    password: str,
) -> None:
    """
    Update the *username*, *url*, and *password* fields of the entry
    identified by exact *service* name match.  Any field passed as an empty
    string is left unchanged.  *service* is immutable and cannot be changed.

    Raises KeyError when *service* is not found.
    Raises ValueError when the master password is incorrect.
    """
    conn = _open_db(db_path, master_password)
    try:
        cur = conn.execute(
            "SELECT username, url, password FROM entries WHERE service = ?",
            (service,),
        )
        row = cur.fetchone()
        if row is None:
            raise KeyError(f"No entry found for service '{service}'")
        new_username = username if username else row[0]
        new_url      = url      if url      else row[1]
        new_password = password if password else row[2]
        conn.execute(
            "UPDATE entries SET username = ?, url = ?, password = ? "
            "WHERE service = ?",
            (new_username, new_url, new_password, service),
        )
        conn.commit()
    finally:
        conn.close()


def remove_entry(
    db_path: str,
    master_password: str,
    service: str,
    confirm: bool,
) -> None:
    """
    Delete the entry identified by exact *service* name match when *confirm*
    is True.  Returns without modifying the database when *confirm* is False.

    Raises KeyError when *confirm* is True and *service* is not found.
    Raises ValueError when the master password is incorrect.
    """
    if not confirm:
        return

    conn = _open_db(db_path, master_password)
    try:
        cur = conn.execute(
            "SELECT 1 FROM entries WHERE service = ?", (service,)
        )
        if cur.fetchone() is None:
            raise KeyError(f"No entry found for service '{service}'")
        conn.execute("DELETE FROM entries WHERE service = ?", (service,))
        conn.commit()
    finally:
        conn.close()


def generate_password(
    length: int,
    use_upper: bool,
    use_lower: bool,
    use_digits: bool,
    use_symbols: bool,
    pronounceable: bool,
) -> str:
    """
    Generate and return a random password of exactly *length* characters.

    When *pronounceable* is True a syllable-based (CV / CVC / VC patterns)
    password is produced; the four character-class flags are ignored.

    When *pronounceable* is False only the enabled character classes are used.
    Raises ValueError when *pronounceable* is False and all four flags are False.
    """
    if pronounceable:
        result: list[str] = []
        while len(result) < length:
            pattern = secrets.choice(["CV", "CVC", "VC"])
            for ch_type in pattern:
                if ch_type == "C":
                    result.append(secrets.choice(_CONSONANTS))
                else:
                    result.append(secrets.choice(_VOWELS))
        return "".join(result[:length])

    # Non-pronounceable path
    if not any([use_upper, use_lower, use_digits, use_symbols]):
        raise ValueError(
            "At least one character class must be enabled when pronounceable is False"
        )

    charset = ""
    guaranteed: list[str] = []

    if use_upper:
        charset += string.ascii_uppercase
        guaranteed.append(secrets.choice(string.ascii_uppercase))
    if use_lower:
        charset += string.ascii_lowercase
        guaranteed.append(secrets.choice(string.ascii_lowercase))
    if use_digits:
        charset += string.digits
        guaranteed.append(secrets.choice(string.digits))
    if use_symbols:
        charset += _SYMBOLS
        guaranteed.append(secrets.choice(_SYMBOLS))

    if length <= len(guaranteed):
        pool = guaranteed[:length]
    else:
        fill = [secrets.choice(charset) for _ in range(length - len(guaranteed))]
        pool = guaranteed + fill

    # Shuffle in-place using a cryptographically strong RNG.
    rng = secrets.SystemRandom()
    rng.shuffle(pool)
    return "".join(pool)


def search_entries(
    db_path: str,
    master_password: str,
    query: str,
) -> list[dict]:
    """
    Return all entries whose service name contains *query* as a
    case-insensitive substring.

    Returns an empty list when no entries match.
    Raises ValueError when the master password is incorrect.
    """
    # Escape LIKE special characters in the user query.
    escaped_query = (
        query
        .replace("\\", "\\\\")
        .replace("%", "\\%")
        .replace("_", "\\_")
    )

    conn = _open_db(db_path, master_password)
    try:
        cur = conn.execute(
            "SELECT service, username FROM entries "
            "WHERE LOWER(service) LIKE LOWER(?) ESCAPE '\\' "
            "ORDER BY service",
            (f"%{escaped_query}%",),
        )
        return [{"service": row[0], "username": row[1]} for row in cur.fetchall()]
    finally:
        conn.close()


def export_vault(
    db_path: str,
    master_password: str,
    backup_path: str,
    backup_password: str,
) -> None:
    """
    Read all entries from the vault at *db_path* and write them to a new
    SQLCipher-encrypted backup database at *backup_path* using *backup_password*
    as the encryption key.

    Raises ValueError when the master password is incorrect.
    """
    import sqlcipher3  # type: ignore

    source = _open_db(db_path, master_password)
    try:
        rows = source.execute(
            "SELECT service, username, url, password FROM entries"
        ).fetchall()
    finally:
        source.close()

    # Remove an existing backup file so we always create a fresh database.
    if os.path.exists(backup_path):
        os.remove(backup_path)

    dest = sqlcipher3.connect(backup_path)
    try:
        escaped = _escape_pragma_str(backup_password)
        dest.execute(f"PRAGMA key = '{escaped}'")
        dest.execute(f"PRAGMA kdf_iter = {_KDF_ITER}")
        dest.execute(
            """
            CREATE TABLE IF NOT EXISTS entries (
                service  TEXT PRIMARY KEY NOT NULL,
                username TEXT NOT NULL,
                url      TEXT NOT NULL,
                password TEXT NOT NULL
            )
            """
        )
        dest.executemany(
            "INSERT INTO entries (service, username, url, password) "
            "VALUES (?, ?, ?, ?)",
            rows,
        )
        dest.commit()
    finally:
        dest.close()


def import_vault(
    db_path: str,
    master_password: str,
    backup_path: str,
    backup_password: str,
) -> None:
    """
    Read entries from the SQLCipher-encrypted backup at *backup_path* using
    *backup_password* and restore them into the vault at *db_path*.

    Existing entries whose service name matches an imported entry are
    overwritten with the imported values.

    Raises ValueError when the backup password is incorrect.
    Raises ValueError when the master password for the vault is incorrect.
    """
    backup = _open_db(backup_path, backup_password)
    try:
        rows = backup.execute(
            "SELECT service, username, url, password FROM entries"
        ).fetchall()
    finally:
        backup.close()

    dest = _open_db(db_path, master_password)
    try:
        dest.executemany(
            """
            INSERT INTO entries (service, username, url, password)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(service) DO UPDATE SET
                username = excluded.username,
                url      = excluded.url,
                password = excluded.password
            """,
            rows,
        )
        dest.commit()
    finally:
        dest.close()


def audit_passwords(db_path: str, master_password: str) -> list[dict]:
    """
    Evaluate every stored password against three weakness checks:

    1. Fewer than 12 characters.
    2. Fewer than 3 of the 4 character classes (uppercase, lowercase,
       digits, symbols).
    3. Present in the bundled common passwords file at
       ``data/common_passwords.txt``.

    Returns a list of dicts – one per weak entry – with keys:
    *service* (str), *username* (str), *reasons* (list[str]).

    Returns an empty list when no entries are weak.
    Raises ValueError when the master password is incorrect.
    """
    common_path = Path(__file__).parent / "data" / "common_passwords.txt"
    common_passwords: set[str] = set()
    if common_path.exists():
        with common_path.open(encoding="utf-8") as fh:
            for line in fh:
                stripped = line.strip()
                if stripped:
                    common_passwords.add(stripped)

    conn = _open_db(db_path, master_password)
    try:
        rows = conn.execute(
            "SELECT service, username, password FROM entries"
        ).fetchall()
    finally:
        conn.close()

    results: list[dict] = []
    for service, username, password in rows:
        reasons: list[str] = []

        # Check 1: length
        if len(password) < 12:
            reasons.append("Password is fewer than 12 characters")

        # Check 2: character class diversity
        classes = sum([
            any(c in string.ascii_uppercase for c in password),
            any(c in string.ascii_lowercase for c in password),
            any(c in string.digits         for c in password),
            any(c not in string.ascii_letters + string.digits for c in password),
        ])
        if classes < 3:
            reasons.append("Password uses fewer than 3 character classes")

        # Check 3: common passwords list
        if password in common_passwords:
            reasons.append("Password is in the common passwords list")

        if reasons:
            results.append({
                "service":  service,
                "username": username,
                "reasons":  reasons,
            })

    return results


# ---------------------------------------------------------------------------
# Session management (plaintext allowed per spec for idle-timeout data)
# ---------------------------------------------------------------------------

def _load_session() -> dict:
    """Load the persisted session state from disk; return {} on failure."""
    if os.path.exists(_SESSION_FILE):
        try:
            with open(_SESSION_FILE, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            pass
    return {}


def _save_session(db_path: str, master_password: str) -> None:
    """Persist session state (db path, master password, timestamp) to disk."""
    session = {
        "last_time":       time.time(),
        "master_password": master_password,
        "db_path":         db_path,
    }
    with open(_SESSION_FILE, "w", encoding="utf-8") as fh:
        json.dump(session, fh)


def _resolve_master_password(db_path: str, timeout: int, session: dict) -> str:
    """
    Return the master password from the active session when the idle timeout
    has not expired and the db_path matches, otherwise prompt the user via
    getpass.
    """
    import getpass

    elapsed = time.time() - session.get("last_time", 0.0)
    if (
        session
        and "master_password" in session
        and session.get("db_path") == db_path
        and elapsed <= timeout
    ):
        return session["master_password"]

    return getpass.getpass("Master password: ")


# ---------------------------------------------------------------------------
# CLI output helpers
# ---------------------------------------------------------------------------

def _print_table(entries: list[dict]) -> None:
    """
    Print a list of {service, username} dicts as an ASCII box-drawing table.
    """
    if not entries:
        print("(no entries)")
        return

    svc_w = max(max(len(e["service"])  for e in entries), len("Service"))
    usr_w = max(max(len(e["username"]) for e in entries), len("Username"))

    sep = f"+{'-' * (svc_w + 2)}+{'-' * (usr_w + 2)}+"
    header = f"| {'Service':<{svc_w}} | {'Username':<{usr_w}} |"

    print(sep)
    print(header)
    print(sep)
    for e in entries:
        print(f"| {e['service']:<{svc_w}} | {e['username']:<{usr_w}} |")
    print(sep)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    import argparse
    import getpass

    parser = argparse.ArgumentParser(
        prog="vault",
        description="Command-line password manager with SQLCipher encryption",
    )
    parser.add_argument(
        "--db",
        default="vault.db",
        metavar="PATH",
        help="Path to the vault database file (default: vault.db)",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=300,
        metavar="SECONDS",
        help="Idle timeout in seconds before re-prompting for password (default: 300)",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    # --- init ---
    sub.add_parser("init", help="Initialise a new encrypted vault")

    # --- add ---
    p_add = sub.add_parser("add", help="Add a new credential entry")
    p_add.add_argument("--service",  required=True, help="Service / site name")
    p_add.add_argument("--username", default="",    help="Username or e-mail")
    p_add.add_argument("--url",      default="",    help="URL")
    p_add.add_argument(
        "--password",
        default="",
        help="Password (omit or leave empty to auto-generate)",
    )

    # --- get ---
    p_get = sub.add_parser("get", help="Retrieve a credential entry")
    p_get.add_argument("--service", required=True, help="Exact service name")
    p_get.add_argument(
        "--clipboard-timeout",
        type=int,
        default=30,
        metavar="SECONDS",
        help="Seconds before clipboard is cleared (default: 30)",
    )

    # --- list ---
    sub.add_parser("list", help="List all stored entries")

    # --- edit ---
    p_edit = sub.add_parser("edit", help="Edit an existing entry")
    p_edit.add_argument("--service",  required=True, help="Exact service name")
    p_edit.add_argument(
        "--username", default="", help="New username (empty = unchanged)"
    )
    p_edit.add_argument(
        "--url",      default="", help="New URL (empty = unchanged)"
    )
    p_edit.add_argument(
        "--password", default="", help="New password (empty = unchanged)"
    )

    # --- remove ---
    p_remove = sub.add_parser("remove", help="Delete an entry")
    p_remove.add_argument("--service", required=True, help="Exact service name")
    p_remove.add_argument(
        "--confirm",
        action="store_true",
        default=False,
        help="Required flag to actually perform the deletion",
    )

    # --- generate ---
    p_gen = sub.add_parser("generate", help="Generate a random password")
    p_gen.add_argument("--length", type=int, default=16, help="Password length (default: 16)")
    p_gen.add_argument(
        "--no-upper", dest="no_upper", action="store_true", default=False,
        help="Exclude uppercase letters",
    )
    p_gen.add_argument(
        "--no-lower", dest="no_lower", action="store_true", default=False,
        help="Exclude lowercase letters",
    )
    p_gen.add_argument(
        "--no-digits", dest="no_digits", action="store_true", default=False,
        help="Exclude digits",
    )
    p_gen.add_argument(
        "--no-symbols", dest="no_symbols", action="store_true", default=False,
        help="Exclude symbol characters",
    )
    p_gen.add_argument(
        "--pronounceable",
        action="store_true",
        default=False,
        help="Generate a syllable-based pronounceable password",
    )

    # --- search ---
    p_search = sub.add_parser("search", help="Search entries by service name")
    p_search.add_argument("--query", required=True, help="Substring to search for")

    # --- export ---
    p_export = sub.add_parser("export", help="Export vault to an encrypted backup file")
    p_export.add_argument("--backup-path",     required=True, help="Destination backup file path")
    p_export.add_argument("--backup-password", default=None,  help="Backup encryption password")

    # --- import ---
    p_import = sub.add_parser("import", help="Import entries from an encrypted backup file")
    p_import.add_argument("--backup-path",     required=True, help="Source backup file path")
    p_import.add_argument("--backup-password", default=None,  help="Backup encryption password")

    # --- audit ---
    sub.add_parser("audit", help="Audit stored passwords for weaknesses")

    args = parser.parse_args()

    # ------------------------------------------------------------------
    # generate does not interact with the vault or session at all.
    # ------------------------------------------------------------------
    if args.command == "generate":
        try:
            pwd = generate_password(
                length=args.length,
                use_upper=not args.no_upper,
                use_lower=not args.no_lower,
                use_digits=not args.no_digits,
                use_symbols=not args.no_symbols,
                pronounceable=args.pronounceable,
            )
            print(pwd)
        except ValueError as exc:
            print(f"Error: {exc}")
        return

    # ------------------------------------------------------------------
    # init always prompts for a new password (with confirmation).
    # ------------------------------------------------------------------
    if args.command == "init":
        master_password = getpass.getpass("Master password: ")
        try:
            init_vault(args.db, master_password)
            print(f"Vault created at '{args.db}'")
            _save_session(args.db, master_password)
        except Exception as exc:
            print(f"Error: {exc}")
            sys.exit(1)
        return

    # ------------------------------------------------------------------
    # All other commands: resolve master password via session / prompt.
    # ------------------------------------------------------------------
    session = _load_session()
    master_password = _resolve_master_password(args.db, args.timeout, session)

    try:
        if args.command == "add":
            add_entry(
                args.db,
                master_password,
                args.service,
                args.username,
                args.url,
                args.password,
            )
            print(f"Entry for '{args.service}' added successfully.")

        elif args.command == "get":
            entry = get_entry(
                args.db,
                master_password,
                args.service,
                args.clipboard_timeout,
            )
            print(f"Service:  {entry['service']}")
            print(f"Username: {entry['username']}")
            print(f"URL:      {entry['url']}")
            print(f"Password: {entry['password']}")
            print(
                f"(Password was copied to the clipboard and cleared "
                f"after {args.clipboard_timeout} second(s))"
            )

        elif args.command == "list":
            entries = list_entries(args.db, master_password)
            _print_table(entries)

        elif args.command == "edit":
            edit_entry(
                args.db,
                master_password,
                args.service,
                args.username,
                args.url,
                args.password,
            )
            print(f"Entry for '{args.service}' updated successfully.")

        elif args.command == "remove":
            remove_entry(args.db, master_password, args.service, args.confirm)
            if args.confirm:
                print(f"Entry for '{args.service}' removed.")
            else:
                print(
                    "Removal cancelled. Pass --confirm to permanently delete the entry."
                )

        elif args.command == "search":
            entries = search_entries(args.db, master_password, args.query)
            _print_table(entries)

        elif args.command == "export":
            backup_password = args.backup_password
            if backup_password is None:
                backup_password = getpass.getpass("Backup password: ")
            export_vault(args.db, master_password, args.backup_path, backup_password)
            print(f"Vault exported to '{args.backup_path}'.")

        elif args.command == "import":
            backup_password = args.backup_password
            if backup_password is None:
                backup_password = getpass.getpass("Backup password: ")
            import_vault(args.db, master_password, args.backup_path, backup_password)
            print("Vault import complete.")

        elif args.command == "audit":
            results = audit_passwords(args.db, master_password)
            if not results:
                print("All passwords passed the audit. No weaknesses found.")
            else:
                print(f"{len(results)} weak password(s) found:\n")
                for item in results:
                    print(f"  Service:  {item['service']}")
                    print(f"  Username: {item['username']}")
                    for reason in item["reasons"]:
                        print(f"    - {reason}")
                    print()

        # Persist successful session state.
        _save_session(args.db, master_password)

    except Exception as exc:
        print(f"Error: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    main()