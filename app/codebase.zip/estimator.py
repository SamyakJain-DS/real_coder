import pandas as pd


def estimate_single_payment_amount(
    cba_pricing: pd.DataFrame,
    supplier_bids: pd.DataFrame,
) -> pd.DataFrame:
    # Step 1: historical mean SPA per (cba_id, hcpcs_code)
    historical_mean_spa = (
        cba_pricing
        .groupby(["cba_id", "hcpcs_code"], as_index=False)["payment_amount"]
        .mean()
        .rename(columns={"payment_amount": "historical_mean_spa"})
    )

    # Max round per (cba_id, hcpcs_code) from cba_pricing
    max_round = (
        cba_pricing
        .groupby(["cba_id", "hcpcs_code"], as_index=False)["round"]
        .max()
    )

    # Step 2: filter to accredited suppliers with an active surety bond
    filtered = supplier_bids[
        (supplier_bids["accreditation_status"] == "accredited") &
        (supplier_bids["surety_bond_status"] == "active")
    ].copy()

    # Unique (cba_id, hcpcs_code) combinations present in supplier_bids,
    # carrying through the invariant product_category value for each group.
    unique_combos = (
        supplier_bids[["cba_id", "hcpcs_code", "product_category"]]
        .drop_duplicates(subset=["cba_id", "hcpcs_code"])
        .reset_index(drop=True)
    )

    # Build look-ups for historical mean SPA and max round
    hist_lookup = historical_mean_spa.set_index(["cba_id", "hcpcs_code"])["historical_mean_spa"]
    round_lookup = max_round.set_index(["cba_id", "hcpcs_code"])["round"]

    # Group filtered bids once for efficiency
    filtered_groups = filtered.groupby(["cba_id", "hcpcs_code"])

    results = []
    for _, row in unique_combos.iterrows():
        cba_id         = row["cba_id"]
        hcpcs_code     = row["hcpcs_code"]
        product_category = row["product_category"]

        # Historical mean SPA (always defined per spec)
        hist_mean_spa = hist_lookup.get((cba_id, hcpcs_code))

        # Max round
        round_val = round_lookup.get((cba_id, hcpcs_code))

        # Filtered group for this (cba_id, hcpcs_code)
        if (cba_id, hcpcs_code) in filtered_groups.groups:
            group = filtered_groups.get_group((cba_id, hcpcs_code))

            # Step 3: capacity-weighted average bid
            total_capacity = group["capacity_units"].sum()
            cap_weighted_avg = (
                (group["bid_amount"] * group["capacity_units"]).sum() / total_capacity
            )

            # Step 4: mean absolute deviation from the capacity-weighted average
            mean_absolute_deviation = (group["bid_amount"] - cap_weighted_avg).abs().mean()

            # Step 5: estimated SPA = max(raw estimate, historical mean SPA)
            raw_estimate  = cap_weighted_avg - mean_absolute_deviation
            estimated_spa = max(raw_estimate, hist_mean_spa)
        else:
            # Step 5 (empty filtered group): fall back to historical mean SPA
            estimated_spa = hist_mean_spa

        results.append({
            "cba_id":           cba_id,
            "hcpcs_code":       hcpcs_code,
            "product_category": product_category,
            "round":            round_val,
            "estimated_spa":    estimated_spa,
        })

    return pd.DataFrame(
        results,
        columns=["cba_id", "hcpcs_code", "product_category", "round", "estimated_spa"],
    )