using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Text.Json;
using WeddingStudio.Api.Models;

namespace WeddingStudio.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Booking> Bookings => Set<Booking>();
    public DbSet<Session> Sessions => Set<Session>();
    public DbSet<InventoryItem> InventoryItems => Set<InventoryItem>();
    public DbSet<EquipmentKit> EquipmentKits => Set<EquipmentKit>();
    public DbSet<ProofingWorkflow> ProofingWorkflows => Set<ProofingWorkflow>();
    public DbSet<ProofingRound> ProofingRounds => Set<ProofingRound>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Booking.Deliverables stored as a JSON string column
        modelBuilder.Entity<Booking>()
            .Property(b => b.Deliverables)
            .HasConversion(
                v => JsonSerializer.Serialize(v, (JsonSerializerOptions?)null),
                v => JsonSerializer.Deserialize<List<string>>(v, (JsonSerializerOptions?)null)!,
                new ValueComparer<List<string>>(
                    (a, b) => a != null && b != null && a.SequenceEqual(b),
                    c => c.Aggregate(0, (acc, s) => HashCode.Combine(acc, s.GetHashCode())),
                    c => c.ToList()
                )
            );

        // EquipmentKit.InventoryItemIds stored as a JSON string column
        modelBuilder.Entity<EquipmentKit>()
            .Property(e => e.InventoryItemIds)
            .HasConversion(
                v => JsonSerializer.Serialize(v, (JsonSerializerOptions?)null),
                v => JsonSerializer.Deserialize<List<int>>(v, (JsonSerializerOptions?)null)!,
                new ValueComparer<List<int>>(
                    (a, b) => a != null && b != null && a.SequenceEqual(b),
                    c => c.Aggregate(0, (acc, i) => HashCode.Combine(acc, i.GetHashCode())),
                    c => c.ToList()
                )
            );
    }
}
