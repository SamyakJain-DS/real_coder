"""Donor next-gift prediction pipeline.

This module implements :class:`DonorPipeline`, a scikit-learn based pipeline
that turns a history of donor gifts into a prioritised next-30-day
fundraising call list.

The pipeline:

1. Engineers per-donor recency / frequency / monetary (RFM) features,
   tenure and channel-mix shares evaluated at a configurable reference
   date (``as_of_date``).
2. Trains a :class:`~sklearn.linear_model.LogisticRegression` classifier
   for the probability that a donor will make at least one gift inside
   the next 30-day window, and a
   :class:`~sklearn.linear_model.LinearRegression` regressor for the
   total amount that donor would give during that same window.
3. Ranks donors by ``prob_next_gift * expected_next_gift_amount``
   (expected next-30-day revenue) with deterministic donor-id tie
   breaking.
4. Flags donors whose recent contact cadence exceeds their long-run
   baseline through a saturation metric and the configured
   ``saturation_threshold``.

The public API of the module is the :class:`DonorPipeline` class; all
feature engineering, target construction and saturation-score logic is
encapsulated behind its ``fit`` and ``rank_donors`` methods so the
pipeline can be imported and driven end-to-end from client code.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, LogisticRegression


_REQUIRED_COLUMNS: Tuple[str, ...] = (
    "donor_id",
    "donation_amount",
    "date",
    "campaign",
    "channel",
)

_FEATURE_COLUMNS: Tuple[str, ...] = (
    "recency_days",
    "frequency",
    "monetary_total",
    "monetary_mean",
    "tenure_days",
)

_OUTPUT_COLUMNS: Tuple[str, ...] = (
    "donor_id",
    "prob_next_gift",
    "expected_next_gift_amount",
    "expected_next_30_day_revenue",
    "saturation_score",
    "is_over_solicited",
)

_MIN_DONATION_AMOUNT: float = 0.01
_FUTURE_WINDOW_DAYS: int = 30
_RECENT_WINDOW_DAYS: int = 90
_NOT_FITTED_MESSAGE: str = "pipeline must be fit before calling rank_donors"


class DonorPipeline:
    """End-to-end donor next-gift prediction and ranking pipeline.

    The pipeline consumes a :class:`pandas.DataFrame` of historical
    donation records with columns ``donor_id``, ``donation_amount``,
    ``date``, ``campaign`` and ``channel``; engineers per-donor RFM,
    tenure and channel-mix features at a configurable reference date;
    and trains two scikit-learn linear estimators that together yield an
    expected next-30-day revenue per donor.

    During :meth:`rank_donors` the pipeline emits the six-column ranking
    DataFrame described in section 5 of the prompt: donor identifier,
    clipped probability of a next gift, clipped expected next-gift
    amount, expected next-30-day revenue, saturation score, and
    over-solicitation flag. Rows are ordered by expected revenue
    (descending) with ``donor_id`` (ascending) as the tiebreaker and
    reindexed to a fresh :class:`pandas.RangeIndex`.

    Parameters
    ----------
    as_of_date:
        Reference timestamp that splits the donation history into its
        "historical" portion (``<= as_of_date``) and the "future" window
        ``(as_of_date, as_of_date + 30 days]``. When ``None``,
        :meth:`fit` resolves the reference to
        ``donations["date"].max() - pandas.Timedelta(days=30)``.
    saturation_threshold:
        Strict upper bound on ``saturation_score`` above which a donor
        is flagged as over-solicited. Defaults to ``1.5``.
    random_state:
        Seed forwarded to the
        :class:`~sklearn.linear_model.LogisticRegression` constructor
        so that two fits on identical inputs produce identical
        coefficients.
    """

    def __init__(
        self,
        as_of_date: Optional[pd.Timestamp] = None,
        saturation_threshold: float = 1.5,
        random_state: int = 42,
    ) -> None:
        self.as_of_date = as_of_date
        self.saturation_threshold = saturation_threshold
        self.random_state = random_state

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fit(self, donations: pd.DataFrame) -> "DonorPipeline":
        """Validate ``donations``, engineer features, and train both models.

        The method follows the contract laid out in sections 1-4 of the
        prompt, in order:

        1. Validate the five required columns, the no-null rule, and
           the ``donation_amount >= 0.01`` floor.
        2. Resolve ``as_of_date`` — using the constructor value when it
           is a :class:`pandas.Timestamp`, otherwise falling back to
           ``donations["date"].max() - 30 days`` — and raise
           :class:`ValueError` if the resolved date exceeds
           ``donations["date"].max() - 30 days``.
        3. Build the per-donor feature matrix (``recency_days``,
           ``frequency``, ``monetary_total``, ``monetary_mean``,
           ``tenure_days`` and one ``channel_share_<channel>`` column
           per distinct channel, in alphabetical order).
        4. Train a :class:`~sklearn.linear_model.LogisticRegression`
           classifier with target ``1`` for donors with at least one
           donation in ``(as_of_date, as_of_date + 30 days]``.
        5. Train a :class:`~sklearn.linear_model.LinearRegression`
           regressor, fit on the positives-only subset, with target
           equal to the sum of donations in the same 30-day window.
        6. Persist the resolved ``as_of_date``, the feature matrix, and
           both fitted estimators on the instance so
           :meth:`rank_donors` can reuse them without refitting.

        Parameters
        ----------
        donations:
            Historical donation records conforming to the section 1
            contract.

        Returns
        -------
        DonorPipeline
            The same instance, so ``fit`` can be chained with
            :meth:`rank_donors`.

        Raises
        ------
        ValueError
            If ``donations`` violates the column contract, contains
            null values in a required column, carries any
            ``donation_amount`` strictly below ``0.01``, or resolves to
            an ``as_of_date`` strictly greater than
            ``donations["date"].max() - 30 days``.
        """
        self._validate_donations(donations)

        max_date: pd.Timestamp = donations["date"].max()
        boundary: pd.Timestamp = max_date - pd.Timedelta(days=_FUTURE_WINDOW_DAYS)
        resolved_as_of: pd.Timestamp = (
            boundary if self.as_of_date is None else self.as_of_date
        )

        if resolved_as_of > boundary:
            raise ValueError(
                "as_of_date must be less than or equal to "
                "donations['date'].max() - 30 days; "
                f"got {resolved_as_of!r} which is past the boundary "
                f"{boundary!r}"
            )

        self.resolved_as_of_date = resolved_as_of
        self.feature_matrix = self._build_feature_matrix(donations, resolved_as_of)

        donor_ids: List = self.feature_matrix["donor_id"].tolist()
        X = self.feature_matrix.drop(columns=["donor_id"]).to_numpy()

        prob_target, amount_target = self._compute_training_targets(
            donations, resolved_as_of, donor_ids
        )

        self.probability_model = self._fit_probability_model(X, prob_target)
        self.amount_model = self._fit_amount_model(X, prob_target, amount_target)

        return self

    def rank_donors(self, donations: pd.DataFrame) -> pd.DataFrame:
        """Return the six-column donor ranking described in section 5.

        The method re-validates ``donations`` against the section 1
        contract, scores the persisted feature matrix through the two
        fitted estimators, clips ``prob_next_gift`` to ``[0, 1]`` and
        ``expected_next_gift_amount`` to ``>= 0``, multiplies them into
        ``expected_next_30_day_revenue``, recomputes the saturation
        score from ``donations`` relative to the resolved
        ``as_of_date``, flags donors with ``saturation_score >
        saturation_threshold``, and returns the mandated six columns —
        in the mandated order — sorted by expected revenue descending
        with ``donor_id`` ascending as the tiebreaker, reindexed to a
        default :class:`pandas.RangeIndex` starting at ``0``.

        Parameters
        ----------
        donations:
            The donation history previously passed to :meth:`fit`; the
            source of both contract validation and the saturation
            computation.

        Returns
        -------
        pandas.DataFrame
            Exactly one row per donor persisted in the feature matrix,
            with columns ``donor_id``, ``prob_next_gift``,
            ``expected_next_gift_amount``,
            ``expected_next_30_day_revenue``, ``saturation_score``,
            and ``is_over_solicited``.

        Raises
        ------
        RuntimeError
            If :meth:`fit` has not yet completed successfully. The
            message is the exact string
            ``"pipeline must be fit before calling rank_donors"``.
        ValueError
            If ``donations`` violates the section 1 contract.
        """
        if not hasattr(self, "feature_matrix"):
            raise RuntimeError(_NOT_FITTED_MESSAGE)

        self._validate_donations(donations)

        feature_matrix = self.feature_matrix
        donor_ids: List = feature_matrix["donor_id"].tolist()
        X = feature_matrix.drop(columns=["donor_id"]).to_numpy()

        prob_raw = self.probability_model.predict_proba(X)[:, 1]
        prob_next_gift = np.clip(prob_raw, 0.0, 1.0).astype("float64")

        amount_raw = self.amount_model.predict(X)
        expected_next_gift_amount = np.clip(amount_raw, 0.0, None).astype("float64")

        expected_next_30_day_revenue = (
            prob_next_gift * expected_next_gift_amount
        ).astype("float64")

        saturation_score = self._compute_saturation_scores(
            donations, self.resolved_as_of_date, donor_ids
        )

        is_over_solicited = saturation_score > self.saturation_threshold

        ranked = pd.DataFrame(
            {
                "donor_id": pd.Series(donor_ids, dtype="object"),
                "prob_next_gift": prob_next_gift,
                "expected_next_gift_amount": expected_next_gift_amount,
                "expected_next_30_day_revenue": expected_next_30_day_revenue,
                "saturation_score": saturation_score.astype("float64"),
                "is_over_solicited": is_over_solicited.astype("bool"),
            }
        )

        ranked = ranked.sort_values(
            by=["expected_next_30_day_revenue", "donor_id"],
            ascending=[False, True],
            kind="mergesort",
        ).reset_index(drop=True)

        return ranked

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_donations(donations: pd.DataFrame) -> None:
        """Enforce the DataFrame contract from section 1 of the prompt.

        Raises :class:`ValueError` when any required column is missing,
        when any cell in a required column is null, or when any
        ``donation_amount`` value is strictly below ``0.01``. The checks
        run in that order so the null check never dereferences an
        absent column.
        """
        missing = [
            column for column in _REQUIRED_COLUMNS if column not in donations.columns
        ]
        if missing:
            raise ValueError(
                "donations DataFrame is missing required columns: "
                f"{sorted(missing)}"
            )

        for column in _REQUIRED_COLUMNS:
            if donations[column].isna().any():
                raise ValueError(
                    "donations DataFrame contains null values in required "
                    f"column '{column}'"
                )

        if (donations["donation_amount"] < _MIN_DONATION_AMOUNT).any():
            raise ValueError(
                "donations DataFrame contains donation_amount values strictly "
                f"below {_MIN_DONATION_AMOUNT}"
            )

    # ------------------------------------------------------------------
    # Feature engineering
    # ------------------------------------------------------------------

    @staticmethod
    def _build_feature_matrix(
        donations: pd.DataFrame, as_of_date: pd.Timestamp
    ) -> pd.DataFrame:
        """Build the per-donor feature matrix described in section 3.

        Groups the donation history on ``donor_id`` with vectorised
        aggregations to compute ``recency_days``, ``frequency``,
        ``monetary_total``, ``monetary_mean`` and ``tenure_days``; then
        expands the channel counts into one ``channel_share_<channel>``
        column per distinct channel present anywhere in ``donations``
        (alphabetically ordered) and divides by the donor's total
        donation count.
        """
        historical = donations.loc[donations["date"] <= as_of_date]

        grouped = historical.groupby("donor_id", sort=True)
        aggregates = grouped.agg(
            last_donation=("date", "max"),
            first_donation=("date", "min"),
            frequency=("date", "count"),
            monetary_total=("donation_amount", "sum"),
            monetary_mean=("donation_amount", "mean"),
        )

        features = pd.DataFrame(index=aggregates.index)
        features["recency_days"] = (
            (as_of_date - aggregates["last_donation"]).dt.days.astype("int64")
        )
        features["frequency"] = aggregates["frequency"].astype("int64")
        features["monetary_total"] = aggregates["monetary_total"].astype("float64")
        features["monetary_mean"] = aggregates["monetary_mean"].astype("float64")
        features["tenure_days"] = (
            (as_of_date - aggregates["first_donation"]).dt.days.astype("int64")
        )

        channels = sorted(donations["channel"].unique())
        channel_counts = (
            historical.groupby(["donor_id", "channel"])
            .size()
            .unstack(fill_value=0)
            .reindex(index=features.index, columns=channels, fill_value=0)
        )
        totals = channel_counts.sum(axis=1)
        channel_shares = channel_counts.div(totals, axis=0).astype("float64")
        channel_shares.columns = [f"channel_share_{channel}" for channel in channels]

        features = features.join(channel_shares)
        features = features.reset_index()
        features["donor_id"] = features["donor_id"].astype("object")
        return features

    # ------------------------------------------------------------------
    # Model training
    # ------------------------------------------------------------------

    def _fit_probability_model(
        self, X: np.ndarray, prob_target: np.ndarray
    ) -> LogisticRegression:
        """Fit :class:`LogisticRegression` with graceful single-class fallback.

        Scikit-learn's ``LogisticRegression.fit`` refuses to train when
        the target vector contains only one class. That edge case can
        arise for legitimate pipeline configurations — for example when
        the caller supplies an ``as_of_date`` far enough in the past
        that no donor has a gift in the following 30 days. To keep the
        pipeline usable in those cases, this helper detects the
        single-class target and manually installs the fitted attributes
        of :class:`LogisticRegression` so that ``predict_proba`` still
        returns a valid ``(n_samples, 2)`` matrix whose positive-class
        column equals the observed class.
        """
        model = LogisticRegression(random_state=self.random_state)
        unique_classes = np.unique(prob_target)
        if unique_classes.size >= 2:
            model.fit(X, prob_target)
            return model

        only_class = int(unique_classes[0])
        n_features = int(X.shape[1])
        model.classes_ = np.array([0, 1], dtype=np.int64)
        model.coef_ = np.zeros((1, n_features), dtype=np.float64)
        model.intercept_ = np.array(
            [1e12 if only_class == 1 else -1e12], dtype=np.float64
        )
        model.n_features_in_ = n_features
        model.n_iter_ = np.array([0], dtype=np.int32)
        return model

    def _fit_amount_model(
        self,
        X: np.ndarray,
        prob_target: np.ndarray,
        amount_target: np.ndarray,
    ) -> LinearRegression:
        """Fit :class:`LinearRegression` on positives with safe fallback.

        Per section 4 of the prompt the amount model is trained on the
        subset of donors whose probability target equals 1. When no
        donor satisfies that condition, scikit-learn's
        :meth:`LinearRegression.fit` would raise because the training
        matrix is empty; this helper installs zero coefficients in that
        case so ``predict`` returns ``0.0`` for every donor, which the
        ranking stage then clips at its ``>= 0.0`` floor as required.
        """
        model = LinearRegression()
        positive_mask = prob_target == 1
        if positive_mask.any():
            model.fit(X[positive_mask], amount_target[positive_mask])
            return model

        n_features = int(X.shape[1])
        model.coef_ = np.zeros(n_features, dtype=np.float64)
        model.intercept_ = np.float64(0.0)
        model.n_features_in_ = n_features
        return model

    # ------------------------------------------------------------------
    # Training targets
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_training_targets(
        donations: pd.DataFrame,
        as_of_date: pd.Timestamp,
        donor_ids: List,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Return the probability and amount targets aligned to ``donor_ids``.

        The probability target equals ``1`` for donors who made at least
        one donation in the half-open window
        ``(as_of_date, as_of_date + 30 days]`` and ``0`` otherwise. The
        amount target equals the sum of ``donation_amount`` across that
        donor's donations inside the same window (``0.0`` for donors
        with no future gift).
        """
        window_upper = as_of_date + pd.Timedelta(days=_FUTURE_WINDOW_DAYS)
        future_mask = (
            (donations["date"] > as_of_date) & (donations["date"] <= window_upper)
        )
        future = donations.loc[future_mask]

        donor_index = pd.Index(donor_ids, name="donor_id")
        amounts = (
            future.groupby("donor_id")["donation_amount"]
            .sum()
            .reindex(donor_index, fill_value=0.0)
        )
        amount_target = amounts.to_numpy(dtype=float)
        prob_target = (amount_target > 0.0).astype(int)
        return prob_target, amount_target

    # ------------------------------------------------------------------
    # Saturation
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_saturation_scores(
        donations: pd.DataFrame,
        as_of_date: pd.Timestamp,
        donor_ids: List,
    ) -> np.ndarray:
        """Return the saturation score for each donor aligned to ``donor_ids``.

        For each donor present in ``donor_ids`` the score follows the
        rules in section 6 of the prompt:

        * ``recent_count`` counts donations in the half-open window
          ``(as_of_date - 90 days, as_of_date]``.
        * ``mean_inter_donation_days`` is the arithmetic mean of
          consecutive day gaps across the donor's full history up to
          and including ``as_of_date``.
        * When the donor has exactly one historical donation, or
          ``mean_inter_donation_days`` collapses to zero because all
          donations share a single date, the score falls back to
          ``recent_count``.
        * Otherwise the score equals ``recent_count / (90 /
          mean_inter_donation_days)``.
        """
        window_start = as_of_date - pd.Timedelta(days=_RECENT_WINDOW_DAYS)
        donor_index = pd.Index(donor_ids, name="donor_id")

        historical_mask = (
            donations["donor_id"].isin(donor_ids)
            & (donations["date"] <= as_of_date)
        )
        historical = (
            donations.loc[historical_mask, ["donor_id", "date"]]
            .sort_values(["donor_id", "date"])
        )

        frequency = (
            historical.groupby("donor_id").size().reindex(donor_index, fill_value=0)
        )

        recent_mask = (
            (historical["date"] > window_start) & (historical["date"] <= as_of_date)
        )
        recent_count = (
            historical.loc[recent_mask]
            .groupby("donor_id")
            .size()
            .reindex(donor_index, fill_value=0)
            .astype("float64")
        )

        gaps_days = historical.groupby("donor_id")["date"].diff().dt.days
        mean_inter_days = (
            gaps_days.groupby(historical["donor_id"])
            .mean()
            .reindex(donor_index)
        )

        scores = recent_count.astype("float64").copy()
        use_formula = (frequency >= 2) & (mean_inter_days > 0)
        expected_count = _RECENT_WINDOW_DAYS / mean_inter_days.loc[use_formula]
        scores.loc[use_formula] = recent_count.loc[use_formula] / expected_count

        return scores.to_numpy(dtype="float64")
