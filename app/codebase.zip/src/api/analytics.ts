import { Router, Request, Response } from 'express';
import { db, getTodayDate } from '../database/db';

const router = Router();

// GET /api/analytics/trips
router.get('/analytics/trips', (req: Request, res: Response) => {
  const today = getTodayDate();

  const query = `
    SELECT 
      t.activityType,
      SUM(b.groupSize) as attendance,
      SUM(t.price * b.groupSize) as revenue
    FROM trips t
    LEFT JOIN bookings b ON t.id = b.tripId AND b.confirmed = 1
    WHERE t.date < ?
    GROUP BY t.activityType
  `;

  db.all(query, [today], (err, rows: any[]) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
      return;
    }

    const analytics = rows.map(row => ({
      activityType: row.activityType,
      attendance: row.attendance || 0,
      revenue: row.revenue || 0
    }));

    res.json({ analytics });
  });
});

export default router;
