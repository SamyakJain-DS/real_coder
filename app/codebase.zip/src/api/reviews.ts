import { Router, Request, Response } from 'express';
import { db, getTodayDate } from '../database/db';

const router = Router();

// GET /api/reviews
router.get('/reviews', (req: Request, res: Response) => {
  const tripId = req.query.tripId;

  if (!tripId) {
    res.status(400).json({ error: 'tripId is required' });
    return;
  }

  db.all('SELECT * FROM reviews WHERE tripId = ?', [tripId], (err, rows: any[]) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
      return;
    }

    const reviews = rows.map(review => ({
      id: review.id,
      tripId: review.tripId,
      rating: review.rating,
      reviewText: review.reviewText
    }));

    res.json(reviews);
  });
});

// POST /api/reviews
router.post('/reviews', (req: Request, res: Response) => {
  const { tripId, rating, reviewText, email } = req.body;

  if (!tripId || !rating || !reviewText || !email) {
    res.status(400).json({ error: 'Missing required fields' });
    return;
  }

  // Check if trip is completed
  const today = getTodayDate();
  db.get('SELECT date FROM trips WHERE id = ?', [tripId], (err, row: any) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
      return;
    }

    if (!row) {
      res.status(400).json({ error: 'Trip not found' });
      return;
    }

    if (row.date >= today) {
      res.status(400).json({ error: 'Cannot review upcoming trips' });
      return;
    }

    // Check that the submitted email matches a confirmed booking for this trip
    db.get(
      'SELECT id FROM bookings WHERE tripId = ? AND email = ? AND confirmed = 1',
      [tripId, email],
      (err, booking: any) => {
        if (err) {
          res.status(500).json({ error: 'Database error' });
          return;
        }

        if (!booking) {
          res.status(400).json({ error: 'No confirmed booking found for this email and trip' });
          return;
        }

        // Create review
        db.run(
          'INSERT INTO reviews (tripId, rating, reviewText) VALUES (?, ?, ?)',
          [tripId, rating, reviewText],
          function(err) {
            if (err) {
              res.status(500).json({ error: 'Database error' });
              return;
            }

            res.status(201).json({ reviewId: this.lastID });
          }
        );
      }
    );
  });
});

export default router;
