import { Router, Request, Response } from 'express';
import { db, getTodayDate } from '../database/db';

const router = Router();

// GET /api/trips
router.get('/trips', (req: Request, res: Response) => {
  const today = getTodayDate();
  
  db.all('SELECT * FROM trips', (err, rows: any[]) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
      return;
    }

    const trips = rows.map(trip => ({
      id: trip.id,
      activityType: trip.activityType,
      date: trip.date,
      guideName: trip.guideName,
      difficulty: trip.difficulty,
      groupSizeLimit: trip.groupSizeLimit,
      price: trip.price,
      description: trip.description,
      status: trip.date >= today ? 'upcoming' : 'completed'
    }));

    res.json(trips);
  });
});

export default router;
