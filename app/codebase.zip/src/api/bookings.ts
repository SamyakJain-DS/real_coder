import { Router, Request, Response } from 'express';
import { db, getTodayDate } from '../database/db';

const router = Router();

// POST /api/bookings
router.post('/bookings', (req: Request, res: Response) => {
  const { tripId, customerName, email, groupSize, dietaryNotes, medicalNotes, waiverAcknowledged } = req.body;

  // Validate required fields
  if (!customerName || !email || !groupSize) {
    res.status(400).json({ error: 'Missing required fields' });
    return;
  }

  // Validate waiver acknowledgment
  if (waiverAcknowledged !== true) {
    res.status(400).json({ error: 'Waiver must be acknowledged' });
    return;
  }

  const today = getTodayDate();

  // Check if trip exists and is upcoming
  db.get('SELECT id, date, groupSizeLimit FROM trips WHERE id = ?', [tripId], (err, trip: any) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
      return;
    }

    if (!trip) {
      res.status(400).json({ error: 'Trip not found' });
      return;
    }

    if (trip.date < today) {
      res.status(400).json({ error: 'Cannot book completed trips' });
      return;
    }

    // Check capacity: sum of confirmed bookings + incoming groupSize must not exceed groupSizeLimit
    db.get(
      'SELECT COALESCE(SUM(groupSize), 0) as confirmedTotal FROM bookings WHERE tripId = ? AND confirmed = 1',
      [tripId],
      (err, row: any) => {
        if (err) {
          res.status(500).json({ error: 'Database error' });
          return;
        }

        if (row.confirmedTotal + groupSize > trip.groupSizeLimit) {
          res.status(400).json({ error: 'Booking exceeds trip capacity' });
          return;
        }

        // Create booking with pending status
        db.run(
          'INSERT INTO bookings (tripId, customerName, email, groupSize, dietaryNotes, medicalNotes, waiverAcknowledged, confirmed) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
          [tripId, customerName, email, groupSize, dietaryNotes || null, medicalNotes || null, 1, 0],
          function(err) {
            if (err) {
              res.status(500).json({ error: 'Database error' });
              return;
            }

            res.status(201).json({ bookingId: this.lastID });
          }
        );
      }
    );
  });
});

// GET /api/bookings/pending
router.get('/bookings/pending', (req: Request, res: Response) => {
  db.all('SELECT * FROM bookings WHERE confirmed = 0', (err, rows: any[]) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
      return;
    }

    const bookings = rows.map(booking => ({
      id: booking.id,
      tripId: booking.tripId,
      customerName: booking.customerName,
      email: booking.email,
      groupSize: booking.groupSize,
      dietaryNotes: booking.dietaryNotes,
      medicalNotes: booking.medicalNotes
    }));

    res.json(bookings);
  });
});

// GET /api/bookings/confirmed
router.get('/bookings/confirmed', (req: Request, res: Response) => {
  db.all('SELECT * FROM bookings WHERE confirmed = 1', (err, rows: any[]) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
      return;
    }

    const bookings = rows.map(booking => ({
      id: booking.id,
      tripId: booking.tripId,
      customerName: booking.customerName,
      email: booking.email,
      groupSize: booking.groupSize,
      dietaryNotes: booking.dietaryNotes,
      medicalNotes: booking.medicalNotes
    }));

    res.json(bookings);
  });
});

// PUT /api/bookings/:id/confirm
router.put('/bookings/:id/confirm', (req: Request, res: Response) => {
  const bookingId = req.params.id;

  // Fetch the booking to get tripId and groupSize
  db.get('SELECT tripId, groupSize FROM bookings WHERE id = ? AND confirmed = 0', [bookingId], (err, booking: any) => {
    if (err) {
      res.status(500).json({ error: 'Database error' });
      return;
    }

    if (!booking) {
      res.status(400).json({ error: 'Booking not found or already confirmed' });
      return;
    }

    // Get the trip's groupSizeLimit
    db.get('SELECT groupSizeLimit FROM trips WHERE id = ?', [booking.tripId], (err, trip: any) => {
      if (err) {
        res.status(500).json({ error: 'Database error' });
        return;
      }

      if (!trip) {
        res.status(400).json({ error: 'Trip not found' });
        return;
      }

      // Sum existing confirmed bookings for this trip
      db.get(
        'SELECT COALESCE(SUM(groupSize), 0) as confirmedTotal FROM bookings WHERE tripId = ? AND confirmed = 1',
        [booking.tripId],
        (err, row: any) => {
          if (err) {
            res.status(500).json({ error: 'Database error' });
            return;
          }

          if (row.confirmedTotal + booking.groupSize > trip.groupSizeLimit) {
            res.status(400).json({ error: 'Confirming this booking would exceed trip capacity' });
            return;
          }

          db.run('UPDATE bookings SET confirmed = 1 WHERE id = ?', [bookingId], function(err) {
            if (err) {
              res.status(500).json({ error: 'Database error' });
              return;
            }

            res.json({ success: true });
          });
        }
      );
    });
  });
});

export default router;
