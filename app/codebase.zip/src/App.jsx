import { useState, useMemo } from 'react'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import './App.css'

/* ─── Constants ────────────────────────────────────────────────────────────── */
const STORAGE_KEY = 'reading-journal'

/* ─── Utilities ─────────────────────────────────────────────────────────────── */
let _seq = 0
function generateId() {
  _seq += 1
  return `${Date.now().toString(36)}-${_seq}-${Math.random().toString(36).slice(2)}`
}

function loadLibrary() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return { books: [], activity: [] }
    const parsed = JSON.parse(raw)
    return {
      books: Array.isArray(parsed.books) ? parsed.books : [],
      activity: Array.isArray(parsed.activity) ? parsed.activity : [],
    }
  } catch {
    return { books: [], activity: [] }
  }
}

function saveLibrary(books, activity) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ books, activity }))
}

/**
 * Given an ISO timestamp, return the UTC Monday of that week as YYYY-MM-DD.
 * Week starts Monday 00:00:00 UTC per requirements.
 */
function getWeekMondayUTC(isoTimestamp) {
  const d = new Date(isoTimestamp)
  const dow = d.getUTCDay() // 0=Sun, 1=Mon … 6=Sat
  const diffToMon = dow === 0 ? 6 : dow - 1
  const monday = new Date(
    Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - diffToMon)
  )
  const y = monday.getUTCFullYear()
  const m = String(monday.getUTCMonth() + 1).padStart(2, '0')
  const day = String(monday.getUTCDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

/** Returns true if s (after trim) is a base-10 positive integer string. */
function isPositiveIntStr(s) {
  const t = s.trim()
  if (!/^\d+$/.test(t)) return false
  return parseInt(t, 10) > 0
}

/** Returns true if s (after trim) is an integer in [lo, hi]. */
function isIntInRange(s, lo, hi) {
  const t = s.trim()
  if (!/^-?\d+$/.test(t)) return false
  const n = parseInt(t, 10)
  return n >= lo && n <= hi
}

/* ─── App ────────────────────────────────────────────────────────────────────── */
export default function App() {
  /* Library state (books + activity) backed by localStorage */
  const [lib, setLib] = useState(() => loadLibrary())
  const { books, activity } = lib

  function commit(newBooks, newActivity) {
    saveLibrary(newBooks, newActivity)
    setLib({ books: newBooks, activity: newActivity })
  }

  /* ── Add-book form state ── */
  const [addTitle, setAddTitle] = useState('')
  const [addAuthor, setAddAuthor] = useState('')
  const [addTotalPages, setAddTotalPages] = useState('')
  const [addErrs, setAddErrs] = useState({ title: '', author: '', totalPages: '' })

  /* ── Per-book update-progress state ── */
  const [pgInputs, setPgInputs] = useState({})  // { [bookId]: string }
  const [pgErrors, setPgErrors] = useState({})   // { [bookId]: string }

  /* ── Per-book finish-form state ── */
  const [frRatings, setFrRatings] = useState({}) // { [bookId]: string }
  const [frReviews, setFrReviews] = useState({}) // { [bookId]: string }
  const [frErrors, setFrErrors] = useState({})   // { [bookId]: { rating, review } }

  /* ── Filter / search state ── */
  const [searchTerm, setSearchTerm] = useState('')
  const [fAuthor, setFAuthor] = useState('')
  const [fRating, setFRating] = useState('')
  const [fYear, setFYear] = useState('')

  /* ── Reset confirmation state ── */
  const [resetPending, setResetPending] = useState(false)

  /* ─────────────────────────────────────────────────────────────────────────── */
  /* Handlers                                                                     */
  /* ─────────────────────────────────────────────────────────────────────────── */

  function onAddBook(e) {
    e.preventDefault()
    const errs = { title: '', author: '', totalPages: '' }
    if (!addTitle.trim()) errs.title = 'Title is required.'
    if (!addAuthor.trim()) errs.author = 'Author is required.'
    if (!isPositiveIntStr(addTotalPages)) errs.totalPages = 'Must be a positive integer.'
    setAddErrs(errs)
    if (errs.title || errs.author || errs.totalPages) return

    const now = new Date().toISOString()
    const book = {
      id: generateId(),
      title: addTitle.trim(),
      author: addAuthor.trim(),
      totalPages: parseInt(addTotalPages.trim(), 10),
      currentPage: 0,
      status: 'currently_reading',
      rating: null,
      review: null,
      createdAt: now,
      finishedAt: null,
    }
    commit([...books, book], activity)
    setAddTitle('')
    setAddAuthor('')
    setAddTotalPages('')
    setAddErrs({ title: '', author: '', totalPages: '' })
  }

  function onUpdateProgress(bookId) {
    const book = books.find((b) => b.id === bookId)
    if (!book) return
    const val = pgInputs[bookId] ?? ''
    if (!isIntInRange(val, 0, book.totalPages)) {
      setPgErrors((prev) => ({
        ...prev,
        [bookId]: `Enter a whole number from 0 to ${book.totalPages}.`,
      }))
      return
    }
    setPgErrors((prev) => ({ ...prev, [bookId]: '' }))
    const newPage = parseInt(val.trim(), 10)
    const now = new Date().toISOString()
    let newActivity = activity
    if (newPage > book.currentPage) {
      newActivity = [
        ...activity,
        {
          id: generateId(),
          bookId,
          timestamp: now,
          pagesAdded: newPage - book.currentPage,
        },
      ]
    }
    const newBooks = books.map((b) =>
      b.id === bookId ? { ...b, currentPage: newPage } : b
    )
    commit(newBooks, newActivity)
  }

  function onFinishBook(bookId) {
    const book = books.find((b) => b.id === bookId)
    if (!book) return
    const rVal = frRatings[bookId] ?? ''
    const rvVal = frReviews[bookId] ?? ''
    const errs = { rating: '', review: '' }
    if (!isIntInRange(rVal, 1, 5)) errs.rating = 'Rating must be an integer from 1 to 5.'
    if (!rvVal.trim()) errs.review = 'Review cannot be empty.'
    setFrErrors((prev) => ({ ...prev, [bookId]: errs }))
    if (errs.rating || errs.review) return

    const now = new Date().toISOString()
    const ratingNum = parseInt(rVal.trim(), 10)
    let newActivity = activity
    if (book.totalPages > book.currentPage) {
      newActivity = [
        ...activity,
        {
          id: generateId(),
          bookId,
          timestamp: now,
          pagesAdded: book.totalPages - book.currentPage,
        },
      ]
    }
    const newBooks = books.map((b) =>
      b.id === bookId
        ? {
            ...b,
            status: 'finished',
            currentPage: b.totalPages,
            rating: ratingNum,
            review: rvVal.trim(),
            finishedAt: now,
          }
        : b
    )
    commit(newBooks, newActivity)
  }

  function onReturnToReading(bookId) {
    const newBooks = books.map((b) =>
      b.id === bookId
        ? { ...b, status: 'currently_reading', rating: null, review: null, finishedAt: null }
        : b
    )
    commit(newBooks, activity)
  }

  function onReset() {
    commit([], [])
    setResetPending(false)
  }

  /* ─────────────────────────────────────────────────────────────────────────── */
  /* Derived data                                                                 */
  /* ─────────────────────────────────────────────────────────────────────────── */

  const allAuthors = useMemo(
    () => [...new Set(books.map((b) => b.author))].sort(),
    [books]
  )

  const allFinishedYears = useMemo(
    () =>
      [
        ...new Set(
          books
            .filter((b) => b.status === 'finished' && b.finishedAt)
            .map((b) => String(new Date(b.finishedAt).getFullYear()))
        ),
      ].sort(),
    [books]
  )

  /* Currently-reading shelf filtered by search + author filter */
  const crBooks = useMemo(
    () =>
      books.filter((b) => {
        if (b.status !== 'currently_reading') return false
        if (
          searchTerm &&
          !b.author.toLowerCase().includes(searchTerm.toLowerCase())
        )
          return false
        if (fAuthor && b.author !== fAuthor) return false
        return true
      }),
    [books, searchTerm, fAuthor]
  )

  /* Finished shelf filtered by all active filters */
  const fnBooks = useMemo(
    () =>
      books.filter((b) => {
        if (b.status !== 'finished') return false
        if (
          searchTerm &&
          !b.author.toLowerCase().includes(searchTerm.toLowerCase())
        )
          return false
        if (fAuthor && b.author !== fAuthor) return false
        if (fRating && b.rating !== parseInt(fRating, 10)) return false
        if (fYear) {
          if (!b.finishedAt) return false
          if (String(new Date(b.finishedAt).getFullYear()) !== fYear) return false
        }
        return true
      }),
    [books, searchTerm, fAuthor, fRating, fYear]
  )

  /* Stats */
  const thisYear = new Date().getFullYear()

  const finishedThisYear = useMemo(
    () =>
      books.filter(
        (b) =>
          b.status === 'finished' &&
          b.finishedAt &&
          new Date(b.finishedAt).getFullYear() === thisYear
      ),
    [books, thisYear]
  )

  const statBooksThisYear = finishedThisYear.length

  const statPagesThisYear = useMemo(
    () => finishedThisYear.reduce((s, b) => s + b.totalPages, 0),
    [finishedThisYear]
  )

  const statPagesAll = useMemo(
    () =>
      books
        .filter((b) => b.status === 'finished')
        .reduce((s, b) => s + b.totalPages, 0),
    [books]
  )

  const statAvgLengthThisYear =
    finishedThisYear.length > 0
      ? Math.round(statPagesThisYear / finishedThisYear.length)
      : 0

  /* Pages-per-week chart data */
  const ppwData = useMemo(() => {
    const map = new Map()
    for (const e of activity) {
      const key = getWeekMondayUTC(e.timestamp)
      map.set(key, (map.get(key) || 0) + e.pagesAdded)
    }
    return [...map.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([week, pages]) => ({ week, pages }))
  }, [activity])

  /* Progress percent helper */
  function pct(book) {
    if (book.totalPages === 0) return 0
    return Math.round((book.currentPage / book.totalPages) * 100)
  }

  /* ─────────────────────────────────────────────────────────────────────────── */
  /* Render                                                                       */
  /* ─────────────────────────────────────────────────────────────────────────── */
  return (
    <div className="app">
      <header className="app-header">
        <h1 className="app-title">📚 Reading Journal</h1>
      </header>

      {/* ── Add-Book Form ─────────────────────────────────────────────────────── */}
      <section className="card">
        <h2>Add a Book</h2>
        <form data-testid="add-book-form" onSubmit={onAddBook} noValidate>
          <div className="field">
            <label htmlFor="input-add-title">Title</label>
            <input
              id="input-add-title"
              data-testid="field-title"
              type="text"
              value={addTitle}
              onChange={(e) => setAddTitle(e.target.value)}
              placeholder="Book title"
              autoComplete="off"
            />
            {addErrs.title && (
              <span className="err" role="alert">
                {addErrs.title}
              </span>
            )}
          </div>

          <div className="field">
            <label htmlFor="input-add-author">Author</label>
            <input
              id="input-add-author"
              data-testid="field-author"
              type="text"
              value={addAuthor}
              onChange={(e) => setAddAuthor(e.target.value)}
              placeholder="Author name"
              autoComplete="off"
            />
            {addErrs.author && (
              <span className="err" role="alert">
                {addErrs.author}
              </span>
            )}
          </div>

          <div className="field">
            <label htmlFor="input-add-pages">Total Pages</label>
            <input
              id="input-add-pages"
              data-testid="field-total-pages"
              type="text"
              value={addTotalPages}
              onChange={(e) => setAddTotalPages(e.target.value)}
              placeholder="e.g. 320"
              autoComplete="off"
            />
            {addErrs.totalPages && (
              <span className="err" role="alert">
                {addErrs.totalPages}
              </span>
            )}
          </div>

          <button type="submit" data-testid="submit-add-book" className="btn btn-primary">
            Add Book
          </button>
        </form>
      </section>

      {/* ── Search & Filter ───────────────────────────────────────────────────── */}
      <section className="card">
        <h2>Search &amp; Filter</h2>
        <div className="filters">
          <div className="filter-item">
            <label htmlFor="search-input-el" className="sr-only">
              Search by author
            </label>
            <input
              id="search-input-el"
              type="text"
              data-testid="search-input"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by author…"
            />
          </div>

          <div className="filter-item">
            <label htmlFor="filter-author-el" className="sr-only">
              Filter by author
            </label>
            <select
              id="filter-author-el"
              data-testid="filter-author"
              value={fAuthor}
              onChange={(e) => setFAuthor(e.target.value)}
              aria-label="Filter by author"
            >
              <option value="">All Authors</option>
              {allAuthors.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>
          </div>

          <div className="filter-item">
            <label htmlFor="filter-rating-el" className="sr-only">
              Filter by rating
            </label>
            <select
              id="filter-rating-el"
              data-testid="filter-rating"
              value={fRating}
              onChange={(e) => setFRating(e.target.value)}
              aria-label="Filter by rating (finished shelf)"
            >
              <option value="">All Ratings</option>
              {[1, 2, 3, 4, 5].map((r) => (
                <option key={r} value={String(r)}>
                  {r} ★
                </option>
              ))}
            </select>
          </div>

          <div className="filter-item">
            <label htmlFor="filter-year-el" className="sr-only">
              Filter by year finished
            </label>
            <select
              id="filter-year-el"
              data-testid="filter-year"
              value={fYear}
              onChange={(e) => setFYear(e.target.value)}
              aria-label="Filter by year finished (finished shelf)"
            >
              <option value="">All Years</option>
              {allFinishedYears.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {/* ── Currently Reading Shelf ───────────────────────────────────────────── */}
      <section data-testid="shelf-currently-reading" className="card shelf">
        <h2>Currently Reading ({crBooks.length})</h2>

        {crBooks.length === 0 && (
          <p className="empty-msg">No books here yet.</p>
        )}

        {crBooks.map((book) => (
          <article
            key={book.id}
            data-testid={`book-card-${book.id}`}
            className="book-card"
          >
            {/* Book meta */}
            <div className="book-meta">
              <h3 className="book-title">{book.title}</h3>
              <p className="book-author">by {book.author}</p>
              <p className="page-count">
                {book.currentPage} / {book.totalPages} pages
              </p>
            </div>

            {/* Progress bar */}
            <div
              data-testid={`progress-bar-${book.id}`}
              className="prog-bar"
              role="progressbar"
              aria-valuenow={pct(book)}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label={`Reading progress for ${book.title}`}
            >
              <div
                className="prog-fill"
                style={{ width: `${pct(book)}%` }}
              />
            </div>
            <p className="prog-pct-line">
              <span data-testid={`progress-percent-${book.id}`}>
                {pct(book)}%
              </span>{' '}
              complete
            </p>

            {/* Update-progress controls */}
            <div className="prog-ctrl">
              <input
                type="text"
                data-testid={`update-progress-input-${book.id}`}
                value={pgInputs[book.id] ?? ''}
                onChange={(e) =>
                  setPgInputs((prev) => ({ ...prev, [book.id]: e.target.value }))
                }
                placeholder={`0–${book.totalPages}`}
                className="input-narrow"
                aria-label={`Set current page for ${book.title}`}
              />
              <button
                type="button"
                data-testid={`update-progress-submit-${book.id}`}
                className="btn btn-sm btn-outline"
                onClick={() => onUpdateProgress(book.id)}
              >
                Update
              </button>
              {pgErrors[book.id] && (
                <span className="err" role="alert">
                  {pgErrors[book.id]}
                </span>
              )}
            </div>

            {/* Finish section */}
            <div className="finish-section">
              <button
                type="button"
                data-testid={`mark-finished-${book.id}`}
                className="btn btn-accent"
                onClick={() => {
                  const el = document.getElementById(`finish-rating-input-${book.id}`)
                  if (el) el.focus()
                }}
              >
                ✓ Mark as Finished
              </button>

              <div className="finish-form">
                <div className="field">
                  <label htmlFor={`finish-rating-input-${book.id}`}>
                    Rating (1–5)
                  </label>
                  <input
                    id={`finish-rating-input-${book.id}`}
                    type="text"
                    data-testid={`finish-rating-${book.id}`}
                    value={frRatings[book.id] ?? ''}
                    onChange={(e) =>
                      setFrRatings((prev) => ({
                        ...prev,
                        [book.id]: e.target.value,
                      }))
                    }
                    placeholder="1–5"
                    className="input-narrow"
                    aria-label={`Rating for ${book.title}`}
                  />
                  {frErrors[book.id]?.rating && (
                    <span className="err" role="alert">
                      {frErrors[book.id].rating}
                    </span>
                  )}
                </div>

                <div className="field">
                  <label htmlFor={`finish-review-input-${book.id}`}>
                    Review
                  </label>
                  <textarea
                    id={`finish-review-input-${book.id}`}
                    data-testid={`finish-review-${book.id}`}
                    value={frReviews[book.id] ?? ''}
                    onChange={(e) =>
                      setFrReviews((prev) => ({
                        ...prev,
                        [book.id]: e.target.value,
                      }))
                    }
                    placeholder="Write your thoughts…"
                    rows={3}
                    aria-label={`Review for ${book.title}`}
                  />
                  {frErrors[book.id]?.review && (
                    <span className="err" role="alert">
                      {frErrors[book.id].review}
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  data-testid={`finish-submit-${book.id}`}
                  className="btn btn-accent"
                  onClick={() => onFinishBook(book.id)}
                >
                  Submit &amp; Finish
                </button>
              </div>
            </div>
          </article>
        ))}
      </section>

      {/* ── Finished Shelf ────────────────────────────────────────────────────── */}
      <section data-testid="shelf-finished" className="card shelf">
        <h2>Finished ({fnBooks.length})</h2>

        {fnBooks.length === 0 && (
          <p className="empty-msg">No finished books yet.</p>
        )}

        {fnBooks.map((book) => (
          <article
            key={book.id}
            data-testid={`book-card-${book.id}`}
            className="book-card book-card-finished"
          >
            <div className="book-meta">
              <h3 className="book-title">{book.title}</h3>
              <p className="book-author">by {book.author}</p>
              <p className="page-count">{book.totalPages} pages</p>
            </div>

            {book.rating != null && (
              <p className="book-rating" aria-label={`Rating: ${book.rating} out of 5`}>
                {'★'.repeat(book.rating)}
                {'☆'.repeat(5 - book.rating)}&nbsp;
                <span className="rating-num">({book.rating}/5)</span>
              </p>
            )}

            {book.review && (
              <p className="book-review">&ldquo;{book.review}&rdquo;</p>
            )}

            {book.finishedAt && (
              <p className="finished-date">
                Finished: {new Date(book.finishedAt).toLocaleDateString()}
              </p>
            )}

            <button
              type="button"
              data-testid={`return-to-reading-${book.id}`}
              className="btn btn-secondary"
              onClick={() => onReturnToReading(book.id)}
            >
              ↩ Return to Reading
            </button>
          </article>
        ))}
      </section>

      {/* ── Stats Dashboard ───────────────────────────────────────────────────── */}
      <section className="card">
        <h2>Stats</h2>

        <div className="stats-grid">
          <div className="stat-box">
            <div
              className="stat-number"
              data-testid="stats-books-finished-this-year"
            >
              {statBooksThisYear}
            </div>
            <div className="stat-label">Books finished this year</div>
          </div>

          <div className="stat-box">
            <div
              className="stat-number"
              data-testid="stats-total-pages-this-year"
            >
              {statPagesThisYear}
            </div>
            <div className="stat-label">Pages read this year</div>
          </div>

          <div className="stat-box">
            <div
              className="stat-number"
              data-testid="stats-total-pages-all"
            >
              {statPagesAll}
            </div>
            <div className="stat-label">Total pages (all finished)</div>
          </div>

          <div className="stat-box">
            <div
              className="stat-number"
              data-testid="stats-average-length-this-year"
            >
              {statAvgLengthThisYear}
            </div>
            <div className="stat-label">Avg pages/book this year</div>
          </div>
        </div>

        <div data-testid="stats-pages-per-week-chart" className="chart-wrap">
          <h3 className="chart-title">Pages per Week</h3>
          {ppwData.length === 0 ? (
            <p className="empty-msg chart-empty">
              Start reading to see your weekly progress here.
            </p>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <LineChart
                data={ppwData}
                margin={{ top: 8, right: 16, bottom: 60, left: 10 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis
                  dataKey="week"
                  angle={-45}
                  textAnchor="end"
                  tick={{ fontSize: 11, fill: '#718096' }}
                  interval="preserveStartEnd"
                />
                <YAxis tick={{ fontSize: 11, fill: '#718096' }} width={40} />
                <Tooltip
                  contentStyle={{
                    background: '#fff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '6px',
                    fontSize: '0.85rem',
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="pages"
                  stroke="#4f46e5"
                  strokeWidth={2}
                  dot={{ r: 3, fill: '#4f46e5' }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>

      {/* ── Reset ─────────────────────────────────────────────────────────────── */}
      <section className="card reset-card">
        <button
          type="button"
          data-testid="reset-library"
          className="btn btn-danger"
          onClick={() => setResetPending(true)}
        >
          Reset All Data
        </button>

        {resetPending && (
          <div className="reset-confirm-box">
            <p className="reset-warning">
              This will permanently delete all books and reading history.
            </p>
            <div className="reset-actions">
              <button
                type="button"
                data-testid="reset-confirm"
                className="btn btn-danger"
                onClick={onReset}
              >
                Yes, Delete Everything
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setResetPending(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  )
}
