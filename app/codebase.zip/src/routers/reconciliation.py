import uuid
from datetime import date

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional

from src.database import get_connection
from src.models import RiskAdjustmentReconciliation

router = APIRouter()


class ReconciliationCreate(BaseModel):
    insurer_id: str
    plan_year: int
    risk_adjustment_transfer_amount: float
    notes: Optional[str] = None


def _row_to_reconciliation(row) -> dict:
    return RiskAdjustmentReconciliation(
        reconciliation_id=row["reconciliation_id"],
        insurer_id=row["insurer_id"],
        plan_year=row["plan_year"],
        risk_adjustment_transfer_amount=row["risk_adjustment_transfer_amount"],
        cciio_submission_status=row["cciio_submission_status"],
        submission_date=row["submission_date"],
        notes=row["notes"],
    ).model_dump()


@router.post("/api/reconciliation", status_code=201)
def create_reconciliation(payload: ReconciliationCreate):
    conn = get_connection()
    try:
        insurer = conn.execute(
            "SELECT insurer_id FROM insurers WHERE insurer_id = ?", (payload.insurer_id,)
        ).fetchone()
        if insurer is None:
            raise HTTPException(status_code=404, detail="Insurer not found")

        reconciliation_id = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO risk_adjustment_reconciliation (reconciliation_id, insurer_id, plan_year, "
            "risk_adjustment_transfer_amount, cciio_submission_status, submission_date, notes) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (reconciliation_id, payload.insurer_id, payload.plan_year,
             payload.risk_adjustment_transfer_amount, "pending", None, payload.notes),
        )
        conn.commit()

        row = conn.execute(
            "SELECT * FROM risk_adjustment_reconciliation WHERE reconciliation_id = ?",
            (reconciliation_id,),
        ).fetchone()
        return _row_to_reconciliation(row)
    finally:
        conn.close()


@router.post("/api/reconciliation/{reconciliation_id}/submit")
def submit_reconciliation(reconciliation_id: str):
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM risk_adjustment_reconciliation WHERE reconciliation_id = ?",
            (reconciliation_id,),
        ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Reconciliation record not found")

        if row["cciio_submission_status"] != "pending":
            raise HTTPException(status_code=400, detail="Only records with 'pending' status can be submitted")

        submission_date = date.today().isoformat()
        conn.execute(
            "UPDATE risk_adjustment_reconciliation SET cciio_submission_status = 'submitted', "
            "submission_date = ? WHERE reconciliation_id = ?",
            (submission_date, reconciliation_id),
        )
        conn.commit()

        row = conn.execute(
            "SELECT * FROM risk_adjustment_reconciliation WHERE reconciliation_id = ?",
            (reconciliation_id,),
        ).fetchone()
        return _row_to_reconciliation(row)
    finally:
        conn.close()


@router.get("/api/reconciliation")
def list_reconciliation(insurer_id: Optional[str] = Query(None)):
    conn = get_connection()
    try:
        if insurer_id:
            rows = conn.execute(
                "SELECT * FROM risk_adjustment_reconciliation WHERE insurer_id = ?",
                (insurer_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM risk_adjustment_reconciliation").fetchall()
        return [_row_to_reconciliation(r) for r in rows]
    finally:
        conn.close()
