import uuid

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, field_validator
from typing import Optional

from src.database import get_connection
from src.models import Insurer

router = APIRouter()


class InsurerCreate(BaseModel):
    naic_code: str
    company_name: str
    company_type: str
    state_license_status: str
    domicile_state: str
    admitted_date: str

    @field_validator("company_type")
    @classmethod
    def _validate_company_type(cls, v: str) -> str:
        if v not in ("insurer", "mco"):
            raise ValueError("company_type must be 'insurer' or 'mco'")
        return v

    @field_validator("state_license_status")
    @classmethod
    def _validate_license_status(cls, v: str) -> str:
        if v not in ("active", "suspended", "revoked"):
            raise ValueError("state_license_status must be 'active', 'suspended', or 'revoked'")
        return v


class InsurerUpdate(BaseModel):
    naic_code: Optional[str] = None
    company_name: Optional[str] = None
    company_type: Optional[str] = None
    state_license_status: Optional[str] = None
    domicile_state: Optional[str] = None
    admitted_date: Optional[str] = None

    @field_validator("company_type")
    @classmethod
    def _validate_company_type(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v not in ("insurer", "mco"):
            raise ValueError("company_type must be 'insurer' or 'mco'")
        return v

    @field_validator("state_license_status")
    @classmethod
    def _validate_license_status(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v not in ("active", "suspended", "revoked"):
            raise ValueError("state_license_status must be 'active', 'suspended', or 'revoked'")
        return v


def _row_to_insurer(row) -> dict:
    return Insurer(
        insurer_id=row["insurer_id"],
        naic_code=row["naic_code"],
        company_name=row["company_name"],
        company_type=row["company_type"],
        state_license_status=row["state_license_status"],
        domicile_state=row["domicile_state"],
        admitted_date=row["admitted_date"],
    ).model_dump()


@router.post("/api/insurers", status_code=201)
def create_insurer(payload: InsurerCreate):
    insurer_id = str(uuid.uuid4())
    conn = get_connection()
    try:
        conn.execute(
            "INSERT INTO insurers (insurer_id, naic_code, company_name, company_type, "
            "state_license_status, domicile_state, admitted_date) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (insurer_id, payload.naic_code, payload.company_name, payload.company_type,
             payload.state_license_status, payload.domicile_state, payload.admitted_date),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM insurers WHERE insurer_id = ?", (insurer_id,)).fetchone()
        return _row_to_insurer(row)
    finally:
        conn.close()


@router.get("/api/insurers")
def list_insurers():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM insurers").fetchall()
        return [_row_to_insurer(r) for r in rows]
    finally:
        conn.close()


@router.get("/api/insurers/{insurer_id}")
def get_insurer(insurer_id: str):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM insurers WHERE insurer_id = ?", (insurer_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Insurer not found")
        return _row_to_insurer(row)
    finally:
        conn.close()


@router.put("/api/insurers/{insurer_id}")
def update_insurer(insurer_id: str, payload: InsurerUpdate):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM insurers WHERE insurer_id = ?", (insurer_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Insurer not found")

        updates = payload.model_dump(exclude_none=True)
        if updates:
            set_clause = ", ".join(f"{k} = ?" for k in updates)
            values = list(updates.values()) + [insurer_id]
            conn.execute(f"UPDATE insurers SET {set_clause} WHERE insurer_id = ?", values)
            conn.commit()

        row = conn.execute("SELECT * FROM insurers WHERE insurer_id = ?", (insurer_id,)).fetchone()
        return _row_to_insurer(row)
    finally:
        conn.close()


@router.delete("/api/insurers/{insurer_id}", status_code=204)
def delete_insurer(insurer_id: str):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM insurers WHERE insurer_id = ?", (insurer_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Insurer not found")
        conn.execute("DELETE FROM insurers WHERE insurer_id = ?", (insurer_id,))
        conn.commit()
        return None
    finally:
        conn.close()
