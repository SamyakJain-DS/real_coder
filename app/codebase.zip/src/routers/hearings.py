import uuid
from datetime import date, datetime

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from src.database import get_connection
from src.models import PublicHearing

router = APIRouter()


class HearingCreate(BaseModel):
    hearing_date: str
    location: str
    hearing_officer: str
    notice_published_date: str


@router.post("/api/filings/{filing_id}/hearings", status_code=201)
def create_hearing(filing_id: str, payload: HearingCreate):
    conn = get_connection()
    try:
        filing = conn.execute(
            "SELECT filing_id FROM rate_filings WHERE filing_id = ?", (filing_id,)
        ).fetchone()
        if filing is None:
            raise HTTPException(status_code=404, detail="Filing not found")

        # Compare calendar date components only; time-of-day of hearing_date is ignored
        hearing_date_only = datetime.fromisoformat(payload.hearing_date).date()
        notice_date_only = date.fromisoformat(payload.notice_published_date)
        delta = (hearing_date_only - notice_date_only).days
        if delta < 30:
            raise HTTPException(
                status_code=400,
                detail="Hearing date must be at least 30 days after notice published date",
            )

        hearing_id = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO public_hearings (hearing_id, filing_id, hearing_date, location, "
            "hearing_officer, status, notice_published_date) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (hearing_id, filing_id, payload.hearing_date, payload.location,
             payload.hearing_officer, "scheduled", payload.notice_published_date),
        )
        conn.commit()

        return PublicHearing(
            hearing_id=hearing_id,
            filing_id=filing_id,
            hearing_date=payload.hearing_date,
            location=payload.location,
            hearing_officer=payload.hearing_officer,
            status="scheduled",
            notice_published_date=payload.notice_published_date,
        ).model_dump()
    finally:
        conn.close()


@router.get("/api/filings/{filing_id}/hearings")
def list_hearings(filing_id: str):
    conn = get_connection()
    try:
        filing = conn.execute(
            "SELECT filing_id FROM rate_filings WHERE filing_id = ?", (filing_id,)
        ).fetchone()
        if filing is None:
            raise HTTPException(status_code=404, detail="Filing not found")

        rows = conn.execute(
            "SELECT * FROM public_hearings WHERE filing_id = ?", (filing_id,)
        ).fetchall()
        return [
            PublicHearing(
                hearing_id=r["hearing_id"],
                filing_id=r["filing_id"],
                hearing_date=r["hearing_date"],
                location=r["location"],
                hearing_officer=r["hearing_officer"],
                status=r["status"],
                notice_published_date=r["notice_published_date"],
            ).model_dump()
            for r in rows
        ]
    finally:
        conn.close()
