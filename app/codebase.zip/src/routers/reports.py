from fastapi import APIRouter, HTTPException

from src.database import get_connection

router = APIRouter()


@router.get("/api/reports/insurer/{insurer_id}")
def insurer_report(insurer_id: str):
    conn = get_connection()
    try:
        insurer = conn.execute(
            "SELECT * FROM insurers WHERE insurer_id = ?", (insurer_id,)
        ).fetchone()
        if insurer is None:
            raise HTTPException(status_code=404, detail="Insurer not found")

        rate_filings = conn.execute(
            "SELECT status, COUNT(*) as cnt FROM rate_filings WHERE insurer_id = ? GROUP BY status",
            (insurer_id,),
        ).fetchall()
        total_rate_filings = sum(r["cnt"] for r in rate_filings)
        rate_filing_status_counts = {r["status"]: r["cnt"] for r in rate_filings}

        form_filings = conn.execute(
            "SELECT status, COUNT(*) as cnt FROM form_filings WHERE insurer_id = ? GROUP BY status",
            (insurer_id,),
        ).fetchall()
        total_form_filings = sum(r["cnt"] for r in form_filings)
        form_filing_status_counts = {r["status"]: r["cnt"] for r in form_filings}

        exam_row = conn.execute(
            "SELECT COUNT(*) as cnt FROM market_conduct_exams WHERE insurer_id = ?",
            (insurer_id,),
        ).fetchone()
        total_exams = exam_row["cnt"]

        completed_exams = conn.execute(
            "SELECT AVG(claim_handling_score) as avg_ch, AVG(network_adequacy_score) as avg_na "
            "FROM market_conduct_exams WHERE insurer_id = ? AND status = 'completed'",
            (insurer_id,),
        ).fetchone()
        avg_claim_handling_score = completed_exams["avg_ch"]
        avg_network_adequacy_score = completed_exams["avg_na"]

        rec_rows = conn.execute(
            "SELECT COUNT(*) as cnt, COALESCE(SUM(risk_adjustment_transfer_amount), 0) as total "
            "FROM risk_adjustment_reconciliation WHERE insurer_id = ?",
            (insurer_id,),
        ).fetchone()
        total_reconciliation_records = rec_rows["cnt"]
        net_risk_adjustment_amount = rec_rows["total"]

        filing_ids = conn.execute(
            "SELECT filing_id FROM rate_filings WHERE insurer_id = ?", (insurer_id,)
        ).fetchall()

        total_public_comments = 0
        if filing_ids:
            placeholders = ",".join("?" for _ in filing_ids)
            ids = [r["filing_id"] for r in filing_ids]
            comment_row = conn.execute(
                f"SELECT COUNT(*) as cnt FROM public_comments WHERE filing_id IN ({placeholders})",
                ids,
            ).fetchone()
            total_public_comments = comment_row["cnt"]

        return {
            "insurer_id": insurer_id,
            "company_name": insurer["company_name"],
            "total_rate_filings": total_rate_filings,
            "rate_filing_status_counts": rate_filing_status_counts,
            "total_form_filings": total_form_filings,
            "form_filing_status_counts": form_filing_status_counts,
            "total_exams": total_exams,
            "avg_claim_handling_score": avg_claim_handling_score,
            "avg_network_adequacy_score": avg_network_adequacy_score,
            "total_reconciliation_records": total_reconciliation_records,
            "net_risk_adjustment_amount": net_risk_adjustment_amount,
            "total_public_comments": total_public_comments,
        }
    finally:
        conn.close()


@router.get("/api/reports/serff-summary")
def serff_summary():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT i.naic_code, i.company_name, rf.status, COUNT(*) as cnt
            FROM rate_filings rf
            JOIN insurers i ON rf.insurer_id = i.insurer_id
            GROUP BY rf.insurer_id, rf.status
        """).fetchall()

        insurer_map: dict = {}
        for r in rows:
            key = r["naic_code"]
            if key not in insurer_map:
                insurer_map[key] = {
                    "naic_code": r["naic_code"],
                    "company_name": r["company_name"],
                    "total_filings": 0,
                    "status_counts": {},
                }
            insurer_map[key]["total_filings"] += r["cnt"]
            insurer_map[key]["status_counts"][r["status"]] = r["cnt"]

        return list(insurer_map.values())
    finally:
        conn.close()
