import uuid
from datetime import date

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional

from src.database import get_connection
from src.models import RateFiling, Attachment, RateReview, PublicComment

router = APIRouter()


class AttachmentCreate(BaseModel):
    attachment_type: str
    filename: str
    uploaded_date: str


class FilingCreate(BaseModel):
    insurer_id: str
    serff_tracking_number: str
    filing_type: str
    product_type: str
    effective_date: str
    submission_date: str
    requested_rate_change_pct: float
    attachments: list[AttachmentCreate]


class ReviewInput(BaseModel):
    projected_incurred_claims: float
    projected_quality_improvement_expenses: float
    projected_earned_premium: float
    trend_factor: float
    administrative_expense_ratio: float


class CommentCreate(BaseModel):
    commenter_name: str
    commenter_email: str
    comment_text: str


def _get_attachments(conn, filing_id: str) -> list[dict]:
    rows = conn.execute("SELECT * FROM attachments WHERE filing_id = ?", (filing_id,)).fetchall()
    return [
        Attachment(
            attachment_id=r["attachment_id"],
            filing_id=r["filing_id"],
            attachment_type=r["attachment_type"],
            filename=r["filename"],
            uploaded_date=r["uploaded_date"],
        ).model_dump()
        for r in rows
    ]


def _row_to_filing(conn, row) -> dict:
    filing = RateFiling(
        filing_id=row["filing_id"],
        insurer_id=row["insurer_id"],
        serff_tracking_number=row["serff_tracking_number"],
        filing_type=row["filing_type"],
        product_type=row["product_type"],
        effective_date=row["effective_date"],
        status=row["status"],
        submission_date=row["submission_date"],
        requested_rate_change_pct=row["requested_rate_change_pct"],
        aca_unreasonable_flag=bool(row["aca_unreasonable_flag"]),
        attachments=[],
    ).model_dump()
    filing["attachments"] = _get_attachments(conn, row["filing_id"])
    return filing


@router.post("/api/filings", status_code=201)
def create_filing(payload: FilingCreate):
    conn = get_connection()
    try:
        insurer = conn.execute(
            "SELECT * FROM insurers WHERE insurer_id = ?", (payload.insurer_id,)
        ).fetchone()
        if insurer is None:
            raise HTTPException(status_code=404, detail="Insurer not found")

        if insurer["state_license_status"] != "active":
            raise HTTPException(status_code=400, detail="Insurer license is not active")

        att_types = [a.attachment_type for a in payload.attachments]
        if "actuarial_memorandum" not in att_types or "experience_exhibit" not in att_types:
            raise HTTPException(
                status_code=400,
                detail="Filing must include exactly one actuarial_memorandum and one experience_exhibit attachment",
            )
        if att_types.count("actuarial_memorandum") != 1 or att_types.count("experience_exhibit") != 1:
            raise HTTPException(
                status_code=400,
                detail="Filing must include exactly one actuarial_memorandum and one experience_exhibit attachment",
            )

        filing_id = str(uuid.uuid4())
        aca_unreasonable_flag = payload.requested_rate_change_pct >= 10.0
        try:
            conn.execute(
                "INSERT INTO rate_filings (filing_id, insurer_id, serff_tracking_number, filing_type, "
                "product_type, effective_date, status, submission_date, requested_rate_change_pct, "
                "aca_unreasonable_flag) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (filing_id, payload.insurer_id, payload.serff_tracking_number, payload.filing_type,
                 payload.product_type, payload.effective_date, "received", payload.submission_date,
                 payload.requested_rate_change_pct, int(aca_unreasonable_flag)),
            )
        except Exception as e:
            if "UNIQUE constraint failed" in str(e):
                raise HTTPException(status_code=400, detail="Duplicate SERFF tracking number")
            raise

        for att in payload.attachments:
            attachment_id = str(uuid.uuid4())
            conn.execute(
                "INSERT INTO attachments (attachment_id, filing_id, attachment_type, filename, uploaded_date) "
                "VALUES (?, ?, ?, ?, ?)",
                (attachment_id, filing_id, att.attachment_type, att.filename, att.uploaded_date),
            )

        conn.commit()
        row = conn.execute("SELECT * FROM rate_filings WHERE filing_id = ?", (filing_id,)).fetchone()
        return _row_to_filing(conn, row)
    finally:
        conn.close()


@router.get("/api/filings")
def list_filings(insurer_id: Optional[str] = Query(None)):
    conn = get_connection()
    try:
        if insurer_id:
            rows = conn.execute(
                "SELECT * FROM rate_filings WHERE insurer_id = ?", (insurer_id,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM rate_filings").fetchall()
        return [_row_to_filing(conn, r) for r in rows]
    finally:
        conn.close()


@router.get("/api/filings/{filing_id}")
def get_filing(filing_id: str):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM rate_filings WHERE filing_id = ?", (filing_id,)).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Filing not found")
        return _row_to_filing(conn, row)
    finally:
        conn.close()


@router.post("/api/filings/{filing_id}/review", status_code=201)
def perform_review(filing_id: str, payload: ReviewInput):
    conn = get_connection()
    try:
        filing_row = conn.execute(
            "SELECT * FROM rate_filings WHERE filing_id = ?", (filing_id,)
        ).fetchone()
        if filing_row is None:
            raise HTTPException(status_code=404, detail="Filing not found")

        product_type = filing_row["product_type"]
        target_mlr = 0.85 if product_type == "large_group" else 0.80

        projected_mlr = round(
            (payload.projected_incurred_claims * payload.trend_factor
             + payload.projected_quality_improvement_expenses)
            / payload.projected_earned_premium,
            4,
        )

        adequacy_result = "adequate" if projected_mlr >= target_mlr else "inadequate"
        admin_expense_flag = payload.administrative_expense_ratio > 0.20

        review_id = str(uuid.uuid4())
        review_date = date.today().isoformat()

        conn.execute(
            "INSERT INTO rate_reviews (review_id, filing_id, projected_mlr, target_mlr, "
            "trend_factor_used, admin_expense_ratio, admin_expense_flag, adequacy_result, review_date) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (review_id, filing_id, projected_mlr, target_mlr, payload.trend_factor,
             payload.administrative_expense_ratio, int(admin_expense_flag), adequacy_result, review_date),
        )

        conn.execute(
            "UPDATE rate_filings SET status = 'under_review' WHERE filing_id = ? AND status = 'received'",
            (filing_id,),
        )

        conn.commit()

        return RateReview(
            review_id=review_id,
            filing_id=filing_id,
            projected_mlr=projected_mlr,
            target_mlr=target_mlr,
            trend_factor_used=payload.trend_factor,
            admin_expense_ratio=payload.administrative_expense_ratio,
            admin_expense_flag=admin_expense_flag,
            adequacy_result=adequacy_result,
            review_date=review_date,
        ).model_dump()
    finally:
        conn.close()


@router.post("/api/filings/{filing_id}/comments", status_code=201)
def create_comment(filing_id: str, payload: CommentCreate):
    conn = get_connection()
    try:
        filing = conn.execute(
            "SELECT filing_id FROM rate_filings WHERE filing_id = ?", (filing_id,)
        ).fetchone()
        if filing is None:
            raise HTTPException(status_code=404, detail="Filing not found")

        comment_id = str(uuid.uuid4())
        submitted_date = date.today().isoformat()

        conn.execute(
            "INSERT INTO public_comments (comment_id, filing_id, commenter_name, commenter_email, "
            "comment_text, submitted_date) VALUES (?, ?, ?, ?, ?, ?)",
            (comment_id, filing_id, payload.commenter_name, payload.commenter_email,
             payload.comment_text, submitted_date),
        )
        conn.commit()

        return PublicComment(
            comment_id=comment_id,
            filing_id=filing_id,
            commenter_name=payload.commenter_name,
            commenter_email=payload.commenter_email,
            comment_text=payload.comment_text,
            submitted_date=submitted_date,
        ).model_dump()
    finally:
        conn.close()


@router.get("/api/filings/{filing_id}/comments")
def list_comments(filing_id: str):
    conn = get_connection()
    try:
        filing = conn.execute(
            "SELECT filing_id FROM rate_filings WHERE filing_id = ?", (filing_id,)
        ).fetchone()
        if filing is None:
            raise HTTPException(status_code=404, detail="Filing not found")

        rows = conn.execute(
            "SELECT * FROM public_comments WHERE filing_id = ?", (filing_id,)
        ).fetchall()
        return [
            PublicComment(
                comment_id=r["comment_id"],
                filing_id=r["filing_id"],
                commenter_name=r["commenter_name"],
                commenter_email=r["commenter_email"],
                comment_text=r["comment_text"],
                submitted_date=r["submitted_date"],
            ).model_dump()
            for r in rows
        ]
    finally:
        conn.close()
