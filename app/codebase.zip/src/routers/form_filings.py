import json
import uuid

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional

from src.database import get_connection
from src.models import FormFiling

router = APIRouter()

REQUIRED_BENEFITS = [
    "mental_health_parity",
    "maternity_coverage",
    "preventive_care",
    "prescription_drug",
    "emergency_services",
    "pediatric_dental",
    "pediatric_vision",
    "rehabilitative_services",
    "laboratory_services",
    "chronic_disease_management",
]


class FormFilingCreate(BaseModel):
    insurer_id: str
    form_type: str
    product_type: str
    submission_date: str
    mandated_benefits_checklist: dict


def _row_to_form_filing(row) -> dict:
    checklist = row["mandated_benefits_checklist"]
    if isinstance(checklist, str):
        checklist = json.loads(checklist)
    return FormFiling(
        form_filing_id=row["form_filing_id"],
        insurer_id=row["insurer_id"],
        form_type=row["form_type"],
        product_type=row["product_type"],
        submission_date=row["submission_date"],
        status=row["status"],
        mandated_benefits_checklist=checklist,
    ).model_dump()


@router.post("/api/form-filings", status_code=201)
def create_form_filing(payload: FormFilingCreate):
    conn = get_connection()
    try:
        insurer = conn.execute(
            "SELECT insurer_id, state_license_status FROM insurers WHERE insurer_id = ?",
            (payload.insurer_id,),
        ).fetchone()
        if insurer is None:
            raise HTTPException(status_code=404, detail="Insurer not found")
        if insurer["state_license_status"] != "active":
            raise HTTPException(status_code=400, detail="Insurer license is not active")

        form_filing_id = str(uuid.uuid4())
        checklist_json = json.dumps(payload.mandated_benefits_checklist)

        conn.execute(
            "INSERT INTO form_filings (form_filing_id, insurer_id, form_type, product_type, "
            "submission_date, status, mandated_benefits_checklist) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (form_filing_id, payload.insurer_id, payload.form_type, payload.product_type,
             payload.submission_date, "received", checklist_json),
        )
        conn.commit()

        row = conn.execute(
            "SELECT * FROM form_filings WHERE form_filing_id = ?", (form_filing_id,)
        ).fetchone()
        return _row_to_form_filing(row)
    finally:
        conn.close()


@router.post("/api/form-filings/{form_filing_id}/review")
def review_form_filing(form_filing_id: str):
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM form_filings WHERE form_filing_id = ?", (form_filing_id,)
        ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Form filing not found")

        checklist = row["mandated_benefits_checklist"]
        if isinstance(checklist, str):
            checklist = json.loads(checklist)

        missing_benefits = []
        for benefit in REQUIRED_BENEFITS:
            if benefit not in checklist or checklist[benefit] is not True:
                missing_benefits.append(benefit)

        if not missing_benefits:
            new_status = "approved"
        else:
            new_status = "rejected"

        conn.execute(
            "UPDATE form_filings SET status = ? WHERE form_filing_id = ?",
            (new_status, form_filing_id),
        )
        conn.commit()

        result = {"status": new_status}
        if missing_benefits:
            result["missing_benefits"] = missing_benefits
        return result
    finally:
        conn.close()


@router.get("/api/form-filings")
def list_form_filings(insurer_id: Optional[str] = Query(None)):
    conn = get_connection()
    try:
        if insurer_id:
            rows = conn.execute(
                "SELECT * FROM form_filings WHERE insurer_id = ?", (insurer_id,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM form_filings").fetchall()
        return [_row_to_form_filing(r) for r in rows]
    finally:
        conn.close()
