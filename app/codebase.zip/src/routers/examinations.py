import uuid

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional

from src.database import get_connection
from src.models import MarketConductExam

router = APIRouter()


class ExamCreate(BaseModel):
    insurer_id: str
    exam_type: str
    scheduled_date: str


class ExamComplete(BaseModel):
    claim_handling_score: float
    network_adequacy_score: float


def _row_to_exam(row) -> dict:
    return MarketConductExam(
        exam_id=row["exam_id"],
        insurer_id=row["insurer_id"],
        exam_type=row["exam_type"],
        scheduled_date=row["scheduled_date"],
        status=row["status"],
        claim_handling_score=row["claim_handling_score"],
        network_adequacy_score=row["network_adequacy_score"],
    ).model_dump()


@router.post("/api/examinations", status_code=201)
def create_examination(payload: ExamCreate):
    conn = get_connection()
    try:
        insurer = conn.execute(
            "SELECT insurer_id FROM insurers WHERE insurer_id = ?", (payload.insurer_id,)
        ).fetchone()
        if insurer is None:
            raise HTTPException(status_code=404, detail="Insurer not found")

        exam_id = str(uuid.uuid4())
        conn.execute(
            "INSERT INTO market_conduct_exams (exam_id, insurer_id, exam_type, scheduled_date, "
            "status, claim_handling_score, network_adequacy_score) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (exam_id, payload.insurer_id, payload.exam_type, payload.scheduled_date,
             "scheduled", None, None),
        )
        conn.commit()

        row = conn.execute(
            "SELECT * FROM market_conduct_exams WHERE exam_id = ?", (exam_id,)
        ).fetchone()
        return _row_to_exam(row)
    finally:
        conn.close()


@router.post("/api/examinations/{exam_id}/complete")
def complete_examination(exam_id: str, payload: ExamComplete):
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM market_conduct_exams WHERE exam_id = ?", (exam_id,)
        ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Examination not found")

        if not (0.0 <= payload.claim_handling_score <= 100.0):
            raise HTTPException(status_code=400, detail="claim_handling_score must be between 0.0 and 100.0")
        if not (0.0 <= payload.network_adequacy_score <= 100.0):
            raise HTTPException(status_code=400, detail="network_adequacy_score must be between 0.0 and 100.0")

        conn.execute(
            "UPDATE market_conduct_exams SET status = 'completed', claim_handling_score = ?, "
            "network_adequacy_score = ? WHERE exam_id = ?",
            (payload.claim_handling_score, payload.network_adequacy_score, exam_id),
        )
        conn.commit()

        row = conn.execute(
            "SELECT * FROM market_conduct_exams WHERE exam_id = ?", (exam_id,)
        ).fetchone()
        return _row_to_exam(row)
    finally:
        conn.close()


@router.get("/api/examinations")
def list_examinations(insurer_id: Optional[str] = Query(None)):
    conn = get_connection()
    try:
        if insurer_id:
            rows = conn.execute(
                "SELECT * FROM market_conduct_exams WHERE insurer_id = ?", (insurer_id,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM market_conduct_exams").fetchall()
        return [_row_to_exam(r) for r in rows]
    finally:
        conn.close()
