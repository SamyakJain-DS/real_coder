"""
Landlord compliance classifier for the housing code enforcement analytics pipeline.
Computes per-landlord metrics and classifies compliance behavior.
"""
import numpy as np
import pandas as pd

NUM_YEARS = 5


def classify_landlord_compliance(data: dict) -> pd.DataFrame:
    """
    Classify each landlord portfolio by compliance behavior.

    Args:
        data: Dict returned by load_data with keys "properties", "violations", "landlords".

    Returns:
        DataFrame indexed by landlord_id with columns:
            portfolio_size, total_violations, repeat_violation_rate,
            violation_density, compliance_score, compliance_classification
    """
    properties = data["properties"]
    violations = data["violations"]
    landlords = data["landlords"]

    # Portfolio size per landlord
    portfolio = properties.groupby("landlord_id")["property_id"].nunique().rename("portfolio_size")

    # Violations per landlord
    viol_counts = violations.groupby("landlord_id").size().rename("total_violations")

    # Repeat violation rate: count of is_repeat==True / total_violations
    repeat_counts = (
        violations[violations["is_repeat"] == True]
        .groupby("landlord_id")
        .size()
        .rename("repeat_count")
    )

    # Assemble base DataFrame from all landlords
    all_lids = landlords["landlord_id"].values
    df = pd.DataFrame(index=all_lids)
    df.index.name = "landlord_id"

    df["portfolio_size"] = portfolio.reindex(df.index).fillna(0).astype(int)
    df["total_violations"] = viol_counts.reindex(df.index).fillna(0).astype(int)

    repeat_count_series = repeat_counts.reindex(df.index).fillna(0)
    total_viol_safe = df["total_violations"].values.copy().astype(float)
    total_viol_safe[total_viol_safe == 0] = 1.0
    df["repeat_violation_rate"] = np.where(
        df["total_violations"] > 0,
        repeat_count_series.values / total_viol_safe,
        0.0,
    )

    # violation_density: total_violations / portfolio_size / NUM_YEARS
    df["violation_density"] = np.where(
        df["portfolio_size"] > 0,
        df["total_violations"] / df["portfolio_size"] / NUM_YEARS,
        0.0,
    )

    # compliance_score: equally weighted average of min-max normalized metrics
    rvr = df["repeat_violation_rate"].values.astype(float)
    vd = df["violation_density"].values.astype(float)

    rvr_min, rvr_max = rvr.min(), rvr.max()
    vd_min, vd_max = vd.min(), vd.max()

    rvr_norm = (rvr - rvr_min) / (rvr_max - rvr_min) if rvr_max > rvr_min else np.zeros_like(rvr)
    vd_norm = (vd - vd_min) / (vd_max - vd_min) if vd_max > vd_min else np.zeros_like(vd)

    df["compliance_score"] = (rvr_norm + vd_norm) / 2.0

    # Classification: 75th percentile of repeat_violation_rate
    threshold = np.percentile(df["repeat_violation_rate"].values, 75)
    df["compliance_classification"] = np.where(
        df["repeat_violation_rate"] >= threshold,
        "systematic_noncompliant",
        "incidental",
    )

    return df[[
        "portfolio_size",
        "total_violations",
        "repeat_violation_rate",
        "violation_density",
        "compliance_score",
        "compliance_classification",
    ]]
