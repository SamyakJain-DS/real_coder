from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, field_validator


class Insurer(BaseModel):
    insurer_id: str
    naic_code: str
    company_name: str
    company_type: str
    state_license_status: str
    domicile_state: str
    admitted_date: str

    @field_validator("company_type")
    @classmethod
    def _validate_company_type(cls, v: str) -> str:
        if v not in ("insurer", "mco"):
            raise ValueError("company_type must be 'insurer' or 'mco'")
        return v

    @field_validator("state_license_status")
    @classmethod
    def _validate_license_status(cls, v: str) -> str:
        if v not in ("active", "suspended", "revoked"):
            raise ValueError("state_license_status must be 'active', 'suspended', or 'revoked'")
        return v


class Attachment(BaseModel):
    attachment_id: str
    filing_id: str
    attachment_type: str
    filename: str
    uploaded_date: str

    @field_validator("attachment_type")
    @classmethod
    def _validate_attachment_type(cls, v: str) -> str:
        if v not in ("actuarial_memorandum", "experience_exhibit"):
            raise ValueError("attachment_type must be 'actuarial_memorandum' or 'experience_exhibit'")
        return v


class RateFiling(BaseModel):
    filing_id: str
    insurer_id: str
    serff_tracking_number: str
    filing_type: str
    product_type: str
    effective_date: str
    status: str
    submission_date: str
    requested_rate_change_pct: float
    aca_unreasonable_flag: bool
    attachments: list[Attachment] = []

    @field_validator("filing_type")
    @classmethod
    def _validate_filing_type(cls, v: str) -> str:
        if v not in ("initial", "amendment", "renewal"):
            raise ValueError("filing_type must be 'initial', 'amendment', or 'renewal'")
        return v

    @field_validator("product_type")
    @classmethod
    def _validate_product_type(cls, v: str) -> str:
        if v not in ("individual", "small_group", "large_group"):
            raise ValueError("product_type must be 'individual', 'small_group', or 'large_group'")
        return v

    @field_validator("status")
    @classmethod
    def _validate_status(cls, v: str) -> str:
        if v not in ("received", "under_review", "approved", "rejected", "withdrawn"):
            raise ValueError("Invalid filing status")
        return v


class RateReview(BaseModel):
    review_id: str
    filing_id: str
    projected_mlr: float
    target_mlr: float
    trend_factor_used: float
    admin_expense_ratio: float
    admin_expense_flag: bool
    adequacy_result: str
    review_date: str

    @field_validator("adequacy_result")
    @classmethod
    def _validate_adequacy_result(cls, v: str) -> str:
        if v not in ("adequate", "inadequate"):
            raise ValueError("adequacy_result must be 'adequate' or 'inadequate'")
        return v


class PublicComment(BaseModel):
    comment_id: str
    filing_id: str
    commenter_name: str
    commenter_email: str
    comment_text: str
    submitted_date: str


class PublicHearing(BaseModel):
    hearing_id: str
    filing_id: str
    hearing_date: str
    location: str
    hearing_officer: str
    status: str
    notice_published_date: str

    @field_validator("status")
    @classmethod
    def _validate_status(cls, v: str) -> str:
        if v not in ("scheduled", "completed", "cancelled"):
            raise ValueError("Hearing status must be 'scheduled', 'completed', or 'cancelled'")
        return v


class FormFiling(BaseModel):
    form_filing_id: str
    insurer_id: str
    form_type: str
    product_type: str
    submission_date: str
    status: str
    mandated_benefits_checklist: dict

    @field_validator("form_type")
    @classmethod
    def _validate_form_type(cls, v: str) -> str:
        if v not in ("policy", "certificate", "rider", "endorsement"):
            raise ValueError("form_type must be 'policy', 'certificate', 'rider', or 'endorsement'")
        return v

    @field_validator("product_type")
    @classmethod
    def _validate_product_type(cls, v: str) -> str:
        if v not in ("individual", "small_group", "large_group"):
            raise ValueError("product_type must be 'individual', 'small_group', or 'large_group'")
        return v

    @field_validator("status")
    @classmethod
    def _validate_status(cls, v: str) -> str:
        if v not in ("received", "under_review", "approved", "rejected"):
            raise ValueError("Invalid form filing status")
        return v


class MarketConductExam(BaseModel):
    exam_id: str
    insurer_id: str
    exam_type: str
    scheduled_date: str
    status: str
    claim_handling_score: Optional[float] = None
    network_adequacy_score: Optional[float] = None

    @field_validator("exam_type")
    @classmethod
    def _validate_exam_type(cls, v: str) -> str:
        if v not in ("claim_handling", "network_adequacy", "comprehensive"):
            raise ValueError("exam_type must be 'claim_handling', 'network_adequacy', or 'comprehensive'")
        return v

    @field_validator("status")
    @classmethod
    def _validate_status(cls, v: str) -> str:
        if v not in ("scheduled", "in_progress", "completed", "cancelled"):
            raise ValueError("Invalid exam status")
        return v


class RiskAdjustmentReconciliation(BaseModel):
    reconciliation_id: str
    insurer_id: str
    plan_year: int
    risk_adjustment_transfer_amount: float
    cciio_submission_status: str
    submission_date: Optional[str] = None
    notes: Optional[str] = None

    @field_validator("cciio_submission_status")
    @classmethod
    def _validate_cciio_status(cls, v: str) -> str:
        if v not in ("pending", "submitted", "accepted", "rejected"):
            raise ValueError("cciio_submission_status must be 'pending', 'submitted', 'accepted', or 'rejected'")
        return v
