export interface ProvenanceEntry {
  owner: string
  acquiredOn: string
  note: string
}

export interface SharpeningSession {
  id: string
  date: string
  angle: number
  stoneGritProgression: number[]
}

export interface Knife {
  id: string
  maker: string
  pattern: string
  provenanceChain: ProvenanceEntry[]
  photoDataUrl: string
  edgeGeometry: string
  scaleMaterial: string
  sharpeningSessions: SharpeningSession[]
}
