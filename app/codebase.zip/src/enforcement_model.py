"""
Enforcement effectiveness modeller for the housing code enforcement analytics pipeline.
Fits a logistic regression model to estimate enforcement tool effects on compliance.
"""
import math

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression


ENFORCEMENT_TOOLS = ["warning_notice", "civil_fine", "court_referral", "license_suspension"]
REFERENCE_TOOL = "warning_notice"


def _compute_ci_and_pvalue(model, X: np.ndarray, y: np.ndarray, coef_idx: int):
    """
    Compute 95% CI and p-value for a logistic regression coefficient
    using the Wald test with Fisher information (observed Hessian approximation).
    """
    n = X.shape[0]
    p_hat = model.predict_proba(X)[:, 1]
    W = p_hat * (1 - p_hat)

    # Hessian of log-likelihood = X^T W X
    XtWX = (X.T * W) @ X
    try:
        cov = np.linalg.inv(XtWX)
        se = np.sqrt(max(cov[coef_idx, coef_idx], 0.0))
    except np.linalg.LinAlgError:
        se = 0.0

    coef = model.coef_[0][coef_idx]
    z = coef / se if se > 0 else 0.0

    # p-value from two-sided Wald test (standard normal survival function)
    # Pr(|Z| > |z|) = 2 * (1 - Phi(|z|)) = erfc(|z| / sqrt(2))
    p_value = math.erfc(abs(z) / math.sqrt(2.0))

    ci_lower = coef - 1.96 * se
    ci_upper = coef + 1.96 * se

    return float(coef), (float(ci_lower), float(ci_upper)), float(p_value)


def model_enforcement_effectiveness(data: dict, follow_up_days: int = 180) -> dict:
    """
    Model the effect of enforcement tools on compliance probability.

    Args:
        data: Dict returned by load_data.
        follow_up_days: Number of days defining the compliance follow-up window.

    Returns:
        dict with keys:
            "model_type": "logistic_regression"
            "tool_effects": dict mapping each tool name to
                {"effect_size": float, "confidence_interval": (lower, upper), "p_value": float}
    """
    violations = data["violations"].copy()

    # Binary outcome: complied_within_window
    def _complied(row) -> int:
        res_date = row["resolution_date"]
        enf_date = row["enforcement_action_date"]
        if pd.isnull(res_date) or pd.isnull(enf_date):
            return 0
        delta = (res_date - enf_date).days
        return 1 if 0 <= delta <= follow_up_days else 0

    violations["complied_within_window"] = violations.apply(_complied, axis=1)

    # One-hot encode enforcement tool with warning_notice as reference (dropped)
    non_reference_tools = [t for t in ENFORCEMENT_TOOLS if t != REFERENCE_TOOL]
    for tool in non_reference_tools:
        violations[f"tool_{tool}"] = (violations["enforcement_tool"] == tool).astype(int)

    feature_cols = [f"tool_{t}" for t in non_reference_tools]
    X = violations[feature_cols].values.astype(float)
    y = violations["complied_within_window"].values.astype(int)

    # Fit logistic regression
    clf = LogisticRegression(
        fit_intercept=True,
        max_iter=1000,
        random_state=42,
        solver="lbfgs",
    )
    clf.fit(X, y)

    # Build X_with_intercept for Hessian computation (include intercept column)
    X_aug = np.column_stack([np.ones(len(X)), X])
    # Refit with intercept in X_aug as no-intercept model to get all coefficients
    clf_aug = LogisticRegression(
        fit_intercept=False,
        max_iter=1000,
        random_state=42,
        solver="lbfgs",
    )
    clf_aug.fit(X_aug, y)

    tool_effects = {}

    # Reference tool: warning_notice
    tool_effects[REFERENCE_TOOL] = {
        "effect_size": 0.0,
        "confidence_interval": (0.0, 0.0),
        "p_value": 1.0,
    }

    # Other tools: coefficient indices 1, 2, 3 (0 is intercept)
    for i, tool in enumerate(non_reference_tools):
        coef_idx = i + 1  # +1 because index 0 is the intercept
        effect_size, ci, p_value = _compute_ci_and_pvalue(clf_aug, X_aug, y, coef_idx)
        tool_effects[tool] = {
            "effect_size": effect_size,
            "confidence_interval": ci,
            "p_value": p_value,
        }

    return {
        "model_type": "logistic_regression",
        "tool_effects": tool_effects,
    }
