//! Concurrent B-link tree crate providing an in-memory ordered map.
//!
//! Public types:
//! - [`BLinkTree`]: a concurrent B-link tree (Lehman and Yao, 1981) with
//!   lock-free readers and per-node-latch-coupling writers. Writers do not
//!   share a global mutex; concurrent inserts and removes that touch
//!   disjoint subtrees proceed without contention. Readers traverse
//!   exclusively through `Acquire`-ordered atomic loads.
//! - [`RwLockBTreeMap`]: a reference baseline wrapping
//!   `std::sync::RwLock<std::collections::BTreeMap<K, V>>` exposing the four
//!   inherent methods that the benchmark harness drives.

use arc_swap::ArcSwap;
use std::collections::BTreeMap;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::sync::{Mutex, MutexGuard, RwLock};

// Per-node fan-out cap. Pairs (leaf) and children (internal) must not exceed
// this count after publication; an overflowing modification triggers a split.
const NODE_CAPACITY: usize = 16;
// Lower bound that triggers a merge with an adjacent sibling on remove.
// Set to 1 so underflow means "node has become empty"; an empty node plus
// any sibling combines to at most NODE_CAPACITY entries, so merge is always
// feasible without redistribution and the prompt's unconditional
// merge-on-underflow contract holds for every interleaving.
const MIN_OCCUPANCY: usize = 1;

// ---------------------------------------------------------------------------
// Node representation.
//
// Every node owns a writer latch (`Mutex<()>`) for the per-node latch-coupling
// write protocol and an `ArcSwap<NodeData>` snapshot. The snapshot is the
// single publication point for the node's keys, values, child pointers,
// separators, high key, and right-link, swapped atomically through `ArcSwap`
// whose internal pointer is stored with `Release` and loaded with `Acquire`
// ordering.
// ---------------------------------------------------------------------------

struct Node<K, V> {
    latch: Mutex<()>,
    data: ArcSwap<NodeData<K, V>>,
}

enum NodeData<K, V> {
    Leaf(LeafData<K, V>),
    Internal(InternalData<K, V>),
}

struct LeafData<K, V> {
    // Key/value pairs sorted ascending by key.
    pairs: Vec<(K, V)>,
    // High key bounding every key reachable through this node.
    // `None` means positive infinity (rightmost node at this level).
    high_key: Option<K>,
    // Right sibling at the same level. `None` only for the rightmost node.
    right: Option<Arc<Node<K, V>>>,
}

struct InternalData<K, V> {
    // `separators[i]` is the upper-bound key for `children[i]`. Equal length
    // to `children`. `None` means positive infinity and is only allowed as
    // the very last entry, when this internal node is rightmost at its
    // level. Separators are owned by the parent and remain stable when a
    // child later splits, so a writer descending through this parent picks
    // the correct child even when that child's own `high_key` has just
    // shrunk via a concurrent split that has not yet been propagated.
    separators: Vec<Option<K>>,
    children: Vec<Arc<Node<K, V>>>,
    // Mirror of `separators.last()`.
    high_key: Option<K>,
    right: Option<Arc<Node<K, V>>>,
}

impl<K, V> Node<K, V> {
    fn new_leaf(data: LeafData<K, V>) -> Arc<Self> {
        Arc::new(Node {
            latch: Mutex::new(()),
            data: ArcSwap::from(Arc::new(NodeData::Leaf(data))),
        })
    }

    fn new_internal(data: InternalData<K, V>) -> Arc<Self> {
        Arc::new(Node {
            latch: Mutex::new(()),
            data: ArcSwap::from(Arc::new(NodeData::Internal(data))),
        })
    }
}

// ---------------------------------------------------------------------------
// BLinkTree.
// ---------------------------------------------------------------------------

/// Concurrent B-link tree exposing an owning, thread-safe ordered map API.
///
/// Mutation methods take `&self`, so an `Arc<BLinkTree<K, V>>` can be shared
/// across threads and every change happens through interior mutability.
/// Writers do not share a global mutex: concurrent writes proceed under
/// per-node latch coupling, and only the atomic replacement of the root
/// pointer (when the tree's height grows or shrinks) is briefly serialised
/// through `root_mu`.
pub struct BLinkTree<K, V> {
    root: ArcSwap<Node<K, V>>,
    // Held only while atomically swapping the root pointer (root split, root
    // collapse, or recovery after another writer has changed the root). All
    // other writes proceed without it.
    root_mu: Mutex<()>,
    len: AtomicUsize,
}

impl<K, V> BLinkTree<K, V>
where
    K: Ord + Clone + Send + Sync + 'static,
    V: Clone + Send + Sync + 'static,
{
    /// Constructs an empty tree whose root is a single empty leaf.
    pub fn new() -> Self {
        let root = Node::new_leaf(LeafData {
            pairs: Vec::new(),
            high_key: None,
            right: None,
        });
        BLinkTree {
            root: ArcSwap::from(root),
            root_mu: Mutex::new(()),
            len: AtomicUsize::new(0),
        }
    }

    /// Returns the number of mappings currently stored.
    pub fn len(&self) -> usize {
        self.len.load(Ordering::Acquire)
    }

    /// Returns `true` exactly when `self.len() == 0`.
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Returns `true` exactly when `get(key)` would return `Some(_)`.
    pub fn contains_key(&self, key: &K) -> bool {
        self.get(key).is_some()
    }

    // -----------------------------------------------------------------------
    // Lock-free read path.
    //
    // Readers acquire no latch. Each step performs an Acquire-ordered atomic
    // load (through `ArcSwap::load_full`) of the node's snapshot, which
    // contains the keys, values, separators, high key, right-link and child
    // pointers published by writers under Release ordering.
    // -----------------------------------------------------------------------

    /// Returns a clone of the value bound to `key`, or `None`.
    pub fn get(&self, key: &K) -> Option<V> {
        let mut node = self.root.load_full();
        loop {
            node = walk_right_at_level(node, |hk| hk.map_or(false, |h| key > h));

            let step: Step<K, V> = {
                let snap = node.data.load_full();
                match &*snap {
                    NodeData::Leaf(l) => Step::Found(
                        l.pairs
                            .binary_search_by(|(k, _)| k.cmp(key))
                            .ok()
                            .map(|i| l.pairs[i].1.clone()),
                    ),
                    NodeData::Internal(n) => Step::Descend(pick_child(n, key)),
                }
            };
            match step {
                Step::Found(v) => return v,
                Step::Descend(child) => node = child,
            }
        }
    }

    /// Returns every `(key, value)` pair with `low <= key <= high`, sorted
    /// ascending by key.
    ///
    /// The scan descends lock-free to the leftmost leaf containing keys
    /// `>= low` and then walks the leaf-level right-link chain until a leaf
    /// whose high key already covers `high`. Every visited node is loaded
    /// through an Acquire-ordered atomic load, and the high-key check at the
    /// leaf level mirrors the lock-free traversal used by `get`.
    pub fn range_collect(&self, low: &K, high: &K) -> Vec<(K, V)> {
        let mut out: Vec<(K, V)> = Vec::new();
        if low > high {
            return out;
        }

        let mut node = self.root.load_full();
        loop {
            node = walk_right_at_level(node, |hk| hk.map_or(false, |h| low > h));
            let next_child: Option<Arc<Node<K, V>>> = {
                let snap = node.data.load_full();
                match &*snap {
                    NodeData::Leaf(_) => None,
                    NodeData::Internal(n) => Some(pick_child(n, low)),
                }
            };
            match next_child {
                None => break,
                Some(c) => node = c,
            }
        }

        loop {
            node = walk_right_at_level(node, |hk| hk.map_or(false, |h| low > h));
            let next: Option<Arc<Node<K, V>>> = {
                let snap = node.data.load_full();
                let leaf = match &*snap {
                    NodeData::Leaf(l) => l,
                    _ => unreachable!(),
                };
                for (k, v) in &leaf.pairs {
                    if k >= low && k <= high {
                        if let Some((last_k, _)) = out.last() {
                            if last_k >= k {
                                // A concurrent split could leave a stale
                                // snapshot whose right-link chain re-visits a
                                // key already collected; skip such repeats so
                                // the result remains strictly ascending.
                                continue;
                            }
                        }
                        out.push((k.clone(), v.clone()));
                    }
                }
                match (&leaf.high_key, &leaf.right) {
                    (Some(hk), Some(right)) if hk < high => Some(right.clone()),
                    _ => None,
                }
            };
            match next {
                Some(n) => node = n,
                None => break,
            }
        }
        out
    }

    // -----------------------------------------------------------------------
    // Writer path: per-node latch-coupling descent followed by split / merge.
    //
    // Writers acquire only per-node latches. On every step the writer takes
    // the chosen child's latch before releasing the parent's latch, in line
    // with the Lehman-Yao protocol. Writers also follow right-links during
    // descent (the same way readers do) so they tolerate concurrent splits
    // initiated by other writers in disjoint subtrees.
    //
    // The only mutex shared across the tree as a whole is `root_mu`, held
    // briefly while the root pointer itself is swapped (root split or root
    // collapse). All other writes proceed without it.
    // -----------------------------------------------------------------------

    /// Inserts the mapping `(key, value)` and returns the previous value
    /// bound to `key`, or `None` when the key was absent.
    pub fn insert(&self, key: K, value: V) -> Option<V> {
        let (leaf, leaf_guard, ancestors) = self.descend_for_write(&key);

        let snap = leaf.data.load_full();
        let leaf_data = match &*snap {
            NodeData::Leaf(l) => l,
            _ => unreachable!(),
        };

        let mut new_pairs = leaf_data.pairs.clone();
        let prev = match new_pairs.binary_search_by(|(k, _)| k.cmp(&key)) {
            Ok(idx) => Some(std::mem::replace(&mut new_pairs[idx].1, value)),
            Err(idx) => {
                new_pairs.insert(idx, (key, value));
                None
            }
        };

        let high_key = leaf_data.high_key.clone();
        let right_link = leaf_data.right.clone();
        drop(snap);

        if new_pairs.len() <= NODE_CAPACITY {
            leaf.data.store(Arc::new(NodeData::Leaf(LeafData {
                pairs: new_pairs,
                high_key,
                right: right_link,
            })));
            drop(leaf_guard);
            if prev.is_none() {
                self.len.fetch_add(1, Ordering::Release);
            }
            return prev;
        }

        // Overflow: split the leaf into a new lower (kept in place) and a new
        // right sibling that takes the upper half of the keys.
        let mid = new_pairs.len() / 2;
        let upper_pairs = new_pairs.split_off(mid);
        let lower_high = Some(new_pairs.last().unwrap().0.clone());
        let upper_high = high_key;
        let upper_right = right_link;

        let new_sibling = Node::new_leaf(LeafData {
            pairs: upper_pairs,
            high_key: upper_high.clone(),
            right: upper_right,
        });

        leaf.data.store(Arc::new(NodeData::Leaf(LeafData {
            pairs: new_pairs,
            high_key: lower_high.clone(),
            right: Some(new_sibling.clone()),
        })));
        drop(leaf_guard);

        if prev.is_none() {
            self.len.fetch_add(1, Ordering::Release);
        }

        self.propagate_split(
            ancestors,
            leaf,
            new_sibling,
            lower_high,
            upper_high,
        );
        prev
    }

    /// Removes the mapping for `key` and returns the removed value, or `None`.
    pub fn remove(&self, key: &K) -> Option<V> {
        let (leaf, leaf_guard, ancestors) = self.descend_for_write(key);

        let snap = leaf.data.load_full();
        let leaf_data = match &*snap {
            NodeData::Leaf(l) => l,
            _ => unreachable!(),
        };

        let mut new_pairs = leaf_data.pairs.clone();
        let removed = match new_pairs.binary_search_by(|(k, _)| k.cmp(key)) {
            Ok(idx) => Some(new_pairs.remove(idx).1),
            Err(_) => None,
        };

        if removed.is_none() {
            drop(snap);
            drop(leaf_guard);
            return None;
        }

        let new_len = new_pairs.len();
        leaf.data.store(Arc::new(NodeData::Leaf(LeafData {
            pairs: new_pairs,
            high_key: leaf_data.high_key.clone(),
            right: leaf_data.right.clone(),
        })));
        drop(snap);
        drop(leaf_guard);

        self.len.fetch_sub(1, Ordering::Release);

        if new_len < MIN_OCCUPANCY && !ancestors.is_empty() {
            self.handle_underflow(leaf, ancestors);
        }

        removed
    }

    // Per-node latch-coupling descent. At every step the writer takes the
    // chosen child's latch before releasing the parent's latch, and follows
    // right-links at the current level whenever the search key exceeds the
    // current node's high key (to tolerate concurrent splits committed by
    // other writers in the same subtree). Returns the leaf node, its still
    // held latch guard, and the ancestor stack (parents the writer actually
    // descended through, in order from root to leaf's parent) used for
    // split / merge propagation.
    fn descend_for_write(
        &self,
        key: &K,
    ) -> (
        Arc<Node<K, V>>,
        OwningGuard<K, V>,
        Vec<Arc<Node<K, V>>>,
    ) {
        let mut ancestors: Vec<Arc<Node<K, V>>> = Vec::new();
        let mut node = self.root.load_full();
        let mut guard = OwningGuard::new(node.clone());

        loop {
            // Right-walk at this level (latch-coupled): if the writer's key
            // exceeds the current node's high key, hop to the right sibling.
            loop {
                let right_arc: Option<Arc<Node<K, V>>> = {
                    let snap = node.data.load_full();
                    let (hk, right) = match &*snap {
                        NodeData::Leaf(l) => (l.high_key.as_ref(), l.right.clone()),
                        NodeData::Internal(n) => (n.high_key.as_ref(), n.right.clone()),
                    };
                    if hk.map_or(false, |h| key > h) {
                        right
                    } else {
                        None
                    }
                };
                match right_arc {
                    Some(r) => {
                        let rguard = OwningGuard::new(r.clone());
                        drop(guard);
                        node = r;
                        guard = rguard;
                    }
                    None => break,
                }
            }

            let next_child: Option<Arc<Node<K, V>>> = {
                let snap = node.data.load_full();
                match &*snap {
                    NodeData::Leaf(_) => None,
                    NodeData::Internal(n) => Some(pick_child(n, key)),
                }
            };
            match next_child {
                None => return (node, guard, ancestors),
                Some(child) => {
                    // Latch coupling: take the child latch first, then drop
                    // the parent latch.
                    let child_guard = OwningGuard::new(child.clone());
                    drop(guard);

                    ancestors.push(node);
                    node = child;
                    guard = child_guard;
                }
            }
        }
    }

    // Propagates a split up the tree. At each level the writer pops the
    // recorded ancestor and walks right-links at that level to find the
    // node currently holding `left_child` as one of its children. That node
    // receives the new sibling reference next to the existing entry; if it
    // overflows it splits in turn and the propagation continues. When the
    // propagation walks past the recorded root, a new root is installed
    // (under `root_mu`) — or, if another writer already changed the root,
    // the propagation is restarted by re-descending from the current root.
    fn propagate_split(
        &self,
        mut ancestors: Vec<Arc<Node<K, V>>>,
        mut left_child: Arc<Node<K, V>>,
        mut right_child: Arc<Node<K, V>>,
        mut new_left_separator: Option<K>,
        mut new_right_separator: Option<K>,
    ) {
        loop {
            let parent_arc = match ancestors.pop() {
                Some(a) => a,
                None => {
                    self.try_install_new_root(
                        left_child,
                        right_child,
                        new_left_separator,
                        new_right_separator,
                    );
                    return;
                }
            };

            // Walk right at the parent level, latch-coupled, to find the
            // parent currently holding `left_child` as one of its children.
            let mut parent = parent_arc;
            let mut pguard = OwningGuard::new(parent.clone());

            let mut found = false;
            loop {
                let (contains, right_link, is_internal) = {
                    let snap = parent.data.load_full();
                    match &*snap {
                        NodeData::Internal(pdata) => {
                            let c = pdata
                                .children
                                .iter()
                                .any(|c| Arc::ptr_eq(c, &left_child));
                            (c, pdata.right.clone(), true)
                        }
                        _ => (false, None, false),
                    }
                };
                if !is_internal {
                    break;
                }
                if contains {
                    found = true;
                    break;
                }
                match right_link {
                    Some(r) => {
                        let rguard = OwningGuard::new(r.clone());
                        drop(pguard);
                        parent = r;
                        pguard = rguard;
                    }
                    None => break,
                }
            }

            if !found {
                drop(pguard);
                // The recorded ancestor level no longer contains our
                // left_child. Either the root grew above this level via
                // another writer's root split, or the structure changed in
                // a way that requires re-descending. Try the new-root path,
                // which will re-find the parent if the root has changed.
                self.try_install_new_root(
                    left_child,
                    right_child,
                    new_left_separator,
                    new_right_separator,
                );
                return;
            }

            // Insert the new sibling reference into the parent.
            let snap = parent.data.load_full();
            let pdata = match &*snap {
                NodeData::Internal(n) => n,
                _ => unreachable!(),
            };
            let pos = pdata
                .children
                .iter()
                .position(|c| Arc::ptr_eq(c, &left_child))
                .expect("parent must contain left_child by the previous check");

            let mut new_seps = pdata.separators.clone();
            let mut new_children = pdata.children.clone();
            new_seps[pos] = new_left_separator.clone();
            new_seps.insert(pos + 1, new_right_separator.clone());
            new_children.insert(pos + 1, right_child.clone());
            let parent_right = pdata.right.clone();
            drop(snap);

            if new_children.len() <= NODE_CAPACITY {
                let new_high = new_seps.last().expect("non-empty").clone();
                parent
                    .data
                    .store(Arc::new(NodeData::Internal(InternalData {
                        separators: new_seps,
                        children: new_children,
                        high_key: new_high,
                        right: parent_right,
                    })));
                drop(pguard);
                return;
            }

            // Split the parent.
            let mid = new_children.len() / 2;
            let upper_children = new_children.split_off(mid);
            let upper_seps = new_seps.split_off(mid);
            let lower_new_hk = new_seps.last().expect("non-empty").clone();
            let upper_new_hk = upper_seps.last().expect("non-empty").clone();

            let new_sibling = Node::new_internal(InternalData {
                separators: upper_seps,
                children: upper_children,
                high_key: upper_new_hk.clone(),
                right: parent_right,
            });

            parent
                .data
                .store(Arc::new(NodeData::Internal(InternalData {
                    separators: new_seps,
                    children: new_children,
                    high_key: lower_new_hk.clone(),
                    right: Some(new_sibling.clone()),
                })));
            drop(pguard);

            left_child = parent;
            right_child = new_sibling;
            new_left_separator = lower_new_hk;
            new_right_separator = upper_new_hk;
        }
    }

    // Installs a brand-new root containing the (left, right) pair, growing
    // the tree height. If another writer has already grown the tree (so the
    // current root is no longer `left`), this function re-descends from the
    // new root to find the parent of `left` and continues propagation there.
    fn try_install_new_root(
        &self,
        left: Arc<Node<K, V>>,
        right: Arc<Node<K, V>>,
        left_sep: Option<K>,
        right_sep: Option<K>,
    ) {
        let _root_lock = self.root_mu.lock().unwrap();
        let cur = self.root.load_full();
        if Arc::ptr_eq(&cur, &left) {
            let new_root = Node::new_internal(InternalData {
                separators: vec![left_sep, right_sep.clone()],
                children: vec![left, right],
                high_key: right_sep,
                right: None,
            });
            self.root.store(new_root);
            return;
        }
        drop(_root_lock);

        // The root has changed since we descended. Re-find the parent of
        // `left` by descending from the current root using the separator key
        // (which lies inside `left`'s subtree), then continue propagation.
        let key = match &left_sep {
            Some(k) => k.clone(),
            None => return,
        };
        if let Some(ancestors) = self.find_path_to_node(&left, &key) {
            self.propagate_split(ancestors, left, right, left_sep, right_sep);
        }
    }

    // Walks down from the current root looking for `target`. Returns the
    // ancestor path (root .. parent_of_target) on success. Used to recover
    // when another writer changed the root between our descent and our
    // propagation.
    fn find_path_to_node(
        &self,
        target: &Arc<Node<K, V>>,
        key: &K,
    ) -> Option<Vec<Arc<Node<K, V>>>> {
        let mut ancestors: Vec<Arc<Node<K, V>>> = Vec::new();
        let mut node = self.root.load_full();
        if Arc::ptr_eq(&node, target) {
            return None;
        }
        loop {
            // Right-walk if needed.
            loop {
                let right_arc: Option<Arc<Node<K, V>>> = {
                    let snap = node.data.load_full();
                    let (hk, right) = match &*snap {
                        NodeData::Leaf(l) => (l.high_key.as_ref(), l.right.clone()),
                        NodeData::Internal(n) => (n.high_key.as_ref(), n.right.clone()),
                    };
                    if hk.map_or(false, |h| key > h) {
                        right
                    } else {
                        None
                    }
                };
                match right_arc {
                    Some(r) => node = r,
                    None => break,
                }
            }

            let action: FindAction<K, V> = {
                let snap = node.data.load_full();
                match &*snap {
                    NodeData::Leaf(_) => FindAction::Stop,
                    NodeData::Internal(n) => {
                        if n.children.iter().any(|c| Arc::ptr_eq(c, target)) {
                            FindAction::Found
                        } else {
                            FindAction::Down(pick_child(n, key))
                        }
                    }
                }
            };
            match action {
                FindAction::Found => {
                    ancestors.push(node);
                    return Some(ancestors);
                }
                FindAction::Down(child) => {
                    ancestors.push(node);
                    node = child;
                }
                FindAction::Stop => return None,
            }
        }
    }

    // -----------------------------------------------------------------------
    // Underflow handling: merge an underfull node with its adjacent sibling
    // at the same level, then propagate to the parent and collapse the root
    // if it becomes a single-child internal node.
    // -----------------------------------------------------------------------

    fn handle_underflow(
        &self,
        mut underfull: Arc<Node<K, V>>,
        mut ancestors: Vec<Arc<Node<K, V>>>,
    ) {
        while let Some(parent_arc) = ancestors.pop() {
            // Walk right at parent level to find the parent currently
            // holding `underfull` as one of its children.
            let mut parent = parent_arc;
            let mut pguard = OwningGuard::new(parent.clone());

            let mut pos_opt: Option<usize> = None;
            loop {
                let (pos, right_link, is_internal) = {
                    let snap = parent.data.load_full();
                    match &*snap {
                        NodeData::Internal(pdata) => {
                            let p = pdata
                                .children
                                .iter()
                                .position(|c| Arc::ptr_eq(c, &underfull));
                            (p, pdata.right.clone(), true)
                        }
                        _ => (None, None, false),
                    }
                };
                if !is_internal {
                    break;
                }
                if pos.is_some() {
                    pos_opt = pos;
                    break;
                }
                match right_link {
                    Some(r) => {
                        let rguard = OwningGuard::new(r.clone());
                        drop(pguard);
                        parent = r;
                        pguard = rguard;
                    }
                    None => break,
                }
            }

            let pos = match pos_opt {
                Some(p) => p,
                None => {
                    drop(pguard);
                    return;
                }
            };

            let (parent_seps, parent_children, parent_high, parent_right) = {
                let snap = parent.data.load_full();
                let pdata = match &*snap {
                    NodeData::Internal(n) => n,
                    _ => {
                        drop(snap);
                        drop(pguard);
                        return;
                    }
                };
                (
                    pdata.separators.clone(),
                    pdata.children.clone(),
                    pdata.high_key.clone(),
                    pdata.right.clone(),
                )
            };

            let (left_idx, right_idx) = if pos + 1 < parent_children.len() {
                (pos, pos + 1)
            } else if pos > 0 {
                (pos - 1, pos)
            } else {
                drop(pguard);
                return;
            };

            let left_node = parent_children[left_idx].clone();
            let right_node = parent_children[right_idx].clone();

            // Latch both siblings before mutating them or the parent.
            let _lguard = OwningGuard::new(left_node.clone());
            let _rguard = OwningGuard::new(right_node.clone());

            let merged = {
                let lsnap = left_node.data.load_full();
                let rsnap = right_node.data.load_full();
                match (&*lsnap, &*rsnap) {
                    (NodeData::Leaf(ll), NodeData::Leaf(rl)) => {
                        if ll.pairs.len() + rl.pairs.len() > NODE_CAPACITY {
                            false
                        } else {
                            let mut merged = ll.pairs.clone();
                            merged.extend(rl.pairs.iter().cloned());
                            left_node.data.store(Arc::new(NodeData::Leaf(LeafData {
                                pairs: merged,
                                high_key: rl.high_key.clone(),
                                right: rl.right.clone(),
                            })));
                            true
                        }
                    }
                    (NodeData::Internal(li), NodeData::Internal(ri)) => {
                        if li.children.len() + ri.children.len() > NODE_CAPACITY {
                            false
                        } else {
                            let mut merged_seps = li.separators.clone();
                            merged_seps.extend(ri.separators.iter().cloned());
                            let mut merged_children = li.children.clone();
                            merged_children.extend(ri.children.iter().cloned());
                            left_node.data.store(Arc::new(NodeData::Internal(
                                InternalData {
                                    separators: merged_seps,
                                    children: merged_children,
                                    high_key: ri.high_key.clone(),
                                    right: ri.right.clone(),
                                },
                            )));
                            true
                        }
                    }
                    _ => false,
                }
            };

            if !merged {
                drop(pguard);
                return;
            }

            // Remove the absorbed sibling's separator and child entry.
            let mut new_seps = parent_seps;
            let mut new_children = parent_children;
            // The surviving left node's high_key is now the absorbed
            // sibling's high_key, so the parent's separator at left_idx
            // must be updated accordingly.
            new_seps[left_idx] = new_seps[right_idx].clone();
            new_seps.remove(right_idx);
            new_children.remove(right_idx);

            let new_count = new_children.len();
            let new_high = new_seps.last().cloned().unwrap_or(parent_high);
            parent
                .data
                .store(Arc::new(NodeData::Internal(InternalData {
                    separators: new_seps,
                    children: new_children,
                    high_key: new_high,
                    right: parent_right,
                })));
            drop(pguard);

            // Root collapse when the surviving root has a single child.
            if ancestors.is_empty() {
                if new_count == 1 {
                    let _root_lock = self.root_mu.lock().unwrap();
                    let cur = self.root.load_full();
                    if Arc::ptr_eq(&cur, &parent) {
                        let only_child = {
                            let s = parent.data.load_full();
                            match &*s {
                                NodeData::Internal(n) if n.children.len() == 1 => {
                                    Some(n.children[0].clone())
                                }
                                _ => None,
                            }
                        };
                        if let Some(c) = only_child {
                            self.root.store(c);
                        }
                    }
                }
                return;
            }

            if new_count >= MIN_OCCUPANCY {
                return;
            }
            // The parent itself underflows; continue merging upward.
            underfull = parent;
        }
    }
}

impl<K, V> Default for BLinkTree<K, V>
where
    K: Ord + Clone + Send + Sync + 'static,
    V: Clone + Send + Sync + 'static,
{
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Helpers for descent and node bookkeeping.
// ---------------------------------------------------------------------------

enum Step<K, V> {
    Found(Option<V>),
    Descend(Arc<Node<K, V>>),
}

enum FindAction<K, V> {
    Found,
    Down(Arc<Node<K, V>>),
    Stop,
}

// Walks the right-link chain at the current level while the predicate
// `should_advance(current_node_high_key)` returns `true` and a right-link
// is available. Returns the first node whose high key covers the search
// position (or which is rightmost at its level).
fn walk_right_at_level<K, V, F>(mut node: Arc<Node<K, V>>, should_advance: F) -> Arc<Node<K, V>>
where
    F: Fn(Option<&K>) -> bool,
{
    loop {
        let next_opt: Option<Arc<Node<K, V>>> = {
            let snap = node.data.load_full();
            let (hk, right) = match &*snap {
                NodeData::Leaf(l) => (l.high_key.as_ref(), l.right.clone()),
                NodeData::Internal(n) => (n.high_key.as_ref(), n.right.clone()),
            };
            if should_advance(hk) {
                right
            } else {
                None
            }
        };
        match next_opt {
            Some(n) => node = n,
            None => return node,
        }
    }
}

// Picks the child whose parent-recorded separator is the smallest one that
// covers the search key (`separator >= key` or `separator == +inf`). Because
// separators live in the parent and are immutable until the parent is
// updated, this rule selects the correct child even when the picked child
// has just split (and so its own `high_key` may be smaller than the
// separator). The descender will then follow right-links at the child's
// level to reach the new sibling that owns the search key's range.
fn pick_child<K, V>(node: &InternalData<K, V>, key: &K) -> Arc<Node<K, V>>
where
    K: Ord + Clone,
    V: Clone,
{
    for (i, sep) in node.separators.iter().enumerate() {
        match sep {
            None => return node.children[i].clone(),
            Some(s) if s >= key => return node.children[i].clone(),
            _ => continue,
        }
    }
    node.children
        .last()
        .expect("internal node has children")
        .clone()
}

// ---------------------------------------------------------------------------
// OwningGuard: a per-node latch guard that owns its `Arc<Node>` so the
// underlying `Mutex<()>` outlives the `MutexGuard`. This enables the
// child-before-parent latch coupling protocol without juggling explicit
// lifetimes across descent steps.
// ---------------------------------------------------------------------------

struct OwningGuard<K, V> {
    // Field order matters: `_guard` is dropped before `_node`, releasing the
    // mutex before its backing `Arc<Node>` is potentially released.
    _guard: MutexGuard<'static, ()>,
    _node: Arc<Node<K, V>>,
}

impl<K, V> OwningGuard<K, V> {
    fn new(node: Arc<Node<K, V>>) -> Self {
        // SAFETY: the `MutexGuard` borrows from `node.latch`; we keep `node`
        // alive in the same struct so the borrow remains valid for the
        // guard's entire lifetime. Field-drop order guarantees the guard is
        // released before the `Arc` is dropped.
        let guard: MutexGuard<'_, ()> = node.latch.lock().unwrap();
        let guard_static: MutexGuard<'static, ()> = unsafe { std::mem::transmute(guard) };
        OwningGuard {
            _guard: guard_static,
            _node: node,
        }
    }
}

// ---------------------------------------------------------------------------
// RwLockBTreeMap: reference baseline.
// ---------------------------------------------------------------------------

/// Reference baseline backed by `std::sync::RwLock<std::collections::BTreeMap<K, V>>`.
///
/// Exposes exactly the four inherent methods the benchmark harness uses, all
/// taking `&self` so an `Arc<RwLockBTreeMap<K, V>>` is shareable across
/// threads for the `mixed_concurrent` workload.
pub struct RwLockBTreeMap<K, V> {
    inner: RwLock<BTreeMap<K, V>>,
}

impl<K, V> RwLockBTreeMap<K, V>
where
    K: Ord + Clone + Send + Sync + 'static,
    V: Clone + Send + Sync + 'static,
{
    /// Constructs an empty baseline holding an empty `BTreeMap` behind an `RwLock`.
    pub fn new() -> Self {
        RwLockBTreeMap {
            inner: RwLock::new(BTreeMap::new()),
        }
    }

    /// Acquires the inner `RwLock` in write mode for the duration of the call
    /// and inserts or updates the mapping; returns the previous value bound
    /// to `key`, or `None` when the key was absent.
    pub fn insert(&self, key: K, value: V) -> Option<V> {
        let mut guard = self.inner.write().unwrap();
        guard.insert(key, value)
    }

    /// Acquires the inner `RwLock` in read mode for the duration of the call
    /// and returns `Some(value.clone())` when `key` is present, `None`
    /// otherwise.
    pub fn get(&self, key: &K) -> Option<V> {
        let guard = self.inner.read().unwrap();
        guard.get(key).cloned()
    }

    /// Acquires the inner `RwLock` in write mode and removes the mapping for
    /// `key`, returning the removed value, or `None`.
    pub fn remove(&self, key: &K) -> Option<V> {
        let mut guard = self.inner.write().unwrap();
        guard.remove(key)
    }
}

impl<K, V> Default for RwLockBTreeMap<K, V>
where
    K: Ord + Clone + Send + Sync + 'static,
    V: Clone + Send + Sync + 'static,
{
    fn default() -> Self {
        Self::new()
    }
}
