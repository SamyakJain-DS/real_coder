import path from 'path';
// @ts-ignore — node:sqlite is a built-in available in Node 22; no npm package needed
import { DatabaseSync } from 'node:sqlite';

const dbPath = path.join(__dirname, '../../adventure.db');
const rawDb = new DatabaseSync(dbPath);

// Thin shim that exposes the sqlite3 callback-style API used throughout the codebase.
export const db = {
  serialize(fn: () => void) {
    fn();
  },

  run(
    sql: string,
    params: any[] | ((this: { lastID: number; changes: number }, err: Error | null) => void) = [],
    callback?: (this: { lastID: number; changes: number }, err: Error | null) => void
  ) {
    const cb   = typeof params === 'function' ? params : callback;
    const args = typeof params === 'function' ? [] : params;
    try {
      const info = rawDb.prepare(sql).run(...args);
      if (cb) cb.call({ lastID: Number(info.lastInsertRowid), changes: info.changes }, null);
    } catch (e: any) {
      if (cb) cb.call({ lastID: 0, changes: 0 }, e);
    }
  },

  get(
    sql: string,
    params: any[] | ((err: Error | null, row: any) => void) = [],
    callback?: (err: Error | null, row: any) => void
  ) {
    const cb   = typeof params === 'function' ? params : callback;
    const args = typeof params === 'function' ? [] : params;
    try {
      const row = rawDb.prepare(sql).get(...args);
      if (cb) cb(null, row != null ? { ...row } : null);
    } catch (e: any) {
      if (cb) cb(e, null);
    }
  },

  all(
    sql: string,
    params: any[] | ((err: Error | null, rows: any[]) => void) = [],
    callback?: (err: Error | null, rows: any[]) => void
  ) {
    const cb   = typeof params === 'function' ? params : callback;
    const args = typeof params === 'function' ? [] : params;
    try {
      const rows = rawDb.prepare(sql).all(...args) as any[];
      if (cb) cb(null, rows.map(r => ({ ...r })));
    } catch (e: any) {
      if (cb) cb(e, []);
    }
  },

  prepare(sql: string) {
    return {
      run(...args: any[]) {
        const last = args[args.length - 1];
        const hasCallback = typeof last === 'function';
        const params = hasCallback ? args.slice(0, -1) : args;
        try {
          rawDb.prepare(sql).run(...params);
          if (hasCallback) last(null);
        } catch (e: any) {
          if (hasCallback) last(e);
        }
      },
      finalize(cb?: (err: Error | null) => void) {
        if (cb) cb(null);
      }
    };
  }
};

export function initializeDatabase(): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      rawDb.exec(`
        CREATE TABLE IF NOT EXISTS trips (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          activityType TEXT NOT NULL,
          date TEXT NOT NULL,
          guideName TEXT NOT NULL,
          difficulty TEXT NOT NULL,
          groupSizeLimit INTEGER NOT NULL,
          price REAL NOT NULL,
          description TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS bookings (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tripId INTEGER NOT NULL,
          customerName TEXT NOT NULL,
          email TEXT NOT NULL,
          groupSize INTEGER NOT NULL,
          dietaryNotes TEXT,
          medicalNotes TEXT,
          waiverAcknowledged INTEGER NOT NULL,
          confirmed INTEGER DEFAULT 0,
          FOREIGN KEY (tripId) REFERENCES trips(id)
        );
        CREATE TABLE IF NOT EXISTS reviews (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tripId INTEGER NOT NULL,
          rating INTEGER NOT NULL,
          reviewText TEXT NOT NULL,
          FOREIGN KEY (tripId) REFERENCES trips(id)
        );
      `);
      resolve();
    } catch (e: any) {
      reject(e);
    }
  });
}

export function getTodayDate(): string {
  const today = new Date();
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
}