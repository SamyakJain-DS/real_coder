import { db } from '../database/db';
import { sampleTrips, sampleBookings, sampleReviews } from '../data/sampleData';

export function loadSampleData(): Promise<void> {
  return new Promise((resolve, reject) => {
    db.get('SELECT COUNT(*) as count FROM trips', (err, row: any) => {
      if (err) {
        reject(err);
        return;
      }

      // Only load sample data if database is empty
      if (row.count > 0) {
        resolve();
        return;
      }

      db.serialize(() => {
        const tripStmt = db.prepare('INSERT INTO trips (activityType, date, guideName, difficulty, groupSizeLimit, price, description) VALUES (?, ?, ?, ?, ?, ?, ?)');
        
        sampleTrips.forEach(trip => {
          tripStmt.run(trip.activityType, trip.date, trip.guideName, trip.difficulty, trip.groupSizeLimit, trip.price, trip.description);
        });
        
        tripStmt.finalize();

        const bookingStmt = db.prepare('INSERT INTO bookings (tripId, customerName, email, groupSize, dietaryNotes, medicalNotes, waiverAcknowledged, confirmed) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        
        sampleBookings.forEach(booking => {
          bookingStmt.run(booking.tripId, booking.customerName, booking.email, booking.groupSize, booking.dietaryNotes, booking.medicalNotes, booking.waiverAcknowledged, booking.confirmed);
        });
        
        bookingStmt.finalize();

        const reviewStmt = db.prepare('INSERT INTO reviews (tripId, rating, reviewText) VALUES (?, ?, ?)');
        
        sampleReviews.forEach(review => {
          reviewStmt.run(review.tripId, review.rating, review.reviewText);
        });
        
        reviewStmt.finalize(() => {
          resolve();
        });
      });
    });
  });
}
