import { db } from '../database/db';
import { sampleTrips, sampleBookings, sampleReviews } from '../data/sampleData';

export function loadSampleData(): Promise<void> {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // Always clear existing data so a stale adventure.db never causes
      // mismatched sample data (delete in FK-safe order)
      db.run('DELETE FROM reviews');
      db.run('DELETE FROM bookings');
      db.run('DELETE FROM trips');

      const tripStmt = db.prepare(
        'INSERT INTO trips (activityType, date, guideName, difficulty, groupSizeLimit, price, description) VALUES (?, ?, ?, ?, ?, ?, ?)'
      );
      sampleTrips.forEach(trip => {
        tripStmt.run(
          trip.activityType, trip.date, trip.guideName,
          trip.difficulty, trip.groupSizeLimit, trip.price, trip.description
        );
      });
      tripStmt.finalize();

      const bookingStmt = db.prepare(
        'INSERT INTO bookings (tripId, customerName, email, groupSize, dietaryNotes, medicalNotes, waiverAcknowledged, confirmed) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      );
      sampleBookings.forEach(booking => {
        bookingStmt.run(
          booking.tripId, booking.customerName, booking.email,
          booking.groupSize, booking.dietaryNotes, booking.medicalNotes,
          booking.waiverAcknowledged, booking.confirmed
        );
      });
      bookingStmt.finalize();

      const reviewStmt = db.prepare(
        'INSERT INTO reviews (tripId, rating, reviewText) VALUES (?, ?, ?)'
      );
      sampleReviews.forEach(review => {
        reviewStmt.run(review.tripId, review.rating, review.reviewText);
      });
      reviewStmt.finalize(() => {
        resolve();
      });
    });
  });
}