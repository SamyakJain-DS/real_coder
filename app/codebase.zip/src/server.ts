import express from 'express';
import cors from 'cors';
import { initializeDatabase } from './database/db';
import { loadSampleData } from './database/seed';
import tripsRouter from './api/trips';
import bookingsRouter from './api/bookings';
import reviewsRouter from './api/reviews';
import analyticsRouter from './api/analytics';

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// API routes
app.use('/api', tripsRouter);
app.use('/api', bookingsRouter);
app.use('/api', reviewsRouter);
app.use('/api', analyticsRouter);

// Serve static files in production
app.use(express.static('dist/public'));

// Initialize database and start server
async function start() {
  try {
    await initializeDatabase();
    await loadSampleData();
    
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();

export default app;
