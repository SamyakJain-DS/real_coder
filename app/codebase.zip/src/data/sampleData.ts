export const sampleTrips = [
  {
    activityType: 'Hiking',
    date: '2026-05-15',
    guideName: 'Sarah Mountain',
    difficulty: 'Moderate',
    groupSizeLimit: 12,
    price: 85.00,
    description: 'Scenic mountain trail with breathtaking views of the valley. Perfect for intermediate hikers looking for a rewarding day hike.'
  },
  {
    activityType: 'Kayaking',
    date: '2026-05-20',
    guideName: 'Mike Rivers',
    difficulty: 'Easy',
    groupSizeLimit: 8,
    price: 65.00,
    description: 'Peaceful river kayaking experience suitable for beginners. Explore calm waters and enjoy local wildlife.'
  },
  {
    activityType: 'Climbing',
    date: '2026-06-01',
    guideName: 'Alex Stone',
    difficulty: 'Hard',
    groupSizeLimit: 6,
    price: 120.00,
    description: 'Challenging rock climbing adventure for experienced climbers. Technical routes with stunning summit views.'
  },
  {
    activityType: 'Hiking',
    date: '2026-03-10',
    guideName: 'Sarah Mountain',
    difficulty: 'Easy',
    groupSizeLimit: 15,
    price: 55.00,
    description: 'Gentle nature walk through forest trails. Great for families and beginners wanting to explore the outdoors.'
  },
  {
    activityType: 'Kayaking',
    date: '2026-02-25',
    guideName: 'Mike Rivers',
    difficulty: 'Moderate',
    groupSizeLimit: 10,
    price: 75.00,
    description: 'Coastal kayaking with opportunities to see seals and seabirds. Some experience recommended.'
  },
  {
    activityType: 'Climbing',
    date: '2026-01-15',
    guideName: 'Alex Stone',
    difficulty: 'Moderate',
    groupSizeLimit: 8,
    price: 95.00,
    description: 'Indoor climbing session followed by outdoor bouldering. Perfect for those building their climbing skills.'
  }
];

export const sampleBookings = [
  {
    tripId: 4,
    customerName: 'John Doe',
    email: 'john@example.com',
    groupSize: 2,
    dietaryNotes: 'Vegetarian',
    medicalNotes: null,
    waiverAcknowledged: 1,
    confirmed: 1
  },
  {
    tripId: 5,
    customerName: 'Jane Smith',
    email: 'jane@example.com',
    groupSize: 3,
    dietaryNotes: null,
    medicalNotes: 'Allergic to bees',
    waiverAcknowledged: 1,
    confirmed: 1
  },
  {
    tripId: 6,
    customerName: 'Bob Wilson',
    email: 'bob@example.com',
    groupSize: 1,
    dietaryNotes: null,
    medicalNotes: null,
    waiverAcknowledged: 1,
    confirmed: 1
  }
];

export const sampleReviews = [
  {
    tripId: 4,
    rating: 5,
    reviewText: 'Amazing experience! Sarah was a wonderful guide and the trails were beautiful.'
  },
  {
    tripId: 5,
    rating: 4,
    reviewText: 'Great kayaking trip. Saw lots of wildlife. Would recommend bringing binoculars!'
  },
  {
    tripId: 6,
    rating: 5,
    reviewText: 'Alex is an excellent instructor. Learned so much and had a blast climbing!'
  }
];
