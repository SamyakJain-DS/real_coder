"""
Report generator for the housing code enforcement analytics pipeline.
Renders a self-contained HTML planning report with embedded charts.
"""
import base64
import io
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
from jinja2 import Environment, BaseLoader


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Housing Code Enforcement Analytics Report</title>
<style>
  body { font-family: Arial, sans-serif; max-width: 1100px; margin: 0 auto; padding: 20px; background: #f8f9fa; color: #333; }
  h1 { color: #1a1a2e; border-bottom: 3px solid #e94560; padding-bottom: 10px; }
  h2 { color: #16213e; margin-top: 30px; }
  section { background: #fff; border-radius: 8px; padding: 24px; margin-bottom: 28px; box-shadow: 0 2px 6px rgba(0,0,0,0.08); }
  .chart-container { text-align: center; margin: 20px 0; }
  img { max-width: 100%; border-radius: 4px; }
  .narrative { background: #f0f4ff; border-left: 4px solid #3a86ff; padding: 16px; border-radius: 4px; margin-top: 16px; line-height: 1.7; }
  table { border-collapse: collapse; width: 100%; font-size: 0.9em; }
  th { background: #16213e; color: #fff; padding: 8px 12px; text-align: left; }
  td { padding: 7px 12px; border-bottom: 1px solid #e0e0e0; }
  tr:nth-child(even) { background: #f7f7f7; }
  .badge-nc { background: #e94560; color: #fff; border-radius: 10px; padding: 2px 8px; font-size: 0.8em; }
  .badge-inc { background: #3a86ff; color: #fff; border-radius: 10px; padding: 2px 8px; font-size: 0.8em; }
</style>
</head>
<body>
<h1>Housing Code Enforcement Analytics Report</h1>
<p style="color:#666; font-size:0.95em;">Generated for the Housing Inspection Division &mdash; City Council Budget Planning</p>

<section id="landlord-compliance">
  <h2>Landlord Compliance Classification</h2>
  <div class="chart-container">
    <img src="data:image/png;base64,{{ charts.landlord }}" alt="Landlord Compliance Chart"/>
  </div>
  <p>Analysis of {{ n_landlords }} landlord portfolios reveals compliance patterns across the five-year enforcement period.
  Landlords at or above the 75th percentile of repeat violation rate are classified as <strong>Systematic Noncompliant</strong>;
  all others are classified as <strong>Incidental</strong>.</p>
</section>

<section id="neighborhood-decline">
  <h2>Neighborhood Decline Attribution</h2>
  <div class="chart-container">
    <img src="data:image/png;base64,{{ charts.neighborhood }}" alt="Neighborhood Decline Chart"/>
  </div>
  <p>Neighborhood decline indices and their correlation with ownership-pattern features
  across {{ n_neighborhoods }} neighborhoods. Higher decline index indicates worsening housing conditions.</p>
</section>

<section id="enforcement-effectiveness">
  <h2>Enforcement Tool Effectiveness</h2>
  <div class="chart-container">
    <img src="data:image/png;base64,{{ charts.enforcement }}" alt="Enforcement Effectiveness Chart"/>
  </div>
  <p>Log-odds coefficients from logistic regression model estimating probability of compliance
  within the 180-day follow-up window. Warning notice is the reference category (coefficient = 0).</p>
</section>

<section id="budget-recommendation">
  <h2>Budget Recommendation</h2>
  <div class="chart-container">
    <img src="data:image/png;base64,{{ charts.budget }}" alt="Budget Recommendation Chart"/>
  </div>
  <div class="narrative">
    <p>{{ budget_narrative }}</p>
  </div>
</section>
</body>
</html>
"""


def _fig_to_base64(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", dpi=100)
    buf.seek(0)
    encoded = base64.b64encode(buf.read()).decode("utf-8")
    plt.close(fig)
    return encoded


def _make_landlord_chart(landlord_df: pd.DataFrame) -> str:
    nc = (landlord_df["compliance_classification"] == "systematic_noncompliant").sum()
    inc = (landlord_df["compliance_classification"] == "incidental").sum()

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle("Landlord Compliance Classification", fontsize=14, fontweight="bold")

    # Pie chart
    ax = axes[0]
    colors = ["#e94560", "#3a86ff"]
    ax.pie([nc, inc], labels=["Systematic\nNoncompliant", "Incidental"],
           colors=colors, autopct="%1.1f%%", startangle=90,
           wedgeprops={"edgecolor": "white", "linewidth": 1.5})
    ax.set_title("Classification Distribution")

    # Scatter: compliance_score vs repeat_violation_rate
    ax2 = axes[1]
    color_map = landlord_df["compliance_classification"].map(
        {"systematic_noncompliant": "#e94560", "incidental": "#3a86ff"}
    )
    ax2.scatter(
        landlord_df["repeat_violation_rate"],
        landlord_df["compliance_score"],
        c=color_map,
        alpha=0.6,
        edgecolors="none",
        s=40,
    )
    ax2.set_xlabel("Repeat Violation Rate")
    ax2.set_ylabel("Compliance Score")
    ax2.set_title("Compliance Score vs Repeat Violation Rate")
    patch_nc = mpatches.Patch(color="#e94560", label="Systematic Noncompliant")
    patch_inc = mpatches.Patch(color="#3a86ff", label="Incidental")
    ax2.legend(handles=[patch_nc, patch_inc], fontsize=9)

    plt.tight_layout()
    return _fig_to_base64(fig)


def _make_neighborhood_chart(neighborhood_df: pd.DataFrame) -> str:
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle("Neighborhood Decline vs Ownership Pattern Features", fontsize=13, fontweight="bold")

    features = [
        ("noncompliant_ownership_share", "Noncompliant Ownership Share", "#e94560"),
        ("absentee_owner_ratio", "Absentee Owner Ratio", "#ff9f43"),
        ("portfolio_concentration_hhi", "Portfolio Concentration (HHI)", "#1dd1a1"),
    ]

    for ax, (col, label, color) in zip(axes, features):
        ax.scatter(
            neighborhood_df[col],
            neighborhood_df["decline_index"],
            color=color,
            alpha=0.8,
            s=60,
            edgecolors="white",
            linewidths=0.5,
        )
        # Trend line
        x = neighborhood_df[col].values
        y = neighborhood_df["decline_index"].values
        if x.std() > 0:
            m, b = np.polyfit(x, y, 1)
            x_line = np.linspace(x.min(), x.max(), 100)
            ax.plot(x_line, m * x_line + b, "--", color="#555", linewidth=1.2, alpha=0.8)
        ax.set_xlabel(label, fontsize=9)
        ax.set_ylabel("Decline Index", fontsize=9)
        ax.set_title(label, fontsize=9)
        ax.tick_params(labelsize=8)

    plt.tight_layout()
    return _fig_to_base64(fig)


def _make_enforcement_chart(enforcement_results: dict) -> str:
    tool_effects = enforcement_results["tool_effects"]
    tools = ["warning_notice", "civil_fine", "court_referral", "license_suspension"]
    tool_labels = ["Warning\nNotice", "Civil\nFine", "Court\nReferral", "License\nSuspension"]

    effects = [tool_effects[t]["effect_size"] for t in tools]
    ci_lower = [tool_effects[t]["confidence_interval"][0] for t in tools]
    ci_upper = [tool_effects[t]["confidence_interval"][1] for t in tools]
    errors_lower = [e - l for e, l in zip(effects, ci_lower)]
    errors_upper = [u - e for e, u in zip(effects, ci_upper)]

    fig, ax = plt.subplots(figsize=(9, 5))

    colors = ["#adb5bd", "#3a86ff", "#ff9f43", "#e94560"]
    y_pos = range(len(tools))

    ax.barh(y_pos, effects, xerr=[errors_lower, errors_upper],
            color=colors, edgecolor="white", capsize=5, alpha=0.85,
            error_kw={"ecolor": "#333", "elinewidth": 1.5})

    ax.set_yticks(list(y_pos))
    ax.set_yticklabels(tool_labels)
    ax.axvline(0, color="#333", linewidth=1, linestyle="--", alpha=0.7)
    ax.set_xlabel("Log-Odds Coefficient (relative to Warning Notice)", fontsize=10)
    ax.set_title("Enforcement Tool Effect on Compliance\n(Logistic Regression Coefficients with 95% CI)", fontsize=11)
    ax.tick_params(axis="y", labelsize=9)

    plt.tight_layout()
    return _fig_to_base64(fig)


def _make_budget_chart(landlord_df: pd.DataFrame, neighborhood_df: pd.DataFrame, enforcement_results: dict) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle("Budget Priority Summary", fontsize=13, fontweight="bold")

    # Left: Top 10 landlords by compliance_score
    ax = axes[0]
    top10 = landlord_df.nlargest(10, "compliance_score")
    colors = ["#e94560" if c == "systematic_noncompliant" else "#3a86ff"
              for c in top10["compliance_classification"]]
    ax.barh(range(10), top10["compliance_score"].values, color=colors)
    ax.set_yticks(range(10))
    ax.set_yticklabels([f"Landlord {lid}" for lid in top10.index], fontsize=7)
    ax.set_xlabel("Compliance Score")
    ax.set_title("Top 10 Highest-Risk Landlords")
    patch_nc = mpatches.Patch(color="#e94560", label="Systematic Noncompliant")
    patch_inc = mpatches.Patch(color="#3a86ff", label="Incidental")
    ax.legend(handles=[patch_nc, patch_inc], fontsize=8)

    # Right: Top 5 neighborhoods by decline_index
    ax2 = axes[1]
    top_nbhd = neighborhood_df.nlargest(5, "decline_index")
    driver_colors = {
        "noncompliant_ownership": "#e94560",
        "absentee_ownership": "#ff9f43",
        "portfolio_concentration": "#1dd1a1",
    }
    bar_colors = [driver_colors.get(d, "#888") for d in top_nbhd["primary_decline_driver"]]
    ax2.bar(range(5), top_nbhd["decline_index"].values, color=bar_colors)
    ax2.set_xticks(range(5))
    ax2.set_xticklabels([f"Nbhd {nid}" for nid in top_nbhd.index], fontsize=8)
    ax2.set_ylabel("Decline Index")
    ax2.set_title("Top 5 Declining Neighborhoods")
    handles = [mpatches.Patch(color=c, label=k.replace("_", " ").title()) for k, c in driver_colors.items()]
    ax2.legend(handles=handles, fontsize=7)

    plt.tight_layout()
    return _fig_to_base64(fig)


def _build_budget_narrative(landlord_df: pd.DataFrame, neighborhood_df: pd.DataFrame, enforcement_results: dict) -> str:
    tool_effects = enforcement_results["tool_effects"]
    non_ref_tools = {k: v for k, v in tool_effects.items() if k != "warning_notice"}
    best_tool = max(non_ref_tools, key=lambda t: non_ref_tools[t]["effect_size"])
    best_tool_label = best_tool.replace("_", " ").title()

    nc_count = (landlord_df["compliance_classification"] == "systematic_noncompliant").sum()
    top_nbhd = neighborhood_df.nlargest(3, "decline_index").index.tolist()
    top_nbhd_str = ", ".join(top_nbhd)
    primary_driver = neighborhood_df["primary_decline_driver"].mode().iloc[0].replace("_", " ")

    narrative = (
        f"Our analysis of five years of enforcement data indicates that <strong>{best_tool_label}</strong> "
        f"is the highest-impact enforcement tool, showing the strongest association with landlord compliance "
        f"within the 180-day follow-up window compared to warning notices alone. "
        f"The {nc_count} landlords classified as <em>Systematic Noncompliant</em> should be prioritized for "
        f"escalated enforcement actions, as their portfolios demonstrate persistent repeat violations that "
        f"disproportionately affect housing quality across the city. "
        f"The neighborhoods most at risk of continued decline are {top_nbhd_str}, where the primary driver "
        f"of deteriorating condition scores is <strong>{primary_driver}</strong>; directing inspection resources "
        f"and compliance enforcement toward these areas will deliver the greatest return on the enforcement budget. "
        f"We recommend allocating a majority of enforcement resources to {best_tool_label} actions targeting "
        f"systematic noncompliant landlords in the highest-decline neighborhoods identified above."
    )
    return narrative


def generate_report(
    landlord_df: pd.DataFrame,
    neighborhood_df: pd.DataFrame,
    enforcement_results: dict,
    output_path: str,
) -> str:
    """
    Render a self-contained HTML planning report.

    Args:
        landlord_df: Output of classify_landlord_compliance.
        neighborhood_df: Output of attribute_neighborhood_decline.
        enforcement_results: Output of model_enforcement_effectiveness.
        output_path: File path to write the HTML report to.

    Returns:
        Absolute path to the written HTML file.
    """
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    charts = {
        "landlord": _make_landlord_chart(landlord_df),
        "neighborhood": _make_neighborhood_chart(neighborhood_df),
        "enforcement": _make_enforcement_chart(enforcement_results),
        "budget": _make_budget_chart(landlord_df, neighborhood_df, enforcement_results),
    }

    budget_narrative = _build_budget_narrative(landlord_df, neighborhood_df, enforcement_results)

    env = Environment(loader=BaseLoader())
    template = env.from_string(HTML_TEMPLATE)
    html_content = template.render(
        charts=charts,
        n_landlords=len(landlord_df),
        n_neighborhoods=len(neighborhood_df),
        budget_narrative=budget_narrative,
    )

    abs_path = os.path.abspath(output_path)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    return abs_path
