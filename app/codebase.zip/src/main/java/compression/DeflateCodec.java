package compression;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.PriorityQueue;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

/**
 * DEFLATE-style codec: LZ77 followed by dual-tree Huffman coding.
 *
 * Token stream encoding:
 *   - Literals are symbols 0-255 in the literal-length alphabet.
 *   - Matches produce symbol (256 + length) in the literal-length alphabet,
 *     followed by the distance value in the distance alphabet.
 *   - Symbol 256 = end-of-block marker.
 *
 * Format:
 *   4-byte original length
 *   Literal-length freq table: 2-byte count, then (1-byte symbol, 4-byte freq) per entry
 *   Distance freq table:       2-byte count, then (1-byte lo + 1-byte hi = 2-byte symbol, 4-byte freq) per entry
 *   1-byte padding count
 *   Bit-packed token stream
 */
public class DeflateCodec {

    private static final int DEFAULT_WINDOW_SIZE = 32768;
    // End-of-block marker in literal-length alphabet
    private static final int END_OF_BLOCK = 256;

    private CompressionStats stats = new CompressionStats();

    public DeflateCodec() {}

    // ---- Huffman tree node ----
    private static class Node implements Comparable<Node> {
        int symbol; // -1 for internal
        long freq;
        Node left, right;

        Node(int symbol, long freq) {
            this.symbol = symbol;
            this.freq = freq;
        }

        Node(Node left, Node right) {
            this.symbol = -1;
            this.freq = left.freq + right.freq;
            this.left = left;
            this.right = right;
        }

        boolean isLeaf() {
            return left == null && right == null;
        }

        @Override
        public int compareTo(Node other) {
            return Long.compare(this.freq, other.freq);
        }
    }

    private Node buildTree(Map<Integer, Long> freqs) {
        PriorityQueue<Node> pq = new PriorityQueue<>();
        for (Map.Entry<Integer, Long> e : freqs.entrySet()) {
            if (e.getValue() > 0) {
                pq.add(new Node(e.getKey(), e.getValue()));
            }
        }
        if (pq.isEmpty()) return null;
        if (pq.size() == 1) {
            Node single = pq.poll();
            // Create a tree with left=real symbol, right=dummy with same symbol
            return new Node(single, new Node(single.symbol, 0));
        }
        while (pq.size() > 1) {
            Node a = pq.poll();
            Node b = pq.poll();
            pq.add(new Node(a, b));
        }
        return pq.poll();
    }

    private void buildCodes(Node node, String prefix, Map<Integer, String> codes) {
        if (node == null) return;
        if (node.isLeaf()) {
            codes.put(node.symbol, prefix.isEmpty() ? "0" : prefix);
            return;
        }
        buildCodes(node.left, prefix + "0", codes);
        buildCodes(node.right, prefix + "1", codes);
    }

    // ---- LZ77 token representation ----
    private static class Token {
        boolean isLiteral;
        int value;   // literal byte if isLiteral, else match length
        int distance; // only for match

        static Token literal(int v) {
            Token t = new Token();
            t.isLiteral = true;
            t.value = v;
            return t;
        }

        static Token match(int length, int distance) {
            Token t = new Token();
            t.isLiteral = false;
            t.value = length;
            t.distance = distance;
            return t;
        }
    }

    // ---- LZ77 helpers ----
    private int[] findLongestMatch(byte[] input, int pos, int windowSize) {
        int n = input.length;
        int windowStart = Math.max(0, pos - windowSize);
        int bestLen = 0;
        int bestDist = 0;
        int maxMatchLen = Math.min(65535, n - pos);

        for (int j = windowStart; j < pos; j++) {
            int matchLen = 0;
            while (matchLen < maxMatchLen && input[j + matchLen] == input[pos + matchLen]) {
                matchLen++;
            }
            if (matchLen > bestLen) {
                bestLen = matchLen;
                bestDist = pos - j;
            }
        }

        if (bestLen < 3) return new int[]{0, 0};
        return new int[]{bestLen, bestDist};
    }

    private List<Token> lz77Tokenize(byte[] input) {
        List<Token> tokens = new ArrayList<>();
        int i = 0;
        int n = input.length;

        while (i < n) {
            int[] bestMatch = findLongestMatch(input, i, DEFAULT_WINDOW_SIZE);
            int bestLen = bestMatch[0];
            int bestDist = bestMatch[1];

            if (bestLen >= 3) {
                boolean usedLazy = false;
                if (i + 1 < n) {
                    int[] nextMatch = findLongestMatch(input, i + 1, DEFAULT_WINDOW_SIZE);
                    if (nextMatch[0] > bestLen) {
                        tokens.add(Token.literal(input[i] & 0xFF));
                        i++;
                        tokens.add(Token.match(nextMatch[0], nextMatch[1]));
                        i += nextMatch[0];
                        usedLazy = true;
                    }
                }
                if (!usedLazy) {
                    tokens.add(Token.match(bestLen, bestDist));
                    i += bestLen;
                }
            } else {
                tokens.add(Token.literal(input[i] & 0xFF));
                i++;
            }
        }

        return tokens;
    }

    // ---- Write a freq table ----
    private void writeFreqTable(DataOutputStream out, Map<Integer, Long> freqs, boolean wide) throws IOException {
        // Count non-zero
        int count = 0;
        for (long v : freqs.values()) if (v > 0) count++;
        out.writeShort(count);
        for (Map.Entry<Integer, Long> e : freqs.entrySet()) {
            if (e.getValue() > 0) {
                if (wide) {
                    out.writeShort(e.getKey()); // 2-byte symbol for distance (can be > 255)
                } else {
                    out.writeShort(e.getKey()); // 2-byte for LL too (length+256 can be > 255)
                }
                out.writeInt(e.getValue().intValue());
            }
        }
    }

    // ---- Read a freq table ----
    private Map<Integer, Long> readFreqTable(DataInputStream in) throws IOException {
        Map<Integer, Long> freqs = new HashMap<>();
        int count = in.readUnsignedShort();
        for (int i = 0; i < count; i++) {
            int sym = in.readUnsignedShort();
            long freq = in.readInt() & 0xFFFFFFFFL;
            freqs.put(sym, freq);
        }
        return freqs;
    }

    public byte[] encode(byte[] input) {
        long startTime = System.currentTimeMillis();

        // Step 1: LZ77 tokenize
        List<Token> tokens = lz77Tokenize(input);

        // Step 2: Build frequency tables
        Map<Integer, Long> llFreqs = new HashMap<>(); // literal-length
        Map<Integer, Long> distFreqs = new HashMap<>(); // distance

        // Always include end-of-block
        llFreqs.put(END_OF_BLOCK, 1L);

        for (Token t : tokens) {
            if (t.isLiteral) {
                llFreqs.merge(t.value, 1L, Long::sum);
            } else {
                // Match: literal-length symbol = 256 + length
                int llSym = 256 + t.value;
                llFreqs.merge(llSym, 1L, Long::sum);
                distFreqs.merge(t.distance, 1L, Long::sum);
            }
        }

        // If no distances, add dummy to ensure tree can be built
        if (distFreqs.isEmpty()) {
            distFreqs.put(0, 0L);
        }

        // Step 3: Build Huffman trees
        Node llRoot = buildTree(llFreqs);
        Node distRoot = buildTree(distFreqs);

        Map<Integer, String> llCodes = new HashMap<>();
        Map<Integer, String> distCodes = new HashMap<>();
        buildCodes(llRoot, "", llCodes);
        buildCodes(distRoot, "", distCodes);

        // Step 4: Encode token stream as bits
        StringBuilder bits = new StringBuilder();
        for (Token t : tokens) {
            if (t.isLiteral) {
                bits.append(llCodes.get(t.value));
            } else {
                int llSym = 256 + t.value;
                bits.append(llCodes.get(llSym));
                bits.append(distCodes.get(t.distance));
            }
        }
        // End-of-block
        bits.append(llCodes.get(END_OF_BLOCK));

        // Pad to byte boundary
        int paddingBits = (8 - (bits.length() % 8)) % 8;
        for (int i = 0; i < paddingBits; i++) bits.append('0');

        // Step 5: Serialize
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(baos);

        try {
            out.writeInt(input.length);
            writeFreqTable(out, llFreqs, false);
            writeFreqTable(out, distFreqs, false);
            out.writeByte(paddingBits);

            String bitsStr = bits.toString();
            int totalBits = bitsStr.length();
            for (int i = 0; i < totalBits; i += 8) {
                out.writeByte(Integer.parseInt(bitsStr.substring(i, i + 8), 2));
            }

            out.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        byte[] encoded = baos.toByteArray();
        long endTime = System.currentTimeMillis();

        stats = new CompressionStats();
        stats.originalSize = input.length;
        stats.compressedSize = encoded.length;
        stats.compressionRatio = (stats.compressedSize == 0) ? 0.0 : (double) stats.originalSize / stats.compressedSize;
        stats.encodingTimeMs = endTime - startTime;
        stats.decodingTimeMs = 0;

        return encoded;
    }

    public byte[] decode(byte[] encoded) {
        long startTime = System.currentTimeMillis();

        ByteArrayInputStream bais = new ByteArrayInputStream(encoded);
        DataInputStream in = new DataInputStream(bais);

        byte[] result;
        try {
            int originalLength = in.readInt();

            // Read freq tables and rebuild trees
            Map<Integer, Long> llFreqs = readFreqTable(in);
            Map<Integer, Long> distFreqs = readFreqTable(in);

            Node llRoot = buildTree(llFreqs);
            Node distRoot = buildTree(distFreqs);

            int paddingBits = in.readUnsignedByte();
            byte[] compressedBytes = in.readAllBytes();

            // Decode bit stream
            result = new byte[originalLength];
            int outPos = 0;

            int totalBits = compressedBytes.length * 8 - paddingBits;
            int bitIndex = 0;

            Node llCurrent = llRoot;
            boolean done = false;

            while (!done && bitIndex <= totalBits) {
                // Read LL symbol
                while (llCurrent != null && !llCurrent.isLeaf() && bitIndex < totalBits) {
                    int bit = readBit(compressedBytes, bitIndex++);
                    llCurrent = (bit == 0) ? llCurrent.left : llCurrent.right;
                }

                if (llCurrent == null || !llCurrent.isLeaf()) break;

                int llSym = llCurrent.symbol;
                llCurrent = llRoot;

                if (llSym == END_OF_BLOCK) {
                    done = true;
                } else if (llSym < 256) {
                    // Literal
                    if (outPos < originalLength) {
                        result[outPos++] = (byte) llSym;
                    }
                } else {
                    // Match: read distance
                    int length = llSym - 256;

                    Node distCurrent = distRoot;
                    while (distCurrent != null && !distCurrent.isLeaf() && bitIndex < totalBits) {
                        int bit = readBit(compressedBytes, bitIndex++);
                        distCurrent = (bit == 0) ? distCurrent.left : distCurrent.right;
                    }

                    if (distCurrent == null || !distCurrent.isLeaf()) break;
                    int distance = distCurrent.symbol;

                    // Copy match bytes
                    int startPos = outPos - distance;
                    for (int k = 0; k < length && outPos < originalLength; k++) {
                        result[outPos] = result[startPos + k];
                        outPos++;
                    }
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        long endTime = System.currentTimeMillis();

        stats = new CompressionStats();
        stats.originalSize = result.length;
        stats.compressedSize = encoded.length;
        stats.compressionRatio = (stats.compressedSize == 0) ? 0.0 : (double) stats.originalSize / stats.compressedSize;
        stats.encodingTimeMs = 0;
        stats.decodingTimeMs = endTime - startTime;

        return result;
    }

    private int readBit(byte[] data, int bitIndex) {
        int byteIndex = bitIndex / 8;
        int bitPos = 7 - (bitIndex % 8);
        return (data[byteIndex] >> bitPos) & 1;
    }

    public CompressionStats getStats() {
        return stats;
    }
}
