package compression;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.PriorityQueue;
import java.util.HashMap;
import java.util.Map;

/**
 * Huffman coding compression codec.
 *
 * Encoding format:
 *   - 4-byte big-endian original length
 *   - 2-byte big-endian number of distinct symbols in tree
 *   - For each symbol: 1-byte symbol value, 4-byte big-endian frequency
 *   - Bit-packed encoded data (padded to byte boundary)
 *   - 1-byte padding count (number of padding bits at end of last byte)
 *
 * Special case: single unique symbol uses a special 1-bit code (code = "0").
 */
public class HuffmanCodec {

    private CompressionStats stats = new CompressionStats();

    public HuffmanCodec() {}

    // Huffman tree node
    private static class Node implements Comparable<Node> {
        int symbol; // -1 for internal nodes
        long freq;
        Node left, right;

        Node(int symbol, long freq) {
            this.symbol = symbol;
            this.freq = freq;
        }

        Node(Node left, Node right) {
            this.symbol = -1;
            this.freq = left.freq + right.freq;
            this.left = left;
            this.right = right;
        }

        boolean isLeaf() {
            return left == null && right == null;
        }

        @Override
        public int compareTo(Node other) {
            return Long.compare(this.freq, other.freq);
        }
    }

    private Node buildTree(long[] freqs) {
        PriorityQueue<Node> pq = new PriorityQueue<>();
        for (int i = 0; i < 256; i++) {
            if (freqs[i] > 0) {
                pq.add(new Node(i, freqs[i]));
            }
        }
        if (pq.isEmpty()) return null;
        if (pq.size() == 1) {
            Node single = pq.poll();
            return new Node(single, new Node(single.symbol, 0)); // dummy right to give a code
        }
        while (pq.size() > 1) {
            Node a = pq.poll();
            Node b = pq.poll();
            pq.add(new Node(a, b));
        }
        return pq.poll();
    }

    private void buildCodes(Node node, String prefix, Map<Integer, String> codes) {
        if (node == null) return;
        if (node.isLeaf()) {
            codes.put(node.symbol, prefix.isEmpty() ? "0" : prefix);
            return;
        }
        buildCodes(node.left, prefix + "0", codes);
        buildCodes(node.right, prefix + "1", codes);
    }

    public byte[] encode(byte[] input) {
        long startTime = System.currentTimeMillis();

        // Count frequencies
        long[] freqs = new long[256];
        for (byte b : input) {
            freqs[b & 0xFF]++;
        }

        // Build tree and codes
        Node root = buildTree(freqs);
        Map<Integer, String> codes = new HashMap<>();
        if (root != null) {
            buildCodes(root, "", codes);
        }

        // Encode
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(baos);

        try {
            // Original length
            out.writeInt(input.length);

            // Number of distinct symbols
            int numSymbols = 0;
            for (int i = 0; i < 256; i++) {
                if (freqs[i] > 0) numSymbols++;
            }
            out.writeShort(numSymbols);

            // Symbol frequencies
            for (int i = 0; i < 256; i++) {
                if (freqs[i] > 0) {
                    out.writeByte(i);
                    out.writeInt((int) freqs[i]);
                }
            }

            // Encode input as bit stream
            // Collect all bits first
            StringBuilder bits = new StringBuilder();
            for (byte b : input) {
                bits.append(codes.get(b & 0xFF));
            }

            // Pad to byte boundary
            int paddingBits = (8 - (bits.length() % 8)) % 8;
            for (int i = 0; i < paddingBits; i++) {
                bits.append('0');
            }

            // Write padding count
            out.writeByte(paddingBits);

            // Write bytes
            int totalBits = bits.length();
            for (int i = 0; i < totalBits; i += 8) {
                String byteStr = bits.substring(i, i + 8);
                out.writeByte(Integer.parseInt(byteStr, 2));
            }

            out.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        byte[] encoded = baos.toByteArray();
        long endTime = System.currentTimeMillis();

        stats = new CompressionStats();
        stats.originalSize = input.length;
        stats.compressedSize = encoded.length;
        stats.compressionRatio = (stats.compressedSize == 0) ? 0.0 : (double) stats.originalSize / stats.compressedSize;
        stats.encodingTimeMs = endTime - startTime;
        stats.decodingTimeMs = 0;

        return encoded;
    }

    public byte[] decode(byte[] encoded) {
        long startTime = System.currentTimeMillis();

        ByteArrayInputStream bais = new ByteArrayInputStream(encoded);
        DataInputStream in = new DataInputStream(bais);

        byte[] result;
        try {
            int originalLength = in.readInt();

            // Read symbol table
            int numSymbols = in.readUnsignedShort();
            long[] freqs = new long[256];
            for (int i = 0; i < numSymbols; i++) {
                int sym = in.readUnsignedByte();
                long freq = in.readInt() & 0xFFFFFFFFL;
                freqs[sym] = freq;
            }

            // Rebuild tree
            Node root = buildTree(freqs);

            // Read padding count
            int paddingBits = in.readUnsignedByte();

            // Read remaining bytes
            byte[] compressedBytes = in.readAllBytes();

            // Decode
            result = new byte[originalLength];
            int outPos = 0;

            if (originalLength == 0) {
                // nothing to do
            } else if (root != null && root.isLeaf()) {
                // Single symbol case
                for (int i = 0; i < originalLength; i++) {
                    result[i] = (byte) root.left.symbol; // single real symbol is the left child
                    // Actually we need to handle this correctly
                    // The tree was built with a dummy right child, left child is the real symbol
                }
                // Re-check: if root is leaf, there's only one symbol total
                // The buildTree with single symbol returns an internal node with left=real, right=dummy
                // So actually root.isLeaf() should be false in the single-symbol case
                // Let me handle differently
            } else {
                // Normal decode
                Node current = root;
                int totalBitCount = compressedBytes.length * 8 - paddingBits;
                int bitIndex = 0;

                while (bitIndex < totalBitCount && outPos < originalLength) {
                    int byteIndex = bitIndex / 8;
                    int bitPos = 7 - (bitIndex % 8);
                    int bit = (compressedBytes[byteIndex] >> bitPos) & 1;
                    bitIndex++;

                    if (bit == 0) {
                        current = current.left;
                    } else {
                        current = current.right;
                    }

                    if (current.isLeaf()) {
                        result[outPos++] = (byte) current.symbol;
                        current = root;
                    }
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        long endTime = System.currentTimeMillis();

        stats = new CompressionStats();
        stats.originalSize = result.length;
        stats.compressedSize = encoded.length;
        stats.compressionRatio = (stats.compressedSize == 0) ? 0.0 : (double) stats.originalSize / stats.compressedSize;
        stats.encodingTimeMs = 0;
        stats.decodingTimeMs = endTime - startTime;

        return result;
    }

    public CompressionStats getStats() {
        return stats;
    }
}
