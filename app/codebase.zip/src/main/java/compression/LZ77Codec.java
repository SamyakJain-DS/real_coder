package compression;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

/**
 * LZ77 sliding window compression codec.
 *
 * Encoding format:
 *   Header: 4-byte big-endian original length
 *   Each token:
 *     - 1 byte flag: 0 = literal, 1 = match
 *     - literal:  1 byte value
 *     - match:    2-byte big-endian distance (unsigned), 2-byte big-endian length (unsigned)
 */
public class LZ77Codec {

    private CompressionStats stats = new CompressionStats();

    public LZ77Codec() {}

    public byte[] encode(byte[] input, int windowSize) {
        if (windowSize < 1 || windowSize > 32768) {
            throw new IllegalArgumentException("windowSize must be between 1 and 32768");
        }

        long startTime = System.currentTimeMillis();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(baos);

        try {
            // Write original length as 4-byte big-endian int
            out.writeInt(input.length);

            int i = 0;
            int n = input.length;

            while (i < n) {
                int[] bestMatch = findLongestMatch(input, i, windowSize);
                int bestLen = bestMatch[0];
                int bestDist = bestMatch[1];

                if (bestLen >= 3) {
                    // Lazy matching: check if i+1 gives a strictly longer match
                    boolean usedLazy = false;
                    if (i + 1 < n) {
                        int[] nextMatch = findLongestMatch(input, i + 1, windowSize);
                        if (nextMatch[0] > bestLen) {
                            // Emit i as literal, use the longer match at i+1
                            out.writeByte(0);
                            out.writeByte(input[i] & 0xFF);
                            i++;
                            out.writeByte(1);
                            out.writeShort(nextMatch[1]);
                            out.writeShort(nextMatch[0]);
                            i += nextMatch[0];
                            usedLazy = true;
                        }
                    }
                    if (!usedLazy) {
                        out.writeByte(1);
                        out.writeShort(bestDist);
                        out.writeShort(bestLen);
                        i += bestLen;
                    }
                } else {
                    out.writeByte(0);
                    out.writeByte(input[i] & 0xFF);
                    i++;
                }
            }

            out.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        byte[] encoded = baos.toByteArray();
        long endTime = System.currentTimeMillis();

        stats = new CompressionStats();
        stats.originalSize = input.length;
        stats.compressedSize = encoded.length;
        stats.compressionRatio = (stats.compressedSize == 0) ? 0.0 : (double) stats.originalSize / stats.compressedSize;
        stats.encodingTimeMs = endTime - startTime;
        stats.decodingTimeMs = 0;

        return encoded;
    }

    private int[] findLongestMatch(byte[] input, int pos, int windowSize) {
        int n = input.length;
        int windowStart = Math.max(0, pos - windowSize);
        int bestLen = 0;
        int bestDist = 0;
        int maxMatchLen = Math.min(65535, n - pos);

        for (int j = windowStart; j < pos; j++) {
            int matchLen = 0;
            while (matchLen < maxMatchLen && input[j + matchLen] == input[pos + matchLen]) {
                matchLen++;
            }
            if (matchLen > bestLen) {
                bestLen = matchLen;
                bestDist = pos - j;
            }
        }

        if (bestLen < 3) {
            return new int[]{0, 0};
        }
        return new int[]{bestLen, bestDist};
    }

    public byte[] decode(byte[] encoded) {
        long startTime = System.currentTimeMillis();

        ByteArrayInputStream bais = new ByteArrayInputStream(encoded);
        DataInputStream in = new DataInputStream(bais);

        byte[] result;
        try {
            int originalLength = in.readInt();
            byte[] buf = new byte[originalLength];
            int pos = 0;

            while (pos < originalLength) {
                int flag = in.readUnsignedByte();
                if (flag == 0) {
                    buf[pos++] = (byte) in.readUnsignedByte();
                } else {
                    int distance = in.readUnsignedShort();
                    int length = in.readUnsignedShort();
                    int startPos = pos - distance;
                    for (int k = 0; k < length; k++) {
                        buf[pos] = buf[startPos + k];
                        pos++;
                    }
                }
            }

            result = buf;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        long endTime = System.currentTimeMillis();

        stats = new CompressionStats();
        stats.originalSize = result.length;
        stats.compressedSize = encoded.length;
        stats.compressionRatio = (stats.compressedSize == 0) ? 0.0 : (double) stats.originalSize / stats.compressedSize;
        stats.encodingTimeMs = 0;
        stats.decodingTimeMs = endTime - startTime;

        return result;
    }

    public CompressionStats getStats() {
        return stats;
    }
}
