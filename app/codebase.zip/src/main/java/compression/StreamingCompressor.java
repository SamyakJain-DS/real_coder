package compression;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * Static utility class for block-wise streaming compression and decompression.
 * Each compressed block is prefixed with a 4-byte big-endian integer length header.
 */
public class StreamingCompressor {

    private StreamingCompressor() {}

    public static void compress(InputStream input, OutputStream output, int blockSize, String codec)
            throws IOException {
        DataOutputStream dos = new DataOutputStream(output);
        byte[] buffer = new byte[blockSize];
        int bytesRead;

        while ((bytesRead = input.read(buffer, 0, blockSize)) != -1) {
            // Extract the actual block (may be smaller than blockSize on last read)
            byte[] block;
            if (bytesRead == blockSize) {
                block = buffer;
            } else {
                block = new byte[bytesRead];
                System.arraycopy(buffer, 0, block, 0, bytesRead);
            }

            byte[] compressed = compressBlock(block, codec);
            dos.writeInt(compressed.length);
            dos.write(compressed);
        }

        dos.flush();
    }

    public static void decompress(InputStream input, OutputStream output, String codec)
            throws IOException {
        DataInputStream dis = new DataInputStream(input);

        while (true) {
            int blockLen;
            try {
                blockLen = dis.readInt();
            } catch (java.io.EOFException e) {
                break;
            }

            byte[] compressedBlock = new byte[blockLen];
            dis.readFully(compressedBlock);

            byte[] decompressed = decompressBlock(compressedBlock, codec);
            output.write(decompressed);
        }

        output.flush();
    }

    private static byte[] compressBlock(byte[] block, String codec) {
        switch (codec.toLowerCase()) {
            case "lz77": {
                LZ77Codec c = new LZ77Codec();
                return c.encode(block, 32768);
            }
            case "huffman": {
                HuffmanCodec c = new HuffmanCodec();
                return c.encode(block);
            }
            case "deflate": {
                DeflateCodec c = new DeflateCodec();
                return c.encode(block);
            }
            default:
                throw new IllegalArgumentException("Unknown codec: " + codec);
        }
    }

    private static byte[] decompressBlock(byte[] block, String codec) {
        switch (codec.toLowerCase()) {
            case "lz77": {
                LZ77Codec c = new LZ77Codec();
                return c.decode(block);
            }
            case "huffman": {
                HuffmanCodec c = new HuffmanCodec();
                return c.decode(block);
            }
            case "deflate": {
                DeflateCodec c = new DeflateCodec();
                return c.decode(block);
            }
            default:
                throw new IllegalArgumentException("Unknown codec: " + codec);
        }
    }
}
