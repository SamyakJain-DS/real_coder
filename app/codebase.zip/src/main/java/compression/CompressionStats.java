package compression;

public class CompressionStats {
    public long originalSize;
    public long compressedSize;
    public double compressionRatio;
    public long encodingTimeMs;
    public long decodingTimeMs;
}
