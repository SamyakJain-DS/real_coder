package resolver;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Resolves package dependency version constraints using backtracking search
 * with constraint propagation and conflict-driven learning.
 */
public class DependencyResolver {

    private final PackageRegistry registry;
    private String capturedError;

    public DependencyResolver(PackageRegistry registry) {
        this.registry = registry;
    }

    /**
     * Runs backtracking search with constraint propagation and conflict-driven learning
     * over the registry. Returns a ResolvedResult indicating success or failure.
     */
    public ResolvedResult resolve(List<Requirement> rootRequirements) {
        capturedError = null;

        // Root package names in order
        List<String> rootPackageNames = rootRequirements.stream()
            .map(Requirement::getPackageName)
            .collect(Collectors.toList());

        // Active constraints: package name -> list of (imposerName, imposerVersion, constraintStr)
        // imposerVersion is null if the imposer is root
        Map<String, List<ConstraintEntry>> activeConstraints = new LinkedHashMap<>();

        // Seed active constraints from root requirements
        for (Requirement req : rootRequirements) {
            activeConstraints.computeIfAbsent(req.getPackageName(), k -> new ArrayList<>())
                .add(new ConstraintEntry("root", null, req.getConstraint()));
        }

        // Assignments: package name -> assigned version string
        Map<String, String> assignments = new LinkedHashMap<>();

        // Conflict database: list of assignment sets that lead to failure
        List<Map<String, String>> conflictSet = new ArrayList<>();

        // Run the backtracking search
        boolean solved = backtrack(activeConstraints, assignments, conflictSet);

        if (!solved) {
            String errorMsg = capturedError != null
                ? capturedError
                : buildErrorMessage(activeConstraints, assignments, conflictSet);
            return ResolvedResult.failure(errorMsg);
        }

        // Build constraint chains for each resolved package
        Map<String, List<String>> chains = buildConstraintChains(
            rootPackageNames, assignments, activeConstraints);

        return ResolvedResult.success(assignments, rootPackageNames, chains);
    }

    /**
     * Backtracking algorithm with constraint propagation and conflict-driven learning.
     */
    private boolean backtrack(
            Map<String, List<ConstraintEntry>> activeConstraints,
            Map<String, String> assignments,
            List<Map<String, String>> conflictSet) {

        // Find all unresolved packages (present in constraints but not yet assigned)
        List<String> unresolved = activeConstraints.keySet().stream()
            .filter(pkg -> !assignments.containsKey(pkg))
            .collect(Collectors.toList());

        if (unresolved.isEmpty()) {
            return true; // All packages resolved
        }

        // Step 2: Select the most-constrained unresolved package (fewest valid versions)
        String chosen = null;
        List<PackageVersion> chosenVersions = null;
        int minCount = Integer.MAX_VALUE;

        for (String pkg : unresolved) {
            List<PackageVersion> validVersions = getValidVersions(pkg, activeConstraints);
            if (validVersions.size() < minCount) {
                minCount = validVersions.size();
                chosen = pkg;
                chosenVersions = validVersions;
            }
        }

        if (chosen == null) {
            return false;
        }

        // Step 6: If no valid versions, record conflict and backtrack
        if (chosenVersions.isEmpty()) {
            if (capturedError == null) {
                capturedError = buildConflictMessage(chosen, activeConstraints);
            }
            conflictSet.add(new HashMap<>(assignments));
            return false;
        }

        // Step 3: Try each valid version from newest to oldest
        for (PackageVersion pv : chosenVersions) {
            // Step 7: Check if current assignment + this choice is a superset of any conflict
            Map<String, String> tentative = new HashMap<>(assignments);
            tentative.put(chosen, pv.getVersion());
            if (isSupersetOfAnyConflict(tentative, conflictSet)) {
                continue; // Skip this branch
            }

            // Step 4: Tentatively assign this version
            assignments.put(chosen, pv.getVersion());

            // Merge this version's dependencies into active constraints
            Map<String, List<ConstraintEntry>> addedConstraints = new LinkedHashMap<>();
            for (Requirement dep : pv.getDependencies()) {
                String depPkg = dep.getPackageName();
                ConstraintEntry entry = new ConstraintEntry(chosen, pv.getVersion(), dep.getConstraint());
                activeConstraints.computeIfAbsent(depPkg, k -> new ArrayList<>()).add(entry);
                addedConstraints.computeIfAbsent(depPkg, k -> new ArrayList<>()).add(entry);
            }

            // Step 5: Check propagation - verify no package now has an empty valid set
            boolean propagationOk = checkPropagation(activeConstraints, assignments);

            if (propagationOk) {
                if (backtrack(activeConstraints, assignments, conflictSet)) {
                    return true;
                }
            } else {
                // Propagation failed: capture error before backtracking removes constraints
                if (capturedError == null) {
                    capturedError = findPropagationConflictMessage(activeConstraints, assignments);
                }
                conflictSet.add(new HashMap<>(assignments));
            }

            // Backtrack: undo assignment and remove added constraints
            assignments.remove(chosen);
            for (Map.Entry<String, List<ConstraintEntry>> e : addedConstraints.entrySet()) {
                List<ConstraintEntry> list = activeConstraints.get(e.getKey());
                if (list != null) {
                    list.removeAll(e.getValue());
                    if (list.isEmpty()) {
                        activeConstraints.remove(e.getKey());
                    }
                }
            }
        }

        // All branches failed
        return false;
    }

    /**
     * Returns valid versions of pkg that satisfy all active constraints, newest first.
     */
    private List<PackageVersion> getValidVersions(
            String pkg, Map<String, List<ConstraintEntry>> activeConstraints) {
        List<PackageVersion> allVersions = registry.getVersions(pkg);
        List<ConstraintEntry> constraints = activeConstraints.getOrDefault(pkg, Collections.emptyList());

        return allVersions.stream()
            .filter(pv -> constraints.stream().allMatch(ce ->
                VersionConstraint.parse(ce.constraint).matches(pv.getVersion())))
            .collect(Collectors.toList());
    }

    /**
     * Checks that no unresolved (and unassigned) package has an empty valid version set.
     */
    private boolean checkPropagation(
            Map<String, List<ConstraintEntry>> activeConstraints,
            Map<String, String> assignments) {
        for (String pkg : activeConstraints.keySet()) {
            if (assignments.containsKey(pkg)) continue;
            List<PackageVersion> valid = getValidVersions(pkg, activeConstraints);
            if (valid.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns true if the given assignment map is a superset of any recorded conflict.
     */
    private boolean isSupersetOfAnyConflict(
            Map<String, String> assignments, List<Map<String, String>> conflictSet) {
        for (Map<String, String> conflict : conflictSet) {
            if (assignments.entrySet().containsAll(conflict.entrySet())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Builds a conflict message for a specific package whose valid version set is empty.
     */
    private String buildConflictMessage(
            String pkg, Map<String, List<ConstraintEntry>> activeConstraints) {
        List<ConstraintEntry> constraints = activeConstraints.getOrDefault(pkg, Collections.emptyList());
        StringBuilder sb = new StringBuilder();
        sb.append("Cannot resolve package '").append(pkg).append("': ");
        sb.append("incompatible constraints: ");
        for (int i = 0; i < constraints.size(); i++) {
            ConstraintEntry ce = constraints.get(i);
            if (i > 0) sb.append(", ");
            if (ce.imposerVersion == null) {
                sb.append("root requires ").append(pkg).append(" ").append(ce.constraint);
            } else {
                sb.append(ce.imposerName).append("@").append(ce.imposerVersion)
                  .append(" requires ").append(pkg).append(" ").append(ce.constraint);
            }
        }
        return sb.toString();
    }

    /**
     * Scans active constraints to find the first package with no valid versions
     * and returns a conflict message built while constraints are still present.
     */
    private String findPropagationConflictMessage(
            Map<String, List<ConstraintEntry>> activeConstraints,
            Map<String, String> assignments) {
        for (String pkg : activeConstraints.keySet()) {
            if (assignments.containsKey(pkg)) continue;
            List<PackageVersion> valid = getValidVersions(pkg, activeConstraints);
            if (valid.isEmpty()) {
                return buildConflictMessage(pkg, activeConstraints);
            }
        }
        return "Dependency resolution failed: no compatible version assignment found.";
    }

    /**
     * Builds an error message describing the conflict.
     */
    private String buildErrorMessage(
            Map<String, List<ConstraintEntry>> activeConstraints,
            Map<String, String> assignments,
            List<Map<String, String>> conflictSet) {

        // Find a package with conflicting constraints
        for (Map.Entry<String, List<ConstraintEntry>> entry : activeConstraints.entrySet()) {
            String pkg = entry.getKey();
            List<ConstraintEntry> constraints = entry.getValue();
            if (constraints.size() >= 2) {
                // Check if no version satisfies all constraints simultaneously
                List<PackageVersion> valid = getValidVersions(pkg, activeConstraints);
                if (valid.isEmpty() && !constraints.isEmpty()) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Cannot resolve package '").append(pkg).append("': ");
                    sb.append("incompatible constraints: ");
                    for (int i = 0; i < constraints.size(); i++) {
                        ConstraintEntry ce = constraints.get(i);
                        if (i > 0) sb.append(", ");
                        if (ce.imposerVersion == null) {
                            sb.append("root requires ").append(pkg).append(" ").append(ce.constraint);
                        } else {
                            sb.append(ce.imposerName).append("@").append(ce.imposerVersion)
                              .append(" requires ").append(pkg).append(" ").append(ce.constraint);
                        }
                    }
                    return sb.toString();
                }
            }
        }

        // Fallback: describe conflict from conflict set
        if (!conflictSet.isEmpty()) {
            Map<String, String> lastConflict = conflictSet.get(conflictSet.size() - 1);
            // Find a package whose constraints conflict given the last conflict assignment
            for (Map.Entry<String, List<ConstraintEntry>> entry : activeConstraints.entrySet()) {
                String pkg = entry.getKey();
                if (!lastConflict.containsKey(pkg)) {
                    List<ConstraintEntry> constraints = entry.getValue();
                    if (!constraints.isEmpty()) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Cannot resolve package '").append(pkg).append("': ");
                        sb.append("no version satisfies all constraints: ");
                        for (int i = 0; i < constraints.size(); i++) {
                            ConstraintEntry ce = constraints.get(i);
                            if (i > 0) sb.append(", ");
                            if (ce.imposerVersion == null) {
                                sb.append("root requires ").append(pkg).append(" ").append(ce.constraint);
                            } else {
                                sb.append(ce.imposerName).append("@").append(ce.imposerVersion)
                                  .append(" requires ").append(pkg).append(" ").append(ce.constraint);
                            }
                        }
                        return sb.toString();
                    }
                }
            }
        }

        return "Dependency resolution failed: no compatible version assignment found.";
    }

    /**
     * Builds constraint chains for all resolved packages.
     */
    private Map<String, List<String>> buildConstraintChains(
            List<String> rootPackageNames,
            Map<String, String> assignments,
            Map<String, List<ConstraintEntry>> activeConstraints) {

        Map<String, List<String>> chains = new LinkedHashMap<>();

        for (String pkg : assignments.keySet()) {
            List<String> chain = new ArrayList<>();
            List<ConstraintEntry> constraints = activeConstraints.getOrDefault(pkg, Collections.emptyList());
            for (ConstraintEntry ce : constraints) {
                if (ce.imposerVersion == null) {
                    // Root requirement
                    chain.add("root requires " + pkg + " " + ce.constraint);
                } else {
                    chain.add(ce.imposerName + "@" + ce.imposerVersion
                        + " requires " + pkg + " " + ce.constraint);
                }
            }
            chains.put(pkg, chain);
        }

        return chains;
    }

    /**
     * Internal record of a constraint entry: who imposed it and what the constraint string is.
     */
    private static class ConstraintEntry {
        final String imposerName;
        final String imposerVersion; // null if root
        final String constraint;

        ConstraintEntry(String imposerName, String imposerVersion, String constraint) {
            this.imposerName = imposerName;
            this.imposerVersion = imposerVersion;
            this.constraint = constraint;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof ConstraintEntry)) return false;
            ConstraintEntry that = (ConstraintEntry) o;
            return Objects.equals(imposerName, that.imposerName)
                && Objects.equals(imposerVersion, that.imposerVersion)
                && Objects.equals(constraint, that.constraint);
        }

        @Override
        public int hashCode() {
            return Objects.hash(imposerName, imposerVersion, constraint);
        }
    }
}
