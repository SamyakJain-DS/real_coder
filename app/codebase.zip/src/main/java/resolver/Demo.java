package resolver;

import java.util.*;

public class Demo {
    public static void main(String[] args) throws Exception {
        PackageRegistry reg = PackageRegistry.load("data/registry.json");

        DependencyResolver resolver = new DependencyResolver(reg);
        List<Requirement> roots = List.of(new Requirement("express", "^4.18.0"));

        ResolvedResult result = resolver.resolve(roots);

        if (result.isSuccess()) {
            System.out.println("=== Resolved Versions ===");
            result.getResolvedVersions().forEach((k, v) ->
                System.out.println(k + " -> " + v));

            System.out.println("\n=== Dependency Tree ===");
            System.out.println(DependencyTreePrinter.print(result, reg));

            System.out.println("=== Why was mime-types chosen? ===");
            System.out.println(WhyExplainer.explain("mime-types", result));

            LockFile.write(result.getResolvedVersions(), "output-lock.json");
            System.out.println("Lock file written to output-lock.json");
        } else {
            System.out.println("Resolution failed: " + result.getErrorMessage());
        }

        // Demonstrate conflict detection
        System.out.println("\n=== Conflict Demo ===");
        List<Requirement> conflictRoots = List.of(
            new Requirement("conflict-pkg-a", "2.0.0"),
            new Requirement("conflict-pkg-b", "2.0.0")
        );
        ResolvedResult conflictResult = resolver.resolve(conflictRoots);
        if (!conflictResult.isSuccess()) {
            System.out.println("Expected conflict detected:");
            System.out.println(conflictResult.getErrorMessage());
        }
    }
}