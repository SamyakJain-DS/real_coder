package resolver;

import java.util.List;

/**
 * Utility class providing a static method to explain why a specific package version
 * was selected during resolution.
 */
public class WhyExplainer {

    private WhyExplainer() {
        // No instances
    }

    /**
     * Returns a multi-line string where each line describes one constraint in the
     * resolution chain that caused packageName to be selected.
     * Each line has the form "<imposer>@<version> requires <packageName> <constraint>".
     * When the constraint originates from a root requirement, the imposer is "root"
     * with no version suffix (i.e., "root requires <packageName> <constraint>").
     * Throws IllegalArgumentException when packageName is absent from result.getResolvedVersions().
     */
    public static String explain(String packageName, ResolvedResult result) {
        if (!result.isSuccess() || !result.getResolvedVersions().containsKey(packageName)) {
            throw new IllegalArgumentException(
                "Package '" + packageName + "' is not in the resolved versions.");
        }

        List<String> chain = result.getConstraintChain(packageName);
        return String.join("\n", chain);
    }
}
