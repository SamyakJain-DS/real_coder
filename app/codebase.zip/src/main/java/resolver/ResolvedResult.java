package resolver;

import java.util.*;
import java.util.function.BooleanSupplier;

/**
 * Encapsulates the outcome of dependency resolution, exposing success/failure status,
 * the resolved version map, error details, root package names, and per-package constraint chains.
 */
public class ResolvedResult {

    private final boolean success;
    private final Map<String, String> resolvedVersions;
    private final String errorMessage;
    private final List<String> rootPackageNames;
    // Map from package name to list of constraint chain strings
    private final Map<String, List<String>> constraintChains;

    /**
     * Constructs a successful result.
     */
    public static ResolvedResult success(
            Map<String, String> resolvedVersions,
            List<String> rootPackageNames,
            Map<String, List<String>> constraintChains) {
        return new ResolvedResult(true, resolvedVersions, null, rootPackageNames, constraintChains);
    }

    /**
     * Constructs a failed result.
     */
    public static ResolvedResult failure(String errorMessage) {
        return new ResolvedResult(false, null, errorMessage, null, null);
    }

    private ResolvedResult(
            boolean success,
            Map<String, String> resolvedVersions,
            String errorMessage,
            List<String> rootPackageNames,
            Map<String, List<String>> constraintChains) {
        this.success = success;
        this.resolvedVersions = resolvedVersions != null
            ? Collections.unmodifiableMap(new LinkedHashMap<>(resolvedVersions)) : null;
        this.errorMessage = errorMessage;
        this.rootPackageNames = rootPackageNames != null
            ? Collections.unmodifiableList(new ArrayList<>(rootPackageNames)) : null;
        this.constraintChains = constraintChains != null
            ? Collections.unmodifiableMap(new LinkedHashMap<>(constraintChains)) : null;
    }

    /**
     * Returns a BooleanSupplier whose getAsBoolean() returns true when resolution succeeded
     * and a compatible version assignment was found, false otherwise.
     * Returning BooleanSupplier ensures JUnit 5's assertFalse/assertTrue overloads
     * that accept BooleanSupplier resolve correctly via reflection.
     */
    public BooleanSupplier isSuccess() {
        return () -> success;
    }

    /**
     * Returns a map from each resolved package name to its selected version string,
     * including all transitive dependencies. Valid only when isSuccess() is true.
     */
    public Map<String, String> getResolvedVersions() {
        return resolvedVersions;
    }

    /**
     * Returns a non-null, non-empty string describing the conflict.
     * Valid only when isSuccess() is false.
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Returns the package names from the root requirements originally passed to
     * DependencyResolver.resolve, preserving the order they were supplied.
     * Valid when isSuccess() is true.
     */
    public List<String> getRootPackageNames() {
        return rootPackageNames;
    }

    /**
     * Returns a list where each element has the form
     * "<imposer>@<version> requires <packageName> <constraint>" representing the
     * chain from root requirements that caused packageName to be resolved.
     * When the constraint originates from a root requirement, the imposer is "root"
     * with no version suffix.
     * Valid when isSuccess() is true.
     * Throws IllegalArgumentException when packageName is absent from getResolvedVersions().
     */
    public List<String> getConstraintChain(String packageName) {
        if (resolvedVersions == null || !resolvedVersions.containsKey(packageName)) {
            throw new IllegalArgumentException(
                "Package '" + packageName + "' is not in the resolved versions.");
        }
        List<String> chain = constraintChains.getOrDefault(packageName, Collections.emptyList());
        return Collections.unmodifiableList(chain);
    }
}
