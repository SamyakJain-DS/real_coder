package resolver;

/**
 * Parses and evaluates version constraint strings against semantic versions.
 * Supports: exact, >=, <, ^, ~, and wildcard (1.2.*) constraints.
 */
public class VersionConstraint {

    private enum Type {
        EXACT, GTE, LT, CARET, TILDE, WILDCARD
    }

    private final Type type;
    private final int major;
    private final int minor;
    private final int patch;
    // For wildcard: -1 means wildcard at that position
    private final boolean wildcardPatch;

    private VersionConstraint(Type type, int major, int minor, int patch, boolean wildcardPatch) {
        this.type = type;
        this.major = major;
        this.minor = minor;
        this.patch = patch;
        this.wildcardPatch = wildcardPatch;
    }

    /**
     * Parses a constraint string and returns a VersionConstraint instance.
     */
    public static VersionConstraint parse(String constraint) {
        constraint = constraint.trim();

        if (constraint.startsWith(">=")) {
            int[] parts = parseSemver(constraint.substring(2).trim());
            return new VersionConstraint(Type.GTE, parts[0], parts[1], parts[2], false);
        } else if (constraint.startsWith("<")) {
            int[] parts = parseSemver(constraint.substring(1).trim());
            return new VersionConstraint(Type.LT, parts[0], parts[1], parts[2], false);
        } else if (constraint.startsWith("^")) {
            int[] parts = parseSemver(constraint.substring(1).trim());
            return new VersionConstraint(Type.CARET, parts[0], parts[1], parts[2], false);
        } else if (constraint.startsWith("~")) {
            int[] parts = parseSemver(constraint.substring(1).trim());
            return new VersionConstraint(Type.TILDE, parts[0], parts[1], parts[2], false);
        } else if (constraint.contains(".*")) {
            // Wildcard: e.g. 1.2.*
            String withoutStar = constraint.replace(".*", "");
            String[] segments = withoutStar.split("\\.");
            int maj = Integer.parseInt(segments[0].trim());
            int min = Integer.parseInt(segments[1].trim());
            return new VersionConstraint(Type.WILDCARD, maj, min, -1, true);
        } else {
            // Exact version
            int[] parts = parseSemver(constraint);
            return new VersionConstraint(Type.EXACT, parts[0], parts[1], parts[2], false);
        }
    }

    private static int[] parseSemver(String version) {
        String[] parts = version.split("\\.");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Invalid semver: " + version);
        }
        return new int[]{
            Integer.parseInt(parts[0].trim()),
            Integer.parseInt(parts[1].trim()),
            Integer.parseInt(parts[2].trim())
        };
    }

    /**
     * Returns true if the given version string satisfies this constraint.
     */
    public boolean matches(String versionStr) {
        int[] v = parseSemver(versionStr);
        int vMaj = v[0], vMin = v[1], vPat = v[2];

        switch (type) {
            case EXACT:
                return vMaj == major && vMin == minor && vPat == patch;

            case GTE:
                return compareSemver(vMaj, vMin, vPat, major, minor, patch) >= 0;

            case LT:
                return compareSemver(vMaj, vMin, vPat, major, minor, patch) < 0;

            case CARET:
                // >=major.minor.patch and <(major+1).0.0
                return compareSemver(vMaj, vMin, vPat, major, minor, patch) >= 0
                    && compareSemver(vMaj, vMin, vPat, major + 1, 0, 0) < 0;

            case TILDE:
                // >=major.minor.patch and <major.(minor+1).0
                return compareSemver(vMaj, vMin, vPat, major, minor, patch) >= 0
                    && compareSemver(vMaj, vMin, vPat, major, minor + 1, 0) < 0;

            case WILDCARD:
                // major.minor.*: vMaj==major and vMin==minor, any patch
                return vMaj == major && vMin == minor;

            default:
                return false;
        }
    }

    /**
     * Compares two semver tuples. Returns negative if a < b, 0 if equal, positive if a > b.
     */
    public static int compareSemver(int aMaj, int aMin, int aPat, int bMaj, int bMin, int bPat) {
        if (aMaj != bMaj) return Integer.compare(aMaj, bMaj);
        if (aMin != bMin) return Integer.compare(aMin, bMin);
        return Integer.compare(aPat, bPat);
    }

    /**
     * Compares two version strings semantically.
     */
    public static int compareVersionStrings(String a, String b) {
        String[] pa = a.split("\\.");
        String[] pb = b.split("\\.");
        return compareSemver(
            Integer.parseInt(pa[0]), Integer.parseInt(pa[1]), Integer.parseInt(pa[2]),
            Integer.parseInt(pb[0]), Integer.parseInt(pb[1]), Integer.parseInt(pb[2])
        );
    }
}
