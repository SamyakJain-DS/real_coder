package resolver;

import java.util.List;

/**
 * Represents one specific version of one package as loaded from the registry,
 * including its declared dependencies.
 */
public class PackageVersion {

    private final String name;
    private final String version;
    private final List<Requirement> dependencies;

    public PackageVersion(String name, String version, List<Requirement> dependencies) {
        this.name = name;
        this.version = version;
        this.dependencies = List.copyOf(dependencies);
    }

    /**
     * Returns the package name string.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the semantic version string of the form MAJOR.MINOR.PATCH.
     */
    public String getVersion() {
        return version;
    }

    /**
     * Returns the declared dependencies of this version.
     * Returns an empty list when this version declares no dependencies.
     */
    public List<Requirement> getDependencies() {
        return dependencies;
    }
}
