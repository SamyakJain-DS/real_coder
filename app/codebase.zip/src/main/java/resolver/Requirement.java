package resolver;

/**
 * Immutable value object representing a named package and its version constraint string.
 */
public class Requirement {

    private final String packageName;
    private final String constraint;

    public Requirement(String packageName, String constraint) {
        this.packageName = packageName;
        this.constraint = constraint;
    }

    /**
     * Returns the package name string provided at construction.
     */
    public String getPackageName() {
        return packageName;
    }

    /**
     * Returns the version constraint string provided at construction.
     */
    public String getConstraint() {
        return constraint;
    }
}
