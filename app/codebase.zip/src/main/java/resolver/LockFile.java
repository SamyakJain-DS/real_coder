package resolver;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.Map;

/**
 * Utility class providing static methods to write and read lock files that record
 * resolved dependency versions as flat JSON objects.
 */
public class LockFile {

    private LockFile() {
        // No instances
    }

    /**
     * Serializes resolvedVersions as a flat JSON object to the file at outputPath.
     * Creates the file and any missing parent directories if they do not exist.
     * Throws IOException on write failure.
     */
    public static void write(Map<String, String> resolvedVersions, String outputPath)
            throws IOException {
        File file = new File(outputPath);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            if (!parent.mkdirs()) {
                throw new IOException("Failed to create parent directories for: " + outputPath);
            }
        }
        ObjectMapper mapper = new ObjectMapper();
        mapper.writerWithDefaultPrettyPrinter().writeValue(file, resolvedVersions);
    }

    /**
     * Reads the file at inputPath and deserializes its flat JSON object into a Map<String, String>.
     * Throws IOException on read failure.
     * Throws IllegalArgumentException when the file content is not a valid flat JSON object
     * with string keys and string values.
     */
    public static Map<String, String> read(String inputPath) throws IOException {
        File file = new File(inputPath);
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> raw = mapper.readValue(file, new TypeReference<Map<String, Object>>() {});
            // Validate all values are strings
            for (Map.Entry<String, Object> entry : raw.entrySet()) {
                if (!(entry.getValue() instanceof String)) {
                    throw new IllegalArgumentException(
                        "Lock file must contain only string values. Key '" + entry.getKey()
                        + "' has non-string value: " + entry.getValue());
                }
            }
            @SuppressWarnings("unchecked")
            Map<String, String> result = (Map<String, String>) (Map<?, ?>) raw;
            return result;
        } catch (com.fasterxml.jackson.databind.exc.MismatchedInputException e) {
            throw new IllegalArgumentException(
                "Lock file must be a flat JSON object with string keys and values.", e);
        } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
            throw new IllegalArgumentException("Invalid JSON in lock file: " + inputPath, e);
        }
    }
}