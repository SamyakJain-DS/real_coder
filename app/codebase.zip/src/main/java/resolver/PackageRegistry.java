package resolver;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Holds parsed package-version entries from a registry JSON file.
 * Provides the static factory method load for construction and the instance
 * method getVersions for querying available versions of a named package.
 */
public class PackageRegistry {

    // Map from package name to list of PackageVersion in descending semver order
    private final Map<String, List<PackageVersion>> packageMap;

    private PackageRegistry(Map<String, List<PackageVersion>> packageMap) {
        this.packageMap = packageMap;
    }

    /**
     * Reads the JSON registry file at jsonFilePath, parses all package-version entries,
     * and returns a populated PackageRegistry instance.
     * Throws IOException on file read failure.
     * Throws IllegalArgumentException when the JSON structure does not match the required format.
     */
    public static PackageRegistry load(String jsonFilePath) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root;
        try {
            root = mapper.readTree(new File(jsonFilePath));
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
            throw new IllegalArgumentException(
                "Invalid JSON format in registry file: " + jsonFilePath, e);
        } catch (IOException e) {
            throw new IOException("Failed to read registry file: " + jsonFilePath, e);
        }

        if (!root.isObject() || !root.has("packages")) {
            throw new IllegalArgumentException("Registry JSON must have a top-level 'packages' array.");
        }

        JsonNode packagesNode = root.get("packages");
        if (!packagesNode.isArray()) {
            throw new IllegalArgumentException("'packages' must be an array.");
        }

        Map<String, List<PackageVersion>> packageMap = new HashMap<>();

        for (JsonNode pkgNode : packagesNode) {
            if (!pkgNode.has("name") || !pkgNode.has("version")) {
                throw new IllegalArgumentException("Each package entry must have 'name' and 'version'.");
            }

            String name = pkgNode.get("name").asText();
            String version = pkgNode.get("version").asText();

            List<Requirement> deps = new ArrayList<>();
            if (pkgNode.has("dependencies")) {
                JsonNode depsNode = pkgNode.get("dependencies");
                if (!depsNode.isArray()) {
                    throw new IllegalArgumentException("'dependencies' must be an array.");
                }
                for (JsonNode depNode : depsNode) {
                    if (!depNode.has("name") || !depNode.has("constraint")) {
                        throw new IllegalArgumentException(
                            "Each dependency must have 'name' and 'constraint'.");
                    }
                    deps.add(new Requirement(
                        depNode.get("name").asText(),
                        depNode.get("constraint").asText()
                    ));
                }
            }

            PackageVersion pv = new PackageVersion(name, version, deps);
            packageMap.computeIfAbsent(name, k -> new ArrayList<>()).add(pv);
        }

        // Sort each list in descending semver order (newest first)
        for (List<PackageVersion> versions : packageMap.values()) {
            versions.sort((a, b) ->
                VersionConstraint.compareVersionStrings(b.getVersion(), a.getVersion())
            );
        }

        return new PackageRegistry(Collections.unmodifiableMap(packageMap));
    }

    /**
     * Returns all PackageVersion entries for the given package name in descending
     * semantic version order (newest first).
     * Returns an empty list when the package name is not present in the registry.
     */
    public List<PackageVersion> getVersions(String packageName) {
        return packageMap.getOrDefault(packageName, Collections.emptyList());
    }
}
