package resolver;

import java.util.*;

/**
 * Utility class providing a static method to format the resolved dependency tree
 * as an indented multi-line string.
 */
public class DependencyTreePrinter {

    private DependencyTreePrinter() {
        // No instances
    }

    /**
     * Returns the dependency tree as a multi-line string.
     * Root packages appear at the outermost indentation level (zero leading spaces).
     * Each dependency of a package is indented exactly two spaces further than its parent.
     * Each line is formatted as packageName@version.
     * Throws IllegalArgumentException when result.isSuccess() is false.
     */
    public static String print(ResolvedResult result, PackageRegistry registry) {
        if (!result.isSuccess()) {
            throw new IllegalArgumentException(
                "Cannot print dependency tree: resolution was not successful.");
        }

        Map<String, String> resolvedVersions = result.getResolvedVersions();
        List<String> rootPackageNames = result.getRootPackageNames();

        StringBuilder sb = new StringBuilder();
        Set<String> visited = new LinkedHashSet<>();

        for (String rootPkg : rootPackageNames) {
            String version = resolvedVersions.get(rootPkg);
            if (version != null) {
                printNode(rootPkg, version, registry, resolvedVersions, 0, visited, sb);
            }
        }

        // Remove trailing newline if present
        if (sb.length() > 0 && sb.charAt(sb.length() - 1) == '\n') {
            sb.setLength(sb.length() - 1);
        }

        return sb.toString();
    }

    private static void printNode(
            String packageName,
            String version,
            PackageRegistry registry,
            Map<String, String> resolvedVersions,
            int depth,
            Set<String> visited,
            StringBuilder sb) {

        String indent = "  ".repeat(depth);
        sb.append(indent).append(packageName).append("@").append(version).append("\n");

        if (visited.contains(packageName)) {
            return;
        }
        visited.add(packageName);

        // Find the PackageVersion that was resolved
        List<PackageVersion> pvList = registry.getVersions(packageName);
        PackageVersion resolved = null;
        for (PackageVersion pv : pvList) {
            if (pv.getVersion().equals(version)) {
                resolved = pv;
                break;
            }
        }

        if (resolved != null) {
            for (Requirement dep : resolved.getDependencies()) {
                String depName = dep.getPackageName();
                String depVersion = resolvedVersions.get(depName);
                if (depVersion != null) {
                    printNode(depName, depVersion, registry, resolvedVersions, depth + 1, visited, sb);
                }
            }
        }
    }
}
