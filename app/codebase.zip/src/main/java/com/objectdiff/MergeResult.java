package com.objectdiff;

import java.util.List;

/**
 * Holds the outcome of a {@link DiffMerger#merge} operation.
 * <p>
 * Non-conflicting records from both input diffs are collected in {@code mergedRecords}.
 * Pairs of records from both diffs that share the exact same path are collected in
 * {@code conflicts} and excluded from {@code mergedRecords}.
 */
public final class MergeResult {

    private final List<ChangeRecord> mergedRecords;
    private final List<ConflictRecord> conflicts;

    public MergeResult(List<ChangeRecord> mergedRecords, List<ConflictRecord> conflicts) {
        this.mergedRecords = mergedRecords;
        this.conflicts = conflicts;
    }

    /** All non-conflicting {@link ChangeRecord} instances from both diffs, in encounter order. */
    public List<ChangeRecord> getMergedRecords() {
        return mergedRecords;
    }

    /** All {@link ConflictRecord} instances where both diffs modified the same path. */
    public List<ConflictRecord> getConflicts() {
        return conflicts;
    }
}
