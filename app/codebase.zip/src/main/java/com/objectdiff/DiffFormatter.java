package com.objectdiff;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.*;

/**
 * Converts a list of {@link ChangeRecord} instances into human-readable or JSON output.
 */
public class DiffFormatter {

    private DiffFormatter() {
        // utility class
    }

    /**
     * Shared {@link ObjectMapper} configured to tolerate empty beans and serialize
     * arbitrary {@link Object} values stored in {@link ChangeRecord#getOldValue()} /
     * {@link ChangeRecord#getNewValue()}.
     */
    private static final ObjectMapper MAPPER = new ObjectMapper()
            .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

    /**
     * Returns a multi-line human-readable string representation of {@code records}.
     *
     * <p>Each line corresponds to one {@link ChangeRecord} and contains:
     * <ul>
     *   <li>the path</li>
     *   <li>the change type name</li>
     *   <li>the old value (present for all change types; {@code null} for VALUE_ADDED / COLLECTION_ELEMENT_INSERTED)</li>
     *   <li>the new value (present for all change types; {@code null} for VALUE_REMOVED / COLLECTION_ELEMENT_REMOVED)</li>
     * </ul>
     *
     * @param records the list of change records to format
     * @return multi-line string; empty string if {@code records} is empty
     */
    public static String toText(List<ChangeRecord> records) {
        StringBuilder sb = new StringBuilder();
        for (ChangeRecord r : records) {
            sb.append(r.getPath())
              .append(" [").append(r.getChangeType().name()).append("]")
              .append(" oldValue=").append(r.getOldValue())
              .append(", newValue=").append(r.getNewValue())
              .append(System.lineSeparator());
        }
        return sb.toString();
    }

    /**
     * Returns a valid JSON array string where each element represents one {@link ChangeRecord}.
     *
     * <p>Each JSON object has the keys:
     * <ul>
     *   <li>{@code path} - the path string</li>
     *   <li>{@code changeType} - the {@link ChangeType} constant name</li>
     *   <li>{@code oldValue} - the old value serialized as a JSON-compatible value, or {@code null}</li>
     *   <li>{@code newValue} - the new value serialized as a JSON-compatible value, or {@code null}</li>
     * </ul>
     *
     * @param records the list of change records to serialize
     * @return valid JSON array string
     * @throws RuntimeException if Jackson serialization fails
     */
    public static String toJson(List<ChangeRecord> records) {
        List<Map<String, Object>> list = new ArrayList<>(records.size());
        for (ChangeRecord r : records) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("path",       r.getPath());
            map.put("changeType", r.getChangeType().name());
            map.put("oldValue",   r.getOldValue());
            map.put("newValue",   r.getNewValue());
            list.add(map);
        }
        try {
            return MAPPER.writeValueAsString(list);
        } catch (Exception e) {
            throw new RuntimeException("JSON serialization of diff records failed", e);
        }
    }
}
