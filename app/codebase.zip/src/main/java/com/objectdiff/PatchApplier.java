package com.objectdiff;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;

/**
 * Applies a list of {@link ChangeRecord} instances produced by {@link ObjectDiffer#diff}
 * to a base object, returning a modified deep copy.  The original base object is never mutated.
 */
public class PatchApplier {

    private PatchApplier() {
        // utility class
    }

    /**
     * Creates a deep copy of {@code base}, replays every {@link ChangeRecord} in {@code diff}
     * in order, and returns the modified copy.  The original {@code base} object is not mutated.
     *
     * @param <T>  the type of the base object
     * @param base the original object to patch
     * @param diff the list of change records to apply
     * @return a new object of type {@code T} reflecting all applied changes
     */
    @SuppressWarnings("unchecked")
    public static <T> T apply(T base, List<ChangeRecord> diff) {
        T copy = (T) deepCopy(base);
        for (ChangeRecord record : diff) {
            applyRecord(copy, record);
        }
        return copy;
    }

    // -------------------------------------------------------------------------
    // Record application
    // -------------------------------------------------------------------------

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void applyRecord(Object root, ChangeRecord record) {
        String path = record.getPath();
        List<Object> segments = parsePath(path);
        if (segments.isEmpty()) {
            return;
        }

        // Navigate to the parent of the last segment
        Object parent = navigateTo(root, segments, segments.size() - 1);
        Object lastSegment = segments.get(segments.size() - 1);

        switch (record.getChangeType()) {
            case VALUE_CHANGED:
            case VALUE_ADDED:
                applySetValue(parent, lastSegment, record.getNewValue());
                break;

            case VALUE_REMOVED:
                applySetValue(parent, lastSegment, null);
                break;

            case COLLECTION_ELEMENT_INSERTED: {
                int idx = (Integer) lastSegment;
                ((List<Object>) parent).add(idx, record.getNewValue());
                break;
            }

            case COLLECTION_ELEMENT_REMOVED: {
                int idx = (Integer) lastSegment;
                ((List<Object>) parent).remove(idx);
                break;
            }

            case MAP_ENTRY_ADDED: {
                String key = (String) lastSegment;
                ((Map<Object, Object>) parent).put(key, record.getNewValue());
                break;
            }

            case MAP_ENTRY_REMOVED: {
                String key = (String) lastSegment;
                ((Map) parent).remove(key);
                break;
            }
        }
    }

    /**
     * Sets a value on {@code parent} at the location indicated by {@code segment}.
     *
     * <ul>
     *   <li>Integer segment -> {@code List.set(index, value)}</li>
     *   <li>String segment on a Map -> {@code Map.put(key, value)}</li>
     *   <li>String segment on a POJO -> reflective field assignment</li>
     * </ul>
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void applySetValue(Object parent, Object segment, Object value) {
        if (segment instanceof Integer) {
            ((List<Object>) parent).set((Integer) segment, value);
        } else {
            String key = (String) segment;
            if (parent instanceof Map) {
                ((Map<Object, Object>) parent).put(key, value);
            } else {
                setField(parent, key, value);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Path parsing and navigation
    // -------------------------------------------------------------------------

    /**
     * Parses a dot/bracket path string into an ordered list of path segments.
     *
     * <ul>
     *   <li>Bare name tokens (between dots) -> {@code String}</li>
     *   <li>{@code [integer]} -> {@link Integer}</li>
     *   <li>{@code [non-integer]} -> {@code String} (map key)</li>
     * </ul>
     */
    static List<Object> parsePath(String path) {
        List<Object> segments = new ArrayList<>();
        int i = 0;
        while (i < path.length()) {
            char c = path.charAt(i);
            if (c == '.') {
                i++;  // skip dot separator between field names
            } else if (c == '[') {
                // Find matching ']'
                int end = path.indexOf(']', i + 1);
                if (end == -1) {
                    break;  // malformed - stop
                }
                String accessor = path.substring(i + 1, end);
                try {
                    segments.add(Integer.parseInt(accessor));
                } catch (NumberFormatException e) {
                    segments.add(accessor);  // map key
                }
                i = end + 1;
            } else {
                // Bare field name: read until '.' or '['
                int end = path.length();
                for (int j = i; j < path.length(); j++) {
                    char ch = path.charAt(j);
                    if (ch == '.' || ch == '[') {
                        end = j;
                        break;
                    }
                }
                segments.add(path.substring(i, end));
                i = end;
            }
        }
        return segments;
    }

    /**
     * Navigates {@code count} segments deep into the object graph rooted at {@code root}.
     */
    private static Object navigateTo(Object root, List<Object> segments, int count) {
        Object current = root;
        for (int i = 0; i < count; i++) {
            current = navigateSegment(current, segments.get(i));
        }
        return current;
    }

    /**
     * Moves one step into the object graph following the given segment.
     */
    @SuppressWarnings("unchecked")
    private static Object navigateSegment(Object obj, Object segment) {
        if (segment instanceof Integer) {
            return ((List<?>) obj).get((Integer) segment);
        } else {
            String key = (String) segment;
            if (obj instanceof Map) {
                return ((Map<?, ?>) obj).get(key);
            } else {
                return getField(obj, key);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Reflection helpers
    // -------------------------------------------------------------------------

    private static Object getField(Object obj, String fieldName) {
        try {
            Field field = findField(obj.getClass(), fieldName);
            field.setAccessible(true);
            return field.get(obj);
        } catch (Exception e) {
            throw new RuntimeException("Cannot read field '" + fieldName
                    + "' on " + obj.getClass().getName(), e);
        }
    }

    private static void setField(Object obj, String fieldName, Object value) {
        try {
            Field field = findField(obj.getClass(), fieldName);
            field.setAccessible(true);
            field.set(obj, value);
        } catch (Exception e) {
            throw new RuntimeException("Cannot set field '" + fieldName
                    + "' on " + obj.getClass().getName(), e);
        }
    }

    /**
     * Searches the class hierarchy (up to but not including {@link Object}) for a field
     * with the given name.
     */
    private static Field findField(Class<?> cls, String name) {
        Class<?> current = cls;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException e) {
                current = current.getSuperclass();
            }
        }
        throw new RuntimeException("Field '" + name + "' not found in " + cls.getName());
    }

    // -------------------------------------------------------------------------
    // Deep copy
    // -------------------------------------------------------------------------

    /**
     * Produces a deep copy of {@code obj}.
     *
     * <ul>
     *   <li>{@code null} -> {@code null}</li>
     *   <li>{@link String}, primitives, boxed primitives, enums -> same reference (immutable)</li>
     *   <li>{@link List} -> new {@link ArrayList} with deep-copied elements</li>
     *   <li>{@link Set} -> new {@link LinkedHashSet} with deep-copied elements</li>
     *   <li>{@link Map} -> new {@link LinkedHashMap} with deep-copied keys and values</li>
     *   <li>POJO -> new instance via no-arg constructor with all non-static, non-synthetic
     *       fields deep-copied recursively</li>
     * </ul>
     *
     * <p>If a POJO class has no accessible no-arg constructor the same reference is returned
     * as a best-effort fallback.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    static Object deepCopy(Object obj) {
        if (obj == null) {
            return null;
        }

        Class<?> cls = obj.getClass();

        // Immutable value types: share the reference
        if (cls == String.class
                || cls.isPrimitive()
                || isBoxedPrimitive(cls)
                || cls.isEnum()) {
            return obj;
        }

        if (obj instanceof List) {
            List copy = new ArrayList(((List) obj).size());
            for (Object elem : (List) obj) {
                copy.add(deepCopy(elem));
            }
            return copy;
        }

        if (obj instanceof Set) {
            Set copy = new LinkedHashSet();
            for (Object elem : (Set) obj) {
                copy.add(deepCopy(elem));
            }
            return copy;
        }

        if (obj instanceof Map) {
            Map copy = new LinkedHashMap();
            for (Map.Entry entry : ((Map<?, ?>) obj).entrySet()) {
                copy.put(deepCopy(entry.getKey()), deepCopy(entry.getValue()));
            }
            return copy;
        }

        // POJO: create a blank instance and copy every instance field recursively
        try {
            Constructor<?> ctor;
            try {
                ctor = cls.getDeclaredConstructor();
            } catch (NoSuchMethodException e) {
                // No no-arg constructor - return same reference as a best-effort fallback
                return obj;
            }
            ctor.setAccessible(true);
            Object copy = ctor.newInstance();

            Class<?> current = cls;
            while (current != null && current != Object.class) {
                for (Field field : current.getDeclaredFields()) {
                    if (Modifier.isStatic(field.getModifiers()) || field.isSynthetic()) {
                        continue;
                    }
                    field.setAccessible(true);
                    field.set(copy, deepCopy(field.get(obj)));
                }
                current = current.getSuperclass();
            }
            return copy;
        } catch (Exception e) {
            throw new RuntimeException("Deep copy failed for type: " + cls.getName(), e);
        }
    }

    private static boolean isBoxedPrimitive(Class<?> cls) {
        return cls == Boolean.class
                || cls == Byte.class
                || cls == Character.class
                || cls == Short.class
                || cls == Integer.class
                || cls == Long.class
                || cls == Float.class
                || cls == Double.class;
    }
}
