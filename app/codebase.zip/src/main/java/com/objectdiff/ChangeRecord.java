package com.objectdiff;

/**
 * Immutable record of a single structural change detected during a diff traversal.
 * Carries the dot/bracket path to the changed location, the kind of change,
 * and the old and new values (either may be null depending on the change type).
 */
public final class ChangeRecord {

    private final String path;
    private final ChangeType changeType;
    private final Object oldValue;
    private final Object newValue;

    public ChangeRecord(String path, ChangeType changeType, Object oldValue, Object newValue) {
        this.path = path;
        this.changeType = changeType;
        this.oldValue = oldValue;
        this.newValue = newValue;
    }

    /** Dot-separated path locating the change in the object graph (e.g., {@code address.city} or {@code orders[2].total}). */
    public String getPath() {
        return path;
    }

    /** The kind of change that occurred at this path. */
    public ChangeType getChangeType() {
        return changeType;
    }

    /** The value before the change; may be {@code null} for VALUE_ADDED or COLLECTION_ELEMENT_INSERTED. */
    public Object getOldValue() {
        return oldValue;
    }

    /** The value after the change; may be {@code null} for VALUE_REMOVED or COLLECTION_ELEMENT_REMOVED. */
    public Object getNewValue() {
        return newValue;
    }

    @Override
    public String toString() {
        return "ChangeRecord{path='" + path + "', changeType=" + changeType
                + ", oldValue=" + oldValue + ", newValue=" + newValue + '}';
    }
}
