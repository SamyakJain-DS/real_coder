package com.objectdiff;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

/**
 * Stores a mapping from {@link Class} to {@link Comparator}.
 * <p>
 * When the diff engine encounters a field whose declared type has a registered comparator,
 * it uses that comparator to determine equality: a return value of {@code 0} means equal;
 * any non-zero return means not equal and produces a {@link ChangeType#VALUE_CHANGED} record.
 * <p>
 * An instance is passed to {@link ObjectDiffer} at construction time.
 * Pass {@code null} to {@link ObjectDiffer} to use default {@code equals}-based comparison.
 */
public class ComparatorRegistry {

    private final Map<Class<?>, Comparator<?>> registry = new HashMap<>();

    /**
     * Registers {@code comparator} for {@code type}.
     * When the diff engine encounters a field of {@code type} (matched by declared type),
     * this comparator is invoked instead of {@code equals} to determine equality.
     *
     * @param <T>        the type to register
     * @param type       the class object representing the type
     * @param comparator the comparator to use for equality checks on values of this type
     */
    public <T> void register(Class<T> type, Comparator<T> comparator) {
        registry.put(type, comparator);
    }

    /**
     * Returns the registered comparator for {@code type}, or {@code null} if none is registered.
     */
    @SuppressWarnings("unchecked")
    public <T> Comparator<T> getComparator(Class<T> type) {
        return (Comparator<T>) registry.get(type);
    }

    /**
     * Returns {@code true} if a comparator has been registered for {@code type}.
     */
    public boolean hasComparator(Class<?> type) {
        return registry.containsKey(type);
    }
}
