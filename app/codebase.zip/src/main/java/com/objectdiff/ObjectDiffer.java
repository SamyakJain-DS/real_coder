package com.objectdiff;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;
import java.util.function.Function;

/**
 * Primary entry point for diff computation.
 *
 * <p>Instantiate with an optional {@link ComparatorRegistry}; pass {@code null} to rely
 * solely on {@code equals}-based comparison.  Call {@link #withListIdentity} to register
 * identity functions for specific List fields before calling {@link #diff}.
 *
 * <p>Thread-safety: instances are not thread-safe; create one per diff operation if
 * concurrent use is required.
 */
public class ObjectDiffer {

    private final ComparatorRegistry comparatorRegistry;
    private final Map<String, Function<Object, Object>> identityFunctions;

    /**
     * Creates a new {@code ObjectDiffer}.
     *
     * @param comparatorRegistry optional registry of per-type comparators; may be {@code null}
     */
    public ObjectDiffer(ComparatorRegistry comparatorRegistry) {
        this.comparatorRegistry = comparatorRegistry;
        this.identityFunctions = new HashMap<>();
    }

    /**
     * Registers an identity function for the List field located at {@code fieldPath}.
     *
     * <p>During diff, list elements from both sides are matched by the value returned by
     * {@code identityFunction} before index-based comparison.  Unmatched elements produce
     * {@link ChangeType#COLLECTION_ELEMENT_REMOVED} and
     * {@link ChangeType#COLLECTION_ELEMENT_INSERTED} pairs rather than
     * {@link ChangeType#VALUE_CHANGED} records.
     *
     * @param fieldPath        dot-separated path to the List field (e.g., {@code "orders"} or {@code "customer.orders"})
     * @param identityFunction function that extracts the identity key from a list element
     * @return {@code this} for chaining
     */
    public ObjectDiffer withListIdentity(String fieldPath, Function<Object, Object> identityFunction) {
        identityFunctions.put(fieldPath, identityFunction);
        return this;
    }

    /**
     * Traverses {@code base} and {@code target} recursively and returns all detected
     * differences as {@link ChangeRecord} instances.
     *
     * <p>Both arguments must be instances of the same declared type.
     * Returns an empty list when the two objects are structurally equal.
     *
     * @param base   the original object
     * @param target the modified object
     * @return list of change records, in traversal order
     */
    public List<ChangeRecord> diff(Object base, Object target) {
        if (base == null && target == null) {
            return Collections.emptyList();
        }
        List<ChangeRecord> records = new ArrayList<>();
        // Track object identity in the current traversal stack to detect circular references
        Set<Object> visitedStack = Collections.newSetFromMap(new IdentityHashMap<>());
        traverseObject("", base, target, records, visitedStack);
        return records;
    }

    // -------------------------------------------------------------------------
    // Core traversal
    // -------------------------------------------------------------------------

    /**
     * Recursively traverses the fields of two objects of the same type, accumulating
     * {@link ChangeRecord} instances for any detected differences.
     *
     * <p>If {@code base} is already present in {@code visitedStack} (identity equality),
     * traversal of this branch stops immediately to handle circular references.
     */
    private void traverseObject(String path, Object base, Object target,
                                 List<ChangeRecord> records, Set<Object> visitedStack) {
        if (base == null && target == null) {
            return;
        }
        // Null asymmetry is handled by the caller (compareFieldValues / compareValues);
        // if we arrive here with one side null that means we're at the root-level call.
        if (base == null || target == null) {
            return;
        }

        // Circular-reference guard: stop if this object instance is already on the stack
        if (visitedStack.contains(base)) {
            return;
        }
        visitedStack.add(base);

        try {
            for (Field field : getAllFields(base.getClass())) {
                // Skip fields annotated with @ExcludeFromDiff
                if (field.isAnnotationPresent(ExcludeFromDiff.class)) {
                    continue;
                }
                // Skip static and synthetic fields
                if (Modifier.isStatic(field.getModifiers()) || field.isSynthetic()) {
                    continue;
                }

                field.setAccessible(true);
                Object baseVal;
                Object targetVal;
                try {
                    baseVal = field.get(base);
                    targetVal = field.get(target);
                } catch (IllegalAccessException e) {
                    // Cannot access - skip silently
                    continue;
                }

                // Build the field's full path
                String fieldPath = path.isEmpty() ? field.getName() : path + "." + field.getName();

                // Dispatch based on the declared type of the field
                compareFieldValues(fieldPath, field.getType(), baseVal, targetVal, records, visitedStack);
            }
        } finally {
            visitedStack.remove(base);
        }
    }

    /**
     * Compares two field values using the field's <em>declared</em> type to determine
     * the appropriate comparison strategy.
     */
    private void compareFieldValues(String path, Class<?> declaredType,
                                     Object baseVal, Object targetVal,
                                     List<ChangeRecord> records, Set<Object> visitedStack) {
        // Both null -> no change
        if (baseVal == null && targetVal == null) {
            return;
        }

        // Null -> non-null: VALUE_ADDED
        if (baseVal == null) {
            records.add(new ChangeRecord(path, ChangeType.VALUE_ADDED, null, targetVal));
            return;
        }

        // Non-null -> null: VALUE_REMOVED
        if (targetVal == null) {
            records.add(new ChangeRecord(path, ChangeType.VALUE_REMOVED, baseVal, null));
            return;
        }

        // Custom comparator registered for this declared type takes precedence
        if (comparatorRegistry != null && comparatorRegistry.hasComparator(declaredType)) {
            @SuppressWarnings("unchecked")
            Comparator<Object> cmp = (Comparator<Object>) comparatorRegistry.getComparator(declaredType);
            if (cmp.compare(baseVal, targetVal) != 0) {
                records.add(new ChangeRecord(path, ChangeType.VALUE_CHANGED, baseVal, targetVal));
            }
            return;
        }

        // Primitive, boxed primitive, or String: compare by value equality
        if (isPrimitiveOrString(declaredType)) {
            if (!baseVal.equals(targetVal)) {
                records.add(new ChangeRecord(path, ChangeType.VALUE_CHANGED, baseVal, targetVal));
            }
            return;
        }

        // Enum: compare by value equality
        if (declaredType.isEnum()) {
            if (!baseVal.equals(targetVal)) {
                records.add(new ChangeRecord(path, ChangeType.VALUE_CHANGED, baseVal, targetVal));
            }
            return;
        }

        // List: element-by-element with optional identity function
        if (List.class.isAssignableFrom(declaredType)) {
            compareList(path, (List<?>) baseVal, (List<?>) targetVal, records, visitedStack);
            return;
        }

        // Set: by element equality
        if (Set.class.isAssignableFrom(declaredType)) {
            compareSet(path, (Set<?>) baseVal, (Set<?>) targetVal, records);
            return;
        }

        // Map: by key
        if (Map.class.isAssignableFrom(declaredType)) {
            compareMap(path, (Map<?, ?>) baseVal, (Map<?, ?>) targetVal, records, visitedStack);
            return;
        }

        // Nested complex object: recursive traversal
        traverseObject(path, baseVal, targetVal, records, visitedStack);
    }

    /**
     * Compares two values without a field declaration context (e.g., elements inside a
     * collection or values inside a map).  Uses the runtime type of {@code baseVal} to
     * determine the comparison strategy.
     */
    private void compareValues(String path, Object baseVal, Object targetVal,
                                List<ChangeRecord> records, Set<Object> visitedStack) {
        if (baseVal == null && targetVal == null) {
            return;
        }

        if (baseVal == null) {
            records.add(new ChangeRecord(path, ChangeType.VALUE_ADDED, null, targetVal));
            return;
        }

        if (targetVal == null) {
            records.add(new ChangeRecord(path, ChangeType.VALUE_REMOVED, baseVal, null));
            return;
        }

        Class<?> type = baseVal.getClass();

        // Custom comparator check by runtime type
        if (comparatorRegistry != null && comparatorRegistry.hasComparator(type)) {
            @SuppressWarnings("unchecked")
            Comparator<Object> cmp = (Comparator<Object>) comparatorRegistry.getComparator(type);
            if (cmp.compare(baseVal, targetVal) != 0) {
                records.add(new ChangeRecord(path, ChangeType.VALUE_CHANGED, baseVal, targetVal));
            }
            return;
        }

        if (isPrimitiveOrString(type)) {
            if (!baseVal.equals(targetVal)) {
                records.add(new ChangeRecord(path, ChangeType.VALUE_CHANGED, baseVal, targetVal));
            }
            return;
        }

        if (type.isEnum()) {
            if (!baseVal.equals(targetVal)) {
                records.add(new ChangeRecord(path, ChangeType.VALUE_CHANGED, baseVal, targetVal));
            }
            return;
        }

        if (baseVal instanceof List && targetVal instanceof List) {
            compareList(path, (List<?>) baseVal, (List<?>) targetVal, records, visitedStack);
            return;
        }

        if (baseVal instanceof Set && targetVal instanceof Set) {
            compareSet(path, (Set<?>) baseVal, (Set<?>) targetVal, records);
            return;
        }

        if (baseVal instanceof Map && targetVal instanceof Map) {
            compareMap(path, (Map<?, ?>) baseVal, (Map<?, ?>) targetVal, records, visitedStack);
            return;
        }

        // Complex nested object
        traverseObject(path, baseVal, targetVal, records, visitedStack);
    }

    // -------------------------------------------------------------------------
    // Collection / Map comparisons
    // -------------------------------------------------------------------------

    /**
     * Dispatches List comparison to either identity-based or index-based strategy.
     */
    private void compareList(String path, List<?> base, List<?> target,
                              List<ChangeRecord> records, Set<Object> visitedStack) {
        Function<Object, Object> identityFn = identityFunctions.get(path);
        if (identityFn != null) {
            compareListWithIdentity(path, base, target, identityFn, records, visitedStack);
        } else {
            compareListByIndex(path, base, target, records, visitedStack);
        }
    }

    /**
     * Index-based List comparison.
     *
     * <ul>
     *   <li>Elements present at matching indices are compared via {@link #compareValues}.</li>
     *   <li>Extra elements in {@code base} produce {@link ChangeType#COLLECTION_ELEMENT_REMOVED}.</li>
     *   <li>Extra elements in {@code target} produce {@link ChangeType#COLLECTION_ELEMENT_INSERTED}.</li>
     * </ul>
     */
    private void compareListByIndex(String path, List<?> base, List<?> target,
                                     List<ChangeRecord> records, Set<Object> visitedStack) {
        int minSize = Math.min(base.size(), target.size());

        // Compare overlapping indices
        for (int i = 0; i < minSize; i++) {
            compareValues(path + "[" + i + "]", base.get(i), target.get(i), records, visitedStack);
        }

        // Elements removed from the end of base
        for (int i = minSize; i < base.size(); i++) {
            records.add(new ChangeRecord(
                    path + "[" + i + "]",
                    ChangeType.COLLECTION_ELEMENT_REMOVED,
                    base.get(i), null));
        }

        // Elements inserted at the end in target
        for (int i = minSize; i < target.size(); i++) {
            records.add(new ChangeRecord(
                    path + "[" + i + "]",
                    ChangeType.COLLECTION_ELEMENT_INSERTED,
                    null, target.get(i)));
        }
    }

    /**
     * Identity-based List comparison.
     *
     * <p>Elements are matched by the key returned by {@code identityFn}.
     * <ul>
     *   <li>Elements in base with no matching key in target produce
     *       {@link ChangeType#COLLECTION_ELEMENT_REMOVED} at the base index.</li>
     *   <li>Elements in target with no matching key in base produce
     *       {@link ChangeType#COLLECTION_ELEMENT_INSERTED} at the target index.</li>
     *   <li>Matched elements whose base index differs from their target index have
     *       <em>moved</em>: a {@link ChangeType#COLLECTION_ELEMENT_REMOVED} is emitted
     *       at the base index and a {@link ChangeType#COLLECTION_ELEMENT_INSERTED} is
     *       emitted at the target index, rather than the {@link ChangeType#VALUE_CHANGED}
     *       records that index-based comparison would produce for the same scenario.</li>
     *   <li>Matched elements at the same index in both lists are recursively compared
     *       for field-level differences via {@link #compareValues}.</li>
     * </ul>
     */
    private void compareListWithIdentity(String path, List<?> base, List<?> target,
                                          Function<Object, Object> identityFn,
                                          List<ChangeRecord> records, Set<Object> visitedStack) {
        // Build key->index maps (insertion-ordered to keep output deterministic)
        Map<Object, Integer> baseKeyIndex = new LinkedHashMap<>();
        for (int i = 0; i < base.size(); i++) {
            baseKeyIndex.put(identityFn.apply(base.get(i)), i);
        }

        Map<Object, Integer> targetKeyIndex = new LinkedHashMap<>();
        for (int i = 0; i < target.size(); i++) {
            targetKeyIndex.put(identityFn.apply(target.get(i)), i);
        }

        // Elements present in base but absent in target -> removed (truly deleted)
        for (Map.Entry<Object, Integer> entry : baseKeyIndex.entrySet()) {
            if (!targetKeyIndex.containsKey(entry.getKey())) {
                int idx = entry.getValue();
                records.add(new ChangeRecord(
                        path + "[" + idx + "]",
                        ChangeType.COLLECTION_ELEMENT_REMOVED,
                        base.get(idx), null));
            }
        }

        // Elements present in target but absent in base -> inserted (truly new)
        for (Map.Entry<Object, Integer> entry : targetKeyIndex.entrySet()) {
            if (!baseKeyIndex.containsKey(entry.getKey())) {
                int idx = entry.getValue();
                records.add(new ChangeRecord(
                        path + "[" + idx + "]",
                        ChangeType.COLLECTION_ELEMENT_INSERTED,
                        null, target.get(idx)));
            }
        }

        // Matched pairs: present in both lists under the same identity key
        for (Map.Entry<Object, Integer> entry : baseKeyIndex.entrySet()) {
            if (!targetKeyIndex.containsKey(entry.getKey())) {
                continue; // already handled as removed above
            }
            int baseIdx   = entry.getValue();
            int targetIdx = targetKeyIndex.get(entry.getKey());

            if (baseIdx != targetIdx) {
                // The element moved to a different position.
                // Emit REMOVED at the old (base) index and INSERTED at the new (target) index
                // instead of VALUE_CHANGED records, which is exactly what index-based
                // comparison would have produced for the overlapping positions.
                records.add(new ChangeRecord(
                        path + "[" + baseIdx + "]",
                        ChangeType.COLLECTION_ELEMENT_REMOVED,
                        base.get(baseIdx), null));
                records.add(new ChangeRecord(
                        path + "[" + targetIdx + "]",
                        ChangeType.COLLECTION_ELEMENT_INSERTED,
                        null, target.get(targetIdx)));
            } else {
                // Same position in both lists: compare field-level changes normally
                compareValues(path + "[" + baseIdx + "]",
                        base.get(baseIdx), target.get(targetIdx), records, visitedStack);
            }
        }
    }

    /**
     * Set comparison by element equality.
     *
     * <ul>
     *   <li>Elements in {@code base} absent in {@code target} -> {@link ChangeType#VALUE_REMOVED}.</li>
     *   <li>Elements in {@code target} absent in {@code base} -> {@link ChangeType#VALUE_ADDED}.</li>
     * </ul>
     * The change records are emitted at the field path (no index, as sets are unordered).
     */
    private void compareSet(String path, Set<?> base, Set<?> target, List<ChangeRecord> records) {
        for (Object elem : base) {
            if (!target.contains(elem)) {
                records.add(new ChangeRecord(path, ChangeType.VALUE_REMOVED, elem, null));
            }
        }
        for (Object elem : target) {
            if (!base.contains(elem)) {
                records.add(new ChangeRecord(path, ChangeType.VALUE_ADDED, null, elem));
            }
        }
    }

    /**
     * Map comparison by key.
     *
     * <ul>
     *   <li>Key present in base, absent in target -> {@link ChangeType#MAP_ENTRY_REMOVED}.</li>
     *   <li>Key present in target, absent in base -> {@link ChangeType#MAP_ENTRY_ADDED}.</li>
     *   <li>Key present in both -> associated values compared recursively.</li>
     * </ul>
     * Path for a map entry uses bracket notation: {@code fieldName[keyString]}.
     */
    private void compareMap(String path, Map<?, ?> base, Map<?, ?> target,
                             List<ChangeRecord> records, Set<Object> visitedStack) {
        for (Object key : base.keySet()) {
            String keyPath = path + "[" + key + "]";
            if (!target.containsKey(key)) {
                records.add(new ChangeRecord(keyPath, ChangeType.MAP_ENTRY_REMOVED, base.get(key), null));
            } else {
                compareValues(keyPath, base.get(key), target.get(key), records, visitedStack);
            }
        }
        for (Object key : target.keySet()) {
            if (!base.containsKey(key)) {
                String keyPath = path + "[" + key + "]";
                records.add(new ChangeRecord(keyPath, ChangeType.MAP_ENTRY_ADDED, null, target.get(key)));
            }
        }
    }

    // -------------------------------------------------------------------------
    // Utilities
    // -------------------------------------------------------------------------

    /**
     * Returns {@code true} for primitive types, their boxed counterparts, and {@link String}.
     */
    static boolean isPrimitiveOrString(Class<?> type) {
        return type.isPrimitive()
                || type == Boolean.class
                || type == Byte.class
                || type == Character.class
                || type == Short.class
                || type == Integer.class
                || type == Long.class
                || type == Float.class
                || type == Double.class
                || type == String.class;
    }

    /**
     * Collects all non-static, non-synthetic instance fields declared in {@code clazz}
     * and all of its superclasses (up to but not including {@link Object}).
     * Fields declared in subclasses appear before those from superclasses.
     */
    static List<Field> getAllFields(Class<?> clazz) {
        List<Field> fields = new ArrayList<>();
        Class<?> current = clazz;
        while (current != null && current != Object.class) {
            for (Field f : current.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) && !f.isSynthetic()) {
                    fields.add(f);
                }
            }
            current = current.getSuperclass();
        }
        return fields;
    }
}