package com.objectdiff;

/**
 * Describes the kind of structural difference detected by the diff engine.
 */
public enum ChangeType {
    /** A field held one value and now holds a different non-null value. */
    VALUE_CHANGED,
    /** A field that was null is now set to a non-null value, or a new element appears in a collection. */
    VALUE_ADDED,
    /** A field that was set is now null, or an element is removed from a collection. */
    VALUE_REMOVED,
    /** An element is inserted at a specific index in a List. */
    COLLECTION_ELEMENT_INSERTED,
    /** An element is removed from a specific index in a List. */
    COLLECTION_ELEMENT_REMOVED,
    /** A key-value pair is added to a Map. */
    MAP_ENTRY_ADDED,
    /** A key-value pair is removed from a Map. */
    MAP_ENTRY_REMOVED
}
