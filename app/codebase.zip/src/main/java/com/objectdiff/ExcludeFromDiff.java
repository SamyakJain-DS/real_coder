package com.objectdiff;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * When placed on a field, instructs the diff engine to skip that field entirely during
 * traversal.  No {@link ChangeRecord} will ever be produced for an annotated field,
 * regardless of whether its value differs between the base and target objects.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface ExcludeFromDiff {
}
