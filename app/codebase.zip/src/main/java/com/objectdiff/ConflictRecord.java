package com.objectdiff;

/**
 * Represents a merge conflict: two {@link ChangeRecord} instances from different diffs
 * that both modify the exact same path in the object graph.
 */
public final class ConflictRecord {

    private final String path;
    private final ChangeRecord fromDiff1;
    private final ChangeRecord fromDiff2;

    public ConflictRecord(String path, ChangeRecord fromDiff1, ChangeRecord fromDiff2) {
        this.path = path;
        this.fromDiff1 = fromDiff1;
        this.fromDiff2 = fromDiff2;
    }

    /** The path string shared by both conflicting records. */
    public String getPath() {
        return path;
    }

    /** The {@link ChangeRecord} from the first diff that touches this path. */
    public ChangeRecord getFromDiff1() {
        return fromDiff1;
    }

    /** The {@link ChangeRecord} from the second diff that touches this path. */
    public ChangeRecord getFromDiff2() {
        return fromDiff2;
    }

    @Override
    public String toString() {
        return "ConflictRecord{path='" + path + "', fromDiff1=" + fromDiff1 + ", fromDiff2=" + fromDiff2 + '}';
    }
}
