package com.objectdiff;

import java.util.*;

/**
 * Merges two {@link ChangeRecord} lists computed against the same base object.
 *
 * <p>A conflict occurs when both diffs contain a {@link ChangeRecord} with the exact same
 * path string.  Non-conflicting records from both diffs are collected into
 * {@link MergeResult#getMergedRecords()}.  Conflicting pairs are collected into
 * {@link MergeResult#getConflicts()} and excluded from {@code mergedRecords}.
 */
public class DiffMerger {

    private DiffMerger() {
        // utility class
    }

    /**
     * Combines {@code diff1} and {@code diff2}.
     *
     * <p>Records with paths unique to one diff are placed in
     * {@link MergeResult#getMergedRecords()} (diff1 records first, then diff2 records).
     * Records from both diffs that share the exact same path string are placed in
     * {@link MergeResult#getConflicts()} as {@link ConflictRecord} instances and excluded
     * from {@code mergedRecords}.
     *
     * @param diff1 first diff, computed against the base object
     * @param diff2 second diff, computed against the same base object
     * @return a {@link MergeResult} describing the combined outcome
     */
    public static MergeResult merge(List<ChangeRecord> diff1, List<ChangeRecord> diff2) {
        // Build path->record maps, preserving insertion order for deterministic output
        Map<String, ChangeRecord> diff1Map = new LinkedHashMap<>();
        for (ChangeRecord r : diff1) {
            diff1Map.put(r.getPath(), r);
        }

        Map<String, ChangeRecord> diff2Map = new LinkedHashMap<>();
        for (ChangeRecord r : diff2) {
            diff2Map.put(r.getPath(), r);
        }

        List<ChangeRecord> merged   = new ArrayList<>();
        List<ConflictRecord> conflicts = new ArrayList<>();

        // Iterate diff1: non-conflicting records go to merged; conflicting go to conflicts
        for (ChangeRecord r : diff1) {
            if (diff2Map.containsKey(r.getPath())) {
                conflicts.add(new ConflictRecord(r.getPath(), r, diff2Map.get(r.getPath())));
            } else {
                merged.add(r);
            }
        }

        // Iterate diff2: only add records whose paths don't exist in diff1 (i.e., non-conflicting)
        for (ChangeRecord r : diff2) {
            if (!diff1Map.containsKey(r.getPath())) {
                merged.add(r);
            }
        }

        return new MergeResult(merged, conflicts);
    }
}
