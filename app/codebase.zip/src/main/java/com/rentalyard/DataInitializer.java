package com.rentalyard;

import com.rentalyard.model.*;
import com.rentalyard.repository.*;
import com.rentalyard.service.ConfigService;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Component
public class DataInitializer implements ApplicationRunner {

    private final MemberRepository memberRepo;
    private final EquipmentRepository equipmentRepo;
    private final RentalRepository rentalRepo;
    private final DepositHoldRepository depositHoldRepo;
    private final DisputeRepository disputeRepo;
    private final PeakSeasonPeriodRepository peakRepo;
    private final CommitteeMemberRepository committeeRepo;
    private final ConfigService configService;

    public DataInitializer(MemberRepository memberRepo,
                           EquipmentRepository equipmentRepo,
                           RentalRepository rentalRepo,
                           DepositHoldRepository depositHoldRepo,
                           DisputeRepository disputeRepo,
                           PeakSeasonPeriodRepository peakRepo,
                           CommitteeMemberRepository committeeRepo,
                           ConfigService configService) {
        this.memberRepo = memberRepo;
        this.equipmentRepo = equipmentRepo;
        this.rentalRepo = rentalRepo;
        this.depositHoldRepo = depositHoldRepo;
        this.disputeRepo = disputeRepo;
        this.peakRepo = peakRepo;
        this.committeeRepo = committeeRepo;
        this.configService = configService;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) throws Exception {
        // Always ensure default discount is set
        configService.ensureDefaultDiscount();

        // Only seed if database is empty
        if (memberRepo.count() > 0) return;

        // Seed 3 members (2 coopMember=true, 1 coopMember=false)
        Member alice = memberRepo.save(new Member("Alice Plumber", "alice@coop.com", true));
        Member bob = memberRepo.save(new Member("Bob Electrician", "bob@coop.com", true));
        Member carol = memberRepo.save(new Member("Carol Contractor", "carol@coop.com", false));

        // Seed 4 equipment listings spread across members
        Equipment pipeWrench = new Equipment();
        pipeWrench.setOwner(alice);
        pipeWrench.setName("Pipe Wrench Set");
        pipeWrench.setDescription("Heavy-duty pipe wrench set, 3 sizes");
        pipeWrench.setDailyRate(15.0);
        pipeWrench.setDepositAmount(50.0);
        pipeWrench.setCondition("Good - minor surface scratches on housing");
        pipeWrench.setAvailableFrom(LocalDate.of(2024, 1, 1));
        pipeWrench.setAvailableTo(LocalDate.of(2025, 12, 31));
        pipeWrench = equipmentRepo.save(pipeWrench);

        Equipment drainSnake = new Equipment();
        drainSnake.setOwner(alice);
        drainSnake.setName("Drain Snake 50ft");
        drainSnake.setDescription("Electric drain snake, 50ft cable");
        drainSnake.setDailyRate(20.0);
        drainSnake.setDepositAmount(75.0);
        drainSnake.setCondition("Good - cable has some wear");
        drainSnake.setAvailableFrom(LocalDate.of(2024, 1, 1));
        drainSnake.setAvailableTo(LocalDate.of(2025, 12, 31));
        drainSnake = equipmentRepo.save(drainSnake);

        Equipment voltageTester = new Equipment();
        voltageTester.setOwner(bob);
        voltageTester.setName("Voltage Tester Kit");
        voltageTester.setDescription("Professional voltage tester with accessories");
        voltageTester.setDailyRate(10.0);
        voltageTester.setDepositAmount(30.0);
        voltageTester.setCondition("Excellent - barely used");
        voltageTester.setAvailableFrom(LocalDate.of(2024, 1, 1));
        voltageTester.setAvailableTo(LocalDate.of(2025, 12, 31));
        voltageTester = equipmentRepo.save(voltageTester);

        Equipment conduitBender = new Equipment();
        conduitBender.setOwner(carol);
        conduitBender.setName("Conduit Bender");
        conduitBender.setDescription("Heavy-duty conduit bender for 1/2 to 1 inch");
        conduitBender.setDailyRate(25.0);
        conduitBender.setDepositAmount(100.0);
        conduitBender.setCondition("Good - some paint wear on handle");
        conduitBender.setAvailableFrom(LocalDate.of(2024, 1, 1));
        conduitBender.setAvailableTo(LocalDate.of(2025, 12, 31));
        conduitBender = equipmentRepo.save(conduitBender);

        // Seed 2 completed rentals
        // Rental 1: Bob rents Pipe Wrench Set (5 days, bob is coopMember -> 10% discount)
        // cost: 5 * 15 * 0.9 = 67.5
        Rental rental1 = new Rental();
        rental1.setEquipment(pipeWrench);
        rental1.setRenter(bob);
        rental1.setStartDate(LocalDate.of(2024, 3, 1));
        rental1.setEndDate(LocalDate.of(2024, 3, 5));
        rental1.setStatus(RentalStatus.COMPLETED);
        rental1.setComputedCost(67.5);
        rental1 = rentalRepo.save(rental1);
        DepositHold hold1 = new DepositHold(rental1, 50.0);
        hold1.setStatus(DepositStatus.RELEASED);
        depositHoldRepo.save(hold1);

        // Rental 2: Carol rents Drain Snake (3 days, carol is NOT coopMember -> no discount)
        // cost: 3 * 20 = 60.0
        Rental rental2 = new Rental();
        rental2.setEquipment(drainSnake);
        rental2.setRenter(carol);
        rental2.setStartDate(LocalDate.of(2024, 4, 1));
        rental2.setEndDate(LocalDate.of(2024, 4, 3));
        rental2.setStatus(RentalStatus.COMPLETED);
        rental2.setComputedCost(60.0);
        rental2 = rentalRepo.save(rental2);
        DepositHold hold2 = new DepositHold(rental2, 75.0);
        hold2.setStatus(DepositStatus.RELEASED);
        depositHoldRepo.save(hold2);

        // Seed 1 open dispute linked to rental2
        Dispute dispute = new Dispute();
        dispute.setRental(rental2);
        dispute.setDescription("Equipment returned with damage to housing");
        dispute.setStatus(DisputeStatus.OPEN);
        dispute.setOutcome(null);
        disputeRepo.save(dispute);

        // Seed 1 peak season period
        peakRepo.save(new PeakSeasonPeriod(
            LocalDate.of(2024, 6, 1),
            LocalDate.of(2024, 8, 31),
            1.5
        ));

        // Set arbitration committee to Alice and Bob's IDs
        committeeRepo.save(new CommitteeMember(alice.getId()));
        committeeRepo.save(new CommitteeMember(bob.getId()));
    }
}
