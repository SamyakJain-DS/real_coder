package com.rentalyard.service;

import com.rentalyard.model.*;
import com.rentalyard.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class ReportService {

    private final MemberRepository memberRepository;
    private final EquipmentRepository equipmentRepository;
    private final RentalRepository rentalRepository;
    private final DisputeRepository disputeRepository;

    public ReportService(MemberRepository memberRepository,
                         EquipmentRepository equipmentRepository,
                         RentalRepository rentalRepository,
                         DisputeRepository disputeRepository) {
        this.memberRepository = memberRepository;
        this.equipmentRepository = equipmentRepository;
        this.rentalRepository = rentalRepository;
        this.disputeRepository = disputeRepository;
    }

    public record EarningsByEquipment(Long equipmentId, String equipmentName, Double totalEarnings) {}
    public record MemberEarningsReport(Long memberId, Double totalEarnings, List<EarningsByEquipment> earningsByEquipment) {}

    public Optional<MemberEarningsReport> getMemberEarnings(Long memberId) {
        if (!memberRepository.existsById(memberId)) return Optional.empty();

        List<Equipment> ownedEquipment = equipmentRepository.findByOwnerId(memberId);
        List<EarningsByEquipment> breakdown = new ArrayList<>();
        double totalEarnings = 0.0;

        for (Equipment eq : ownedEquipment) {
            List<Rental> completed = rentalRepository.findByEquipmentIdAndStatus(eq.getId(), RentalStatus.COMPLETED);
            if (completed.isEmpty()) continue;
            double eqEarnings = completed.stream()
                .mapToDouble(r -> r.getComputedCost() != null ? r.getComputedCost() : 0.0)
                .sum();
            breakdown.add(new EarningsByEquipment(eq.getId(), eq.getName(), eqEarnings));
            totalEarnings += eqEarnings;
        }

        return Optional.of(new MemberEarningsReport(memberId, totalEarnings, breakdown));
    }

    public record DisputedTransactionEntry(Long rentalId, String equipmentName, String ownerName,
                                            String renterName, Double rentalCost,
                                            String disputeStatus, String disputeOutcome) {}

    public List<DisputedTransactionEntry> getDisputedTransactions() {
        return disputeRepository.findAll().stream().map(dispute -> {
            Rental rental = dispute.getRental();
            Equipment equipment = rental.getEquipment();
            Member owner = equipment.getOwner();
            Member renter = rental.getRenter();
            return new DisputedTransactionEntry(
                rental.getId(),
                equipment.getName(),
                owner.getName(),
                renter.getName(),
                rental.getComputedCost(),
                dispute.getStatus().name(),
                dispute.getOutcome() != null ? dispute.getOutcome().name() : null
            );
        }).collect(Collectors.toList());
    }

    public record UtilizationReport(Long equipmentId, String equipmentName,
                                     Long totalAvailableDays, Long totalRentedDays,
                                     Double utilizationPercentage) {}

    public Optional<UtilizationReport> getEquipmentUtilization(Long equipmentId) {
        Optional<Equipment> equipOpt = equipmentRepository.findById(equipmentId);
        if (equipOpt.isEmpty()) return Optional.empty();

        Equipment equipment = equipOpt.get();
        long totalAvailableDays = ChronoUnit.DAYS.between(equipment.getAvailableFrom(), equipment.getAvailableTo()) + 1;

        long totalRentedDays = rentalRepository.findByEquipmentIdAndStatus(equipmentId, RentalStatus.COMPLETED)
            .stream()
            .mapToLong(r -> ChronoUnit.DAYS.between(r.getStartDate(), r.getEndDate()) + 1)
            .sum();

        double utilization = totalAvailableDays == 0 ? 0.0
            : Math.round((double) totalRentedDays / totalAvailableDays * 100.0 * 100.0) / 100.0;

        return Optional.of(new UtilizationReport(
            equipmentId, equipment.getName(), totalAvailableDays, totalRentedDays, utilization
        ));
    }
}
