package com.rentalyard.service;

import com.rentalyard.model.CommitteeMember;
import com.rentalyard.model.Member;
import com.rentalyard.model.PeakSeasonPeriod;
import com.rentalyard.model.SystemConfig;
import com.rentalyard.repository.CommitteeMemberRepository;
import com.rentalyard.repository.MemberRepository;
import com.rentalyard.repository.PeakSeasonPeriodRepository;
import com.rentalyard.repository.SystemConfigRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class ConfigService {

    private static final String MEMBER_DISCOUNT_KEY = "memberDiscount";
    private static final double DEFAULT_DISCOUNT = 10.0;

    private final PeakSeasonPeriodRepository peakRepo;
    private final CommitteeMemberRepository committeeRepo;
    private final SystemConfigRepository configRepo;
    private final MemberRepository memberRepository;

    public ConfigService(PeakSeasonPeriodRepository peakRepo,
                         CommitteeMemberRepository committeeRepo,
                         SystemConfigRepository configRepo,
                         MemberRepository memberRepository) {
        this.peakRepo = peakRepo;
        this.committeeRepo = committeeRepo;
        this.configRepo = configRepo;
        this.memberRepository = memberRepository;
    }

    public PeakSeasonPeriod addPeakSeasonPeriod(LocalDate startDate, LocalDate endDate, Double multiplier) {
        PeakSeasonPeriod period = new PeakSeasonPeriod(startDate, endDate, multiplier);
        return peakRepo.save(period);
    }

    @Transactional(readOnly = true)
    public List<PeakSeasonPeriod> listPeakSeasonPeriods() {
        return peakRepo.findAll();
    }

    public Optional<List<Long>> setArbitrationCommittee(List<Long> memberIds) {
        for (Long memberId : memberIds) {
            if (!memberRepository.existsById(memberId)) {
                return Optional.empty();
            }
        }
        committeeRepo.deleteAll();
        committeeRepo.flush();
        List<CommitteeMember> newMembers = memberIds.stream()
            .map(CommitteeMember::new)
            .collect(Collectors.toList());
        committeeRepo.saveAll(newMembers);
        return Optional.of(memberIds);
    }

    @Transactional(readOnly = true)
    public List<Long> getArbitrationCommittee() {
        return committeeRepo.findAllByOrderByIdAsc().stream()
            .map(CommitteeMember::getMemberId)
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public boolean isCommitteeMember(Long memberId) {
        return committeeRepo.existsByMemberId(memberId);
    }

    public double setMemberDiscount(double percentage) {
        SystemConfig config = new SystemConfig(MEMBER_DISCOUNT_KEY, String.valueOf(percentage));
        configRepo.save(config);
        return percentage;
    }

    @Transactional(readOnly = true)
    public double getMemberDiscountPercentage() {
        return configRepo.findById(MEMBER_DISCOUNT_KEY)
            .map(c -> Double.parseDouble(c.getConfigValue()))
            .orElse(DEFAULT_DISCOUNT);
    }

    public void ensureDefaultDiscount() {
        if (!configRepo.existsById(MEMBER_DISCOUNT_KEY)) {
            configRepo.save(new SystemConfig(MEMBER_DISCOUNT_KEY, String.valueOf(DEFAULT_DISCOUNT)));
        }
    }
}
