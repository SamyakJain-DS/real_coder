package com.rentalyard.service;

import com.rentalyard.model.*;
import com.rentalyard.repository.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class DisputeService {

    @PersistenceContext
    private EntityManager entityManager;

    private final DisputeRepository disputeRepository;
    private final DisputeVoteRepository voteRepository;
    private final RentalRepository rentalRepository;
    private final DepositHoldRepository depositHoldRepository;
    private final ConfigService configService;

    public DisputeService(DisputeRepository disputeRepository,
                          DisputeVoteRepository voteRepository,
                          RentalRepository rentalRepository,
                          DepositHoldRepository depositHoldRepository,
                          ConfigService configService) {
        this.disputeRepository = disputeRepository;
        this.voteRepository = voteRepository;
        this.rentalRepository = rentalRepository;
        this.depositHoldRepository = depositHoldRepository;
        this.configService = configService;
    }

    public enum OpenDisputeResult { SUCCESS, RENTAL_NOT_FOUND, INVALID_RENTAL_STATUS, ALREADY_EXISTS }
    public enum VoteResult { SUCCESS, DISPUTE_NOT_FOUND, NOT_COMMITTEE_MEMBER, DUPLICATE_VOTE, DISPUTE_ALREADY_RESOLVED }

    public record OpenResult(OpenDisputeResult result, Dispute dispute) {}
    public record SubmitVoteResult(VoteResult result, Dispute dispute) {}

    public OpenResult openDispute(Long rentalId, String description) {
        Optional<Rental> rentalOpt = rentalRepository.findById(rentalId);
        if (rentalOpt.isEmpty()) return new OpenResult(OpenDisputeResult.RENTAL_NOT_FOUND, null);

        Rental rental = rentalOpt.get();
        if (rental.getStatus() != RentalStatus.APPROVED && rental.getStatus() != RentalStatus.COMPLETED) {
            return new OpenResult(OpenDisputeResult.INVALID_RENTAL_STATUS, null);
        }

        if (disputeRepository.findByRentalId(rentalId).isPresent()) {
            return new OpenResult(OpenDisputeResult.ALREADY_EXISTS, null);
        }

        Dispute dispute = new Dispute();
        dispute.setRental(rental);
        dispute.setDescription(description);
        dispute.setStatus(DisputeStatus.OPEN);
        dispute.setOutcome(null);

        return new OpenResult(OpenDisputeResult.SUCCESS, disputeRepository.save(dispute));
    }

    public SubmitVoteResult submitVote(Long disputeId, Long voterId, VoteDecision decision) {
        Optional<Dispute> disputeOpt = disputeRepository.findById(disputeId);
        if (disputeOpt.isEmpty()) return new SubmitVoteResult(VoteResult.DISPUTE_NOT_FOUND, null);

        Dispute dispute = disputeOpt.get();

        if (dispute.getStatus() == DisputeStatus.RESOLVED) {
            return new SubmitVoteResult(VoteResult.DISPUTE_ALREADY_RESOLVED, null);
        }

        if (!configService.isCommitteeMember(voterId)) {
            return new SubmitVoteResult(VoteResult.NOT_COMMITTEE_MEMBER, null);
        }

        if (voteRepository.findByDisputeIdAndVoterId(disputeId, voterId).isPresent()) {
            return new SubmitVoteResult(VoteResult.DUPLICATE_VOTE, null);
        }

        DisputeVote vote = new DisputeVote(dispute, voterId, decision);
        voteRepository.save(vote);

        // Flush pending writes so the vote INSERT is in the DB, then force a full
        // entity reload to bypass the JPA first-level cache and get a fresh votes list
        entityManager.flush();
        entityManager.refresh(dispute);

        // Check if all committee members have voted
        List<Long> committeeIds = configService.getArbitrationCommittee();
        List<DisputeVote> allVotes = voteRepository.findByDisputeId(disputeId);

        boolean allVoted = committeeIds.stream()
            .allMatch(mid -> allVotes.stream().anyMatch(v -> v.getVoterId().equals(mid)));

        if (allVoted) {
            long ownerFavoredCount = allVotes.stream()
                .filter(v -> v.getDecision() == VoteDecision.OWNER_FAVORED).count();
            long renterFavoredCount = allVotes.stream()
                .filter(v -> v.getDecision() == VoteDecision.RENTER_FAVORED).count();

            DisputeOutcome outcome = (ownerFavoredCount > renterFavoredCount)
                ? DisputeOutcome.OWNER_FAVORED
                : DisputeOutcome.RENTER_FAVORED;

            dispute.setStatus(DisputeStatus.RESOLVED);
            dispute.setOutcome(outcome);
            dispute = disputeRepository.save(dispute);

            // Apply deposit outcome
            depositHoldRepository.findByRentalId(dispute.getRental().getId()).ifPresent(hold -> {
                hold.setStatus(outcome == DisputeOutcome.OWNER_FAVORED
                    ? DepositStatus.FORFEITED : DepositStatus.RELEASED);
                depositHoldRepository.save(hold);
            });
        }

        return new SubmitVoteResult(VoteResult.SUCCESS, dispute);
    }

    @Transactional(readOnly = true)
    public Optional<Dispute> getDispute(Long id) {
        return disputeRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public List<Dispute> getAllDisputes() {
        return disputeRepository.findAll();
    }
}
