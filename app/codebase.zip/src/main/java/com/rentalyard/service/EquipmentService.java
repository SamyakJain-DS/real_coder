package com.rentalyard.service;

import com.rentalyard.model.Equipment;
import com.rentalyard.model.Member;
import com.rentalyard.repository.EquipmentRepository;
import com.rentalyard.repository.MemberRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class EquipmentService {

    private final EquipmentRepository equipmentRepository;
    private final MemberRepository memberRepository;

    public EquipmentService(EquipmentRepository equipmentRepository, MemberRepository memberRepository) {
        this.equipmentRepository = equipmentRepository;
        this.memberRepository = memberRepository;
    }

    public Optional<Equipment> createEquipment(Long ownerId, String name, String description,
                                                Double dailyRate, Double depositAmount, String condition,
                                                LocalDate availableFrom, LocalDate availableTo) {
        Optional<Member> owner = memberRepository.findById(ownerId);
        if (owner.isEmpty()) {
            return Optional.empty();
        }
        Equipment equipment = new Equipment();
        equipment.setOwner(owner.get());
        equipment.setName(name);
        equipment.setDescription(description);
        equipment.setDailyRate(dailyRate);
        equipment.setDepositAmount(depositAmount);
        equipment.setCondition(condition);
        equipment.setAvailableFrom(availableFrom);
        equipment.setAvailableTo(availableTo);
        return Optional.of(equipmentRepository.save(equipment));
    }

    @Transactional(readOnly = true)
    public Optional<Equipment> getEquipment(Long id) {
        return equipmentRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public Optional<List<Equipment>> listByOwner(Long ownerId) {
        if (!memberRepository.existsById(ownerId)) {
            return Optional.empty();
        }
        return Optional.of(equipmentRepository.findByOwnerId(ownerId));
    }
}
