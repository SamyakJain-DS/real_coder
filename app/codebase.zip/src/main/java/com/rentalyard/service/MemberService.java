package com.rentalyard.service;

import com.rentalyard.model.Member;
import com.rentalyard.repository.MemberRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional
public class MemberService {

    private final MemberRepository memberRepository;

    public MemberService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    public Member createMember(String name, String email, boolean coopMember) {
        Member member = new Member(name, email, coopMember);
        return memberRepository.save(member);
    }

    @Transactional(readOnly = true)
    public Optional<Member> getMember(Long id) {
        return memberRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public boolean exists(Long id) {
        return memberRepository.existsById(id);
    }
}
