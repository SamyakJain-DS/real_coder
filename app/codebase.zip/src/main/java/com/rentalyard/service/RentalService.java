package com.rentalyard.service;

import com.rentalyard.model.*;
import com.rentalyard.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RentalService {

    private final RentalRepository rentalRepository;
    private final EquipmentRepository equipmentRepository;
    private final MemberRepository memberRepository;
    private final DepositHoldRepository depositHoldRepository;
    private final PeakSeasonPeriodRepository peakSeasonRepository;
    private final ConfigService configService;

    public RentalService(RentalRepository rentalRepository,
                         EquipmentRepository equipmentRepository,
                         MemberRepository memberRepository,
                         DepositHoldRepository depositHoldRepository,
                         PeakSeasonPeriodRepository peakSeasonRepository,
                         ConfigService configService) {
        this.rentalRepository = rentalRepository;
        this.equipmentRepository = equipmentRepository;
        this.memberRepository = memberRepository;
        this.depositHoldRepository = depositHoldRepository;
        this.peakSeasonRepository = peakSeasonRepository;
        this.configService = configService;
    }

    public enum CreateResult { SUCCESS, EQUIPMENT_NOT_FOUND, RENTER_NOT_FOUND, WINDOW_OUTSIDE_AVAILABILITY, DATE_OVERLAP_CONFLICT }

    public record CreateRentalResult(CreateResult result, Rental rental) {}

    public CreateRentalResult createRentalRequest(Long equipmentId, Long renterId,
                                                   LocalDate startDate, LocalDate endDate) {
        Optional<Equipment> equipOpt = equipmentRepository.findById(equipmentId);
        if (equipOpt.isEmpty()) return new CreateRentalResult(CreateResult.EQUIPMENT_NOT_FOUND, null);

        Optional<Member> renterOpt = memberRepository.findById(renterId);
        if (renterOpt.isEmpty()) return new CreateRentalResult(CreateResult.RENTER_NOT_FOUND, null);

        Equipment equipment = equipOpt.get();

        if (startDate.isBefore(equipment.getAvailableFrom())
                || endDate.isAfter(equipment.getAvailableTo())) {
            return new CreateRentalResult(CreateResult.WINDOW_OUTSIDE_AVAILABILITY, null);
        }

        // Check for overlapping PENDING or APPROVED rentals
        List<Rental> overlapping = rentalRepository.findOverlapping(
            equipmentId,
            List.of(RentalStatus.PENDING, RentalStatus.APPROVED),
            startDate, endDate
        );
        if (!overlapping.isEmpty()) {
            return new CreateRentalResult(CreateResult.DATE_OVERLAP_CONFLICT, null);
        }

        Rental rental = new Rental();
        rental.setEquipment(equipment);
        rental.setRenter(renterOpt.get());
        rental.setStartDate(startDate);
        rental.setEndDate(endDate);
        rental.setStatus(RentalStatus.PENDING);
        rental.setComputedCost(null);

        return new CreateRentalResult(CreateResult.SUCCESS, rentalRepository.save(rental));
    }

    public enum ActionResult { SUCCESS, NOT_FOUND, INVALID_STATUS }

    public record ApproveResult(ActionResult result, Rental rental) {}

    public ApproveResult approveRental(Long id) {
        Optional<Rental> rentalOpt = rentalRepository.findById(id);
        if (rentalOpt.isEmpty()) return new ApproveResult(ActionResult.NOT_FOUND, null);

        Rental rental = rentalOpt.get();
        if (rental.getStatus() != RentalStatus.PENDING) {
            return new ApproveResult(ActionResult.INVALID_STATUS, null);
        }

        double cost = computeCost(rental);
        rental.setComputedCost(cost);
        rental.setStatus(RentalStatus.APPROVED);
        rental = rentalRepository.save(rental);

        DepositHold hold = new DepositHold(rental, rental.getEquipment().getDepositAmount());
        depositHoldRepository.save(hold);

        return new ApproveResult(ActionResult.SUCCESS, rental);
    }

    public record ActionRentalResult(ActionResult result, Rental rental) {}

    public ActionRentalResult rejectRental(Long id) {
        Optional<Rental> rentalOpt = rentalRepository.findById(id);
        if (rentalOpt.isEmpty()) return new ActionRentalResult(ActionResult.NOT_FOUND, null);

        Rental rental = rentalOpt.get();
        if (rental.getStatus() != RentalStatus.PENDING) {
            return new ActionRentalResult(ActionResult.INVALID_STATUS, null);
        }

        rental.setStatus(RentalStatus.REJECTED);
        return new ActionRentalResult(ActionResult.SUCCESS, rentalRepository.save(rental));
    }

    public ActionRentalResult completeRental(Long id) {
        Optional<Rental> rentalOpt = rentalRepository.findById(id);
        if (rentalOpt.isEmpty()) return new ActionRentalResult(ActionResult.NOT_FOUND, null);

        Rental rental = rentalOpt.get();
        if (rental.getStatus() != RentalStatus.APPROVED) {
            return new ActionRentalResult(ActionResult.INVALID_STATUS, null);
        }

        rental.setStatus(RentalStatus.COMPLETED);
        rental = rentalRepository.save(rental);

        depositHoldRepository.findByRentalId(rental.getId()).ifPresent(hold -> {
            hold.setStatus(DepositStatus.RELEASED);
            depositHoldRepository.save(hold);
        });

        return new ActionRentalResult(ActionResult.SUCCESS, rental);
    }

    @Transactional(readOnly = true)
    public Optional<Rental> getRental(Long id) {
        return rentalRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public Optional<DepositHold> getDepositHold(Long rentalId) {
        if (!rentalRepository.existsById(rentalId)) return Optional.empty();
        return depositHoldRepository.findByRentalId(rentalId);
    }

    @Transactional(readOnly = true)
    public Optional<String> getDepositStatus(Long rentalId) {
        return depositHoldRepository.findByRentalId(rentalId)
            .map(h -> h.getStatus().name());
    }

    private double computeCost(Rental rental) {
        Equipment equipment = rental.getEquipment();
        Member renter = rental.getRenter();
        List<PeakSeasonPeriod> peakPeriods = peakSeasonRepository.findAll();

        double total = 0.0;
        LocalDate current = rental.getStartDate();
        while (!current.isAfter(rental.getEndDate())) {
            double multiplier = 1.0;
            for (PeakSeasonPeriod period : peakPeriods) {
                if (!current.isBefore(period.getStartDate()) && !current.isAfter(period.getEndDate())) {
                    multiplier = Math.max(multiplier, period.getMultiplier());
                }
            }
            total += equipment.getDailyRate() * multiplier;
            current = current.plusDays(1);
        }

        double discountPct = configService.getMemberDiscountPercentage();
        if (renter.isCoopMember()) {
            total = total * (1.0 - discountPct / 100.0);
        }

        return total;
    }
}
