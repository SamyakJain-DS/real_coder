package com.rentalyard.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "disputes")
public class Dispute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "rental_id", nullable = false, unique = true)
    private Rental rental;

    @Column(length = 2000)
    private String description;

    @Enumerated(EnumType.STRING)
    private DisputeStatus status;

    @Enumerated(EnumType.STRING)
    private DisputeOutcome outcome;

    @OneToMany(mappedBy = "dispute", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<DisputeVote> votes = new ArrayList<>();

    public Dispute() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Rental getRental() { return rental; }
    public void setRental(Rental rental) { this.rental = rental; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public DisputeStatus getStatus() { return status; }
    public void setStatus(DisputeStatus status) { this.status = status; }
    public DisputeOutcome getOutcome() { return outcome; }
    public void setOutcome(DisputeOutcome outcome) { this.outcome = outcome; }
    public List<DisputeVote> getVotes() { return votes; }
    public void setVotes(List<DisputeVote> votes) { this.votes = votes; }
}
