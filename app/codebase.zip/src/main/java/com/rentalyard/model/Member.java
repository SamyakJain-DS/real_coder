package com.rentalyard.model;

import jakarta.persistence.*;

@Entity
@Table(name = "members")
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private boolean coopMember;

    public Member() {}

    public Member(String name, String email, boolean coopMember) {
        this.name = name;
        this.email = email;
        this.coopMember = coopMember;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public boolean isCoopMember() { return coopMember; }
    public void setCoopMember(boolean coopMember) { this.coopMember = coopMember; }
}
