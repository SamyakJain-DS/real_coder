package com.rentalyard.model;

import jakarta.persistence.*;

@Entity
@Table(name = "dispute_votes")
public class DisputeVote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "dispute_id", nullable = false)
    private Dispute dispute;

    private Long voterId;

    @Enumerated(EnumType.STRING)
    private VoteDecision decision;

    public DisputeVote() {}

    public DisputeVote(Dispute dispute, Long voterId, VoteDecision decision) {
        this.dispute = dispute;
        this.voterId = voterId;
        this.decision = decision;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Dispute getDispute() { return dispute; }
    public void setDispute(Dispute dispute) { this.dispute = dispute; }
    public Long getVoterId() { return voterId; }
    public void setVoterId(Long voterId) { this.voterId = voterId; }
    public VoteDecision getDecision() { return decision; }
    public void setDecision(VoteDecision decision) { this.decision = decision; }
}
