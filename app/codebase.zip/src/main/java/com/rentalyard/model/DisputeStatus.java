package com.rentalyard.model;

public enum DisputeStatus {
    OPEN, RESOLVED
}
