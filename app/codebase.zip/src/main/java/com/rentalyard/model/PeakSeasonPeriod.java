package com.rentalyard.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "peak_season_periods")
public class PeakSeasonPeriod {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate startDate;
    private LocalDate endDate;
    private Double multiplier;

    public PeakSeasonPeriod() {}

    public PeakSeasonPeriod(LocalDate startDate, LocalDate endDate, Double multiplier) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.multiplier = multiplier;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public Double getMultiplier() { return multiplier; }
    public void setMultiplier(Double multiplier) { this.multiplier = multiplier; }
}
