package com.rentalyard.model;

import jakarta.persistence.*;

@Entity
@Table(name = "deposit_holds")
public class DepositHold {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "rental_id", nullable = false, unique = true)
    private Rental rental;

    private Double amount;

    @Enumerated(EnumType.STRING)
    private DepositStatus status;

    public DepositHold() {}

    public DepositHold(Rental rental, Double amount) {
        this.rental = rental;
        this.amount = amount;
        this.status = DepositStatus.HELD;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Rental getRental() { return rental; }
    public void setRental(Rental rental) { this.rental = rental; }
    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }
    public DepositStatus getStatus() { return status; }
    public void setStatus(DepositStatus status) { this.status = status; }
}
