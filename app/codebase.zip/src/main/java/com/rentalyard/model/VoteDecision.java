package com.rentalyard.model;

public enum VoteDecision {
    OWNER_FAVORED, RENTER_FAVORED
}
