package com.rentalyard.model;

public enum RentalStatus {
    PENDING, APPROVED, REJECTED, COMPLETED
}
