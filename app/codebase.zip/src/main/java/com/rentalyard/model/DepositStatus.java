package com.rentalyard.model;

public enum DepositStatus {
    HELD, RELEASED, FORFEITED
}
