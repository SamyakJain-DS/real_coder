package com.rentalyard.model;

public enum DisputeOutcome {
    OWNER_FAVORED, RENTER_FAVORED
}
