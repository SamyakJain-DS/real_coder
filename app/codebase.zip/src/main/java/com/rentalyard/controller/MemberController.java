package com.rentalyard.controller;

import com.rentalyard.model.Member;
import com.rentalyard.service.MemberService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
public class MemberController {

    private final MemberService memberService;

    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    @PostMapping("/api/members")
    public ResponseEntity<?> createMember(@RequestBody Map<String, Object> body) {
        String name = (String) body.get("name");
        String email = (String) body.get("email");
        boolean coopMember = Boolean.TRUE.equals(body.get("coopMember"));
        Member member = memberService.createMember(name, email, coopMember);
        return ResponseEntity.status(HttpStatus.CREATED).body(toMap(member));
    }

    @GetMapping("/api/members/{id}")
    public ResponseEntity<?> getMember(@PathVariable Long id) {
        Optional<Member> opt = memberService.getMember(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(toMap(opt.get()));
    }

    private Map<String, Object> toMap(Member m) {
        return Map.of(
            "id", m.getId(),
            "name", m.getName(),
            "email", m.getEmail(),
            "coopMember", m.isCoopMember()
        );
    }
}
