package com.rentalyard.controller;

import com.rentalyard.model.*;
import com.rentalyard.service.DisputeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
public class DisputeController {

    private final DisputeService disputeService;

    public DisputeController(DisputeService disputeService) {
        this.disputeService = disputeService;
    }

    @PostMapping("/api/disputes")
    public ResponseEntity<?> openDispute(@RequestBody Map<String, Object> body) {
        Long rentalId = toLong(body.get("rentalId"));
        String description = (String) body.get("description");

        DisputeService.OpenResult result = disputeService.openDispute(rentalId, description);
        switch (result.result()) {
            case SUCCESS:
                return ResponseEntity.status(HttpStatus.CREATED).body(toMap(result.dispute()));
            case RENTAL_NOT_FOUND:
                return ResponseEntity.badRequest().body(Map.of("error", "Rental not found"));
            case INVALID_RENTAL_STATUS:
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Rental is not in APPROVED or COMPLETED status"));
            case ALREADY_EXISTS:
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "A dispute already exists for this rental"));
            default:
                return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/api/disputes/{id}/vote")
    public ResponseEntity<?> submitVote(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        Long voterId = toLong(body.get("voterId"));
        VoteDecision decision = VoteDecision.valueOf((String) body.get("decision"));

        DisputeService.SubmitVoteResult result = disputeService.submitVote(id, voterId, decision);
        switch (result.result()) {
            case SUCCESS:
                return ResponseEntity.ok(toMap(result.dispute()));
            case DISPUTE_NOT_FOUND:
                return ResponseEntity.notFound().build();
            case NOT_COMMITTEE_MEMBER:
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Voter is not a committee member", "code", "NOT_COMMITTEE_MEMBER"));
            case DUPLICATE_VOTE:
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Voter has already submitted a vote", "code", "DUPLICATE_VOTE"));
            case DISPUTE_ALREADY_RESOLVED:
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Dispute is already resolved", "code", "DISPUTE_ALREADY_RESOLVED"));
            default:
                return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/api/disputes/{id}")
    public ResponseEntity<?> getDispute(@PathVariable Long id) {
        Optional<Dispute> opt = disputeService.getDispute(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(toMap(opt.get()));
    }

    private Map<String, Object> toMap(Dispute d) {
        List<Map<String, Object>> votes = d.getVotes().stream()
            .map(v -> {
                java.util.LinkedHashMap<String, Object> vm = new java.util.LinkedHashMap<>();
                vm.put("voterId", v.getVoterId());
                vm.put("decision", v.getDecision().name());
                return (Map<String, Object>) vm;
            })
            .collect(Collectors.toList());

        java.util.LinkedHashMap<String, Object> map = new java.util.LinkedHashMap<>();
        map.put("id", d.getId());
        map.put("rentalId", d.getRental().getId());
        map.put("description", d.getDescription());
        map.put("status", d.getStatus().name());
        map.put("outcome", d.getOutcome() != null ? d.getOutcome().name() : null);
        map.put("votes", votes);
        return map;
    }

    private Long toLong(Object value) {
        if (value instanceof Number) return ((Number) value).longValue();
        return null;
    }
}
