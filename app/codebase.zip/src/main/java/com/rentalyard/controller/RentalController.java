package com.rentalyard.controller;

import com.rentalyard.model.*;
import com.rentalyard.service.RentalService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;

@RestController
public class RentalController {

    private final RentalService rentalService;

    public RentalController(RentalService rentalService) {
        this.rentalService = rentalService;
    }

    @PostMapping("/api/rentals")
    public ResponseEntity<?> createRentalRequest(@RequestBody Map<String, Object> body) {
        Long equipmentId = toLong(body.get("equipmentId"));
        Long renterId = toLong(body.get("renterId"));
        LocalDate startDate = LocalDate.parse((String) body.get("startDate"));
        LocalDate endDate = LocalDate.parse((String) body.get("endDate"));

        RentalService.CreateRentalResult result = rentalService.createRentalRequest(
            equipmentId, renterId, startDate, endDate);

        switch (result.result()) {
            case SUCCESS:
                return ResponseEntity.status(HttpStatus.CREATED).body(toCreateMap(result.rental()));
            case WINDOW_OUTSIDE_AVAILABILITY:
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Dates fall outside the equipment's availability window",
                                 "code", "WINDOW_OUTSIDE_AVAILABILITY"));
            case DATE_OVERLAP_CONFLICT:
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Dates overlap with an existing booking",
                                 "code", "DATE_OVERLAP_CONFLICT"));
            default:
                return ResponseEntity.badRequest().body(Map.of("error", "Invalid request"));
        }
    }

    @PostMapping("/api/rentals/{id}/approve")
    public ResponseEntity<?> approveRental(@PathVariable Long id) {
        RentalService.ApproveResult result = rentalService.approveRental(id);
        switch (result.result()) {
            case SUCCESS:
                return ResponseEntity.ok(toMapWithDepositStatus(result.rental()));
            case NOT_FOUND:
                return ResponseEntity.notFound().build();
            case INVALID_STATUS:
                return ResponseEntity.badRequest().body(Map.of("error", "Rental is not in PENDING status"));
            default:
                return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/api/rentals/{id}/reject")
    public ResponseEntity<?> rejectRental(@PathVariable Long id) {
        RentalService.ActionRentalResult result = rentalService.rejectRental(id);
        switch (result.result()) {
            case SUCCESS:
                return ResponseEntity.ok(toMapWithDepositStatus(result.rental()));
            case NOT_FOUND:
                return ResponseEntity.notFound().build();
            case INVALID_STATUS:
                return ResponseEntity.badRequest().body(Map.of("error", "Rental is not in PENDING status"));
            default:
                return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/api/rentals/{id}/complete")
    public ResponseEntity<?> completeRental(@PathVariable Long id) {
        RentalService.ActionRentalResult result = rentalService.completeRental(id);
        switch (result.result()) {
            case SUCCESS:
                return ResponseEntity.ok(toMapWithDepositStatus(result.rental()));
            case NOT_FOUND:
                return ResponseEntity.notFound().build();
            case INVALID_STATUS:
                return ResponseEntity.badRequest().body(Map.of("error", "Rental is not in APPROVED status"));
            default:
                return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/api/rentals/{id}")
    public ResponseEntity<?> getRental(@PathVariable Long id) {
        Optional<Rental> opt = rentalService.getRental(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(toMapWithDepositStatus(opt.get()));
    }

    @GetMapping(value = "/api/rentals/{id}/checklist", produces = "text/html")
    public ResponseEntity<String> getHandoverChecklist(@PathVariable Long id) {
        Optional<Rental> rentalOpt = rentalService.getRental(id);
        if (rentalOpt.isEmpty()) return ResponseEntity.notFound().build();

        Rental rental = rentalOpt.get();
        if (rental.getStatus() != RentalStatus.APPROVED) {
            return ResponseEntity.badRequest().body("<p>Rental is not in APPROVED status</p>");
        }

        Equipment equipment = rental.getEquipment();
        Member owner = equipment.getOwner();
        Member renter = rental.getRenter();

        String html = buildChecklistHtml(equipment, owner, renter, rental);
        return ResponseEntity.ok()
            .header("Content-Type", "text/html; charset=UTF-8")
            .body(html);
    }

    @GetMapping("/api/rentals/{id}/deposit")
    public ResponseEntity<?> getDepositHold(@PathVariable Long id) {
        Optional<DepositHold> holdOpt = rentalService.getDepositHold(id);
        if (holdOpt.isEmpty()) return ResponseEntity.notFound().build();
        DepositHold hold = holdOpt.get();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("rentalId", hold.getRental().getId());
        body.put("amount", hold.getAmount());
        body.put("status", hold.getStatus().name());
        return ResponseEntity.ok(body);
    }

    private String buildChecklistHtml(Equipment equipment, Member owner, Member renter, Rental rental) {
        return "<!DOCTYPE html><html><head><title>Equipment Handover Checklist</title>"
            + "<style>body{font-family:Arial,sans-serif;max-width:800px;margin:40px auto;padding:0 20px;}"
            + "h1{text-align:center;}table{width:100%;border-collapse:collapse;}"
            + "td,th{padding:8px;border:1px solid #ddd;}"
            + ".signature-block{margin-top:40px;padding:20px;border:1px solid #ccc;}"
            + ".signature-line{border:none;border-bottom:2px solid #000;height:40px;margin-top:10px;}"
            + "</style></head><body>"
            + "<h1>Equipment Handover Checklist</h1>"
            + "<h2>Equipment Details</h2>"
            + "<table>"
            + "<tr><td><strong>Equipment Name</strong></td><td>" + escHtml(equipment.getName()) + "</td></tr>"
            + "<tr><td><strong>Owner</strong></td><td>" + escHtml(owner.getName()) + "</td></tr>"
            + "<tr><td><strong>Condition at Handover</strong></td><td>" + escHtml(equipment.getCondition()) + "</td></tr>"
            + "</table>"
            + "<h2>Rental Details</h2>"
            + "<table>"
            + "<tr><td><strong>Renter</strong></td><td>" + escHtml(renter.getName()) + "</td></tr>"
            + "<tr><td><strong>Rental Period</strong></td><td>" + rental.getStartDate() + " to " + rental.getEndDate() + "</td></tr>"
            + "<tr><td><strong>Rental Cost</strong></td><td>$" + String.format("%.2f", rental.getComputedCost()) + "</td></tr>"
            + "<tr><td><strong>Security Deposit</strong></td><td>$" + String.format("%.2f", equipment.getDepositAmount()) + "</td></tr>"
            + "</table>"
            + "<div class='signature-block'>"
            + "<p><strong>Equipment Owner Signature</strong></p>"
            + "<p>Name: " + escHtml(owner.getName()) + "</p>"
            + "<hr class='signature-line'>"
            + "</div>"
            + "<div class='signature-block'>"
            + "<p><strong>Renter Signature</strong></p>"
            + "<p>Name: " + escHtml(renter.getName()) + "</p>"
            + "<hr class='signature-line'>"
            + "</div>"
            + "</body></html>";
    }

    private String escHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private Map<String, Object> toCreateMap(Rental r) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", r.getId());
        map.put("equipmentId", r.getEquipment().getId());
        map.put("renterId", r.getRenter().getId());
        map.put("startDate", r.getStartDate().toString());
        map.put("endDate", r.getEndDate().toString());
        map.put("status", r.getStatus().name());
        map.put("computedCost", r.getComputedCost());
        return map;
    }

    private Map<String, Object> toMap(Rental r, String depositStatus) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", r.getId());
        map.put("equipmentId", r.getEquipment().getId());
        map.put("renterId", r.getRenter().getId());
        map.put("startDate", r.getStartDate().toString());
        map.put("endDate", r.getEndDate().toString());
        map.put("status", r.getStatus().name());
        map.put("computedCost", r.getComputedCost());
        map.put("depositStatus", depositStatus);
        return map;
    }

    private Map<String, Object> toMapWithDepositStatus(Rental r) {
        String depositStatus = rentalService.getDepositStatus(r.getId()).orElse(null);
        return toMap(r, depositStatus);
    }

    private Long toLong(Object value) {
        if (value instanceof Number) return ((Number) value).longValue();
        return null;
    }
}
