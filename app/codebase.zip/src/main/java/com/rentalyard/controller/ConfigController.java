package com.rentalyard.controller;

import com.rentalyard.model.PeakSeasonPeriod;
import com.rentalyard.service.ConfigService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
public class ConfigController {

    private final ConfigService configService;

    public ConfigController(ConfigService configService) {
        this.configService = configService;
    }

    @PostMapping("/api/config/peak-season")
    public ResponseEntity<?> addPeakSeasonPeriod(@RequestBody Map<String, Object> body) {
        LocalDate startDate = LocalDate.parse((String) body.get("startDate"));
        LocalDate endDate = LocalDate.parse((String) body.get("endDate"));
        Double multiplier = toDouble(body.get("multiplier"));
        PeakSeasonPeriod period = configService.addPeakSeasonPeriod(startDate, endDate, multiplier);
        return ResponseEntity.status(HttpStatus.CREATED).body(toMap(period));
    }

    @GetMapping("/api/config/peak-season")
    public ResponseEntity<?> listPeakSeasonPeriods() {
        List<Map<String, Object>> list = configService.listPeakSeasonPeriods()
            .stream().map(this::toMap).collect(Collectors.toList());
        return ResponseEntity.ok(list);
    }

    @PostMapping("/api/config/committee")
    public ResponseEntity<?> setArbitrationCommittee(@RequestBody Map<String, Object> body) {
        @SuppressWarnings("unchecked")
        List<Object> rawIds = (List<Object>) body.get("memberIds");
        List<Long> memberIds = rawIds.stream()
            .map(o -> ((Number) o).longValue())
            .collect(Collectors.toList());

        Optional<List<Long>> result = configService.setArbitrationCommittee(memberIds);
        if (result.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "One or more member IDs do not exist"));
        }
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("memberIds", result.get());
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/api/config/committee")
    public ResponseEntity<?> getArbitrationCommittee() {
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("memberIds", configService.getArbitrationCommittee());
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/api/config/member-discount")
    public ResponseEntity<?> setMemberDiscount(@RequestBody Map<String, Object> body) {
        Double percentage = toDouble(body.get("discountPercentage"));
        double result = configService.setMemberDiscount(percentage);
        return ResponseEntity.ok(Map.of("discountPercentage", result));
    }

    @GetMapping("/api/config/member-discount")
    public ResponseEntity<?> getMemberDiscount() {
        return ResponseEntity.ok(Map.of("discountPercentage", configService.getMemberDiscountPercentage()));
    }

    private Map<String, Object> toMap(PeakSeasonPeriod p) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", p.getId());
        m.put("startDate", p.getStartDate().toString());
        m.put("endDate", p.getEndDate().toString());
        m.put("multiplier", p.getMultiplier());
        return m;
    }

    private Double toDouble(Object value) {
        if (value instanceof Number) return ((Number) value).doubleValue();
        return null;
    }
}
