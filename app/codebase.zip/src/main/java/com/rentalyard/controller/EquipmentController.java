package com.rentalyard.controller;

import com.rentalyard.model.Equipment;
import com.rentalyard.service.EquipmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
public class EquipmentController {

    private final EquipmentService equipmentService;

    public EquipmentController(EquipmentService equipmentService) {
        this.equipmentService = equipmentService;
    }

    @PostMapping("/api/equipment")
    public ResponseEntity<?> registerEquipment(@RequestBody Map<String, Object> body) {
        Long ownerId = toLong(body.get("ownerId"));
        String name = (String) body.get("name");
        String description = (String) body.get("description");
        Double dailyRate = toDouble(body.get("dailyRate"));
        Double depositAmount = toDouble(body.get("depositAmount"));
        String condition = (String) body.get("condition");
        LocalDate availableFrom = LocalDate.parse((String) body.get("availableFrom"));
        LocalDate availableTo = LocalDate.parse((String) body.get("availableTo"));

        Optional<Equipment> result = equipmentService.createEquipment(
            ownerId, name, description, dailyRate, depositAmount, condition, availableFrom, availableTo);

        if (result.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Owner not found"));
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(toMap(result.get()));
    }

    @GetMapping("/api/equipment/{id}")
    public ResponseEntity<?> getEquipment(@PathVariable Long id) {
        Optional<Equipment> opt = equipmentService.getEquipment(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(toMap(opt.get()));
    }

    @GetMapping("/api/members/{ownerId}/equipment")
    public ResponseEntity<?> listEquipmentByOwner(@PathVariable Long ownerId) {
        Optional<List<Equipment>> opt = equipmentService.listByOwner(ownerId);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(opt.get().stream().map(this::toMap).collect(Collectors.toList()));
    }

    private Map<String, Object> toMap(Equipment e) {
        Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("id", e.getId());
        m.put("ownerId", e.getOwner().getId());
        m.put("name", e.getName());
        m.put("description", e.getDescription());
        m.put("dailyRate", e.getDailyRate());
        m.put("depositAmount", e.getDepositAmount());
        m.put("condition", e.getCondition());
        m.put("availableFrom", e.getAvailableFrom().toString());
        m.put("availableTo", e.getAvailableTo().toString());
        return m;
    }

    private Long toLong(Object value) {
        if (value instanceof Number) return ((Number) value).longValue();
        return null;
    }

    private Double toDouble(Object value) {
        if (value instanceof Number) return ((Number) value).doubleValue();
        return null;
    }
}
