package com.rentalyard.controller;

import com.rentalyard.service.ReportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/api/reports/members/{memberId}/earnings")
    public ResponseEntity<?> getMemberEarnings(@PathVariable Long memberId) {
        Optional<ReportService.MemberEarningsReport> opt = reportService.getMemberEarnings(memberId);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        ReportService.MemberEarningsReport report = opt.get();
        List<Map<String, Object>> breakdown = report.earningsByEquipment().stream()
            .map(e -> {
                LinkedHashMap<String, Object> m = new LinkedHashMap<>();
                m.put("equipmentId", e.equipmentId());
                m.put("equipmentName", e.equipmentName());
                m.put("totalEarnings", e.totalEarnings());
                return (Map<String, Object>) m;
            })
            .collect(Collectors.toList());

        LinkedHashMap<String, Object> body = new LinkedHashMap<>();
        body.put("memberId", report.memberId());
        body.put("totalEarnings", report.totalEarnings());
        body.put("earningsByEquipment", breakdown);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/api/reports/disputes")
    public ResponseEntity<?> getDisputedTransactions() {
        List<Map<String, Object>> result = reportService.getDisputedTransactions().stream()
            .map(entry -> {
                LinkedHashMap<String, Object> m = new LinkedHashMap<>();
                m.put("rentalId", entry.rentalId());
                m.put("equipmentName", entry.equipmentName());
                m.put("ownerName", entry.ownerName());
                m.put("renterName", entry.renterName());
                m.put("rentalCost", entry.rentalCost());
                m.put("disputeStatus", entry.disputeStatus());
                m.put("disputeOutcome", entry.disputeOutcome());
                return (Map<String, Object>) m;
            })
            .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/api/reports/equipment/{equipmentId}/utilization")
    public ResponseEntity<?> getEquipmentUtilization(@PathVariable Long equipmentId) {
        Optional<ReportService.UtilizationReport> opt = reportService.getEquipmentUtilization(equipmentId);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        ReportService.UtilizationReport report = opt.get();
        LinkedHashMap<String, Object> body = new LinkedHashMap<>();
        body.put("equipmentId", report.equipmentId());
        body.put("equipmentName", report.equipmentName());
        body.put("totalAvailableDays", report.totalAvailableDays());
        body.put("totalRentedDays", report.totalRentedDays());
        body.put("utilizationPercentage", report.utilizationPercentage());
        return ResponseEntity.ok(body);
    }
}
