package com.rentalyard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentalYardApplication {

    public static void main(String[] args) {
        SpringApplication.run(RentalYardApplication.class, args);
    }
}
