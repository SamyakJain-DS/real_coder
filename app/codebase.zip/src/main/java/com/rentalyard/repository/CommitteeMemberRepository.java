package com.rentalyard.repository;

import com.rentalyard.model.CommitteeMember;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommitteeMemberRepository extends JpaRepository<CommitteeMember, Long> {
    List<CommitteeMember> findAllByOrderByIdAsc();
    boolean existsByMemberId(Long memberId);
}
