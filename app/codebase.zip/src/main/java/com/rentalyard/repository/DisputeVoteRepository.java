package com.rentalyard.repository;

import com.rentalyard.model.DisputeVote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DisputeVoteRepository extends JpaRepository<DisputeVote, Long> {
    List<DisputeVote> findByDisputeId(Long disputeId);
    Optional<DisputeVote> findByDisputeIdAndVoterId(Long disputeId, Long voterId);
}
