package com.rentalyard.repository;

import com.rentalyard.model.PeakSeasonPeriod;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PeakSeasonPeriodRepository extends JpaRepository<PeakSeasonPeriod, Long> {
}
