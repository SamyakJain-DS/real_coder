package com.rentalyard.repository;

import com.rentalyard.model.Rental;
import com.rentalyard.model.RentalStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface RentalRepository extends JpaRepository<Rental, Long> {

    List<Rental> findByEquipmentId(Long equipmentId);

    @Query("SELECT r FROM Rental r WHERE r.equipment.id = :equipmentId " +
           "AND r.status IN :statuses " +
           "AND r.startDate <= :endDate AND r.endDate >= :startDate")
    List<Rental> findOverlapping(
        @Param("equipmentId") Long equipmentId,
        @Param("statuses") List<RentalStatus> statuses,
        @Param("startDate") LocalDate startDate,
        @Param("endDate") LocalDate endDate
    );

    List<Rental> findByEquipmentIdAndStatus(Long equipmentId, RentalStatus status);
}
