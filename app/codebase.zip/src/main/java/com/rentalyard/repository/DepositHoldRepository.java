package com.rentalyard.repository;

import com.rentalyard.model.DepositHold;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DepositHoldRepository extends JpaRepository<DepositHold, Long> {
    Optional<DepositHold> findByRentalId(Long rentalId);
}
