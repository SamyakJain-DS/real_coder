package com.backgammonshop.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class CheckerProductionEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String checkerColor;
    private String material;
    private int quantityTurned;
    private int quantityFinished;

    @ManyToOne
    private WorkshopSession workshopSession;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCheckerColor() {
        return checkerColor;
    }

    public void setCheckerColor(String checkerColor) {
        this.checkerColor = checkerColor;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getQuantityTurned() {
        return quantityTurned;
    }

    public void setQuantityTurned(int quantityTurned) {
        this.quantityTurned = quantityTurned;
    }

    public int getQuantityFinished() {
        return quantityFinished;
    }

    public void setQuantityFinished(int quantityFinished) {
        this.quantityFinished = quantityFinished;
    }

    public WorkshopSession getWorkshopSession() {
        return workshopSession;
    }

    public void setWorkshopSession(WorkshopSession workshopSession) {
        this.workshopSession = workshopSession;
    }
}
