package com.backgammonshop.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class HardwareInstallation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int setNumber;
    private String hingeFinish;
    private String claspFinish;
    private String diceMaterial;
    private String diceSize;
    private String doublingCubeMaterial;
    private String doublingCubeSize;

    @ManyToOne
    private WorkshopSession workshopSession;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getSetNumber() {
        return setNumber;
    }

    public void setSetNumber(int setNumber) {
        this.setNumber = setNumber;
    }

    public String getHingeFinish() {
        return hingeFinish;
    }

    public void setHingeFinish(String hingeFinish) {
        this.hingeFinish = hingeFinish;
    }

    public String getClaspFinish() {
        return claspFinish;
    }

    public void setClaspFinish(String claspFinish) {
        this.claspFinish = claspFinish;
    }

    public String getDiceMaterial() {
        return diceMaterial;
    }

    public void setDiceMaterial(String diceMaterial) {
        this.diceMaterial = diceMaterial;
    }

    public String getDiceSize() {
        return diceSize;
    }

    public void setDiceSize(String diceSize) {
        this.diceSize = diceSize;
    }

    public String getDoublingCubeMaterial() {
        return doublingCubeMaterial;
    }

    public void setDoublingCubeMaterial(String doublingCubeMaterial) {
        this.doublingCubeMaterial = doublingCubeMaterial;
    }

    public String getDoublingCubeSize() {
        return doublingCubeSize;
    }

    public void setDoublingCubeSize(String doublingCubeSize) {
        this.doublingCubeSize = doublingCubeSize;
    }

    public WorkshopSession getWorkshopSession() {
        return workshopSession;
    }

    public void setWorkshopSession(WorkshopSession workshopSession) {
        this.workshopSession = workshopSession;
    }
}
