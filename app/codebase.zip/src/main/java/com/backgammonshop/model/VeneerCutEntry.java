package com.backgammonshop.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class VeneerCutEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String pieceName;
    private String templateName;
    private String material;
    private int quantityCut;

    @ManyToOne
    private WorkshopSession workshopSession;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPieceName() {
        return pieceName;
    }

    public void setPieceName(String pieceName) {
        this.pieceName = pieceName;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getQuantityCut() {
        return quantityCut;
    }

    public void setQuantityCut(int quantityCut) {
        this.quantityCut = quantityCut;
    }

    public WorkshopSession getWorkshopSession() {
        return workshopSession;
    }

    public void setWorkshopSession(WorkshopSession workshopSession) {
        this.workshopSession = workshopSession;
    }
}
