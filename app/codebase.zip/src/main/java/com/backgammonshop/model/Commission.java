package com.backgammonshop.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Commission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String accountType;
    private BigDecimal agreedQuote;
    private BigDecimal depositPaid;
    private int plannedSetCount;
    private String caseMaterial;

    @OneToMany(mappedBy = "commission", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<InlayPoint> inlayPoints = new ArrayList<>();

    @OneToMany(mappedBy = "commission", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<WorkshopSession> workshopSessions = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public BigDecimal getAgreedQuote() {
        return agreedQuote;
    }

    public void setAgreedQuote(BigDecimal agreedQuote) {
        this.agreedQuote = agreedQuote;
    }

    public BigDecimal getDepositPaid() {
        return depositPaid;
    }

    public void setDepositPaid(BigDecimal depositPaid) {
        this.depositPaid = depositPaid;
    }

    public int getPlannedSetCount() {
        return plannedSetCount;
    }

    public void setPlannedSetCount(int plannedSetCount) {
        this.plannedSetCount = plannedSetCount;
    }

    public String getCaseMaterial() {
        return caseMaterial;
    }

    public void setCaseMaterial(String caseMaterial) {
        this.caseMaterial = caseMaterial;
    }

    public List<InlayPoint> getInlayPoints() {
        return inlayPoints;
    }

    public void setInlayPoints(List<InlayPoint> inlayPoints) {
        this.inlayPoints.clear();
        if (inlayPoints != null) {
            inlayPoints.forEach(this::addInlayPoint);
        }
    }

    public void addInlayPoint(InlayPoint inlayPoint) {
        inlayPoint.setCommission(this);
        this.inlayPoints.add(inlayPoint);
    }

    public List<WorkshopSession> getWorkshopSessions() {
        return workshopSessions;
    }

    public void setWorkshopSessions(List<WorkshopSession> workshopSessions) {
        this.workshopSessions.clear();
        if (workshopSessions != null) {
            workshopSessions.forEach(this::addWorkshopSession);
        }
    }

    public void addWorkshopSession(WorkshopSession workshopSession) {
        workshopSession.setCommission(this);
        this.workshopSessions.add(workshopSession);
    }
}
