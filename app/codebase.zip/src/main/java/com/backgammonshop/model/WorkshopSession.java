package com.backgammonshop.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
public class WorkshopSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate sessionDate;

    @ManyToOne
    private Commission commission;

    @OneToMany(mappedBy = "workshopSession", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<VeneerCutEntry> veneerCuts = new ArrayList<>();

    @OneToMany(mappedBy = "workshopSession", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CheckerProductionEntry> checkerProduction = new ArrayList<>();

    @OneToMany(mappedBy = "workshopSession", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<HardwareInstallation> hardwareInstallations = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getSessionDate() {
        return sessionDate;
    }

    public void setSessionDate(LocalDate sessionDate) {
        this.sessionDate = sessionDate;
    }

    public Commission getCommission() {
        return commission;
    }

    public void setCommission(Commission commission) {
        this.commission = commission;
    }

    public List<VeneerCutEntry> getVeneerCuts() {
        return veneerCuts;
    }

    public void setVeneerCuts(List<VeneerCutEntry> veneerCuts) {
        this.veneerCuts.clear();
        if (veneerCuts != null) {
            veneerCuts.forEach(this::addVeneerCut);
        }
    }

    public void addVeneerCut(VeneerCutEntry veneerCut) {
        veneerCut.setWorkshopSession(this);
        this.veneerCuts.add(veneerCut);
    }

    public List<CheckerProductionEntry> getCheckerProduction() {
        return checkerProduction;
    }

    public void setCheckerProduction(List<CheckerProductionEntry> checkerProduction) {
        this.checkerProduction.clear();
        if (checkerProduction != null) {
            checkerProduction.forEach(this::addCheckerProduction);
        }
    }

    public void addCheckerProduction(CheckerProductionEntry checkerProductionEntry) {
        checkerProductionEntry.setWorkshopSession(this);
        this.checkerProduction.add(checkerProductionEntry);
    }

    public List<HardwareInstallation> getHardwareInstallations() {
        return hardwareInstallations;
    }

    public void setHardwareInstallations(List<HardwareInstallation> hardwareInstallations) {
        this.hardwareInstallations.clear();
        if (hardwareInstallations != null) {
            hardwareInstallations.forEach(this::addHardwareInstallation);
        }
    }

    public void addHardwareInstallation(HardwareInstallation hardwareInstallation) {
        hardwareInstallation.setWorkshopSession(this);
        this.hardwareInstallations.add(hardwareInstallation);
    }
}
