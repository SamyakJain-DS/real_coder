package com.backgammonshop.service;

import com.backgammonshop.dto.BillingSummary;
import com.backgammonshop.dto.CheckerColorSummary;
import com.backgammonshop.dto.ProductionSummaryDTO;
import com.backgammonshop.model.CheckerProductionEntry;
import com.backgammonshop.model.Commission;
import com.backgammonshop.model.HardwareInstallation;
import com.backgammonshop.model.InlayPoint;
import com.backgammonshop.model.VeneerCutEntry;
import com.backgammonshop.model.WorkshopSession;
import com.backgammonshop.repository.CommissionRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class CommissionService {

    private static final int BOARD_POINT_COUNT = 24;
    private static final int CHECKERS_PER_SET = 30;

    private final CommissionRepository commissionRepository;

    public CommissionService(CommissionRepository commissionRepository) {
        this.commissionRepository = commissionRepository;
    }

    @Transactional
    public Commission createCommission(Commission commission) {
        validateCommission(commission);
        commission.setAgreedQuote(scaleMoney(commission.getAgreedQuote()));
        commission.setDepositPaid(scaleMoney(commission.getDepositPaid()));
        List<InlayPoint> requestedPoints = new ArrayList<>(commission.getInlayPoints());
        commission.setInlayPoints(requestedPoints);
        commission.setWorkshopSessions(List.of());
        return commissionRepository.save(commission);
    }

    @Transactional(readOnly = true)
    public Commission getCommission(Long commissionId) {
        Commission commission = findCommission(commissionId);
        initializeCommissionGraph(commission);
        return commission;
    }

    @Transactional
    public WorkshopSession addWorkshopSession(
            Long commissionId,
            LocalDate sessionDate,
            List<VeneerCutEntry> veneerCuts,
            List<CheckerProductionEntry> checkerProduction,
            List<HardwareInstallation> hardwareInstallations
    ) {
        Commission commission = findCommission(commissionId);
        WorkshopSession session = new WorkshopSession();
        session.setSessionDate(sessionDate);
        session.setVeneerCuts(veneerCuts == null ? List.of() : veneerCuts);
        session.setCheckerProduction(checkerProduction == null ? List.of() : checkerProduction);
        session.setHardwareInstallations(hardwareInstallations == null ? List.of() : hardwareInstallations);

        validateWorkshopSession(commission, session);
        commission.addWorkshopSession(session);
        // save() calls em.merge(), which returns a new managed copy of the entity.
        // The original `session` variable is never updated by merge, so session.getId()
        // would remain null.  saveAndFlush() forces the INSERT immediately and returns
        // the managed Commission whose workshopSessions collection contains the persisted
        // session with its generated ID already set.
        Commission saved = commissionRepository.saveAndFlush(commission);
        List<WorkshopSession> savedSessions = saved.getWorkshopSessions();
        return savedSessions.get(savedSessions.size() - 1);
    }

    @Transactional(readOnly = true)
    public ProductionSummaryDTO getProductionSummary(Long commissionId) {
        Commission commission = findCommission(commissionId);

        Map<String, Integer> veneerCutsByTemplate = new LinkedHashMap<>();
        Map<String, CheckerAccumulator> checkerTotalsByColor = new HashMap<>();
        Set<Integer> installedHardwareSetNumbers = new HashSet<>();

        for (WorkshopSession session : commission.getWorkshopSessions()) {
            for (VeneerCutEntry veneerCut : session.getVeneerCuts()) {
                veneerCutsByTemplate.merge(veneerCut.getTemplateName(), veneerCut.getQuantityCut(), Integer::sum);
            }
            for (CheckerProductionEntry checkerEntry : session.getCheckerProduction()) {
                checkerTotalsByColor
                        .computeIfAbsent(checkerEntry.getCheckerColor(), ignored -> new CheckerAccumulator())
                        .add(checkerEntry.getQuantityTurned(), checkerEntry.getQuantityFinished());
            }
            for (HardwareInstallation hardwareInstallation : session.getHardwareInstallations()) {
                installedHardwareSetNumbers.add(hardwareInstallation.getSetNumber());
            }
        }

        List<CheckerColorSummary> checkersByColor = checkerTotalsByColor.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(entry -> new CheckerColorSummary(
                        entry.getKey(),
                        entry.getValue().totalTurned(),
                        entry.getValue().totalFinished()
                ))
                .toList();

        int totalCheckersRequired = commission.getPlannedSetCount() * CHECKERS_PER_SET;
        int totalFinished = checkerTotalsByColor.values().stream()
                .mapToInt(CheckerAccumulator::totalFinished)
                .sum();
        int installedHardwareCount = installedHardwareSetNumbers.size();

        return new ProductionSummaryDTO(
                commission.getId(),
                commission.getPlannedSetCount(),
                veneerCutsByTemplate,
                checkersByColor,
                totalCheckersRequired,
                Math.max(0, totalCheckersRequired - totalFinished),
                installedHardwareCount,
                commission.getPlannedSetCount() - installedHardwareCount,
                new BillingSummary(commission.getAgreedQuote(), commission.getDepositPaid())
        );
    }

    private Commission findCommission(Long commissionId) {
        return commissionRepository.findById(commissionId)
                .orElseThrow(() -> new EntityNotFoundException("Commission " + commissionId + " was not found"));
    }

    private void validateCommission(Commission commission) {
        List<String> errors = new ArrayList<>();
        if (commission == null) {
            throw new IllegalArgumentException("Commission request is required");
        }
        requireText(commission.getCustomerName(), "customerName", errors);
        requireText(commission.getAccountType(), "accountType", errors);
        requireText(commission.getCaseMaterial(), "caseMaterial", errors);
        requireNonNegativeMoney(commission.getAgreedQuote(), "agreedQuote", errors);
        requireNonNegativeMoney(commission.getDepositPaid(), "depositPaid", errors);

        if (commission.getAgreedQuote() != null
                && commission.getDepositPaid() != null
                && commission.getDepositPaid().compareTo(commission.getAgreedQuote()) > 0) {
            errors.add("depositPaid must not be greater than agreedQuote");
        }
        if (commission.getPlannedSetCount() < 1) {
            errors.add("plannedSetCount must be at least 1");
        }
        validateInlayPoints(commission.getInlayPoints(), errors);

        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(String.join("; ", errors));
        }
    }

    private void validateInlayPoints(List<InlayPoint> inlayPoints, List<String> errors) {
        if (inlayPoints == null || inlayPoints.size() != BOARD_POINT_COUNT) {
            errors.add("inlayPoints must contain exactly 24 entries");
            return;
        }

        Set<Integer> pointNumbers = new HashSet<>();
        for (InlayPoint point : inlayPoints) {
            if (point == null) {
                errors.add("inlayPoints must not contain null entries");
                continue;
            }
            requireText(point.getColor(), "inlayPoints.color", errors);
            requireText(point.getMaterial(), "inlayPoints.material", errors);
            if (point.getPointNumber() < 1 || point.getPointNumber() > BOARD_POINT_COUNT) {
                errors.add("inlay pointNumber must be between 1 and 24");
            }
            if (!pointNumbers.add(point.getPointNumber())) {
                errors.add("inlay pointNumber values must be unique");
            }
        }

        if (pointNumbers.size() == BOARD_POINT_COUNT) {
            for (int pointNumber = 1; pointNumber <= BOARD_POINT_COUNT; pointNumber++) {
                if (!pointNumbers.contains(pointNumber)) {
                    errors.add("inlayPoints must include every pointNumber from 1 through 24");
                    break;
                }
            }
        }
    }

    private void validateWorkshopSession(Commission commission, WorkshopSession session) {
        List<String> errors = new ArrayList<>();
        if (session.getSessionDate() == null) {
            errors.add("sessionDate is required");
        }

        for (VeneerCutEntry veneerCut : session.getVeneerCuts()) {
            requireText(veneerCut.getPieceName(), "pieceName", errors);
            requireText(veneerCut.getTemplateName(), "templateName", errors);
            requireText(veneerCut.getMaterial(), "material", errors);
            if (veneerCut.getQuantityCut() < 0) {
                errors.add("quantityCut must be at least 0");
            }
        }

        for (CheckerProductionEntry checkerEntry : session.getCheckerProduction()) {
            requireText(checkerEntry.getCheckerColor(), "checkerColor", errors);
            requireText(checkerEntry.getMaterial(), "material", errors);
            if (checkerEntry.getQuantityTurned() < 0) {
                errors.add("quantityTurned must be at least 0");
            }
            if (checkerEntry.getQuantityFinished() < 0) {
                errors.add("quantityFinished must be at least 0");
            }
        }

        Set<Integer> alreadyInstalledSetNumbers = installedHardwareSetNumbers(commission);
        Set<Integer> requestedSetNumbers = new HashSet<>();
        for (HardwareInstallation hardwareInstallation : session.getHardwareInstallations()) {
            int setNumber = hardwareInstallation.getSetNumber();
            if (setNumber < 1 || setNumber > commission.getPlannedSetCount()) {
                errors.add("hardware setNumber must be between 1 and plannedSetCount");
            }
            if (!requestedSetNumbers.add(setNumber) || alreadyInstalledSetNumbers.contains(setNumber)) {
                errors.add("hardware installation for setNumber " + setNumber + " already exists");
            }
            requireText(hardwareInstallation.getHingeFinish(), "hingeFinish", errors);
            requireText(hardwareInstallation.getClaspFinish(), "claspFinish", errors);
            requireText(hardwareInstallation.getDiceMaterial(), "diceMaterial", errors);
            requireText(hardwareInstallation.getDiceSize(), "diceSize", errors);
            requireText(hardwareInstallation.getDoublingCubeMaterial(), "doublingCubeMaterial", errors);
            requireText(hardwareInstallation.getDoublingCubeSize(), "doublingCubeSize", errors);
        }

        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(String.join("; ", errors));
        }
    }

    private Set<Integer> installedHardwareSetNumbers(Commission commission) {
        Set<Integer> installedSetNumbers = new HashSet<>();
        for (WorkshopSession workshopSession : commission.getWorkshopSessions()) {
            for (HardwareInstallation hardwareInstallation : workshopSession.getHardwareInstallations()) {
                installedSetNumbers.add(hardwareInstallation.getSetNumber());
            }
        }
        return installedSetNumbers;
    }

    private void initializeCommissionGraph(Commission commission) {
        commission.getInlayPoints().sort(Comparator.comparingInt(InlayPoint::getPointNumber));
        commission.getWorkshopSessions().forEach(session -> {
            session.getVeneerCuts().size();
            session.getCheckerProduction().size();
            session.getHardwareInstallations().size();
        });
    }

    private void requireText(String value, String fieldName, List<String> errors) {
        if (value == null || value.isBlank()) {
            errors.add(fieldName + " is required");
        }
    }

    private void requireNonNegativeMoney(BigDecimal value, String fieldName, List<String> errors) {
        if (value == null) {
            errors.add(fieldName + " is required");
        } else if (value.compareTo(BigDecimal.ZERO) < 0) {
            errors.add(fieldName + " must be at least 0");
        }
    }

    private BigDecimal scaleMoney(BigDecimal value) {
        return value.setScale(2, RoundingMode.HALF_UP);
    }

    private static class CheckerAccumulator {

        private int totalTurned;
        private int totalFinished;

        private void add(int turned, int finished) {
            totalTurned += turned;
            totalFinished += finished;
        }

        private int totalTurned() {
            return totalTurned;
        }

        private int totalFinished() {
            return totalFinished;
        }
    }
}
