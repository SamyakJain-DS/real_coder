package com.backgammonshop.api;

import com.backgammonshop.dto.CommissionDTO;
import com.backgammonshop.dto.ProductionSummaryDTO;
import com.backgammonshop.dto.WorkshopSessionDTO;
import com.backgammonshop.model.Commission;
import com.backgammonshop.model.WorkshopSession;
import com.backgammonshop.service.CommissionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/commissions")
public class CommissionController {

    private final CommissionService commissionService;

    public CommissionController(CommissionService commissionService) {
        this.commissionService = commissionService;
    }

    @PostMapping
    public ResponseEntity<Object> createCommission(@RequestBody Commission request) {
        Commission commission = commissionService.createCommission(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(new CommissionDTO(commission));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> getCommission(@PathVariable Long id) {
        return ResponseEntity.ok(new CommissionDTO(commissionService.getCommission(id)));
    }

    @PostMapping("/{id}/workshop-sessions")
    public ResponseEntity<Object> addWorkshopSession(@PathVariable Long id, @RequestBody WorkshopSession request) {
        WorkshopSession session = commissionService.addWorkshopSession(
                id,
                request.getSessionDate(),
                request.getVeneerCuts(),
                request.getCheckerProduction(),
                request.getHardwareInstallations()
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(new WorkshopSessionDTO(session));
    }

    @GetMapping("/{id}/production-summary")
    public ResponseEntity<Object> getProductionSummary(@PathVariable Long id) {
        ProductionSummaryDTO summary = commissionService.getProductionSummary(id);
        return ResponseEntity.ok(summary);
    }
}
