package com.backgammonshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackgammonShopApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackgammonShopApplication.class, args);
    }
}
