package com.backgammonshop.dto;

import com.backgammonshop.model.VeneerCutEntry;

public class VeneerCutEntryDTO {

    private Long id;
    private String pieceName;
    private String templateName;
    private String material;
    private int quantityCut;

    public VeneerCutEntryDTO(VeneerCutEntry entry) {
        this.id = entry.getId();
        this.pieceName = entry.getPieceName();
        this.templateName = entry.getTemplateName();
        this.material = entry.getMaterial();
        this.quantityCut = entry.getQuantityCut();
    }

    public Long getId() {
        return id;
    }

    public String getPieceName() {
        return pieceName;
    }

    public String getTemplateName() {
        return templateName;
    }

    public String getMaterial() {
        return material;
    }

    public int getQuantityCut() {
        return quantityCut;
    }
}
