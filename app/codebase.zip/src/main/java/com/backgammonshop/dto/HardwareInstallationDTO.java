package com.backgammonshop.dto;

import com.backgammonshop.model.HardwareInstallation;

public class HardwareInstallationDTO {

    private Long id;
    private int setNumber;
    private String hingeFinish;
    private String claspFinish;
    private String diceMaterial;
    private String diceSize;
    private String doublingCubeMaterial;
    private String doublingCubeSize;

    public HardwareInstallationDTO(HardwareInstallation hardwareInstallation) {
        this.id = hardwareInstallation.getId();
        this.setNumber = hardwareInstallation.getSetNumber();
        this.hingeFinish = hardwareInstallation.getHingeFinish();
        this.claspFinish = hardwareInstallation.getClaspFinish();
        this.diceMaterial = hardwareInstallation.getDiceMaterial();
        this.diceSize = hardwareInstallation.getDiceSize();
        this.doublingCubeMaterial = hardwareInstallation.getDoublingCubeMaterial();
        this.doublingCubeSize = hardwareInstallation.getDoublingCubeSize();
    }

    public Long getId() {
        return id;
    }

    public int getSetNumber() {
        return setNumber;
    }

    public String getHingeFinish() {
        return hingeFinish;
    }

    public String getClaspFinish() {
        return claspFinish;
    }

    public String getDiceMaterial() {
        return diceMaterial;
    }

    public String getDiceSize() {
        return diceSize;
    }

    public String getDoublingCubeMaterial() {
        return doublingCubeMaterial;
    }

    public String getDoublingCubeSize() {
        return doublingCubeSize;
    }
}
