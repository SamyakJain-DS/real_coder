package com.backgammonshop.dto;

public class CheckerColorSummary {

    private String checkerColor;
    private int totalTurned;
    private int totalFinished;

    public CheckerColorSummary(String checkerColor, int totalTurned, int totalFinished) {
        this.checkerColor = checkerColor;
        this.totalTurned = totalTurned;
        this.totalFinished = totalFinished;
    }

    public String getCheckerColor() {
        return checkerColor;
    }

    public void setCheckerColor(String checkerColor) {
        this.checkerColor = checkerColor;
    }

    public int getTotalTurned() {
        return totalTurned;
    }

    public void setTotalTurned(int totalTurned) {
        this.totalTurned = totalTurned;
    }

    public int getTotalFinished() {
        return totalFinished;
    }

    public void setTotalFinished(int totalFinished) {
        this.totalFinished = totalFinished;
    }
}
