package com.backgammonshop.dto;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class BillingSummary {

    private BigDecimal agreedQuote;
    private BigDecimal depositPaid;
    private BigDecimal outstandingBalance;

    public BillingSummary(BigDecimal agreedQuote, BigDecimal depositPaid) {
        this.agreedQuote = scale(agreedQuote);
        this.depositPaid = scale(depositPaid);
        this.outstandingBalance = scale(this.agreedQuote.subtract(this.depositPaid));
    }

    private BigDecimal scale(BigDecimal value) {
        return value.setScale(2, RoundingMode.HALF_UP);
    }

    public BigDecimal getAgreedQuote() {
        return agreedQuote;
    }

    public void setAgreedQuote(BigDecimal agreedQuote) {
        this.agreedQuote = agreedQuote;
    }

    public BigDecimal getDepositPaid() {
        return depositPaid;
    }

    public void setDepositPaid(BigDecimal depositPaid) {
        this.depositPaid = depositPaid;
    }

    public BigDecimal getOutstandingBalance() {
        return outstandingBalance;
    }

    public void setOutstandingBalance(BigDecimal outstandingBalance) {
        this.outstandingBalance = outstandingBalance;
    }
}
