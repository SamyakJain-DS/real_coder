package com.backgammonshop.dto;

import java.util.List;
import java.util.Map;

public class ProductionSummaryDTO {

    private long commissionId;
    private int plannedSetCount;
    private Map<String, Integer> veneerCutsByTemplate;
    private List<CheckerColorSummary> checkersByColor;
    private int totalCheckersRequired;
    private int totalCheckersRemainingToFinish;
    private int installedHardwareCount;
    private int remainingHardwareInstallations;
    private BillingSummary billing;

    public ProductionSummaryDTO(
            long commissionId,
            int plannedSetCount,
            Map<String, Integer> veneerCutsByTemplate,
            List<CheckerColorSummary> checkersByColor,
            int totalCheckersRequired,
            int totalCheckersRemainingToFinish,
            int installedHardwareCount,
            int remainingHardwareInstallations,
            BillingSummary billing
    ) {
        this.commissionId = commissionId;
        this.plannedSetCount = plannedSetCount;
        this.veneerCutsByTemplate = veneerCutsByTemplate;
        this.checkersByColor = checkersByColor;
        this.totalCheckersRequired = totalCheckersRequired;
        this.totalCheckersRemainingToFinish = totalCheckersRemainingToFinish;
        this.installedHardwareCount = installedHardwareCount;
        this.remainingHardwareInstallations = remainingHardwareInstallations;
        this.billing = billing;
    }

    public long getCommissionId() {
        return commissionId;
    }

    public int getPlannedSetCount() {
        return plannedSetCount;
    }

    public Map<String, Integer> getVeneerCutsByTemplate() {
        return veneerCutsByTemplate;
    }

    public List<CheckerColorSummary> getCheckersByColor() {
        return checkersByColor;
    }

    public int getTotalCheckersRequired() {
        return totalCheckersRequired;
    }

    public int getTotalCheckersRemainingToFinish() {
        return totalCheckersRemainingToFinish;
    }

    public int getInstalledHardwareCount() {
        return installedHardwareCount;
    }

    public int getRemainingHardwareInstallations() {
        return remainingHardwareInstallations;
    }

    public BillingSummary getBilling() {
        return billing;
    }
}
