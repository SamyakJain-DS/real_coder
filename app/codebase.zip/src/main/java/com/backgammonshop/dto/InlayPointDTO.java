package com.backgammonshop.dto;

import com.backgammonshop.model.InlayPoint;

public class InlayPointDTO {

    private Long id;
    private int pointNumber;
    private String color;
    private String material;

    public InlayPointDTO(InlayPoint inlayPoint) {
        this.id = inlayPoint.getId();
        this.pointNumber = inlayPoint.getPointNumber();
        this.color = inlayPoint.getColor();
        this.material = inlayPoint.getMaterial();
    }

    public Long getId() {
        return id;
    }

    public int getPointNumber() {
        return pointNumber;
    }

    public String getColor() {
        return color;
    }

    public String getMaterial() {
        return material;
    }
}
