package com.backgammonshop.dto;

import com.backgammonshop.model.WorkshopSession;

import java.time.LocalDate;
import java.util.List;

public class WorkshopSessionDTO {

    private Long id;
    private LocalDate sessionDate;
    private List<VeneerCutEntryDTO> veneerCuts;
    private List<CheckerProductionEntryDTO> checkerProduction;
    private List<HardwareInstallationDTO> hardwareInstallations;

    public WorkshopSessionDTO(WorkshopSession session) {
        this.id = session.getId();
        this.sessionDate = session.getSessionDate();
        this.veneerCuts = session.getVeneerCuts().stream().map(VeneerCutEntryDTO::new).toList();
        this.checkerProduction = session.getCheckerProduction().stream().map(CheckerProductionEntryDTO::new).toList();
        this.hardwareInstallations = session.getHardwareInstallations().stream().map(HardwareInstallationDTO::new).toList();
    }

    public Long getId() {
        return id;
    }

    public LocalDate getSessionDate() {
        return sessionDate;
    }

    public List<VeneerCutEntryDTO> getVeneerCuts() {
        return veneerCuts;
    }

    public List<CheckerProductionEntryDTO> getCheckerProduction() {
        return checkerProduction;
    }

    public List<HardwareInstallationDTO> getHardwareInstallations() {
        return hardwareInstallations;
    }
}
