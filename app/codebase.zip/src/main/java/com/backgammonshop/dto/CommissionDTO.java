package com.backgammonshop.dto;

import com.backgammonshop.model.Commission;

import java.math.BigDecimal;
import java.util.List;

public class CommissionDTO {

    private Long id;
    private String customerName;
    private String accountType;
    private BigDecimal agreedQuote;
    private BigDecimal depositPaid;
    private int plannedSetCount;
    private String caseMaterial;
    private List<InlayPointDTO> inlayPoints;
    private List<WorkshopSessionDTO> workshopSessions;
    private BillingSummary billing;

    public CommissionDTO(Commission commission) {
        this.id = commission.getId();
        this.customerName = commission.getCustomerName();
        this.accountType = commission.getAccountType();
        this.agreedQuote = commission.getAgreedQuote();
        this.depositPaid = commission.getDepositPaid();
        this.plannedSetCount = commission.getPlannedSetCount();
        this.caseMaterial = commission.getCaseMaterial();
        this.inlayPoints = commission.getInlayPoints().stream().map(InlayPointDTO::new).toList();
        this.workshopSessions = commission.getWorkshopSessions().stream().map(WorkshopSessionDTO::new).toList();
        this.billing = new BillingSummary(commission.getAgreedQuote(), commission.getDepositPaid());
    }

    public Long getId() {
        return id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getAccountType() {
        return accountType;
    }

    public BigDecimal getAgreedQuote() {
        return agreedQuote;
    }

    public BigDecimal getDepositPaid() {
        return depositPaid;
    }

    public int getPlannedSetCount() {
        return plannedSetCount;
    }

    public String getCaseMaterial() {
        return caseMaterial;
    }

    public List<InlayPointDTO> getInlayPoints() {
        return inlayPoints;
    }

    public List<WorkshopSessionDTO> getWorkshopSessions() {
        return workshopSessions;
    }

    public BillingSummary getBilling() {
        return billing;
    }
}
