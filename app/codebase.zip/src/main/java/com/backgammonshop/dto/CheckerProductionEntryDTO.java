package com.backgammonshop.dto;

import com.backgammonshop.model.CheckerProductionEntry;

public class CheckerProductionEntryDTO {

    private Long id;
    private String checkerColor;
    private String material;
    private int quantityTurned;
    private int quantityFinished;

    public CheckerProductionEntryDTO(CheckerProductionEntry entry) {
        this.id = entry.getId();
        this.checkerColor = entry.getCheckerColor();
        this.material = entry.getMaterial();
        this.quantityTurned = entry.getQuantityTurned();
        this.quantityFinished = entry.getQuantityFinished();
    }

    public Long getId() {
        return id;
    }

    public String getCheckerColor() {
        return checkerColor;
    }

    public String getMaterial() {
        return material;
    }

    public int getQuantityTurned() {
        return quantityTurned;
    }

    public int getQuantityFinished() {
        return quantityFinished;
    }
}
