package com.etl.orchestrator.model;

public class DataQualityRule {

    private QualityCheckType checkType;
    private String columnName;
    private double threshold;

    public DataQualityRule() {
    }

    public DataQualityRule(QualityCheckType checkType, String columnName, double threshold) {
        this.checkType = checkType;
        this.columnName = columnName;
        this.threshold = threshold;
    }

    public QualityCheckType getCheckType() {
        return checkType;
    }

    public void setCheckType(QualityCheckType checkType) {
        this.checkType = checkType;
    }

    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }

    public double getThreshold() {
        return threshold;
    }

    public void setThreshold(double threshold) {
        this.threshold = threshold;
    }
}
