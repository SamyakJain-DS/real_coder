package com.etl.orchestrator.controller;

import com.etl.orchestrator.model.PipelineRuntime;
import com.etl.orchestrator.model.QualityScoreEntry;
import com.etl.orchestrator.service.DataQualityService;
import com.etl.orchestrator.service.PipelineOrchestratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private final PipelineOrchestratorService orchestratorService;
    private final DataQualityService dataQualityService;

    @Autowired
    public AdminController(PipelineOrchestratorService orchestratorService,
                           DataQualityService dataQualityService) {
        this.orchestratorService = orchestratorService;
        this.dataQualityService = dataQualityService;
    }

    @GetMapping("/pipelines/{pipelineId}/runtime")
    public ResponseEntity<PipelineRuntime> getRuntime(@PathVariable String pipelineId) {
        PipelineRuntime runtime = orchestratorService.getLatestRuntime(pipelineId);
        if (runtime == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(runtime);
    }

    @GetMapping("/datasets/{datasetId}/quality-score/trajectory")
    public ResponseEntity<List<QualityScoreEntry>> getTrajectory(@PathVariable String datasetId) {
        return ResponseEntity.ok(dataQualityService.getQualityScoreTrajectory(datasetId));
    }
}
