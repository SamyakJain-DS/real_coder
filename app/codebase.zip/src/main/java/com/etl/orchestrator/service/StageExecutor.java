package com.etl.orchestrator.service;

import com.etl.orchestrator.model.PipelineStage;
import com.etl.orchestrator.model.StageExecutionResult;

import java.time.LocalDate;

public interface StageExecutor {

    StageExecutionResult execute(PipelineStage stage, String datasetId, LocalDate replayDate);
}
