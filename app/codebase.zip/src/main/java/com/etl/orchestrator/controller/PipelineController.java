package com.etl.orchestrator.controller;

import com.etl.orchestrator.model.BackfillRequest;
import com.etl.orchestrator.model.PipelineDeclaration;
import com.etl.orchestrator.model.PipelineRuntime;
import com.etl.orchestrator.service.BackfillService;
import com.etl.orchestrator.service.PipelineOrchestratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@RestController
@RequestMapping("/pipelines")
public class PipelineController {

    private final PipelineOrchestratorService orchestratorService;
    private final BackfillService backfillService;

    @Autowired
    public PipelineController(PipelineOrchestratorService orchestratorService,
                              BackfillService backfillService) {
        this.orchestratorService = orchestratorService;
        this.backfillService = backfillService;
    }

    @PostMapping
    public ResponseEntity<Void> registerPipeline(@RequestBody PipelineDeclaration declaration) {
        orchestratorService.registerPipeline(declaration);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PostMapping("/{pipelineId}/run")
    public ResponseEntity<PipelineRuntime> runPipeline(@PathVariable String pipelineId) {
        PipelineRuntime runtime = orchestratorService.executePipeline(pipelineId, LocalDate.now());
        orchestratorService.storeRuntime(pipelineId, runtime);
        return ResponseEntity.ok(runtime);
    }

    @PostMapping("/{pipelineId}/backfill")
    public ResponseEntity<?> backfillPipeline(@PathVariable String pipelineId,
                                              @RequestBody BackfillRequest request) {
        LocalDate from;
        LocalDate to;
        try {
            from = LocalDate.parse(request.getFromDate());
            to = LocalDate.parse(request.getToDate());
        } catch (DateTimeParseException | NullPointerException ex) {
            return ResponseEntity.badRequest().body("Invalid date format: " + ex.getMessage());
        }
        PipelineRuntime runtime = backfillService.executeBackfill(pipelineId, from, to);
        return ResponseEntity.ok(runtime);
    }
}
