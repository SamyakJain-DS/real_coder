package com.etl.orchestrator.service;

import com.etl.orchestrator.model.DataQualityRule;
import com.etl.orchestrator.model.PipelineStage;
import com.etl.orchestrator.model.QualityCheckType;
import com.etl.orchestrator.model.StageExecutionResult;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class DefaultStageExecutor implements StageExecutor {

    @Override
    public StageExecutionResult execute(PipelineStage stage, String datasetId, LocalDate replayDate) {
        long startMs = System.currentTimeMillis();

        Map<String, String> realizedSchema = new LinkedHashMap<>(stage.getSchema());

        double syntheticValue = (replayDate.toEpochDay() % 100) / 1000.0;
        Map<String, Map<QualityCheckType, Double>> metricValues = new LinkedHashMap<>();
        for (DataQualityRule rule : stage.getQualityRules()) {
            metricValues
                    .computeIfAbsent(rule.getColumnName(), k -> new LinkedHashMap<>())
                    .put(rule.getCheckType(), syntheticValue);
        }

        long elapsedMs = System.currentTimeMillis() - startMs;

        return new StageExecutionResult(stage.getStageId(), elapsedMs, realizedSchema, metricValues);
    }
}
