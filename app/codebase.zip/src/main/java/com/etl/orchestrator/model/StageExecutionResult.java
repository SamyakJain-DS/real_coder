package com.etl.orchestrator.model;

import java.util.Map;

public class StageExecutionResult {

    private String stageId;
    private long elapsedMs;
    private Map<String, String> realizedSchema;
    private Map<String, Map<QualityCheckType, Double>> metricValues;

    public StageExecutionResult() {
    }

    public StageExecutionResult(String stageId, long elapsedMs,
                                Map<String, String> realizedSchema,
                                Map<String, Map<QualityCheckType, Double>> metricValues) {
        this.stageId = stageId;
        this.elapsedMs = elapsedMs;
        this.realizedSchema = realizedSchema;
        this.metricValues = metricValues;
    }

    public String getStageId() {
        return stageId;
    }

    public void setStageId(String stageId) {
        this.stageId = stageId;
    }

    public long getElapsedMs() {
        return elapsedMs;
    }

    public void setElapsedMs(long elapsedMs) {
        this.elapsedMs = elapsedMs;
    }

    public Map<String, String> getRealizedSchema() {
        return realizedSchema;
    }

    public void setRealizedSchema(Map<String, String> realizedSchema) {
        this.realizedSchema = realizedSchema;
    }

    public Map<String, Map<QualityCheckType, Double>> getMetricValues() {
        return metricValues;
    }

    public void setMetricValues(Map<String, Map<QualityCheckType, Double>> metricValues) {
        this.metricValues = metricValues;
    }
}
