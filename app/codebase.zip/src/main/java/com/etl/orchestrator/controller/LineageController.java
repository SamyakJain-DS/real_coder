package com.etl.orchestrator.controller;

import com.etl.orchestrator.model.ColumnLineage;
import com.etl.orchestrator.service.LineageTrackerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/lineage")
public class LineageController {

    private final LineageTrackerService lineageTrackerService;

    @Autowired
    public LineageController(LineageTrackerService lineageTrackerService) {
        this.lineageTrackerService = lineageTrackerService;
    }

    @PostMapping
    public ResponseEntity<Void> recordLineage(@RequestBody ColumnLineage lineage) {
        lineageTrackerService.recordLineage(lineage);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/{datasetId}/{columnName}/upstream")
    public ResponseEntity<List<String>> getUpstream(@PathVariable String datasetId,
                                                    @PathVariable String columnName) {
        return ResponseEntity.ok(lineageTrackerService.getUpstreamColumns(datasetId, columnName));
    }

    @GetMapping("/{datasetId}/{columnName}/downstream")
    public ResponseEntity<List<String>> getDownstream(@PathVariable String datasetId,
                                                      @PathVariable String columnName) {
        return ResponseEntity.ok(lineageTrackerService.getDownstreamColumns(datasetId, columnName));
    }
}
