package com.etl.orchestrator.model;

import java.util.List;
import java.util.Map;

public class PipelineStage {

    private String stageId;
    private String transformationLogic;
    private List<DataQualityRule> qualityRules;
    private Map<String, String> schema;

    public PipelineStage() {
    }

    public PipelineStage(String stageId, String transformationLogic,
                         List<DataQualityRule> qualityRules, Map<String, String> schema) {
        this.stageId = stageId;
        this.transformationLogic = transformationLogic;
        this.qualityRules = qualityRules;
        this.schema = schema;
    }

    public String getStageId() {
        return stageId;
    }

    public void setStageId(String stageId) {
        this.stageId = stageId;
    }

    public String getTransformationLogic() {
        return transformationLogic;
    }

    public void setTransformationLogic(String transformationLogic) {
        this.transformationLogic = transformationLogic;
    }

    public List<DataQualityRule> getQualityRules() {
        return qualityRules;
    }

    public void setQualityRules(List<DataQualityRule> qualityRules) {
        this.qualityRules = qualityRules;
    }

    public Map<String, String> getSchema() {
        return schema;
    }

    public void setSchema(Map<String, String> schema) {
        this.schema = schema;
    }
}
