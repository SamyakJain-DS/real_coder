package com.etl.orchestrator.model;

import java.time.Instant;
import java.util.Map;

public class PipelineRuntime {

    private String pipelineId;
    private Instant startedAt;
    private Instant completedAt;
    private String status;
    private Map<String, Long> stageRuntimes;

    public PipelineRuntime() {
    }

    public PipelineRuntime(String pipelineId, Instant startedAt, Instant completedAt,
                           String status, Map<String, Long> stageRuntimes) {
        this.pipelineId = pipelineId;
        this.startedAt = startedAt;
        this.completedAt = completedAt;
        this.status = status;
        this.stageRuntimes = stageRuntimes;
    }

    public String getPipelineId() {
        return pipelineId;
    }

    public void setPipelineId(String pipelineId) {
        this.pipelineId = pipelineId;
    }

    public Instant getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(Instant startedAt) {
        this.startedAt = startedAt;
    }

    public Instant getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Instant completedAt) {
        this.completedAt = completedAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Map<String, Long> getStageRuntimes() {
        return stageRuntimes;
    }

    public void setStageRuntimes(Map<String, Long> stageRuntimes) {
        this.stageRuntimes = stageRuntimes;
    }
}
