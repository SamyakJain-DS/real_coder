package com.etl.orchestrator.model;

import java.util.List;

public class PipelineDeclaration {

    private String pipelineId;
    private String sourceDatasetId;
    private String sinkDatasetId;
    private List<PipelineStage> stages;

    public PipelineDeclaration() {
    }

    public PipelineDeclaration(String pipelineId, String sourceDatasetId,
                                String sinkDatasetId, List<PipelineStage> stages) {
        this.pipelineId = pipelineId;
        this.sourceDatasetId = sourceDatasetId;
        this.sinkDatasetId = sinkDatasetId;
        this.stages = stages;
    }

    public String getPipelineId() {
        return pipelineId;
    }

    public void setPipelineId(String pipelineId) {
        this.pipelineId = pipelineId;
    }

    public String getSourceDatasetId() {
        return sourceDatasetId;
    }

    public void setSourceDatasetId(String sourceDatasetId) {
        this.sourceDatasetId = sourceDatasetId;
    }

    public String getSinkDatasetId() {
        return sinkDatasetId;
    }

    public void setSinkDatasetId(String sinkDatasetId) {
        this.sinkDatasetId = sinkDatasetId;
    }

    public List<PipelineStage> getStages() {
        return stages;
    }

    public void setStages(List<PipelineStage> stages) {
        this.stages = stages;
    }
}
