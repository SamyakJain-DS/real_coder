package com.etl.orchestrator.service;

import com.etl.orchestrator.model.PipelineRuntime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class BackfillService {

    private final PipelineOrchestratorService orchestratorService;

    @Autowired
    public BackfillService(PipelineOrchestratorService orchestratorService) {
        this.orchestratorService = orchestratorService;
    }

    public PipelineRuntime executeBackfill(String pipelineId, LocalDate fromDate, LocalDate toDate) {
        if (fromDate.isAfter(toDate)) {
            throw new IllegalArgumentException("fromDate must not be after toDate");
        }

        List<PipelineRuntime> perDayRuntimes = new ArrayList<>();
        LocalDate current = fromDate;
        while (!current.isAfter(toDate)) {
            perDayRuntimes.add(orchestratorService.executePipeline(pipelineId, current));
            current = current.plusDays(1);
        }

        long completedCount = perDayRuntimes.stream()
                .filter(r -> "COMPLETED".equals(r.getStatus())).count();
        long failedCount = perDayRuntimes.stream()
                .filter(r -> "FAILED".equals(r.getStatus())).count();
        int total = perDayRuntimes.size();

        String aggregateStatus;
        if (completedCount == total) {
            aggregateStatus = "COMPLETED";
        } else if (failedCount == total) {
            aggregateStatus = "FAILED";
        } else {
            aggregateStatus = "PARTIAL_FAILURE";
        }

        Map<String, Long> aggregateStageRuntimes = new LinkedHashMap<>();
        for (PipelineRuntime dayRuntime : perDayRuntimes) {
            for (Map.Entry<String, Long> entry : dayRuntime.getStageRuntimes().entrySet()) {
                aggregateStageRuntimes.merge(entry.getKey(), entry.getValue(), Long::sum);
            }
        }

        PipelineRuntime aggregateRuntime = new PipelineRuntime(
                pipelineId,
                perDayRuntimes.get(0).getStartedAt(),
                perDayRuntimes.get(total - 1).getCompletedAt(),
                aggregateStatus,
                aggregateStageRuntimes
        );

        orchestratorService.storeRuntime(pipelineId, aggregateRuntime);
        return aggregateRuntime;
    }
}
