package com.etl.orchestrator.service;

import com.etl.orchestrator.exception.SchemaValidationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class SchemaValidationService {

    public void validateSchema(Map<String, String> schema,
                               Map<String, String> realizedSchema,
                               String datasetId) {
        List<String> violations = new ArrayList<>();

        for (Map.Entry<String, String> entry : schema.entrySet()) {
            String columnName = entry.getKey();
            String declaredType = entry.getValue();

            if (!realizedSchema.containsKey(columnName)) {
                violations.add("missing column: " + columnName);
            } else {
                String realizedType = realizedSchema.get(columnName);
                if (!declaredType.equals(realizedType)) {
                    violations.add("type mismatch: " + columnName
                            + " expected " + declaredType
                            + " but got " + realizedType);
                }
            }
        }

        if (!violations.isEmpty()) {
            throw new SchemaValidationException(datasetId, violations);
        }
    }
}
