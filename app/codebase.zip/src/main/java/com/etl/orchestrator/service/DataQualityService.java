package com.etl.orchestrator.service;

import com.etl.orchestrator.model.DataQualityResult;
import com.etl.orchestrator.model.DataQualityRule;
import com.etl.orchestrator.model.QualityCheckType;
import com.etl.orchestrator.model.QualityScoreEntry;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DataQualityService {

    private final List<QualityScoreEntry> trajectoryStore = new ArrayList<>();

    public DataQualityResult evaluateQuality(String datasetId,
                                             List<DataQualityRule> rules,
                                             Map<String, Map<QualityCheckType, Double>> metricValues,
                                             LocalDate partitionDate) {
        Map<String, Boolean> ruleResults = new LinkedHashMap<>();
        int passing = 0;

        for (DataQualityRule rule : rules) {
            double measuredValue = metricValues.get(rule.getColumnName()).get(rule.getCheckType());
            boolean passes = measuredValue <= rule.getThreshold();
            String key = rule.getColumnName() + "::" + rule.getCheckType().name();
            ruleResults.put(key, passes);
            if (passes) {
                passing++;
            }
        }

        double score = rules.isEmpty() ? 1.0 : (double) passing / rules.size();

        Instant evaluatedAt = Instant.now();
        QualityScoreEntry entry = new QualityScoreEntry(datasetId, partitionDate, evaluatedAt, score, ruleResults);
        synchronized (trajectoryStore) {
            trajectoryStore.add(entry);
        }

        return new DataQualityResult(datasetId, ruleResults, score);
    }

    public List<QualityScoreEntry> getQualityScoreTrajectory(String datasetId) {
        List<QualityScoreEntry> snapshot;
        synchronized (trajectoryStore) {
            snapshot = new ArrayList<>(trajectoryStore);
        }
        return snapshot.stream()
                .filter(e -> datasetId.equals(e.getDatasetId()))
                .sorted(Comparator.comparing(QualityScoreEntry::getPartitionDate)
                        .thenComparing(QualityScoreEntry::getEvaluatedAt))
                .collect(Collectors.toList());
    }
}
