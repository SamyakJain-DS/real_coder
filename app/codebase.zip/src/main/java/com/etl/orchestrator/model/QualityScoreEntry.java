package com.etl.orchestrator.model;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Map;

public class QualityScoreEntry {

    private String datasetId;
    private LocalDate partitionDate;
    private Instant evaluatedAt;
    private double score;
    private Map<String, Boolean> ruleResults;

    public QualityScoreEntry() {
    }

    public QualityScoreEntry(String datasetId, LocalDate partitionDate, Instant evaluatedAt,
                              double score, Map<String, Boolean> ruleResults) {
        this.datasetId = datasetId;
        this.partitionDate = partitionDate;
        this.evaluatedAt = evaluatedAt;
        this.score = score;
        this.ruleResults = ruleResults;
    }

    public String getDatasetId() {
        return datasetId;
    }

    public void setDatasetId(String datasetId) {
        this.datasetId = datasetId;
    }

    public LocalDate getPartitionDate() {
        return partitionDate;
    }

    public void setPartitionDate(LocalDate partitionDate) {
        this.partitionDate = partitionDate;
    }

    public Instant getEvaluatedAt() {
        return evaluatedAt;
    }

    public void setEvaluatedAt(Instant evaluatedAt) {
        this.evaluatedAt = evaluatedAt;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public Map<String, Boolean> getRuleResults() {
        return ruleResults;
    }

    public void setRuleResults(Map<String, Boolean> ruleResults) {
        this.ruleResults = ruleResults;
    }
}
