package com.etl.orchestrator.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class DataQualityResult {

    private String datasetId;
    private Map<String, Boolean> ruleResults = new LinkedHashMap<>();
    private double score;

    public DataQualityResult() {
    }

    public DataQualityResult(String datasetId, Map<String, Boolean> ruleResults, double score) {
        this.datasetId = datasetId;
        this.ruleResults = ruleResults;
        this.score = score;
    }

    public String getDatasetId() {
        return datasetId;
    }

    public void setDatasetId(String datasetId) {
        this.datasetId = datasetId;
    }

    public Map<String, Boolean> getRuleResults() {
        return ruleResults;
    }

    public void setRuleResults(Map<String, Boolean> ruleResults) {
        this.ruleResults = ruleResults;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
}
