package com.etl.orchestrator.service;

import com.etl.orchestrator.exception.SchemaValidationException;
import com.etl.orchestrator.model.ColumnLineage;
import com.etl.orchestrator.model.PipelineDeclaration;
import com.etl.orchestrator.model.PipelineRuntime;
import com.etl.orchestrator.model.PipelineStage;
import com.etl.orchestrator.model.StageExecutionResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class PipelineOrchestratorService {

    private final Map<String, PipelineDeclaration> pipelineRegistry = new ConcurrentHashMap<>();
    private final Map<String, PipelineRuntime> latestRuntimes = new ConcurrentHashMap<>();

    private final TaskDispatcher taskDispatcher;
    private final SchemaValidationService schemaValidationService;
    private final DataQualityService dataQualityService;
    private final LineageTrackerService lineageTrackerService;

    @Autowired
    public PipelineOrchestratorService(TaskDispatcher taskDispatcher,
                                       SchemaValidationService schemaValidationService,
                                       DataQualityService dataQualityService,
                                       LineageTrackerService lineageTrackerService) {
        this.taskDispatcher = taskDispatcher;
        this.schemaValidationService = schemaValidationService;
        this.dataQualityService = dataQualityService;
        this.lineageTrackerService = lineageTrackerService;
    }

    public void registerPipeline(PipelineDeclaration declaration) {
        pipelineRegistry.put(declaration.getPipelineId(), declaration);
    }

    public PipelineRuntime executePipeline(String pipelineId, LocalDate replayDate) {
        PipelineDeclaration declaration = pipelineRegistry.get(pipelineId);
        String sourceDatasetId = declaration.getSourceDatasetId();
        String sinkDatasetId = declaration.getSinkDatasetId();

        Instant startedAt = Instant.now();
        Map<String, Long> stageRuntimes = new LinkedHashMap<>();

        for (PipelineStage stage : declaration.getStages()) {
            StageExecutionResult stageResult =
                    taskDispatcher.dispatch(stage, sinkDatasetId, replayDate);

            try {
                schemaValidationService.validateSchema(
                        stage.getSchema(), stageResult.getRealizedSchema(), sinkDatasetId);
            } catch (SchemaValidationException e) {
                return new PipelineRuntime(pipelineId, startedAt, Instant.now(), "FAILED", stageRuntimes);
            }

            stageRuntimes.put(stage.getStageId(), stageResult.getElapsedMs());

            dataQualityService.evaluateQuality(
                    sinkDatasetId, stage.getQualityRules(), stageResult.getMetricValues(), replayDate);

            for (String columnName : stage.getSchema().keySet()) {
                lineageTrackerService.recordLineage(new ColumnLineage(
                        sinkDatasetId,
                        columnName,
                        Collections.singletonList(sourceDatasetId + "::" + columnName),
                        Collections.emptyList()
                ));
                lineageTrackerService.recordLineage(new ColumnLineage(
                        sourceDatasetId,
                        columnName,
                        Collections.emptyList(),
                        Collections.singletonList(sinkDatasetId + "::" + columnName)
                ));
            }
        }

        return new PipelineRuntime(pipelineId, startedAt, Instant.now(), "COMPLETED", stageRuntimes);
    }

    public void storeRuntime(String pipelineId, PipelineRuntime runtime) {
        latestRuntimes.put(pipelineId, runtime);
    }

    public PipelineRuntime getLatestRuntime(String pipelineId) {
        return latestRuntimes.get(pipelineId);
    }
}
