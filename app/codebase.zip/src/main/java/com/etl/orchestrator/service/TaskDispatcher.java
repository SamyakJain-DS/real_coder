package com.etl.orchestrator.service;

import com.etl.orchestrator.model.PipelineStage;
import com.etl.orchestrator.model.StageExecutionResult;
import com.etl.orchestrator.model.WorkerNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class TaskDispatcher {

    private final StageExecutor stageExecutor;
    private final List<WorkerNode> workerRegistry = new ArrayList<>();
    private final AtomicInteger roundRobinIndex = new AtomicInteger(0);
    private WorkerNode lastSelectedWorker;

    @Autowired
    public TaskDispatcher(StageExecutor stageExecutor) {
        this.stageExecutor = stageExecutor;
    }

    public void registerWorker(WorkerNode node) {
        workerRegistry.add(node);
    }

    public StageExecutionResult dispatch(PipelineStage stage, String datasetId, LocalDate replayDate) {
        if (!workerRegistry.isEmpty()) {
            int idx = roundRobinIndex.getAndUpdate(i -> (i + 1) % workerRegistry.size());
            lastSelectedWorker = workerRegistry.get(idx);
        }

        long startMs = System.currentTimeMillis();
        StageExecutionResult executorResult = stageExecutor.execute(stage, datasetId, replayDate);
        long elapsedMs = System.currentTimeMillis() - startMs;

        return new StageExecutionResult(
                executorResult.getStageId(),
                elapsedMs,
                executorResult.getRealizedSchema(),
                executorResult.getMetricValues()
        );
    }
}
