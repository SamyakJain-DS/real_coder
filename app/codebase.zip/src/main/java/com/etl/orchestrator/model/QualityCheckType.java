package com.etl.orchestrator.model;

public enum QualityCheckType {
    NULL_RATE,
    FRESHNESS,
    VOLUME,
    DISTRIBUTION_DRIFT
}
