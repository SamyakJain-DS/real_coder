package com.etl.orchestrator.exception;

import java.util.ArrayList;
import java.util.List;

public class SchemaValidationException extends RuntimeException {

    private final String datasetId;
    private final List<String> violations;

    public SchemaValidationException(String datasetId, List<String> violations) {
        super("Schema validation failed for dataset '" + datasetId + "': " + violations);
        this.datasetId = datasetId;
        this.violations = violations == null ? new ArrayList<>() : new ArrayList<>(violations);
    }

    public String getDatasetId() {
        return datasetId;
    }

    public List<String> getViolations() {
        return violations;
    }
}
