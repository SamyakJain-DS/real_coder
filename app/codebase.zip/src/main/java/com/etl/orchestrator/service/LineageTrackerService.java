package com.etl.orchestrator.service;

import com.etl.orchestrator.model.ColumnLineage;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class LineageTrackerService {

    private final Map<String, ColumnLineage> store = new ConcurrentHashMap<>();

    private String key(String datasetId, String columnName) {
        return datasetId + "\u0000" + columnName;
    }

    public void recordLineage(ColumnLineage lineage) {
        store.put(key(lineage.getDatasetId(), lineage.getColumnName()), lineage);
    }

    public List<String> getUpstreamColumns(String datasetId, String columnName) {
        ColumnLineage lineage = store.get(key(datasetId, columnName));
        if (lineage == null) {
            return Collections.emptyList();
        }
        return lineage.getUpstreamColumns();
    }

    public List<String> getDownstreamColumns(String datasetId, String columnName) {
        ColumnLineage lineage = store.get(key(datasetId, columnName));
        if (lineage == null) {
            return Collections.emptyList();
        }
        return lineage.getDownstreamColumns();
    }
}
