package com.etl.orchestrator.model;

import java.util.ArrayList;
import java.util.List;

public class ColumnLineage {

    private String datasetId;
    private String columnName;
    private List<String> upstreamColumns = new ArrayList<>();
    private List<String> downstreamColumns = new ArrayList<>();

    public ColumnLineage() {
    }

    public ColumnLineage(String datasetId,
                         String columnName,
                         List<String> upstreamColumns,
                         List<String> downstreamColumns) {
        this.datasetId = datasetId;
        this.columnName = columnName;
        this.upstreamColumns = upstreamColumns;
        this.downstreamColumns = downstreamColumns;
    }

    public String getDatasetId() {
        return datasetId;
    }

    public void setDatasetId(String datasetId) {
        this.datasetId = datasetId;
    }

    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }

    public List<String> getUpstreamColumns() {
        return upstreamColumns;
    }

    public void setUpstreamColumns(List<String> upstreamColumns) {
        this.upstreamColumns = upstreamColumns;
    }

    public List<String> getDownstreamColumns() {
        return downstreamColumns;
    }

    public void setDownstreamColumns(List<String> downstreamColumns) {
        this.downstreamColumns = downstreamColumns;
    }
}
