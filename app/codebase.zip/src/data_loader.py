"""
Data loader for the housing code enforcement analytics pipeline.
Loads and validates the five CSV files, parses date columns, and returns typed DataFrames.
"""
import os
import pandas as pd


REQUIRED_COLUMNS = {
    "properties": ["property_id", "landlord_id", "neighborhood_id", "absentee_owner", "year_built"],
    "inspections": ["inspection_id", "property_id", "inspection_date", "inspector_id", "outcome"],
    "violations": [
        "violation_id", "inspection_id", "property_id", "landlord_id",
        "violation_category", "enforcement_tool", "violation_date",
        "enforcement_action_date", "resolution_date", "resolution_outcome", "is_repeat",
    ],
    "landlords": ["landlord_id", "landlord_name"],
    "neighborhoods": ["neighborhood_id", "neighborhood_name", "year", "condition_score"],
}

DATE_COLUMNS = {
    "inspections": ["inspection_date"],
    "violations": ["violation_date", "enforcement_action_date", "resolution_date"],
}

FILE_NAMES = {
    "properties": "properties.csv",
    "inspections": "inspections.csv",
    "violations": "violations.csv",
    "landlords": "landlords.csv",
    "neighborhoods": "neighborhoods.csv",
}


def load_data(data_dir: str) -> dict:
    """
    Load and validate the five CSV files from data_dir.

    Args:
        data_dir: Directory containing the five CSV files.

    Returns:
        dict with keys "properties", "inspections", "violations", "landlords", "neighborhoods",
        each mapping to a validated pandas DataFrame.

    Raises:
        FileNotFoundError: If any expected CSV file is absent.
        ValueError: If any required column is missing from its DataFrame.
    """
    dfs = {}

    for key, filename in FILE_NAMES.items():
        path = os.path.join(data_dir, filename)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Expected CSV file not found: {path}")
        dfs[key] = pd.read_csv(path)

    for key, required_cols in REQUIRED_COLUMNS.items():
        df = dfs[key]
        missing = [c for c in required_cols if c not in df.columns]
        if missing:
            raise ValueError(
                f"DataFrame '{key}' is missing required columns: {missing}"
            )

    # Parse date columns
    for key, date_cols in DATE_COLUMNS.items():
        df = dfs[key]
        for col in date_cols:
            if col in df.columns:
                dfs[key][col] = pd.to_datetime(df[col], errors="coerce")

    # Parse boolean columns
    for col in ["absentee_owner"]:
        if col in dfs["properties"].columns:
            dfs["properties"][col] = dfs["properties"][col].map(
                lambda x: str(x).strip().lower() in ("true", "1", "yes") if pd.notna(x) else False
            )

    for col in ["is_repeat"]:
        if col in dfs["violations"].columns:
            dfs["violations"][col] = dfs["violations"][col].map(
                lambda x: str(x).strip().lower() in ("true", "1", "yes") if pd.notna(x) else False
            )

    return dfs
