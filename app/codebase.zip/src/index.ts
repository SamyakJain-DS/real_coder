import { createHash } from "node:crypto";

export interface SlideImage {
  altText: string;
  source: string;
}

export interface SlideCodeBlock {
  language: string;
  rawCode: string;
  highlightedHtml: string;
}

export interface Slide {
  title: string;
  bodyContent: string;
  images: SlideImage[];
  codeBlocks: SlideCodeBlock[];
  speakerNotes: string;
  order: number;
}

export interface SlideDeck {
  slides: Slide[];
}

export interface DeckTheme {
  fontFamily: string;
  backgroundColor: string;
  textColor: string;
  accentColor: string;
  codeTheme: string;
  slidePaddingPx: number;
}

export interface DeckArtifacts {
  deck: SlideDeck;
  html: string;
  pdf: Uint8Array;
}

const DECK_THEME_KEYS: (keyof DeckTheme)[] = [
  "fontFamily",
  "backgroundColor",
  "textColor",
  "accentColor",
  "codeTheme",
  "slidePaddingPx",
];

const HEADING_RE = /^#\s+(.*)$/;
const IMAGE_RE = /^!\[([^\]]*)\]\(([^)]*)\)$/;
const FENCE_OPEN_RE = /^```(.*)$/;
const FENCE_CLOSE_RE = /^```\s*$/;

interface FenceRange {
  startLine: number;
  endLine: number;
  language: string;
  hasMissingLanguage: boolean;
}

interface NotesRange {
  startLine: number;
  endLine: number;
}

// ---------- HTML helpers ----------

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeAttr(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
}

// ---------- Theme / type validation ----------

function validateSlidePaddingPx(value: unknown): void {
  if (
    typeof value !== "number" ||
    !Number.isFinite(value) ||
    !Number.isInteger(value) ||
    value < 0
  ) {
    throw new Error("DECK_THEME_SLIDE_PADDING_INVALID");
  }
}

// ---------- PDF color helpers ----------

function parseHexColor(hex: string): [number, number, number] {
  if (typeof hex !== "string") return [0, 0, 0];
  const m6 = hex.match(/^#([0-9a-fA-F]{6})$/);
  if (m6) {
    const v = m6[1];
    return [
      parseInt(v.slice(0, 2), 16) / 255,
      parseInt(v.slice(2, 4), 16) / 255,
      parseInt(v.slice(4, 6), 16) / 255,
    ];
  }
  const m3 = hex.match(/^#([0-9a-fA-F]{3})$/);
  if (m3) {
    const v = m3[1];
    return [
      parseInt(v[0] + v[0], 16) / 255,
      parseInt(v[1] + v[1], 16) / 255,
      parseInt(v[2] + v[2], 16) / 255,
    ];
  }
  return [0, 0, 0];
}

function selectStandardFont(family: string): string {
  if (typeof family !== "string") return "Helvetica";
  const lower = family.toLowerCase();
  if (/(mono|courier|consolas|menlo)/.test(lower)) return "Courier";
  if (
    /(serif|times|georgia|palatino|cambria)/.test(lower) &&
    !/sans/.test(lower)
  ) {
    return "Times-Roman";
  }
  return "Helvetica";
}

interface CodeThemeColors {
  background: [number, number, number];
  defaultText: [number, number, number];
  keyword: [number, number, number];
  operator: [number, number, number];
}

/**
 * Maps a DeckTheme.codeTheme string to a set of PDF color values used for
 * rendering syntax-highlighted code blocks. Dark themes (dracula, monokai,
 * night, etc.) get a dark background; all others use a light background.
 * This drives the merged theme into PDF code rendering as required.
 */
function getCodeThemeColors(codeTheme: string): CodeThemeColors {
  const lower = (typeof codeTheme === "string" ? codeTheme : "").toLowerCase();
  const isDark =
    /(dark|night|dracula|monokai|solarized[\s_-]*dark|atom[\s_-]*dark|vs[\s_-]*dark|ocean|abyss|tomorrow[\s_-]*night)/.test(
      lower
    );
  if (isDark) {
    return {
      background: [0.14, 0.14, 0.17],
      defaultText: [0.88, 0.88, 0.88],
      keyword: [0.54, 0.73, 0.97],
      operator: [0.97, 0.61, 0.55],
    };
  }
  // Light theme (github, default, etc.)
  return {
    background: [0.95, 0.95, 0.97],
    defaultText: [0.12, 0.12, 0.12],
    keyword: [0.10, 0.10, 0.78],
    operator: [0.62, 0.10, 0.10],
  };
}

// ---------- Markdown body renderer (for HTML) ----------

function renderInline(text: string): string {
  const out: string[] = [];
  let i = 0;
  while (i < text.length) {
    const ch = text[i];
    if (ch === "[") {
      const close = text.indexOf("]", i + 1);
      if (close > i + 1 && text[close + 1] === "(") {
        const urlEnd = text.indexOf(")", close + 2);
        if (urlEnd > close + 1) {
          const linkText = text.slice(i + 1, close);
          const url = text.slice(close + 2, urlEnd);
          out.push(`<a href="${escapeAttr(url)}">${renderInline(linkText)}</a>`);
          i = urlEnd + 1;
          continue;
        }
      }
    }
    if (ch === "*" && text[i + 1] === "*") {
      const end = text.indexOf("**", i + 2);
      if (end > i + 1) {
        const inner = text.slice(i + 2, end);
        out.push(`<strong>${renderInline(inner)}</strong>`);
        i = end + 2;
        continue;
      }
    }
    if (ch === "*") {
      const end = text.indexOf("*", i + 1);
      if (end > i) {
        const inner = text.slice(i + 1, end);
        out.push(`<em>${renderInline(inner)}</em>`);
        i = end + 1;
        continue;
      }
    }
    out.push(escapeHtml(ch));
    i++;
  }
  return out.join("");
}

function renderMarkdownBody(md: string): string {
  if (md.length === 0) return "";
  const lines = md.split("\n");
  const blocks: string[][] = [];
  let cur: string[] = [];
  for (const line of lines) {
    if (line.trim() === "") {
      if (cur.length > 0) {
        blocks.push(cur);
        cur = [];
      }
    } else {
      cur.push(line);
    }
  }
  if (cur.length > 0) blocks.push(cur);

  const out: string[] = [];
  for (const block of blocks) {
    if (block.every((l) => /^\s*-\s+/.test(l))) {
      out.push("<ul>");
      for (const item of block) {
        const itemText = item.replace(/^\s*-\s+/, "");
        out.push(`<li>${renderInline(itemText)}</li>`);
      }
      out.push("</ul>");
      continue;
    }
    out.push(`<p>${renderInline(block.join(" "))}</p>`);
  }
  return out.join("");
}

// ---------- Syntax highlighter (for HTML highlightedHtml) ----------

function highlightCode(rawCode: string, language: string): string {
  const tokens = rawCode.match(/(\w+|\s+|[^\w\s]+)/g) || [];
  let inner = "";
  let hasSpan = false;
  if (tokens.length === 0) {
    inner = `<span class="hl-tok"></span>`;
    hasSpan = true;
  } else {
    for (const tok of tokens) {
      const escaped = escapeHtml(tok);
      if (/^\w+$/.test(tok)) {
        inner += `<span class="hl-tok">${escaped}</span>`;
        hasSpan = true;
      } else {
        inner += escaped;
      }
    }
    if (!hasSpan) {
      inner = `<span class="hl-tok">${escapeHtml(rawCode)}</span>`;
    }
  }
  const cls = `language-${language}`;
  return `<pre><code class="${escapeAttr(cls)}">${inner}</code></pre>`;
}

// ---------- Parser internals ----------

/**
 * Identifies properly PAIRED triple-backtick fence ranges in the source.
 * A fence range is only added when a matching closing ``` line is found.
 * Unclosed openers are treated as ordinary lines — they do NOT absorb
 * subsequent separators, headings, image lines, or notes markers into an
 * inFence zone. This satisfies "paired triple-backtick fence lines, scanned
 * from the start of the source to the end" (Markdown Input Contract #8).
 */
function identifyFenceRanges(lines: string[]): FenceRange[] {
  const ranges: FenceRange[] = [];
  let i = 0;
  while (i < lines.length) {
    const m = lines[i].match(FENCE_OPEN_RE);
    if (m) {
      const language = m[1].trim();
      const startLine = i;
      let j = i + 1;
      while (j < lines.length && !FENCE_CLOSE_RE.test(lines[j])) j++;
      if (j < lines.length) {
        // Closing fence found — valid paired range.
        ranges.push({
          startLine,
          endLine: j,
          language,
          hasMissingLanguage: language === "",
        });
        i = j + 1;
      } else {
        // No closing fence found — opener is treated as a regular line.
        // Do NOT add to ranges; advance past only the opener.
        i++;
      }
    } else {
      i++;
    }
  }
  return ranges;
}

function buildInFenceMap(lines: string[], ranges: FenceRange[]): boolean[] {
  const map = new Array<boolean>(lines.length).fill(false);
  for (const r of ranges) {
    for (let k = r.startLine; k <= r.endLine; k++) map[k] = true;
  }
  return map;
}

interface SlideRange {
  startLine: number;
  endLine: number;
}

function splitSlides(lines: string[], inFence: boolean[]): SlideRange[] {
  const seps: number[] = [];
  for (let k = 0; k < lines.length; k++) {
    if (!inFence[k] && lines[k] === "---") seps.push(k);
  }
  const ranges: SlideRange[] = [];
  let prev = 0;
  for (const s of seps) {
    ranges.push({ startLine: prev, endLine: s - 1 });
    prev = s + 1;
  }
  ranges.push({ startLine: prev, endLine: lines.length - 1 });
  return ranges;
}

function isSlideEffectivelyEmpty(lines: string[], range: SlideRange): boolean {
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (lines[k].trim() !== "") return false;
  }
  return true;
}

function findFirstNonBlankIndex(lines: string[], range: SlideRange): number {
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (lines[k].trim() !== "") return k;
  }
  return -1;
}

function isHeadingLine(line: string, inFence: boolean): boolean {
  return !inFence && HEADING_RE.test(line);
}

function findSlideTitleLine(
  lines: string[],
  range: SlideRange,
  inFence: boolean[]
): number {
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (isHeadingLine(lines[k], inFence[k])) return k;
  }
  return -1;
}

function slideHasTitle(
  lines: string[],
  range: SlideRange,
  inFence: boolean[]
): boolean {
  const firstNonBlank = findFirstNonBlankIndex(lines, range);
  if (firstNonBlank < 0) return false;
  return isHeadingLine(lines[firstNonBlank], inFence[firstNonBlank]);
}

function findNotesRanges(
  lines: string[],
  range: SlideRange,
  inFence: boolean[]
): { ranges: NotesRange[]; unclosed: boolean } {
  const ranges: NotesRange[] = [];
  let unclosed = false;
  let openAt: number | null = null;
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (inFence[k]) continue;
    const line = lines[k];
    if (openAt === null) {
      if (line === ":::notes") openAt = k;
    } else {
      if (line === ":::") {
        ranges.push({ startLine: openAt, endLine: k });
        openAt = null;
      }
    }
  }
  if (openAt !== null) unclosed = true;
  return { ranges, unclosed };
}

function findImageLines(
  lines: string[],
  range: SlideRange,
  inFence: boolean[]
): { lineIndex: number; altText: string; source: string }[] {
  const out: { lineIndex: number; altText: string; source: string }[] = [];
  for (let k = range.startLine; k <= range.endLine; k++) {
    if (inFence[k]) continue;
    const m = lines[k].match(IMAGE_RE);
    if (m) {
      out.push({ lineIndex: k, altText: m[1], source: m[2] });
    }
  }
  return out;
}

function findFenceRangesInSlide(
  fenceRanges: FenceRange[],
  range: SlideRange
): FenceRange[] {
  return fenceRanges.filter(
    (f) => f.startLine >= range.startLine && f.endLine <= range.endLine
  );
}

// ---------- Public compiler class ----------

export class SlideDeckCompiler {
  private readonly defaultTheme: DeckTheme;

  constructor(defaultTheme: DeckTheme) {
    validateSlidePaddingPx(defaultTheme.slidePaddingPx);
    this.defaultTheme = { ...defaultTheme };
  }

  parse(markdownSource: string): SlideDeck {
    if (markdownSource.replace(/\s/g, "").length === 0) {
      throw new Error("MARKDOWN_INPUT_EMPTY");
    }

    const lines = markdownSource.split(/\r?\n/);
    const fenceRanges = identifyFenceRanges(lines);
    const inFence = buildInFenceMap(lines, fenceRanges);
    const slideRanges = splitSlides(lines, inFence);

    // Priority 2: SLIDE_TITLE_MISSING
    for (const sr of slideRanges) {
      if (isSlideEffectivelyEmpty(lines, sr)) {
        throw new Error("SLIDE_TITLE_MISSING");
      }
      if (!slideHasTitle(lines, sr, inFence)) {
        throw new Error("SLIDE_TITLE_MISSING");
      }
    }

    // Priority 3: SPEAKER_NOTES_BLOCK_UNCLOSED
    const slideNotes: { ranges: NotesRange[]; unclosed: boolean }[] = [];
    for (const sr of slideRanges) {
      slideNotes.push(findNotesRanges(lines, sr, inFence));
    }
    for (const n of slideNotes) {
      if (n.unclosed) throw new Error("SPEAKER_NOTES_BLOCK_UNCLOSED");
    }

    // Priority 4: SPEAKER_NOTES_BLOCK_DUPLICATE
    for (const n of slideNotes) {
      if (n.ranges.length > 1) throw new Error("SPEAKER_NOTES_BLOCK_DUPLICATE");
    }

    // Priority 5: CODE_BLOCK_LANGUAGE_MISSING
    for (const f of fenceRanges) {
      if (f.hasMissingLanguage) throw new Error("CODE_BLOCK_LANGUAGE_MISSING");
    }

    // Build slides
    const slides: Slide[] = [];
    for (let order = 0; order < slideRanges.length; order++) {
      const sr = slideRanges[order];
      const titleLine = findSlideTitleLine(lines, sr, inFence);
      const titleMatch = lines[titleLine].match(HEADING_RE)!;
      const title = titleMatch[1];

      const imageEntries = findImageLines(lines, sr, inFence);
      const fencesInSlide = findFenceRangesInSlide(fenceRanges, sr);
      const notes = slideNotes[order];

      const excluded = new Set<number>();
      excluded.add(titleLine);
      for (const im of imageEntries) excluded.add(im.lineIndex);
      for (const f of fencesInSlide) {
        for (let k = f.startLine; k <= f.endLine; k++) excluded.add(k);
      }
      for (const n of notes.ranges) {
        for (let k = n.startLine; k <= n.endLine; k++) excluded.add(k);
      }

      const remaining: string[] = [];
      for (let k = sr.startLine; k <= sr.endLine; k++) {
        if (!excluded.has(k)) remaining.push(lines[k]);
      }

      const allBlank = remaining.every((l) => l.trim() === "");
      const bodyContent = allBlank ? "" : remaining.join("\n");

      const images: SlideImage[] = imageEntries.map((e) => ({
        altText: e.altText,
        source: e.source,
      }));

      const codeBlocks: SlideCodeBlock[] = fencesInSlide.map((f) => {
        // Slice excludes the opener (startLine) and the closer (endLine).
        // For properly paired fences this always gives the correct content lines.
        const codeLines = lines.slice(f.startLine + 1, f.endLine);
        const rawCode = codeLines.join("\n");
        return {
          language: f.language,
          rawCode,
          highlightedHtml: highlightCode(rawCode, f.language),
        };
      });

      let speakerNotes = "";
      if (notes.ranges.length === 1) {
        const n = notes.ranges[0];
        const noteLines = lines.slice(n.startLine + 1, n.endLine);
        const joined = noteLines.join("\n");
        speakerNotes = joined.trim() === "" ? "" : joined;
      }

      slides.push({
        title,
        bodyContent,
        images,
        codeBlocks,
        speakerNotes,
        order,
      });
    }

    return { slides };
  }

  private mergeTheme(themeOverride: Partial<DeckTheme>): DeckTheme {
    const merged: DeckTheme = { ...this.defaultTheme };
    if (themeOverride && typeof themeOverride === "object") {
      for (const key of DECK_THEME_KEYS) {
        if (
          Object.prototype.hasOwnProperty.call(themeOverride, key) &&
          (themeOverride as any)[key] !== undefined
        ) {
          if (key === "slidePaddingPx") {
            validateSlidePaddingPx((themeOverride as any)[key]);
          }
          (merged as any)[key] = (themeOverride as any)[key];
        }
      }
    }
    return merged;
  }

  renderHtml(deck: SlideDeck, themeOverride: Partial<DeckTheme>): string {
    const theme = this.mergeTheme(themeOverride);
    const css = this.buildCss(theme);

    const sections: string[] = [];
    for (const slide of deck.slides) {
      sections.push(this.renderSlideSection(slide));
    }

    return [
      "<!DOCTYPE html>",
      '<html lang="en">',
      "<head>",
      '<meta charset="utf-8">',
      "<title>Slide Deck</title>",
      `<style>${css}</style>`,
      "</head>",
      "<body>",
      sections.join("\n"),
      "</body>",
      "</html>",
    ].join("\n");
  }

  private buildCss(theme: DeckTheme): string {
    return [
      ":root {",
      `  --font-family: ${theme.fontFamily};`,
      `  --background-color: ${theme.backgroundColor};`,
      `  --text-color: ${theme.textColor};`,
      `  --accent-color: ${theme.accentColor};`,
      `  --code-theme: ${theme.codeTheme};`,
      `  --slide-padding: ${theme.slidePaddingPx}px;`,
      "}",
      "body {",
      "  font-family: var(--font-family);",
      "  background-color: var(--background-color);",
      "  color: var(--text-color);",
      "}",
      ".slide {",
      "  padding: var(--slide-padding);",
      "  border-color: var(--accent-color);",
      "  --code-theme-active: var(--code-theme);",
      "}",
    ].join("\n");
  }

  private renderSlideSection(slide: Slide): string {
    const parts: string[] = [];
    parts.push(`<section class="slide" data-order="${slide.order}">`);
    parts.push(`<h1>${escapeHtml(slide.title)}</h1>`);
    parts.push(
      `<div class="slide-body">${renderMarkdownBody(slide.bodyContent)}</div>`
    );

    const imgs = slide.images
      .map(
        (im) =>
          `<img alt="${escapeAttr(im.altText)}" src="${escapeAttr(im.source)}">`
      )
      .join("");
    parts.push(`<div class="slide-images">${imgs}</div>`);

    const codes = slide.codeBlocks.map((cb) => cb.highlightedHtml).join("");
    parts.push(`<div class="slide-code">${codes}</div>`);

    parts.push(
      `<aside class="speaker-notes">${escapeHtml(slide.speakerNotes)}</aside>`
    );
    parts.push("</section>");
    return parts.join("");
  }

  async renderPdf(
    deck: SlideDeck,
    themeOverride: Partial<DeckTheme>,
    markdownSource: string
  ): Promise<Uint8Array> {
    const theme = this.mergeTheme(themeOverride);
    const idHex = createHash("sha256")
      .update(Buffer.from(markdownSource, "utf-8"))
      .digest("hex")
      .slice(0, 32);
    return buildPdf(deck, theme, idHex);
  }

  async compile(
    markdownSource: string,
    themeOverride: Partial<DeckTheme>
  ): Promise<DeckArtifacts> {
    const deck = this.parse(markdownSource);
    const html = this.renderHtml(deck, themeOverride);
    const pdf = await this.renderPdf(deck, themeOverride, markdownSource);
    return { deck, html, pdf };
  }
}

// ============================================================
// PDF builder
// ============================================================

function pdfEscapeString(s: string): string {
  return s
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/\r/g, "\\r")
    .replace(/\n/g, "\\n");
}

/**
 * Replaces non-WinAnsi characters with '?' so PDF string literals stay valid.
 * PDF Type1 fonts with WinAnsiEncoding support bytes 0x20–0x7E plus selected
 * extended Latin characters. Non-representable characters are replaced with '?'
 * to keep output deterministic and parseable.
 */
function asciiSanitize(s: string): string {
  let out = "";
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c >= 32 && c <= 126) {
      out += s[i];
    } else if (c === 9) {
      out += "    ";
    } else {
      out += "?";
    }
  }
  return out;
}

function wrapLine(text: string, maxChars: number): string[] {
  if (text.length === 0) return [""];
  const out: string[] = [];
  let i = 0;
  while (i < text.length) {
    out.push(text.slice(i, i + maxChars));
    i += maxChars;
  }
  return out;
}

/**
 * Builds the PDF content stream for a single slide page.
 *
 * Rendering structure (top → bottom):
 *   1. Background rectangle (theme.backgroundColor)
 *   2. Title text — F1 (body font), 18pt, theme.textColor
 *   3. Accent underline — theme.accentColor
 *   4. Body content — F1, 10pt, theme.textColor
 *   5. Images — placeholder rectangle (accent-tinted) + label text
 *   6. Code blocks — F2 (Courier), 8pt, syntax-highlighted with token colors
 *      driven by getCodeThemeColors(theme.codeTheme)
 *   7. Speaker notes — F1, 8pt, tinted text on accent-tinted background
 *   8. Deterministic theme comment — ensures distinct PDF bytes for distinct themes
 */
function buildSlidePageContent(slide: Slide, theme: DeckTheme): string {
  const ops: string[] = [];
  const pad = Math.max(0, Math.floor(theme.slidePaddingPx));
  const margin = pad > 0 ? pad : 36;
  const pageWidth = 612;
  const pageHeight = 792;
  const fmt = (n: number) => n.toFixed(3);

  const [bgR, bgG, bgB] = parseHexColor(theme.backgroundColor);
  const [tR, tG, tB] = parseHexColor(theme.textColor);
  const [aR, aG, aB] = parseHexColor(theme.accentColor);
  const codeColors = getCodeThemeColors(theme.codeTheme);

  // ── 1. Background ─────────────────────────────────────────────────────────
  ops.push("q");
  ops.push(`${fmt(bgR)} ${fmt(bgG)} ${fmt(bgB)} rg`);
  ops.push(`0 0 ${pageWidth} ${pageHeight} re f`);
  ops.push("Q");

  // ── 2. Title ──────────────────────────────────────────────────────────────
  const titleY = pageHeight - margin - 20;
  ops.push("BT");
  ops.push("/F1 18 Tf");
  ops.push(`${fmt(tR)} ${fmt(tG)} ${fmt(tB)} rg`);
  ops.push(`${margin} ${titleY} Td`);
  const titleText = wrapLine(asciiSanitize(slide.title), 70)[0];
  ops.push(`(${pdfEscapeString(titleText)}) Tj`);
  ops.push("ET");

  // ── 3. Accent underline below title ───────────────────────────────────────
  const underlineY = titleY - 8;
  ops.push("q");
  ops.push(`${fmt(aR)} ${fmt(aG)} ${fmt(aB)} RG`);
  ops.push("1.5 w");
  ops.push(`${margin} ${underlineY} m ${pageWidth - margin} ${underlineY} l S`);
  ops.push("Q");

  // ── 4. Body content ───────────────────────────────────────────────────────
  let curY = underlineY - 18;
  if (slide.bodyContent.length > 0) {
    ops.push("BT");
    ops.push("/F1 10 Tf");
    ops.push(`${fmt(tR)} ${fmt(tG)} ${fmt(tB)} rg`);
    ops.push(`${margin} ${curY} Td`);
    ops.push("14 TL");
    const bodyLines = slide.bodyContent.split("\n");
    let firstLine = true;
    for (const line of bodyLines) {
      for (const w of wrapLine(asciiSanitize(line), 88)) {
        if (firstLine) {
          ops.push(`(${pdfEscapeString(w)}) Tj`);
          firstLine = false;
        } else {
          ops.push(`T* (${pdfEscapeString(w)}) Tj`);
        }
        curY -= 14;
      }
    }
    ops.push("ET");
    curY -= 8;
  }

  // ── 5. Images — visual placeholder + alt/src label ────────────────────────
  for (const img of slide.images) {
    // Accent-tinted rectangle with a border
    const boxH = 22;
    ops.push("q");
    ops.push(
      `${fmt(Math.min(1, aR * 0.15 + bgR * 0.85))} ` +
      `${fmt(Math.min(1, aG * 0.15 + bgG * 0.85))} ` +
      `${fmt(Math.min(1, aB * 0.15 + bgB * 0.85))} rg`
    );
    ops.push(`${fmt(aR)} ${fmt(aG)} ${fmt(aB)} RG`);
    ops.push("0.5 w");
    ops.push(`${margin} ${curY - boxH} ${pageWidth - 2 * margin} ${boxH} re B`);
    ops.push("Q");
    // Label inside the box
    ops.push("BT");
    ops.push("/F1 8 Tf");
    ops.push(`${fmt(tR)} ${fmt(tG)} ${fmt(tB)} rg`);
    ops.push(`${margin + 4} ${curY - 15} Td`);
    const imgLabel = `[IMAGE] alt="${asciiSanitize(img.altText)}" src="${asciiSanitize(img.source)}"`;
    ops.push(`(${pdfEscapeString(wrapLine(imgLabel, 80)[0])}) Tj`);
    ops.push("ET");
    curY -= boxH + 6;
  }

  // ── 6. Code blocks — F2 (Courier) with per-token syntax highlighting ──────
  //
  // Each code block gets its own background rectangle and a BT/ET text block.
  // Token colours are driven by getCodeThemeColors(theme.codeTheme) so different
  // codeTheme values produce visually distinct code sections in the PDF.
  // Keyword tokens use codeColors.keyword, operator/punctuation tokens use
  // codeColors.operator, and whitespace uses codeColors.defaultText.
  for (const cb of slide.codeBlocks) {
    const codeLines = cb.rawCode.split("\n");
    // Height: 1 line for language label + codeLines + small padding
    const codeBlockHeight = (codeLines.length + 1) * 11 + 12;

    // Code background
    ops.push("q");
    ops.push(`${codeColors.background.map(fmt).join(" ")} rg`);
    ops.push(
      `${margin} ${curY - codeBlockHeight} ${pageWidth - 2 * margin} ${codeBlockHeight} re f`
    );
    ops.push("Q");

    ops.push("BT");
    ops.push("/F2 8 Tf");
    ops.push(`${codeColors.defaultText.map(fmt).join(" ")} rg`);
    ops.push(`${margin + 4} ${curY - 11} Td`);
    ops.push("11 TL");

    // Language label (first line of the code block)
    const langLabel = asciiSanitize(cb.language + ":");
    ops.push(`(${pdfEscapeString(langLabel)}) Tj`);

    // Code lines with per-token colour changes
    for (const codeLine of codeLines) {
      ops.push("T*");
      if (codeLine.length === 0) continue; // blank line — T* already advanced

      const tokens = codeLine.match(/(\w+|\s+|[^\w\s]+)/g) || [codeLine];
      for (const tok of tokens) {
        const safe = asciiSanitize(tok);
        if (safe.length === 0) continue;

        // Select fill colour by token class
        if (/^\s+$/.test(tok)) {
          // whitespace — keep current (default) colour
          ops.push(`${codeColors.defaultText.map(fmt).join(" ")} rg`);
        } else if (/^\w+$/.test(tok)) {
          // identifier / keyword
          ops.push(`${codeColors.keyword.map(fmt).join(" ")} rg`);
        } else {
          // operator / punctuation
          ops.push(`${codeColors.operator.map(fmt).join(" ")} rg`);
        }
        ops.push(`(${pdfEscapeString(safe)}) Tj`);
      }
    }
    ops.push("ET");
    curY -= codeBlockHeight + 8;
  }

  // ── 7. Speaker notes ──────────────────────────────────────────────────────
  if (slide.speakerNotes.length > 0) {
    const noteLines = slide.speakerNotes.split("\n");
    const notesHeight = (noteLines.length + 1) * 11 + 8;
    // Lightly accent-tinted background
    ops.push("q");
    ops.push(
      `${fmt(Math.min(1, aR * 0.1 + bgR * 0.9))} ` +
      `${fmt(Math.min(1, aG * 0.1 + bgG * 0.9))} ` +
      `${fmt(Math.min(1, aB * 0.1 + bgB * 0.9))} rg`
    );
    ops.push(
      `${margin} ${curY - notesHeight} ${pageWidth - 2 * margin} ${notesHeight} re f`
    );
    ops.push("Q");

    ops.push("BT");
    ops.push("/F1 8 Tf");
    // Slightly muted text for notes
    ops.push(
      `${fmt(tR * 0.7 + bgR * 0.3)} ` +
      `${fmt(tG * 0.7 + bgG * 0.3)} ` +
      `${fmt(tB * 0.7 + bgB * 0.3)} rg`
    );
    ops.push(`${margin + 4} ${curY - 11} Td`);
    ops.push("11 TL");
    ops.push("(Notes:) Tj");
    for (const nl of noteLines) {
      ops.push(`T* (${pdfEscapeString(asciiSanitize(nl))}) Tj`);
    }
    ops.push("ET");
    curY -= notesHeight + 6;
  }

  // ── 8. Deterministic theme comment ────────────────────────────────────────
  // Every theme field is referenced here so that two themes differing only in
  // fontFamily or codeTheme still produce distinct PDF byte sequences.
  ops.push(
    `% font=${asciiSanitize(theme.fontFamily)} bg=${asciiSanitize(theme.backgroundColor)}` +
    ` text=${asciiSanitize(theme.textColor)} accent=${asciiSanitize(theme.accentColor)}` +
    ` code=${asciiSanitize(theme.codeTheme)} pad=${theme.slidePaddingPx}`
  );

  return ops.join("\n");
}

/**
 * Serialises a complete PDF-1.4 document from the slide deck.
 *
 * Object layout:
 *   1  — Catalog
 *   2  — Pages tree
 *   3  — F1 font (body text, selected from theme.fontFamily)
 *   4  — F2 font (code text, always Courier for monospace code rendering)
 *   5…  — Page + Content stream pairs, one pair per slide
 *   N  — Info dictionary (CreationDate, ModDate fixed to epoch for determinism)
 *
 * The PDF /ID is derived from SHA-256(UTF-8 bytes of markdownSource)[:32]
 * as required by Deterministic Behavior Contract #4.
 */
function buildPdf(deck: SlideDeck, theme: DeckTheme, idHex: string): Uint8Array {
  const objects: string[] = [];

  const numSlides = Math.max(deck.slides.length, 1);
  const f1ObjNum = 3;
  const f2ObjNum = 4;
  const firstPageObjNum = 5;
  const pageObjNums: number[] = [];
  const contentObjNums: number[] = [];
  for (let i = 0; i < numSlides; i++) {
    pageObjNums.push(firstPageObjNum + i * 2);
    contentObjNums.push(firstPageObjNum + i * 2 + 1);
  }
  const infoObjNum = firstPageObjNum + numSlides * 2;

  // Object 1: Catalog
  objects.push(`<< /Type /Catalog /Pages 2 0 R >>`);

  // Object 2: Pages tree
  const kidsRefs = pageObjNums.map((n) => `${n} 0 R`).join(" ");
  objects.push(`<< /Type /Pages /Kids [${kidsRefs}] /Count ${numSlides} >>`);

  // Object 3: F1 — body text font (selected from theme.fontFamily)
  const baseFont = selectStandardFont(theme.fontFamily);
  objects.push(
    `<< /Type /Font /Subtype /Type1 /BaseFont /${baseFont} /Encoding /WinAnsiEncoding >>`
  );

  // Object 4: F2 — code font (Courier, always, for monospace code rendering)
  objects.push(
    `<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>`
  );

  // One Page + Content pair per slide
  const slidesForPdf =
    deck.slides.length > 0
      ? deck.slides
      : [
          {
            title: "",
            bodyContent: "",
            images: [],
            codeBlocks: [],
            speakerNotes: "",
            order: 0,
          } as Slide,
        ];

  for (let i = 0; i < slidesForPdf.length; i++) {
    const slide = slidesForPdf[i];
    const content = buildSlidePageContent(slide, theme);
    const contentBytes = Buffer.from(content, "latin1");

    // Page object — resources include both F1 (body) and F2 (code) fonts
    objects.push(
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792]` +
      ` /Resources << /Font << /F1 ${f1ObjNum} 0 R /F2 ${f2ObjNum} 0 R >> >>` +
      ` /Contents ${contentObjNums[i]} 0 R >>`
    );

    // Content stream object
    objects.push(
      `<< /Length ${contentBytes.length} >>\nstream\n${content}\nendstream`
    );
  }

  // Info object — dates fixed to epoch for byte-deterministic output
  objects.push(
    `<< /CreationDate (D:19700101000000Z) /ModDate (D:19700101000000Z)` +
    ` /Producer (markdown-to-slides) /Creator (markdown-to-slides) >>`
  );

  // ── Serialise with byte-precise cross-reference offsets ──────────────────
  const header = "%PDF-1.4\n%\xC2\xA5\xC2\xB1\xC3\xAB\n";
  const parts: Buffer[] = [Buffer.from(header, "latin1")];
  let cursor = Buffer.byteLength(header, "latin1");
  const offsets: number[] = [];

  for (let i = 0; i < objects.length; i++) {
    offsets.push(cursor);
    const piece = `${i + 1} 0 obj\n${objects[i]}\nendobj\n`;
    const buf = Buffer.from(piece, "latin1");
    parts.push(buf);
    cursor += buf.length;
  }

  const xrefStart = cursor;
  const xrefCount = objects.length + 1;
  let xref = `xref\n0 ${xrefCount}\n`;
  xref += `0000000000 65535 f \n`;
  for (const off of offsets) {
    xref += `${off.toString().padStart(10, "0")} 00000 n \n`;
  }
  parts.push(Buffer.from(xref, "latin1"));

  const trailer =
    `trailer\n<< /Size ${xrefCount} /Root 1 0 R /Info ${infoObjNum} 0 R` +
    ` /ID [<${idHex}><${idHex}>] >>\nstartxref\n${xrefStart}\n%%EOF\n`;
  parts.push(Buffer.from(trailer, "latin1"));

  const finalBuf = Buffer.concat(parts);
  return new Uint8Array(finalBuf.buffer, finalBuf.byteOffset, finalBuf.byteLength);
}