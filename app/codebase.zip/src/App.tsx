import React, { useState } from 'react'
import type { Knife, ProvenanceEntry, SharpeningSession } from './types'

// ─── Constants ───────────────────────────────────────────────────────────────

const STORAGE_KEY = 'knifeCollection'

// ─── Utility helpers ─────────────────────────────────────────────────────────

function generateId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`
}

function loadCollection(): Knife[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

function saveCollection(knives: Knife[]): void {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(knives))
}

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => resolve((e.target as FileReader).result as string)
    reader.onerror = (e) => reject(e)
    reader.readAsDataURL(file)
  })
}

// ─── Types ───────────────────────────────────────────────────────────────────

type AppView = 'collection' | 'detail' | 'print'

// ─── KnifeRow ────────────────────────────────────────────────────────────────

interface KnifeRowProps {
  knife: Knife
  onViewDetails: () => void
}

function KnifeRow({ knife, onViewDetails }: KnifeRowProps) {
  return (
    <div
      style={{
        border: '1px solid #c8b89a',
        borderRadius: '6px',
        padding: '14px 18px',
        marginBottom: '12px',
        background: '#fff',
      }}
    >
      <div style={{ flex: 1 }}>
        <img
          src={knife.photoDataUrl}
          alt={`${knife.maker} ${knife.pattern}`}
          style={{
            width: '80px',
            height: '80px',
            objectFit: 'cover',
            borderRadius: '4px',
            display: 'block',
            marginBottom: '8px',
          }}
        />
        <div style={{ fontWeight: 'bold', fontSize: '1.05rem', marginBottom: '4px' }}>
          {knife.maker} — {knife.pattern}
        </div>
        <div style={{ fontSize: '0.9rem', color: '#555', marginBottom: '2px' }}>
          Edge Geometry: {knife.edgeGeometry}
        </div>
        <div style={{ fontSize: '0.9rem', color: '#555', marginBottom: '8px' }}>
          Scale Material: {knife.scaleMaterial}
        </div>
        <button
          type="button"
          onClick={onViewDetails}
          style={{
            padding: '6px 14px',
            background: '#7a5c2e',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          View Details
        </button>
      </div>
    </div>
  )
}

// ─── CollectionView ───────────────────────────────────────────────────────────

interface CollectionViewProps {
  knives: Knife[]
  onAddKnife: () => void
  onViewDetails: (id: string) => void
}

function CollectionView({ knives, onAddKnife, onViewDetails }: CollectionViewProps) {
  return (
    <div>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '16px',
        }}
      >
        <h2 style={{ margin: 0 }}>Collection ({knives.length} pieces)</h2>
        <button
          type="button"
          onClick={onAddKnife}
          style={{
            padding: '8px 18px',
            background: '#4a7c4e',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontWeight: 'bold',
          }}
        >
          Add Knife
        </button>
      </div>
      {knives.length === 0 && (
        <p style={{ color: '#888', fontStyle: 'italic' }}>
          No knives in the collection yet. Click &ldquo;Add Knife&rdquo; to get started.
        </p>
      )}
      {knives.map((knife) => (
        <KnifeRow
          key={knife.id}
          knife={knife}
          onViewDetails={() => onViewDetails(knife.id)}
        />
      ))}
    </div>
  )
}

// ─── KnifeEntryForm ───────────────────────────────────────────────────────────

interface KnifeEntryFormData {
  maker: string
  pattern: string
  edgeGeometry: string
  scaleMaterial: string
  owner: string
  acquiredOn: string
  note: string
  photoFile: File | null
}

interface KnifeEntryFormProps {
  onSubmit: (data: KnifeEntryFormData) => Promise<void>
  onCancel: () => void
}

function KnifeEntryForm({ onSubmit, onCancel }: KnifeEntryFormProps) {
  const [maker, setMaker] = useState('')
  const [pattern, setPattern] = useState('')
  const [edgeGeometry, setEdgeGeometry] = useState('')
  const [scaleMaterial, setScaleMaterial] = useState('')
  const [owner, setOwner] = useState('')
  const [acquiredOn, setAcquiredOn] = useState('')
  const [note, setNote] = useState('')
  const [photoFile, setPhotoFile] = useState<File | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    await onSubmit({ maker, pattern, edgeGeometry, scaleMaterial, owner, acquiredOn, note, photoFile })
    setSubmitting(false)
  }

  const inputStyle: React.CSSProperties = {
    display: 'block',
    width: '100%',
    padding: '7px 10px',
    border: '1px solid #c8b89a',
    borderRadius: '4px',
    marginTop: '3px',
    fontSize: '0.95rem',
  }
  const labelStyle: React.CSSProperties = {
    display: 'block',
    fontWeight: 'bold',
    fontSize: '0.9rem',
    marginBottom: '10px',
  }

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        background: '#f5f0e8',
        border: '1px solid #c8b89a',
        borderRadius: '8px',
        padding: '20px',
        marginTop: '16px',
      }}
    >
      <h3 style={{ marginTop: 0 }}>New Knife Entry</h3>

      <label style={labelStyle} htmlFor="maker">
        Maker
        <input
          id="maker"
          name="maker"
          type="text"
          value={maker}
          onChange={(e) => setMaker(e.target.value)}
          style={inputStyle}
          placeholder="e.g. Case, Buck, Custom Maker"
        />
      </label>

      <label style={labelStyle} htmlFor="pattern">
        Pattern
        <input
          id="pattern"
          name="pattern"
          type="text"
          value={pattern}
          onChange={(e) => setPattern(e.target.value)}
          style={inputStyle}
          placeholder="e.g. Trapper, 110 Folding Hunter"
        />
      </label>

      <label style={labelStyle} htmlFor="edgeGeometry">
        Edge Geometry
        <input
          id="edgeGeometry"
          name="edgeGeometry"
          type="text"
          value={edgeGeometry}
          onChange={(e) => setEdgeGeometry(e.target.value)}
          style={inputStyle}
          placeholder="e.g. Hollow grind, Flat Scandi"
          aria-label="Edge Geometry"
        />
      </label>

      <label style={labelStyle} htmlFor="scaleMaterial">
        Scale Material
        <input
          id="scaleMaterial"
          name="scaleMaterial"
          type="text"
          value={scaleMaterial}
          onChange={(e) => setScaleMaterial(e.target.value)}
          style={inputStyle}
          placeholder="e.g. Stag, Bone, Synthetic"
          aria-label="Scale Material"
        />
      </label>

      <h4 style={{ margin: '16px 0 8px' }}>First Provenance Entry</h4>

      <label style={labelStyle} htmlFor="owner">
        Owner
        <input
          id="owner"
          name="owner"
          type="text"
          value={owner}
          onChange={(e) => setOwner(e.target.value)}
          style={inputStyle}
          placeholder="First owner name"
        />
      </label>

      <label style={labelStyle} htmlFor="acquiredOn">
        Acquired On
        <input
          id="acquiredOn"
          name="acquiredOn"
          type="text"
          value={acquiredOn}
          onChange={(e) => setAcquiredOn(e.target.value)}
          style={inputStyle}
          placeholder="YYYY-MM-DD"
          aria-label="Acquired On"
        />
      </label>

      <label style={labelStyle} htmlFor="note">
        Note
        <input
          id="note"
          name="note"
          type="text"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          style={inputStyle}
          placeholder="Provenance note"
        />
      </label>

      <label style={labelStyle} htmlFor="photo">
        Photo
        <input
          id="photo"
          name="photo"
          type="file"
          accept="image/*"
          onChange={(e) => setPhotoFile(e.target.files?.[0] ?? null)}
          style={{ marginTop: '3px', display: 'block' }}
        />
      </label>

      <div style={{ marginTop: '16px', display: 'flex', gap: '10px' }}>
        <button
          type="submit"
          disabled={submitting}
          style={{
            padding: '8px 20px',
            background: '#4a7c4e',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontWeight: 'bold',
          }}
        >
          Save Knife
        </button>
        <button
          type="button"
          onClick={onCancel}
          style={{
            padding: '8px 20px',
            background: '#888',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Cancel
        </button>
      </div>
    </form>
  )
}

// ─── ProvenanceEntryForm ──────────────────────────────────────────────────────

interface ProvenanceEntryFormProps {
  onSubmit: (entry: ProvenanceEntry) => void
  onCancel: () => void
}

function ProvenanceEntryForm({ onSubmit, onCancel }: ProvenanceEntryFormProps) {
  const [owner, setOwner] = useState('')
  const [acquiredOn, setAcquiredOn] = useState('')
  const [note, setNote] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({ owner, acquiredOn, note })
  }

  const inputStyle: React.CSSProperties = {
    display: 'block',
    width: '100%',
    padding: '6px 10px',
    border: '1px solid #c8b89a',
    borderRadius: '4px',
    marginTop: '3px',
    fontSize: '0.9rem',
  }

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        background: '#fdf6ec',
        border: '1px solid #c8b89a',
        borderRadius: '6px',
        padding: '14px',
        marginTop: '8px',
      }}
    >
      <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 'bold' }} htmlFor="prov-owner">
        Owner
        <input
          id="prov-owner"
          name="owner"
          type="text"
          value={owner}
          onChange={(e) => setOwner(e.target.value)}
          style={inputStyle}
          placeholder="New owner name"
        />
      </label>

      <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 'bold' }} htmlFor="prov-acquiredOn">
        Acquired On
        <input
          id="prov-acquiredOn"
          name="acquiredOn"
          type="text"
          value={acquiredOn}
          onChange={(e) => setAcquiredOn(e.target.value)}
          style={inputStyle}
          placeholder="YYYY-MM-DD"
          aria-label="Acquired On"
        />
      </label>

      <label style={{ display: 'block', marginBottom: '10px', fontSize: '0.9rem', fontWeight: 'bold' }} htmlFor="prov-note">
        Note
        <input
          id="prov-note"
          name="note"
          type="text"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          style={inputStyle}
          placeholder="Provenance note"
        />
      </label>

      <div style={{ display: 'flex', gap: '8px' }}>
        <button
          type="submit"
          style={{
            padding: '6px 16px',
            background: '#4a7c4e',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Save
        </button>
        <button
          type="button"
          onClick={onCancel}
          style={{
            padding: '6px 16px',
            background: '#888',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Cancel
        </button>
      </div>
    </form>
  )
}

// ─── SharpeningSessionForm ────────────────────────────────────────────────────

interface SharpeningSessionFormProps {
  onSubmit: (session: SharpeningSession) => void
  onCancel: () => void
}

function SharpeningSessionForm({ onSubmit, onCancel }: SharpeningSessionFormProps) {
  const [date, setDate] = useState('')
  const [angle, setAngle] = useState('')
  const [grits, setGrits] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const stoneGritProgression = grits
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0)
      .map((s) => Number(s))
      .filter((n) => !Number.isNaN(n))

    onSubmit({
      id: generateId(),
      date,
      angle: Number(angle),
      stoneGritProgression,
    })
  }

  const inputStyle: React.CSSProperties = {
    display: 'block',
    width: '100%',
    padding: '6px 10px',
    border: '1px solid #c8b89a',
    borderRadius: '4px',
    marginTop: '3px',
    fontSize: '0.9rem',
  }

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        background: '#fdf6ec',
        border: '1px solid #c8b89a',
        borderRadius: '6px',
        padding: '14px',
        marginTop: '8px',
      }}
    >
      <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 'bold' }} htmlFor="sess-date">
        Date
        <input
          id="sess-date"
          name="date"
          type="text"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          style={inputStyle}
          placeholder="YYYY-MM-DD"
          aria-label="Date"
        />
      </label>

      <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 'bold' }} htmlFor="sess-angle">
        Angle (degrees)
        <input
          id="sess-angle"
          name="angle"
          type="text"
          value={angle}
          onChange={(e) => setAngle(e.target.value)}
          style={inputStyle}
          placeholder="e.g. 20"
          aria-label="Angle"
        />
      </label>

      <label style={{ display: 'block', marginBottom: '10px', fontSize: '0.9rem', fontWeight: 'bold' }} htmlFor="sess-grit">
        Stone Grit Progression (comma-separated, coarsest first)
        <input
          id="sess-grit"
          name="stoneGritProgression"
          type="text"
          value={grits}
          onChange={(e) => setGrits(e.target.value)}
          style={inputStyle}
          placeholder="e.g. 220, 1000, 4000"
          aria-label="Stone Grit Progression"
        />
      </label>

      <div style={{ display: 'flex', gap: '8px' }}>
        <button
          type="submit"
          style={{
            padding: '6px 16px',
            background: '#4a7c4e',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Save
        </button>
        <button
          type="button"
          onClick={onCancel}
          style={{
            padding: '6px 16px',
            background: '#888',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Cancel
        </button>
      </div>
    </form>
  )
}

// ─── KnifeDetailView ──────────────────────────────────────────────────────────

interface KnifeDetailViewProps {
  knife: Knife
  onAddProvenance: (entry: ProvenanceEntry) => void
  onAddSession: (session: SharpeningSession) => void
  onBack: () => void
}

function KnifeDetailView({ knife, onAddProvenance, onAddSession, onBack }: KnifeDetailViewProps) {
  const [showProvForm, setShowProvForm] = useState(false)
  const [showSessionForm, setShowSessionForm] = useState(false)

  const handleAddProvenance = (entry: ProvenanceEntry) => {
    onAddProvenance(entry)
    setShowProvForm(false)
  }

  const handleAddSession = (session: SharpeningSession) => {
    onAddSession(session)
    setShowSessionForm(false)
  }

  const sectionStyle: React.CSSProperties = {
    borderTop: '1px solid #e0d5c5',
    paddingTop: '14px',
    marginTop: '16px',
  }

  return (
    <div>
      <button
        type="button"
        onClick={onBack}
        style={{
          padding: '6px 14px',
          background: 'transparent',
          border: '1px solid #7a5c2e',
          borderRadius: '4px',
          cursor: 'pointer',
          color: '#7a5c2e',
          marginBottom: '16px',
        }}
      >
        ← Back to Collection
      </button>

      <h2 style={{ margin: '0 0 4px' }}>
        {knife.maker} — {knife.pattern}
      </h2>

      <img
        src={knife.photoDataUrl}
        alt={`${knife.maker} ${knife.pattern}`}
        style={{
          maxWidth: '220px',
          maxHeight: '220px',
          objectFit: 'cover',
          borderRadius: '6px',
          margin: '12px 0',
          display: 'block',
        }}
      />

      <div style={{ marginBottom: '6px' }}>
        <strong>Edge Geometry:</strong> {knife.edgeGeometry}
      </div>
      <div style={{ marginBottom: '6px' }}>
        <strong>Scale Material:</strong> {knife.scaleMaterial}
      </div>

      {/* Provenance Chain */}
      <div style={sectionStyle}>
        <h3 style={{ margin: '0 0 10px' }}>Provenance Chain</h3>
        {knife.provenanceChain.length === 0 && (
          <p style={{ color: '#888', fontStyle: 'italic' }}>No provenance entries recorded.</p>
        )}
        {[...knife.provenanceChain].sort((a, b) => a.acquiredOn.localeCompare(b.acquiredOn)).map((entry, idx) => (
          <div
            key={idx}
            style={{
              border: '1px solid #e0d5c5',
              borderRadius: '4px',
              padding: '10px 14px',
              marginBottom: '8px',
              background: '#fdf8f2',
            }}
          >
            <div><strong>Owner:</strong> {entry.owner}</div>
            <div><strong>Acquired On:</strong> {entry.acquiredOn}</div>
            <div><strong>Note:</strong> {entry.note}</div>
          </div>
        ))}
        <button
          type="button"
          onClick={() => setShowProvForm(true)}
          style={{
            padding: '7px 16px',
            background: '#7a5c2e',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            marginTop: '4px',
          }}
        >
          Add Provenance Entry
        </button>
        {showProvForm && (
          <ProvenanceEntryForm
            onSubmit={handleAddProvenance}
            onCancel={() => setShowProvForm(false)}
          />
        )}
      </div>

      {/* Sharpening Sessions */}
      <div style={sectionStyle}>
        <h3 style={{ margin: '0 0 10px' }}>Sharpening Sessions</h3>
        {knife.sharpeningSessions.length === 0 && (
          <p style={{ color: '#888', fontStyle: 'italic' }}>No sharpening sessions recorded.</p>
        )}
        {[...knife.sharpeningSessions].sort((a, b) => a.date.localeCompare(b.date)).map((session) => (
          <div
            key={session.id}
            style={{
              border: '1px solid #e0d5c5',
              borderRadius: '4px',
              padding: '10px 14px',
              marginBottom: '8px',
              background: '#fdf8f2',
            }}
          >
            <div><strong>Date:</strong> {session.date}</div>
            <div><strong>Angle:</strong> {session.angle}°</div>
            <div>
              <strong>Stone Grit Progression:</strong>{' '}
              {session.stoneGritProgression.join(' → ')}
            </div>
          </div>
        ))}
        <button
          type="button"
          onClick={() => setShowSessionForm(true)}
          style={{
            padding: '7px 16px',
            background: '#7a5c2e',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            marginTop: '4px',
          }}
        >
          Add Sharpening Session
        </button>
        {showSessionForm && (
          <SharpeningSessionForm
            onSubmit={handleAddSession}
            onCancel={() => setShowSessionForm(false)}
          />
        )}
      </div>
    </div>
  )
}

// ─── PrintCardsView ───────────────────────────────────────────────────────────

interface PrintCardsViewProps {
  knives: Knife[]
}

function PrintCardsView({ knives }: PrintCardsViewProps) {
  const handlePrint = () => window.print()

  return (
    <div>
      <div className="no-print" style={{ marginBottom: '20px' }}>
        <h2 style={{ margin: '0 0 12px' }}>Display Cards for Show Table</h2>
        <button
          type="button"
          onClick={handlePrint}
          style={{
            padding: '10px 24px',
            background: '#7a5c2e',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontWeight: 'bold',
            fontSize: '1rem',
          }}
        >
          Print Display Cards
        </button>
      </div>

      {knives.length === 0 && (
        <p style={{ color: '#888', fontStyle: 'italic' }}>
          No knives in collection to display.
        </p>
      )}

      {knives.map((knife) => {
        const lastOwner =
          knife.provenanceChain.length > 0
            ? knife.provenanceChain[knife.provenanceChain.length - 1].owner
            : ''

        return (
          <div
            key={knife.id}
            className="display-card"
            style={{
              border: '2px solid #7a5c2e',
              borderRadius: '8px',
              padding: '28px 32px',
              marginBottom: '24px',
              background: '#fff',
              pageBreakAfter: 'always',
              breakAfter: 'page',
              maxWidth: '600px',
            }}
          >
            <h2 style={{ margin: '0 0 6px', color: '#3a2a10' }}>{knife.maker}</h2>
            <p style={{ margin: '0 0 4px', fontSize: '1.05rem' }}>
              <strong>Pattern:</strong> {knife.pattern}
            </p>
            <p style={{ margin: '0 0 4px' }}>
              <strong>Edge Geometry:</strong> {knife.edgeGeometry}
            </p>
            <p style={{ margin: '0 0 4px' }}>
              <strong>Scale Material:</strong> {knife.scaleMaterial}
            </p>
            <p style={{ margin: '0 0 4px' }}>
              <strong>Current Owner:</strong> {lastOwner}
            </p>
            <img
              src={knife.photoDataUrl}
              alt={`${knife.maker} ${knife.pattern}`}
              style={{
                marginTop: '14px',
                maxWidth: '180px',
                maxHeight: '180px',
                objectFit: 'cover',
                borderRadius: '4px',
                display: 'block',
              }}
            />
          </div>
        )
      })}
    </div>
  )
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App(): JSX.Element {
  const [knives, setKnives] = useState<Knife[]>(() => loadCollection())
  const [appView, setAppView] = useState<AppView>('collection')
  const [selectedKnifeId, setSelectedKnifeId] = useState<string | null>(null)
  const [showAddKnifeForm, setShowAddKnifeForm] = useState(false)

  const updateKnives = (updated: Knife[]) => {
    setKnives(updated)
    saveCollection(updated)
  }

  const handleAddKnifeSubmit = async (formData: KnifeEntryFormData) => {
    let photoDataUrl = ''
    if (formData.photoFile) {
      photoDataUrl = await readFileAsDataURL(formData.photoFile)
    }
    const newKnife: Knife = {
      id: generateId(),
      maker: formData.maker,
      pattern: formData.pattern,
      edgeGeometry: formData.edgeGeometry,
      scaleMaterial: formData.scaleMaterial,
      photoDataUrl,
      provenanceChain: [
        {
          owner: formData.owner,
          acquiredOn: formData.acquiredOn,
          note: formData.note,
        },
      ],
      sharpeningSessions: [],
    }
    updateKnives([...knives, newKnife])
    setShowAddKnifeForm(false)
  }

  const handleAddProvenance = (knifeId: string, entry: ProvenanceEntry) => {
    setKnives((prev) => {
      const updated = prev.map((k) =>
        k.id === knifeId
          ? { ...k, provenanceChain: [...k.provenanceChain, entry].sort((a, b) => a.acquiredOn.localeCompare(b.acquiredOn)) }
          : k,
      )
      saveCollection(updated)
      return updated
    })
  }

  const handleAddSession = (knifeId: string, session: SharpeningSession) => {
    setKnives((prev) => {
      const updated = prev.map((k) =>
        k.id === knifeId
          ? { ...k, sharpeningSessions: [...k.sharpeningSessions, session].sort((a, b) => a.date.localeCompare(b.date)) }
          : k,
      )
      saveCollection(updated)
      return updated
    })
  }

  const openDetail = (knifeId: string) => {
    setSelectedKnifeId(knifeId)
    setAppView('detail')
    setShowAddKnifeForm(false)
  }

  const selectedKnife = knives.find((k) => k.id === selectedKnifeId) ?? null

  const navButtonStyle = (active: boolean): React.CSSProperties => ({
    padding: '8px 18px',
    background: active ? '#7a5c2e' : 'transparent',
    color: active ? '#fff' : '#7a5c2e',
    border: '1px solid #7a5c2e',
    borderRadius: '4px',
    cursor: 'pointer',
    fontWeight: active ? 'bold' : 'normal',
    marginRight: '8px',
  })

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      {/* Header */}
      <header
        className="no-print"
        style={{
          borderBottom: '2px solid #c8b89a',
          paddingBottom: '14px',
          marginBottom: '20px',
        }}
      >
        <h1 style={{ margin: '0 0 10px', color: '#3a2a10', fontSize: '1.6rem' }}>
          Knife Collection Manager
        </h1>
        <nav>
          <button
            type="button"
            onClick={() => {
              setAppView('collection')
              setShowAddKnifeForm(false)
            }}
            style={navButtonStyle(appView === 'collection' || appView === 'detail')}
          >
            Collection
          </button>
          <button
            type="button"
            onClick={() => setAppView('print')}
            style={navButtonStyle(appView === 'print')}
          >
            Print Cards
          </button>
        </nav>
      </header>

      {/* Main content */}
      <main>
        {/* Collection view */}
        {appView === 'collection' && (
          <div>
            <CollectionView
              knives={knives}
              onAddKnife={() => setShowAddKnifeForm(true)}
              onViewDetails={openDetail}
            />
            {showAddKnifeForm && (
              <KnifeEntryForm
                onSubmit={handleAddKnifeSubmit}
                onCancel={() => setShowAddKnifeForm(false)}
              />
            )}
          </div>
        )}

        {/* Detail view */}
        {appView === 'detail' && selectedKnife && (
          <KnifeDetailView
            knife={selectedKnife}
            onAddProvenance={(entry) => handleAddProvenance(selectedKnifeId!, entry)}
            onAddSession={(session) => handleAddSession(selectedKnifeId!, session)}
            onBack={() => setAppView('collection')}
          />
        )}

        {/* Print cards view */}
        {appView === 'print' && <PrintCardsView knives={knives} />}
      </main>
    </div>
  )
}
