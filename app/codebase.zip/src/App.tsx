import React, { useState } from 'react';
import { TripList } from './components/TripList';
import { OperatorDashboard } from './components/OperatorDashboard';
import './styles.css';

const OPERATOR_PASSWORD = 'operator123';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'trips' | 'dashboard'>('trips');
  const [operatorAuthenticated, setOperatorAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [showPasswordModal, setShowPasswordModal] = useState(false);

  const handleOperatorAccess = () => {
    if (operatorAuthenticated) {
      setCurrentView('dashboard');
    } else {
      setShowPasswordModal(true);
      setPasswordInput('');
      setPasswordError('');
    }
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === OPERATOR_PASSWORD) {
      setOperatorAuthenticated(true);
      setShowPasswordModal(false);
      setCurrentView('dashboard');
      setPasswordError('');
    } else {
      setPasswordError('Incorrect password. Please try again.');
    }
  };

  const handleOperatorLogout = () => {
    setOperatorAuthenticated(false);
    setCurrentView('trips');
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>Outdoor Adventure Trips</h1>
        <nav>
          <button
            className={currentView === 'trips' ? 'active' : ''}
            onClick={() => setCurrentView('trips')}
          >
            Browse Trips
          </button>
          <button
            className={currentView === 'dashboard' ? 'active' : ''}
            onClick={handleOperatorAccess}
          >
            Operator Dashboard
          </button>
          {operatorAuthenticated && (
            <button onClick={handleOperatorLogout} className="logout-btn">
              Logout
            </button>
          )}
        </nav>
      </header>

      {showPasswordModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>Operator Access</h2>
            <p>Enter the operator password to access the dashboard.</p>
            <form onSubmit={handlePasswordSubmit}>
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Enter password"
                autoFocus
              />
              {passwordError && <p className="error">{passwordError}</p>}
              <div className="modal-buttons">
                <button type="submit">Login</button>
                <button type="button" onClick={() => setShowPasswordModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <main className="app-main">
        {currentView === 'trips' && <TripList />}
        {currentView === 'dashboard' && operatorAuthenticated && <OperatorDashboard />}
      </main>
    </div>
  );
};

export default App;