import React, { useState } from 'react';
import { TripList } from './components/TripList';
import { OperatorDashboard } from './components/OperatorDashboard';
import { TripHistory } from './components/TripHistory';
import './styles.css';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'trips' | 'dashboard' | 'history'>('trips');

  return (
    <div className="app">
      <header className="app-header">
        <h1>Outdoor Adventure Trips</h1>
        <nav>
          <button 
            className={currentView === 'trips' ? 'active' : ''}
            onClick={() => setCurrentView('trips')}
          >
            Browse Trips
          </button>
          <button 
            className={currentView === 'dashboard' ? 'active' : ''}
            onClick={() => setCurrentView('dashboard')}
          >
            Operator Dashboard
          </button>
          <button 
            className={currentView === 'history' ? 'active' : ''}
            onClick={() => setCurrentView('history')}
          >
            Trip History
          </button>
        </nav>
      </header>
      <main className="app-main">
        {currentView === 'trips' && <TripList />}
        {currentView === 'dashboard' && <OperatorDashboard />}
        {currentView === 'history' && <TripHistory />}
      </main>
    </div>
  );
};

export default App;
