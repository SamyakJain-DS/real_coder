from contextlib import asynccontextmanager

from fastapi import FastAPI

from src.database import init_db
from src.routers import insurers, filings, hearings, form_filings, examinations, reconciliation, reports


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


application = FastAPI(title="DOI Health Insurance Rate Review Platform", lifespan=lifespan)

application.include_router(insurers.router)
application.include_router(filings.router)
application.include_router(hearings.router)
application.include_router(form_filings.router)
application.include_router(examinations.router)
application.include_router(reconciliation.router)
application.include_router(reports.router)
