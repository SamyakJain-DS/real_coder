"""
Neighborhood decline attributor for the housing code enforcement analytics pipeline.
Correlates ownership-pattern features with neighborhood decline across 15 neighborhoods.
"""
import numpy as np
import pandas as pd


def _compute_hhi(group_props: pd.DataFrame) -> float:
    """Compute Herfindahl-Hirschman Index for landlord property concentration.

    HHI = sum of squared ownership shares per landlord. For fractional shares
    that sum to 1, the raw HHI already lies in (0, 1].
    """
    total = len(group_props)
    if total == 0:
        return 0.0
    counts = group_props.groupby("landlord_id").size()
    shares = counts / total
    return float((shares ** 2).sum())


def attribute_neighborhood_decline(data: dict, landlord_classifications: pd.DataFrame) -> pd.DataFrame:
    """
    Attribute neighborhood housing decline to ownership-pattern features.

    Args:
        data: Dict returned by load_data.
        landlord_classifications: DataFrame returned by classify_landlord_compliance.

    Returns:
        DataFrame indexed by neighborhood_id (15 rows) with columns:
            decline_index, noncompliant_ownership_share, absentee_owner_ratio,
            portfolio_concentration_hhi, primary_decline_driver
    """
    properties = data["properties"]
    neighborhoods = data["neighborhoods"]

    # Merge classification status onto properties
    props_with_class = properties.merge(
        landlord_classifications[["compliance_classification"]].reset_index(),
        on="landlord_id",
        how="left",
    )

    # Compute decline_index: negative of linear regression slope of condition_score over year
    decline_indices = {}
    nbhd_ids = neighborhoods["neighborhood_id"].unique()

    for nid in nbhd_ids:
        nbhd_data = neighborhoods[neighborhoods["neighborhood_id"] == nid].sort_values("year")
        if len(nbhd_data) >= 2:
            years = nbhd_data["year"].values.astype(float)
            scores = nbhd_data["condition_score"].values.astype(float)
            slope = float(np.polyfit(years, scores, 1)[0])
            decline_indices[nid] = -slope
        else:
            decline_indices[nid] = 0.0

    # Compute per-neighborhood ownership pattern features
    records = []
    for nid in nbhd_ids:
        nbhd_props = props_with_class[props_with_class["neighborhood_id"] == nid]
        total = len(nbhd_props)

        if total == 0:
            noncompliant_share = 0.0
            absentee_ratio = 0.0
            hhi = 0.0
        else:
            noncompliant = nbhd_props[nbhd_props["compliance_classification"] == "systematic_noncompliant"]
            noncompliant_share = len(noncompliant) / total

            absentee = nbhd_props[nbhd_props["absentee_owner"] == True]
            absentee_ratio = len(absentee) / total

            hhi = _compute_hhi(nbhd_props)

        records.append({
            "neighborhood_id": nid,
            "decline_index": decline_indices[nid],
            "noncompliant_ownership_share": float(np.clip(noncompliant_share, 0.0, 1.0)),
            "absentee_owner_ratio": float(np.clip(absentee_ratio, 0.0, 1.0)),
            "portfolio_concentration_hhi": float(np.clip(hhi, 0.0, 1.0)),
        })

    df = pd.DataFrame(records).set_index("neighborhood_id")

    # Determine primary_decline_driver: highest absolute Pearson correlation with decline_index
    feature_map = {
        "noncompliant_ownership_share": "noncompliant_ownership",
        "absentee_owner_ratio": "absentee_ownership",
        "portfolio_concentration_hhi": "portfolio_concentration",
    }

    decline_vals = df["decline_index"].values
    correlations = {}
    for feature_col, driver_name in feature_map.items():
        feat_vals = df[feature_col].values
        if feat_vals.std() == 0 or decline_vals.std() == 0:
            corr = 0.0
        else:
            corr = float(np.corrcoef(decline_vals, feat_vals)[0, 1])
        correlations[driver_name] = abs(corr)

    # Alphabetical tie-breaking
    sorted_drivers = sorted(correlations.items(), key=lambda x: (-x[1], x[0]))
    primary_driver = sorted_drivers[0][0]

    df["primary_decline_driver"] = primary_driver

    return df[[
        "decline_index",
        "noncompliant_ownership_share",
        "absentee_owner_ratio",
        "portfolio_concentration_hhi",
        "primary_decline_driver",
    ]]
