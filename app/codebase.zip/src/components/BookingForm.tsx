import React, { useState, useEffect } from 'react';

interface Trip {
  id: number;
  activityType: string;
  date: string;
  guideName: string;
  difficulty: string;
  groupSizeLimit: number;
  price: number;
  description: string;
  status: 'upcoming' | 'completed';
}

interface Review {
  id: number;
  tripId: number;
  rating: number;
  reviewText: string;
}

interface BookingFormProps {
  tripId: number;
}

export const BookingForm: React.FC<BookingFormProps> = ({ tripId }) => {
  const [customerName, setCustomerName] = useState('');
  const [email, setEmail] = useState('');
  const [groupSize, setGroupSize] = useState(1);
  const [dietaryNotes, setDietaryNotes] = useState('');
  const [medicalNotes, setMedicalNotes] = useState('');
  const [waiverAcknowledged, setWaiverAcknowledged] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!customerName || !email || !groupSize) {
      setError('Please fill in all required fields');
      return;
    }

    if (!waiverAcknowledged) {
      setError('You must acknowledge the waiver to proceed');
      return;
    }

    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tripId,
          customerName,
          email,
          groupSize,
          dietaryNotes: dietaryNotes || undefined,
          medicalNotes: medicalNotes || undefined,
          waiverAcknowledged
        })
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Booking failed');
        return;
      }

      setSuccess('Booking submitted successfully!');
      setCustomerName('');
      setEmail('');
      setGroupSize(1);
      setDietaryNotes('');
      setMedicalNotes('');
      setWaiverAcknowledged(false);
    } catch (err) {
      setError('Failed to submit booking');
    }
  };

  return (
    <div className="booking-form">
      <h3>Book This Trip</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Name *</label>
          <input
            type="text"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Email *</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Group Size *</label>
          <input
            type="number"
            min="1"
            value={groupSize}
            onChange={(e) => setGroupSize(parseInt(e.target.value))}
            required
          />
        </div>
        <div className="form-group">
          <label>Dietary Notes</label>
          <textarea
            value={dietaryNotes}
            onChange={(e) => setDietaryNotes(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>Medical Notes</label>
          <textarea
            value={medicalNotes}
            onChange={(e) => setMedicalNotes(e.target.value)}
          />
        </div>
        <div className="form-group checkbox">
          <label>
            <input
              type="checkbox"
              checked={waiverAcknowledged}
              onChange={(e) => setWaiverAcknowledged(e.target.checked)}
            />
            I acknowledge the waiver and accept the terms *
          </label>
        </div>
        {error && <div className="error">{error}</div>}
        {success && <div className="success">{success}</div>}
        <button type="submit">Submit Booking</button>
      </form>
    </div>
  );
};
