import React, { useState, useEffect } from 'react';
import { TripHistory } from './TripHistory';

interface Booking {
  id: number;
  tripId: number;
  customerName: string;
  email: string;
  groupSize: number;
  dietaryNotes: string | null;
  medicalNotes: string | null;
}

export const OperatorDashboard: React.FC = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [errors, setErrors] = useState<{ [id: number]: string }>({});

  useEffect(() => {
    fetchPendingBookings();
  }, []);

  const fetchPendingBookings = async () => {
    try {
      const response = await fetch('/api/bookings/pending');
      const data = await response.json();
      setBookings(data);
    } catch (error) {
      console.error('Failed to fetch bookings:', error);
    }
  };

  const confirmBooking = async (bookingId: number) => {
    setErrors(prev => ({ ...prev, [bookingId]: '' }));
    try {
      const response = await fetch(`/api/bookings/${bookingId}/confirm`, {
        method: 'PUT'
      });

      const data = await response.json();

      if (!response.ok) {
        setErrors(prev => ({ ...prev, [bookingId]: data.error || 'Failed to confirm booking' }));
        return;
      }

      setBookings(bookings.filter(b => b.id !== bookingId));
    } catch (error) {
      setErrors(prev => ({ ...prev, [bookingId]: 'Failed to confirm booking' }));
    }
  };

  return (
    <div className="operator-dashboard">
      <h2>Operator Dashboard</h2>
      <h3>Pending Bookings</h3>
      {bookings.length === 0 ? (
        <p>No pending bookings</p>
      ) : (
        <div className="bookings-list">
          {bookings.map(booking => (
            <div key={booking.id} className="booking-card">
              <p><strong>Customer:</strong> {booking.customerName}</p>
              <p><strong>Email:</strong> {booking.email}</p>
              <p><strong>Group Size:</strong> {booking.groupSize}</p>
              <p><strong>Trip ID:</strong> {booking.tripId}</p>
              {booking.dietaryNotes && (
                <p><strong>Dietary Notes:</strong> {booking.dietaryNotes}</p>
              )}
              {booking.medicalNotes && (
                <p><strong>Medical Notes:</strong> {booking.medicalNotes}</p>
              )}
              {errors[booking.id] && (
                <div className="error">{errors[booking.id]}</div>
              )}
              <button onClick={() => confirmBooking(booking.id)}>
                Confirm Booking
              </button>
            </div>
          ))}
        </div>
      )}

      <TripHistory />
    </div>
  );
};