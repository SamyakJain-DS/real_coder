import React, { useState, useEffect } from 'react';
import { BookingForm } from './BookingForm';
import { ReviewForm } from './ReviewForm';

interface Trip {
  id: number;
  activityType: string;
  date: string;
  guideName: string;
  difficulty: string;
  groupSizeLimit: number;
  price: number;
  description: string;
  status: 'upcoming' | 'completed';
}

interface Review {
  id: number;
  tripId: number;
  rating: number;
  reviewText: string;
}

export const TripList: React.FC = () => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [reviews, setReviews] = useState<{ [tripId: number]: Review[] }>({});
  const [selectedTripForBooking, setSelectedTripForBooking] = useState<number | null>(null);
  const [selectedTripForReview, setSelectedTripForReview] = useState<number | null>(null);

  useEffect(() => {
    fetchTrips();
  }, []);

  const fetchTrips = async () => {
    try {
      const response = await fetch('/api/trips');
      const data = await response.json();
      setTrips(data);

      const completedTrips = data.filter((t: Trip) => t.status === 'completed');
      for (const trip of completedTrips) {
        fetchReviews(trip.id);
      }
    } catch (error) {
      console.error('Failed to fetch trips:', error);
    }
  };

  const fetchReviews = async (tripId: number) => {
    try {
      const response = await fetch(`/api/reviews?tripId=${tripId}`);
      const data = await response.json();
      setReviews(prev => ({ ...prev, [tripId]: data }));
    } catch (error) {
      console.error('Failed to fetch reviews:', error);
    }
  };

  return (
    <div className="trip-list">
      <h2>Available Trips</h2>
      {trips.map(trip => (
        <div key={trip.id} className={`trip-card ${trip.status}`}>
          <div className="trip-header">
            <h3>{trip.activityType}</h3>
            <span className={`status-badge ${trip.status}`}>
              {trip.status === 'upcoming' ? 'Upcoming' : 'Completed'}
            </span>
          </div>
          <div className="trip-details">
            <p><strong>Date:</strong> {trip.date}</p>
            <p><strong>Guide:</strong> {trip.guideName}</p>
            <p><strong>Difficulty:</strong> {trip.difficulty}</p>
            <p><strong>Group Size Limit:</strong> {trip.groupSizeLimit}</p>
            <p><strong>Price:</strong> ${trip.price.toFixed(2)}</p>
            <p className="description">{trip.description}</p>
          </div>

          {trip.status === 'upcoming' && (
            <div className="trip-actions">
              <button onClick={() => setSelectedTripForBooking(
                selectedTripForBooking === trip.id ? null : trip.id
              )}>
                Book This Trip
              </button>
              {selectedTripForBooking === trip.id && (
                <BookingForm tripId={trip.id} />
              )}
            </div>
          )}

          {trip.status === 'completed' && (
            <div className="trip-reviews">
              <h4>Reviews</h4>
              {reviews[trip.id] && reviews[trip.id].length > 0 ? (
                reviews[trip.id].map(review => (
                  <div key={review.id} className="review">
                    <div className="rating">Rating: {review.rating}/5</div>
                    <p>{review.reviewText}</p>
                  </div>
                ))
              ) : (
                <p className="no-reviews">No reviews yet</p>
              )}
              <button onClick={() => setSelectedTripForReview(
                selectedTripForReview === trip.id ? null : trip.id
              )}>
                Write a Review
              </button>
              {selectedTripForReview === trip.id && (
                <ReviewForm tripId={trip.id} />
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};