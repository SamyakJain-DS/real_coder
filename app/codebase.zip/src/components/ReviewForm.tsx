import React, { useState } from 'react';

interface ReviewFormProps {
  tripId: number;
}

export const ReviewForm: React.FC<ReviewFormProps> = ({ tripId }) => {
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email || !reviewText) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      const response = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tripId, rating, reviewText, email })
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Review submission failed');
        return;
      }

      setSuccess('Review submitted successfully!');
      setRating(5);
      setReviewText('');
      setEmail('');

      setTimeout(() => window.location.reload(), 1000);
    } catch (err) {
      setError('Failed to submit review');
    }
  };

  return (
    <div className="review-form">
      <h3>Leave a Review</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Email *</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Must match your booking email"
            required
          />
        </div>
        <div className="form-group">
          <label>Rating</label>
          <select value={rating} onChange={(e) => setRating(parseInt(e.target.value))}>
            <option value="5">5 - Excellent</option>
            <option value="4">4 - Good</option>
            <option value="3">3 - Average</option>
            <option value="2">2 - Poor</option>
            <option value="1">1 - Terrible</option>
          </select>
        </div>
        <div className="form-group">
          <label>Review *</label>
          <textarea
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            placeholder="Share your experience..."
            rows={4}
            required
          />
        </div>
        {error && <div className="error">{error}</div>}
        {success && <div className="success">{success}</div>}
        <button type="submit">Submit Review</button>
      </form>
    </div>
  );
};