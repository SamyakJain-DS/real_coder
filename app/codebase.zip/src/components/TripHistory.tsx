import React, { useState, useEffect } from 'react';

interface AnalyticsData {
  activityType: string;
  attendance: number;
  revenue: number;
}

interface ConfirmedBooking {
  id: number;
  tripId: number;
  customerName: string;
  email: string;
  groupSize: number;
  dietaryNotes: string | null;
  medicalNotes: string | null;
}

export const TripHistory: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData[]>([]);
  const [confirmedBookings, setConfirmedBookings] = useState<ConfirmedBooking[]>([]);
  const [showBookings, setShowBookings] = useState(false);

  useEffect(() => {
    fetchAnalytics();
    fetchConfirmedBookings();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const response = await fetch('/api/analytics/trips');
      const data = await response.json();
      setAnalytics(data.analytics);
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    }
  };

  const fetchConfirmedBookings = async () => {
    try {
      const response = await fetch('/api/bookings/confirmed');
      const data = await response.json();
      setConfirmedBookings(data);
    } catch (error) {
      console.error('Failed to fetch confirmed bookings:', error);
    }
  };

  return (
    <div className="trip-history">
      <h2>Trip History</h2>
      <h3>Analytics by Activity Type</h3>
      {analytics.length === 0 ? (
        <p>No completed trips yet</p>
      ) : (
        <table className="analytics-table">
          <thead>
            <tr>
              <th>Activity Type</th>
              <th>Total Attendance</th>
              <th>Total Revenue</th>
            </tr>
          </thead>
          <tbody>
            {analytics.map(item => (
              <tr key={item.activityType}>
                <td>{item.activityType}</td>
                <td>{item.attendance}</td>
                <td>${item.revenue.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div className="confirmed-bookings-section">
        <h3>
          Confirmed Bookings
          <button
            className="toggle-btn"
            onClick={() => setShowBookings(!showBookings)}
          >
            {showBookings ? 'Hide' : 'Show'}
          </button>
        </h3>
        {showBookings && (
          confirmedBookings.length === 0 ? (
            <p>No confirmed bookings</p>
          ) : (
            <table className="analytics-table">
              <thead>
                <tr>
                  <th>Booking ID</th>
                  <th>Trip ID</th>
                  <th>Customer</th>
                  <th>Email</th>
                  <th>Group Size</th>
                </tr>
              </thead>
              <tbody>
                {confirmedBookings.map(booking => (
                  <tr key={booking.id}>
                    <td>{booking.id}</td>
                    <td>{booking.tripId}</td>
                    <td>{booking.customerName}</td>
                    <td>{booking.email}</td>
                    <td>{booking.groupSize}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        )}
      </div>
    </div>
  );
};
