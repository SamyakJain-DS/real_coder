import os
import sqlite3

DATABASE_PATH = os.environ.get("DATABASE_PATH", "doi_platform.db")


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS insurers (
            insurer_id TEXT PRIMARY KEY,
            naic_code TEXT NOT NULL,
            company_name TEXT NOT NULL,
            company_type TEXT NOT NULL,
            state_license_status TEXT NOT NULL,
            domicile_state TEXT NOT NULL,
            admitted_date TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS rate_filings (
            filing_id TEXT PRIMARY KEY,
            insurer_id TEXT NOT NULL,
            serff_tracking_number TEXT NOT NULL UNIQUE,
            filing_type TEXT NOT NULL,
            product_type TEXT NOT NULL,
            effective_date TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'received',
            submission_date TEXT NOT NULL,
            requested_rate_change_pct REAL NOT NULL,
            aca_unreasonable_flag INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (insurer_id) REFERENCES insurers(insurer_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attachments (
            attachment_id TEXT PRIMARY KEY,
            filing_id TEXT NOT NULL,
            attachment_type TEXT NOT NULL,
            filename TEXT NOT NULL,
            uploaded_date TEXT NOT NULL,
            FOREIGN KEY (filing_id) REFERENCES rate_filings(filing_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS rate_reviews (
            review_id TEXT PRIMARY KEY,
            filing_id TEXT NOT NULL,
            projected_mlr REAL NOT NULL,
            target_mlr REAL NOT NULL,
            trend_factor_used REAL NOT NULL,
            admin_expense_ratio REAL NOT NULL,
            admin_expense_flag INTEGER NOT NULL,
            adequacy_result TEXT NOT NULL,
            review_date TEXT NOT NULL,
            FOREIGN KEY (filing_id) REFERENCES rate_filings(filing_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS public_comments (
            comment_id TEXT PRIMARY KEY,
            filing_id TEXT NOT NULL,
            commenter_name TEXT NOT NULL,
            commenter_email TEXT NOT NULL,
            comment_text TEXT NOT NULL,
            submitted_date TEXT NOT NULL,
            FOREIGN KEY (filing_id) REFERENCES rate_filings(filing_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS public_hearings (
            hearing_id TEXT PRIMARY KEY,
            filing_id TEXT NOT NULL,
            hearing_date TEXT NOT NULL,
            location TEXT NOT NULL,
            hearing_officer TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'scheduled',
            notice_published_date TEXT NOT NULL,
            FOREIGN KEY (filing_id) REFERENCES rate_filings(filing_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS form_filings (
            form_filing_id TEXT PRIMARY KEY,
            insurer_id TEXT NOT NULL,
            form_type TEXT NOT NULL,
            product_type TEXT NOT NULL,
            submission_date TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'received',
            mandated_benefits_checklist TEXT NOT NULL,
            FOREIGN KEY (insurer_id) REFERENCES insurers(insurer_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS market_conduct_exams (
            exam_id TEXT PRIMARY KEY,
            insurer_id TEXT NOT NULL,
            exam_type TEXT NOT NULL,
            scheduled_date TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'scheduled',
            claim_handling_score REAL,
            network_adequacy_score REAL,
            FOREIGN KEY (insurer_id) REFERENCES insurers(insurer_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS risk_adjustment_reconciliation (
            reconciliation_id TEXT PRIMARY KEY,
            insurer_id TEXT NOT NULL,
            plan_year INTEGER NOT NULL,
            risk_adjustment_transfer_amount REAL NOT NULL,
            cciio_submission_status TEXT NOT NULL DEFAULT 'pending',
            submission_date TEXT,
            notes TEXT,
            FOREIGN KEY (insurer_id) REFERENCES insurers(insurer_id)
        )
    """)


    # Migration: add aca_unreasonable_flag to existing rate_filings tables that pre-date this column
    try:
        cursor.execute(
            "ALTER TABLE rate_filings ADD COLUMN aca_unreasonable_flag INTEGER NOT NULL DEFAULT 0"
        )
    except Exception:
        pass  # column already exists

    conn.commit()
    conn.close()
