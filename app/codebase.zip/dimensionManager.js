const INCHES_PER_CENTIMETER_RATIO = 2.54;

const VALID_UNITS = new Set(["inches", "centimeters"]);

export function convertUnit(value, fromUnit, toUnit) {
  if (!VALID_UNITS.has(fromUnit)) {
    throw new RangeError("Invalid unit");
  }
  if (!VALID_UNITS.has(toUnit)) {
    throw new RangeError("Invalid unit");
  }
  if (fromUnit === toUnit) {
    return value;
  }
  if (fromUnit === "inches" && toUnit === "centimeters") {
    return value * INCHES_PER_CENTIMETER_RATIO;
  }
  return value / INCHES_PER_CENTIMETER_RATIO;
}
