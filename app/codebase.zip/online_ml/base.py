from abc import ABC, abstractmethod

import numpy as np

from .schema import FeatureSchema


class BaseEstimator(ABC):
    def __init__(self, schema: FeatureSchema):
        self.schema = schema

    @abstractmethod
    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        ...

    @abstractmethod
    def predict(self, X: np.ndarray) -> np.ndarray:
        ...

    @abstractmethod
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        ...
