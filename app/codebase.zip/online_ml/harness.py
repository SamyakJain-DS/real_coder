from typing import Literal, Dict

import numpy as np

from .base import BaseEstimator
from .metrics import RollingMetrics


class ChampionChallenger:
    def __init__(
        self,
        champion: BaseEstimator,
        challenger: BaseEstimator,
        window_size: int,
        task: Literal["regression", "classification", "clustering", "anomaly"],
    ):
        self.champion = champion
        self.challenger = challenger
        self.window_size = window_size
        self.task = task
        self._champion_metrics = RollingMetrics(window_size=window_size, task=task)
        self._challenger_metrics = RollingMetrics(window_size=window_size, task=task)

    def feed(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X)
        y = np.asarray(y)
        champ_pred = self.champion.predict(X)
        chall_pred = self.challenger.predict(X)
        self._champion_metrics.update(y, champ_pred)
        self._challenger_metrics.update(y, chall_pred)
        self.champion.partial_fit(X, y)
        self.challenger.partial_fit(X, y)
        return None

    def get_comparison(self) -> Dict[str, Dict[str, float]]:
        return {
            "champion": self._champion_metrics.get_metrics(),
            "challenger": self._challenger_metrics.get_metrics(),
        }
