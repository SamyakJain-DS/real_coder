from collections import deque

import numpy as np
from scipy.optimize import minimize_scalar

from .base import BaseEstimator
from .schema import FeatureSchema


def _softmax(scores: np.ndarray) -> np.ndarray:
    s = scores - scores.max(axis=1, keepdims=True)
    e = np.exp(s)
    return e / e.sum(axis=1, keepdims=True)


class OnlineLogisticClassifier(BaseEstimator):
    def __init__(
        self,
        schema: FeatureSchema,
        n_classes: int,
        learning_rate: float = 0.01,
        calibration_window: int = 200,
    ):
        super().__init__(schema)
        self.n_classes = n_classes
        self.learning_rate = learning_rate
        self.calibration_window = calibration_window
        n = schema.n_features
        self.W = np.zeros((n_classes, n), dtype=np.float64)
        self.b = np.zeros(n_classes, dtype=np.float64)
        self.temperature = 1.0
        self._calib_buffer: deque = deque(maxlen=calibration_window)

    def _linear_scores(self, X: np.ndarray) -> np.ndarray:
        return X @ self.W.T + self.b

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        scores = self._linear_scores(X)
        t = self.temperature if self.temperature > 1e-6 else 1e-6
        return _softmax(scores / t)

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        return np.argmax(self._linear_scores(X), axis=1).astype(np.int64)

    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.int64)
        for i in range(X.shape[0]):
            xi = X[i]
            yi = int(y[i])
            logits = xi @ self.W.T + self.b
            self._calib_buffer.append((logits.copy(), yi))
            shifted = logits - logits.max()
            e = np.exp(shifted)
            probs = e / e.sum()
            target = np.zeros(self.n_classes, dtype=np.float64)
            target[yi] = 1.0
            error = probs - target
            self.W -= self.learning_rate * np.outer(error, xi)
            self.b -= self.learning_rate * error
        self._refit_temperature()
        return None

    def _refit_temperature(self) -> None:
        if len(self._calib_buffer) < 2:
            return
        logits_arr = np.array([item[0] for item in self._calib_buffer], dtype=np.float64)
        labels_arr = np.array([item[1] for item in self._calib_buffer], dtype=np.int64)
        n = labels_arr.shape[0]
        idx = np.arange(n)

        def nll(t: float) -> float:
            if t <= 0.0:
                return float("inf")
            scaled = logits_arr / t
            scaled = scaled - scaled.max(axis=1, keepdims=True)
            log_sum = np.log(np.exp(scaled).sum(axis=1))
            return float(-(scaled[idx, labels_arr] - log_sum).sum())

        try:
            res = minimize_scalar(nll, bounds=(0.05, 20.0), method="bounded")
            t_new = float(res.x)
            if np.isfinite(t_new) and t_new > 0.0:
                self.temperature = t_new
        except Exception:
            return


class OnlineNaiveBayes(BaseEstimator):
    def __init__(self, schema: FeatureSchema, n_classes: int):
        super().__init__(schema)
        self.n_classes = n_classes
        n = schema.n_features
        self.class_count = np.zeros(n_classes, dtype=np.float64)
        self.feature_sum = np.zeros((n_classes, n), dtype=np.float64)
        self._alpha = 1.0

    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.int64)
        Xp = np.abs(X)
        for i in range(X.shape[0]):
            c = int(y[i])
            self.class_count[c] += 1.0
            self.feature_sum[c] += Xp[i]
        return None

    def _log_score(self, X: np.ndarray) -> np.ndarray:
        Xp = np.abs(X)
        n_features = self.schema.n_features
        total = self.class_count.sum() + self._alpha * self.n_classes
        log_prior = np.log((self.class_count + self._alpha) / total)
        theta_num = self.feature_sum + self._alpha
        theta_den = theta_num.sum(axis=1, keepdims=True)
        log_theta = np.log(theta_num / theta_den)
        return Xp @ log_theta.T + log_prior

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        return _softmax(self._log_score(X))

    def predict(self, X: np.ndarray) -> np.ndarray:
        return np.argmax(self.predict_proba(X), axis=1).astype(np.int64)


class _TreeNode:
    """Binary decision tree node that grows incrementally.

    Each leaf accumulates per-class counts and a running mean per feature in
    the assigned subset. Once a leaf has seen enough samples it splits into
    two children on a randomly selected feature at the running-mean threshold.
    """

    def __init__(self, n_classes: int, depth: int, feature_subset: list):
        self.n_classes = n_classes
        self.depth = depth
        self.feature_subset = list(feature_subset)
        self.class_count = np.zeros(n_classes, dtype=np.float64)
        self.samples_seen = 0
        self.feature_mean = np.zeros(len(self.feature_subset), dtype=np.float64)
        self.is_leaf = True
        self.split_feature = -1
        self.split_threshold = 0.0
        self.left = None
        self.right = None

    def update(self, x: np.ndarray, c: int, max_depth: int, split_after: int, rng: np.random.Generator) -> None:
        self.class_count[c] += 1.0
        self.samples_seen += 1
        if not self.is_leaf:
            if x[self.split_feature] <= self.split_threshold:
                self.left.update(x, c, max_depth, split_after, rng)
            else:
                self.right.update(x, c, max_depth, split_after, rng)
            return
        for i, f in enumerate(self.feature_subset):
            delta = x[f] - self.feature_mean[i]
            self.feature_mean[i] += delta / self.samples_seen
        if self.depth < max_depth and self.samples_seen >= split_after and len(self.feature_subset) > 0:
            sub_pos = int(rng.integers(0, len(self.feature_subset)))
            self.split_feature = int(self.feature_subset[sub_pos])
            self.split_threshold = float(self.feature_mean[sub_pos])
            self.is_leaf = False
            self.left = _TreeNode(self.n_classes, self.depth + 1, self.feature_subset)
            self.right = _TreeNode(self.n_classes, self.depth + 1, self.feature_subset)

    def proba(self, x: np.ndarray) -> np.ndarray:
        if self.is_leaf:
            counts = self.class_count + 1.0
            return counts / counts.sum()
        target = self.left if x[self.split_feature] <= self.split_threshold else self.right
        if target.samples_seen == 0:
            counts = self.class_count + 1.0
            return counts / counts.sum()
        return target.proba(x)


class OnlineRandomForest(BaseEstimator):
    def __init__(self, schema: FeatureSchema, n_classes: int, n_trees: int = 10):
        super().__init__(schema)
        self.n_classes = n_classes
        self.n_trees = n_trees
        self._max_depth = 4
        self._split_after = 15
        n = schema.n_features
        seed_rng = np.random.default_rng(0)
        if n > 0:
            subset_size = max(1, min(int(np.ceil(np.sqrt(n))), n))
        else:
            subset_size = 0
        self.trees: list = []
        self.tree_rngs: list = []
        for t in range(n_trees):
            if n == 0:
                subset = []
            else:
                subset = list(int(v) for v in seed_rng.choice(n, size=subset_size, replace=False))
            self.trees.append(_TreeNode(n_classes, 0, subset))
            self.tree_rngs.append(np.random.default_rng(1000 + t))

    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.int64)
        for i in range(X.shape[0]):
            xi = X[i]
            ci = int(y[i])
            for t in range(self.n_trees):
                self.trees[t].update(xi, ci, self._max_depth, self._split_after, self.tree_rngs[t])
        return None

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        n = X.shape[0]
        total = np.zeros((n, self.n_classes), dtype=np.float64)
        for i in range(n):
            xi = X[i]
            row = np.zeros(self.n_classes, dtype=np.float64)
            for tree in self.trees:
                row += tree.proba(xi)
            total[i] = row
        return total / max(self.n_trees, 1)

    def predict(self, X: np.ndarray) -> np.ndarray:
        return np.argmax(self.predict_proba(X), axis=1).astype(np.int64)
