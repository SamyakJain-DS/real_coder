import numpy as np

from .base import BaseEstimator
from .schema import FeatureSchema


class OnlineLinearRegressor(BaseEstimator):
    def __init__(self, schema: FeatureSchema, learning_rate: float = 0.01):
        super().__init__(schema)
        self.learning_rate = learning_rate
        n = schema.n_features
        self.w = np.zeros(n, dtype=np.float64)
        self.b = 0.0
        self.grad_sq_sum = np.zeros(n, dtype=np.float64)
        self.bias_grad_sq_sum = 0.0
        self._resid_count = 0
        self._resid_mean = 0.0
        self._resid_M2 = 0.0
        self._eps = 1e-8

    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.float64)
        for i in range(X.shape[0]):
            xi = X[i]
            yi = y[i]
            pred = float(np.dot(self.w, xi) + self.b)
            err = pred - yi
            grad = err * xi
            bias_grad = err
            self.grad_sq_sum += grad * grad
            self.bias_grad_sq_sum += bias_grad * bias_grad
            step = self.learning_rate / (np.sqrt(self.grad_sq_sum) + self._eps)
            self.w -= step * grad
            self.b -= (self.learning_rate / (np.sqrt(self.bias_grad_sq_sum) + self._eps)) * bias_grad
            self._resid_count += 1
            delta = err - self._resid_mean
            self._resid_mean += delta / self._resid_count
            delta2 = err - self._resid_mean
            self._resid_M2 += delta * delta2
        return None

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        return (X @ self.w + self.b).astype(np.float64)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        if self._resid_count > 1:
            base_var = self._resid_M2 / self._resid_count
        else:
            base_var = 0.0
        if base_var < 0.0:
            base_var = 0.0
        # Per-feature weight uncertainty shrinks as gradient history accumulates
        weight_uncertainty = 1.0 / (1.0 + self.grad_sq_sum)
        per_sample_term = np.sum((X * X) * weight_uncertainty, axis=1)
        return base_var + per_sample_term


class _Stump:
    __slots__ = ("feature", "threshold", "left_value", "right_value")

    def __init__(self, feature: int, threshold: float, left_value: float, right_value: float):
        self.feature = feature
        self.threshold = threshold
        self.left_value = left_value
        self.right_value = right_value

    def predict(self, X: np.ndarray) -> np.ndarray:
        col = X[:, self.feature]
        out = np.where(col <= self.threshold, self.left_value, self.right_value)
        return out.astype(np.float64)


class OnlineGBTRegressor(BaseEstimator):
    def __init__(self, schema: FeatureSchema, n_estimators: int = 10, learning_rate: float = 0.1):
        super().__init__(schema)
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.trees: list = []
        self._rng = np.random.default_rng(0)
        self._resid_count = 0
        self._resid_mean = 0.0
        self._resid_M2 = 0.0

    def _fit_stump(self, X: np.ndarray, residuals: np.ndarray) -> _Stump:
        n_features = X.shape[1]
        feature = int(self._rng.integers(0, n_features))
        col = X[:, feature]
        threshold = float(np.median(col))
        left_mask = col <= threshold
        right_mask = ~left_mask
        if left_mask.any():
            left_val = float(residuals[left_mask].mean())
        else:
            left_val = 0.0
        if right_mask.any():
            right_val = float(residuals[right_mask].mean())
        else:
            right_val = 0.0
        return _Stump(feature, threshold, left_val, right_val)

    def _ensemble_predict(self, X: np.ndarray) -> np.ndarray:
        out = np.zeros(X.shape[0], dtype=np.float64)
        for tree in self.trees:
            out += self.learning_rate * tree.predict(X)
        return out

    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.float64)
        if X.shape[0] == 0:
            return None
        current_pred = self._ensemble_predict(X)
        residuals = y - current_pred
        new_tree = self._fit_stump(X, residuals)
        self.trees.append(new_tree)
        if len(self.trees) > self.n_estimators:
            self.trees.pop(0)
        # Track residual variance after tree update
        updated_pred = current_pred + self.learning_rate * new_tree.predict(X)
        new_residuals = y - updated_pred
        for r in new_residuals:
            self._resid_count += 1
            delta = r - self._resid_mean
            self._resid_mean += delta / self._resid_count
            delta2 = r - self._resid_mean
            self._resid_M2 += delta * delta2
        return None

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        return self._ensemble_predict(X)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        n = X.shape[0]
        if not self.trees:
            return np.zeros(n, dtype=np.float64)
        if self._resid_count > 1:
            base_var = self._resid_M2 / self._resid_count
        else:
            base_var = 0.0
        if base_var < 0.0:
            base_var = 0.0
        # Per-sample variance: disagreement across trees in the ensemble
        tree_preds = np.stack(
            [self.learning_rate * tree.predict(X) for tree in self.trees], axis=0
        )
        if tree_preds.shape[0] > 1:
            ensemble_var = tree_preds.var(axis=0)
        else:
            ensemble_var = np.zeros(n, dtype=np.float64)
        return base_var + ensemble_var
