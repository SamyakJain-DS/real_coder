from dataclasses import dataclass
from typing import Literal, Optional, List

import numpy as np
from scipy import stats

from .schema import FeatureSchema


@dataclass
class DriftAlert:
    alert_type: Literal["error", "feature"]
    feature_name: Optional[str]
    p_value: float


class DriftDetector:
    def __init__(self, schema: FeatureSchema, error_window: int, feature_window: int):
        self.schema = schema
        self.error_window = error_window
        self.feature_window = feature_window
        self._half_feat = max(1, feature_window // 2)
        self._half_err = max(1, error_window // 2)
        n = schema.n_features
        self._feat_ref: List[Optional[list]] = [None] * n
        self._feat_cur: List[list] = [[] for _ in range(n)]
        self._err_ref: Optional[list] = None
        self._err_cur: list = []
        self._alerts: List[DriftAlert] = []
        self._alpha = 0.05

    def _process_feature_value(self, j: int, v: float) -> None:
        cur = self._feat_cur[j]
        cur.append(v)
        if len(cur) >= self._half_feat:
            if self._feat_ref[j] is None:
                self._feat_ref[j] = list(cur)
                self._feat_cur[j] = []
            else:
                ref = self._feat_ref[j]
                try:
                    res = stats.ks_2samp(np.asarray(ref), np.asarray(cur))
                    p = float(res.pvalue)
                except Exception:
                    p = 1.0
                if p < self._alpha:
                    self._alerts.append(
                        DriftAlert(
                            alert_type="feature",
                            feature_name=self.schema.feature_names[j],
                            p_value=p,
                        )
                    )
                self._feat_ref[j] = list(cur)
                self._feat_cur[j] = []

    def _process_error_value(self, e: float) -> None:
        self._err_cur.append(e)
        if len(self._err_cur) >= self._half_err:
            if self._err_ref is None:
                self._err_ref = list(self._err_cur)
                self._err_cur = []
            else:
                ref = self._err_ref
                cur = self._err_cur
                try:
                    res = stats.ks_2samp(np.asarray(ref), np.asarray(cur))
                    p = float(res.pvalue)
                except Exception:
                    p = 1.0
                if p < self._alpha:
                    self._alerts.append(
                        DriftAlert(
                            alert_type="error",
                            feature_name=None,
                            p_value=p,
                        )
                    )
                self._err_ref = list(cur)
                self._err_cur = []

    def update(self, X: np.ndarray, errors: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        errors = np.asarray(errors, dtype=np.float64).reshape(-1)
        # Reset active alerts; get_alerts reflects drifts detected during this call only
        self._alerts = []
        n_samples = X.shape[0]
        n_features = self.schema.n_features
        for i in range(n_samples):
            for j in range(n_features):
                self._process_feature_value(j, float(X[i, j]))
        for i in range(errors.shape[0]):
            self._process_error_value(float(errors[i]))
        return None

    def get_alerts(self) -> List[DriftAlert]:
        return list(self._alerts)
