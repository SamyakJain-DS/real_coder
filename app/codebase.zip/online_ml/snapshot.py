import os
import pickle
from typing import Optional

from .base import BaseEstimator


class SnapshotManager:
    def __init__(self, directory: str, schedule_interval: int):
        self.directory = directory
        self.schedule_interval = schedule_interval
        os.makedirs(directory, exist_ok=True)

    def save(self, estimator: BaseEstimator, tag: str) -> str:
        path = os.path.abspath(os.path.join(self.directory, f"{tag}.pkl"))
        with open(path, "wb") as f:
            pickle.dump(estimator, f)
        return path

    def load(self, tag: str) -> BaseEstimator:
        path = os.path.abspath(os.path.join(self.directory, f"{tag}.pkl"))
        with open(path, "rb") as f:
            return pickle.load(f)

    def checkpoint(self, estimator: BaseEstimator, step: int) -> Optional[str]:
        if self.schedule_interval <= 0:
            return None
        if step % self.schedule_interval != 0:
            return None
        path = os.path.abspath(os.path.join(self.directory, f"checkpoint_{step}.pkl"))
        with open(path, "wb") as f:
            pickle.dump(estimator, f)
        return path
