from dataclasses import dataclass
from typing import Literal, List


@dataclass
class FeatureSpec:
    name: str
    dtype: Literal["numeric", "categorical"]


class FeatureSchema:
    def __init__(self, specs: List[FeatureSpec]):
        self._specs = list(specs)

    @property
    def n_features(self) -> int:
        return len(self._specs)

    @property
    def feature_names(self) -> List[str]:
        return [s.name for s in self._specs]
