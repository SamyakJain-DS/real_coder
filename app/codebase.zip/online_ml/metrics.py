from typing import Literal, Dict

import numpy as np


class RollingMetrics:
    def __init__(self, window_size: int, task: Literal["regression", "classification", "clustering", "anomaly"]):
        self.window_size = window_size
        self.task = task
        self._y_true = np.array([], dtype=np.float64)
        self._y_pred = np.array([], dtype=np.float64)

    def update(self, y_true: np.ndarray, y_pred: np.ndarray) -> None:
        y_true = np.asarray(y_true).astype(np.float64).reshape(-1)
        y_pred = np.asarray(y_pred).astype(np.float64).reshape(-1)
        self._y_true = np.concatenate([self._y_true, y_true])
        self._y_pred = np.concatenate([self._y_pred, y_pred])
        if self.window_size > 0 and len(self._y_true) > self.window_size:
            self._y_true = self._y_true[-self.window_size:]
            self._y_pred = self._y_pred[-self.window_size:]
        return None

    def get_metrics(self) -> Dict[str, float]:
        yt = self._y_true
        yp = self._y_pred
        if self.task == "regression":
            if yt.size == 0:
                return {"mse": 0.0, "mae": 0.0}
            err = yp - yt
            return {"mse": float(np.mean(err * err)), "mae": float(np.mean(np.abs(err)))}
        if self.task == "classification":
            if yt.size == 0:
                return {"accuracy": 0.0, "f1": 0.0}
            yt_i = yt.astype(np.int64)
            yp_i = yp.astype(np.int64)
            acc = float(np.mean(yt_i == yp_i))
            classes = np.unique(np.concatenate([yt_i, yp_i]))
            f1_vals = []
            for c in classes:
                tp = int(np.sum((yp_i == c) & (yt_i == c)))
                fp = int(np.sum((yp_i == c) & (yt_i != c)))
                fn = int(np.sum((yp_i != c) & (yt_i == c)))
                if tp + fp == 0 or tp + fn == 0:
                    f1_c = 0.0
                else:
                    prec = tp / (tp + fp)
                    rec = tp / (tp + fn)
                    f1_c = 0.0 if prec + rec == 0 else 2 * prec * rec / (prec + rec)
                f1_vals.append(f1_c)
            f1 = float(np.mean(f1_vals)) if f1_vals else 0.0
            return {"accuracy": acc, "f1": f1}
        if self.task == "clustering":
            if yp.size == 0:
                return {"label_entropy": 0.0}
            labels = yp.astype(np.int64)
            _, counts = np.unique(labels, return_counts=True)
            probs = counts / counts.sum()
            ent = float(-np.sum(probs * np.log(probs + 1e-12)))
            return {"label_entropy": ent}
        if self.task == "anomaly":
            if yt.size == 0:
                return {"precision": 0.0, "recall": 0.0}
            yt_i = yt.astype(np.int64)
            yp_i = yp.astype(np.int64)
            tp = int(np.sum((yp_i == 1) & (yt_i == 1)))
            fp = int(np.sum((yp_i == 1) & (yt_i == 0)))
            fn = int(np.sum((yp_i == 0) & (yt_i == 1)))
            precision = float(tp / (tp + fp)) if (tp + fp) > 0 else 0.0
            recall = float(tp / (tp + fn)) if (tp + fn) > 0 else 0.0
            return {"precision": precision, "recall": recall}
        return {}
