import collections

import numpy as np

from .base import BaseEstimator
from .schema import FeatureSchema


class _HSTree:
    def __init__(self, n_features: int, depth: int, low: np.ndarray, high: np.ndarray, rng: np.random.Generator):
        self.depth = depth
        self.n_features = n_features
        n_internal = (1 << depth) - 1
        self.split_feature = np.zeros(n_internal, dtype=np.int64)
        self.split_threshold = np.zeros(n_internal, dtype=np.float64)
        for node in range(n_internal):
            f = int(rng.integers(0, max(n_features, 1)))
            self.split_feature[node] = f
            self.split_threshold[node] = float(rng.uniform(low[f], high[f]))
        self.leaf_mass = np.zeros(1 << depth, dtype=np.float64)

    def _leaf(self, x: np.ndarray) -> int:
        node = 0
        n_internal = (1 << self.depth) - 1
        for _ in range(self.depth):
            f = self.split_feature[node]
            t = self.split_threshold[node]
            if x[f] < t:
                node = 2 * node + 1
            else:
                node = 2 * node + 2
        return node - n_internal

    def update(self, X: np.ndarray) -> None:
        for i in range(X.shape[0]):
            self.leaf_mass[self._leaf(X[i])] += 1.0

    def mass(self, x: np.ndarray) -> float:
        return float(self.leaf_mass[self._leaf(x)])


class HalfSpaceTrees(BaseEstimator):
    def __init__(self, schema: FeatureSchema, n_trees: int, window_size: int):
        super().__init__(schema)
        self.n_trees = n_trees
        self.window_size = window_size
        self.depth = 8
        n_features = schema.n_features
        rng = np.random.default_rng(0)
        low = np.full(max(n_features, 1), -3.0, dtype=np.float64)
        high = np.full(max(n_features, 1), 3.0, dtype=np.float64)
        self.trees = [_HSTree(n_features, self.depth, low, high, rng) for _ in range(n_trees)]
        self._n_seen = 0

    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        for tree in self.trees:
            tree.update(X)
        # Cap influence by window_size by decaying when seen exceeds window
        self._n_seen += X.shape[0]
        if self._n_seen > self.window_size and self.window_size > 0:
            decay = self.window_size / self._n_seen
            for tree in self.trees:
                tree.leaf_mass *= decay
            self._n_seen = self.window_size
        return None

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        n = X.shape[0]
        if self.n_trees == 0:
            return np.zeros(n, dtype=np.float64)
        max_mass = 0.0
        for tree in self.trees:
            m = float(tree.leaf_mass.max()) if tree.leaf_mass.size else 0.0
            if m > max_mass:
                max_mass = m
        if max_mass <= 0.0:
            return np.zeros(n, dtype=np.float64)
        out = np.zeros(n, dtype=np.float64)
        for i in range(n):
            avg = 0.0
            for tree in self.trees:
                avg += tree.mass(X[i])
            avg /= self.n_trees
            score = 1.0 - avg / max_mass
            if score < 0.0:
                score = 0.0
            elif score > 1.0:
                score = 1.0
            out[i] = score
        return out

    def predict(self, X: np.ndarray) -> np.ndarray:
        scores = self.predict_proba(X)
        return (scores > 0.5).astype(np.int64)


class OnlineQuantileDetector(BaseEstimator):
    def __init__(self, schema: FeatureSchema, quantile: float, window_size: int):
        super().__init__(schema)
        self.quantile = quantile
        self.window_size = window_size
        self.buffer: collections.deque = collections.deque(maxlen=window_size)

    def _mean(self) -> np.ndarray:
        if len(self.buffer) == 0:
            return np.zeros(self.schema.n_features, dtype=np.float64)
        arr = np.array(self.buffer, dtype=np.float64)
        return arr.mean(axis=0)

    def _deviations(self) -> np.ndarray:
        if len(self.buffer) == 0:
            return np.array([0.0])
        arr = np.array(self.buffer, dtype=np.float64)
        m = arr.mean(axis=0)
        return np.linalg.norm(arr - m, axis=1)

    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        for i in range(X.shape[0]):
            self.buffer.append(X[i].copy())
        return None

    def _threshold_and_devs(self, X: np.ndarray):
        m = self._mean()
        new_devs = np.linalg.norm(X - m, axis=1)
        if len(self.buffer) == 0:
            return new_devs, 0.0, 1.0
        devs = self._deviations()
        threshold = float(np.quantile(devs, self.quantile))
        max_dev = float(devs.max())
        if max_dev <= 0.0:
            max_dev = max(threshold, 1.0)
        return new_devs, threshold, max_dev

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        new_devs, threshold, _ = self._threshold_and_devs(X)
        return (new_devs > threshold).astype(np.int64)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        new_devs, _, max_dev = self._threshold_and_devs(X)
        scores = new_devs / max_dev
        return np.clip(scores, 0.0, 1.0)
