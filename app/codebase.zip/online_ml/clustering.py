import collections

import numpy as np

from .base import BaseEstimator
from .schema import FeatureSchema


class IncrementalKMeans(BaseEstimator):
    def __init__(
        self,
        schema: FeatureSchema,
        n_clusters: int,
        split_variance_threshold: float,
        merge_distance_threshold: float,
    ):
        super().__init__(schema)
        self.n_clusters_initial = n_clusters
        self.split_variance_threshold = split_variance_threshold
        self.merge_distance_threshold = merge_distance_threshold
        self.centroids: list = []
        self.counts: list = []
        self.M2: list = []
        self._initialized = False

    def _init_centroids(self, X: np.ndarray) -> None:
        n_samples = X.shape[0]
        n_features = X.shape[1]
        if n_samples == 0:
            for _ in range(self.n_clusters_initial):
                self.centroids.append(np.zeros(n_features, dtype=np.float64))
                self.counts.append(0)
                self.M2.append(np.zeros(n_features, dtype=np.float64))
            self._initialized = True
            return
        # k-means++ style farthest-point seeding (deterministic on first sample)
        chosen_indices = [0]
        for _ in range(1, self.n_clusters_initial):
            dists = np.full(n_samples, np.inf)
            for ci in chosen_indices:
                d = np.linalg.norm(X - X[ci], axis=1)
                dists = np.minimum(dists, d)
            next_idx = int(np.argmax(dists))
            chosen_indices.append(next_idx)
        for ci in chosen_indices:
            self.centroids.append(X[ci].astype(np.float64).copy())
            self.counts.append(0)
            self.M2.append(np.zeros(n_features, dtype=np.float64))
        self._initialized = True

    def _assign(self, x: np.ndarray) -> int:
        best = 0
        best_d = np.inf
        for k, c in enumerate(self.centroids):
            d = float(np.sum((x - c) ** 2))
            if d < best_d:
                best_d = d
                best = k
        return best

    def _split_clusters(self) -> None:
        new_centroids = []
        new_counts = []
        new_M2 = []
        for k in range(len(self.centroids)):
            cnt = self.counts[k]
            if cnt > 1:
                var_per_dim = self.M2[k] / cnt
                total_var = float(var_per_dim.sum())
            else:
                total_var = 0.0
            if cnt > 1 and total_var > self.split_variance_threshold:
                std = np.sqrt(np.maximum(self.M2[k] / cnt, 0.0))
                offset = std.copy()
                if float(np.linalg.norm(offset)) == 0.0:
                    offset = np.ones_like(self.centroids[k]) * max(
                        1e-6, np.sqrt(self.split_variance_threshold)
                    )
                new_centroids.append(self.centroids[k] + offset)
                new_centroids.append(self.centroids[k] - offset)
                half = cnt // 2
                new_counts.append(half)
                new_counts.append(cnt - half)
                new_M2.append(np.zeros_like(self.M2[k]))
                new_M2.append(np.zeros_like(self.M2[k]))
            else:
                new_centroids.append(self.centroids[k])
                new_counts.append(cnt)
                new_M2.append(self.M2[k])
        self.centroids = new_centroids
        self.counts = new_counts
        self.M2 = new_M2

    def _merge_clusters(self) -> None:
        while len(self.centroids) > 1:
            merged = False
            for i in range(len(self.centroids)):
                for j in range(i + 1, len(self.centroids)):
                    d = float(np.linalg.norm(self.centroids[i] - self.centroids[j]))
                    if d < self.merge_distance_threshold:
                        n_i = self.counts[i]
                        n_j = self.counts[j]
                        total = n_i + n_j
                        if total > 0:
                            new_c = (self.centroids[i] * n_i + self.centroids[j] * n_j) / total
                        else:
                            new_c = (self.centroids[i] + self.centroids[j]) / 2.0
                        new_M = self.M2[i] + self.M2[j]
                        for idx in sorted([i, j], reverse=True):
                            self.centroids.pop(idx)
                            self.counts.pop(idx)
                            self.M2.pop(idx)
                        self.centroids.append(new_c)
                        self.counts.append(total)
                        self.M2.append(new_M)
                        merged = True
                        break
                if merged:
                    break
            if not merged:
                break

    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        if not self._initialized:
            self._init_centroids(X)
        for i in range(X.shape[0]):
            x = X[i]
            k = self._assign(x)
            self.counts[k] += 1
            cnt = self.counts[k]
            delta = x - self.centroids[k]
            self.centroids[k] = self.centroids[k] + delta / cnt
            delta2 = x - self.centroids[k]
            self.M2[k] = self.M2[k] + delta * delta2
        self._split_clusters()
        self._merge_clusters()
        return None

    def _distances(self, X: np.ndarray) -> np.ndarray:
        n = X.shape[0]
        k = len(self.centroids)
        out = np.zeros((n, k), dtype=np.float64)
        for ki, c in enumerate(self.centroids):
            out[:, ki] = np.linalg.norm(X - c, axis=1)
        return out

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        if not self.centroids:
            return np.zeros(X.shape[0], dtype=np.int64)
        d = self._distances(X)
        return np.argmin(d, axis=1).astype(np.int64)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        if not self.centroids:
            return np.ones((X.shape[0], 1), dtype=np.float64)
        d = self._distances(X)
        # Soft assignment via inverse distance
        weights = 1.0 / (d + 1e-12)
        weights = weights / weights.sum(axis=1, keepdims=True)
        return weights


class OnlineDBSCAN(BaseEstimator):
    def __init__(self, schema: FeatureSchema, eps: float, min_samples: int, window_size: int):
        super().__init__(schema)
        self.eps = eps
        self.min_samples = min_samples
        self.window_size = window_size
        self.buffer: collections.deque = collections.deque(maxlen=window_size)

    def partial_fit(self, X: np.ndarray, y: np.ndarray) -> None:
        X = np.asarray(X, dtype=np.float64)
        for i in range(X.shape[0]):
            self.buffer.append(X[i].copy())
        return None

    def _buffer_components(self):
        n = len(self.buffer)
        if n == 0:
            return None, None, None
        pts = np.array(self.buffer, dtype=np.float64)
        diff = pts[:, None, :] - pts[None, :, :]
        dists = np.linalg.norm(diff, axis=2)
        within = dists < self.eps
        core_count = within.sum(axis=1)
        is_core = core_count >= self.min_samples
        parent = list(range(n))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb

        for i in range(n):
            if not is_core[i]:
                continue
            for j in range(i + 1, n):
                if within[i, j]:
                    union(i, j)

        roots = [find(i) for i in range(n)]
        unique_core_roots = []
        seen = set()
        for i in range(n):
            if is_core[i]:
                r = roots[i]
                if r not in seen:
                    seen.add(r)
                    unique_core_roots.append(r)
        root_to_cid = {r: idx for idx, r in enumerate(unique_core_roots)}
        labels = np.full(n, -1, dtype=np.int64)
        for i in range(n):
            r = roots[i]
            if r in root_to_cid:
                labels[i] = root_to_cid[r]
        return pts, labels, is_core

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        n = X.shape[0]
        if len(self.buffer) == 0:
            return np.full(n, -1, dtype=np.int64)
        pts, buf_labels, _ = self._buffer_components()
        out = np.full(n, -1, dtype=np.int64)
        for i in range(n):
            q = X[i]
            d = np.linalg.norm(pts - q, axis=1)
            within = d < self.eps
            count = int(within.sum())
            if count >= self.min_samples:
                neighbor_labels = buf_labels[within]
                valid = neighbor_labels[neighbor_labels >= 0]
                if valid.size > 0:
                    counts = np.bincount(valid)
                    out[i] = int(np.argmax(counts))
                else:
                    out[i] = -1
            else:
                out[i] = -1
        return out

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        n = X.shape[0]
        out = np.zeros((n, 1), dtype=np.float64)
        if len(self.buffer) == 0:
            return out
        pts = np.array(self.buffer, dtype=np.float64)
        denom = max(self.min_samples, 1)
        for i in range(n):
            q = X[i]
            d = np.linalg.norm(pts - q, axis=1)
            count = int((d < self.eps).sum())
            out[i, 0] = min(count / denom, 1.0)
        return out
