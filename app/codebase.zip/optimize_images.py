import argparse
import json
import os
import sys
from PIL import Image

SUPPORTED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.gif', '.tiff', '.tif', '.bmp'}
ORIENTATION_TAG = 274


def parse_args(args):
    parser = argparse.ArgumentParser(
        description='Batch-process images into web-optimized WebP files.'
    )
    parser.add_argument('input_dir', help='Directory containing source images')
    parser.add_argument('output_dir', help='Directory to write output files')
    parser.add_argument(
        '--max-dimension', type=int, default=1920,
        help='Maximum width or height in pixels (default: 1920)'
    )
    parser.add_argument(
        '--quality', type=int, default=85,
        help='WebP quality 0-100 (default: 85)'
    )
    parser.add_argument(
        '--thumbnail-size', type=int, default=200,
        help='Maximum thumbnail dimension in pixels (default: 200)'
    )
    return parser.parse_args(args)


def load_manifest(output_dir):
    """Load existing manifest.json from output_dir and return a dict keyed by original_filename."""
    manifest_path = os.path.join(output_dir, 'manifest.json')
    if os.path.isfile(manifest_path):
        try:
            with open(manifest_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return {entry['original_filename']: entry for entry in data.get('images', [])}
        except Exception:
            return {}
    return {}


def get_orientation(img):
    """Return the EXIF orientation tag value (tag 274), or None if not present."""
    try:
        exif = img.getexif()
        if exif and ORIENTATION_TAG in exif:
            return exif[ORIENTATION_TAG]
    except Exception:
        pass
    return None


def build_exif_bytes(orientation):
    """Build minimal EXIF bytes containing only the orientation tag, using Pillow's Exif class."""
    if orientation is None:
        return None
    try:
        exif = Image.Exif()
        exif[ORIENTATION_TAG] = orientation
        return exif.tobytes()
    except Exception:
        return None


def resize_image(img, max_dim):
    """
    Resize img so that neither dimension exceeds max_dim, preserving aspect ratio.
    Does not upscale images already within max_dim on both sides.
    """
    w, h = img.size
    if w <= max_dim and h <= max_dim:
        return img
    scale = min(max_dim / w, max_dim / h)
    new_w = int(w * scale)
    new_h = int(h * scale)
    return img.resize((new_w, new_h), Image.LANCZOS)


def save_webp(img, path, quality, exif_bytes):
    """Save img to path as WebP, optionally embedding exif_bytes."""
    save_kwargs = {'format': 'WEBP', 'quality': quality}
    if exif_bytes is not None:
        save_kwargs['exif'] = exif_bytes
    img.save(path, **save_kwargs)


def process_image(src_path, out_path, thumb_path, max_dimension, quality, thumbnail_size):
    """
    Open src_path, resize, convert to WebP for both main output and thumbnail.
    Strips all EXIF except orientation tag.
    """
    img = Image.open(src_path)
    img.load()

    # Capture orientation before any conversion that might lose EXIF
    orientation = get_orientation(img)
    exif_bytes = build_exif_bytes(orientation)

    # Convert to a mode compatible with WebP (RGB or RGBA)
    if img.mode in ('RGBA', 'LA', 'PA'):
        img = img.convert('RGBA')
    elif img.mode != 'RGB':
        img = img.convert('RGB')

    # Main resized output
    resized = resize_image(img, max_dimension)
    save_webp(resized, out_path, quality, exif_bytes)

    # Thumbnail output
    thumb = resize_image(img, thumbnail_size)
    save_webp(thumb, thumb_path, quality, exif_bytes)


def main(args=None):
    parsed = parse_args(args)

    input_dir = parsed.input_dir
    output_dir = parsed.output_dir
    max_dimension = parsed.max_dimension
    quality = parsed.quality
    thumbnail_size = parsed.thumbnail_size

    # Validate input_dir exists
    if not os.path.isdir(input_dir):
        sys.exit(1)

    # Validate quality range
    if quality < 0 or quality > 100:
        sys.exit(1)

    # Validate / create output_dir
    if os.path.exists(output_dir) and not os.path.isdir(output_dir):
        # output_dir exists as a file - cannot create directory there
        sys.exit(1)
    if not os.path.exists(output_dir):
        try:
            os.makedirs(output_dir)
        except Exception:
            sys.exit(1)

    # Load existing manifest for skip logic
    existing_manifest = load_manifest(output_dir)

    # Collect supported files from top-level of input_dir only (non-recursive)
    try:
        all_entries = os.listdir(input_dir)
    except Exception:
        sys.exit(1)

    candidate_files = []
    for name in all_entries:
        full_path = os.path.join(input_dir, name)
        if not os.path.isfile(full_path):
            continue
        ext = os.path.splitext(name)[1].lower()
        if ext in SUPPORTED_EXTENSIONS:
            candidate_files.append(name)

    # Sort alphabetically so collision resolution and manifest order are deterministic
    candidate_files.sort()

    # Handle basename collision: first file alphabetically wins, subsequent are skipped
    seen_basenames = {}
    accepted_files = []
    for name in candidate_files:
        basename = os.path.splitext(name)[0]
        if basename not in seen_basenames:
            seen_basenames[basename] = name
            accepted_files.append(name)
        # else: skip - second (or later) alphabetical file with the same basename

    # Process each accepted file
    manifest_entries = {}

    for name in accepted_files:
        src_path = os.path.join(input_dir, name)
        basename = os.path.splitext(name)[0]
        out_filename = basename + '.webp'
        thumb_filename = basename + '_thumb.webp'
        out_path = os.path.join(output_dir, out_filename)
        thumb_path = os.path.join(output_dir, thumb_filename)

        # Get source file modification timestamp
        try:
            mtime = os.path.getmtime(src_path)
        except Exception:
            continue

        # Skip logic: if manifest entry exists with matching last_modified, retain and skip
        if name in existing_manifest:
            prev_entry = existing_manifest[name]
            if prev_entry.get('last_modified') == mtime:
                manifest_entries[name] = prev_entry
                continue

        # Process the image; skip file on any error and continue with remaining files
        try:
            process_image(src_path, out_path, thumb_path, max_dimension, quality, thumbnail_size)
        except Exception:
            continue

        # Gather statistics for manifest entry
        try:
            original_size = os.path.getsize(src_path)
            optimized_size = os.path.getsize(out_path)
            compression_ratio = round(original_size / optimized_size, 4)
        except Exception:
            continue

        entry = {
            'original_filename': name,
            'output_filename': out_filename,
            'thumbnail_filename': thumb_filename,
            'original_size': original_size,
            'optimized_size': optimized_size,
            'compression_ratio': compression_ratio,
            'last_modified': mtime,
        }
        manifest_entries[name] = entry

    # Build manifest image list: only current source files, ordered alphabetically
    # (accepted_files is already sorted alphabetically)
    images_list = []
    for name in accepted_files:
        if name in manifest_entries:
            images_list.append(manifest_entries[name])

    manifest = {'images': images_list}
    manifest_path = os.path.join(output_dir, 'manifest.json')
    try:
        with open(manifest_path, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, indent=2)
    except Exception:
        sys.exit(1)

    sys.exit(0)


if __name__ == '__main__':
    main()