"""
Dental Lab Case Management Backend
==================================

A SQLite-backed Python backend for a small custom dental lab that fabricates
crowns, bridges, dentures, and night guards on prescription. The module exposes
a single :class:`DentalLab` class that handles case intake, workflow
progression through four lab stations, turnaround tracking against the
dentist's promised seat date, and per-dentist monthly billing reconciled
against a per-restoration fee schedule.

All persistence is performed through Python's built-in :mod:`sqlite3` module
(the sole database interface), via a single persistent connection opened
during :py:meth:`DentalLab.__init__` and reused for the lifetime of the
instance.
"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime, timezone
from typing import Optional


class DentalLab:
    """Case management backend for a custom dental lab.

    The constructor opens (or creates) a SQLite database at ``db_path`` and
    ensures every required table exists. All public methods reuse the same
    connection and commit their changes immediately, so data survives
    instance lifecycles: a new ``DentalLab`` opened on the same file sees
    everything previously written.
    """

    # ------------------------------------------------------------------
    # Domain vocabularies (kept as class-level constants so they can be
    # introspected and reused by callers and tests alike).
    # ------------------------------------------------------------------

    RESTORATION_TYPES: frozenset[str] = frozenset(
        {"crown", "bridge", "denture", "night_guard"}
    )
    HANDOFF_TYPES: frozenset[str] = frozenset({"impression", "intraoral_scan"})
    STATIONS: frozenset[str] = frozenset(
        {"design", "milling", "pressing", "finishing", "quality_check"}
    )
    # Stations that occupy slot 2 of the workflow (mutually exclusive).
    SLOT_TWO_STATIONS: frozenset[str] = frozenset({"milling", "pressing"})

    # ------------------------------------------------------------------
    # Construction & schema
    # ------------------------------------------------------------------

    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        # A single, persistent connection used for every subsequent call.
        self._conn: sqlite3.Connection = sqlite3.connect(
            db_path, check_same_thread=False
        )
        # Enforce referential integrity at the database layer.
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._create_schema()

    @property
    def conn(self) -> sqlite3.Connection:
        """The single persistent SQLite connection used by this instance."""
        return self._conn

    def close(self) -> None:
        """Close the underlying SQLite connection (idempotent)."""
        try:
            self._conn.close()
        except sqlite3.ProgrammingError:
            pass

    def _create_schema(self) -> None:
        """Create every required table if it does not already exist."""
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS dentists (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                name      TEXT    NOT NULL,
                practice  TEXT    NOT NULL,
                phone     TEXT    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS patients (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                first_name  TEXT    NOT NULL,
                last_name   TEXT    NOT NULL,
                dob         TEXT    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS technicians (
                id    INTEGER PRIMARY KEY AUTOINCREMENT,
                name  TEXT    NOT NULL
            );

            CREATE TABLE IF NOT EXISTS cases (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                dentist_id       INTEGER NOT NULL,
                patient_id       INTEGER NOT NULL,
                seat_date        TEXT    NOT NULL,
                creation_date    TEXT    NOT NULL,
                completion_date  TEXT,
                FOREIGN KEY (dentist_id) REFERENCES dentists(id),
                FOREIGN KEY (patient_id) REFERENCES patients(id)
            );

            CREATE TABLE IF NOT EXISTS restorations (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                case_id     INTEGER NOT NULL,
                type        TEXT    NOT NULL,
                shade       TEXT    NOT NULL,
                material    TEXT    NOT NULL,
                billed_fee  REAL,
                FOREIGN KEY (case_id) REFERENCES cases(id)
            );

            CREATE TABLE IF NOT EXISTS handoffs (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                case_id       INTEGER NOT NULL,
                tray_id       TEXT    NOT NULL,
                handoff_type  TEXT    NOT NULL,
                FOREIGN KEY (case_id) REFERENCES cases(id)
            );

            CREATE TABLE IF NOT EXISTS stations (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                case_id        INTEGER NOT NULL,
                station        TEXT    NOT NULL,
                technician_id  INTEGER NOT NULL,
                assigned_at    TEXT    NOT NULL,
                completed_at   TEXT,
                FOREIGN KEY (case_id) REFERENCES cases(id),
                FOREIGN KEY (technician_id) REFERENCES technicians(id)
            );

            -- The fee schedule lives in its own table, keyed by restoration
            -- type. This keeps the live schedule fully separated from the
            -- per-case `restorations.billed_fee` snapshot taken at QC time.
            CREATE TABLE IF NOT EXISTS fee_schedule (
                restoration_type  TEXT    PRIMARY KEY,
                fee               REAL    NOT NULL
            );
            """
        )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _workflow_state(self, case_id: int) -> tuple[Optional[dict], list[str]]:
        """Return ``(active, completed_stations)`` for ``case_id``.

        ``active`` is ``None`` when no station is currently open; otherwise
        a dict with the open station's name and assigned technician id.
        ``completed_stations`` is the ordered list of station names that have
        been marked complete on this case (insertion order).
        """
        rows = self._conn.execute(
            """
            SELECT station, technician_id, completed_at
            FROM stations
            WHERE case_id = ?
            ORDER BY id
            """,
            (case_id,),
        ).fetchall()

        active: Optional[dict] = None
        completed: list[str] = []
        for station, technician_id, completed_at in rows:
            if completed_at is None:
                active = {"station": station, "technician_id": technician_id}
            else:
                completed.append(station)
        return active, completed

    def _validate_next_station(
        self, station: str, completed: list[str], active: Optional[dict]
    ) -> None:
        """Raise ``ValueError`` unless ``station`` is the legal next step."""
        if active is not None:
            raise ValueError(
                f"Station '{active['station']}' is still open; "
                "complete it before opening another station."
            )
        if "quality_check" in completed:
            raise ValueError("Case is already fully complete.")

        slot_two_done = bool(set(completed) & self.SLOT_TWO_STATIONS)

        if not completed:
            expected = "design"
        elif "design" not in completed:
            # The very first completion is missing — only design is valid.
            expected = "design"
        elif not slot_two_done:
            if station in self.SLOT_TWO_STATIONS:
                return
            raise ValueError(
                "After 'design', the next station must be 'milling' or "
                f"'pressing'; got '{station}'."
            )
        elif "finishing" not in completed:
            expected = "finishing"
        else:
            expected = "quality_check"

        if station != expected:
            raise ValueError(
                f"Station '{station}' is out of sequence; expected '{expected}'."
            )

    # ------------------------------------------------------------------
    # Reference-data inserts
    # ------------------------------------------------------------------

    def add_dentist(self, name: str, practice: str, phone: str) -> int:
        """Insert a dentist and return the new ``dentist_id``."""
        cursor = self._conn.execute(
            "INSERT INTO dentists (name, practice, phone) VALUES (?, ?, ?)",
            (name, practice, phone),
        )
        self._conn.commit()
        return int(cursor.lastrowid)

    def add_patient(self, first_name: str, last_name: str, dob: str) -> int:
        """Insert a patient (``dob`` is an ISO ``YYYY-MM-DD`` string)."""
        cursor = self._conn.execute(
            "INSERT INTO patients (first_name, last_name, dob) VALUES (?, ?, ?)",
            (first_name, last_name, dob),
        )
        self._conn.commit()
        return int(cursor.lastrowid)

    def add_technician(self, name: str) -> int:
        """Insert a lab technician and return the new ``technician_id``."""
        cursor = self._conn.execute(
            "INSERT INTO technicians (name) VALUES (?)",
            (name,),
        )
        self._conn.commit()
        return int(cursor.lastrowid)

    # ------------------------------------------------------------------
    # Case intake
    # ------------------------------------------------------------------

    def create_case(
        self,
        dentist_id: int,
        patient_id: int,
        restorations: list,
        seat_date: str,
    ) -> int:
        """Create a new case linked to ``dentist_id`` and ``patient_id``.

        ``restorations`` is a non-empty list of dicts; each dict supplies
        ``type`` (one of the four valid restoration types), ``shade``, and
        ``material``. The case's ``seat_date`` (the dentist's promised
        delivery date) is stored as supplied, and the creation date is
        captured as today's ISO date at insert time.
        """
        if not restorations:
            raise ValueError("A case requires at least one restoration.")

        for restoration in restorations:
            rtype = restoration["type"]
            if rtype not in self.RESTORATION_TYPES:
                raise ValueError(
                    f"Invalid restoration type '{rtype}'; "
                    f"must be one of {sorted(self.RESTORATION_TYPES)}."
                )

        creation_date = date.today().isoformat()
        cursor = self._conn.execute(
            """
            INSERT INTO cases (dentist_id, patient_id, seat_date, creation_date)
            VALUES (?, ?, ?, ?)
            """,
            (dentist_id, patient_id, seat_date, creation_date),
        )
        case_id = int(cursor.lastrowid)

        self._conn.executemany(
            """
            INSERT INTO restorations (case_id, type, shade, material)
            VALUES (?, ?, ?, ?)
            """,
            [
                (case_id, r["type"], r["shade"], r["material"])
                for r in restorations
            ],
        )
        self._conn.commit()
        return case_id

    def record_handoff(self, case_id: int, tray_id: str, handoff_type: str) -> None:
        """Record the physical handoff (tray + impression/intraoral_scan)."""
        if handoff_type not in self.HANDOFF_TYPES:
            raise ValueError(
                f"Invalid handoff_type '{handoff_type}'; "
                f"must be one of {sorted(self.HANDOFF_TYPES)}."
            )
        self._conn.execute(
            "INSERT INTO handoffs (case_id, tray_id, handoff_type) VALUES (?, ?, ?)",
            (case_id, tray_id, handoff_type),
        )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Lab workflow
    # ------------------------------------------------------------------

    def advance_station(
        self, case_id: int, station: str, technician_id: int
    ) -> None:
        """Open ``station`` for ``case_id`` and assign ``technician_id``.

        The assignment timestamp is recorded as the current UTC datetime in
        ISO format. Raises :class:`ValueError` if ``station`` is not one of
        the five allowed stations or is out of sequence (including reopening
        a station that is already complete or attempting to advance while
        another station is still active).
        """
        if station not in self.STATIONS:
            raise ValueError(
                f"Invalid station '{station}'; "
                f"must be one of {sorted(self.STATIONS)}."
            )

        active, completed = self._workflow_state(case_id)
        self._validate_next_station(station, completed, active)

        assigned_at = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            """
            INSERT INTO stations (case_id, station, technician_id, assigned_at)
            VALUES (?, ?, ?, ?)
            """,
            (case_id, station, technician_id, assigned_at),
        )
        self._conn.commit()

    def complete_station(self, case_id: int, station: str) -> None:
        """Mark ``station`` complete for ``case_id``.

        Raises :class:`ValueError` if ``station`` is not currently the active
        station for the case. When ``station`` is ``"quality_check"``: every
        restoration on the case must have a fee in the fee schedule — its
        live value is snapshotted into ``restorations.billed_fee`` and the
        case's ``completion_date`` is set to today. If any restoration type
        is missing from the schedule, a ``ValueError`` is raised and the
        ``quality_check`` station is left incomplete (i.e. callers can set
        the missing fee and retry).
        """
        active, _ = self._workflow_state(case_id)
        if active is None or active["station"] != station:
            raise ValueError(
                f"Station '{station}' is not currently active for case {case_id}."
            )

        if station == "quality_check":
            self._snapshot_fees_and_record_completion(case_id)

        completed_at = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            """
            UPDATE stations
            SET completed_at = ?
            WHERE case_id = ? AND station = ? AND completed_at IS NULL
            """,
            (completed_at, case_id, station),
        )
        self._conn.commit()

    def _snapshot_fees_and_record_completion(self, case_id: int) -> None:
        """Snapshot live fees and record today's completion date for ``case_id``.

        Fees are validated for *every* restoration before any write occurs;
        this guarantees that when a fee is missing the ``ValueError`` is
        raised and the case state is left exactly as it was (i.e. the
        ``quality_check`` station remains active).
        """
        restorations = self._conn.execute(
            "SELECT id, type FROM restorations WHERE case_id = ?",
            (case_id,),
        ).fetchall()

        snapshots: list[tuple[float, int]] = []
        for restoration_id, restoration_type in restorations:
            row = self._conn.execute(
                "SELECT fee FROM fee_schedule WHERE restoration_type = ?",
                (restoration_type,),
            ).fetchone()
            if row is None:
                raise ValueError(
                    f"No fee set for restoration type '{restoration_type}'; "
                    "quality_check cannot be completed."
                )
            snapshots.append((float(row[0]), restoration_id))

        self._conn.executemany(
            "UPDATE restorations SET billed_fee = ? WHERE id = ?",
            snapshots,
        )
        self._conn.execute(
            "UPDATE cases SET completion_date = ? WHERE id = ?",
            (date.today().isoformat(), case_id),
        )

    # ------------------------------------------------------------------
    # Case status
    # ------------------------------------------------------------------

    def get_case_status(self, case_id: int) -> dict:
        """Return the workflow status for ``case_id``.

        Keys:
            ``current_station``        — name of the open, incomplete station,
                                         or ``None`` when the case is pristine
                                         or all stations are complete.
            ``technician_id``          — technician assigned to the active
                                         station, or ``None`` when none.
            ``completed``              — ``True`` iff ``quality_check`` is
                                         complete.
            ``last_completed_station`` — most recently completed station, or
                                         ``None`` when no station has been
                                         completed yet (this is what tells
                                         a pristine case apart from an
                                         inter-station gap).
        """
        active, completed = self._workflow_state(case_id)
        return {
            "current_station": active["station"] if active else None,
            "technician_id": active["technician_id"] if active else None,
            "completed": "quality_check" in completed,
            "last_completed_station": completed[-1] if completed else None,
        }

    # ------------------------------------------------------------------
    # Fee schedule
    # ------------------------------------------------------------------

    def set_fee(self, restoration_type: str, fee: float) -> None:
        """Store the flat ``fee`` (USD) for ``restoration_type``.

        Replaces any existing fee for that type. ``restoration_type`` must
        be one of ``crown``, ``bridge``, ``denture``, ``night_guard``.
        """
        if restoration_type not in self.RESTORATION_TYPES:
            raise ValueError(
                f"Invalid restoration_type '{restoration_type}'; "
                f"must be one of {sorted(self.RESTORATION_TYPES)}."
            )
        self._conn.execute(
            """
            INSERT INTO fee_schedule (restoration_type, fee)
            VALUES (?, ?)
            ON CONFLICT(restoration_type) DO UPDATE SET fee = excluded.fee
            """,
            (restoration_type, float(fee)),
        )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Turnaround tracking
    # ------------------------------------------------------------------

    def get_case_turnaround(self, case_id: int) -> dict:
        """Return turnaround information for ``case_id``.

        ``elapsed_days`` is the integer difference between the
        ``completion_date`` (set when ``quality_check`` is completed) and the
        ``creation_date`` (captured during :py:meth:`create_case`). Both
        ``completion_date`` and ``elapsed_days`` are ``None`` until the case
        is complete.
        """
        row = self._conn.execute(
            """
            SELECT seat_date, creation_date, completion_date
            FROM cases
            WHERE id = ?
            """,
            (case_id,),
        ).fetchone()
        if row is None:
            raise ValueError(f"No case with id {case_id}.")
        seat_date, creation_date, completion_date = row

        elapsed_days: Optional[int] = None
        if completion_date is not None:
            elapsed_days = (
                date.fromisoformat(completion_date)
                - date.fromisoformat(creation_date)
            ).days

        return {
            "case_id": case_id,
            "seat_date": seat_date,
            "completion_date": completion_date,
            "elapsed_days": elapsed_days,
        }

    # ------------------------------------------------------------------
    # Billing
    # ------------------------------------------------------------------

    def generate_statement(
        self, dentist_id: int, year: int, month: int
    ) -> dict:
        """Return the monthly billing statement for ``dentist_id``.

        The statement contains every case for the dentist whose
        ``quality_check`` was completed in the supplied calendar month/year.
        Each per-case ``amount`` is the sum of the snapshotted ``billed_fee``
        values captured at quality-check completion time; the live fee
        schedule is intentionally *not* consulted.
        """
        month_prefix = f"{year:04d}-{month:02d}-"
        rows = self._conn.execute(
            """
            SELECT c.id, COALESCE(SUM(r.billed_fee), 0.0) AS amount
            FROM cases AS c
            LEFT JOIN restorations AS r ON r.case_id = c.id
            WHERE c.dentist_id = ?
              AND c.completion_date LIKE ?
            GROUP BY c.id
            ORDER BY c.id
            """,
            (dentist_id, month_prefix + "%"),
        ).fetchall()

        cases = [{"case_id": int(case_id), "amount": float(amount)}
                 for case_id, amount in rows]
        total = float(sum(entry["amount"] for entry in cases))

        return {
            "dentist_id": dentist_id,
            "year": year,
            "month": month,
            "cases": cases,
            "total": total,
        }

    # ------------------------------------------------------------------
    # Lifecycle helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"DentalLab(db_path={self.db_path!r})"

    def __enter__(self) -> "DentalLab":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()