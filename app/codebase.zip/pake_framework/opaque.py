"""
OPAQUE Asymmetric PAKE (IRTF CFRG draft surface).

Registration flow (3 messages):
  Client → Server : OpaqueRegistrationRequest   (blinded OPRF element)
  Server → Client : OpaqueRegistrationResponse  (evaluated element + server public key)
  Client → stored : OpaqueRegistrationRecord    (encrypted envelope + masking key + client pubkey)

Login AKE flow (3 messages):
  Client → Server : OpaqueKE1  (credential request + AKE sub-message 1)
  Server → Client : OpaqueKE2  (credential response + AKE sub-message 2 + masking nonce)
  Client → Server : OpaqueKE3  (client authentication MAC)

After successful AKE both parties derive the same session key.
MAC failures raise AuthenticationError.
"""

import dataclasses
import hashlib
import hmac
import os
from typing import Tuple

from .exceptions import AuthenticationError
from .groups import Group


# ─────────────────────────────────────────────────────────────────────────────
# Typed message dataclasses
# ─────────────────────────────────────────────────────────────────────────────

@dataclasses.dataclass
class OpaqueRegistrationRequest:
    """First registration message (client → server). Carries OPRF-blinded password element."""
    blinded_element: bytes


@dataclasses.dataclass
class OpaqueRegistrationResponse:
    """Second registration message (server → client). OPRF-evaluated element + server pubkey."""
    evaluated_element: bytes
    server_public_key: bytes


@dataclasses.dataclass
class OpaqueRegistrationRecord:
    """Client-produced record stored server-side after registration."""
    envelope: bytes
    masking_key: bytes
    client_public_key: bytes


@dataclasses.dataclass
class OpaqueKE1:
    """First login message (client → server). OPRF credential request + first AKE sub-message."""
    credential_request: bytes
    auth_request: bytes


@dataclasses.dataclass
class OpaqueKE2:
    """Second login message (server → client). OPRF credential response + AKE sub-message 2 + masking nonce."""
    credential_response: bytes
    auth_response: bytes
    masking_nonce: bytes


@dataclasses.dataclass
class OpaqueKE3:
    """Third login message (client → server). Client authentication MAC."""
    auth_finalizer: bytes


# ─────────────────────────────────────────────────────────────────────────────
# Intermediate state dataclasses
# ─────────────────────────────────────────────────────────────────────────────

@dataclasses.dataclass
class OpaqueClientRegistrationState:
    """Intermediate state produced by OpaqueClient.registration_request."""
    blinding_scalar: bytes
    password: bytes


@dataclasses.dataclass
class OpaqueClientLoginState:
    """Intermediate state produced by OpaqueClient.login_start."""
    blinding_scalar: bytes
    password: bytes
    eph_private_key: bytes
    ke1_credential_request: bytes
    ke1_auth_request: bytes


@dataclasses.dataclass
class OpaqueServerLoginState:
    """Intermediate state produced by OpaqueServer.login_respond."""
    ke: bytes
    expected_client_mac: bytes


# ─────────────────────────────────────────────────────────────────────────────
# Internal cryptographic helpers
# ─────────────────────────────────────────────────────────────────────────────

def _hkdf(key_material: bytes, info: bytes, length: int) -> bytes:
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives.hashes import SHA256
    h = HKDF(algorithm=SHA256(), length=length, salt=None, info=info)
    return h.derive(key_material)


def _hmac_sha256(key: bytes, data: bytes) -> bytes:
    return hmac.new(key, data, hashlib.sha256).digest()


def _scalar_invert(scalar_bytes: bytes, group: Group) -> bytes:
    """Compute modular inverse of a scalar within the group's scalar field."""
    name = group.name
    if name in ("P-256", "P-384"):
        from .groups import _P256, _P384
        c = _P256 if name == "P-256" else _P384
        k = int.from_bytes(scalar_bytes, "big") % c.n
        k_inv = pow(k, c.n - 2, c.n)
        return k_inv.to_bytes(c.byte_len, "big")
    elif name == "ristretto255":
        import nacl.bindings as nb
        return nb.crypto_core_ed25519_scalar_invert(scalar_bytes)
    else:
        raise NotImplementedError(f"Scalar inversion not supported for {name}")


def _extract_x(point_bytes: bytes, group: Group) -> bytes:
    """Extract x-coordinate bytes from a point for use in HKDF."""
    if group.name in ("P-256", "P-384"):
        bl = group.byte_len
        return point_bytes[1 : 1 + bl]
    return point_bytes


# ─────────────────────────────────────────────────────────────────────────────
# OPAQUE Client
# ─────────────────────────────────────────────────────────────────────────────

class OpaqueClient:
    """Client side of the OPAQUE protocol."""

    def __init__(self, group: Group):
        self._group = group

    def registration_request(
        self, password: bytes
    ) -> Tuple[OpaqueClientRegistrationState, OpaqueRegistrationRequest]:
        """Blind the password for the OPRF and return state + first registration message."""
        r = self._group.random_scalar()
        h_pwd = self._group.hash_to_group(password)
        blinded = self._group.scalar_mult(r, h_pwd)
        state = OpaqueClientRegistrationState(blinding_scalar=r, password=password)
        return state, OpaqueRegistrationRequest(blinded_element=blinded)

    def registration_record(
        self,
        state: OpaqueClientRegistrationState,
        response: OpaqueRegistrationResponse,
    ) -> OpaqueRegistrationRecord:
        """Finalise registration: deblind OPRF output, build credential envelope."""
        r_inv = _scalar_invert(state.blinding_scalar, self._group)
        oprf_out = self._group.scalar_mult(r_inv, response.evaluated_element)
        oprf_x = _extract_x(oprf_out, self._group)

        rw = _hkdf(oprf_x, b"opaque-rw", 32)
        env_key = _hkdf(rw, b"opaque-envelope-key", 32)
        masking_key = _hkdf(rw, b"opaque-masking-key", 32)

        # Deterministic client key pair derived from rw — scalar must match group size
        bl = self._group.byte_len
        sk_c = _hkdf(rw, b"opaque-client-sk", bl)
        pk_c = self._group.scalar_mult(sk_c, self._group.base_point())

        # Envelope plaintext: sk_c || server_public_key
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        nonce = os.urandom(12)
        aes = AESGCM(env_key[:32])
        plaintext = sk_c + response.server_public_key
        ciphertext = aes.encrypt(nonce, plaintext, None)
        envelope = nonce + ciphertext

        return OpaqueRegistrationRecord(
            envelope=envelope,
            masking_key=masking_key,
            client_public_key=pk_c,
        )

    def login_start(
        self, password: bytes
    ) -> Tuple[OpaqueClientLoginState, OpaqueKE1]:
        """Initiate the login AKE. Returns client state and first AKE message."""
        r = self._group.random_scalar()
        h_pwd = self._group.hash_to_group(password)
        cred_req = self._group.scalar_mult(r, h_pwd)

        ek_c = self._group.random_scalar()
        ek_C = self._group.scalar_mult(ek_c, self._group.base_point())

        state = OpaqueClientLoginState(
            blinding_scalar=r,
            password=password,
            eph_private_key=ek_c,
            ke1_credential_request=cred_req,
            ke1_auth_request=ek_C,
        )
        return state, OpaqueKE1(credential_request=cred_req, auth_request=ek_C)

    def login_finish(
        self,
        state: OpaqueClientLoginState,
        ke2: OpaqueKE2,
    ) -> Tuple[OpaqueKE3, bytes]:
        """
        Process server KE2, recover credential, verify server MAC.
        Returns (OpaqueKE3, session_key). Raises AuthenticationError on MAC failure.
        """
        # Step 1: Split credential_response into OPRF element and masked envelope.
        # The OPRF element has the same byte-length as the credential_request.
        oprf_element_size = len(state.ke1_credential_request)
        oprf_element = ke2.credential_response[:oprf_element_size]
        masked_envelope = ke2.credential_response[oprf_element_size:]

        # Step 2: Deblind the OPRF element to recover rw.
        r_inv = _scalar_invert(state.blinding_scalar, self._group)
        oprf_out = self._group.scalar_mult(r_inv, oprf_element)
        oprf_x = _extract_x(oprf_out, self._group)

        rw = _hkdf(oprf_x, b"opaque-rw", 32)
        masking_key = _hkdf(rw, b"opaque-masking-key", 32)
        env_key = _hkdf(rw, b"opaque-envelope-key", 32)

        # Step 3: Unmask and decrypt the envelope to recover the client credential.
        # Wrong password → wrong masking_key → wrong mask → AESGCM decryption fails → AuthError.
        mask = _hkdf(
            masking_key + ke2.masking_nonce,
            b"opaque-credential-mask",
            len(masked_envelope),
        )
        envelope_bytes = bytes(a ^ b for a, b in zip(masked_envelope, mask))
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            aes_nonce = envelope_bytes[:12]
            aes_ciphertext = envelope_bytes[12:]
            plaintext = AESGCM(env_key).decrypt(aes_nonce, aes_ciphertext, None)
        except Exception:
            raise AuthenticationError(
                "Envelope decryption failed: wrong password or tampered credential"
            )

        # Step 4: Parse sk_c (client static private key) from decrypted plaintext.
        bl = self._group.byte_len
        sk_c = plaintext[:bl]

        # Step 5: Parse auth_response → EK_S (server ephemeral public key) + server_mac.
        ek_S = ke2.auth_response[:-32]
        server_mac_recv = ke2.auth_response[-32:]

        # Step 6: Compute DH1 (ephemeral-ephemeral) and DH2 (client static × server ephemeral).
        # If auth_response is tampered, ek_S may be invalid — treat as auth failure.
        try:
            dh1 = _extract_x(self._group.scalar_mult(state.eph_private_key, ek_S), self._group)
        except ValueError:
            raise AuthenticationError(
                "Server MAC verification failed: invalid or tampered auth_response"
            )
        try:
            dh2 = _extract_x(self._group.scalar_mult(sk_c, ek_S), self._group)
        except ValueError:
            raise AuthenticationError(
                "Server MAC verification failed: invalid client credential or auth_response"
            )

        # Step 7: Key derivation — same inputs as server (masking_key = record.masking_key
        # if and only if the correct password was used).
        km_ke = _hkdf(dh1 + dh2 + masking_key, b"opaque-km-ke", 64)
        km, ke = km_ke[:32], km_ke[32:]

        # Step 8: Verify server MAC over the transcript (uses bare OPRF element, not full credential_response).
        transcript_for_mac = (
            state.ke1_credential_request
            + state.ke1_auth_request
            + oprf_element
            + ek_S
            + ke2.masking_nonce
        )
        expected_server_mac = _hmac_sha256(km, transcript_for_mac)
        if not hmac.compare_digest(expected_server_mac, server_mac_recv):
            raise AuthenticationError(
                "Server MAC verification failed: wrong password or tampered transcript"
            )

        # Step 9: Compute client MAC for KE3.
        transcript3 = transcript_for_mac + server_mac_recv
        client_mac = _hmac_sha256(ke, transcript3)

        return OpaqueKE3(auth_finalizer=client_mac), ke


# ─────────────────────────────────────────────────────────────────────────────
# OPAQUE Server
# ─────────────────────────────────────────────────────────────────────────────

class OpaqueServer:
    """Server side of the OPAQUE protocol."""

    def __init__(self, group: Group, server_private_key: bytes, server_public_key: bytes):
        self._group = group
        self._sk_s = server_private_key
        self._pk_s = server_public_key
        # Derive OPRF key from server private key
        bl = group.byte_len
        self._oprf_key = _hkdf(server_private_key, b"opaque-oprf-key", bl)

    def registration_response(
        self, request: OpaqueRegistrationRequest
    ) -> OpaqueRegistrationResponse:
        """Evaluate the OPRF on the client's blinded element."""
        evaluated = self._group.scalar_mult(self._oprf_key, request.blinded_element)
        return OpaqueRegistrationResponse(
            evaluated_element=evaluated,
            server_public_key=self._pk_s,
        )

    def login_respond(
        self,
        ke1: OpaqueKE1,
        record: OpaqueRegistrationRecord,
    ) -> Tuple[OpaqueServerLoginState, OpaqueKE2]:
        """
        Process client KE1. Evaluate OPRF, produce AKE sub-message 2.
        Returns server state and KE2.
        """
        # Evaluate OPRF on the client's blinded credential request
        cred_resp = self._group.scalar_mult(self._oprf_key, ke1.credential_request)
        ek_C = ke1.auth_request

        # Generate fresh masking nonce and mask the stored envelope before sending
        masking_nonce = os.urandom(32)
        mask = _hkdf(
            record.masking_key + masking_nonce,
            b"opaque-credential-mask",
            len(record.envelope),
        )
        masked_envelope = bytes(a ^ b for a, b in zip(record.envelope, mask))

        # credential_response = OPRF element || masked envelope
        # The client splits this using the known size of the OPRF element.
        credential_response = cred_resp + masked_envelope

        # Ephemeral key pair for AKE
        ek_s = self._group.random_scalar()
        ek_S = self._group.scalar_mult(ek_s, self._group.base_point())

        # DH1: ephemeral-ephemeral (ek_s × ek_C = ek_c × ek_S by commutativity)
        dh1 = _extract_x(self._group.scalar_mult(ek_s, ek_C), self._group)

        # DH2: server ephemeral × client static public key — uses record.client_public_key
        # (client computes sk_c × ek_S, recovered from the decrypted envelope)
        dh2 = _extract_x(self._group.scalar_mult(ek_s, record.client_public_key), self._group)

        # Key derivation over both DH components and the stored masking key
        km_ke = _hkdf(dh1 + dh2 + record.masking_key, b"opaque-km-ke", 64)
        km, ke = km_ke[:32], km_ke[32:]

        # Transcript for server MAC uses the bare OPRF element (cred_resp), not full credential_response
        transcript_for_mac = (
            ke1.credential_request
            + ke1.auth_request
            + cred_resp
            + ek_S
            + masking_nonce
        )
        server_mac = _hmac_sha256(km, transcript_for_mac)
        auth_response = ek_S + server_mac

        ke2 = OpaqueKE2(
            credential_response=credential_response,
            auth_response=auth_response,
            masking_nonce=masking_nonce,
        )

        # Pre-compute expected client MAC
        transcript3 = transcript_for_mac + server_mac
        expected_client_mac = _hmac_sha256(ke, transcript3)

        state = OpaqueServerLoginState(ke=ke, expected_client_mac=expected_client_mac)
        return state, ke2

    def login_finalize(
        self,
        state: OpaqueServerLoginState,
        ke3: OpaqueKE3,
    ) -> bytes:
        """
        Verify client MAC in KE3. Returns session key on success.
        Raises AuthenticationError if client MAC fails.
        """
        if not hmac.compare_digest(state.expected_client_mac, ke3.auth_finalizer):
            raise AuthenticationError("Client MAC verification failed")
        return state.ke
