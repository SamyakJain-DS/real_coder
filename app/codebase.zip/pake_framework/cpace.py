"""
CPace Protocol (IRTF CFRG draft surface, draft-irtf-cfrg-cpace).

Both parties hash the shared password, channel identifier, and party identifier
to a group point, apply an ephemeral random scalar, exchange one message each,
and derive a shared session key via ECDH and HKDF.

The protocol is symmetric — both parties use the same CPaceParty class.

Both parties call hash_to_group(password || channel_id || party_id) to derive
a password-bound generator, apply an ephemeral random scalar, exchange one
message each, and derive a shared session key via HKDF.
X25519 is not compatible (raises NotImplementedError — no hash_to_group).
"""

import dataclasses
from typing import Tuple

from .groups import Group


# ─────────────────────────────────────────────────────────────────────────────
# Typed message and state dataclasses
# ─────────────────────────────────────────────────────────────────────────────

@dataclasses.dataclass
class CPaceMessage:
    """Single CPace round message: the party's ephemeral group element."""
    element: bytes


@dataclasses.dataclass
class CPaceState:
    """Intermediate state produced by CPaceParty.start; consumed by CPaceParty.finish."""
    ephemeral_scalar: bytes
    generator: bytes
    group_name: str


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _hkdf(key_material: bytes, info: bytes, length: int) -> bytes:
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives.hashes import SHA256
    h = HKDF(algorithm=SHA256(), length=length, salt=None, info=info)
    return h.derive(key_material)


def _derive_generator(password: bytes, channel_id: bytes, party_id: bytes, group: Group) -> bytes:
    """
    Derive a password-bound generator for CPace via hash_to_group.
    Prompt: "Derives a password-bound generator from the password, channel_id, and party_id
    using the group's hash_to_group primitive."
    X25519 raises NotImplementedError here because it has no hash_to_group.
    """
    return group.hash_to_group(password + channel_id + party_id)


def _extract_shared_bytes(shared: bytes, group: Group) -> bytes:
    """For HKDF input: extract x-coordinate for Weierstrass curves, full bytes otherwise."""
    if group.name == "P-256":
        return shared[1:33]    # 1 prefix byte + 32-byte x-coordinate
    if group.name == "P-384":
        return shared[1:49]    # 1 prefix byte + 48-byte x-coordinate
    return shared


# ─────────────────────────────────────────────────────────────────────────────
# CPace Party
# ─────────────────────────────────────────────────────────────────────────────

class CPaceParty:
    """
    Implements a CPace party. Both the initiator and responder use this class
    (the protocol is symmetric).
    """

    def __init__(self, group: Group):
        self._group = group

    def start(
        self,
        password: bytes,
        channel_id: bytes,
        party_id: bytes,
    ) -> Tuple[CPaceState, CPaceMessage]:
        """
        Derive password-bound generator, apply ephemeral scalar, return state + message.

        generator = hash_to_group(password || channel_id || party_id) per the prompt.
        X25519 raises NotImplementedError at the hash_to_group call.
        """
        generator = _derive_generator(password, channel_id, party_id, self._group)
        y = self._group.random_scalar()
        element = self._group.scalar_mult(y, generator)
        state = CPaceState(
            ephemeral_scalar=y,
            generator=generator,
            group_name=self._group.name,
        )
        return state, CPaceMessage(element=element)

    def finish(self, state: CPaceState, peer_message: CPaceMessage) -> bytes:
        """
        Compute shared secret via ECDH with peer's element, derive session key via HKDF.
        Returns the shared session key.
        """
        shared_pt = self._group.scalar_mult(state.ephemeral_scalar, peer_message.element)
        shared_bytes = _extract_shared_bytes(shared_pt, self._group)
        session_key = _hkdf(shared_bytes, b"CPace-session-key", 32)
        return session_key
