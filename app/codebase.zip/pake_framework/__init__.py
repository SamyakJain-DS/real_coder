"""
pake_framework — Typed Python PAKE Protocol Framework Library.

Re-exports all public classes, functions, and exceptions.
"""

from .exceptions import AuthenticationError

from .groups import (
    Group,
    get_group,
    P256Group,
    P384Group,
    Ristretto255Group,
    X25519Group,
)

from .opaque import (
    OpaqueRegistrationRequest,
    OpaqueRegistrationResponse,
    OpaqueRegistrationRecord,
    OpaqueKE1,
    OpaqueKE2,
    OpaqueKE3,
    OpaqueClientRegistrationState,
    OpaqueClientLoginState,
    OpaqueServerLoginState,
    OpaqueClient,
    OpaqueServer,
)

from .spake2 import (
    SPAKE2Message,
    SPAKE2ConfirmMessage,
    SPAKE2State,
    SPAKE2PlusState,
    SPAKE2Client,
    SPAKE2Server,
    SPAKE2PlusClient,
    SPAKE2PlusServer,
)

from .cpace import (
    CPaceMessage,
    CPaceState,
    CPaceParty,
)

from .augmented import (
    AugmentedEnvelope,
    AugmentedCredentialManager,
)

from .instrumentation import (
    RoundTiming,
    PAKEProfiler,
)

__all__ = [
    # Exceptions
    "AuthenticationError",
    # Group framework
    "Group",
    "get_group",
    "P256Group",
    "P384Group",
    "Ristretto255Group",
    "X25519Group",
    # OPAQUE messages
    "OpaqueRegistrationRequest",
    "OpaqueRegistrationResponse",
    "OpaqueRegistrationRecord",
    "OpaqueKE1",
    "OpaqueKE2",
    "OpaqueKE3",
    # OPAQUE state
    "OpaqueClientRegistrationState",
    "OpaqueClientLoginState",
    "OpaqueServerLoginState",
    # OPAQUE actors
    "OpaqueClient",
    "OpaqueServer",
    # SPAKE2 messages
    "SPAKE2Message",
    "SPAKE2ConfirmMessage",
    # SPAKE2 state
    "SPAKE2State",
    "SPAKE2PlusState",
    # SPAKE2 actors
    "SPAKE2Client",
    "SPAKE2Server",
    "SPAKE2PlusClient",
    "SPAKE2PlusServer",
    # CPace
    "CPaceMessage",
    "CPaceState",
    "CPaceParty",
    # Augmented credential envelope
    "AugmentedEnvelope",
    "AugmentedCredentialManager",
    # Instrumentation
    "RoundTiming",
    "PAKEProfiler",
]
