"""
Augmented Credential Envelope Framework.

The server stores only HKDF-derived, AES-GCM-encrypted material —
never the raw password — providing server compromise resistance.
"""

import dataclasses
import os

from .groups import Group


@dataclasses.dataclass
class AugmentedEnvelope:
    """
    Server-side pre-computed credential envelope.
    Stores the AES-GCM encrypted credential tag, a per-registration nonce,
    and the AES-GCM authentication tag — exclusively HKDF-derived material.
    """
    credential_tag: bytes
    nonce: bytes
    auth_tag: bytes


def _hkdf(key_material: bytes, info: bytes, length: int) -> bytes:
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives.hashes import SHA256
    h = HKDF(algorithm=SHA256(), length=length, salt=None, info=info)
    return h.derive(key_material)


class AugmentedCredentialManager:
    """
    Manages creation and verification of augmented credential envelopes
    using AES-GCM authenticated encryption (cryptography>=41.0.0).
    """

    def __init__(self, group: Group):
        self._group = group

    def create_envelope(self, password_verifier: bytes) -> AugmentedEnvelope:
        """
        Derives a fresh per-envelope nonce and HKDF-based AES-GCM encryption key
        from the password verifier, encrypts the credential tag, and returns a new
        AugmentedEnvelope. Each call produces a distinct envelope even for the same verifier.
        """
        nonce = os.urandom(12)   # standard AES-GCM 96-bit nonce
        enc_key = _hkdf(password_verifier, b"augmented-envelope-enc-key", 32)

        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        aes = AESGCM(enc_key)

        # The credential is HKDF-derived from the verifier (a transformed credential,
        # not the raw password — ensuring server compromise resistance).
        raw_credential = _hkdf(password_verifier, b"augmented-envelope-credential", 32)

        # AES-GCM encrypt: returns ciphertext || 16-byte auth tag
        aes_output = aes.encrypt(nonce, raw_credential, None)
        credential_tag = aes_output[:-16]   # ciphertext
        auth_tag = aes_output[-16:]          # GCM authentication tag

        return AugmentedEnvelope(
            credential_tag=credential_tag,
            nonce=nonce,
            auth_tag=auth_tag,
        )

    def verify_envelope(self, password_verifier: bytes, envelope: AugmentedEnvelope) -> bool:
        """
        Verifies that password_verifier is consistent with the stored envelope by
        recomputing the expected authentication tag and comparing in constant time
        via AES-GCM decryption (which authenticates in constant time internally).
        Returns True if valid, False otherwise.
        """
        try:
            enc_key = _hkdf(password_verifier, b"augmented-envelope-enc-key", 32)
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            aes = AESGCM(enc_key)
            # Reconstruct the full AES-GCM ciphertext: credential_tag || auth_tag
            aes_output = envelope.credential_tag + envelope.auth_tag
            aes.decrypt(envelope.nonce, aes_output, None)
            return True
        except Exception:
            return False
