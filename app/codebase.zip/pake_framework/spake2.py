"""
SPAKE2 (RFC 9382) and SPAKE2+ (augmented variant) protocols.

SPAKE2:
  Both parties hold the same password. Each sends one blinded message.
  Key confirmation is mandatory (RFC 9382 §4): confirmP (client) and confirmV (server).
  Transcript TT follows RFC 9382 §4 with 8-byte LE length-prefixed fields:
      TT = len(A)||A || len(B)||B || len(S)||S || len(T)||T || len(K)||K || len(w)||w

SPAKE2+:
  Server stores a pre-computed verifier (w0 || W1), not the raw password.
  Role-differentiated blinding factors provide server-compromise resistance.
  Transcript includes client/server identities, both message elements,
  shared key K, and the w0 verifier scalar.
"""

import dataclasses
import hashlib
import hmac
import os
from typing import Tuple

from .exceptions import AuthenticationError
from .groups import Group


# ─────────────────────────────────────────────────────────────────────────────
# Typed message dataclasses
# ─────────────────────────────────────────────────────────────────────────────

@dataclasses.dataclass
class SPAKE2Message:
    """Single SPAKE2 or SPAKE2+ round message carrying a blinded group element."""
    element: bytes


@dataclasses.dataclass
class SPAKE2ConfirmMessage:
    """Key-confirmation MAC produced after the initial message exchange (RFC 9382 §4)."""
    mac: bytes


# ─────────────────────────────────────────────────────────────────────────────
# Intermediate state dataclasses
# ─────────────────────────────────────────────────────────────────────────────

@dataclasses.dataclass
class SPAKE2State:
    """Intermediate state produced by SPAKE2Client.start / SPAKE2Server.start."""
    random_scalar: bytes
    blinded_element: bytes
    password: bytes
    role: str             # "client" or "server"
    group_name: str
    client_identity: bytes = b""
    server_identity: bytes = b""


@dataclasses.dataclass
class SPAKE2PlusState:
    """Intermediate state produced by SPAKE2PlusClient.start / SPAKE2PlusServer.start."""
    random_scalar: bytes
    blinded_element: bytes
    w0: bytes
    w1: bytes
    role: str             # "client" or "server"
    client_identity: bytes
    server_identity: bytes
    group_name: str


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _hkdf(key_material: bytes, info: bytes, length: int) -> bytes:
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives.hashes import SHA256
    h = HKDF(algorithm=SHA256(), length=length, salt=None, info=info)
    return h.derive(key_material)


def _hmac_sha256(key: bytes, data: bytes) -> bytes:
    return hmac.new(key, data, hashlib.sha256).digest()


def _encode_len_prefixed(data: bytes) -> bytes:
    """Encode data with 8-byte little-endian length prefix (RFC 9382 §4)."""
    return len(data).to_bytes(8, "little") + data


def _build_spake2_tt(
    A: bytes, B: bytes, S: bytes, T: bytes, K_bytes: bytes, w_bytes: bytes
) -> bytes:
    """
    Build the RFC 9382 §4 transcript TT:
        TT = len(A)||A || len(B)||B || len(S)||S || len(T)||T || len(K)||K || len(w)||w
    All lengths are 8-byte little-endian. S = server element, T = client element.
    """
    return (
        _encode_len_prefixed(A)
        + _encode_len_prefixed(B)
        + _encode_len_prefixed(S)
        + _encode_len_prefixed(T)
        + _encode_len_prefixed(K_bytes)
        + _encode_len_prefixed(w_bytes)
    )


def _pw_to_scalar(password: bytes, label: bytes, group: Group) -> bytes:
    """Derive a deterministic scalar from a password using HKDF."""
    name = group.name
    bl = group.byte_len
    if name in ("P-256", "P-384"):
        from .groups import _P256, _P384
        c = _P256 if name == "P-256" else _P384
        raw = _hkdf(password, label, bl * 2)
        k = int.from_bytes(raw, "big") % c.n
        if k == 0:
            k = 1
        return k.to_bytes(bl, "big")
    elif name == "ristretto255":
        import nacl.bindings as nb
        h = hashlib.sha512(label + password).digest()
        return nb.crypto_core_ed25519_scalar_reduce(h)
    else:
        raise NotImplementedError("X25519 backend is not compatible with SPAKE2 / SPAKE2+")


def _scalar_negate(scalar_bytes: bytes, group: Group) -> bytes:
    """Return the additive negation of a scalar: -s mod order."""
    name = group.name
    bl = group.byte_len
    if name in ("P-256", "P-384"):
        from .groups import _P256, _P384
        c = _P256 if name == "P-256" else _P384
        k = int.from_bytes(scalar_bytes, "big") % c.n
        neg = (c.n - k) % c.n
        return neg.to_bytes(bl, "big")
    elif name == "ristretto255":
        import nacl.bindings as nb
        return nb.crypto_core_ed25519_scalar_negate(scalar_bytes)
    else:
        raise NotImplementedError(f"Scalar negation not supported for {name}")


def _get_blinding_points(group: Group) -> Tuple[bytes, bytes]:
    """Return fixed blinding points M (client) and N (server) for a given group."""
    M = group.hash_to_group(b"SPAKE2 M blinding point " + group.name.encode())
    N = group.hash_to_group(b"SPAKE2 N blinding point " + group.name.encode())
    return M, N


def _extract_key_bytes(point_bytes: bytes, group: Group) -> bytes:
    """Extract bytes for HKDF from a point (x-coordinate for Weierstrass curves)."""
    if group.name in ("P-256", "P-384"):
        bl = group.byte_len
        return point_bytes[1 : 1 + bl]
    return point_bytes


# ─────────────────────────────────────────────────────────────────────────────
# Confirmation state (internal)
# ─────────────────────────────────────────────────────────────────────────────

@dataclasses.dataclass
class _SPAKE2ConfirmState:
    session_key: bytes
    expected_peer_mac: bytes


# ─────────────────────────────────────────────────────────────────────────────
# SPAKE2 Client
# ─────────────────────────────────────────────────────────────────────────────

class SPAKE2Client:
    """Client side of SPAKE2 (RFC 9382)."""

    def __init__(self, group: Group):
        self._group = group
        self._confirm_state: dict = {}

    def start(
        self,
        password: bytes,
    ) -> Tuple[SPAKE2State, SPAKE2Message]:
        """
        Generate random scalar, compute blinded element T = x*G + w*M.
        Identity strings are empty bytes per the prompt interface (password: bytes only).
        """
        M, _ = _get_blinding_points(self._group)
        x = self._group.random_scalar()
        w = _pw_to_scalar(password, b"SPAKE2-password-scalar", self._group)
        xG = self._group.scalar_mult(x, self._group.base_point())
        wM = self._group.scalar_mult(w, M)
        T = self._group.point_add(xG, wM)
        state = SPAKE2State(
            random_scalar=x,
            blinded_element=T,
            password=password,
            role="client",
            group_name=self._group.name,
            client_identity=b"",
            server_identity=b"",
        )
        return state, SPAKE2Message(element=T)

    def finish(
        self, state: SPAKE2State, server_message: SPAKE2Message
    ) -> Tuple[bytes, SPAKE2ConfirmMessage]:
        """
        Derive session key and return (session_key, confirmP).
        Transcript follows RFC 9382 §4: TT includes both party identities,
        both message elements, the shared group element K, and the password scalar w.
        Must call confirm() with server's confirmV before using the session key.
        """
        _, N = _get_blinding_points(self._group)
        w = _pw_to_scalar(state.password, b"SPAKE2-password-scalar", self._group)
        neg_w = _scalar_negate(w, self._group)

        S = server_message.element
        neg_wN = self._group.scalar_mult(neg_w, N)
        S_minus_wN = self._group.point_add(S, neg_wN)
        K_pt = self._group.scalar_mult(state.random_scalar, S_minus_wN)

        K_bytes = _extract_key_bytes(K_pt, self._group)
        T = state.blinded_element

        # RFC 9382 §4 transcript: TT = len(A)||A||len(B)||B||len(S)||S||len(T)||T||len(K)||K||len(w)||w
        tt = _build_spake2_tt(
            A=state.client_identity,
            B=state.server_identity,
            S=S,
            T=T,
            K_bytes=K_bytes,
            w_bytes=w,
        )

        # Derive session key and confirmation keys from TT
        ka_ke = _hkdf(tt, b"SPAKE2-Ka-and-Ke", 64)
        Ka, session_key = ka_ke[:32], ka_ke[32:]

        # confirmP = HMAC(Ka, "SPAKE2 Confirm A" || TT)
        confirm_P = _hmac_sha256(Ka, b"SPAKE2 Confirm A" + tt)
        # Expected server confirmV
        expected_V = _hmac_sha256(Ka, b"SPAKE2 Confirm B" + tt)

        self._confirm_state[id(state)] = _SPAKE2ConfirmState(
            session_key=session_key,
            expected_peer_mac=expected_V,
        )

        return session_key, SPAKE2ConfirmMessage(mac=confirm_P)

    def confirm(
        self, session_key: bytes, server_confirm: SPAKE2ConfirmMessage
    ) -> bytes:
        """
        Verify server confirmV MAC in constant time.
        Returns session_key on success; raises AuthenticationError on mismatch.
        """
        stored = None
        for cs in self._confirm_state.values():
            if hmac.compare_digest(cs.session_key, session_key):
                stored = cs
                break
        if stored is None:
            raise AuthenticationError("No matching SPAKE2 session found for confirm()")

        if not hmac.compare_digest(stored.expected_peer_mac, server_confirm.mac):
            raise AuthenticationError(
                "SPAKE2 key-confirmation MAC mismatch: wrong password or tampered transcript"
            )
        return session_key


# ─────────────────────────────────────────────────────────────────────────────
# SPAKE2 Server
# ─────────────────────────────────────────────────────────────────────────────

class SPAKE2Server:
    """Server side of SPAKE2 (RFC 9382)."""

    def __init__(self, group: Group):
        self._group = group
        self._confirm_state: dict = {}

    def start(
        self,
        password: bytes,
    ) -> Tuple[SPAKE2State, SPAKE2Message]:
        """
        Generate random scalar, compute blinded element S = y*G + w*N.
        Identity strings default to empty bytes per the prompt interface.
        """
        _, N = _get_blinding_points(self._group)
        y = self._group.random_scalar()
        w = _pw_to_scalar(password, b"SPAKE2-password-scalar", self._group)
        yG = self._group.scalar_mult(y, self._group.base_point())
        wN = self._group.scalar_mult(w, N)
        S = self._group.point_add(yG, wN)
        state = SPAKE2State(
            random_scalar=y,
            blinded_element=S,
            password=password,
            role="server",
            group_name=self._group.name,
            client_identity=b"",
            server_identity=b"",
        )
        return state, SPAKE2Message(element=S)

    def finish(
        self, state: SPAKE2State, client_message: SPAKE2Message
    ) -> Tuple[bytes, SPAKE2ConfirmMessage]:
        """
        Derive session key and return (session_key, confirmV).
        Transcript follows RFC 9382 §4.
        Must call confirm() with client's confirmP before using the session key.
        """
        M, _ = _get_blinding_points(self._group)
        w = _pw_to_scalar(state.password, b"SPAKE2-password-scalar", self._group)
        neg_w = _scalar_negate(w, self._group)

        T = client_message.element
        neg_wM = self._group.scalar_mult(neg_w, M)
        T_minus_wM = self._group.point_add(T, neg_wM)
        K_pt = self._group.scalar_mult(state.random_scalar, T_minus_wM)

        K_bytes = _extract_key_bytes(K_pt, self._group)
        S = state.blinded_element

        # RFC 9382 §4 transcript
        tt = _build_spake2_tt(
            A=state.client_identity,
            B=state.server_identity,
            S=S,
            T=T,
            K_bytes=K_bytes,
            w_bytes=w,
        )

        ka_ke = _hkdf(tt, b"SPAKE2-Ka-and-Ke", 64)
        Ka, session_key = ka_ke[:32], ka_ke[32:]

        # confirmV = HMAC(Ka, "SPAKE2 Confirm B" || TT)
        confirm_V = _hmac_sha256(Ka, b"SPAKE2 Confirm B" + tt)
        expected_P = _hmac_sha256(Ka, b"SPAKE2 Confirm A" + tt)

        self._confirm_state[id(state)] = _SPAKE2ConfirmState(
            session_key=session_key,
            expected_peer_mac=expected_P,
        )

        return session_key, SPAKE2ConfirmMessage(mac=confirm_V)

    def confirm(
        self, session_key: bytes, client_confirm: SPAKE2ConfirmMessage
    ) -> bytes:
        """
        Verify client confirmP MAC in constant time.
        Returns session_key on success; raises AuthenticationError on mismatch.
        """
        stored = None
        for cs in self._confirm_state.values():
            if hmac.compare_digest(cs.session_key, session_key):
                stored = cs
                break
        if stored is None:
            raise AuthenticationError("No matching SPAKE2 session found for confirm()")

        if not hmac.compare_digest(stored.expected_peer_mac, client_confirm.mac):
            raise AuthenticationError(
                "SPAKE2 key-confirmation MAC mismatch: wrong password or tampered transcript"
            )
        return session_key


# ─────────────────────────────────────────────────────────────────────────────
# SPAKE2+ helpers
# ─────────────────────────────────────────────────────────────────────────────

def _derive_w0_w1(password: bytes, group: Group) -> Tuple[bytes, bytes]:
    """Derive w0 and w1 from password for SPAKE2+."""
    w0 = _pw_to_scalar(password, b"SPAKE2plus-w0", group)
    w1 = _pw_to_scalar(password, b"SPAKE2plus-w1", group)
    return w0, w1


@dataclasses.dataclass
class _SPAKE2PlusConfirmState:
    session_key: bytes
    expected_peer_mac: bytes


def _build_spake2plus_tt(
    A: bytes,
    B: bytes,
    T: bytes,
    S: bytes,
    K_bytes: bytes,
    L_bytes: bytes,
    w0: bytes,
) -> bytes:
    """
    Build the SPAKE2+ transcript TT (RFC 9382 §4 extended for augmented variant):
        TT = len(A)||A || len(B)||B || len(T)||T || len(S)||S
             || len(K)||K || len(L)||L || len(w0)||w0
    L = w1*G (client's long-term public element); w0 is the password verifier scalar.
    """
    return (
        _encode_len_prefixed(A)
        + _encode_len_prefixed(B)
        + _encode_len_prefixed(T)
        + _encode_len_prefixed(S)
        + _encode_len_prefixed(K_bytes)
        + _encode_len_prefixed(L_bytes)
        + _encode_len_prefixed(w0)
    )


# ─────────────────────────────────────────────────────────────────────────────
# SPAKE2+ Client
# ─────────────────────────────────────────────────────────────────────────────

class SPAKE2PlusClient:
    """Client side of SPAKE2+. Holds raw password; server holds verifier only."""

    def __init__(self, group: Group):
        self._group = group
        self._confirm_state: dict = {}

    def start(
        self,
        password: bytes,
        client_identity: bytes,
        server_identity: bytes,
    ) -> Tuple[SPAKE2PlusState, SPAKE2Message]:
        """Initiate SPAKE2+ from client role. T = x*G + w0*M."""
        M, _ = _get_blinding_points(self._group)
        x = self._group.random_scalar()
        w0, w1 = _derive_w0_w1(password, self._group)
        xG = self._group.scalar_mult(x, self._group.base_point())
        w0M = self._group.scalar_mult(w0, M)
        T = self._group.point_add(xG, w0M)
        state = SPAKE2PlusState(
            random_scalar=x,
            blinded_element=T,
            w0=w0,
            w1=w1,
            role="client",
            client_identity=client_identity,
            server_identity=server_identity,
            group_name=self._group.name,
        )
        return state, SPAKE2Message(element=T)

    def finish(
        self, state: SPAKE2PlusState, server_message: SPAKE2Message
    ) -> Tuple[bytes, SPAKE2ConfirmMessage]:
        """
        Derive session key and return (session_key, confirmP).
        Transcript follows RFC 9382 §4 (augmented): includes both party identities,
        both message elements, shared key K, L = w1*G, and w0 scalar.
        """
        _, N = _get_blinding_points(self._group)
        neg_w0 = _scalar_negate(state.w0, self._group)

        S = server_message.element
        neg_w0N = self._group.scalar_mult(neg_w0, N)
        S_minus_w0N = self._group.point_add(S, neg_w0N)
        K_pt = self._group.scalar_mult(state.random_scalar, S_minus_w0N)
        K_bytes = _extract_key_bytes(K_pt, self._group)

        # L = w1*G (client's long-term public contribution)
        L = self._group.scalar_mult(state.w1, self._group.base_point())
        L_bytes = _extract_key_bytes(L, self._group)

        T = state.blinded_element
        tt = _build_spake2plus_tt(
            A=state.client_identity,
            B=state.server_identity,
            T=T,
            S=S,
            K_bytes=K_bytes,
            L_bytes=L_bytes,
            w0=state.w0,
        )

        ka_ke = _hkdf(tt, b"SPAKE2plus-Ka-and-Ke", 64)
        Ka, session_key = ka_ke[:32], ka_ke[32:]

        confirm_P = _hmac_sha256(Ka, b"SPAKE2plus Confirm A" + tt)
        expected_V = _hmac_sha256(Ka, b"SPAKE2plus Confirm B" + tt)

        self._confirm_state[id(state)] = _SPAKE2PlusConfirmState(
            session_key=session_key,
            expected_peer_mac=expected_V,
        )

        return session_key, SPAKE2ConfirmMessage(mac=confirm_P)

    def confirm(
        self, session_key: bytes, server_confirm: SPAKE2ConfirmMessage
    ) -> bytes:
        """Verify server confirmV. Returns session_key on success; raises AuthenticationError."""
        stored = None
        for cs in self._confirm_state.values():
            if hmac.compare_digest(cs.session_key, session_key):
                stored = cs
                break
        if stored is None:
            raise AuthenticationError("No matching SPAKE2+ session found")

        if not hmac.compare_digest(stored.expected_peer_mac, server_confirm.mac):
            raise AuthenticationError(
                "SPAKE2+ key-confirmation MAC mismatch: wrong password or tampered transcript"
            )
        return session_key


# ─────────────────────────────────────────────────────────────────────────────
# SPAKE2+ Server
# ─────────────────────────────────────────────────────────────────────────────

class SPAKE2PlusServer:
    """Server side of SPAKE2+. Operates on a pre-computed password verifier."""

    def __init__(self, group: Group):
        self._group = group
        self._confirm_state: dict = {}

    def create_verifier(self, password: bytes) -> bytes:
        """
        Derive and return the SPAKE2+ server-side password verifier.
        The verifier encodes w0 || W1 where W1 = w1*G.
        Stored server-side in place of the raw password.
        """
        w0, w1 = _derive_w0_w1(password, self._group)
        W1 = self._group.scalar_mult(w1, self._group.base_point())
        return w0 + W1

    def start(
        self,
        verifier: bytes,
        client_identity: bytes,
        server_identity: bytes,
    ) -> Tuple[SPAKE2PlusState, SPAKE2Message]:
        """Initiate SPAKE2+ from server role using stored verifier. S = y*G + w0*N."""
        _, N = _get_blinding_points(self._group)
        bl = self._group.byte_len
        point_len = 2 * bl + 1 if self._group.name in ("P-256", "P-384") else bl
        w0 = verifier[:bl]
        W1 = verifier[bl : bl + point_len]
        y = self._group.random_scalar()
        yG = self._group.scalar_mult(y, self._group.base_point())
        w0N = self._group.scalar_mult(w0, N)
        S = self._group.point_add(yG, w0N)
        state = SPAKE2PlusState(
            random_scalar=y,
            blinded_element=S,
            w0=w0,
            w1=W1,   # server stores W1 (= w1*G, public) not the raw w1 scalar
            role="server",
            client_identity=client_identity,
            server_identity=server_identity,
            group_name=self._group.name,
        )
        return state, SPAKE2Message(element=S)

    def finish(
        self, state: SPAKE2PlusState, client_message: SPAKE2Message
    ) -> Tuple[bytes, SPAKE2ConfirmMessage]:
        """
        Derive session key and return (session_key, confirmV).
        Transcript follows RFC 9382 §4 (augmented).
        """
        M, _ = _get_blinding_points(self._group)
        neg_w0 = _scalar_negate(state.w0, self._group)

        T = client_message.element
        neg_w0M = self._group.scalar_mult(neg_w0, M)
        T_minus_w0M = self._group.point_add(T, neg_w0M)
        K_pt = self._group.scalar_mult(state.random_scalar, T_minus_w0M)
        K_bytes = _extract_key_bytes(K_pt, self._group)

        # Server has W1 = w1*G (public); client computes L = w1*G the same way
        W1 = state.w1
        L_bytes = _extract_key_bytes(W1, self._group)

        S = state.blinded_element
        tt = _build_spake2plus_tt(
            A=state.client_identity,
            B=state.server_identity,
            T=T,
            S=S,
            K_bytes=K_bytes,
            L_bytes=L_bytes,
            w0=state.w0,
        )

        ka_ke = _hkdf(tt, b"SPAKE2plus-Ka-and-Ke", 64)
        Ka, session_key = ka_ke[:32], ka_ke[32:]

        confirm_V = _hmac_sha256(Ka, b"SPAKE2plus Confirm B" + tt)
        expected_P = _hmac_sha256(Ka, b"SPAKE2plus Confirm A" + tt)

        self._confirm_state[id(state)] = _SPAKE2PlusConfirmState(
            session_key=session_key,
            expected_peer_mac=expected_P,
        )

        return session_key, SPAKE2ConfirmMessage(mac=confirm_V)

    def confirm(
        self, session_key: bytes, client_confirm: SPAKE2ConfirmMessage
    ) -> bytes:
        """Verify client confirmP. Returns session_key on success; raises AuthenticationError."""
        stored = None
        for cs in self._confirm_state.values():
            if hmac.compare_digest(cs.session_key, session_key):
                stored = cs
                break
        if stored is None:
            raise AuthenticationError("No matching SPAKE2+ session found")

        if not hmac.compare_digest(stored.expected_peer_mac, client_confirm.mac):
            raise AuthenticationError(
                "SPAKE2+ key-confirmation MAC mismatch: wrong password or tampered transcript"
            )
        return session_key
