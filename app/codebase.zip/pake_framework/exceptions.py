"""
Exceptions for the PAKE framework library.
"""


class AuthenticationError(Exception):
    """
    Raised whenever a MAC verification step fails during any protocol's
    authentication flow. Covers OPAQUE AKE MAC failures and SPAKE2/SPAKE2+/CPace
    key-confirmation MAC mismatches.
    """
