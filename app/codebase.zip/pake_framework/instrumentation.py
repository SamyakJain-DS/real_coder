"""
Typed instrumentation surface for per-protocol round throughput profiling.
PAKEProfiler is thread-safe and aggregates wall-clock timings in nanoseconds.
"""

import dataclasses
import threading
import time
from typing import Any, Callable, Dict, List


@dataclasses.dataclass
class RoundTiming:
    """Records the timing of one protocol round execution."""
    protocol_name: str
    round_label: str
    elapsed_ns: int


class PAKEProfiler:
    """
    Thread-safe collector of per-round timing records across multiple protocol executions.
    Accumulates RoundTiming entries and computes per-key throughput statistics on demand.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._records: List[RoundTiming] = []

    def profile_round(
        self,
        protocol_name: str,
        round_label: str,
        fn: Callable[..., Any],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Call fn(*args, **kwargs), record wall-clock elapsed time as a RoundTiming
        entry keyed by protocol_name and round_label, and return the result of fn.
        Safe to call from multiple threads simultaneously.
        """
        start = time.perf_counter_ns()
        result = fn(*args, **kwargs)
        elapsed_ns = time.perf_counter_ns() - start

        entry = RoundTiming(
            protocol_name=protocol_name,
            round_label=round_label,
            elapsed_ns=elapsed_ns,
        )
        with self._lock:
            self._records.append(entry)

        return result

    def get_report(self) -> Dict[str, Dict[str, float]]:
        """
        Returns a nested dict mapping protocol_name → round_label → average throughput
        in rounds per second (1e9 / mean(elapsed_ns)).
        Returns an empty dict if no rounds have been profiled.
        """
        with self._lock:
            records = list(self._records)

        if not records:
            return {}

        # Group timings by (protocol_name, round_label)
        grouped: Dict[str, Dict[str, List[int]]] = {}
        for r in records:
            if r.protocol_name not in grouped:
                grouped[r.protocol_name] = {}
            if r.round_label not in grouped[r.protocol_name]:
                grouped[r.protocol_name][r.round_label] = []
            grouped[r.protocol_name][r.round_label].append(r.elapsed_ns)

        report: Dict[str, Dict[str, float]] = {}
        for protocol, rounds in grouped.items():
            report[protocol] = {}
            for label, timings in rounds.items():
                mean_ns = sum(timings) / len(timings)
                report[protocol][label] = 1e9 / mean_ns if mean_ns > 0 else 0.0

        return report
