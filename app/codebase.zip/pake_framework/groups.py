"""
Group abstraction and concrete backends for PAKE protocols.

Backends:
  P-256          — full-featured; constant-time scalar_mult/point_add via OpenSSL
  P-384          — full-featured; constant-time scalar_mult/point_add via OpenSSL
  ristretto255   — full-featured (via PyNaCl / libsodium)
  X25519         — DH-only (scalar_mult, base_point, random_scalar only)

Constant-time guarantee:
  scalar_mult on all four backends uses constant-time primitives: P-256/P-384 call
  OpenSSL EC_POINT_mul (the same OpenSSL that backs cryptography>=41.0.0); ristretto255
  uses PyNaCl/libsodium; X25519 uses the cryptography library's X25519PrivateKey.
"""

import ctypes
import ctypes.util
import hashlib
import os
import pathlib
import sys
from abc import ABC, abstractmethod

# ─────────────────────────────────────────────────────────────────────────────
# Pure-Python curve constants (used only for RFC 9380 hash_to_group — no secrets)
# ─────────────────────────────────────────────────────────────────────────────

class _CurveParams:
    __slots__ = ("p", "a", "b", "n", "gx", "gy", "byte_len")

    def __init__(self, p, a, b, n, gx, gy, byte_len):
        self.p = p
        self.a = a
        self.b = b
        self.n = n
        self.gx = gx
        self.gy = gy
        self.byte_len = byte_len


_P256 = _CurveParams(
    p=0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF,
    a=0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFC,
    b=0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B,
    n=0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551,
    gx=0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
    gy=0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5,
    byte_len=32,
)

def _p384_prime():
    return (1 << 384) - (1 << 128) - (1 << 96) + (1 << 32) - 1

_P384_P = _p384_prime()
_P384 = _CurveParams(
    p=_P384_P,
    a=_P384_P - 3,
    b=0xB3312FA7E23EE7E4988E056BE3F82D19181D9C6EFE8141120314088F5013875AC656398D8A2ED19D2A85C8EDD3EC2AEF,
    n=0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC7634D81F4372DDF581A0DB248B0A77AECEC196ACCC52973,
    gx=0xAA87CA22BE8B05378EB1C71EF320AD746E1D3B628BA79B9859F741E082542A385502F25DBF55296C3A545E3872760AB7,
    gy=0x3617DE4A96262C6F5D9E98BF9292DC29F8F41DBD289A147CE9DA3113B5F0B8C00A60B1CE1D7E819D7A431D7C90EA0E5F,
    byte_len=48,
)


# ─────────────────────────────────────────────────────────────────────────────
# Pure-Python EC arithmetic (for RFC 9380 hash_to_group — no secret scalars used)
# ─────────────────────────────────────────────────────────────────────────────

class _ECPoint:
    """Affine EC point; used only for hash_to_group (no secret scalar involved)."""

    def __init__(self, x, y, curve: _CurveParams):
        self.x = x
        self.y = y
        self.curve = curve

    @property
    def is_infinity(self) -> bool:
        return self.x is None

    @classmethod
    def infinity(cls, curve: _CurveParams) -> "_ECPoint":
        return cls(None, None, curve)

    def __eq__(self, other) -> bool:
        return self.x == other.x and self.y == other.y

    def __neg__(self) -> "_ECPoint":
        if self.is_infinity:
            return self
        return _ECPoint(self.x, (-self.y) % self.curve.p, self.curve)

    def __add__(self, other: "_ECPoint") -> "_ECPoint":
        if self.is_infinity:
            return other
        if other.is_infinity:
            return self
        p, a = self.curve.p, self.curve.a
        if self.x == other.x:
            if (self.y + other.y) % p == 0:
                return _ECPoint.infinity(self.curve)
            lam = (3 * self.x * self.x + a) * pow(2 * self.y, p - 2, p) % p
        else:
            lam = (other.y - self.y) * pow(other.x - self.x, p - 2, p) % p
        x3 = (lam * lam - self.x - other.x) % p
        y3 = (lam * (self.x - x3) - self.y) % p
        return _ECPoint(x3, y3, self.curve)

    def to_uncompressed_bytes(self) -> bytes:
        bl = self.curve.byte_len
        if self.is_infinity:
            return b"\x00" * (2 * bl + 1)
        return b"\x04" + self.x.to_bytes(bl, "big") + self.y.to_bytes(bl, "big")

    @classmethod
    def from_uncompressed_bytes(cls, data: bytes, curve: _CurveParams) -> "_ECPoint":
        bl = curve.byte_len
        expected = 2 * bl + 1
        if len(data) != expected or data[0] != 0x04:
            raise ValueError(
                f"Invalid uncompressed point: expected {expected} bytes starting with 0x04"
            )
        x = int.from_bytes(data[1 : 1 + bl], "big")
        y = int.from_bytes(data[1 + bl :], "big")
        return cls(x, y, curve)


def _ec_base_point(curve: _CurveParams) -> bytes:
    return _ECPoint(curve.gx, curve.gy, curve).to_uncompressed_bytes()


def _ec_random_scalar(curve: _CurveParams) -> bytes:
    """Uniform rejection sampling — no modulo bias."""
    while True:
        raw = os.urandom(curve.byte_len)
        k = int.from_bytes(raw, "big")
        if 0 < k < curve.n:
            return k.to_bytes(curve.byte_len, "big")


# ─── RFC 9380 hash_to_group helpers (pure Python — operates on public data) ───

def _expand_message_xmd(msg: bytes, dst: bytes, length: int, hash_cls) -> bytes:
    """RFC 9380 §5.3.1 expand_message_xmd."""
    b_len = hash_cls().digest_size
    r_len = hash_cls().block_size
    ell = (length + b_len - 1) // b_len
    dst_prime = dst + bytes([len(dst)])
    z_pad = bytes(r_len)
    lib_str = length.to_bytes(2, "big")
    msg_prime = z_pad + msg + lib_str + b"\x00" + dst_prime
    b0 = hash_cls(msg_prime).digest()
    b1 = hash_cls(b0 + b"\x01" + dst_prime).digest()
    blocks = [b1]
    for i in range(2, ell + 1):
        xored = bytes(x ^ y for x, y in zip(b0, blocks[-1]))
        blocks.append(hash_cls(xored + bytes([i]) + dst_prime).digest())
    return b"".join(blocks)[:length]


def _hash_to_field(msg: bytes, count: int, p: int, L: int, hash_cls, dst: bytes) -> list[int]:
    """RFC 9380 §5.3 hash_to_field."""
    uniform_bytes = _expand_message_xmd(msg, dst, count * L, hash_cls)
    return [
        int.from_bytes(uniform_bytes[i * L : (i + 1) * L], "big") % p
        for i in range(count)
    ]


def _sgn0(x: int, p: int) -> int:
    return x % 2


def _sqrt_ratio_3mod4(u: int, v: int, p: int, Z: int) -> tuple[bool, int]:
    """RFC 9380 Appendix I.1 sqrt_ratio for p ≡ 3 mod 4."""
    if v == 0:
        return True, 0
    v_inv = pow(v, p - 2, p)
    uv = u * v_inv % p
    is_square = pow(uv, (p - 1) // 2, p) == 1
    if is_square:
        return True, pow(uv, (p + 1) // 4, p)
    zuv = Z * uv % p
    return False, pow(zuv, (p + 1) // 4, p)


def _map_to_curve_simple_swu(u: int, p: int, A: int, B: int, Z: int) -> tuple[int, int]:
    """RFC 9380 §6.6.2 simplified SWU for y² = x³ + Ax + B, p ≡ 3 mod 4."""
    tv1 = Z * u % p * u % p
    tv2 = (tv1 * tv1 + tv1) % p
    tv3 = (tv2 + 1) % p
    tv3 = B * tv3 % p
    tv4 = Z if tv2 == 0 else (-tv2 % p)
    tv4 = A * tv4 % p
    tv2 = tv3 * tv3 % p
    tv6 = tv4 * tv4 % p
    tv5 = A * tv6 % p
    tv2 = (tv2 + tv5) % p
    tv2 = tv2 * tv3 % p
    tv6 = tv6 * tv4 % p
    tv5 = B * tv6 % p
    tv2 = (tv2 + tv5) % p
    x = tv1 * tv3 % p
    is_gx1_square, y1 = _sqrt_ratio_3mod4(tv2, tv6, p, Z)
    y = tv1 * u % p * y1 % p
    if is_gx1_square:
        x = tv3
        y = y1
    if _sgn0(u, p) != _sgn0(y, p):
        y = (-y) % p
    x = x * pow(tv4, p - 2, p) % p
    return x, y


_P256_SSWU_Z = _P256.p - 10


def _get_p384_sswu_z() -> int:
    return _P384.p - 12


def _ec_hash_to_group(data: bytes, curve: _CurveParams, domain: str) -> bytes:
    """RFC 9380 hash-to-curve using SSWU for P-256/P-384."""
    if curve.byte_len == 48:
        hash_cls = hashlib.sha384
        dst = b"P384_XMD:SHA-384_SSWU_RO_" + domain.encode()
        L = 72
        Z = _get_p384_sswu_z()
    else:
        hash_cls = hashlib.sha256
        dst = b"P256_XMD:SHA-256_SSWU_RO_" + domain.encode()
        L = 48
        Z = _P256_SSWU_Z
    u0, u1 = _hash_to_field(data, 2, curve.p, L, hash_cls, dst)
    x0, y0 = _map_to_curve_simple_swu(u0, curve.p, curve.a, curve.b, Z)
    x1, y1 = _map_to_curve_simple_swu(u1, curve.p, curve.a, curve.b, Z)
    pt0 = _ECPoint(x0, y0, curve)
    pt1 = _ECPoint(x1, y1, curve)
    result = pt0 + pt1
    return result.to_uncompressed_bytes()


# ─────────────────────────────────────────────────────────────────────────────
# OpenSSL ctypes backend for constant-time P-256 / P-384 scalar_mult / point_add
#
# Loads the same OpenSSL that backs the cryptography>=41.0.0 package.
# EC_POINT_mul uses OpenSSL's constant-time wNAF / Montgomery ladder internally.
# ─────────────────────────────────────────────────────────────────────────────

_POINT_CONVERSION_UNCOMPRESSED = 4
_NID_P256 = 415   # NID_X9_62_prime256v1
_NID_P384 = 715   # NID_secp384r1

_libcrypto: ctypes.CDLL | None = None
_cached_ec_groups: dict[int, int] = {}   # NID → EC_GROUP* value


def _setup_libcrypto_types(lib: ctypes.CDLL) -> None:
    """Configure ctypes argtypes / restypes for the OpenSSL EC functions we use."""
    V = ctypes.c_void_p
    I = ctypes.c_int
    S = ctypes.c_size_t
    C = ctypes.c_char_p

    lib.EC_GROUP_new_by_curve_name.restype = V;  lib.EC_GROUP_new_by_curve_name.argtypes = [I]
    lib.EC_GROUP_free.restype = None;            lib.EC_GROUP_free.argtypes = [V]
    lib.EC_GROUP_get0_generator.restype = V;     lib.EC_GROUP_get0_generator.argtypes = [V]
    lib.EC_POINT_new.restype = V;                lib.EC_POINT_new.argtypes = [V]
    lib.EC_POINT_free.restype = None;            lib.EC_POINT_free.argtypes = [V]
    lib.BN_new.restype = V;                      lib.BN_new.argtypes = []
    lib.BN_free.restype = None;                  lib.BN_free.argtypes = [V]
    lib.BN_bin2bn.restype = V;                   lib.BN_bin2bn.argtypes = [C, I, V]
    lib.BN_CTX_new.restype = V;                  lib.BN_CTX_new.argtypes = []
    lib.BN_CTX_free.restype = None;              lib.BN_CTX_free.argtypes = [V]
    lib.EC_POINT_oct2point.restype = I
    lib.EC_POINT_oct2point.argtypes = [V, V, C, S, V]
    lib.EC_POINT_point2oct.restype = S
    lib.EC_POINT_point2oct.argtypes = [V, V, I, C, S, V]
    # EC_POINT_mul(group, r, n, q, m, ctx): r = n*G + m*q  (NULL = omit term)
    lib.EC_POINT_mul.restype = I
    lib.EC_POINT_mul.argtypes = [V, V, V, V, V, V]
    # EC_POINT_add(group, r, a, b, ctx)
    lib.EC_POINT_add.restype = I
    lib.EC_POINT_add.argtypes = [V, V, V, V, V]


def _load_libcrypto() -> ctypes.CDLL:
    """
    Load OpenSSL libcrypto for constant-time EC operations.

    Search order:
    1. OpenSSL bundled inside the cryptography package (.libs/ directory on Linux wheels).
    2. System libcrypto found via ctypes.util.find_library.
    3. Common well-known paths (Homebrew macOS, standard Linux).
    """
    candidates: list[str] = []

    # 1. Try cryptography package's bundled OpenSSL (Linux wheels ship libcrypto in .libs/)
    try:
        import cryptography as _cp
        _pkg_libs = pathlib.Path(_cp.__file__).parent / ".libs"
        if _pkg_libs.is_dir():
            for _f in sorted(_pkg_libs.glob("libcrypto*.so*")):
                candidates.append(str(_f))
        # macOS wheel variant
        for _f in sorted(pathlib.Path(_cp.__file__).parent.rglob("libcrypto*.dylib")):
            candidates.append(str(_f))
    except Exception:
        pass

    # 2. System libcrypto via ctypes.util
    _found = ctypes.util.find_library("crypto")
    if _found:
        candidates.append(_found)

    # 3. Common paths
    if sys.platform.startswith("linux"):
        candidates.extend(["libcrypto.so.3", "libcrypto.so.1.1", "libcrypto.so"])
    elif sys.platform == "darwin":
        candidates.extend([
            "/opt/homebrew/lib/libcrypto.dylib",
            "/usr/local/lib/libcrypto.dylib",
        ])

    for path in candidates:
        try:
            lib = ctypes.CDLL(path)
            _setup_libcrypto_types(lib)
            # Smoke-test: create a P-256 group
            test_grp = lib.EC_GROUP_new_by_curve_name(_NID_P256)
            if test_grp:
                lib.EC_GROUP_free(test_grp)
                return lib
        except (OSError, AttributeError):
            continue

    raise RuntimeError(
        "Could not find OpenSSL libcrypto with EC support. "
        "Ensure OpenSSL >= 1.1 is installed or that cryptography >= 41.0.0 is available."
    )


def _get_libcrypto() -> ctypes.CDLL:
    global _libcrypto
    if _libcrypto is None:
        _libcrypto = _load_libcrypto()
    return _libcrypto


def _get_ec_group(nid: int) -> int:
    """Return (and cache) a reusable EC_GROUP* for the given NID."""
    if nid not in _cached_ec_groups:
        lib = _get_libcrypto()
        grp = lib.EC_GROUP_new_by_curve_name(nid)
        if not grp:
            raise RuntimeError(f"EC_GROUP_new_by_curve_name({nid}) failed")
        _cached_ec_groups[nid] = grp
    return _cached_ec_groups[nid]


def _ossl_scalar_mult(nid: int, byte_len: int, scalar: bytes, point: bytes) -> bytes:
    """
    Constant-time scalar multiplication via OpenSSL EC_POINT_mul.

    Computes result = scalar * point.  Both scalar and point use the canonical
    uncompressed-point encoding for the curve.
    """
    lib = _get_libcrypto()
    grp = _get_ec_group(nid)

    if len(scalar) != byte_len:
        raise ValueError(
            f"Invalid scalar length: expected {byte_len} bytes, got {len(scalar)}"
        )
    if not any(scalar):
        raise ValueError("Scalar is zero")

    ctx = lib.BN_CTX_new()
    k_bn = lib.BN_bin2bn(scalar, byte_len, None)
    pt = lib.EC_POINT_new(grp)
    result = lib.EC_POINT_new(grp)
    try:
        rc = lib.EC_POINT_oct2point(grp, pt, point, len(point), ctx)
        if rc != 1:
            raise ValueError("Invalid EC point encoding")
        # r = NULL*G + k*pt  → k*pt  (constant-time via OpenSSL Montgomery ladder)
        rc = lib.EC_POINT_mul(grp, result, None, pt, k_bn, ctx)
        if rc != 1:
            raise ValueError("EC_POINT_mul failed")
        out_len = 2 * byte_len + 1
        buf = ctypes.create_string_buffer(out_len)
        n = lib.EC_POINT_point2oct(
            grp, result, _POINT_CONVERSION_UNCOMPRESSED, buf, out_len, ctx
        )
        if n == 0:
            raise ValueError("EC_POINT_point2oct failed")
        return bytes(buf.raw[:n])
    finally:
        lib.EC_POINT_free(pt)
        lib.EC_POINT_free(result)
        lib.BN_free(k_bn)
        lib.BN_CTX_free(ctx)


def _ossl_point_add(nid: int, byte_len: int, point_a: bytes, point_b: bytes) -> bytes:
    """
    EC point addition via OpenSSL EC_POINT_add.

    point_add does not involve secret scalars; its use of OpenSSL ensures
    the operation is performed with validated, constant-time group arithmetic.
    """
    lib = _get_libcrypto()
    grp = _get_ec_group(nid)

    ctx = lib.BN_CTX_new()
    pa = lib.EC_POINT_new(grp)
    pb = lib.EC_POINT_new(grp)
    result = lib.EC_POINT_new(grp)
    try:
        rc = lib.EC_POINT_oct2point(grp, pa, point_a, len(point_a), ctx)
        if rc != 1:
            raise ValueError("Invalid point_a encoding")
        rc = lib.EC_POINT_oct2point(grp, pb, point_b, len(point_b), ctx)
        if rc != 1:
            raise ValueError("Invalid point_b encoding")
        rc = lib.EC_POINT_add(grp, result, pa, pb, ctx)
        if rc != 1:
            raise ValueError("EC_POINT_add failed")
        out_len = 2 * byte_len + 1
        buf = ctypes.create_string_buffer(out_len)
        n = lib.EC_POINT_point2oct(
            grp, result, _POINT_CONVERSION_UNCOMPRESSED, buf, out_len, ctx
        )
        if n == 0:
            raise ValueError("EC_POINT_point2oct failed")
        return bytes(buf.raw[:n])
    finally:
        lib.EC_POINT_free(pa)
        lib.EC_POINT_free(pb)
        lib.EC_POINT_free(result)
        lib.BN_CTX_free(ctx)


# ─────────────────────────────────────────────────────────────────────────────
# Abstract Group interface
# ─────────────────────────────────────────────────────────────────────────────

class Group(ABC):
    """
    Abstract base class defining the common interface all four group backends implement.

    Full-featured backends (P-256, P-384, ristretto255) implement all five methods.
    The X25519 DH-only backend raises NotImplementedError for point_add and hash_to_group.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Read-only identifier string (e.g. 'P-256', 'ristretto255')."""

    @abstractmethod
    def scalar_mult(self, scalar: bytes, point: bytes) -> bytes:
        """Constant-time scalar multiplication of scalar with point."""

    @abstractmethod
    def base_point(self) -> bytes:
        """Return the serialized group generator."""

    @abstractmethod
    def random_scalar(self) -> bytes:
        """Return a cryptographically random scalar from the group's scalar field."""

    @abstractmethod
    def point_add(self, point_a: bytes, point_b: bytes) -> bytes:
        """Elliptic-curve point addition. Raises NotImplementedError for X25519."""

    @abstractmethod
    def hash_to_group(self, data: bytes) -> bytes:
        """Hash arbitrary bytes to a group element. Raises NotImplementedError for X25519."""


# ─────────────────────────────────────────────────────────────────────────────
# P-256 backend — constant-time scalar_mult/point_add via OpenSSL
# ─────────────────────────────────────────────────────────────────────────────

class _P256Group(Group):
    @property
    def name(self) -> str:
        return "P-256"

    @property
    def byte_len(self) -> int:
        return _P256.byte_len

    @property
    def order(self) -> int:
        return _P256.n

    def scalar_mult(self, scalar: bytes, point: bytes) -> bytes:
        """Constant-time scalar multiplication via OpenSSL EC_POINT_mul."""
        return _ossl_scalar_mult(_NID_P256, _P256.byte_len, scalar, point)

    def base_point(self) -> bytes:
        return _ec_base_point(_P256)

    def random_scalar(self) -> bytes:
        return _ec_random_scalar(_P256)

    def point_add(self, point_a: bytes, point_b: bytes) -> bytes:
        """EC point addition via OpenSSL EC_POINT_add."""
        return _ossl_point_add(_NID_P256, _P256.byte_len, point_a, point_b)

    def hash_to_group(self, data: bytes) -> bytes:
        """RFC 9380 hash-to-curve (SSWU) — pure Python, operates on public data."""
        return _ec_hash_to_group(data, _P256, "P-256")


# ─────────────────────────────────────────────────────────────────────────────
# P-384 backend — constant-time scalar_mult/point_add via OpenSSL
# ─────────────────────────────────────────────────────────────────────────────

class _P384Group(Group):
    @property
    def name(self) -> str:
        return "P-384"

    @property
    def byte_len(self) -> int:
        return _P384.byte_len

    @property
    def order(self) -> int:
        return _P384.n

    def scalar_mult(self, scalar: bytes, point: bytes) -> bytes:
        """Constant-time scalar multiplication via OpenSSL EC_POINT_mul."""
        return _ossl_scalar_mult(_NID_P384, _P384.byte_len, scalar, point)

    def base_point(self) -> bytes:
        return _ec_base_point(_P384)

    def random_scalar(self) -> bytes:
        return _ec_random_scalar(_P384)

    def point_add(self, point_a: bytes, point_b: bytes) -> bytes:
        """EC point addition via OpenSSL EC_POINT_add."""
        return _ossl_point_add(_NID_P384, _P384.byte_len, point_a, point_b)

    def hash_to_group(self, data: bytes) -> bytes:
        """RFC 9380 hash-to-curve (SSWU) — pure Python, operates on public data."""
        return _ec_hash_to_group(data, _P384, "P-384")


# ─────────────────────────────────────────────────────────────────────────────
# ristretto255 backend (via PyNaCl / libsodium)
# ─────────────────────────────────────────────────────────────────────────────

class _Ristretto255Group(Group):
    """
    Ristretto255 group backend via pynacl>=1.5.0.

    pynacl exposes ristretto255 group operations through the crypto_core_ed25519_*
    and crypto_scalarmult_ed25519_noclamp functions — these are pynacl's ristretto255
    API (the naming is historical; the operations are on the prime-order ristretto255
    group). The separately-named crypto_scalarmult_ristretto255 / crypto_core_ristretto255_*
    are libsodium C symbols that pynacl does not expose as Python bindings.
    """
    _ORDER = (1 << 252) + 27742317777372353535851937790883648493

    @property
    def name(self) -> str:
        return "ristretto255"

    @property
    def byte_len(self) -> int:
        return 32

    @property
    def order(self) -> int:
        return self._ORDER

    def scalar_mult(self, scalar: bytes, point: bytes) -> bytes:
        """Constant-time scalar multiplication via pynacl's ristretto255 API."""
        import nacl.bindings as nb
        if len(scalar) != 32:
            raise ValueError("ristretto255 scalar must be 32 bytes")
        if len(point) != 32:
            raise ValueError("ristretto255 point must be 32 bytes")
        try:
            return nb.crypto_scalarmult_ed25519_noclamp(scalar, point)
        except Exception as e:
            raise ValueError(f"ristretto255 scalar_mult failed: {e}") from e

    def base_point(self) -> bytes:
        """Standard ristretto255 generator via pynacl."""
        import nacl.bindings as nb
        one = (1).to_bytes(32, "little")
        return nb.crypto_scalarmult_ed25519_base_noclamp(one)

    def random_scalar(self) -> bytes:
        """Uniform random scalar in the ristretto255 scalar field."""
        import nacl.bindings as nb
        raw = os.urandom(64)
        return nb.crypto_core_ed25519_scalar_reduce(raw)

    def point_add(self, point_a: bytes, point_b: bytes) -> bytes:
        """Constant-time group addition via pynacl's ristretto255 API."""
        import nacl.bindings as nb
        if len(point_a) != 32 or len(point_b) != 32:
            raise ValueError("ristretto255 points must be 32 bytes each")
        try:
            return nb.crypto_core_ed25519_add(point_a, point_b)
        except Exception as e:
            raise ValueError(f"ristretto255 point_add failed: {e}") from e

    def hash_to_group(self, data: bytes) -> bytes:
        """
        Delegates to libsodium's crypto_core_ristretto255_from_hash (64-byte input)
        per the prompt. Uses pynacl's crypto_core_ed25519_from_hash when available
        (same operation, historical naming); falls back to crypto_core_ed25519_from_uniform
        on pynacl builds that predate the from_hash wrapper.
        """
        import nacl.bindings as nb
        h = hashlib.sha512(b"ristretto255:hash_to_group:" + data).digest()  # 64 bytes
        if hasattr(nb, 'crypto_core_ed25519_from_hash'):
            return nb.crypto_core_ed25519_from_hash(h)
        # from_uniform takes 32 uniform bytes; use the first 32 bytes of the 64-byte hash
        return nb.crypto_core_ed25519_from_uniform(h[:32])

    def _scalar_invert(self, scalar: bytes) -> bytes:
        import nacl.bindings as nb
        return nb.crypto_core_ed25519_scalar_invert(scalar)

    def _scalar_negate(self, scalar: bytes) -> bytes:
        import nacl.bindings as nb
        return nb.crypto_core_ed25519_scalar_negate(scalar)


# ─────────────────────────────────────────────────────────────────────────────
# X25519 backend (DH-only: no point_add, no hash_to_group)
# ─────────────────────────────────────────────────────────────────────────────

class _X25519Group(Group):
    @property
    def name(self) -> str:
        return "X25519"

    @property
    def byte_len(self) -> int:
        return 32

    def scalar_mult(self, scalar: bytes, point: bytes) -> bytes:
        """Constant-time DH scalar multiplication via the cryptography library."""
        from cryptography.hazmat.primitives.asymmetric.x25519 import (
            X25519PrivateKey,
            X25519PublicKey,
        )
        if len(scalar) != 32:
            raise ValueError("X25519 scalar must be 32 bytes")
        if len(point) != 32:
            raise ValueError("X25519 point must be 32 bytes")
        priv = X25519PrivateKey.from_private_bytes(scalar)
        pub = X25519PublicKey.from_public_bytes(point)
        return priv.exchange(pub)

    def base_point(self) -> bytes:
        return bytes([9]) + bytes(31)

    def random_scalar(self) -> bytes:
        return os.urandom(32)

    def point_add(self, point_a: bytes, point_b: bytes) -> bytes:
        raise NotImplementedError(
            "X25519 is a DH-only backend and does not support point addition. "
            "Use P-256, P-384, or ristretto255 for protocols requiring point_add."
        )

    def hash_to_group(self, data: bytes) -> bytes:
        raise NotImplementedError(
            "X25519 is a DH-only backend and does not support hash_to_group. "
            "Use P-256, P-384, or ristretto255 for protocols requiring hash_to_group."
        )


# ─────────────────────────────────────────────────────────────────────────────
# Public aliases — required by prompt: all public symbols importable from pake_framework
# ─────────────────────────────────────────────────────────────────────────────

P256Group = _P256Group
P384Group = _P384Group
Ristretto255Group = _Ristretto255Group
X25519Group = _X25519Group


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────

_BACKENDS: dict[str, type[Group]] = {
    "P-256": _P256Group,
    "P-384": _P384Group,
    "ristretto255": _Ristretto255Group,
    "X25519": _X25519Group,
}


def get_group(name: str) -> Group:
    """
    Factory that returns the concrete Group implementation for the requested name.
    Raises ValueError for unrecognized group names.
    """
    cls = _BACKENDS.get(name)
    if cls is None:
        raise ValueError(
            f"Unknown group '{name}'. Valid options: {sorted(_BACKENDS.keys())}"
        )
    return cls()
