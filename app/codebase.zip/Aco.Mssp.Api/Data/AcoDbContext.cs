using Aco.Mssp.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Aco.Mssp.Api.Data;

public class AcoDbContext : DbContext
{
    public AcoDbContext(DbContextOptions<AcoDbContext> options) : base(options) { }

    public DbSet<Beneficiary> Beneficiaries => Set<Beneficiary>();
    public DbSet<Provider> Providers => Set<Provider>();
    public DbSet<PrimaryCareService> PrimaryCareServices => Set<PrimaryCareService>();
    public DbSet<AttributionRecord> AttributionRecords => Set<AttributionRecord>();
    public DbSet<QualityMeasureResult> QualityMeasureResults => Set<QualityMeasureResult>();
    public DbSet<CareEpisode> CareEpisodes => Set<CareEpisode>();
    public DbSet<SharedSavingsSettlement> SharedSavingsSettlements => Set<SharedSavingsSettlement>();
    public DbSet<RegulatoryReport> RegulatoryReports => Set<RegulatoryReport>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<Beneficiary>(b =>
        {
            b.HasKey(x => x.Id);
            b.Property(x => x.MedicareId).IsRequired().HasMaxLength(11);
            b.HasIndex(x => x.MedicareId).IsUnique();
            b.Property(x => x.HccRiskScore)
             .HasConversion(v => v.ToString(), s => decimal.Parse(s));
        });

        mb.Entity<Provider>(b =>
        {
            b.HasKey(x => x.Id);
            b.Property(x => x.Npi).IsRequired().HasMaxLength(10);
            b.HasIndex(x => x.Npi).IsUnique();
            b.Property(x => x.ProviderType).HasConversion<string>();
        });

        mb.Entity<PrimaryCareService>(b =>
        {
            b.HasKey(x => x.Id);
            b.Property(x => x.AllowedAmount)
             .HasConversion(v => v.ToString(), s => decimal.Parse(s));
        });

        mb.Entity<AttributionRecord>(b =>
        {
            b.HasKey(x => x.Id);
            b.Property(x => x.AssignmentStep).HasConversion<string>();
            b.HasIndex(x => new { x.BeneficiaryId, x.PerformanceYear });
        });

        mb.Entity<QualityMeasureResult>(b =>
        {
            b.HasKey(x => x.Id);
            b.Property(x => x.PercentilePerformance)
             .HasConversion(v => v.ToString(), s => decimal.Parse(s));
        });

        mb.Entity<CareEpisode>(b =>
        {
            b.HasKey(x => x.Id);
            b.Property(x => x.EpisodeType).HasConversion<string>();
            b.Property(x => x.Status).HasConversion<string>();
        });

        mb.Entity<SharedSavingsSettlement>(b =>
        {
            b.HasKey(x => x.Id);
            b.Property(x => x.Track).HasConversion<string>();
            b.HasIndex(x => new { x.ProviderId, x.PerformanceYear }).IsUnique();
            b.Property(x => x.BenchmarkExpenditure)
             .HasConversion(v => v.ToString(), s => decimal.Parse(s));
            b.Property(x => x.ActualExpenditure)
             .HasConversion(v => v.ToString(), s => decimal.Parse(s));
            b.Property(x => x.EarnedSavings)
             .HasConversion(v => v.ToString(), s => decimal.Parse(s));
            b.Property(x => x.EarnedLosses)
             .HasConversion(v => v.ToString(), s => decimal.Parse(s));
            b.Property(x => x.FinalQualityScore)
             .HasConversion(v => v.ToString(), s => decimal.Parse(s));
        });

        mb.Entity<RegulatoryReport>(b =>
        {
            b.HasKey(x => x.Id);
            b.Property(x => x.ReportType).HasConversion<string>();
        });
    }
}
