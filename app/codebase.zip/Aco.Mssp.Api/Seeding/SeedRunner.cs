using System.Text.Json;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Models;

namespace Aco.Mssp.Api.Seeding;

/// <summary>
/// Hydrates the SQLite database from <c>data/seed.json</c> on first run.
/// The seeder is a no-op once the <see cref="AcoDbContext.Beneficiaries"/>
/// table has any rows, so it never overwrites operator-supplied data.
/// </summary>
public static class SeedRunner
{
    /// <summary>
    /// Loads providers, beneficiaries, services, quality measures, and care
    /// episodes from the seed file when the database is empty. The seed file
    /// is resolved relative to the current working directory and the API's
    /// content root so the application remains runnable under either layout.
    /// </summary>
    public static void Run(AcoDbContext db, IWebHostEnvironment env)
    {
        if (db.Beneficiaries.Any()) return;

        var seedPath = ResolveSeedPath(env);
        if (seedPath is null) return;

        using var stream = File.OpenRead(seedPath);
        using var doc = JsonDocument.Parse(stream);
        var root = doc.RootElement;

        // Providers
        var providerIds = new List<int>();
        if (root.TryGetProperty("providers", out var providers))
        {
            foreach (var p in providers.EnumerateArray())
            {
                var entity = new Provider
                {
                    Npi = p.GetProperty("npi").GetString() ?? string.Empty,
                    Name = p.GetProperty("name").GetString() ?? string.Empty,
                    ProviderType = Enum.Parse<ProviderType>(p.GetProperty("providerType").GetString() ?? "PrimaryCare"),
                    TaxId = p.GetProperty("taxId").GetString() ?? string.Empty,
                };
                db.Providers.Add(entity);
                db.SaveChanges();
                providerIds.Add(entity.Id);
            }
        }

        // Beneficiaries
        var beneficiaryIds = new List<int>();
        if (root.TryGetProperty("beneficiaries", out var beneficiaries))
        {
            foreach (var b in beneficiaries.EnumerateArray())
            {
                var entity = new Beneficiary
                {
                    MedicareId = b.GetProperty("medicareId").GetString() ?? string.Empty,
                    FirstName = b.GetProperty("firstName").GetString() ?? string.Empty,
                    LastName = b.GetProperty("lastName").GetString() ?? string.Empty,
                    DateOfBirth = DateOnly.Parse(b.GetProperty("dateOfBirth").GetString()!),
                    HccRiskScore = b.GetProperty("hccRiskScore").GetDecimal(),
                    EnrollmentStartDate = DateOnly.Parse(b.GetProperty("enrollmentStartDate").GetString()!),
                    EnrollmentEndDate = b.TryGetProperty("enrollmentEndDate", out var ed) && ed.ValueKind != JsonValueKind.Null
                        ? DateOnly.Parse(ed.GetString()!)
                        : (DateOnly?)null,
                };
                db.Beneficiaries.Add(entity);
                db.SaveChanges();
                beneficiaryIds.Add(entity.Id);
            }
        }

        // Services
        if (root.TryGetProperty("services", out var services))
        {
            foreach (var s in services.EnumerateArray())
            {
                var entity = new PrimaryCareService
                {
                    BeneficiaryId = beneficiaryIds[s.GetProperty("beneficiaryIndex").GetInt32()],
                    ProviderId = providerIds[s.GetProperty("providerIndex").GetInt32()],
                    ServiceDate = DateOnly.Parse(s.GetProperty("serviceDate").GetString()!),
                    AllowedAmount = s.GetProperty("allowedAmount").GetDecimal(),
                };
                db.PrimaryCareServices.Add(entity);
            }
            db.SaveChanges();
        }

        // Quality measures
        if (root.TryGetProperty("qualityMeasures", out var measures))
        {
            foreach (var m in measures.EnumerateArray())
            {
                var entity = new QualityMeasureResult
                {
                    ProviderId = providerIds[m.GetProperty("providerIndex").GetInt32()],
                    MeasureCode = m.GetProperty("measureCode").GetString() ?? string.Empty,
                    PerformanceYear = m.GetProperty("performanceYear").GetInt32(),
                    Numerator = m.GetProperty("numerator").GetInt32(),
                    Denominator = m.GetProperty("denominator").GetInt32(),
                    PercentilePerformance = m.GetProperty("percentilePerformance").GetDecimal(),
                };
                db.QualityMeasureResults.Add(entity);
            }
            db.SaveChanges();
        }

        // Care episodes
        if (root.TryGetProperty("careEpisodes", out var episodes))
        {
            foreach (var e in episodes.EnumerateArray())
            {
                var entity = new CareEpisode
                {
                    BeneficiaryId = beneficiaryIds[e.GetProperty("beneficiaryIndex").GetInt32()],
                    EpisodeType = Enum.Parse<EpisodeType>(e.GetProperty("episodeType").GetString() ?? "ChronicDiseaseManagement"),
                    StartDate = DateOnly.Parse(e.GetProperty("startDate").GetString()!),
                    EndDate = e.TryGetProperty("endDate", out var ed) && ed.ValueKind != JsonValueKind.Null
                        ? DateOnly.Parse(ed.GetString()!)
                        : (DateOnly?)null,
                    Status = e.TryGetProperty("status", out var st) && st.ValueKind != JsonValueKind.Null
                        ? Enum.Parse<EpisodeStatus>(st.GetString() ?? "Open")
                        : EpisodeStatus.Open,
                };
                db.CareEpisodes.Add(entity);
            }
            db.SaveChanges();
        }
    }

    /// <summary>
    /// Walks several candidate paths (current working dir, content root, and
    /// ancestors of content root) looking for <c>data/seed.json</c>. Returns
    /// <c>null</c> if no seed file is found.
    /// </summary>
    private static string? ResolveSeedPath(IWebHostEnvironment env)
    {
        var candidates = new List<string>
        {
            Path.Combine(Directory.GetCurrentDirectory(), "data", "seed.json"),
            Path.Combine(env.ContentRootPath, "data", "seed.json"),
            Path.Combine(env.ContentRootPath, "..", "data", "seed.json"),
            Path.Combine(AppContext.BaseDirectory, "data", "seed.json"),
        };

        // Also walk up from the content root in case the API project is run
        // from an unusual working directory.
        var dir = env.ContentRootPath;
        for (var i = 0; i < 6 && !string.IsNullOrEmpty(dir); i++)
        {
            candidates.Add(Path.Combine(dir, "data", "seed.json"));
            dir = Path.GetDirectoryName(dir) ?? "";
        }

        foreach (var c in candidates)
        {
            try
            {
                var full = Path.GetFullPath(c);
                if (File.Exists(full)) return full;
            }
            catch
            {
                // ignored
            }
        }
        return null;
    }
}
