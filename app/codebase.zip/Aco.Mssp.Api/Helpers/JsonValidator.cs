using System.Globalization;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

namespace Aco.Mssp.Api.Helpers;

/// <summary>
/// Manual JSON validation helpers used by every controller so that missing
/// fields, wrong-typed fields, and out-of-range fields can each return the
/// documented `{ "error": string }` envelope.
/// </summary>
public static class JsonValidator
{
    /// <summary>Wraps the supplied message in the documented error envelope at the given status.</summary>
    public static IActionResult Error(int statusCode, string message)
        => new ObjectResult(new { error = message }) { StatusCode = statusCode };

    /// <summary>Convenience: HTTP 400 with the documented error envelope.</summary>
    public static IActionResult BadRequest(string message) => Error(400, message);

    /// <summary>Convenience: HTTP 404 with the documented error envelope.</summary>
    public static IActionResult NotFound(string message) => Error(404, message);

    /// <summary>Convenience: HTTP 409 with the documented error envelope.</summary>
    public static IActionResult Conflict(string message) => Error(409, message);

    /// <summary>Returns <c>true</c> only when <paramref name="root"/> is a JSON object.</summary>
    public static bool IsObject(JsonElement root)
        => root.ValueKind == JsonValueKind.Object;

    /// <summary>
    /// Looks up <paramref name="name"/> on <paramref name="root"/>, returning
    /// <c>false</c> when the root is not an object or the property is absent.
    /// </summary>
    public static bool TryGet(JsonElement root, string name, out JsonElement value)
    {
        if (root.ValueKind != JsonValueKind.Object)
        {
            value = default;
            return false;
        }
        return root.TryGetProperty(name, out value);
    }

    /// <summary>
    /// Reads a required JSON string property. Returns <c>false</c> with an
    /// error message when the field is missing, JSON null, or the wrong type.
    /// </summary>
    public static bool TryString(JsonElement root, string name, out string? value, out string? error)
    {
        value = null;
        error = null;
        if (!TryGet(root, name, out var prop))
        {
            error = $"Field '{name}' is required.";
            return false;
        }
        if (prop.ValueKind == JsonValueKind.Null)
        {
            error = $"Field '{name}' must be a string.";
            return false;
        }
        if (prop.ValueKind != JsonValueKind.String)
        {
            error = $"Field '{name}' must be a string.";
            return false;
        }
        value = prop.GetString();
        return true;
    }

    /// <summary>
    /// Reads a required JSON integer property. Returns <c>false</c> with an
    /// error message when the field is missing, the wrong type, or out of
    /// <see cref="int"/> range.
    /// </summary>
    public static bool TryInt(JsonElement root, string name, out int value, out string? error)
    {
        value = 0;
        error = null;
        if (!TryGet(root, name, out var prop))
        {
            error = $"Field '{name}' is required.";
            return false;
        }
        if (prop.ValueKind != JsonValueKind.Number)
        {
            error = $"Field '{name}' must be a number.";
            return false;
        }
        if (!prop.TryGetInt32(out var i))
        {
            error = $"Field '{name}' must be an integer.";
            return false;
        }
        value = i;
        return true;
    }

    /// <summary>
    /// Reads a required JSON number property as a <see cref="decimal"/> for
    /// money or ratio fields. Returns <c>false</c> with an error message when
    /// the field is missing, the wrong type, or out of decimal range.
    /// </summary>
    public static bool TryDecimal(JsonElement root, string name, out decimal value, out string? error)
    {
        value = 0m;
        error = null;
        if (!TryGet(root, name, out var prop))
        {
            error = $"Field '{name}' is required.";
            return false;
        }
        if (prop.ValueKind != JsonValueKind.Number)
        {
            error = $"Field '{name}' must be a number.";
            return false;
        }
        if (!prop.TryGetDecimal(out var d))
        {
            error = $"Field '{name}' must be a decimal number.";
            return false;
        }
        value = d;
        return true;
    }

    /// <summary>
    /// Reads a required ISO-formatted date string ("yyyy-MM-dd") into a
    /// <see cref="DateOnly"/>. ISO datetime strings are also tolerated.
    /// </summary>
    public static bool TryDateOnly(JsonElement root, string name, out DateOnly value, out string? error)
    {
        value = default;
        error = null;
        if (!TryGet(root, name, out var prop))
        {
            error = $"Field '{name}' is required.";
            return false;
        }
        if (prop.ValueKind != JsonValueKind.String)
        {
            error = $"Field '{name}' must be an ISO date string.";
            return false;
        }
        var s = prop.GetString();
        if (string.IsNullOrWhiteSpace(s))
        {
            error = $"Field '{name}' must be an ISO date string.";
            return false;
        }
        if (!DateOnly.TryParseExact(s, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
        {
            // Tolerate ISO datetime forms too (e.g., "2024-03-04T00:00:00").
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var dt))
            {
                value = DateOnly.FromDateTime(dt);
                return true;
            }
            error = $"Field '{name}' must be an ISO date string.";
            return false;
        }
        value = d;
        return true;
    }

    /// <summary>
    /// Like TryDateOnly but allows an explicit JSON null. Returns true with
    /// `value = null` for null. Returns false (with an error) if the field is
    /// missing entirely or has the wrong shape.
    /// </summary>
    public static bool TryNullableDateOnly(JsonElement root, string name, out DateOnly? value, out string? error)
    {
        value = null;
        error = null;
        if (!TryGet(root, name, out var prop))
        {
            error = $"Field '{name}' is required.";
            return false;
        }
        if (prop.ValueKind == JsonValueKind.Null)
        {
            value = null;
            return true;
        }
        if (prop.ValueKind != JsonValueKind.String)
        {
            error = $"Field '{name}' must be an ISO date string or null.";
            return false;
        }
        var s = prop.GetString();
        if (string.IsNullOrWhiteSpace(s))
        {
            error = $"Field '{name}' must be an ISO date string or null.";
            return false;
        }
        if (!DateOnly.TryParseExact(s, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
        {
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var dt))
            {
                value = DateOnly.FromDateTime(dt);
                return true;
            }
            error = $"Field '{name}' must be an ISO date string or null.";
            return false;
        }
        value = d;
        return true;
    }

    /// <summary>
    /// Reads a required JSON string property and parses it case-sensitively
    /// against the named values of <typeparamref name="TEnum"/>. Returns
    /// <c>false</c> with an error message when the value is not in the enum.
    /// </summary>
    public static bool TryEnum<TEnum>(JsonElement root, string name, out TEnum value, out string? error)
        where TEnum : struct, Enum
    {
        value = default;
        error = null;
        if (!TryString(root, name, out var s, out error)) return false;
        if (!Enum.TryParse<TEnum>(s, ignoreCase: false, out var parsed) || !Enum.IsDefined(typeof(TEnum), parsed))
        {
            error = $"Field '{name}' must be one of: {string.Join(", ", Enum.GetNames(typeof(TEnum)))}.";
            return false;
        }
        value = parsed;
        return true;
    }
}
