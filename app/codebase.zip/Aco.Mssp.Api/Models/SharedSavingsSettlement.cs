namespace Aco.Mssp.Api.Models;

/// <summary>
/// A persisted shared-savings (or shared-losses) settlement computed against
/// a specific MSSP track's risk corridor for a given performance year.
/// </summary>
public class SharedSavingsSettlement
{
    /// <summary>Surrogate primary key.</summary>
    public int Id { get; set; }

    /// <summary>Performance year the settlement applies to.</summary>
    public int PerformanceYear { get; set; }

    /// <summary>FK to the provider the settlement is computed for.</summary>
    public int ProviderId { get; set; }

    /// <summary>MSSP track whose risk-corridor parameters were applied.</summary>
    public SavingsTrack Track { get; set; }

    /// <summary>CMS-aligned benchmark expenditure for the year.</summary>
    public decimal BenchmarkExpenditure { get; set; }

    /// <summary>Actual expenditure observed for the year.</summary>
    public decimal ActualExpenditure { get; set; }

    /// <summary>Earned shared savings (zero unless gross savings ratio meets MSR).</summary>
    public decimal EarnedSavings { get; set; }

    /// <summary>Earned shared losses (zero unless gross loss ratio meets MLR and the track is two-sided).</summary>
    public decimal EarnedLosses { get; set; }

    /// <summary>Final quality score in the unit interval, used to scale earned savings.</summary>
    public decimal FinalQualityScore { get; set; }
}
