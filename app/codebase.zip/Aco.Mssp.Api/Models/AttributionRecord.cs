namespace Aco.Mssp.Api.Models;

/// <summary>
/// Persisted result of running the two-step plurality attribution algorithm
/// for a single beneficiary in a single performance year.
/// </summary>
public class AttributionRecord
{
    /// <summary>Surrogate primary key.</summary>
    public int Id { get; set; }

    /// <summary>FK to the beneficiary this record describes.</summary>
    public int BeneficiaryId { get; set; }

    /// <summary>FK to the assigned provider, or <c>null</c> when unassigned.</summary>
    public int? AssignedProviderId { get; set; }

    /// <summary>Performance year for which this attribution applies.</summary>
    public int PerformanceYear { get; set; }

    /// <summary>Which step of the algorithm produced the assignment.</summary>
    public AssignmentStep AssignmentStep { get; set; }

    /// <summary>Timestamp (UTC) when the attribution run that produced this row executed.</summary>
    public DateTime AssignedAtUtc { get; set; }
}
