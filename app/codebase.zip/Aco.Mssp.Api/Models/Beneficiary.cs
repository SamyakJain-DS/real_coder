namespace Aco.Mssp.Api.Models;

/// <summary>
/// A Medicare beneficiary attributed (or eligible to be attributed) to the ACO
/// for one or more performance years.
/// </summary>
public class Beneficiary
{
    /// <summary>Surrogate primary key.</summary>
    public int Id { get; set; }

    /// <summary>CMS Medicare Beneficiary Identifier (exactly 11 characters, unique).</summary>
    public string MedicareId { get; set; } = string.Empty;

    /// <summary>Beneficiary's legal first name.</summary>
    public string FirstName { get; set; } = string.Empty;

    /// <summary>Beneficiary's legal last name.</summary>
    public string LastName { get; set; } = string.Empty;

    /// <summary>Date of birth (used for eligibility and risk adjustment).</summary>
    public DateOnly DateOfBirth { get; set; }

    /// <summary>HCC risk score driving expected expenditure adjustments.</summary>
    public decimal HccRiskScore { get; set; }

    /// <summary>Date the beneficiary first became eligible for ACO attribution.</summary>
    public DateOnly EnrollmentStartDate { get; set; }

    /// <summary>Date enrollment ended; <c>null</c> while the beneficiary is currently enrolled.</summary>
    public DateOnly? EnrollmentEndDate { get; set; }
}
