namespace Aco.Mssp.Api.Models;

/// <summary>
/// A care coordination episode (chronic disease management or post-acute
/// transition) tracked across the documented Open → Closed / Open → Escalated
/// / Escalated → Closed state machine.
/// </summary>
public class CareEpisode
{
    /// <summary>Surrogate primary key.</summary>
    public int Id { get; set; }

    /// <summary>FK to the beneficiary the episode is for.</summary>
    public int BeneficiaryId { get; set; }

    /// <summary>Category of the episode (CDM or post-acute transition).</summary>
    public EpisodeType EpisodeType { get; set; }

    /// <summary>Date the episode began.</summary>
    public DateOnly StartDate { get; set; }

    /// <summary>Date the episode closed; <c>null</c> while Open or Escalated.</summary>
    public DateOnly? EndDate { get; set; }

    /// <summary>Current lifecycle state of the episode.</summary>
    public EpisodeStatus Status { get; set; }
}
