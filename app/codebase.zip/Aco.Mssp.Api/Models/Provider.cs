namespace Aco.Mssp.Api.Models;

/// <summary>
/// A primary care, specialist, or hospital provider participating in the ACO
/// under the single ACO Participation Agreement.
/// </summary>
public class Provider
{
    /// <summary>Surrogate primary key.</summary>
    public int Id { get; set; }

    /// <summary>National Provider Identifier — exactly 10 ASCII digits and unique.</summary>
    public string Npi { get; set; } = string.Empty;

    /// <summary>Provider or practice name.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Provider category used by the attribution algorithm.</summary>
    public ProviderType ProviderType { get; set; }

    /// <summary>Tax identifier of the billing entity.</summary>
    public string TaxId { get; set; } = string.Empty;
}
