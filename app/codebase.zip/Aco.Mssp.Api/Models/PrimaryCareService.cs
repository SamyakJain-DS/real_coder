namespace Aco.Mssp.Api.Models;

/// <summary>
/// A claimed service used as input for the two-step plurality attribution
/// algorithm. Both PCP and specialist services are persisted here; their
/// distinction is read from the related <see cref="Provider.ProviderType"/>.
/// </summary>
public class PrimaryCareService
{
    /// <summary>Surrogate primary key.</summary>
    public int Id { get; set; }

    /// <summary>FK to the beneficiary the service was rendered to.</summary>
    public int BeneficiaryId { get; set; }

    /// <summary>FK to the provider that rendered the service.</summary>
    public int ProviderId { get; set; }

    /// <summary>Date of service (used to scope claims to a performance year).</summary>
    public DateOnly ServiceDate { get; set; }

    /// <summary>Allowed amount on the claim, used as the plurality weighting in attribution.</summary>
    public decimal AllowedAmount { get; set; }
}
