namespace Aco.Mssp.Api.Models;

/// <summary>
/// A single CMS quality measure reported by a provider for a performance year.
/// The mean of <see cref="PercentilePerformance"/> across measures becomes
/// that provider's quality score.
/// </summary>
public class QualityMeasureResult
{
    /// <summary>Surrogate primary key.</summary>
    public int Id { get; set; }

    /// <summary>FK to the provider whose performance is recorded.</summary>
    public int ProviderId { get; set; }

    /// <summary>CMS measure code (e.g. "CMS122").</summary>
    public string MeasureCode { get; set; } = string.Empty;

    /// <summary>Performance year this measure result applies to.</summary>
    public int PerformanceYear { get; set; }

    /// <summary>Numerator of the measure ratio (must satisfy 0 ≤ Numerator ≤ Denominator).</summary>
    public int Numerator { get; set; }

    /// <summary>Denominator of the measure ratio (must be &gt; 0).</summary>
    public int Denominator { get; set; }

    /// <summary>Benchmarked percentile performance in the unit interval [0.0, 1.0].</summary>
    public decimal PercentilePerformance { get; set; }
}
