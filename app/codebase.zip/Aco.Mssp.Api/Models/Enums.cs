namespace Aco.Mssp.Api.Models;

/// <summary>
/// MSSP-recognized provider categories used for the two-step plurality
/// attribution algorithm and for general provider classification.
/// </summary>
public enum ProviderType
{
    /// <summary>Primary care physician or practice (Step 1 attribution candidate).</summary>
    PrimaryCare,
    /// <summary>Specialist provider (Step 2 attribution candidate when no Step 1 match exists).</summary>
    Specialist,
    /// <summary>Hospital facility (not used for attribution).</summary>
    Hospital,
}

/// <summary>
/// Records which step of the two-step plurality attribution algorithm
/// produced a beneficiary's assigned provider for a performance year.
/// </summary>
public enum AssignmentStep
{
    /// <summary>The beneficiary was assigned to a primary care provider in Step 1.</summary>
    Step1Pcp,
    /// <summary>The beneficiary was assigned to a specialist in Step 2 (no Step 1 match).</summary>
    Step2Specialist,
    /// <summary>Neither Step 1 nor Step 2 produced an assignment.</summary>
    Unassigned,
}

/// <summary>
/// Care coordination episode categories tracked for chronic-disease and
/// post-acute populations under the MSSP care management workflow.
/// </summary>
public enum EpisodeType
{
    /// <summary>A chronic disease management (CDM) longitudinal episode.</summary>
    ChronicDiseaseManagement,
    /// <summary>A Transitional Care Management (TCM) post-acute episode.</summary>
    PostAcuteTransition,
}

/// <summary>
/// Lifecycle states for a <see cref="CareEpisode"/>. Transitions are governed
/// by a deterministic state machine documented on the controller.
/// </summary>
public enum EpisodeStatus
{
    /// <summary>The episode is currently active and has no end date.</summary>
    Open,
    /// <summary>The episode has been closed with a documented end date.</summary>
    Closed,
    /// <summary>The episode is open and has been escalated to a higher tier of care.</summary>
    Escalated,
}

/// <summary>
/// MSSP risk-corridor tracks supported for shared savings settlement. Each
/// track maps to its own MSR/MLR, sharing rate, and loss rate.
/// </summary>
public enum SavingsTrack
{
    /// <summary>BASIC track Level A — one-sided, 40% sharing rate, 0% loss rate.</summary>
    BasicA,
    /// <summary>BASIC track Level B — one-sided, 40% sharing rate, 0% loss rate.</summary>
    BasicB,
    /// <summary>BASIC track Level C — one-sided, 50% sharing rate, 0% loss rate.</summary>
    BasicC,
    /// <summary>BASIC track Level D — two-sided, 50% sharing rate, 30% loss rate.</summary>
    BasicD,
    /// <summary>BASIC track Level E — two-sided, 50% sharing rate, 30% loss rate.</summary>
    BasicE,
    /// <summary>ENHANCED track — two-sided, 75% sharing rate, 40% loss rate.</summary>
    Enhanced,
}

/// <summary>
/// Discriminator for the two regulatory submission payloads persisted to
/// <see cref="RegulatoryReport"/>.
/// </summary>
public enum ReportType
{
    /// <summary>CMS MSSP performance-year submission payload.</summary>
    CmsMsspSubmission,
    /// <summary>State public health agency coordination payload.</summary>
    StatePublicHealth,
}
