using System.Text.Json;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Helpers;
using Aco.Mssp.Api.Models;
using Microsoft.AspNetCore.Mvc;

namespace Aco.Mssp.Api.Controllers;

/// <summary>
/// REST endpoints for registering ACO-participating providers.
/// </summary>
[ApiController]
[Route("api/providers")]
public class ProvidersController : ControllerBase
{
    private readonly AcoDbContext _db;

    /// <summary>Creates a new controller. The <paramref name="db"/> is supplied by DI.</summary>
    public ProvidersController(AcoDbContext db) => _db = db;

    /// <summary>
    /// Persists a new <see cref="Provider"/>. Validates that the NPI is
    /// exactly 10 ASCII digits and unique, and that providerType is one of
    /// the allowed enum values. Returns 201 on success, 400 on validation
    /// failure, or 409 when the NPI is already taken.
    /// </summary>
    [HttpPost]
    public IActionResult Create([FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryString(body, "npi", out var npi, out var err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryString(body, "name", out var name, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryEnum<ProviderType>(body, "providerType", out var providerType, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryString(body, "taxId", out var taxId, out err))
            return JsonValidator.BadRequest(err!);

        if (!IsTenAsciiDigits(npi!))
            return JsonValidator.BadRequest("Field 'npi' must be exactly 10 ASCII digits.");

        if (_db.Providers.Any(p => p.Npi == npi))
            return JsonValidator.Conflict($"A provider with npi '{npi}' already exists.");

        var entity = new Provider
        {
            Npi = npi!,
            Name = name!,
            ProviderType = providerType,
            TaxId = taxId!,
        };
        _db.Providers.Add(entity);
        _db.SaveChanges();

        return new ObjectResult(Project(entity)) { StatusCode = StatusCodes.Status201Created };
    }

    private static bool IsTenAsciiDigits(string s)
    {
        if (s.Length != 10) return false;
        foreach (var c in s)
        {
            if (c < '0' || c > '9') return false;
        }
        return true;
    }

    private static object Project(Provider p) => new
    {
        id = p.Id,
        npi = p.Npi,
        name = p.Name,
        providerType = p.ProviderType.ToString(),
        taxId = p.TaxId,
    };
}
