using System.Text.Json;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Helpers;
using Aco.Mssp.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Aco.Mssp.Api.Controllers;

/// <summary>
/// REST endpoints implementing the CMS two-step plurality attribution
/// algorithm and the per-beneficiary attribution lookup.
/// </summary>
[ApiController]
[Route("api/attribution")]
public class AttributionController : ControllerBase
{
    private readonly AcoDbContext _db;

    /// <summary>Creates a new controller. The <paramref name="db"/> is supplied by DI.</summary>
    public AttributionController(AcoDbContext db) => _db = db;

    /// <summary>Lightweight DTO for in-memory aggregation of in-year services.</summary>
    private record ServiceRow(int BeneficiaryId, int ProviderId, DateOnly ServiceDate, decimal AllowedAmount, ProviderType ProviderType);

    /// <summary>
    /// Runs two-step plurality attribution for every enrolled beneficiary in
    /// the supplied <c>performanceYear</c>. Replaces any prior attribution
    /// rows for that year so the operation is idempotent. Returns 200 with
    /// per-step counts, or 400 when the year is missing or out of the MSSP
    /// range [2012, 2100].
    /// </summary>
    [HttpPost("run")]
    public IActionResult Run([FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryInt(body, "performanceYear", out var year, out var err))
            return JsonValidator.BadRequest(err!);

        if (year < 2012 || year > 2100)
            return JsonValidator.BadRequest("Field 'performanceYear' must be between 2012 and 2100 (inclusive).");

        var yearStart = new DateOnly(year, 1, 1);
        var yearEnd = new DateOnly(year, 12, 31);

        var prior = _db.AttributionRecords.Where(a => a.PerformanceYear == year).ToList();
        if (prior.Count > 0)
        {
            _db.AttributionRecords.RemoveRange(prior);
            _db.SaveChanges();
        }

        var enrolled = _db.Beneficiaries
            .Where(b => b.EnrollmentStartDate <= yearEnd
                && (b.EnrollmentEndDate == null || b.EnrollmentEndDate >= yearStart))
            .Select(b => b.Id)
            .ToList();

        var services = (from s in _db.PrimaryCareServices.AsNoTracking()
                        join p in _db.Providers.AsNoTracking() on s.ProviderId equals p.Id
                        where s.ServiceDate >= yearStart && s.ServiceDate <= yearEnd
                        select new { s.BeneficiaryId, s.ProviderId, s.ServiceDate, s.AllowedAmount, p.ProviderType })
                       .ToList()
                       .Select(x => new ServiceRow(x.BeneficiaryId, x.ProviderId, x.ServiceDate, x.AllowedAmount, x.ProviderType))
                       .ToList();

        var step1 = 0;
        var step2 = 0;
        var unassigned = 0;
        var nowUtc = DateTime.UtcNow;
        var newRecords = new List<AttributionRecord>(enrolled.Count);

        foreach (var benId in enrolled)
        {
            var benServices = services.Where(s => s.BeneficiaryId == benId).ToList();

            var assigned = SelectByPlurality(benServices, ProviderType.PrimaryCare);
            AssignmentStep step;
            if (assigned is not null)
            {
                step = AssignmentStep.Step1Pcp;
                step1++;
            }
            else
            {
                assigned = SelectByPlurality(benServices, ProviderType.Specialist);
                if (assigned is not null)
                {
                    step = AssignmentStep.Step2Specialist;
                    step2++;
                }
                else
                {
                    step = AssignmentStep.Unassigned;
                    unassigned++;
                }
            }

            newRecords.Add(new AttributionRecord
            {
                BeneficiaryId = benId,
                AssignedProviderId = assigned,
                PerformanceYear = year,
                AssignmentStep = step,
                AssignedAtUtc = nowUtc,
            });
        }

        _db.AttributionRecords.AddRange(newRecords);
        _db.SaveChanges();

        return Ok(new
        {
            performanceYear = year,
            step1Count = step1,
            step2Count = step2,
            unassignedCount = unassigned,
        });
    }

    /// <summary>
    /// Picks the provider of <paramref name="target"/> type whose summed
    /// <see cref="ServiceRow.AllowedAmount"/> dominates the beneficiary's
    /// in-year claims. Ties are broken by the most recent service date, then
    /// by the lowest provider id, per spec.
    /// </summary>
    private static int? SelectByPlurality(List<ServiceRow> rows, ProviderType target)
    {
        var grouped = rows
            .Where(r => r.ProviderType == target)
            .GroupBy(r => r.ProviderId)
            .Select(g => new
            {
                ProviderId = g.Key,
                Sum = g.Sum(x => x.AllowedAmount),
                LatestDate = g.Max(x => x.ServiceDate),
            })
            .Where(g => g.Sum > 0m)
            .ToList();

        if (grouped.Count == 0) return null;

        var maxSum = grouped.Max(g => g.Sum);
        var topByAmount = grouped.Where(g => g.Sum == maxSum).ToList();
        if (topByAmount.Count == 1) return topByAmount[0].ProviderId;

        var maxDate = topByAmount.Max(g => g.LatestDate);
        var topByDate = topByAmount.Where(g => g.LatestDate == maxDate).ToList();
        if (topByDate.Count == 1) return topByDate[0].ProviderId;

        return topByDate.Min(g => g.ProviderId);
    }

    /// <summary>
    /// Returns the persisted attribution outcome for a single beneficiary in
    /// a single performance year. Responds 404 when no record exists for
    /// that beneficiary/year pair.
    /// </summary>
    [HttpGet("{beneficiaryId:int}")]
    public IActionResult GetForBeneficiary(int beneficiaryId, [FromQuery] int? performanceYear)
    {
        if (performanceYear is null)
            return JsonValidator.BadRequest("Query parameter 'performanceYear' is required.");

        var record = _db.AttributionRecords
            .FirstOrDefault(a => a.BeneficiaryId == beneficiaryId && a.PerformanceYear == performanceYear);
        if (record is null)
            return JsonValidator.NotFound($"No attribution record exists for beneficiary {beneficiaryId} in performance year {performanceYear}.");

        return Ok(new
        {
            beneficiaryId = record.BeneficiaryId,
            performanceYear = record.PerformanceYear,
            assignedProviderId = record.AssignedProviderId,
            assignmentStep = record.AssignmentStep.ToString(),
        });
    }
}
