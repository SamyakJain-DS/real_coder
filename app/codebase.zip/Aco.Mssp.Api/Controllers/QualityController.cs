using System.Text.Json;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Helpers;
using Aco.Mssp.Api.Models;
using Microsoft.AspNetCore.Mvc;

namespace Aco.Mssp.Api.Controllers;

/// <summary>
/// REST endpoints for recording per-provider CMS quality measure submissions
/// and querying aggregated per-provider quality scores.
/// </summary>
[ApiController]
[Route("api/quality")]
public class QualityController : ControllerBase
{
    private readonly AcoDbContext _db;

    /// <summary>Creates a new controller. The <paramref name="db"/> is supplied by DI.</summary>
    public QualityController(AcoDbContext db) => _db = db;

    /// <summary>
    /// Persists a new <see cref="QualityMeasureResult"/>. Validates that
    /// denominator &gt; 0, 0 ≤ numerator ≤ denominator, and 0 ≤
    /// percentilePerformance ≤ 1. Returns 201 on success, 404 if the
    /// provider does not exist, or 400 on validation failure.
    /// </summary>
    [HttpPost("measures")]
    public IActionResult RecordMeasure([FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryInt(body, "providerId", out var providerId, out var err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryString(body, "measureCode", out var measureCode, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryInt(body, "performanceYear", out var year, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryInt(body, "numerator", out var numerator, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryInt(body, "denominator", out var denominator, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDecimal(body, "percentilePerformance", out var pct, out err))
            return JsonValidator.BadRequest(err!);

        if (denominator <= 0)
            return JsonValidator.BadRequest("Field 'denominator' must be greater than zero.");
        if (numerator < 0 || numerator > denominator)
            return JsonValidator.BadRequest("Field 'numerator' must be between 0 and 'denominator'.");
        if (pct < 0m || pct > 1m)
            return JsonValidator.BadRequest("Field 'percentilePerformance' must be between 0.0 and 1.0.");

        if (!_db.Providers.Any(p => p.Id == providerId))
            return JsonValidator.NotFound($"Provider with id {providerId} not found.");

        var entity = new QualityMeasureResult
        {
            ProviderId = providerId,
            MeasureCode = measureCode!,
            PerformanceYear = year,
            Numerator = numerator,
            Denominator = denominator,
            PercentilePerformance = pct,
        };
        _db.QualityMeasureResults.Add(entity);
        _db.SaveChanges();

        return new ObjectResult(new
        {
            id = entity.Id,
            providerId = entity.ProviderId,
            measureCode = entity.MeasureCode,
            performanceYear = entity.PerformanceYear,
            numerator = entity.Numerator,
            denominator = entity.Denominator,
            percentilePerformance = entity.PercentilePerformance,
        }) { StatusCode = StatusCodes.Status201Created };
    }

    /// <summary>
    /// Returns the unweighted arithmetic mean of percentilePerformance across
    /// all <see cref="QualityMeasureResult"/> rows for the provider in the
    /// requested year, rounded to four decimal places. Returns
    /// <c>qualityScore = 0.0</c> and <c>measureCount = 0</c> when no
    /// measures exist. Returns 404 if the provider does not exist.
    /// </summary>
    [HttpGet("score/{providerId:int}")]
    public IActionResult GetScore(int providerId, [FromQuery] int? performanceYear)
    {
        if (performanceYear is null)
            return JsonValidator.BadRequest("Query parameter 'performanceYear' is required.");

        if (!_db.Providers.Any(p => p.Id == providerId))
            return JsonValidator.NotFound($"Provider with id {providerId} not found.");

        var pcts = _db.QualityMeasureResults
            .Where(q => q.ProviderId == providerId && q.PerformanceYear == performanceYear)
            .Select(q => q.PercentilePerformance)
            .ToList();

        decimal score = pcts.Count == 0
            ? 0m
            : Math.Round(pcts.Average(), 4, MidpointRounding.AwayFromZero);

        return Ok(new
        {
            providerId,
            performanceYear = performanceYear.Value,
            qualityScore = score,
            measureCount = pcts.Count,
        });
    }
}
