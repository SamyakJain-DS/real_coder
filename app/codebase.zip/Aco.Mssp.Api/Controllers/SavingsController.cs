using System.Text.Json;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Helpers;
using Aco.Mssp.Api.Models;
using Microsoft.AspNetCore.Mvc;

namespace Aco.Mssp.Api.Controllers;

[ApiController]
[Route("api/savings")]
public class SavingsController : ControllerBase
{
    private readonly AcoDbContext _db;

    public SavingsController(AcoDbContext db) => _db = db;

    private record TrackParams(decimal Msr, decimal Mlr, decimal SharingRate, decimal LossRate);

    private static readonly Dictionary<SavingsTrack, TrackParams> Tracks = new()
    {
        [SavingsTrack.BasicA]   = new(0.02m, 0.02m, 0.25m, 0.00m),
        [SavingsTrack.BasicB]   = new(0.02m, 0.02m, 0.30m, 0.00m),
        [SavingsTrack.BasicC]   = new(0.02m, 0.02m, 0.40m, 0.00m),
        [SavingsTrack.BasicD]   = new(0.02m, 0.02m, 0.50m, 0.30m),
        [SavingsTrack.BasicE]   = new(0.02m, 0.02m, 0.60m, 0.30m),
        [SavingsTrack.Enhanced] = new(0.02m, 0.02m, 0.75m, 0.40m),
    };

    [HttpPost("settlement")]
    public IActionResult CalculateSettlement([FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryInt(body, "providerId", out var providerId, out var err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryInt(body, "performanceYear", out var year, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryEnum<SavingsTrack>(body, "track", out var track, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDecimal(body, "benchmarkExpenditure", out var benchmark, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDecimal(body, "actualExpenditure", out var actual, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDecimal(body, "finalQualityScore", out var quality, out err))
            return JsonValidator.BadRequest(err!);

        if (benchmark <= 0m)
            return JsonValidator.BadRequest("Field 'benchmarkExpenditure' must be greater than zero.");
        if (actual < 0m)
            return JsonValidator.BadRequest("Field 'actualExpenditure' must not be negative.");
        if (quality < 0m || quality > 1m)
            return JsonValidator.BadRequest("Field 'finalQualityScore' must be between 0.0 and 1.0.");

        if (!_db.Providers.Any(p => p.Id == providerId))
            return JsonValidator.NotFound($"Provider with id {providerId} not found.");

        if (_db.SharedSavingsSettlements.Any(s => s.ProviderId == providerId && s.PerformanceYear == year))
            return JsonValidator.Conflict($"A settlement for provider {providerId} in year {year} already exists.");

        var p = Tracks[track];
        var grossDiff = benchmark - actual;
        var ratio = grossDiff / benchmark;

        decimal earnedSavings = 0m;
        decimal earnedLosses = 0m;

        if (ratio >= p.Msr)
        {
            earnedSavings = grossDiff * p.SharingRate * quality;
        }
        else if (ratio <= -p.Mlr && p.LossRate > 0m)
        {
            earnedLosses = Math.Abs(grossDiff) * p.LossRate;
        }

        var entity = new SharedSavingsSettlement
        {
            ProviderId = providerId,
            PerformanceYear = year,
            Track = track,
            BenchmarkExpenditure = benchmark,
            ActualExpenditure = actual,
            EarnedSavings = earnedSavings,
            EarnedLosses = earnedLosses,
            FinalQualityScore = quality,
        };
        _db.SharedSavingsSettlements.Add(entity);
        _db.SaveChanges();

        return new ObjectResult(new
        {
            id = entity.Id,
            performanceYear = entity.PerformanceYear,
            providerId = entity.ProviderId,
            track = entity.Track.ToString(),
            benchmarkExpenditure = entity.BenchmarkExpenditure,
            actualExpenditure = entity.ActualExpenditure,
            earnedSavings = entity.EarnedSavings,
            earnedLosses = entity.EarnedLosses,
            finalQualityScore = entity.FinalQualityScore,
        }) { StatusCode = StatusCodes.Status201Created };
    }
}
