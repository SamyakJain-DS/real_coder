using System.Text.Json;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Helpers;
using Aco.Mssp.Api.Models;
using Microsoft.AspNetCore.Mvc;

namespace Aco.Mssp.Api.Controllers;

/// <summary>
/// REST endpoints for recording primary-care-eligible service claims that
/// feed the two-step plurality attribution algorithm.
/// </summary>
[ApiController]
[Route("api/services")]
public class ServicesController : ControllerBase
{
    private readonly AcoDbContext _db;

    /// <summary>Creates a new controller. The <paramref name="db"/> is supplied by DI.</summary>
    public ServicesController(AcoDbContext db) => _db = db;

    /// <summary>
    /// Persists a new <see cref="PrimaryCareService"/>. Returns 201 on
    /// success, 404 when the referenced beneficiary or provider does not
    /// exist, or 400 when allowedAmount is negative or serviceDate is in
    /// the near future.
    /// </summary>
    [HttpPost]
    public IActionResult Create([FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryInt(body, "beneficiaryId", out var benId, out var err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryInt(body, "providerId", out var provId, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDateOnly(body, "serviceDate", out var serviceDate, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDecimal(body, "allowedAmount", out var amount, out err))
            return JsonValidator.BadRequest(err!);

        if (amount < 0m)
            return JsonValidator.BadRequest("Field 'allowedAmount' must not be negative.");

        var todayUtc = DateOnly.FromDateTime(DateTime.UtcNow);
        if (serviceDate > todayUtc)
            return JsonValidator.BadRequest("Field 'serviceDate' must be on or before today (UTC).");

        if (!_db.Beneficiaries.Any(b => b.Id == benId))
            return JsonValidator.NotFound($"Beneficiary with id {benId} not found.");
        if (!_db.Providers.Any(p => p.Id == provId))
            return JsonValidator.NotFound($"Provider with id {provId} not found.");

        var entity = new PrimaryCareService
        {
            BeneficiaryId = benId,
            ProviderId = provId,
            ServiceDate = serviceDate,
            AllowedAmount = amount,
        };
        _db.PrimaryCareServices.Add(entity);
        _db.SaveChanges();

        return new ObjectResult(new
        {
            id = entity.Id,
            beneficiaryId = entity.BeneficiaryId,
            providerId = entity.ProviderId,
            serviceDate = entity.ServiceDate.ToString("yyyy-MM-dd"),
            allowedAmount = entity.AllowedAmount,
        }) { StatusCode = StatusCodes.Status201Created };
    }
}
