using System.Text.Json;
using System.Text.Json.Serialization;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Helpers;
using Aco.Mssp.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Aco.Mssp.Api.Controllers;

[ApiController]
[Route("api/reports")]
public class ReportsController : ControllerBase
{
    private readonly AcoDbContext _db;
    private readonly JsonSerializerOptions _jsonOptions;

    public ReportsController(AcoDbContext db, IOptions<Microsoft.AspNetCore.Mvc.JsonOptions> jsonOpts)
    {
        _db = db;
        _jsonOptions = jsonOpts.Value.JsonSerializerOptions;
    }

    [HttpPost("cms-submission")]
    public IActionResult GenerateCmsSubmission([FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryInt(body, "performanceYear", out var year, out var err))
            return JsonValidator.BadRequest(err!);

        var totalAttributed = _db.AttributionRecords.Count(a =>
            a.PerformanceYear == year &&
            (a.AssignmentStep == AssignmentStep.Step1Pcp || a.AssignmentStep == AssignmentStep.Step2Specialist));

        var totalProviders = _db.Providers.Count();

        var measureRows = _db.QualityMeasureResults
            .Where(q => q.PerformanceYear == year)
            .Select(q => new { q.ProviderId, q.PercentilePerformance })
            .ToList();

        var perProviderRounded = measureRows
            .GroupBy(x => x.ProviderId)
            .Select(g => Math.Round(g.Average(x => x.PercentilePerformance), 4, MidpointRounding.AwayFromZero))
            .ToList();

        decimal averageQualityScore = perProviderRounded.Count == 0
            ? 0m
            : Math.Round(perProviderRounded.Average(), 4, MidpointRounding.AwayFromZero);

        var settlements = _db.SharedSavingsSettlements
            .Where(s => s.PerformanceYear == year)
            .OrderBy(s => s.Id)
            .Select(s => new
            {
                track = s.Track.ToString(),
                earnedSavings = s.EarnedSavings,
                earnedLosses = s.EarnedLosses,
            })
            .ToList();

        var payload = new
        {
            performanceYear = year,
            totalAttributedBeneficiaries = totalAttributed,
            totalProviders = totalProviders,
            averageQualityScore = averageQualityScore,
            settlements = settlements,
        };

        var payloadJson = JsonSerializer.Serialize(payload, _jsonOptions);
        _db.RegulatoryReports.Add(new RegulatoryReport
        {
            PerformanceYear = year,
            ReportType = ReportType.CmsMsspSubmission,
            GeneratedAtUtc = DateTime.UtcNow,
            PayloadJson = payloadJson,
        });
        _db.SaveChanges();

        return Ok(payload);
    }

    [HttpPost("state-public-health")]
    public IActionResult GenerateStatePublicHealth([FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryInt(body, "performanceYear", out var year, out var err))
            return JsonValidator.BadRequest(err!);

        var openCdm = _db.CareEpisodes.Count(e =>
            e.EpisodeType == EpisodeType.ChronicDiseaseManagement && e.Status == EpisodeStatus.Open);
        var openPostAcute = _db.CareEpisodes.Count(e =>
            e.EpisodeType == EpisodeType.PostAcuteTransition && e.Status == EpisodeStatus.Open);
        var escalated = _db.CareEpisodes.Count(e => e.Status == EpisodeStatus.Escalated);

        var payload = new
        {
            performanceYear = year,
            openChronicDiseaseEpisodes = openCdm,
            openPostAcuteEpisodes = openPostAcute,
            escalatedEpisodes = escalated,
        };

        var payloadJson = JsonSerializer.Serialize(payload, _jsonOptions);
        _db.RegulatoryReports.Add(new RegulatoryReport
        {
            PerformanceYear = year,
            ReportType = ReportType.StatePublicHealth,
            GeneratedAtUtc = DateTime.UtcNow,
            PayloadJson = payloadJson,
        });
        _db.SaveChanges();

        return Ok(payload);
    }
}
