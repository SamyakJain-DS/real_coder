using System.Text.Json;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Helpers;
using Aco.Mssp.Api.Models;
using Microsoft.AspNetCore.Mvc;

namespace Aco.Mssp.Api.Controllers;

/// <summary>
/// REST endpoints for the care coordination workflow: opening chronic
/// disease management or post-acute transition episodes and progressing them
/// through the documented Open / Closed / Escalated state machine.
/// </summary>
[ApiController]
[Route("api/care-coordination/episodes")]
public class CareCoordinationController : ControllerBase
{
    private readonly AcoDbContext _db;

    /// <summary>Creates a new controller. The <paramref name="db"/> is supplied by DI.</summary>
    public CareCoordinationController(AcoDbContext db) => _db = db;

    /// <summary>
    /// Opens a new <see cref="CareEpisode"/> in the <c>Open</c> state with
    /// <c>endDate = null</c>. Returns 201 on success, 404 when the
    /// referenced beneficiary does not exist, or 409 when an open episode of
    /// the same type already exists for the beneficiary.
    /// </summary>
    [HttpPost]
    public IActionResult OpenEpisode([FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryInt(body, "beneficiaryId", out var benId, out var err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryEnum<EpisodeType>(body, "episodeType", out var episodeType, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDateOnly(body, "startDate", out var startDate, out err))
            return JsonValidator.BadRequest(err!);

        if (!_db.Beneficiaries.Any(b => b.Id == benId))
            return JsonValidator.NotFound($"Beneficiary with id {benId} not found.");

        var existingOpen = _db.CareEpisodes.Any(e =>
            e.BeneficiaryId == benId
            && e.EpisodeType == episodeType
            && e.Status == EpisodeStatus.Open);
        if (existingOpen)
            return JsonValidator.Conflict($"An open '{episodeType}' episode already exists for beneficiary {benId}.");

        var entity = new CareEpisode
        {
            BeneficiaryId = benId,
            EpisodeType = episodeType,
            StartDate = startDate,
            EndDate = null,
            Status = EpisodeStatus.Open,
        };
        _db.CareEpisodes.Add(entity);
        _db.SaveChanges();

        return new ObjectResult(Project(entity)) { StatusCode = StatusCodes.Status201Created };
    }

    /// <summary>
    /// Transitions an existing episode through the documented state machine:
    /// Open → Closed (with valid endDate), Open → Escalated (null endDate),
    /// or Escalated → Closed. Any other transition (or any update against an
    /// already-Closed episode) returns 409 and leaves state unchanged.
    /// Returns 404 when the episode does not exist.
    /// </summary>
    [HttpPatch("{id:int}")]
    public IActionResult UpdateEpisode(int id, [FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryEnum<EpisodeStatus>(body, "targetStatus", out var target, out var err))
            return JsonValidator.BadRequest(err!);
        if (target != EpisodeStatus.Closed && target != EpisodeStatus.Escalated)
            return JsonValidator.BadRequest("Field 'targetStatus' must be 'Closed' or 'Escalated'.");

        if (!JsonValidator.TryNullableDateOnly(body, "endDate", out var endDate, out err))
            return JsonValidator.BadRequest(err!);

        var episode = _db.CareEpisodes.FirstOrDefault(e => e.Id == id);
        if (episode is null)
            return JsonValidator.NotFound($"Care episode with id {id} not found.");

        // Any transition against an already-Closed episode is rejected.
        if (episode.Status == EpisodeStatus.Closed)
            return JsonValidator.Conflict($"Episode {id} is already Closed and cannot be modified.");

        if (target == EpisodeStatus.Closed)
        {
            if (endDate is null || endDate < episode.StartDate)
                return JsonValidator.Conflict($"Closing episode {id} requires an endDate on or after the startDate.");
            // Allowed: Open → Closed, Escalated → Closed.
            episode.Status = EpisodeStatus.Closed;
            episode.EndDate = endDate;
            _db.SaveChanges();
            return Ok(Project(episode));
        }

        if (target == EpisodeStatus.Escalated)
        {
            if (endDate is not null)
                return JsonValidator.Conflict($"Escalating episode {id} must not include an endDate.");
            // Allowed: Open → Escalated. Escalated → Escalated is rejected (only Open can transition).
            if (episode.Status != EpisodeStatus.Open)
                return JsonValidator.Conflict($"Episode {id} cannot transition from {episode.Status} to Escalated.");
            episode.Status = EpisodeStatus.Escalated;
            episode.EndDate = null;
            _db.SaveChanges();
            return Ok(Project(episode));
        }

        return JsonValidator.Conflict($"Transition for episode {id} is not allowed.");
    }

    private static object Project(CareEpisode e) => new
    {
        id = e.Id,
        beneficiaryId = e.BeneficiaryId,
        episodeType = e.EpisodeType.ToString(),
        startDate = e.StartDate.ToString("yyyy-MM-dd"),
        endDate = e.EndDate?.ToString("yyyy-MM-dd"),
        status = e.Status.ToString(),
    };
}
