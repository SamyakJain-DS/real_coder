using System.Text.Json;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Helpers;
using Aco.Mssp.Api.Models;
using Microsoft.AspNetCore.Mvc;

namespace Aco.Mssp.Api.Controllers;

/// <summary>
/// REST endpoints for managing Medicare beneficiaries attributed to the ACO.
/// </summary>
[ApiController]
[Route("api/beneficiaries")]
public class BeneficiariesController : ControllerBase
{
    private readonly AcoDbContext _db;

    /// <summary>Creates a new controller. The <paramref name="db"/> is supplied by DI.</summary>
    public BeneficiariesController(AcoDbContext db) => _db = db;

    /// <summary>
    /// Persists a new <see cref="Beneficiary"/>. Validates the medicareId
    /// length/uniqueness and the enrollmentStartDate per the documented
    /// rules. Returns the created row with HTTP 201, HTTP 400 for validation
    /// failures, or HTTP 409 when the medicareId is already taken.
    /// </summary>
    [HttpPost]
    public IActionResult Create([FromBody] JsonElement body)
    {
        if (!JsonValidator.IsObject(body))
            return JsonValidator.BadRequest("Request body must be a JSON object.");

        if (!JsonValidator.TryString(body, "medicareId", out var medicareId, out var err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryString(body, "firstName", out var firstName, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryString(body, "lastName", out var lastName, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDateOnly(body, "dateOfBirth", out var dob, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDecimal(body, "hccRiskScore", out var hcc, out err))
            return JsonValidator.BadRequest(err!);
        if (!JsonValidator.TryDateOnly(body, "enrollmentStartDate", out var enrollStart, out err))
            return JsonValidator.BadRequest(err!);

        if ((medicareId ?? string.Empty).Length != 11)
            return JsonValidator.BadRequest("Field 'medicareId' must be exactly 11 characters.");

        var todayUtc = DateOnly.FromDateTime(DateTime.UtcNow);
        if (enrollStart > todayUtc)
            return JsonValidator.BadRequest("Field 'enrollmentStartDate' must be on or before today (UTC).");

        if (_db.Beneficiaries.Any(b => b.MedicareId == medicareId))
            return JsonValidator.Conflict($"A beneficiary with medicareId '{medicareId}' already exists.");

        var entity = new Beneficiary
        {
            MedicareId = medicareId!,
            FirstName = firstName!,
            LastName = lastName!,
            DateOfBirth = dob,
            HccRiskScore = hcc,
            EnrollmentStartDate = enrollStart,
            EnrollmentEndDate = null,
        };
        _db.Beneficiaries.Add(entity);
        _db.SaveChanges();

        return new ObjectResult(Project(entity)) { StatusCode = StatusCodes.Status201Created };
    }

    private static object Project(Beneficiary b) => new
    {
        id = b.Id,
        medicareId = b.MedicareId,
        firstName = b.FirstName,
        lastName = b.LastName,
        dateOfBirth = b.DateOfBirth.ToString("yyyy-MM-dd"),
        hccRiskScore = b.HccRiskScore,
        enrollmentStartDate = b.EnrollmentStartDate.ToString("yyyy-MM-dd"),
        enrollmentEndDate = b.EnrollmentEndDate?.ToString("yyyy-MM-dd"),
    };
}
