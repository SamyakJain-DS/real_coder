using System.Text.Json;
using System.Text.Json.Serialization;
using Aco.Mssp.Api.Data;
using Aco.Mssp.Api.Seeding;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AcoDbContext>(o => o.UseSqlite("Data Source=aco.db"));

builder.Services
    .AddControllers()
    .AddJsonOptions(opts =>
    {
        opts.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        opts.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
        opts.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.Never;
        opts.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    });

builder.Services.Configure<ApiBehaviorOptions>(o =>
{
    o.SuppressModelStateInvalidFilter = true;
});

var app = builder.Build();

// Funnel any unhandled exception into the documented `{ "error": string }` envelope.
app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async ctx =>
    {
        var feature = ctx.Features.Get<IExceptionHandlerFeature>();
        ctx.Response.ContentType = "application/json";
        var ex = feature?.Error;
        if (ex is BadHttpRequestException bad)
        {
            ctx.Response.StatusCode = bad.StatusCode;
        }
        else if (ex is JsonException)
        {
            ctx.Response.StatusCode = StatusCodes.Status400BadRequest;
        }
        else
        {
            ctx.Response.StatusCode = StatusCodes.Status500InternalServerError;
        }

        var msg = ex?.Message ?? "Unhandled error.";
        var payload = JsonSerializer.Serialize(new { error = msg });
        await ctx.Response.WriteAsync(payload);
    });
});

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AcoDbContext>();
    db.Database.EnsureCreated();
    SeedRunner.Run(db, app.Environment);
}

app.MapControllers();

app.Run();
