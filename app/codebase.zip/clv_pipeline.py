"""
Customer Lifetime Value (CLV) Prediction Pipeline
==================================================
Ingests historical customer transaction records, engineers behavioural
features, trains probabilistic BG/NBD + Gamma-Gamma models, generates
individual CLV estimates over a configurable future time horizon, and
segments customers into actionable value tiers with per-tier retention
recommendations.

All processing runs entirely offline using the bundled local dataset.
No external API calls or live data downloads are performed.
"""

from __future__ import annotations

from typing import Dict

import numpy as np
import pandas as pd
from autograd import value_and_grad
from autograd import hessian as _autograd_hessian
from lifetimes import BetaGeoFitter, GammaGammaFitter
from scipy.optimize import minimize as _scipy_minimize


# ---------------------------------------------------------------------------
# Internal helpers – robust model fitting via subclasses
# ---------------------------------------------------------------------------

def _robust_fit(self, minimizing_function_args, initial_params,
                params_size, disp, tol: float = 1e-7,
                bounds=None, **kwargs):
    """Override for ``BaseFitter._fit`` that does not raise
    ``ConvergenceError`` when the optimiser fails to reach the desired
    tolerance.  The best-found parameter vector is used instead, which is
    sufficient for prediction even when the log-likelihood surface is flat
    (as it often is on very small datasets).
    """
    x0 = (0.1 * np.ones(params_size)
          if initial_params is None else initial_params)
    output = _scipy_minimize(
        value_and_grad(self._negative_log_likelihood),
        jac=True,
        method=None,
        tol=tol,
        x0=x0,
        args=minimizing_function_args,
        options={"disp": False},
        bounds=bounds,
    )
    try:
        hessian_ = _autograd_hessian(self._negative_log_likelihood)(
            output.x, *minimizing_function_args
        )
    except Exception:
        hessian_ = np.eye(params_size)
    return output.x, output.fun, hessian_


class _RobustBetaGeoFitter(BetaGeoFitter):
    """BetaGeoFitter that uses best-found parameters on non-convergence."""
    _fit = _robust_fit


class _RobustGammaGammaFitter(GammaGammaFitter):
    """GammaGammaFitter that uses best-found parameters on non-convergence."""
    _fit = _robust_fit


# ---------------------------------------------------------------------------
# 1. Transaction Loader
# ---------------------------------------------------------------------------

def load_transactions(filepath: str) -> pd.DataFrame:
    """Read transaction records from a local CSV file.

    Parameters
    ----------
    filepath : str
        Path to the CSV file.  Must contain the columns:
        ``customer_id``, ``transaction_date``, ``order_value``,
        ``product_category``.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns:
        - ``customer_id``          – str
        - ``transaction_date``     – datetime64[ns]
        - ``order_value``          – float64
        - ``product_category``     – str (object)
    """
    df = pd.read_csv(filepath)

    required_columns = {"customer_id", "transaction_date",
                        "order_value", "product_category"}
    missing = required_columns - set(df.columns)
    if missing:
        raise ValueError(
            f"transactions CSV is missing required column(s): {missing}"
        )

    df["transaction_date"] = pd.to_datetime(df["transaction_date"])
    df["order_value"] = df["order_value"].astype(float)
    df["customer_id"] = df["customer_id"].astype(str)
    df["product_category"] = df["product_category"].astype(str)

    return df[["customer_id", "transaction_date",
               "order_value", "product_category"]]


# ---------------------------------------------------------------------------
# 2. Feature Engineer
# ---------------------------------------------------------------------------

def engineer_features(transactions: pd.DataFrame) -> pd.DataFrame:
    """Compute per-customer behavioural features from raw transactions.

    The observation period end date is derived from the maximum
    ``transaction_date`` found in ``transactions``.

    Parameters
    ----------
    transactions : pd.DataFrame
        Output of :func:`load_transactions`.

    Returns
    -------
    pd.DataFrame
        DataFrame **indexed by** ``customer_id`` with columns:

        - ``frequency``          (int)   – repeat purchase count (total − 1)
        - ``recency``            (float) – days between first and last purchase
        - ``T``                  (float) – days from first purchase to
                                            observation period end
        - ``monetary_value``     (float) – mean order value of repeat purchases;
                                            equals single observed order value
                                            for one-time buyers
        - ``category_diversity`` (int)   – distinct product categories purchased
        - ``seasonal_score``     (float) – coefficient of variation of monthly
                                            purchase counts; 0.0 when < 2 purchases
    """
    observation_end: pd.Timestamp = transactions["transaction_date"].max()

    # Sort once; cumcount gives 0-based chronological rank per customer
    txns = transactions.sort_values(
        ["customer_id", "transaction_date"]
    ).copy()
    txns["_rank"] = txns.groupby("customer_id").cumcount()
    txns["_month"] = txns["transaction_date"].dt.to_period("M")

    # ------------------------------------------------------------------
    # Vectorised aggregations: frequency, recency, T, category_diversity
    # ------------------------------------------------------------------
    agg = txns.groupby("customer_id").agg(
        _n_purchases=("transaction_date", "count"),
        _first_date=("transaction_date", "min"),
        _last_date=("transaction_date", "max"),
        category_diversity=("product_category", "nunique"),
    )

    agg["frequency"] = (agg["_n_purchases"] - 1).astype(int)
    agg["recency"] = (
        (agg["_last_date"] - agg["_first_date"]).dt.days.astype(float)
    )
    agg["T"] = (
        (observation_end - agg["_first_date"]).dt.days.astype(float)
    )

    # ------------------------------------------------------------------
    # monetary_value
    # Repeat buyers  → mean of all transactions except the first (rank > 0)
    # One-time buyers → their single observed order value (rank == 0)
    # ------------------------------------------------------------------
    monetary_repeat = (
        txns[txns["_rank"] > 0]
        .groupby("customer_id")["order_value"]
        .mean()
    )
    monetary_first = (
        txns[txns["_rank"] == 0]
        .set_index("customer_id")["order_value"]
    )
    # combine_first: use repeat mean where available, fall back to first value
    agg["monetary_value"] = (
        monetary_repeat.combine_first(monetary_first).astype(float)
    )

    # ------------------------------------------------------------------
    # seasonal_score – CV of monthly purchase counts
    # Groups transactions by (customer, calendar month) then computes
    # std / mean; NaN std (single distinct month) resolves to 0.0.
    # Customers with fewer than 2 purchases are set to 0.0 per spec.
    # ------------------------------------------------------------------
    monthly_counts = txns.groupby(["customer_id", "_month"]).size()
    cv_stats = monthly_counts.groupby("customer_id").agg(
        _mean="mean", _std="std"          # std uses ddof=1 (pandas default)
    )
    seasonal_raw = (cv_stats["_std"] / cv_stats["_mean"]).fillna(0.0)

    # Enforce spec: 0.0 for customers with < 2 total purchases
    ss = seasonal_raw.reindex(agg.index).fillna(0.0)
    agg["seasonal_score"] = ss.where(
        agg["_n_purchases"] >= 2, 0.0
    ).astype(float)

    result = agg[[
        "frequency", "recency", "T",
        "monetary_value", "category_diversity", "seasonal_score",
    ]].copy()
    result.index.name = "customer_id"
    return result


# ---------------------------------------------------------------------------
# 3. BG/NBD Model Trainer
# ---------------------------------------------------------------------------

def train_bgnbd_model(
    features_df: pd.DataFrame,
    penalizer_coef: float = 0.001,
) -> BetaGeoFitter:
    """Fit a BG/NBD (Beta-Geometric / Negative Binomial Distribution) model.

    Parameters
    ----------
    features_df : pd.DataFrame
        Output of :func:`engineer_features`; must contain ``frequency``,
        ``recency``, and ``T`` columns.
    penalizer_coef : float, optional
        L2 regularisation penalty for the BG/NBD optimiser (default 0.001).

    Returns
    -------
    BetaGeoFitter
        Fitted BG/NBD model object ready for prediction.
    """
    bgf = _RobustBetaGeoFitter(penalizer_coef=penalizer_coef)
    bgf.fit(
        frequency=features_df["frequency"],
        recency=features_df["recency"],
        T=features_df["T"],
    )
    return bgf


# ---------------------------------------------------------------------------
# 4. Gamma-Gamma Model Trainer
# ---------------------------------------------------------------------------

def train_gamma_gamma_model(
    features_df: pd.DataFrame,
    penalizer_coef: float = 0.001,
) -> GammaGammaFitter:
    """Fit a Gamma-Gamma spend model on repeat buyers.

    Parameters
    ----------
    features_df : pd.DataFrame
        Output of :func:`engineer_features`; must contain ``frequency``
        and ``monetary_value`` columns.
    penalizer_coef : float, optional
        L2 regularisation penalty for the Gamma-Gamma optimiser
        (default 0.001).

    Returns
    -------
    GammaGammaFitter
        Fitted Gamma-Gamma model object ready for prediction.
    """
    repeat_buyers = features_df[features_df["frequency"] > 0].copy()

    ggf = _RobustGammaGammaFitter(penalizer_coef=penalizer_coef)
    ggf.fit(
        frequency=repeat_buyers["frequency"],
        monetary_value=repeat_buyers["monetary_value"],
    )
    return ggf


# ---------------------------------------------------------------------------
# 5. CLV Predictor
# ---------------------------------------------------------------------------

def predict_clv(
    bgnbd_model: BetaGeoFitter,
    gg_model: GammaGammaFitter,
    features_df: pd.DataFrame,
    time_horizon: float = 12,
    discount_rate: float = 0.01,
) -> pd.DataFrame:
    """Compute Customer Lifetime Value for every customer.

    Parameters
    ----------
    bgnbd_model : BetaGeoFitter
        Fitted BG/NBD model (from :func:`train_bgnbd_model`).
    gg_model : GammaGammaFitter
        Fitted Gamma-Gamma model (from :func:`train_gamma_gamma_model`).
    features_df : pd.DataFrame
        Output of :func:`engineer_features`.
    time_horizon : float, optional
        Number of months into the future to project CLV (default 12).
    discount_rate : float, optional
        Monthly discount rate applied when computing present-value CLV
        (default 0.01, i.e. 1 % per month).

    Returns
    -------
    pd.DataFrame
        DataFrame **indexed by** ``customer_id`` with columns:

        - ``predicted_purchases``      (float, >= 0)
        - ``expected_avg_order_value`` (float, >= 0)
        - ``clv``                      (float, >= 0)
        - ``probability_alive``        (float, 0.0 – 1.0)
    """
    # -----------------------------------------------------------------------
    # Predicted number of purchases over the time horizon
    # -----------------------------------------------------------------------
    n_months: int = max(1, int(time_horizon))
    predicted_purchases = pd.Series(0.0, index=features_df.index)
    prev_cumulative = pd.Series(0.0, index=features_df.index)

    for month in range(1, n_months + 1):
        t_month = float(month) * 30.0
        current = bgnbd_model.conditional_expected_number_of_purchases_up_to_time(
            t=t_month,
            frequency=features_df["frequency"],
            recency=features_df["recency"],
            T=features_df["T"],
        )
        delta = (current - prev_cumulative).clip(lower=0.0).fillna(0.0)
        predicted_purchases = predicted_purchases + delta
        prev_cumulative = current.where(current.notna(), prev_cumulative)

    predicted_purchases = predicted_purchases.clip(lower=0.0)

    # -----------------------------------------------------------------------
    # Probability alive
    # -----------------------------------------------------------------------
    probability_alive: pd.Series = bgnbd_model.conditional_probability_alive(
        frequency=features_df["frequency"],
        recency=features_df["recency"],
        T=features_df["T"],
    ).clip(0.0, 1.0)

    # -----------------------------------------------------------------------
    # Expected average order value (Gamma-Gamma)
    # -----------------------------------------------------------------------
    repeat_mask: pd.Series = features_df["frequency"] > 0
    repeat_buyers: pd.DataFrame = features_df[repeat_mask]

    gg_expected_value: pd.Series = gg_model.conditional_expected_average_profit(
        frequency=repeat_buyers["frequency"],
        monetary_value=repeat_buyers["monetary_value"],
    ).clip(lower=0.0)

    expected_avg_order_value: pd.Series = (
        features_df["monetary_value"].copy().astype(float)
    )
    expected_avg_order_value.loc[repeat_buyers.index] = gg_expected_value

    # -----------------------------------------------------------------------
    # CLV
    # -----------------------------------------------------------------------
    clv = pd.Series(0.0, index=features_df.index, dtype=float)

    if repeat_buyers.shape[0] > 0:
        gg_clv: pd.Series = gg_model.customer_lifetime_value(
            transaction_prediction_model=bgnbd_model,
            frequency=repeat_buyers["frequency"],
            recency=repeat_buyers["recency"],
            T=repeat_buyers["T"],
            monetary_value=repeat_buyers["monetary_value"],
            time=time_horizon,
            discount_rate=discount_rate,
        ).clip(lower=0.0)
        clv.loc[repeat_buyers.index] = gg_clv

    one_time_mask: pd.Series = ~repeat_mask
    if one_time_mask.any():
        one_time_idx = features_df[one_time_mask].index
        clv.loc[one_time_idx] = (
            predicted_purchases.loc[one_time_idx]
            * features_df.loc[one_time_idx, "monetary_value"]
        ).clip(lower=0.0)

    clv = clv.clip(lower=0.0).fillna(0.0)

    return pd.DataFrame(
        {
            "predicted_purchases": predicted_purchases,
            "expected_avg_order_value": expected_avg_order_value,
            "clv": clv,
            "probability_alive": probability_alive,
        },
        index=features_df.index,
    )


# ---------------------------------------------------------------------------
# 6. Customer Segmenter
# ---------------------------------------------------------------------------

def segment_customers(clv_df: pd.DataFrame) -> pd.DataFrame:
    """Assign every customer to a CLV-based value tier.

    Tiers are derived from quantile thresholds on the ``clv`` column.
    Ties at quantile boundaries are assigned to the **higher** tier
    (>= lower-bound convention).

    Parameters
    ----------
    clv_df : pd.DataFrame
        Output of :func:`predict_clv`; must contain a ``clv`` column.

    Returns
    -------
    pd.DataFrame
        The input DataFrame with an additional ``segment`` column whose
        values are exactly one of:
        ``"Champions"``, ``"Loyal"``, ``"At-Risk"``, ``"Lost Causes"``.
    """
    clv_series: pd.Series = clv_df["clv"]

    q25 = clv_series.quantile(0.25)
    q50 = clv_series.quantile(0.50)
    q75 = clv_series.quantile(0.75)

    def _assign_tier(value: float) -> str:
        if value >= q75:
            return "Champions"
        if value >= q50:
            return "Loyal"
        if value >= q25:
            return "At-Risk"
        return "Lost Causes"

    clv_df = clv_df.copy()
    clv_df["segment"] = clv_series.apply(_assign_tier)
    return clv_df


# ---------------------------------------------------------------------------
# 7. Retention Recommendation Provider
# ---------------------------------------------------------------------------

def get_retention_recommendations() -> Dict[str, str]:
    """Return actionable retention recommendations for each customer tier.

    Returns
    -------
    dict[str, str]
        Exactly four keys – ``"Champions"``, ``"Loyal"``, ``"At-Risk"``,
        ``"Lost Causes"`` – each mapped to a non-empty actionable
        recommendation string.
    """
    return {
        "Champions": (
            "Reward top spenders with an exclusive VIP loyalty programme, "
            "early access to new product launches, and personalised thank-you "
            "outreach from an account manager.  Invite them to beta-test new "
            "features and solicit reviews to build social proof."
        ),
        "Loyal": (
            "Deepen engagement through a tiered points programme that rewards "
            "cross-category exploration.  Send personalised bundle "
            "recommendations based on past purchase history and offer a "
            "moderate loyalty discount on their next purchase to encourage "
            "regular re-engagement."
        ),
        "At-Risk": (
            "Re-engage with a time-limited win-back offer (e.g. 15 % off their "
            "most-purchased category) and a brief satisfaction survey to "
            "surface any service issues.  Follow up with a curated 'You might "
            "also like' email sequence tailored to their browsing history."
        ),
        "Lost Causes": (
            "Run a low-cost reactivation campaign – a single personalised "
            "email with a compelling discount or free-shipping threshold – "
            "then suppress from costly outreach if there is no response "
            "within 30 days.  Focus retention budget on higher-value "
            "segments instead."
        ),
    }


# ---------------------------------------------------------------------------
# 8. End-to-End Pipeline Runner
# ---------------------------------------------------------------------------

def run_pipeline(
    data_path: str = "data/transactions.csv",
    time_horizon: float = 12,
    discount_rate: float = 0.01,
) -> pd.DataFrame:
    """Execute the full CLV pipeline end-to-end.

    Steps
    -----
    1. Load transactions from ``data_path``.
    2. Engineer per-customer features.
    3. Train BG/NBD model.
    4. Train Gamma-Gamma model.
    5. Predict CLV for every customer.
    6. Segment customers into value tiers.
    7. Join engineered features onto the output DataFrame.

    Parameters
    ----------
    data_path : str, optional
        Path to the transactions CSV (default ``"data/transactions.csv"``).
    time_horizon : float, optional
        Projection horizon in months (default 12).
    discount_rate : float, optional
        Monthly discount rate (default 0.01).

    Returns
    -------
    pd.DataFrame
        DataFrame **indexed by** ``customer_id`` with columns:

        ``predicted_purchases``, ``expected_avg_order_value``, ``clv``,
        ``probability_alive``, ``segment``,
        ``frequency``, ``recency``, ``T``, ``monetary_value``,
        ``category_diversity``, ``seasonal_score``.
    """
    transactions: pd.DataFrame = load_transactions(data_path)
    features_df: pd.DataFrame = engineer_features(transactions)
    bgnbd_model: BetaGeoFitter = train_bgnbd_model(features_df)
    gg_model: GammaGammaFitter = train_gamma_gamma_model(features_df)
    clv_df: pd.DataFrame = predict_clv(
        bgnbd_model=bgnbd_model,
        gg_model=gg_model,
        features_df=features_df,
        time_horizon=time_horizon,
        discount_rate=discount_rate,
    )
    clv_df = segment_customers(clv_df)
    result: pd.DataFrame = clv_df.join(features_df, how="left")

    ordered_columns = [
        "predicted_purchases", "expected_avg_order_value", "clv",
        "probability_alive", "segment",
        "frequency", "recency", "T",
        "monetary_value", "category_diversity", "seasonal_score",
    ]
    return result[ordered_columns]