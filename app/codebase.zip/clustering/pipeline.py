import os
import io
import base64
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.colors import ListedColormap
from scipy.cluster.hierarchy import dendrogram
from sklearn.decomposition import PCA

from clustering.preprocessing import preprocess_data
from clustering.clustering import run_kmeans, run_dbscan, run_agglomerative, run_gmm
from clustering.selection import select_k
from clustering.evaluation import evaluate_clustering
from clustering.profiling import profile_clusters


def _fig_to_base64(fig) -> str:
    """Convert a matplotlib figure to a base64-encoded PNG string."""
    buf = io.BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight', dpi=100)
    buf.seek(0)
    img_data = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()
    plt.close(fig)
    return img_data


def _plot_elbow(k_range: list, inertias: list) -> str:
    """Generate elbow plot of K-Means inertia against k."""
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(k_range, inertias, marker='o', linewidth=2, color='steelblue')
    ax.set_xlabel('Number of Clusters (k)', fontsize=12)
    ax.set_ylabel('Inertia', fontsize=12)
    ax.set_title('Elbow Plot: K-Means Inertia vs k', fontsize=14)
    ax.set_xticks(k_range)
    ax.grid(True, alpha=0.3)
    return _fig_to_base64(fig)


def _plot_silhouette_bars(k_range: list,
                          silhouette_samples_per_k: list,
                          silhouette_scores: list,
                          labels_per_k: list) -> list:
    """Generate per-cluster silhouette bar plots for each k in k_range."""
    images = []
    for idx, k in enumerate(k_range):
        sil_samples = silhouette_samples_per_k[idx]
        sil_score = silhouette_scores[idx]

        if np.any(np.isnan(sil_samples)):
            # Cannot plot silhouette for k=1
            fig, ax = plt.subplots(figsize=(8, 5))
            ax.set_title(f'Silhouette Plot for k={k} (not available for k=1)', fontsize=14)
            ax.text(0.5, 0.5, 'Silhouette score not defined for k=1',
                    ha='center', va='center', transform=ax.transAxes, fontsize=12)
            images.append(_fig_to_base64(fig))
            continue

        # Use pre-computed labels — no KMeans re-fit needed
        labels = labels_per_k[idx]

        fig, ax = plt.subplots(figsize=(8, 5))
        y_lower = 10
        colors = cm.nipy_spectral(np.linspace(0, 1, k))

        for cluster_idx in range(k):
            cluster_sil = sil_samples[labels == cluster_idx]
            cluster_sil.sort()
            size = len(cluster_sil)
            y_upper = y_lower + size
            ax.fill_betweenx(np.arange(y_lower, y_upper), 0, cluster_sil,
                             facecolor=colors[cluster_idx], alpha=0.7)
            ax.text(-0.05, y_lower + 0.5 * size, str(cluster_idx), fontsize=9)
            y_lower = y_upper + 10

        ax.axvline(x=sil_score, color='red', linestyle='--',
                   label=f'Mean silhouette = {sil_score:.3f}')
        ax.set_xlabel('Silhouette Coefficient', fontsize=12)
        ax.set_ylabel('Cluster', fontsize=12)
        ax.set_title(f'Per-Cluster Silhouette Plot for k={k}', fontsize=14)
        ax.legend(loc='upper right')
        ax.set_yticks([])
        images.append(_fig_to_base64(fig))

    return images


def _plot_dendrogram(linkage_matrix: np.ndarray, truncate_level: int) -> str:
    """Generate dendrogram for agglomerative clustering."""
    fig, ax = plt.subplots(figsize=(12, 6))
    dendrogram(
        linkage_matrix,
        truncate_mode='lastp',
        p=truncate_level,
        ax=ax,
        leaf_rotation=90.,
        leaf_font_size=10.
    )
    ax.set_title('Agglomerative Clustering Dendrogram', fontsize=14)
    ax.set_xlabel('Sample Index or (Cluster Size)', fontsize=12)
    ax.set_ylabel('Distance', fontsize=12)
    return _fig_to_base64(fig)


def _plot_cluster_scatter(X: np.ndarray, labels: np.ndarray,
                          algorithm_name: str) -> str:
    """
    Generate 2D scatter plot of cluster assignments projected using PCA (top 2 components)
    with cluster coloring, centroid markers, and decision boundary approximations.
    """
    # Project to 2D using PCA
    pca2d = PCA(n_components=2)
    X_2d = pca2d.fit_transform(X)

    unique_labels = np.unique(labels)
    n_clusters = len(unique_labels[unique_labels != -1])

    fig, ax = plt.subplots(figsize=(9, 6))

    # Build color map
    if n_clusters > 0:
        cmap = matplotlib.colormaps.get_cmap('tab10').resampled(max(n_clusters, 1))
    else:
        cmap = matplotlib.colormaps.get_cmap('tab10').resampled(1)

    # Decision boundary approximation using a mesh grid
    x_min, x_max = X_2d[:, 0].min() - 0.5, X_2d[:, 0].max() + 0.5
    y_min, y_max = X_2d[:, 1].min() - 0.5, X_2d[:, 1].max() + 0.5
    h = (x_max - x_min) / 100.0
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                          np.arange(y_min, y_max, h))

    # Use nearest centroid approach for decision boundaries
    centroids_2d = []
    centroid_labels_list = []
    for i, lbl in enumerate(unique_labels):
        if lbl == -1:
            continue
        mask = labels == lbl
        centroid = X_2d[mask].mean(axis=0)
        centroids_2d.append(centroid)
        centroid_labels_list.append(i)

    if len(centroids_2d) >= 2:
        centroids_2d_arr = np.array(centroids_2d)
        # Assign each mesh point to nearest centroid
        mesh_points = np.c_[xx.ravel(), yy.ravel()]
        # Compute distances to each centroid
        diffs = mesh_points[:, np.newaxis, :] - centroids_2d_arr[np.newaxis, :, :]
        dists = np.sqrt((diffs ** 2).sum(axis=2))
        nearest = np.argmin(dists, axis=1)
        zz = nearest.reshape(xx.shape)
        # Plot decision boundary background
        boundary_cmap = ListedColormap([cmap(i / max(n_clusters - 1, 1))
                                        for i in range(n_clusters)])
        ax.contourf(xx, yy, zz, alpha=0.15, cmap=boundary_cmap,
                    levels=np.arange(-0.5, n_clusters, 1))

    # Plot points
    label_to_color_idx = {}
    color_idx = 0
    for lbl in unique_labels:
        if lbl == -1:
            continue
        label_to_color_idx[lbl] = color_idx
        color_idx += 1

    for lbl in unique_labels:
        mask = labels == lbl
        if lbl == -1:
            ax.scatter(X_2d[mask, 0], X_2d[mask, 1],
                       c='black', s=20, marker='x', label='Noise', alpha=0.6, zorder=3)
        else:
            color = cmap(label_to_color_idx[lbl] / max(n_clusters - 1, 1))
            ax.scatter(X_2d[mask, 0], X_2d[mask, 1],
                       color=color, s=40, alpha=0.7,
                       label=f'Cluster {lbl}', zorder=3)

    # Plot centroids
    for i, lbl in enumerate(unique_labels):
        if lbl == -1:
            continue
        mask = labels == lbl
        centroid = X_2d[mask].mean(axis=0)
        color = cmap(label_to_color_idx[lbl] / max(n_clusters - 1, 1))
        ax.scatter(centroid[0], centroid[1], color=color, s=200,
                   marker='*', edgecolors='black', linewidths=1,
                   zorder=5, label=f'Centroid {lbl}')

    ax.set_xlabel('PCA Component 1', fontsize=11)
    ax.set_ylabel('PCA Component 2', fontsize=11)
    ax.set_title(f'Cluster Assignments: {algorithm_name} (PCA 2D Projection)', fontsize=13)

    # Deduplicate legend entries
    handles, legend_labels = ax.get_legend_handles_labels()
    by_label = dict(zip(legend_labels, handles))
    ax.legend(by_label.values(), by_label.keys(),
              loc='best', fontsize=8, markerscale=0.8)

    ax.grid(True, alpha=0.2)
    return _fig_to_base64(fig)


def _format_metric(val) -> str:
    """Format a metric value for display in HTML table."""
    if isinstance(val, float) and np.isnan(val):
        return 'N/A'
    if isinstance(val, float):
        return f'{val:.4f}'
    return str(val)


def _build_html_report(
        k_range: list,
        inertias: list,
        silhouette_scores: list,
        gap_statistics: list,
        eval_results: dict,
        profile_results: dict,
        elbow_img: str,
        silhouette_imgs: list,
        dendrogram_img: str,
        scatter_imgs: dict
) -> str:
    """Build the complete HTML report with all tables and visualizations."""

    html_parts = []
    html_parts.append("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clustering Analysis Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background: #f5f5f5;
            color: #333;
        }
        h1 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        h2 {
            color: #34495e;
            margin-top: 40px;
            border-left: 4px solid #3498db;
            padding-left: 10px;
        }
        h3 {
            color: #555;
            margin-top: 25px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 900px;
            margin: 15px 0;
            background: white;
            box-shadow: 0 1px 4px rgba(0,0,0,0.1);
        }
        th {
            background-color: #3498db;
            color: white;
            padding: 10px 14px;
            text-align: left;
            font-size: 13px;
        }
        td {
            padding: 9px 14px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 13px;
        }
        tr:nth-child(even) { background-color: #f9f9f9; }
        tr:hover { background-color: #eaf4fb; }
        .true-flag { color: #e74c3c; font-weight: bold; }
        .false-flag { color: #27ae60; }
        .img-container {
            margin: 20px 0;
            background: white;
            padding: 15px;
            display: inline-block;
            box-shadow: 0 1px 4px rgba(0,0,0,0.1);
            border-radius: 4px;
        }
        img {
            max-width: 100%;
            display: block;
        }
        .section-divider {
            border: none;
            border-top: 1px solid #ddd;
            margin: 30px 0;
        }
    </style>
</head>
<body>
<h1>Clustering Analysis Report</h1>
""")

    # ---- Cluster Count Selection Summary Table ----
    html_parts.append('<h2>1. Cluster Count Selection Summary</h2>')
    html_parts.append('<table>')
    html_parts.append('<tr><th>k</th><th>Inertia</th><th>Silhouette Score</th><th>Gap Statistic</th></tr>')
    for i, k in enumerate(k_range):
        sil = _format_metric(silhouette_scores[i])
        gap = _format_metric(gap_statistics[i])
        html_parts.append(
            f'<tr><td>{k}</td><td>{inertias[i]:.4f}</td><td>{sil}</td><td>{gap}</td></tr>'
        )
    html_parts.append('</table>')

    # ---- Elbow Plot ----
    html_parts.append('<h3>Elbow Plot (K-Means Inertia vs k)</h3>')
    html_parts.append(f'<div class="img-container"><img src="data:image/png;base64,{elbow_img}" alt="Elbow Plot"/></div>')

    # ---- Silhouette Bar Plots ----
    html_parts.append('<h3>Per-Cluster Silhouette Bar Plots</h3>')
    for i, k in enumerate(k_range):
        html_parts.append(f'<div class="img-container"><img src="data:image/png;base64,{silhouette_imgs[i]}" alt="Silhouette Plot k={k}"/></div>')

    html_parts.append('<hr class="section-divider"/>')

    # ---- Cluster Evaluation Comparison Table ----
    html_parts.append('<h2>2. Cluster Evaluation Comparison</h2>')
    html_parts.append('<table>')
    html_parts.append('<tr><th>Algorithm</th><th>Silhouette Score</th><th>Calinski-Harabasz Index</th><th>Davies-Bouldin Index</th></tr>')
    for algo_name, metrics in eval_results.items():
        sil = _format_metric(metrics['silhouette_score'])
        ch = _format_metric(metrics['calinski_harabasz_index'])
        db = _format_metric(metrics['davies_bouldin_index'])
        html_parts.append(
            f'<tr><td>{algo_name}</td><td>{sil}</td><td>{ch}</td><td>{db}</td></tr>'
        )
    html_parts.append('</table>')

    html_parts.append('<hr class="section-divider"/>')

    # ---- Scatter Plots ----
    html_parts.append('<h2>3. Cluster Visualization (PCA 2D Scatter Plots)</h2>')
    for algo_name, scatter_img in scatter_imgs.items():
        html_parts.append(f'<h3>{algo_name}</h3>')
        html_parts.append(f'<div class="img-container"><img src="data:image/png;base64,{scatter_img}" alt="{algo_name} Scatter"/></div>')

    # ---- Dendrogram ----
    html_parts.append('<h2>4. Agglomerative Clustering Dendrogram</h2>')
    html_parts.append(f'<div class="img-container"><img src="data:image/png;base64,{dendrogram_img}" alt="Dendrogram"/></div>')

    html_parts.append('<hr class="section-divider"/>')

    # ---- Cluster Profiling Tables ----
    html_parts.append('<h2>5. Cluster Profiling</h2>')
    for algo_name, profile_df in profile_results.items():
        html_parts.append(f'<h3>{algo_name}</h3>')
        html_parts.append('<table>')
        html_parts.append('<tr><th>Cluster</th><th>Feature</th><th>Mean</th><th>Median</th><th>Std</th><th>Significant Deviation</th></tr>')
        for _, row in profile_df.iterrows():
            dev_class = 'true-flag' if row['significant_deviation'] else 'false-flag'
            dev_text = 'Yes' if row['significant_deviation'] else 'No'
            html_parts.append(
                f'<tr>'
                f'<td>{int(row["cluster"])}</td>'
                f'<td>{row["feature"]}</td>'
                f'<td>{row["mean"]:.4f}</td>'
                f'<td>{row["median"]:.4f}</td>'
                f'<td>{row["std"]:.4f}</td>'
                f'<td class="{dev_class}">{dev_text}</td>'
                f'</tr>'
            )
        html_parts.append('</table>')

    html_parts.append('</body>\n</html>')

    return '\n'.join(html_parts)


def run_pipeline(csv_path: str, config: dict) -> tuple:
    """
    Executes the full clustering pipeline on the dataset at csv_path.

    config must contain:
        pca_variance_threshold, dbscan_min_samples, agglomerative_n_clusters,
        agglomerative_linkage, agglomerative_truncate_level, gmm_covariance_type,
        k_range, output_dir

    Returns a tuple (output_csv_path, output_html_path).
    """
    pca_variance_threshold = config['pca_variance_threshold']
    dbscan_min_samples = config['dbscan_min_samples']
    agglomerative_n_clusters = config['agglomerative_n_clusters']
    agglomerative_linkage = config['agglomerative_linkage']
    agglomerative_truncate_level = config['agglomerative_truncate_level']
    gmm_covariance_type = config['gmm_covariance_type']
    k_range = config['k_range']
    output_dir = config['output_dir']

    os.makedirs(output_dir, exist_ok=True)

    # ---- Preprocessing ----
    X = preprocess_data(csv_path, pca_variance_threshold)

    # ---- Cluster Count Selection ----
    selection_results = select_k(X, k_range)
    optimal_k = selection_results['optimal_k']
    inertias = selection_results['inertias']
    silhouette_scores = selection_results['silhouette_scores']
    silhouette_samples_per_k = selection_results['silhouette_samples_per_k']
    gap_statistics = selection_results['gap_statistics']

    labels_per_k = selection_results['labels_per_k']

    # ---- Run Clustering Algorithms ----
    kmeans_labels = run_kmeans(X, optimal_k)
    dbscan_labels = run_dbscan(X, dbscan_min_samples)
    agg_result = run_agglomerative(X, agglomerative_n_clusters, agglomerative_linkage)
    agg_labels = agg_result['labels']
    linkage_matrix = agg_result['linkage_matrix']
    gmm_labels = run_gmm(X, optimal_k, gmm_covariance_type)

    # ---- Cluster Evaluation ----
    eval_results = {
        'K-Means': evaluate_clustering(X, kmeans_labels),
        'DBSCAN': evaluate_clustering(X, dbscan_labels),
        'Agglomerative': evaluate_clustering(X, agg_labels),
        'GMM': evaluate_clustering(X, gmm_labels)
    }

    # ---- Cluster Profiling ----
    original_df = pd.read_csv(csv_path)
    numeric_cols = original_df.select_dtypes(include=[np.number]).columns.tolist()
    # Use median imputation for profiling (consistent with preprocessing)
    df_for_profiling = original_df.copy()
    for col in numeric_cols:
        df_for_profiling[col] = df_for_profiling[col].fillna(df_for_profiling[col].median())

    profile_results = {
        'K-Means': profile_clusters(df_for_profiling[numeric_cols], kmeans_labels),
        'DBSCAN': profile_clusters(df_for_profiling[numeric_cols], dbscan_labels),
        'Agglomerative': profile_clusters(df_for_profiling[numeric_cols], agg_labels),
        'GMM': profile_clusters(df_for_profiling[numeric_cols], gmm_labels)
    }

    # ---- Generate Visualizations ----

    # Elbow plot
    elbow_img = _plot_elbow(k_range, inertias)

    # Per-cluster silhouette bar plots
    silhouette_imgs = _plot_silhouette_bars(k_range, silhouette_samples_per_k,
                                            silhouette_scores, labels_per_k)

    # Dendrogram
    dendrogram_img = _plot_dendrogram(linkage_matrix, agglomerative_truncate_level)

    # 2D scatter plots
    scatter_imgs = {
        'K-Means': _plot_cluster_scatter(X, kmeans_labels, 'K-Means'),
        'DBSCAN': _plot_cluster_scatter(X, dbscan_labels, 'DBSCAN'),
        'Agglomerative': _plot_cluster_scatter(X, agg_labels, 'Agglomerative'),
        'GMM': _plot_cluster_scatter(X, gmm_labels, 'GMM')
    }

    # ---- Build HTML Report ----
    html_content = _build_html_report(
        k_range=k_range,
        inertias=inertias,
        silhouette_scores=silhouette_scores,
        gap_statistics=gap_statistics,
        eval_results=eval_results,
        profile_results=profile_results,
        elbow_img=elbow_img,
        silhouette_imgs=silhouette_imgs,
        dendrogram_img=dendrogram_img,
        scatter_imgs=scatter_imgs
    )

    # ---- Write Output Artifacts ----

    # Annotated CSV with cluster labels appended
    output_df = original_df.copy()
    output_df['cluster_kmeans'] = kmeans_labels.astype(int)
    output_df['cluster_dbscan'] = dbscan_labels.astype(int)
    output_df['cluster_agglomerative'] = agg_labels.astype(int)
    output_df['cluster_gmm'] = gmm_labels.astype(int)

    output_csv_path = os.path.join(output_dir, 'clustered_data.csv')
    output_html_path = os.path.join(output_dir, 'clustering_report.html')

    output_df.to_csv(output_csv_path, index=False)

    with open(output_html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)

    return (output_csv_path, output_html_path)