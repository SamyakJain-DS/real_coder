import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, silhouette_samples


def _compute_gap_statistic(X: np.ndarray, k: int, n_references: int = 10,
                            random_state: int = 42) -> float:
    """
    Computes the gap statistic for a given k by comparing within-cluster dispersion
    against null reference distributions.
    """
    rng = np.random.RandomState(random_state)

    def _within_cluster_dispersion(X_data: np.ndarray, labels: np.ndarray) -> float:
        dispersion = 0.0
        unique_labels = np.unique(labels)
        for label in unique_labels:
            cluster_points = X_data[labels == label]
            if len(cluster_points) > 1:
                # Sum of pairwise squared distances divided by 2 * cluster size
                from sklearn.metrics.pairwise import euclidean_distances
                dists = euclidean_distances(cluster_points)
                dispersion += np.sum(dists ** 2) / (2.0 * len(cluster_points))
        return dispersion

    # Fit K-Means on actual data
    kmeans = KMeans(n_clusters=k, init='k-means++', random_state=random_state)
    kmeans.fit(X)
    actual_labels = kmeans.labels_
    actual_dispersion = _within_cluster_dispersion(X, actual_labels)

    # Compute log of actual dispersion (avoid log(0))
    log_actual = np.log(actual_dispersion + 1e-10)

    # Generate reference datasets and compute dispersions
    ref_log_dispersions = []
    # Get the bounding box of X
    mins = X.min(axis=0)
    maxs = X.max(axis=0)

    for _ in range(n_references):
        X_ref = rng.uniform(low=mins, high=maxs, size=X.shape)
        kmeans_ref = KMeans(n_clusters=k, init='k-means++', random_state=rng.randint(0, 10000))
        kmeans_ref.fit(X_ref)
        ref_labels = kmeans_ref.labels_
        ref_dispersion = _within_cluster_dispersion(X_ref, ref_labels)
        ref_log_dispersions.append(np.log(ref_dispersion + 1e-10))

    ref_log_dispersions = np.array(ref_log_dispersions)
    gap = np.mean(ref_log_dispersions) - log_actual
    return float(gap)


def select_k(X: np.ndarray, k_range: list) -> dict:
    """
    For each k in k_range, fits K-Means (with K-Means++ initialization) and computes
    three cluster-count selection diagnostics based on the K-Means fit.
    Returns a dict with keys:
        - inertias: list[float]
        - silhouette_scores: list[float]
        - silhouette_samples_per_k: list[np.ndarray]
        - gap_statistics: list[float]
        - optimal_k: int
    """
    inertias = []
    silhouette_scores = []
    silhouette_samples_per_k = []
    gap_statistics = []
    labels_per_k = []

    for k in k_range:
        kmeans = KMeans(n_clusters=k, init='k-means++', random_state=42)
        kmeans.fit(X)
        labels = kmeans.labels_
        labels_per_k.append(labels.copy())

        # Inertia
        inertias.append(float(kmeans.inertia_))

        # Silhouette score and per-sample silhouette coefficients
        if k > 1:
            sil_score = float(silhouette_score(X, labels))
            sil_samples = silhouette_samples(X, labels)
        else:
            sil_score = float('nan')
            sil_samples = np.full(X.shape[0], float('nan'))

        silhouette_scores.append(sil_score)
        silhouette_samples_per_k.append(sil_samples)

        # Gap statistic
        gap = _compute_gap_statistic(X, k)
        gap_statistics.append(gap)

    # Determine optimal_k as the k with the highest mean silhouette score
    valid_scores = [(score, k) for score, k in zip(silhouette_scores, k_range)
                    if not (isinstance(score, float) and np.isnan(score))]
    if valid_scores:
        optimal_k = max(valid_scores, key=lambda x: x[0])[1]
    else:
        optimal_k = k_range[0]

    return {
        'inertias': inertias,
        'silhouette_scores': silhouette_scores,
        'silhouette_samples_per_k': silhouette_samples_per_k,
        'gap_statistics': gap_statistics,
        'optimal_k': optimal_k,
        'labels_per_k': labels_per_k
    }