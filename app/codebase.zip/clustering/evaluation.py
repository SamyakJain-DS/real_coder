import numpy as np
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score


def evaluate_clustering(X: np.ndarray, labels: np.ndarray) -> dict:
    """
    Computes clustering quality metrics for feature matrix X and integer cluster
    assignment array labels. Noise points (label -1) are excluded before metric
    computation. When fewer than 2 distinct non-noise clusters exist in labels,
    returns nan values. Otherwise returns silhouette_score, calinski_harabasz_index,
    and davies_bouldin_index.
    """
    # Exclude noise points (label -1)
    mask = labels != -1
    X_clean = X[mask]
    labels_clean = labels[mask]

    # Check for sufficient cluster structure
    unique_labels = np.unique(labels_clean)
    if len(unique_labels) < 2:
        return {
            'silhouette_score': float('nan'),
            'calinski_harabasz_index': float('nan'),
            'davies_bouldin_index': float('nan')
        }

    sil = float(silhouette_score(X_clean, labels_clean))
    ch = float(calinski_harabasz_score(X_clean, labels_clean))
    db = float(davies_bouldin_score(X_clean, labels_clean))

    return {
        'silhouette_score': sil,
        'calinski_harabasz_index': ch,
        'davies_bouldin_index': db
    }
