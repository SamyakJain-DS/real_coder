import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler


def preprocess_data(csv_path: str, pca_variance_threshold: float) -> np.ndarray:
    """
    Loads the CSV at csv_path. Applies median imputation for numeric columns and
    mode imputation for categorical columns. Applies z-score normalization to
    numeric features and one-hot encoding to categorical features. Applies PCA
    retaining the minimum components that explain at least pca_variance_threshold
    of total variance. Returns a 2D numpy array of shape (n_samples, n_components).
    """
    # Step 1: Load the CSV
    df = pd.read_csv(csv_path)

    # Step 2: Impute missing values
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(exclude=[np.number]).columns.tolist()

    for col in numeric_cols:
        median_val = df[col].median()
        df[col] = df[col].fillna(median_val)

    for col in categorical_cols:
        mode_val = df[col].mode()
        if len(mode_val) > 0:
            df[col] = df[col].fillna(mode_val[0])

    # Step 3: Standardize numeric features using z-score normalization
    if numeric_cols:
        scaler = StandardScaler()
        numeric_data = scaler.fit_transform(df[numeric_cols])
        numeric_df = pd.DataFrame(numeric_data, columns=numeric_cols, index=df.index)
    else:
        numeric_df = pd.DataFrame(index=df.index)

    # Step 4: Encode categorical features using one-hot encoding
    if categorical_cols:
        categorical_df = pd.get_dummies(df[categorical_cols], drop_first=False)
        categorical_df = categorical_df.astype(float)
        feature_matrix = pd.concat([numeric_df, categorical_df], axis=1)
    else:
        feature_matrix = numeric_df

    X = feature_matrix.values

    # Step 5: Apply PCA retaining minimum components for pca_variance_threshold
    pca = PCA()
    pca.fit(X)

    cumulative_variance = np.cumsum(pca.explained_variance_ratio_)
    n_components = int(np.searchsorted(cumulative_variance, pca_variance_threshold) + 1)
    n_components = min(n_components, X.shape[1])

    pca_final = PCA(n_components=n_components)
    X_pca = pca_final.fit_transform(X)

    return X_pca