import numpy as np
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.neighbors import NearestNeighbors
from scipy.cluster.hierarchy import linkage as linkage_fn


def run_kmeans(X: np.ndarray, k: int) -> np.ndarray:
    """
    Fits K-Means with K-Means++ initialization on X using k clusters.
    Returns a 1D integer numpy array of cluster labels with length X.shape[0],
    where each value is in the range [0, k).
    """
    kmeans = KMeans(n_clusters=k, init='k-means++', random_state=42)
    kmeans.fit(X)
    return kmeans.labels_.astype(int)


def run_dbscan(X: np.ndarray, min_samples: int) -> np.ndarray:
    """
    Computes k-distances using min_samples as k, identifies the elbow point as
    the estimated epsilon, and fits DBSCAN on X with the estimated epsilon and
    min_samples. Returns a 1D integer numpy array of cluster labels with length
    X.shape[0], where -1 indicates noise points.
    """
    # Compute k-distances using min_samples as k
    nbrs = NearestNeighbors(n_neighbors=min_samples)
    nbrs.fit(X)
    distances, _ = nbrs.kneighbors(X)

    # k-distance is the distance to the k-th nearest neighbor (last column)
    k_distances = distances[:, -1]
    k_distances_sorted = np.sort(k_distances)[::-1]

    # Identify the elbow point using the k-distance elbow method
    n = len(k_distances_sorted)
    # Draw line from first to last point and find the point with max distance to line
    p1 = np.array([0, k_distances_sorted[0]])
    p2 = np.array([n - 1, k_distances_sorted[-1]])
    line_vec = p2 - p1
    line_vec_norm = line_vec / np.linalg.norm(line_vec)

    distances_to_line = []
    for i in range(n):
        point = np.array([i, k_distances_sorted[i]])
        vec_from_p1 = point - p1
        proj = np.dot(vec_from_p1, line_vec_norm) * line_vec_norm
        perp = vec_from_p1 - proj
        distances_to_line.append(np.linalg.norm(perp))

    elbow_idx = int(np.argmax(distances_to_line))
    epsilon = float(k_distances_sorted[elbow_idx])

    # Fit DBSCAN with estimated epsilon and min_samples
    dbscan = DBSCAN(eps=epsilon, min_samples=min_samples)
    dbscan.fit(X)
    return dbscan.labels_.astype(int)


def run_agglomerative(X: np.ndarray, n_clusters: int, linkage: str) -> dict:
    """
    Fits agglomerative hierarchical clustering on X using n_clusters and the
    specified linkage method. Also computes the scipy linkage matrix of shape
    (n_samples - 1, 4) required for dendrogram generation.
    Returns a dict with keys 'labels' (np.ndarray) and 'linkage_matrix' (np.ndarray).
    """
    # Fit agglomerative clustering
    agg = AgglomerativeClustering(n_clusters=n_clusters, linkage=linkage)
    labels = agg.fit_predict(X).astype(int)

    # Compute scipy linkage matrix for dendrogram
    linkage_matrix = linkage_fn(X, method=linkage)

    return {
        'labels': labels,
        'linkage_matrix': linkage_matrix
    }


def run_gmm(X: np.ndarray, n_components: int, covariance_type: str) -> np.ndarray:
    """
    Fits a Gaussian Mixture Model on X with n_components components and the
    specified covariance_type. Returns a 1D integer numpy array of predicted
    cluster labels with length X.shape[0], where each value is in the range
    [0, n_components).
    """
    gmm = GaussianMixture(n_components=n_components, covariance_type=covariance_type,
                          random_state=42)
    gmm.fit(X)
    labels = gmm.predict(X).astype(int)
    return labels