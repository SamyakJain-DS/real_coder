import numpy as np
import pandas as pd


def profile_clusters(df: pd.DataFrame, labels: np.ndarray) -> pd.DataFrame:
    """
    For each unique integer label in labels, computes mean, median, and standard
    deviation for each numeric column in df. Returns a DataFrame with columns:
    cluster, feature, mean, median, std, significant_deviation.

    significant_deviation is True when the cluster mean for that feature deviates
    by more than 1.5 population standard deviations from the overall population
    mean for that feature.
    """
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()

    # Compute population mean and std for each numeric feature
    pop_means = df[numeric_cols].mean()
    pop_stds = df[numeric_cols].std()

    unique_labels = np.unique(labels)

    rows = []
    for label in unique_labels:
        label = int(label)
        cluster_mask = labels == label
        cluster_df = df[cluster_mask]

        for col in numeric_cols:
            cluster_mean = float(cluster_df[col].mean())
            cluster_median = float(cluster_df[col].median())
            cluster_std = float(cluster_df[col].std())

            # Check significant deviation: |cluster_mean - pop_mean| > 1.5 * pop_std
            pop_mean = float(pop_means[col])
            pop_std = float(pop_stds[col])

            if pop_std > 0:
                significant_deviation = bool(abs(cluster_mean - pop_mean) > 1.5 * pop_std)
            else:
                significant_deviation = False

            rows.append({
                'cluster': label,
                'feature': col,
                'mean': cluster_mean,
                'median': cluster_median,
                'std': cluster_std,
                'significant_deviation': significant_deviation
            })

    result_df = pd.DataFrame(rows, columns=['cluster', 'feature', 'mean', 'median',
                                             'std', 'significant_deviation'])
    result_df['significant_deviation'] = result_df['significant_deviation'].astype(bool)
    return result_df