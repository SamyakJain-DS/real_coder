"""Fertility treatment outcome prediction pipeline.

Implements the data ingestion, calibrated outcome models, propensity-score
based protocol effect decomposition, SART-style registry summary, and
per-couple counseling report described in the project specification.
"""

import os
import warnings

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder, StandardScaler


REQUIRED_COLUMNS = [
    "patient_id",
    "age",
    "amh",
    "fsh",
    "prior_pregnancies",
    "prior_losses",
    "bmi",
    "partner_factor",
    "protocol",
    "oocytes_retrieved",
    "fertilization_rate",
    "blastocyst_formation_rate",
    "embryo_grade",
    "transfer_type",
    "outcome_pregnancy",
    "outcome_ongoing_pregnancy",
    "outcome_live_birth",
]

FEATURE_COLS = [
    "age",
    "amh",
    "fsh",
    "prior_pregnancies",
    "prior_losses",
    "bmi",
    "partner_factor",
    "protocol",
    "oocytes_retrieved",
    "fertilization_rate",
    "blastocyst_formation_rate",
    "embryo_grade",
    "transfer_type",
]

NUMERIC_FEATURE_COLS = [
    "age",
    "amh",
    "fsh",
    "prior_pregnancies",
    "prior_losses",
    "bmi",
    "partner_factor",
    "oocytes_retrieved",
    "fertilization_rate",
    "blastocyst_formation_rate",
]

CATEGORICAL_FEATURE_COLS = ["protocol", "embryo_grade", "transfer_type"]

OUTCOME_COLS = [
    "outcome_pregnancy",
    "outcome_ongoing_pregnancy",
    "outcome_live_birth",
]

PROPENSITY_COVARIATES = [
    "age",
    "amh",
    "fsh",
    "bmi",
    "prior_pregnancies",
    "prior_losses",
    "partner_factor",
]

AGE_BANDS = [
    ("under_35", lambda a: a < 35),
    ("35_37", lambda a: (a >= 35) & (a < 38)),
    ("38_40", lambda a: (a >= 38) & (a < 41)),
    ("41_42", lambda a: (a >= 41) & (a < 43)),
    ("over_42", lambda a: a >= 43),
]

N_BOOTSTRAP = 500
WEIGHT_CLIP_LOW = 0.1
WEIGHT_CLIP_HIGH = 10.0


def load_dataset(filepath: str) -> pd.DataFrame:
    """Read the fertility cycles CSV and validate required columns.

    Raises FileNotFoundError if the file does not exist and ValueError if any
    of the required columns are missing.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Dataset file not found: {filepath}")

    df = pd.read_csv(filepath)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    return df


def _prepare_features(df: pd.DataFrame) -> pd.DataFrame:
    """Return a feature DataFrame with NaN transfer_type filled with a token."""
    out = df[FEATURE_COLS].copy()
    out["transfer_type"] = out["transfer_type"].astype(object).where(
        out["transfer_type"].notna(), "none"
    )
    out["embryo_grade"] = out["embryo_grade"].astype(object)
    out["protocol"] = out["protocol"].astype(object)
    return out


def _fit_calibrated_logreg(X, y):
    """Fit a logistic regression and a monotonic isotonic calibrator.

    Returns a tuple (base_model, isotonic_model) usable for calibrated
    probability prediction. If the bootstrap resample contains only one class
    a degenerate constant predictor is returned that emits the observed mean.
    """
    classes = np.unique(y)
    if len(classes) < 2:
        constant = float(np.mean(y))
        return ("constant", constant)

    base = LogisticRegression(max_iter=1000, solver="lbfgs")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        base.fit(X, y)
    raw = base.predict_proba(X)[:, 1]
    iso = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
    iso.fit(raw, y)
    return (base, iso)


def _predict_calibrated(model_pair, X) -> np.ndarray:
    base, iso = model_pair
    if base == "constant":
        return np.full(X.shape[0], iso, dtype=float)
    raw = base.predict_proba(X)[:, 1]
    return np.clip(iso.predict(raw), 0.0, 1.0)


class FertilityPipeline:
    """Encapsulates outcome models, propensity model, and reporting methods."""

    def __init__(self):
        self._fitted = False
        self._preprocessor = None
        self._main_models = {}
        self._bootstrap_models = {col: [] for col in OUTCOME_COLS}
        self._propensity_model = None
        self._propensity_scaler = None
        self._propensity_classes = None
        self._known_protocols = set()
        self._train_df = None
        self._ipw_rates_cache = None

    def _check_fitted(self):
        if not self._fitted:
            raise RuntimeError("FertilityPipeline.fit must be called first")

    def _validate_columns(self, df: pd.DataFrame, require_outcomes: bool):
        missing_features = [c for c in FEATURE_COLS if c not in df.columns]
        if missing_features:
            raise ValueError(f"Missing required feature columns: {missing_features}")
        if require_outcomes:
            missing_out = [c for c in OUTCOME_COLS if c not in df.columns]
            if missing_out:
                raise ValueError(f"Missing required outcome columns: {missing_out}")

    def fit(self, df: pd.DataFrame) -> None:
        self._validate_columns(df, require_outcomes=True)

        df = df.reset_index(drop=True).copy()
        self._train_df = df.copy()
        self._known_protocols = set(df["protocol"].unique())

        feat = _prepare_features(df)
        self._preprocessor = ColumnTransformer(
            transformers=[
                ("num", StandardScaler(), NUMERIC_FEATURE_COLS),
                (
                    "cat",
                    OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                    CATEGORICAL_FEATURE_COLS,
                ),
            ]
        )
        X_mat = self._preprocessor.fit_transform(feat)

        for col in OUTCOME_COLS:
            y = df[col].astype(int).values
            self._main_models[col] = _fit_calibrated_logreg(X_mat, y)

        rng = np.random.RandomState(42)
        n = len(df)
        boot_idx = rng.randint(0, n, size=(N_BOOTSTRAP, n))

        for col in OUTCOME_COLS:
            y_full = df[col].astype(int).values
            store = []
            for i in range(N_BOOTSTRAP):
                idx = boot_idx[i]
                X_boot = X_mat[idx]
                y_boot = y_full[idx]
                store.append(_fit_calibrated_logreg(X_boot, y_boot))
            self._bootstrap_models[col] = store

        self._propensity_scaler = StandardScaler()
        Xp = self._propensity_scaler.fit_transform(df[PROPENSITY_COVARIATES])
        self._propensity_model = LogisticRegression(
            max_iter=1000, solver="lbfgs"
        )
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            self._propensity_model.fit(Xp, df["protocol"].values)
        self._propensity_classes = list(self._propensity_model.classes_)

        self._ipw_rates_cache = self._compute_ipw_rates(df)

        self._fitted = True

    def _compute_ipw_rates(self, df: pd.DataFrame) -> dict:
        """Return dict protocol -> (n_cycles, unadjusted_rate, ipw_rate)."""
        Xp = self._propensity_scaler.transform(df[PROPENSITY_COVARIATES])
        proba = self._propensity_model.predict_proba(Xp)
        protocols = df["protocol"].values
        outcomes = df["outcome_live_birth"].astype(float).values

        class_idx = {c: i for i, c in enumerate(self._propensity_classes)}

        propensity_assigned = np.array(
            [
                proba[i, class_idx[protocols[i]]] if protocols[i] in class_idx else np.nan
                for i in range(len(df))
            ]
        )
        weights = 1.0 / np.where(propensity_assigned > 0, propensity_assigned, np.nan)
        weights = np.clip(weights, WEIGHT_CLIP_LOW, WEIGHT_CLIP_HIGH)

        out = {}
        for proto in pd.unique(protocols):
            mask = protocols == proto
            n = int(mask.sum())
            unadj = float(outcomes[mask].mean()) if n > 0 else 0.0
            w = weights[mask]
            y = outcomes[mask]
            if np.nansum(w) > 0:
                ipw = float(np.nansum(w * y) / np.nansum(w))
            else:
                ipw = unadj
            out[proto] = {
                "n_cycles": n,
                "unadjusted_live_birth_rate": round(unadj, 4),
                "ipw_adjusted_live_birth_rate": round(ipw, 4),
            }
        return out

    def predict_outcomes(self, patient_df: pd.DataFrame) -> pd.DataFrame:
        self._check_fitted()
        if not isinstance(patient_df, pd.DataFrame):
            patient_df = pd.DataFrame(patient_df)

        feat = _prepare_features(patient_df)
        X_mat = self._preprocessor.transform(feat)
        n_rows = X_mat.shape[0]

        preg_pe = _predict_calibrated(self._main_models["outcome_pregnancy"], X_mat)
        ong_pe = _predict_calibrated(self._main_models["outcome_ongoing_pregnancy"], X_mat)
        live_pe = _predict_calibrated(self._main_models["outcome_live_birth"], X_mat)

        ong_pe = np.minimum(ong_pe, preg_pe)
        live_pe = np.minimum(live_pe, ong_pe)

        preg_boot = np.empty((N_BOOTSTRAP, n_rows))
        ong_boot = np.empty((N_BOOTSTRAP, n_rows))
        live_boot = np.empty((N_BOOTSTRAP, n_rows))

        for i in range(N_BOOTSTRAP):
            p = _predict_calibrated(self._bootstrap_models["outcome_pregnancy"][i], X_mat)
            o = _predict_calibrated(self._bootstrap_models["outcome_ongoing_pregnancy"][i], X_mat)
            l = _predict_calibrated(self._bootstrap_models["outcome_live_birth"][i], X_mat)
            o = np.minimum(o, p)
            l = np.minimum(l, o)
            preg_boot[i] = p
            ong_boot[i] = o
            live_boot[i] = l

        preg_lo = np.percentile(preg_boot, 2.5, axis=0)
        preg_hi = np.percentile(preg_boot, 97.5, axis=0)
        ong_lo = np.percentile(ong_boot, 2.5, axis=0)
        ong_hi = np.percentile(ong_boot, 97.5, axis=0)
        live_lo = np.percentile(live_boot, 2.5, axis=0)
        live_hi = np.percentile(live_boot, 97.5, axis=0)

        preg_lo = np.minimum(preg_lo, preg_pe)
        preg_hi = np.maximum(preg_hi, preg_pe)
        ong_lo = np.minimum(ong_lo, ong_pe)
        ong_hi = np.maximum(ong_hi, ong_pe)
        live_lo = np.minimum(live_lo, live_pe)
        live_hi = np.maximum(live_hi, live_pe)

        clip01 = lambda a: np.clip(a, 0.0, 1.0)
        out = pd.DataFrame(
            {
                "pregnancy_prob": clip01(preg_pe),
                "pregnancy_ci_lower": clip01(preg_lo),
                "pregnancy_ci_upper": clip01(preg_hi),
                "ongoing_pregnancy_prob": clip01(ong_pe),
                "ongoing_pregnancy_ci_lower": clip01(ong_lo),
                "ongoing_pregnancy_ci_upper": clip01(ong_hi),
                "live_birth_prob": clip01(live_pe),
                "live_birth_ci_lower": clip01(live_lo),
                "live_birth_ci_upper": clip01(live_hi),
            }
        )
        return out

    def compute_protocol_selection_effects(self, df: pd.DataFrame) -> pd.DataFrame:
        self._check_fitted()
        rates = self._compute_ipw_rates(df)
        protocols = list(pd.unique(df["protocol"].values))
        rows = []
        for p in protocols:
            r = rates[p]
            rows.append(
                {
                    "n_cycles": int(r["n_cycles"]),
                    "unadjusted_live_birth_rate": float(r["unadjusted_live_birth_rate"]),
                    "ipw_adjusted_live_birth_rate": float(r["ipw_adjusted_live_birth_rate"]),
                }
            )
        return pd.DataFrame(rows, index=protocols)

    def generate_sart_summary(self, df: pd.DataFrame) -> dict:
        self._check_fitted()

        by_age_rows = {}
        ages = df["age"].values
        for label, predicate in AGE_BANDS:
            mask = predicate(ages)
            subset = df[mask]
            n_cycles = int(len(subset))
            n_retrievals = int((subset["oocytes_retrieved"] > 0).sum())
            n_transfers = int(subset["transfer_type"].notna().sum())
            if n_cycles > 0:
                preg_rate = round(float(subset["outcome_pregnancy"].mean()), 4)
                ong_rate = round(float(subset["outcome_ongoing_pregnancy"].mean()), 4)
                live_rate = round(float(subset["outcome_live_birth"].mean()), 4)
            else:
                preg_rate = 0.0
                ong_rate = 0.0
                live_rate = 0.0
            by_age_rows[label] = {
                "n_cycles": n_cycles,
                "n_retrievals": n_retrievals,
                "n_transfers": n_transfers,
                "pregnancy_rate": preg_rate,
                "ongoing_pregnancy_rate": ong_rate,
                "live_birth_rate": live_rate,
            }

        by_age = pd.DataFrame.from_dict(by_age_rows, orient="index")
        by_age = by_age[
            [
                "n_cycles",
                "n_retrievals",
                "n_transfers",
                "pregnancy_rate",
                "ongoing_pregnancy_rate",
                "live_birth_rate",
            ]
        ]

        by_proto_rows = {}
        for proto in pd.unique(df["protocol"].values):
            subset = df[df["protocol"] == proto]
            n_cycles = int(len(subset))
            n_transfers = int(subset["transfer_type"].notna().sum())
            preg_rate = round(float(subset["outcome_pregnancy"].mean()), 4)
            ong_rate = round(float(subset["outcome_ongoing_pregnancy"].mean()), 4)
            live_rate = round(float(subset["outcome_live_birth"].mean()), 4)
            by_proto_rows[proto] = {
                "n_cycles": n_cycles,
                "n_transfers": n_transfers,
                "pregnancy_rate": preg_rate,
                "ongoing_pregnancy_rate": ong_rate,
                "live_birth_rate": live_rate,
            }
        by_protocol = pd.DataFrame.from_dict(by_proto_rows, orient="index")
        by_protocol = by_protocol[
            [
                "n_cycles",
                "n_transfers",
                "pregnancy_rate",
                "ongoing_pregnancy_rate",
                "live_birth_rate",
            ]
        ]

        return {"by_age": by_age, "by_protocol": by_protocol}

    def generate_counseling_report(self, patient_row: pd.Series, protocol: str) -> dict:
        self._check_fitted()
        if protocol not in self._known_protocols:
            raise ValueError(
                f"Protocol '{protocol}' was not observed in the training data"
            )

        row = patient_row.copy()
        row["protocol"] = protocol
        single_df = pd.DataFrame([row])
        preds = self.predict_outcomes(single_df)

        report = {}
        outcome_keys = [
            ("pregnancy", "pregnancy"),
            ("ongoing_pregnancy", "ongoing_pregnancy"),
            ("live_birth", "live_birth"),
        ]
        for report_key, prefix in outcome_keys:
            pe = float(preds[f"{prefix}_prob"].iloc[0])
            lo = float(preds[f"{prefix}_ci_lower"].iloc[0])
            hi = float(preds[f"{prefix}_ci_upper"].iloc[0])
            high_unc = bool((hi - lo) > 0.20)
            interp = (
                f"Estimated {report_key.replace('_', ' ')} probability is "
                f"{pe:.3f} with a 95 percent confidence interval from "
                f"{lo:.3f} to {hi:.3f}."
            )
            report[report_key] = {
                "point_estimate": pe,
                "ci_lower": lo,
                "ci_upper": hi,
                "interpretation": interp,
                "high_uncertainty": high_unc,
            }

        cached = self._ipw_rates_cache.get(protocol)
        if cached is None:
            cached = self._compute_ipw_rates(self._train_df).get(protocol)
        report["protocol_effect"] = {
            "unadjusted_live_birth_rate": float(cached["unadjusted_live_birth_rate"]),
            "ipw_adjusted_live_birth_rate": float(cached["ipw_adjusted_live_birth_rate"]),
        }
        return report
