from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import relationship

from flute_shop.database import Base


class Commission(Base):
    __tablename__ = "commissions"

    id = Column(Integer, primary_key=True, index=True)
    customer_name = Column(String, nullable=False)
    instrument_type = Column(String, nullable=False)
    material = Column(String, nullable=False)
    pitch_reference = Column(String, nullable=False)
    target_key = Column(String, nullable=False)
    bore_taper = Column(String, nullable=False)
    status = Column(String, default="quoted", nullable=False)
    quoted_total = Column(Float, nullable=False)
    deposit_amount = Column(Float, nullable=False)
    final_balance = Column(Float, nullable=False)

    build_sessions = relationship("BuildSession", back_populates="commission")
    bom_items = relationship("BillOfMaterialItem", back_populates="commission")
    stock_deductions = relationship("StockDeduction", back_populates="commission")
    charges = relationship("Charge", back_populates="commission")
    credits = relationship("Credit", back_populates="commission")


class BuildSession(Base):
    __tablename__ = "build_sessions"

    id = Column(Integer, primary_key=True, index=True)
    commission_id = Column(Integer, ForeignKey("commissions.id"), nullable=False)
    session_date = Column(String, nullable=False)
    notes = Column(String, nullable=True)

    commission = relationship("Commission", back_populates="build_sessions")
    turning_passes = relationship("TurningPass", back_populates="build_session")
    undercuts = relationship("FingerHoleUndercut", back_populates="build_session")
    lappings = relationship("JointLapping", back_populates="build_session")
    tuning_sessions = relationship("TuningRigSession", back_populates="build_session")


class TurningPass(Base):
    __tablename__ = "turning_passes"

    id = Column(Integer, primary_key=True, index=True)
    build_session_id = Column(Integer, ForeignKey("build_sessions.id"), nullable=False)
    pass_number = Column(Integer, nullable=False)
    target_diameter_mm = Column(Float, nullable=False)
    achieved_diameter_mm = Column(Float, nullable=False)
    tool_used = Column(String, nullable=False)

    build_session = relationship("BuildSession", back_populates="turning_passes")


class FingerHoleUndercut(Base):
    __tablename__ = "finger_hole_undercuts"

    id = Column(Integer, primary_key=True, index=True)
    build_session_id = Column(Integer, ForeignKey("build_sessions.id"), nullable=False)
    hole_number = Column(Integer, nullable=False)
    undercut_depth_mm = Column(Float, nullable=False)
    undercut_angle_degrees = Column(Float, nullable=False)
    is_thumb_hole = Column(Boolean, nullable=False)

    build_session = relationship("BuildSession", back_populates="undercuts")


class JointLapping(Base):
    __tablename__ = "joint_lappings"

    id = Column(Integer, primary_key=True, index=True)
    build_session_id = Column(Integer, ForeignKey("build_sessions.id"), nullable=False)
    joint_identifier = Column(String, nullable=False)
    thread_material = Column(String, nullable=False)
    num_wraps = Column(Integer, nullable=False)
    fit_tightness = Column(String, nullable=False)

    build_session = relationship("BuildSession", back_populates="lappings")


class TuningRigSession(Base):
    __tablename__ = "tuning_rig_sessions"

    id = Column(Integer, primary_key=True, index=True)
    build_session_id = Column(Integer, ForeignKey("build_sessions.id"), nullable=False)
    hole_number = Column(Integer, nullable=False)
    target_frequency_hz = Column(Float, nullable=False)
    measured_frequency_hz = Column(Float, nullable=False)
    deviation_cents = Column(Float, nullable=False)

    build_session = relationship("BuildSession", back_populates="tuning_sessions")


class InventoryItem(Base):
    __tablename__ = "inventory_items"

    id = Column(Integer, primary_key=True, index=True)
    material_name = Column(String, nullable=False)
    material_type = Column(String, nullable=False)
    unit_of_measure = Column(String, nullable=False)
    quantity_on_hand = Column(Float, nullable=False)
    reorder_threshold = Column(Float, nullable=False)

    stock_deductions = relationship("StockDeduction", back_populates="inventory_item")


class StockDeduction(Base):
    __tablename__ = "stock_deductions"

    id = Column(Integer, primary_key=True, index=True)
    inventory_item_id = Column(Integer, ForeignKey("inventory_items.id"), nullable=False)
    commission_id = Column(Integer, ForeignKey("commissions.id"), nullable=False)
    quantity = Column(Float, nullable=False)
    deducted_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    inventory_item = relationship("InventoryItem", back_populates="stock_deductions")
    commission = relationship("Commission", back_populates="stock_deductions")


class BillOfMaterialItem(Base):
    __tablename__ = "bill_of_material_items"

    id = Column(Integer, primary_key=True, index=True)
    commission_id = Column(Integer, ForeignKey("commissions.id"), nullable=False)
    inventory_item_id = Column(Integer, ForeignKey("inventory_items.id"), nullable=False)
    quantity_required = Column(Float, nullable=False)

    commission = relationship("Commission", back_populates="bom_items")
    inventory_item = relationship("InventoryItem")


class Charge(Base):
    __tablename__ = "charges"

    id = Column(Integer, primary_key=True, index=True)
    commission_id = Column(Integer, ForeignKey("commissions.id"), nullable=False)
    amount = Column(Float, nullable=False)
    reason = Column(String, nullable=False)

    commission = relationship("Commission", back_populates="charges")


class Credit(Base):
    __tablename__ = "credits"

    id = Column(Integer, primary_key=True, index=True)
    commission_id = Column(Integer, ForeignKey("commissions.id"), nullable=False)
    amount = Column(Float, nullable=False)
    reason = Column(String, nullable=False)

    commission = relationship("Commission", back_populates="credits")
