from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from flute_shop.database import get_db
from flute_shop.models import (
    BillOfMaterialItem,
    Commission,
    InventoryItem,
    StockDeduction,
)
from flute_shop.schemas import (
    BomItemCreate,
    BomItemResponse,
    CommissionCreate,
    CommissionDetailResponse,
    CommissionResponse,
    CommissionStatusUpdate,
)

router = APIRouter()


# Key Requirement #2: commissions progress through statuses in the fixed
# forward-only sequence below; only the immediate next status is a valid
# transition and the API returns HTTP 409 for any other requested value.
STATUS_SEQUENCE = [
    "quoted",
    "deposit_paid",
    "in_progress",
    "final_fitting",
    "completed",
    "delivered",
]


def _next_status(current: str) -> Optional[str]:
    if current in STATUS_SEQUENCE:
        idx = STATUS_SEQUENCE.index(current)
        if idx + 1 < len(STATUS_SEQUENCE):
            return STATUS_SEQUENCE[idx + 1]
    return None


@router.post("/commissions", status_code=201, response_model=CommissionResponse)
def create_commission(payload: CommissionCreate, db: Session = Depends(get_db)):
    commission = Commission(
        customer_name=payload.customer_name,
        instrument_type=payload.instrument_type,
        material=payload.material,
        pitch_reference=payload.pitch_reference,
        target_key=payload.target_key,
        bore_taper=payload.bore_taper,
        status="quoted",
        quoted_total=payload.quoted_total,
        deposit_amount=payload.deposit_amount,
        final_balance=payload.quoted_total - payload.deposit_amount,
    )
    db.add(commission)
    db.commit()
    db.refresh(commission)
    return commission


@router.get("/commissions/{commission_id}", response_model=CommissionDetailResponse)
def get_commission(commission_id: int, db: Session = Depends(get_db)):
    commission = db.query(Commission).filter(Commission.id == commission_id).first()
    if not commission:
        raise HTTPException(status_code=404, detail="Commission not found")
    return commission


@router.get("/commissions", response_model=List[CommissionResponse])
def list_commissions(
    status: Optional[str] = None,
    customer_name: Optional[str] = None,
    db: Session = Depends(get_db),
):
    query = db.query(Commission)
    if status is not None:
        query = query.filter(Commission.status == status)
    if customer_name is not None:
        query = query.filter(Commission.customer_name == customer_name)
    return query.all()


@router.patch(
    "/commissions/{commission_id}/status",
    response_model=CommissionDetailResponse,
)
def update_commission_status(
    commission_id: int,
    payload: CommissionStatusUpdate,
    db: Session = Depends(get_db),
):
    commission = db.query(Commission).filter(Commission.id == commission_id).first()
    if not commission:
        raise HTTPException(status_code=404, detail="Commission not found")

    expected_next = _next_status(commission.status)
    if expected_next is None or payload.status != expected_next:
        raise HTTPException(
            status_code=409,
            detail=(
                f"Invalid status transition: '{commission.status}' -> "
                f"'{payload.status}'. Only the immediate next status in the "
                f"sequence {STATUS_SEQUENCE} is allowed."
            ),
        )

    if payload.status == "in_progress":
        bom_items = (
            db.query(BillOfMaterialItem)
            .filter(BillOfMaterialItem.commission_id == commission_id)
            .all()
        )
        # Spec: "Returns HTTP 409 if any deduction would bring stock below
        # zero (no partial deductions are applied)." Validate every BOM line
        # against current stock before applying any deduction.
        for bom in bom_items:
            inv = (
                db.query(InventoryItem)
                .filter(InventoryItem.id == bom.inventory_item_id)
                .first()
            )
            if inv is None or inv.quantity_on_hand < bom.quantity_required:
                raise HTTPException(
                    status_code=409,
                    detail="Insufficient stock for bill-of-materials deduction",
                )

        for bom in bom_items:
            inv = (
                db.query(InventoryItem)
                .filter(InventoryItem.id == bom.inventory_item_id)
                .first()
            )
            inv.quantity_on_hand -= bom.quantity_required
            deduction = StockDeduction(
                inventory_item_id=bom.inventory_item_id,
                commission_id=commission_id,
                quantity=bom.quantity_required,
            )
            db.add(deduction)

    commission.status = payload.status
    db.commit()
    db.refresh(commission)
    return commission


@router.post(
    "/commissions/{commission_id}/bom-items",
    status_code=201,
    response_model=BomItemResponse,
)
def add_bom_item(
    commission_id: int,
    payload: BomItemCreate,
    db: Session = Depends(get_db),
):
    commission = db.query(Commission).filter(Commission.id == commission_id).first()
    if not commission:
        raise HTTPException(status_code=404, detail="Commission not found")

    inv = (
        db.query(InventoryItem)
        .filter(InventoryItem.id == payload.inventory_item_id)
        .first()
    )
    if not inv:
        raise HTTPException(status_code=404, detail="Inventory item not found")

    bom = BillOfMaterialItem(
        commission_id=commission_id,
        inventory_item_id=payload.inventory_item_id,
        quantity_required=payload.quantity_required,
    )
    db.add(bom)
    db.commit()
    db.refresh(bom)
    return bom


@router.get(
    "/commissions/{commission_id}/bom-items",
    response_model=List[BomItemResponse],
)
def list_bom_items(commission_id: int, db: Session = Depends(get_db)):
    commission = db.query(Commission).filter(Commission.id == commission_id).first()
    if not commission:
        raise HTTPException(status_code=404, detail="Commission not found")
    return (
        db.query(BillOfMaterialItem)
        .filter(BillOfMaterialItem.commission_id == commission_id)
        .all()
    )
