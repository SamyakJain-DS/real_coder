from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from flute_shop.database import get_db
from flute_shop.models import Charge, Commission, Credit
from flute_shop.schemas import (
    ChargeCreate,
    ChargeResponse,
    CreditCreate,
    CreditResponse,
    ReconciliationResponse,
)

router = APIRouter()


@router.post(
    "/commissions/{commission_id}/charges",
    status_code=201,
    response_model=ChargeResponse,
)
def add_charge(
    commission_id: int,
    payload: ChargeCreate,
    db: Session = Depends(get_db),
):
    commission = db.query(Commission).filter(Commission.id == commission_id).first()
    if not commission:
        raise HTTPException(status_code=404, detail="Commission not found")

    charge = Charge(
        commission_id=commission_id,
        amount=payload.amount,
        reason=payload.reason,
    )
    db.add(charge)
    db.commit()
    db.refresh(charge)
    return charge


@router.post(
    "/commissions/{commission_id}/credits",
    status_code=201,
    response_model=CreditResponse,
)
def add_credit(
    commission_id: int,
    payload: CreditCreate,
    db: Session = Depends(get_db),
):
    commission = db.query(Commission).filter(Commission.id == commission_id).first()
    if not commission:
        raise HTTPException(status_code=404, detail="Commission not found")

    credit = Credit(
        commission_id=commission_id,
        amount=payload.amount,
        reason=payload.reason,
    )
    db.add(credit)
    db.commit()
    db.refresh(credit)
    return credit


@router.get(
    "/commissions/{commission_id}/reconcile",
    response_model=ReconciliationResponse,
)
def reconcile_commission(commission_id: int, db: Session = Depends(get_db)):
    commission = db.query(Commission).filter(Commission.id == commission_id).first()
    if not commission:
        raise HTTPException(status_code=404, detail="Commission not found")

    charges = (
        db.query(Charge).filter(Charge.commission_id == commission_id).all()
    )
    credits = (
        db.query(Credit).filter(Credit.commission_id == commission_id).all()
    )

    total_charges = sum(c.amount for c in charges)
    total_credits = sum(c.amount for c in credits)

    # Spec formula:
    #   final_balance_owed = round(
    #       quoted_total + total_additional_charges
    #       - deposit_paid - total_credits,
    #       2,
    #   )
    # "balanced" when result equals 0.00, "underpaid" when positive,
    # "overpaid" when negative.
    final_balance_owed = round(
        commission.quoted_total
        + total_charges
        - commission.deposit_amount
        - total_credits,
        2,
    )

    if final_balance_owed == 0:
        reconciliation_status = "balanced"
    elif final_balance_owed > 0:
        reconciliation_status = "underpaid"
    else:
        reconciliation_status = "overpaid"

    return ReconciliationResponse(
        commission_id=commission_id,
        quoted_total=commission.quoted_total,
        deposit_paid=commission.deposit_amount,
        total_additional_charges=total_charges,
        total_credits=total_credits,
        final_balance_owed=final_balance_owed,
        status=reconciliation_status,
    )
