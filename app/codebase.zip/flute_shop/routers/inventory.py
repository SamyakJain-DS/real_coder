from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from flute_shop.database import get_db
from flute_shop.models import Commission, InventoryItem, StockDeduction
from flute_shop.schemas import (
    InventoryItemCreate,
    InventoryItemResponse,
    StockDeductionResponse,
    StockDeductRequest,
)

router = APIRouter()


@router.post("/inventory", status_code=201, response_model=InventoryItemResponse)
def create_inventory_item(
    payload: InventoryItemCreate, db: Session = Depends(get_db)
):
    item = InventoryItem(
        material_name=payload.material_name,
        material_type=payload.material_type,
        unit_of_measure=payload.unit_of_measure,
        quantity_on_hand=payload.quantity_on_hand,
        reorder_threshold=payload.reorder_threshold,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@router.get("/inventory", response_model=List[InventoryItemResponse])
def list_inventory(
    material_type: Optional[str] = None, db: Session = Depends(get_db)
):
    query = db.query(InventoryItem)
    if material_type is not None:
        query = query.filter(InventoryItem.material_type == material_type)
    return query.all()


@router.post("/inventory/deduct", response_model=InventoryItemResponse)
def deduct_stock(payload: StockDeductRequest, db: Session = Depends(get_db)):
    inv = (
        db.query(InventoryItem)
        .filter(InventoryItem.id == payload.inventory_item_id)
        .first()
    )
    if not inv:
        raise HTTPException(status_code=404, detail="Inventory item not found")

    commission = (
        db.query(Commission).filter(Commission.id == payload.commission_id).first()
    )
    if not commission:
        raise HTTPException(status_code=404, detail="Commission not found")

    if inv.quantity_on_hand < payload.quantity:
        raise HTTPException(status_code=409, detail="Insufficient stock")

    inv.quantity_on_hand -= payload.quantity

    deduction = StockDeduction(
        inventory_item_id=payload.inventory_item_id,
        commission_id=payload.commission_id,
        quantity=payload.quantity,
    )
    db.add(deduction)
    db.commit()
    db.refresh(inv)
    return inv


@router.get("/inventory/deductions", response_model=List[StockDeductionResponse])
def get_stock_deductions(
    commission_id: Optional[int] = None, db: Session = Depends(get_db)
):
    query = db.query(StockDeduction)
    if commission_id is not None:
        query = query.filter(StockDeduction.commission_id == commission_id)
    return query.all()
