from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from flute_shop.database import get_db
from flute_shop.models import (
    BuildSession,
    Commission,
    FingerHoleUndercut,
    JointLapping,
    TuningRigSession,
    TurningPass,
)
from flute_shop.schemas import (
    BuildSessionCreate,
    BuildSessionDetailResponse,
    BuildSessionResponse,
    LappingCreate,
    LappingResponse,
    TuningRigCreate,
    TuningRigResponse,
    TurningPassCreate,
    TurningPassResponse,
    UndercutCreate,
    UndercutResponse,
)

router = APIRouter()


@router.post(
    "/commissions/{commission_id}/build-sessions",
    status_code=201,
    response_model=BuildSessionResponse,
)
def create_build_session(
    commission_id: int,
    payload: BuildSessionCreate,
    db: Session = Depends(get_db),
):
    commission = db.query(Commission).filter(Commission.id == commission_id).first()
    if not commission:
        raise HTTPException(status_code=404, detail="Commission not found")

    session = BuildSession(
        commission_id=commission_id,
        session_date=payload.session_date,
        notes=payload.notes,
    )
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


@router.get("/build-sessions/{session_id}", response_model=BuildSessionDetailResponse)
def get_build_session(session_id: int, db: Session = Depends(get_db)):
    session = db.query(BuildSession).filter(BuildSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Build session not found")
    return session


@router.post(
    "/build-sessions/{session_id}/turning-passes",
    status_code=201,
    response_model=TurningPassResponse,
)
def log_turning_pass(
    session_id: int,
    payload: TurningPassCreate,
    db: Session = Depends(get_db),
):
    session = db.query(BuildSession).filter(BuildSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Build session not found")

    turning_pass = TurningPass(
        build_session_id=session_id,
        pass_number=payload.pass_number,
        target_diameter_mm=payload.target_diameter_mm,
        achieved_diameter_mm=payload.achieved_diameter_mm,
        tool_used=payload.tool_used,
    )
    db.add(turning_pass)
    db.commit()
    db.refresh(turning_pass)
    return turning_pass


@router.post(
    "/build-sessions/{session_id}/undercuts",
    status_code=201,
    response_model=UndercutResponse,
)
def log_finger_hole_undercut(
    session_id: int,
    payload: UndercutCreate,
    db: Session = Depends(get_db),
):
    session = db.query(BuildSession).filter(BuildSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Build session not found")

    undercut = FingerHoleUndercut(
        build_session_id=session_id,
        hole_number=payload.hole_number,
        undercut_depth_mm=payload.undercut_depth_mm,
        undercut_angle_degrees=payload.undercut_angle_degrees,
        is_thumb_hole=payload.is_thumb_hole,
    )
    db.add(undercut)
    db.commit()
    db.refresh(undercut)
    return undercut


@router.post(
    "/build-sessions/{session_id}/lappings",
    status_code=201,
    response_model=LappingResponse,
)
def log_joint_lapping(
    session_id: int,
    payload: LappingCreate,
    db: Session = Depends(get_db),
):
    session = db.query(BuildSession).filter(BuildSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Build session not found")

    lapping = JointLapping(
        build_session_id=session_id,
        joint_identifier=payload.joint_identifier,
        thread_material=payload.thread_material,
        num_wraps=payload.num_wraps,
        fit_tightness=payload.fit_tightness,
    )
    db.add(lapping)
    db.commit()
    db.refresh(lapping)
    return lapping


@router.post(
    "/build-sessions/{session_id}/tuning-sessions",
    status_code=201,
    response_model=TuningRigResponse,
)
def log_tuning_rig_session(
    session_id: int,
    payload: TuningRigCreate,
    db: Session = Depends(get_db),
):
    session = db.query(BuildSession).filter(BuildSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Build session not found")

    tuning = TuningRigSession(
        build_session_id=session_id,
        hole_number=payload.hole_number,
        target_frequency_hz=payload.target_frequency_hz,
        measured_frequency_hz=payload.measured_frequency_hz,
        deviation_cents=payload.deviation_cents,
    )
    db.add(tuning)
    db.commit()
    db.refresh(tuning)
    return tuning
