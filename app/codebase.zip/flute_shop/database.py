import os

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.pool import StaticPool

# Per the prompt, "all data is stored locally in an SQLite database file;
# the application operates entirely offline with local persistence only".
# That is the default. A `DATABASE_URL` override is honoured when set so
# the same engine can be pointed at an alternate SQLite location without
# changing the prompt's local-file default behaviour.
SQLALCHEMY_DATABASE_URL = os.environ.get(
    "DATABASE_URL", "sqlite:///./flute_shop.db"
)

_engine_kwargs = {"connect_args": {"check_same_thread": False}}

# An in-memory SQLite URL ("sqlite://" or "sqlite:///:memory:") gives every
# pooled connection its own private database, which would hide the tables
# created on startup from request-handler connections. StaticPool shares a
# single connection across the engine so the in-memory schema is visible
# everywhere. File-based URLs are unaffected and continue to use the
# default pool exactly as before.
if SQLALCHEMY_DATABASE_URL in ("sqlite://", "sqlite:///:memory:"):
    _engine_kwargs["poolclass"] = StaticPool

engine = create_engine(SQLALCHEMY_DATABASE_URL, **_engine_kwargs)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
