from contextlib import asynccontextmanager

from fastapi import FastAPI

from flute_shop.database import Base, engine
from flute_shop.routers import billing, build_sessions, commissions, inventory


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(title="Flute & Whistle Workshop API", lifespan=lifespan)

app.include_router(commissions.router)
app.include_router(build_sessions.router)
app.include_router(inventory.router)
app.include_router(billing.router)
