from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


# ── Commission ──────────────────────────────────────────────────

class CommissionCreate(BaseModel):
    customer_name: str
    instrument_type: Literal["flute", "whistle"]
    material: str
    pitch_reference: str
    target_key: str
    bore_taper: str
    quoted_total: float
    deposit_amount: float


class CommissionStatusUpdate(BaseModel):
    status: str


class CommissionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    customer_name: str
    instrument_type: str
    material: str
    pitch_reference: str
    target_key: str
    bore_taper: str
    status: str
    quoted_total: float
    deposit_amount: float
    final_balance: float


# ── Bill of Material Item ───────────────────────────────────────

class BomItemCreate(BaseModel):
    inventory_item_id: int
    quantity_required: float


class BomItemResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    commission_id: int
    inventory_item_id: int
    quantity_required: float


# ── Build Session ───────────────────────────────────────────────

class BuildSessionCreate(BaseModel):
    session_date: str
    notes: Optional[str] = None


class BuildSessionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    commission_id: int
    session_date: str
    notes: Optional[str] = None


# ── Turning Pass ────────────────────────────────────────────────

class TurningPassCreate(BaseModel):
    pass_number: int
    target_diameter_mm: float
    achieved_diameter_mm: float
    tool_used: str


class TurningPassResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    build_session_id: int
    pass_number: int
    target_diameter_mm: float
    achieved_diameter_mm: float
    tool_used: str


# ── Finger Hole Undercut ────────────────────────────────────────

class UndercutCreate(BaseModel):
    # Key Requirement #6: hole number is 1-6 for both flutes and whistles.
    hole_number: int = Field(ge=1, le=6)
    undercut_depth_mm: float
    undercut_angle_degrees: float
    is_thumb_hole: bool


class UndercutResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    build_session_id: int
    hole_number: int
    undercut_depth_mm: float
    undercut_angle_degrees: float
    is_thumb_hole: bool


# ── Joint Lapping ───────────────────────────────────────────────

class LappingCreate(BaseModel):
    joint_identifier: str
    thread_material: str
    num_wraps: int
    fit_tightness: Literal["loose", "snug", "tight"]


class LappingResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    build_session_id: int
    joint_identifier: str
    thread_material: str
    num_wraps: int
    fit_tightness: str


# ── Tuning Rig Session ──────────────────────────────────────────

class TuningRigCreate(BaseModel):
    hole_number: int
    target_frequency_hz: float
    measured_frequency_hz: float
    deviation_cents: float


class TuningRigResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    build_session_id: int
    hole_number: int
    target_frequency_hz: float
    measured_frequency_hz: float
    deviation_cents: float


# ── Build Session Detail (nested) ───────────────────────────────

class BuildSessionDetailResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    commission_id: int
    session_date: str
    notes: Optional[str] = None
    turning_passes: List[TurningPassResponse] = []
    undercuts: List[UndercutResponse] = []
    lappings: List[LappingResponse] = []
    tuning_sessions: List[TuningRigResponse] = []


# ── Commission Detail (with nested build session summaries) ─────
# Spec for `get_commission` / `update_commission_status`:
#   build_sessions is "an array of summary objects each containing
#   id, commission_id, session_date, notes — craftsmanship sub-records
#   (turning passes, undercuts, lappings, tuning sessions) are not
#   included; use GET /build-sessions/{session_id} to retrieve those".

class CommissionDetailResponse(CommissionResponse):
    model_config = ConfigDict(from_attributes=True)

    build_sessions: List[BuildSessionResponse] = []


# ── Inventory Item ──────────────────────────────────────────────

class InventoryItemCreate(BaseModel):
    material_name: str
    material_type: Literal["wood", "metal"]
    unit_of_measure: str
    quantity_on_hand: float
    reorder_threshold: float


class InventoryItemResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    material_name: str
    material_type: str
    unit_of_measure: str
    quantity_on_hand: float
    reorder_threshold: float


# ── Stock Deduction ─────────────────────────────────────────────

class StockDeductRequest(BaseModel):
    inventory_item_id: int
    quantity: float
    commission_id: int


class StockDeductionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    inventory_item_id: int
    commission_id: int
    quantity: float
    deducted_at: datetime


# ── Billing ─────────────────────────────────────────────────────

class ChargeCreate(BaseModel):
    amount: float
    reason: str


class ChargeResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    commission_id: int
    amount: float
    reason: str


class CreditCreate(BaseModel):
    amount: float
    reason: str


class CreditResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    commission_id: int
    amount: float
    reason: str


class ReconciliationResponse(BaseModel):
    commission_id: int
    quoted_total: float
    deposit_paid: float
    total_additional_charges: float
    total_credits: float
    final_balance_owed: float
    status: str
