namespace WeddingStudio.Api.Dtos;

public class CreateBookingRequest
{
    public string Partner1Name { get; set; } = string.Empty;
    public string Partner2Name { get; set; } = string.Empty;
    public string VenueName { get; set; } = string.Empty;
    public string WeddingDate { get; set; } = string.Empty;
    public string PackageType { get; set; } = string.Empty;
    public List<string> Deliverables { get; set; } = new();
}

public class CreateSessionRequest
{
    public string Location { get; set; } = string.Empty;
    public string ScheduledStartTime { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
}

public class CreateInventoryItemRequest
{
    public string Name { get; set; } = string.Empty;
}

public class CreateEquipmentKitRequest
{
    public string KitName { get; set; } = string.Empty;
    public List<int> InventoryItemIds { get; set; } = new();
}

public class CreateProofingWorkflowRequest
{
    public string ContractedDeliveryDate { get; set; } = string.Empty;
}

public class AddProofingRoundRequest
{
    public string SubmittedDate { get; set; } = string.Empty;
    public int ImagesSelected { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class ProofingRoundResponse
{
    public int Id { get; set; }
    public int RoundNumber { get; set; }
    public string SubmittedDate { get; set; } = string.Empty;
    public int ImagesSelected { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class ProofingWorkflowResponse
{
    public int Id { get; set; }
    public int BookingId { get; set; }
    public string ContractedDeliveryDate { get; set; } = string.Empty;
    public List<ProofingRoundResponse> Rounds { get; set; } = new();
    public bool? IsWithinDeliveryWindow { get; set; }
}
