import json
import os

import pandas as pd


def generate_performance_report(
    spa_estimates: pd.DataFrame,
    access_patterns: pd.DataFrame,
    equity_impacts: pd.DataFrame,
    lcd_data: pd.DataFrame,
    contractor_inquiries: pd.DataFrame,
) -> dict:
    report = {
        "single_payment_amounts": spa_estimates.to_dict(orient="records"),
        "access_patterns":        access_patterns.to_dict(orient="records"),
        "equity_impacts":         equity_impacts.to_dict(orient="records"),
        "lcd_determinations":     lcd_data.to_dict(orient="records"),
        "contractor_inquiries":   contractor_inquiries.to_dict(orient="records"),
    }

    os.makedirs("outputs", exist_ok=True)
    with open("outputs/performance_report.json", "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)

    return report


def generate_recommendation_packet(
    spa_estimates: pd.DataFrame,
    access_patterns: pd.DataFrame,
    gap_fill_pricing: pd.DataFrame,
) -> dict:
    # Build the set of (cba_id, hcpcs_code) combos flagged as contract_attrition
    attrition_set = set(
        map(
            tuple,
            access_patterns.loc[
                access_patterns["access_pattern"] == "contract_attrition",
                ["cba_id", "hcpcs_code"],
            ].values.tolist(),
        )
    )

    bid_limits = []
    for _, row in spa_estimates.iterrows():
        key = (row["cba_id"], row["hcpcs_code"])
        multiplier = 1.15 if key in attrition_set else 1.10
        recommended_bid_limit = round(row["estimated_spa"] * multiplier, 2)
        bid_limits.append({
            "cba_id":                row["cba_id"],
            "hcpcs_code":            row["hcpcs_code"],
            "product_category":      row["product_category"],
            "round":                 row["round"],
            "recommended_bid_limit": recommended_bid_limit,
        })

    gap_fill_recommendations = (
        gap_fill_pricing[["hcpcs_code", "cba_id", "gap_fill_amount", "methodology"]]
        .to_dict(orient="records")
    )

    packet = {
        "bid_limits":              bid_limits,
        "gap_fill_recommendations": gap_fill_recommendations,
    }

    os.makedirs("outputs", exist_ok=True)
    with open("outputs/recommendation_packet.json", "w", encoding="utf-8") as fh:
        json.dump(packet, fh, indent=2)

    return packet