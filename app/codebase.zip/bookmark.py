import sys
import json
import os
import subprocess
import pyperclip

def get_bookmarks_path():
    return os.path.expanduser("~/.bookmarks.json")


def load_bookmarks():
    path = get_bookmarks_path()
    if not os.path.exists(path):
        return []
    with open(path, "r") as f:
        return json.load(f)


def save_bookmarks(bookmarks):
    path = get_bookmarks_path()
    with open(path, "w") as f:
        json.dump(bookmarks, f, indent=2)


def fuzzy_match(query, text):
    query = query.lower()
    text = text.lower()
    it = iter(text)
    return all(c in it for c in query)


def print_bookmark(bookmark):
    print(f"Name: {bookmark['name']}")
    print(f"Command: {bookmark['command']}")
    print(f"Description: {bookmark['description']}")


def main(args=None):
    if args is None:
        args = sys.argv[1:]

    if len(args) == 0 or args[0] not in ("save", "find", "list", "copy", "run"):
        print("Usage: bookmark {save|find|list|copy|run}")
        sys.exit(1)

    subcommand = args[0]

    if subcommand == "save":
        name = args[1]
        command = args[2]
        description = args[3]
        bookmarks = load_bookmarks()
        for i, b in enumerate(bookmarks):
            if b["name"] == name:
                bookmarks[i] = {"name": name, "command": command, "description": description}
                save_bookmarks(bookmarks)
                return
        bookmarks.append({"name": name, "command": command, "description": description})
        save_bookmarks(bookmarks)

    elif subcommand == "find":
        query = args[1]
        bookmarks = load_bookmarks()
        matches = [
            b for b in bookmarks
            if fuzzy_match(query, b["name"]) or fuzzy_match(query, b["command"]) or fuzzy_match(query, b["description"])
        ]
        if not matches:
            print(f"No bookmarks match '{query}'")
        else:
            for i, b in enumerate(matches):
                print_bookmark(b)
                if i < len(matches) - 1:
                    print()

    elif subcommand == "list":
        bookmarks = load_bookmarks()
        if not bookmarks:
            print("No bookmarks saved")
        else:
            for i, b in enumerate(bookmarks):
                print_bookmark(b)
                if i < len(bookmarks) - 1:
                    print()

    elif subcommand == "copy":
        name = args[1]
        bookmarks = load_bookmarks()
        for b in bookmarks:
            if b["name"] == name:
                pyperclip.copy(b["command"])
                print(f"Copied '{name}' to clipboard")
                return
        print(f"No bookmark named '{name}'")
        sys.exit(1)

    elif subcommand == "run":
        name = args[1]
        bookmarks = load_bookmarks()
        for b in bookmarks:
            if b["name"] == name:
                result = subprocess.run(b["command"], shell=True, capture_output=True, text=True)
                print(result.stdout, end="")
                return
        print(f"No bookmark named '{name}'")
        sys.exit(1)


if __name__ == "__main__":
    main()