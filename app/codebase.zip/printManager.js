const PAPER_WIDTH_INCHES = 8.5;
const PAPER_HEIGHT_INCHES = 11.0;
const MARGIN_INCHES = 0.5;

const PORTRAIT_CONTENT_WIDTH_INCHES = PAPER_WIDTH_INCHES - 2 * MARGIN_INCHES;
const PORTRAIT_CONTENT_HEIGHT_INCHES = PAPER_HEIGHT_INCHES - 2 * MARGIN_INCHES;
const LANDSCAPE_CONTENT_WIDTH_INCHES = PORTRAIT_CONTENT_HEIGHT_INCHES;
const LANDSCAPE_CONTENT_HEIGHT_INCHES = PORTRAIT_CONTENT_WIDTH_INCHES;

const REGISTRATION_MARK_INCHES = 0.25;
const REGISTRATION_MARK_CENTER_OFFSET_INCHES = REGISTRATION_MARK_INCHES / 2;

function resolveContentDimensions(orientation) {
  if (orientation === "portrait") {
    return {
      contentWidthInches: PORTRAIT_CONTENT_WIDTH_INCHES,
      contentHeightInches: PORTRAIT_CONTENT_HEIGHT_INCHES,
    };
  }
  if (orientation === "landscape") {
    return {
      contentWidthInches: LANDSCAPE_CONTENT_WIDTH_INCHES,
      contentHeightInches: LANDSCAPE_CONTENT_HEIGHT_INCHES,
    };
  }
  throw new RangeError("Invalid orientation");
}

export function computeTileRegions(
  imageWidthPx,
  imageHeightPx,
  realWidthInches,
  realHeightInches,
  orientation,
) {
  const { contentWidthInches, contentHeightInches } =
    resolveContentDimensions(orientation);

  const cols = Math.ceil(realWidthInches / contentWidthInches);
  const rows = Math.ceil(realHeightInches / contentHeightInches);
  const pxPerInchX = imageWidthPx / realWidthInches;
  const pxPerInchY = imageHeightPx / realHeightInches;

  const regions = [];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const sx = Math.floor(col * pxPerInchX * contentWidthInches);
      const sy = Math.floor(row * pxPerInchY * contentHeightInches);
      const sw = Math.min(
        Math.floor(pxPerInchX * contentWidthInches),
        imageWidthPx - sx,
      );
      const sh = Math.min(
        Math.floor(pxPerInchY * contentHeightInches),
        imageHeightPx - sy,
      );
      const widthInches = sw / pxPerInchX;
      const heightInches = sh / pxPerInchY;
      regions.push({ col, row, sx, sy, sw, sh, widthInches, heightInches });
    }
  }
  return regions;
}

function injectPageStyle(orientation) {
  const existing = document.getElementById("print-page-style");
  if (existing) {
    existing.remove();
  }
  const style = document.createElement("style");
  style.id = "print-page-style";
  style.textContent = `@page { size: letter ${orientation}; margin: ${MARGIN_INCHES}in; }`;
  document.head.appendChild(style);
}

function buildRegistrationMark(corner) {
  const mark = document.createElement("div");
  mark.className = "registration-mark";
  const offset = `-${REGISTRATION_MARK_CENTER_OFFSET_INCHES}in`;
  const cornerStyles = {
    "top-left":     `top: ${offset}; left: ${offset};`,
    "top-right":    `top: ${offset}; right: ${offset};`,
    "bottom-left":  `bottom: ${offset}; left: ${offset};`,
    "bottom-right": `bottom: ${offset}; right: ${offset};`,
  };
  mark.setAttribute("style", cornerStyles[corner]);

  const verticalLine = document.createElement("div");
  verticalLine.className = "registration-mark-vertical";
  mark.appendChild(verticalLine);

  const horizontalLine = document.createElement("div");
  horizontalLine.className = "registration-mark-horizontal";
  mark.appendChild(horizontalLine);

  return mark;
}

function buildTileElement(sourceCanvas, region, includeRegistrationMarks) {
  const tile = document.createElement("div");
  tile.className = "print-tile";
  const sizeStyle = `width: ${region.widthInches}in; height: ${region.heightInches}in;`;
  tile.setAttribute(
    "style",
    `${sizeStyle} page-break-after: always; position: relative; overflow: hidden;`,
  );

  const canvas = document.createElement("canvas");
  canvas.width = region.sw;
  canvas.height = region.sh;
  canvas.setAttribute("style", `${sizeStyle} display: block;`);
  const context = canvas.getContext("2d");
  context.drawImage(
    sourceCanvas,
    region.sx,
    region.sy,
    region.sw,
    region.sh,
    0,
    0,
    region.sw,
    region.sh,
  );
  tile.appendChild(canvas);

  if (includeRegistrationMarks) {
    tile.appendChild(buildRegistrationMark("top-left"));
    tile.appendChild(buildRegistrationMark("top-right"));
    tile.appendChild(buildRegistrationMark("bottom-left"));
    tile.appendChild(buildRegistrationMark("bottom-right"));
  }

  return tile;
}

export function buildPrintLayout(
  sourceCanvas,
  tileRegions,
  includeRegistrationMarks,
  orientation,
  container,
) {
  if (orientation !== "portrait" && orientation !== "landscape") {
    throw new RangeError("Invalid orientation");
  }

  while (container.firstChild) {
    container.removeChild(container.firstChild);
  }

  injectPageStyle(orientation);

  for (const region of tileRegions) {
    container.appendChild(
      buildTileElement(sourceCanvas, region, includeRegistrationMarks),
    );
  }
}
