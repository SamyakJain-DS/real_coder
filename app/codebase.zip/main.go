package main

import (
	"fmt"
	"os"

	"md2slides/slides"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintf(os.Stderr, "Usage: md2slides <input_file> <output_file>\n")
		os.Exit(1)
	}

	inputPath := os.Args[1]
	outputPath := os.Args[2]

	content, err := os.ReadFile(inputPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error reading input file %q: %v\n", inputPath, err)
		os.Exit(1)
	}

	parsed := slides.ParseSlides(string(content))
	html := slides.ConvertToHTML(parsed)

	err = os.WriteFile(outputPath, []byte(html), 0644)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error writing output file %q: %v\n", outputPath, err)
		os.Exit(1)
	}

	os.Exit(0)
}