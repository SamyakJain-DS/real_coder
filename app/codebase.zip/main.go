package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

// channelIDPattern enforces the valid character set for channel IDs.
var channelIDPattern = regexp.MustCompile(`^[a-zA-Z0-9_-]+$`)

// ---------------------------------------------------------------------------
// Event & SSE wire format
// ---------------------------------------------------------------------------

// sseEvent is a single published SSE event with its server-assigned integer ID.
type sseEvent struct {
	id    int64
	etype string // optional SSE event type field
	data  string
}

// format serialises the event to the SSE wire format:
//
//	id:<id>\n
//	event:<type>\n  (omitted when empty)
//	data:<data>\n
//	\n
func (e sseEvent) format() string {
	var sb strings.Builder
	fmt.Fprintf(&sb, "id:%d\n", e.id)
	if e.etype != "" {
		fmt.Fprintf(&sb, "event:%s\n", e.etype)
	}
	fmt.Fprintf(&sb, "data:%s\n", e.data)
	sb.WriteByte('\n')
	return sb.String()
}

// ---------------------------------------------------------------------------
// Ring buffer – rolling event history
// ---------------------------------------------------------------------------

type ringBuffer struct {
	buf   []sseEvent
	size  int
	head  int // index of the oldest element
	count int // number of elements currently stored
}

func newRingBuffer(size int) *ringBuffer {
	if size < 0 {
		size = 0
	}
	return &ringBuffer{
		buf:  make([]sseEvent, size),
		size: size,
	}
}

// add appends an event; when the buffer is full the oldest entry is overwritten.
func (r *ringBuffer) add(e sseEvent) {
	if r.size == 0 {
		return
	}
	if r.count < r.size {
		r.buf[(r.head+r.count)%r.size] = e
		r.count++
	} else {
		r.buf[r.head] = e
		r.head = (r.head + 1) % r.size
	}
}

// getSince returns all buffered events whose ID is strictly greater than lastID.
// Pass lastID = -1 to get the full buffer contents.
func (r *ringBuffer) getSince(lastID int64) []sseEvent {
	result := make([]sseEvent, 0, r.count)
	for i := 0; i < r.count; i++ {
		e := r.buf[(r.head+i)%r.size]
		if e.id > lastID {
			result = append(result, e)
		}
	}
	return result
}

// ---------------------------------------------------------------------------
// Subscriber
// ---------------------------------------------------------------------------

// subscriber represents one active SSE connection.
type subscriber struct {
	ch chan sseEvent
}

// ---------------------------------------------------------------------------
// sseChannel
// ---------------------------------------------------------------------------

// sseChannel is a named SSE channel with its own history buffer, subscriber
// registry, and optional access-control tokens.
type sseChannel struct {
	mu             sync.RWMutex
	id             string
	publishToken   string
	subscribeToken string
	history        *ringBuffer
	nextID         int64
	subscribers    map[*subscriber]struct{}
}

func newSSEChannel(id string, historySize int, publishToken, subscribeToken string) *sseChannel {
	return &sseChannel{
		id:             id,
		publishToken:   publishToken,
		subscribeToken: subscribeToken,
		history:        newRingBuffer(historySize),
		nextID:         1,
		subscribers:    make(map[*subscriber]struct{}),
	}
}

// publish assigns the next sequential ID, appends the event to the ring
// buffer, and fans it out to all registered subscribers.
func (c *sseChannel) publish(etype, data string) sseEvent {
	c.mu.Lock()
	defer c.mu.Unlock()

	e := sseEvent{
		id:    c.nextID,
		etype: etype,
		data:  data,
	}
	c.nextID++
	c.history.add(e)

	for sub := range c.subscribers {
		select {
		case sub.ch <- e:
		default:
			// Buffer full – drop for this slow subscriber rather than blocking.
		}
	}
	return e
}

// subscribe registers a new subscriber and atomically snapshots the history
// slice that must be replayed before live events.
//
//   - lastID = -1  → replay the full history window.
//   - lastID >= 0  → replay only events whose id > lastID.
//
// The caller MUST call unsubscribe when the connection closes.
func (c *sseChannel) subscribe(lastID int64) (*subscriber, []sseEvent) {
	c.mu.Lock()
	defer c.mu.Unlock()

	sub := &subscriber{
		ch: make(chan sseEvent, 512),
	}
	c.subscribers[sub] = struct{}{}

	// Snapshot history under the same lock so we never miss an event published
	// between the snapshot and the registration.
	history := c.history.getSince(lastID)
	return sub, history
}

// unsubscribe removes the subscriber from the registry and closes its channel.
func (c *sseChannel) unsubscribe(sub *subscriber) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if _, ok := c.subscribers[sub]; ok {
		delete(c.subscribers, sub)
		close(sub.ch)
	}
}

// ---------------------------------------------------------------------------
// Broker
// ---------------------------------------------------------------------------

type broker struct {
	mu                 sync.RWMutex
	channels           map[string]*sseChannel
	defaultHistorySize int
}

// NewBroker constructs and returns the fully configured SSE broker as an
// http.Handler with all routes registered:
//
//	POST /channels
//	POST /channels/{channel}/events
//	GET  /channels/{channel}/events
//
// Tests instantiate the broker exclusively via this function and verify all
// endpoint behaviour through the returned handler.
func NewBroker(defaultHistorySize int) http.Handler {
	b := &broker{
		channels:           make(map[string]*sseChannel),
		defaultHistorySize: defaultHistorySize,
	}

	mux := http.NewServeMux()
	mux.HandleFunc("POST /channels", b.handleCreateChannel)
	mux.HandleFunc("POST /channels/{channel}/events", b.handlePublish)
	mux.HandleFunc("GET /channels/{channel}/events", b.handleSubscribe)

	return mux
}

// ---------------------------------------------------------------------------
// HTTP handlers
// ---------------------------------------------------------------------------

// ---- POST /channels --------------------------------------------------------

type createChannelRequest struct {
	ChannelID      string `json:"channel_id"`
	HistorySize    *int   `json:"history_size"`
	PublishToken   string `json:"publish_token"`
	SubscribeToken string `json:"subscribe_token"`
}

func (b *broker) handleCreateChannel(w http.ResponseWriter, r *http.Request) {
	var req createChannelRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid JSON body")
		return
	}

	// channel_id must be non-empty and match ^[a-zA-Z0-9_-]+$
	if req.ChannelID == "" || !channelIDPattern.MatchString(req.ChannelID) {
		writeError(w, http.StatusBadRequest, "channel_id is missing or contains invalid characters")
		return
	}

	// history_size: validate only when explicitly provided.
	historySize := b.defaultHistorySize
	if req.HistorySize != nil {
		if *req.HistorySize < 0 || *req.HistorySize > 10000 {
			writeError(w, http.StatusBadRequest, "history_size must be between 0 and 10000 inclusive")
			return
		}
		historySize = *req.HistorySize
	}

	b.mu.Lock()
	defer b.mu.Unlock()

	if _, exists := b.channels[req.ChannelID]; exists {
		writeError(w, http.StatusConflict, "channel already exists")
		return
	}

	b.channels[req.ChannelID] = newSSEChannel(
		req.ChannelID, historySize, req.PublishToken, req.SubscribeToken,
	)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	_ = json.NewEncoder(w).Encode(map[string]string{"channel_id": req.ChannelID})
}

// ---- POST /channels/{channel}/events ---------------------------------------

type publishRequest struct {
	Data  string `json:"data"`
	Event string `json:"event"`
}

func (b *broker) handlePublish(w http.ResponseWriter, r *http.Request) {
	channelID := r.PathValue("channel")

	b.mu.RLock()
	ch, exists := b.channels[channelID]
	b.mu.RUnlock()

	if !exists {
		writeError(w, http.StatusNotFound, "channel not found")
		return
	}

	// Token fields are immutable after channel creation; a read lock suffices.
	ch.mu.RLock()
	publishToken := ch.publishToken
	ch.mu.RUnlock()

	if publishToken != "" && !checkBearer(r, publishToken) {
		writeError(w, http.StatusUnauthorized, "unauthorized")
		return
	}

	var req publishRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid JSON body")
		return
	}

	if req.Data == "" {
		writeError(w, http.StatusBadRequest, "data field is required and must be non-empty")
		return
	}

	e := ch.publish(req.Event, req.Data)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(map[string]string{"id": strconv.FormatInt(e.id, 10)})
}

// ---- GET /channels/{channel}/events  (SSE stream) -------------------------

func (b *broker) handleSubscribe(w http.ResponseWriter, r *http.Request) {
	channelID := r.PathValue("channel")

	b.mu.RLock()
	ch, exists := b.channels[channelID]
	b.mu.RUnlock()

	if !exists {
		writeError(w, http.StatusNotFound, "channel not found")
		return
	}

	ch.mu.RLock()
	subscribeToken := ch.subscribeToken
	ch.mu.RUnlock()

	if subscribeToken != "" && !checkBearer(r, subscribeToken) {
		writeError(w, http.StatusUnauthorized, "unauthorized")
		return
	}

	// Determine history replay boundary from the Last-Event-ID header.
	//   Header absent               → lastID = -1  (replay full history window)
	//   Valid non-negative integer  → lastID = parsed value
	//   Unparseable value           → lastID = -1  (ignore, replay full window)
	lastID := int64(-1)
	if rawID := r.Header.Get("Last-Event-ID"); rawID != "" {
		if parsed, err := strconv.ParseInt(rawID, 10, 64); err == nil && parsed >= 0 {
			lastID = parsed
		}
	}

	// Register subscriber and atomically snapshot the history to replay.
	sub, history := ch.subscribe(lastID)
	defer ch.unsubscribe(sub)

	// Confirm the ResponseWriter supports flushing before writing any headers.
	flusher, ok := w.(http.Flusher)
	if !ok {
		writeError(w, http.StatusInternalServerError, "streaming not supported")
		return
	}

	// Mandatory SSE response headers (set before WriteHeader).
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("X-Accel-Buffering", "no")
	w.WriteHeader(http.StatusOK)

	// Phase 1: replay history events.
	for _, e := range history {
		fmt.Fprint(w, e.format())
	}
	flusher.Flush()

	// Phase 2: stream live events until the client disconnects.
	ctx := r.Context()
	keepalive := time.NewTicker(15 * time.Second)
	defer keepalive.Stop()

	for {
		select {
		case <-ctx.Done():
			// Client disconnected; deferred unsubscribe handles cleanup.
			return

		case e, ok := <-sub.ch:
			if !ok {
				// Subscriber channel was closed (server-side shutdown).
				return
			}
			fmt.Fprint(w, e.format())
			flusher.Flush()

		case <-keepalive.C:
			// SSE comment to prevent proxy timeout disconnections.
			fmt.Fprint(w, ":keepalive\n\n")
			flusher.Flush()
		}
	}
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// checkBearer returns true when the Authorization header equals
// "Bearer <expected>".
func checkBearer(r *http.Request, expected string) bool {
	return r.Header.Get("Authorization") == "Bearer "+expected
}

// writeError sends a plain-text HTTP error response.
func writeError(w http.ResponseWriter, status int, msg string) {
	http.Error(w, msg, status)
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

func main() {
	port := flag.Int("port", 8080, "TCP port to listen on")
	defaultHistorySize := flag.Int("default-history-size", 100, "default per-channel history buffer size")
	flag.Parse()

	handler := NewBroker(*defaultHistorySize)

	addr := fmt.Sprintf(":%d", *port)
	log.Printf("SSE broker listening on %s (default-history-size=%d)", addr, *defaultHistorySize)
	if err := http.ListenAndServe(addr, handler); err != nil {
		log.Fatalf("server error: %v", err)
	}
}