"""Personal Journal CLI Viewer.

A command-line tool for reviewing personal journal entries stored as
dated plain-text files (YYYY-MM-DD.txt). Provides commands to view
today's entry, display a random past entry, search by keyword, and
show journal statistics.
"""

import os
import re
import random as rand_module
from datetime import date
from collections import Counter

import click

DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}\.txt$")


def get_valid_entries(journal_dir):
    """Return a sorted list of (date, filepath) tuples for valid journal files.

    Only files matching the YYYY-MM-DD.txt naming pattern with parseable
    dates are included. Results are sorted by date ascending.
    """
    if not os.path.isdir(journal_dir):
        return []
    entries = []
    for filename in os.listdir(journal_dir):
        if DATE_PATTERN.match(filename):
            try:
                dt = date.fromisoformat(filename.replace(".txt", ""))
                entries.append((dt, os.path.join(journal_dir, filename)))
            except ValueError:
                continue
    entries.sort()
    return entries


@click.group()
@click.option('--journal-dir', default='./journal', type=click.Path())
@click.pass_context
def cli(ctx, journal_dir):
    """Personal Journal CLI Viewer."""
    ctx.ensure_object(dict)
    ctx.obj['journal_dir'] = journal_dir


@cli.command()
@click.pass_context
def today(ctx):
    """Display today's journal entry."""
    journal_dir = ctx.obj['journal_dir']
    today_date = date.today()
    filepath = os.path.join(journal_dir, f"{today_date.isoformat()}.txt")
    if os.path.isfile(filepath):
        click.echo(click.style(today_date.isoformat(), fg='cyan'))
        with open(filepath) as f:
            click.echo(f.read(), nl=False)
    else:
        click.echo(f"No entry found for today ({today_date.isoformat()}).")


@cli.command()
@click.pass_context
def random(ctx):
    """Display a random past journal entry."""
    journal_dir = ctx.obj['journal_dir']
    today_date = date.today()
    entries = get_valid_entries(journal_dir)
    past_entries = [(dt, fp) for dt, fp in entries if dt < today_date]
    if not past_entries:
        click.echo("No past entries found.")
        return
    dt, filepath = rand_module.choice(past_entries)
    click.echo(click.style(dt.isoformat(), fg='cyan'))
    with open(filepath) as f:
        click.echo(f.read(), nl=False)


@cli.command()
@click.argument('keyword')
@click.pass_context
def search(ctx, keyword):
    """Search journal entries for lines containing a keyword."""
    journal_dir = ctx.obj['journal_dir']
    entries = get_valid_entries(journal_dir)
    results = []
    for dt, filepath in entries:
        with open(filepath) as f:
            for line in f:
                if keyword.lower() in line.lower():
                    results.append((dt, line.rstrip('\n').rstrip('\r')))
    if not results:
        click.echo(f"No entries found containing '{keyword}'.")
        return
    for dt, line_text in results:
        click.echo(click.style(dt.isoformat(), fg='cyan') + f": {line_text}")


@cli.command()
@click.pass_context
def stats(ctx):
    """Display journal statistics."""
    journal_dir = ctx.obj['journal_dir']
    entries = get_valid_entries(journal_dir)
    total = len(entries)

    click.echo(
        click.style("Total entries: ", fg='green')
        + click.style(str(total), fg='yellow')
    )

    if total == 0:
        streak = 0
    else:
        dates = [dt for dt, _ in entries]
        streak = 1
        current = 1
        for i in range(1, len(dates)):
            if (dates[i] - dates[i - 1]).days == 1:
                current += 1
            else:
                streak = max(streak, current)
                current = 1
        streak = max(streak, current)

    click.echo(
        click.style("Longest streak: ", fg='green')
        + click.style(str(streak), fg='yellow')
    )

    if total > 0:
        month_counts = Counter()
        for dt, _ in entries:
            month_counts[dt.strftime("%Y-%m")] += 1
        max_count = max(month_counts.values())
        candidates = sorted(m for m, c in month_counts.items() if c == max_count)
        best_month = candidates[0]
        click.echo(
            click.style("Most active month: ", fg='green')
            + click.style(f"{best_month} ({max_count} entries)", fg='yellow')
        )


if __name__ == '__main__':
    cli()
