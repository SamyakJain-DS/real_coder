"""
F2P Test Suite for md2slides: Markdown to HTML Slide Deck CLI

All tests verify observable behavior through the CLI binary.
No implementation details, internal function names, or private
structures are tested.

Interfaces covered:
  - CLI Entry Point  (main.go)
  - ParseSlides behavior  (slides/slides.go) via section count
  - ConvertToHTML behavior (slides/slides.go) via HTML content
"""

import os
import subprocess
import pytest

_TEST_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.join(_TEST_DIR, "..")
_BINARY = os.path.join(_PARENT_DIR, "md2slides")


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def _run(args):
    """Run the CLI binary.  If the binary is absent (empty codebase),
    call pytest.fail() so every test records FAIL, not ERROR."""
    if not os.path.isfile(_BINARY):
        pytest.fail("md2slides binary not found - build has not been run")
    return subprocess.run([_BINARY] + args, capture_output=True, text=True)


def _convert(tmp_path, md_content):
    """Write md_content to a temp file, invoke CLI, return
    (subprocess result, html string).  html is '' when no output file
    is produced."""
    inp = tmp_path / "input.md"
    out = tmp_path / "output.html"
    inp.write_text(md_content, encoding="utf-8")
    proc = _run([str(inp), str(out)])
    html = out.read_text(encoding="utf-8") if out.exists() else ""
    return proc, html


def _extract_block(html, open_tag, close_tag):
    """Return the content between the first open_tag and close_tag."""
    start = html.find(open_tag)
    end = html.find(close_tag, start)
    if start == -1 or end == -1:
        return ""
    return html[start:end + len(close_tag)]


# ════════════════════════════════════════════════════════════════
# CLI Entry Point - success path
# ════════════════════════════════════════════════════════════════

class TestCLISuccess:
    def test_exit_code_zero_on_valid_input(self, tmp_path):
        proc, _ = _convert(tmp_path, "# Slide One")
        assert proc.returncode == 0

    def test_output_file_is_created(self, tmp_path):
        inp = tmp_path / "input.md"
        out = tmp_path / "output.html"
        inp.write_text("# Slide One", encoding="utf-8")
        _run([str(inp), str(out)])
        assert out.exists()

    def test_output_file_is_nonempty(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        assert len(html) > 0


# ════════════════════════════════════════════════════════════════
# CLI Entry Point - error path
# ════════════════════════════════════════════════════════════════

class TestCLIErrors:
    def test_exit_code_1_with_no_arguments(self):
        proc = _run([])
        assert proc.returncode == 1

    def test_stderr_nonempty_with_no_arguments(self):
        proc = _run([])
        assert proc.stderr.strip() != ""

    def test_exit_code_1_with_one_argument(self, tmp_path):
        inp = tmp_path / "input.md"
        inp.write_text("# Slide One", encoding="utf-8")
        proc = _run([str(inp)])
        assert proc.returncode == 1

    def test_stderr_nonempty_with_one_argument(self, tmp_path):
        inp = tmp_path / "input.md"
        inp.write_text("# Slide One", encoding="utf-8")
        proc = _run([str(inp)])
        assert proc.stderr.strip() != ""

    def test_exit_code_1_with_missing_input_file(self, tmp_path):
        proc = _run([
            str(tmp_path / "does_not_exist.md"),
            str(tmp_path / "out.html"),
        ])
        assert proc.returncode == 1

    def test_stderr_nonempty_with_missing_input_file(self, tmp_path):
        proc = _run([
            str(tmp_path / "does_not_exist.md"),
            str(tmp_path / "out.html"),
        ])
        assert proc.stderr.strip() != ""

    def test_exit_code_1_with_unwritable_output_path(self, tmp_path):
        inp = tmp_path / "input.md"
        inp.write_text("# Slide One", encoding="utf-8")
        # Write into a non-existent subdirectory - fails for all users
        # including root, unlike chmod which root ignores.
        proc = _run([str(inp), str(tmp_path / "nonexistent_dir" / "out.html")])
        assert proc.returncode == 1

    def test_stderr_nonempty_with_unwritable_output_path(self, tmp_path):
        inp = tmp_path / "input.md"
        inp.write_text("# Slide One", encoding="utf-8")
        proc = _run([str(inp), str(tmp_path / "nonexistent_dir" / "out.html")])
        assert proc.stderr.strip() != ""


# ════════════════════════════════════════════════════════════════
# ParseSlides - slide boundary behavior via section count
# ════════════════════════════════════════════════════════════════

class TestParseSlides:
    def test_separator_splits_into_two_slides(self, tmp_path):
        _, html = _convert(tmp_path, "Slide one\n---\nSlide two")
        assert html.count("<section") == 2

    def test_h1_heading_splits_into_two_slides(self, tmp_path):
        _, html = _convert(tmp_path, "# First\ncontent\n# Second\ncontent")
        assert html.count("<section") == 2

    def test_h1_immediately_after_separator_produces_two_slides(self, tmp_path):
        _, html = _convert(tmp_path, "Slide one\n---\n# Slide two\ncontent")
        assert html.count("<section") == 2

    def test_empty_slide_between_separators_is_excluded(self, tmp_path):
        _, html = _convert(tmp_path, "Slide one\n---\n---\nSlide two")
        assert html.count("<section") == 2

    def test_separator_inside_fenced_code_block_is_not_a_boundary(self, tmp_path):
        md = "# Slide one\n```\n---\n```\nmore content"
        _, html = _convert(tmp_path, md)
        assert html.count("<section") == 1

    def test_h1_inside_fenced_code_block_is_not_a_boundary(self, tmp_path):
        md = "# Slide one\n```\n# Not a new slide\n```\nmore content"
        _, html = _convert(tmp_path, md)
        assert html.count("<section") == 1

    def test_multiple_h1_headings_produce_correct_section_count(self, tmp_path):
        md = "# A\ncontent\n# B\ncontent\n# C\ncontent"
        _, html = _convert(tmp_path, md)
        assert html.count("<section") == 3

    def test_empty_input_produces_no_sections(self, tmp_path):
        proc, html = _convert(tmp_path, "")
        assert proc.returncode == 0
        assert html.count("<section") == 0

    def test_separator_line_not_rendered_in_slide_content(self, tmp_path):
        """--- must be consumed as a separator; if incorrectly passed to goldmark
        it renders as <hr>. Blank line before --- ensures no Setext ambiguity."""
        _, html = _convert(tmp_path, "First slide\n\n---\n\nSecond slide")
        assert "<hr" not in html

    def test_h1_heading_included_in_slide_content(self, tmp_path):
        """The # heading line that triggers a new slide must appear rendered
        inside that slide's HTML, not be silently dropped."""
        _, html = _convert(tmp_path, "# MySlide\ncontent")
        assert "<h1>" in html
        assert "MySlide" in html


# ════════════════════════════════════════════════════════════════
# ConvertToHTML - HTML document structure
# ════════════════════════════════════════════════════════════════

class TestHTMLDocumentStructure:
    def test_output_is_html5_document(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        assert "doctype html" in html.lower()

    def test_output_contains_head_element(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        assert "<head>" in html

    def test_output_contains_body_element(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        assert "<body>" in html

    def test_slide_wrapped_in_section_element(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        assert "<section" in html

    def test_style_block_present_in_head(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        assert "<style>" in html

    def test_script_block_present_in_head(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        assert "<script>" in html

    def test_speaker_note_class_has_display_none_in_style(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        style = _extract_block(html, "<style>", "</style>")
        assert "speaker-note" in style
        assert "none" in style

    def test_section_viewport_width_in_style(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        assert "100vw" in html

    def test_section_viewport_height_in_style(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        assert "100vh" in html

    def test_section_overflow_hidden_in_style(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One")
        style = _extract_block(html, "<style>", "</style>")
        assert "overflow" in style
        assert "hidden" in style


# ════════════════════════════════════════════════════════════════
# ConvertToHTML - navigation behavior (CSS + script)
# ════════════════════════════════════════════════════════════════

class TestNavigationBehavior:
    def test_css_hides_inactive_sections(self, tmp_path):
        """Style block must hide sections that do not have class active."""
        _, html = _convert(tmp_path, "# Slide One\n---\n# Slide Two")
        style = _extract_block(html, "<style>", "</style>")
        assert "active" in style
        assert "none" in style

    def test_script_manages_active_class(self, tmp_path):
        """Script block must add and transfer the active class."""
        _, html = _convert(tmp_path, "# Slide One\n---\n# Slide Two")
        script = _extract_block(html, "<script>", "</script>")
        assert "active" in script

    def test_script_handles_keyboard_events(self, tmp_path):
        """Script block must respond to keyboard events for navigation."""
        _, html = _convert(tmp_path, "# Slide One\n---\n# Slide Two")
        script = _extract_block(html, "<script>", "</script>")
        assert "key" in script.lower()

    def test_script_handles_right_arrow(self, tmp_path):
        """Script block must advance slides on right arrow key press."""
        _, html = _convert(tmp_path, "# Slide One\n---\n# Slide Two")
        script = _extract_block(html, "<script>", "</script>")
        assert "ArrowRight" in script or "39" in script

    def test_script_handles_left_arrow(self, tmp_path):
        """Script block must return to previous slide on left arrow key press."""
        _, html = _convert(tmp_path, "# Slide One\n---\n# Slide Two")
        script = _extract_block(html, "<script>", "</script>")
        assert "ArrowLeft" in script or "37" in script




# ════════════════════════════════════════════════════════════════
# ConvertToHTML - speaker notes
# ════════════════════════════════════════════════════════════════

class TestSpeakerNotes:
    def test_note_line_produces_speaker_note_div(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One\nNOTE: My note text")
        assert '<div class="speaker-note">' in html

    def test_note_content_present_in_output(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One\nNOTE: My note text")
        assert "My note text" in html

    def test_note_prefix_string_absent_from_output(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One\nNOTE: My note text")
        assert "NOTE: My note text" not in html

    def test_note_inside_fenced_code_block_not_extracted_as_note(self, tmp_path):
        md = "# Slide One\n```\nNOTE: inside code\n```"
        _, html = _convert(tmp_path, md)
        assert '<div class="speaker-note">' not in html

    def test_note_inside_fenced_code_block_preserved_in_output(self, tmp_path):
        md = "# Slide One\n```\nNOTE: inside code\n```"
        _, html = _convert(tmp_path, md)
        assert "inside code" in html


# ════════════════════════════════════════════════════════════════
# ConvertToHTML - Markdown rendering
# ════════════════════════════════════════════════════════════════

class TestMarkdownRendering:
    def test_fenced_code_block_rendered_as_pre_element(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One\n```\nsome code\n```")
        assert "<pre>" in html

    def test_fenced_code_block_rendered_as_code_element(self, tmp_path):
        _, html = _convert(tmp_path, "# Slide One\n```\nsome code\n```")
        assert "<code>" in html

    def test_image_rendered_as_img_element(self, tmp_path):
        _, html = _convert(tmp_path, "![alt text](image.png)")
        assert "<img" in html

    def test_image_src_attribute_preserved(self, tmp_path):
        _, html = _convert(tmp_path, "![alt text](image.png)")
        assert "image.png" in html

    def test_image_alt_attribute_preserved(self, tmp_path):
        _, html = _convert(tmp_path, "![alt text](image.png)")
        assert "alt text" in html

    def test_table_rendered_as_table_element(self, tmp_path):
        md = "| A | B |\n|---|---|\n| 1 | 2 |"
        _, html = _convert(tmp_path, md)
        assert "<table>" in html

    def test_table_contains_thead(self, tmp_path):
        md = "| A | B |\n|---|---|\n| 1 | 2 |"
        _, html = _convert(tmp_path, md)
        assert "<thead>" in html

    def test_table_contains_tbody(self, tmp_path):
        md = "| A | B |\n|---|---|\n| 1 | 2 |"
        _, html = _convert(tmp_path, md)
        assert "<tbody>" in html