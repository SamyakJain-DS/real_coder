"""
F2P test suite for the Customer Lifetime Value Prediction Pipeline.

Every test maps to an explicit or implicit requirement from the prompt.
Tests verify observable behaviour and public interfaces only - no
implementation details, no hardcoded error messages, no private helpers.
"""

import os
import sys

import pandas as pd
import pytest
from pathlib import Path

_TEST_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.join(_TEST_DIR, "..")
_DEFAULT_CSV_PATH = os.path.join(_PARENT_DIR, "data", "transactions.csv")

sys.path.insert(0, _PARENT_DIR)

try:
    import clv_pipeline as clv
    _MODULE_AVAILABLE = True
except ImportError:
    clv = None
    _MODULE_AVAILABLE = False


# ---------------------------------------------------------------------------
# Shared fixtures
#
# Fixtures that depend on clv return None when the module is unavailable.
# They NEVER raise or call pytest.fail() - fixture-level failures produce
# ERROR, not FAILED.  Test bodies receive None and fail naturally on their
# first assertion or attribute access, which produces FAILED.
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def sample_transactions():
    """
    Minimal synthetic transaction DataFrame satisfying the schema.

    Customer summary:
      A - 3 purchases, 2 categories, multi-month (used for recency check)
      B - 4 purchases, 3 categories, multi-month
      C - 1 purchase only  (frequency = 0, seasonal_score = 0 edge case)
      D - 2 purchases, 1 category
      E - 3 purchases, 2 categories
      F - 3 purchases, 2 months: Jan x2 + Jul x1 (used for CV formula check)
    """
    records = [
        # A
        {"customer_id": "A", "transaction_date": "2022-01-10",
         "order_value": 50.0, "product_category": "electronics"},
        {"customer_id": "A", "transaction_date": "2022-04-15",
         "order_value": 80.0, "product_category": "electronics"},
        {"customer_id": "A", "transaction_date": "2022-09-20",
         "order_value": 60.0, "product_category": "clothing"},
        # B
        {"customer_id": "B", "transaction_date": "2022-02-01",
         "order_value": 30.0, "product_category": "electronics"},
        {"customer_id": "B", "transaction_date": "2022-05-01",
         "order_value": 40.0, "product_category": "clothing"},
        {"customer_id": "B", "transaction_date": "2022-08-01",
         "order_value": 50.0, "product_category": "food"},
        {"customer_id": "B", "transaction_date": "2022-11-01",
         "order_value": 35.0, "product_category": "electronics"},
        # C - single purchase
        {"customer_id": "C", "transaction_date": "2022-03-15",
         "order_value": 100.0, "product_category": "food"},
        # D
        {"customer_id": "D", "transaction_date": "2022-01-20",
         "order_value": 20.0, "product_category": "clothing"},
        {"customer_id": "D", "transaction_date": "2022-07-20",
         "order_value": 25.0, "product_category": "clothing"},
        # E
        {"customer_id": "E", "transaction_date": "2022-03-01",
         "order_value": 15.0, "product_category": "food"},
        {"customer_id": "E", "transaction_date": "2022-06-01",
         "order_value": 18.0, "product_category": "food"},
        {"customer_id": "E", "transaction_date": "2022-10-01",
         "order_value": 22.0, "product_category": "electronics"},
        # F - 2 purchases in Jan, 1 in Jul: unequal monthly counts for CV test
        {"customer_id": "F", "transaction_date": "2022-01-05",
         "order_value": 10.0, "product_category": "food"},
        {"customer_id": "F", "transaction_date": "2022-01-20",
         "order_value": 10.0, "product_category": "food"},
        {"customer_id": "F", "transaction_date": "2022-07-15",
         "order_value": 10.0, "product_category": "electronics"},
    ]
    df = pd.DataFrame(records)
    df["transaction_date"] = pd.to_datetime(df["transaction_date"])
    return df


@pytest.fixture(scope="module")
def features(sample_transactions):
    if not _MODULE_AVAILABLE:
        return None
    return clv.engineer_features(sample_transactions)


@pytest.fixture(scope="module")
def bgnbd_model(features):
    if not _MODULE_AVAILABLE:
        return None
    return clv.train_bgnbd_model(features)


@pytest.fixture(scope="module")
def gg_model(features):
    if not _MODULE_AVAILABLE:
        return None
    return clv.train_gamma_gamma_model(features)


@pytest.fixture(scope="module")
def clv_df(bgnbd_model, gg_model, features):
    if not _MODULE_AVAILABLE:
        return None
    return clv.predict_clv(bgnbd_model, gg_model, features)


@pytest.fixture(scope="module")
def segmented_df(clv_df):
    if not _MODULE_AVAILABLE:
        return None
    return clv.segment_customers(clv_df.copy())


# ---------------------------------------------------------------------------
# 1. data/transactions.csv
# ---------------------------------------------------------------------------

class TestDatasetFile:
    def test_file_exists(self):
        assert Path(_DEFAULT_CSV_PATH).exists()

    def test_required_columns_present(self):
        df = pd.read_csv(_DEFAULT_CSV_PATH)
        for col in ["customer_id", "transaction_date", "order_value",
                    "product_category"]:
            assert col in df.columns

    def test_contains_repeat_purchasers(self):
        df = pd.read_csv(_DEFAULT_CSV_PATH)
        counts = df.groupby("customer_id").size()
        assert (counts > 1).any()

    def test_order_value_is_positive(self):
        df = pd.read_csv(_DEFAULT_CSV_PATH)
        assert (df["order_value"] > 0).all()


# ---------------------------------------------------------------------------
# 2. load_transactions
# ---------------------------------------------------------------------------

class TestLoadTransactions:
    def test_returns_dataframe(self):
        result = clv.load_transactions(_DEFAULT_CSV_PATH)
        assert isinstance(result, pd.DataFrame)

    def test_required_columns_present(self):
        df = clv.load_transactions(_DEFAULT_CSV_PATH)
        for col in ["customer_id", "transaction_date", "order_value",
                    "product_category"]:
            assert col in df.columns

    def test_transaction_date_is_datetime(self):
        df = clv.load_transactions(_DEFAULT_CSV_PATH)
        assert pd.api.types.is_datetime64_any_dtype(df["transaction_date"])

    def test_order_value_is_numeric(self):
        df = clv.load_transactions(_DEFAULT_CSV_PATH)
        assert pd.api.types.is_numeric_dtype(df["order_value"])

    def test_order_value_is_positive(self):
        df = clv.load_transactions(_DEFAULT_CSV_PATH)
        assert (df["order_value"] > 0).all()

    def test_product_category_is_string_like(self):
        df = clv.load_transactions(_DEFAULT_CSV_PATH)
        assert df["product_category"].dtype == object or \
               pd.api.types.is_string_dtype(df["product_category"])


# ---------------------------------------------------------------------------
# 3. engineer_features
# ---------------------------------------------------------------------------

class TestEngineerFeatures:
    def test_returns_dataframe(self, sample_transactions):
        assert isinstance(clv.engineer_features(sample_transactions),
                          pd.DataFrame)

    def test_indexed_by_customer_id(self, features):
        assert features.index.name == "customer_id"

    def test_required_columns_present(self, features):
        for col in ["frequency", "recency", "T", "monetary_value",
                    "category_diversity", "seasonal_score"]:
            assert col in features.columns

    def test_frequency_dtype_is_integer(self, features):
        assert pd.api.types.is_integer_dtype(features["frequency"])

    def test_frequency_non_negative(self, features):
        assert (features["frequency"] >= 0).all()

    def test_frequency_is_total_purchases_minus_one(self, sample_transactions,
                                                     features):
        counts = sample_transactions.groupby("customer_id").size()
        for cid in features.index:
            assert features.loc[cid, "frequency"] == max(counts[cid] - 1, 0)

    def test_recency_non_negative(self, features):
        assert (features["recency"] >= 0).all()

    def test_recency_zero_for_single_purchase_customer(self, features):
        assert features.loc["C", "recency"] == 0.0

    def test_recency_exact_value_for_multi_purchase_customer(
            self, sample_transactions, features):
        txns_a = sample_transactions[
            sample_transactions["customer_id"] == "A"
        ]
        first = txns_a["transaction_date"].min()
        last = txns_a["transaction_date"].max()
        expected_recency = (last - first).days
        assert features.loc["A", "recency"] == pytest.approx(expected_recency)

    def test_T_non_negative(self, features):
        assert (features["T"] >= 0).all()

    def test_T_at_least_recency(self, features):
        assert (features["T"] >= features["recency"]).all()

    def test_T_derived_from_max_transaction_date(self, sample_transactions,
                                                  features):
        max_date = sample_transactions["transaction_date"].max()
        for cid in features.index:
            first = sample_transactions[
                sample_transactions["customer_id"] == cid
            ]["transaction_date"].min()
            expected_T = (max_date - first).days
            assert features.loc[cid, "T"] == pytest.approx(expected_T)

    def test_float_columns_dtype(self, features):
        for col in ["recency", "T", "monetary_value", "seasonal_score"]:
            assert pd.api.types.is_float_dtype(features[col]), \
                f"Expected float dtype for column '{col}'"

    def test_monetary_value_positive(self, features):
        assert (features["monetary_value"] > 0).all()

    def test_monetary_value_frequency_zero_equals_observed(
            self, sample_transactions, features):
        observed = sample_transactions[
            sample_transactions["customer_id"] == "C"
        ]["order_value"].iloc[0]
        assert features.loc["C", "monetary_value"] == pytest.approx(observed)

    def test_monetary_value_repeat_customers_excludes_first_purchase(
            self, sample_transactions, features):
        txns_a = sample_transactions[
            sample_transactions["customer_id"] == "A"
        ].sort_values("transaction_date")
        repeat_mean = txns_a.iloc[1:]["order_value"].mean()
        assert features.loc["A", "monetary_value"] == pytest.approx(repeat_mean)

    def test_category_diversity_dtype_is_integer(self, features):
        assert pd.api.types.is_integer_dtype(features["category_diversity"])

    def test_category_diversity_at_least_one(self, features):
        assert (features["category_diversity"] >= 1).all()

    def test_category_diversity_correct(self, sample_transactions, features):
        for cid in features.index:
            expected = sample_transactions[
                sample_transactions["customer_id"] == cid
            ]["product_category"].nunique()
            assert features.loc[cid, "category_diversity"] == expected

    def test_seasonal_score_non_negative(self, features):
        assert (features["seasonal_score"] >= 0.0).all()

    def test_seasonal_score_zero_for_single_purchase_customer(self, features):
        assert features.loc["C", "seasonal_score"] == 0.0

    def test_seasonal_score_is_cv_of_monthly_counts(
            self, sample_transactions, features):
        """
        Customer F: 2 purchases in Jan-2022, 1 in Jul-2022.
        The prompt specifies CV = std/mean of monthly purchase counts but
        does not define whether 'months' means transaction-months only or
        all calendar months in the observation window, nor whether to use
        population (ddof=0) or sample (ddof=1) std.
        We therefore compute all four valid interpretations and accept any.
        """
        txns_f = sample_transactions[
            sample_transactions["customer_id"] == "F"
        ].copy()
        periods = txns_f["transaction_date"].dt.to_period("M")

        # Interpretation 1: transaction-months only ([2, 1])
        txn_counts = txns_f.groupby(periods).size()

        # Interpretation 2: full observation window (includes zero months)
        full_range = pd.period_range(periods.min(), periods.max(), freq="M")
        full_counts = txn_counts.reindex(full_range, fill_value=0)

        def cv(series, ddof):
            m = series.mean()
            return series.std(ddof=ddof) / m if m > 0 else 0.0

        candidates = [
            cv(txn_counts, ddof=0),
            cv(txn_counts, ddof=1),
            cv(full_counts, ddof=0),
            cv(full_counts, ddof=1),
        ]

        score = features.loc["F", "seasonal_score"]

        assert any(
            abs(score - c) <= 0.01 * c
            for c in candidates
            if c > 0
        ), (
            f"seasonal_score={score:.4f} does not match any valid CV "
            f"interpretation: {[f'{c:.4f}' for c in candidates]}"
        )


# ---------------------------------------------------------------------------
# 4. train_bgnbd_model
# ---------------------------------------------------------------------------

class TestTrainBGNBD:
    def test_returns_betageo_fitter(self, bgnbd_model):
        from lifetimes import BetaGeoFitter
        assert isinstance(bgnbd_model, BetaGeoFitter)

    def test_model_is_fitted(self, bgnbd_model):
        assert hasattr(bgnbd_model, "params_")

    def test_accepts_custom_penalizer_coef(self, features):
        # Verify penalizer_coef actually affects fitted parameters
        model_low = clv.train_bgnbd_model(features, penalizer_coef=0.0)
        model_high = clv.train_bgnbd_model(features, penalizer_coef=5.0)
        assert model_low.params_.to_dict() != pytest.approx(
            model_high.params_.to_dict(), rel=1e-3
        )

    def test_default_penalizer_coef_is_0001(self, features):
        model = clv.train_bgnbd_model(features)
        assert model.penalizer_coef == pytest.approx(0.001)


# ---------------------------------------------------------------------------
# 5. train_gamma_gamma_model
# ---------------------------------------------------------------------------

class TestTrainGammaGamma:
    def test_returns_gamma_gamma_fitter(self, gg_model):
        from lifetimes import GammaGammaFitter
        assert isinstance(gg_model, GammaGammaFitter)

    def test_model_is_fitted(self, gg_model):
        assert hasattr(gg_model, "params_")

    def test_accepts_custom_penalizer_coef(self, features):
        # Verify penalizer_coef actually affects fitted parameters
        model_low = clv.train_gamma_gamma_model(features, penalizer_coef=0.0)
        model_high = clv.train_gamma_gamma_model(features, penalizer_coef=5.0)
        assert model_low.params_.to_dict() != pytest.approx(
            model_high.params_.to_dict(), rel=1e-3
        )

    def test_trains_on_repeat_customers_only(self, features):
        # Training on full features (incl. frequency=0) must produce identical
        # params as training on the frequency>0 subset - confirms filtering occurs
        model_full = clv.train_gamma_gamma_model(features)
        repeat_only = features[features["frequency"] > 0]
        model_subset = clv.train_gamma_gamma_model(repeat_only)
        assert model_full.params_.to_dict() == pytest.approx(
            model_subset.params_.to_dict(), rel=1e-4
        )

    def test_default_penalizer_coef_is_0001(self, features):
        model = clv.train_gamma_gamma_model(features)
        assert model.penalizer_coef == pytest.approx(0.001)


# ---------------------------------------------------------------------------
# 6. predict_clv
# ---------------------------------------------------------------------------

class TestPredictCLV:
    def test_returns_dataframe(self, clv_df):
        assert isinstance(clv_df, pd.DataFrame)

    def test_indexed_by_customer_id(self, clv_df):
        assert clv_df.index.name == "customer_id"

    def test_required_columns_present(self, clv_df):
        for col in ["predicted_purchases", "expected_avg_order_value",
                    "clv", "probability_alive"]:
            assert col in clv_df.columns

    def test_float_columns_dtype(self, clv_df):
        for col in ["predicted_purchases", "expected_avg_order_value",
                    "clv", "probability_alive"]:
            assert pd.api.types.is_float_dtype(clv_df[col]), \
                f"Expected float dtype for column '{col}'"

    def test_all_customers_in_output(self, features, clv_df):
        assert set(features.index) == set(clv_df.index)

    def test_predicted_purchases_non_negative(self, clv_df):
        assert (clv_df["predicted_purchases"] >= 0).all()

    def test_expected_avg_order_value_non_negative(self, clv_df):
        assert (clv_df["expected_avg_order_value"] >= 0).all()

    def test_clv_non_negative(self, clv_df):
        assert (clv_df["clv"] >= 0).all()

    def test_probability_alive_bounded(self, clv_df):
        assert (clv_df["probability_alive"] >= 0.0).all()
        assert (clv_df["probability_alive"] <= 1.0).all()

    def test_frequency_zero_uses_observed_monetary_value(self, features,
                                                          clv_df):
        zero_freq = features[features["frequency"] == 0].index
        for cid in zero_freq:
            assert clv_df.loc[cid, "expected_avg_order_value"] == pytest.approx(
                features.loc[cid, "monetary_value"]
            )

    def test_longer_time_horizon_yields_higher_or_equal_clv(
            self, bgnbd_model, gg_model, features):
        short = clv.predict_clv(bgnbd_model, gg_model, features,
                                 time_horizon=6)
        long_ = clv.predict_clv(bgnbd_model, gg_model, features,
                                 time_horizon=24)
        assert (long_["clv"] >= short["clv"] - 1e-6).all()

    def test_discount_rate_affects_clv_monotonically(self, bgnbd_model,
                                                       gg_model, features):
        clv_low_dr = clv.predict_clv(bgnbd_model, gg_model, features,
                                      discount_rate=0.0)
        clv_high_dr = clv.predict_clv(bgnbd_model, gg_model, features,
                                       discount_rate=0.5)
        assert (clv_low_dr["clv"] >= clv_high_dr["clv"] - 1e-6).all()

    def test_default_time_horizon_is_twelve_months(self, bgnbd_model,
                                                     gg_model, features):
        default = clv.predict_clv(bgnbd_model, gg_model, features)
        explicit = clv.predict_clv(bgnbd_model, gg_model, features,
                                    time_horizon=12)
        pd.testing.assert_frame_equal(default, explicit)

    def test_default_discount_rate(self, bgnbd_model, gg_model, features):
        default = clv.predict_clv(bgnbd_model, gg_model, features)
        explicit = clv.predict_clv(bgnbd_model, gg_model, features,
                                    discount_rate=0.01)
        pd.testing.assert_frame_equal(default, explicit)


# ---------------------------------------------------------------------------
# 7. segment_customers
# ---------------------------------------------------------------------------

class TestSegmentCustomers:
    def test_returns_dataframe(self, segmented_df):
        assert isinstance(segmented_df, pd.DataFrame)

    def test_segment_column_present(self, segmented_df):
        assert "segment" in segmented_df.columns

    def test_only_valid_labels(self, segmented_df):
        valid = {"Champions", "Loyal", "At-Risk", "Lost Causes"}
        assert set(segmented_df["segment"].unique()).issubset(valid)

    def test_no_missing_segments(self, segmented_df):
        assert segmented_df["segment"].isna().sum() == 0

    def test_tier_boundary_consistency(self, segmented_df):
        q25 = segmented_df["clv"].quantile(0.25)
        q50 = segmented_df["clv"].quantile(0.50)
        q75 = segmented_df["clv"].quantile(0.75)
        for _, row in segmented_df.iterrows():
            if row["segment"] == "Champions":
                assert row["clv"] >= q75 - 1e-6
            elif row["segment"] == "Loyal":
                assert row["clv"] >= q50 - 1e-6
                assert row["clv"] < q75 + 1e-6
            elif row["segment"] == "At-Risk":
                assert row["clv"] >= q25 - 1e-6
                assert row["clv"] < q50 + 1e-6
            elif row["segment"] == "Lost Causes":
                assert row["clv"] < q25 + 1e-6


# ---------------------------------------------------------------------------
# 8. get_retention_recommendations
# ---------------------------------------------------------------------------

class TestGetRetentionRecommendations:
    def test_returns_dict(self):
        assert isinstance(clv.get_retention_recommendations(), dict)

    def test_exactly_four_keys(self):
        assert len(clv.get_retention_recommendations()) == 4

    def test_keys_match_segment_labels(self):
        assert set(clv.get_retention_recommendations().keys()) == {
            "Champions", "Loyal", "At-Risk", "Lost Causes"
        }

    def test_all_values_are_non_empty_strings(self):
        for key, val in clv.get_retention_recommendations().items():
            assert isinstance(val, str)
            assert len(val.strip()) > 0


# ---------------------------------------------------------------------------
# 9. run_pipeline
# ---------------------------------------------------------------------------

class TestRunPipeline:
    def test_returns_dataframe(self):
        assert isinstance(clv.run_pipeline(data_path=_DEFAULT_CSV_PATH),
                          pd.DataFrame)

    def test_indexed_by_customer_id(self):
        assert clv.run_pipeline(
            data_path=_DEFAULT_CSV_PATH).index.name == "customer_id"

    def test_all_required_columns_present(self):
        result = clv.run_pipeline(data_path=_DEFAULT_CSV_PATH)
        for col in [
            "predicted_purchases", "expected_avg_order_value", "clv",
            "probability_alive", "segment", "frequency", "recency", "T",
            "monetary_value", "category_diversity", "seasonal_score",
        ]:
            assert col in result.columns

    def test_clv_non_negative(self):
        assert (clv.run_pipeline(data_path=_DEFAULT_CSV_PATH)["clv"] >= 0).all()

    def test_probability_alive_bounded(self):
        result = clv.run_pipeline(data_path=_DEFAULT_CSV_PATH)
        assert (result["probability_alive"] >= 0.0).all()
        assert (result["probability_alive"] <= 1.0).all()

    def test_segment_labels_valid(self):
        result = clv.run_pipeline(data_path=_DEFAULT_CSV_PATH)
        valid = {"Champions", "Loyal", "At-Risk", "Lost Causes"}
        assert set(result["segment"].unique()).issubset(valid)

    def test_longer_time_horizon_yields_higher_or_equal_clv(self):
        short = clv.run_pipeline(data_path=_DEFAULT_CSV_PATH, time_horizon=6)
        long_ = clv.run_pipeline(data_path=_DEFAULT_CSV_PATH, time_horizon=24)
        assert (long_["clv"] >= short["clv"] - 1e-6).all()

    def test_discount_rate_affects_clv_monotonically(self):
        result_low = clv.run_pipeline(
            data_path=_DEFAULT_CSV_PATH, discount_rate=0.0)
        result_high = clv.run_pipeline(
            data_path=_DEFAULT_CSV_PATH, discount_rate=0.5)
        assert (result_low["clv"] >= result_high["clv"] - 1e-6).all()

    def test_data_path_parameter_is_forwarded(self):
        result = clv.run_pipeline(data_path=_DEFAULT_CSV_PATH)
        expected_customers = set(
            clv.load_transactions(_DEFAULT_CSV_PATH)["customer_id"].unique()
        )
        assert set(result.index) == expected_customers

    def test_default_data_path_is_bundled_csv(self):
        default = clv.run_pipeline()
        explicit = clv.run_pipeline(data_path=_DEFAULT_CSV_PATH)
        pd.testing.assert_frame_equal(default, explicit)

    def test_default_time_horizon_is_twelve_months(self):
        default = clv.run_pipeline(data_path=_DEFAULT_CSV_PATH)
        explicit = clv.run_pipeline(
            data_path=_DEFAULT_CSV_PATH, time_horizon=12)
        pd.testing.assert_frame_equal(default, explicit)

    def test_default_discount_rate_is_001(self):
        default = clv.run_pipeline(data_path=_DEFAULT_CSV_PATH)
        explicit = clv.run_pipeline(
            data_path=_DEFAULT_CSV_PATH, discount_rate=0.01)
        pd.testing.assert_frame_equal(default, explicit)