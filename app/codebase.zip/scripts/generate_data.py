"""
Synthetic dataset generator for housing code enforcement analytics pipeline.
All randomness is seeded through a single seed parameter for full reproducibility.
"""
import os
import csv
import random
from datetime import date, timedelta


VIOLATION_CATEGORIES = [
    "structural_deficiency",
    "plumbing_failure",
    "electrical_hazard",
    "pest_infestation",
    "heating_system_failure",
    "fire_safety_violation",
    "sanitation_violation",
    "exterior_maintenance",
]

ENFORCEMENT_TOOLS = [
    "warning_notice",
    "civil_fine",
    "court_referral",
    "license_suspension",
]

INSPECTION_OUTCOMES = ["pass", "fail", "conditional_pass"]

NUM_PROPERTIES = 500
NUM_LANDLORDS = 120
NUM_NEIGHBORHOODS = 15
YEARS = [2019, 2020, 2021, 2022, 2023]


def _random_date(rng, start: date, end: date) -> date:
    delta = (end - start).days
    return start + timedelta(days=rng.randint(0, delta))


def generate_dataset(output_dir: str, seed: int = 42) -> None:
    """
    Generate synthetic five-year housing enforcement dataset and write to output_dir.

    Args:
        output_dir: Directory to write the five CSV files to.
        seed: Random seed for reproducibility.
    """
    os.makedirs(output_dir, exist_ok=True)
    rng = random.Random(seed)

    # --- Landlords ---
    landlord_ids = [f"L{i:03d}" for i in range(1, NUM_LANDLORDS + 1)]
    first_names = [
        "James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael",
        "Linda", "William", "Barbara", "David", "Susan", "Richard", "Jessica",
        "Joseph", "Sarah", "Thomas", "Karen", "Charles", "Nancy", "Christopher",
        "Lisa", "Daniel", "Betty", "Matthew", "Margaret", "Anthony", "Sandra",
        "Mark", "Ashley", "Donald", "Dorothy", "Steven", "Kimberly", "Paul",
        "Emily", "Andrew", "Donna", "Joshua", "Michelle",
    ]
    last_names = [
        "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
        "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez",
        "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
        "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark",
        "Ramirez", "Lewis", "Robinson",
    ]
    landlords = []
    for lid in landlord_ids:
        fn = rng.choice(first_names)
        ln = rng.choice(last_names)
        landlords.append({"landlord_id": lid, "landlord_name": f"{fn} {ln}"})

    # --- Neighborhoods ---
    neighborhood_names = [
        "Riverside Heights", "Oak Park", "Elmwood", "Northgate", "Westside",
        "Greenfield", "Lakewood", "Hillcrest", "Maplewood", "Sunset District",
        "Downtown Core", "East Village", "Harbor View", "Cedar Grove", "Pinehurst",
    ]
    neighborhood_ids = [f"N{i:02d}" for i in range(1, NUM_NEIGHBORHOODS + 1)]

    # Assign base condition scores and trends per neighborhood
    base_scores = {nid: rng.uniform(40, 85) for nid in neighborhood_ids}
    trends = {nid: rng.uniform(-4, 1) for nid in neighborhood_ids}

    neighborhoods = []
    for nid, name in zip(neighborhood_ids, neighborhood_names):
        base = base_scores[nid]
        trend = trends[nid]
        for i, year in enumerate(YEARS):
            score = base + trend * i + rng.gauss(0, 1.5)
            score = max(0.0, min(100.0, score))
            neighborhoods.append({
                "neighborhood_id": nid,
                "neighborhood_name": name,
                "year": year,
                "condition_score": round(score, 4),
            })

    # --- Properties ---
    # Distribute properties across landlords with variability
    property_ids = [f"P{i:04d}" for i in range(1, NUM_PROPERTIES + 1)]

    # Some landlords have big portfolios, some small
    weights = [rng.expovariate(0.5) + 0.5 for _ in landlord_ids]
    total_weight = sum(weights)
    cumulative = []
    acc = 0
    for w in weights:
        acc += w / total_weight
        cumulative.append(acc)

    properties = []
    prop_to_landlord = {}
    prop_to_neighborhood = {}
    for pid in property_ids:
        r = rng.random()
        lid_idx = next(i for i, c in enumerate(cumulative) if r <= c)
        lid = landlord_ids[lid_idx]
        nid = rng.choice(neighborhood_ids)
        absentee = rng.random() < 0.35
        year_built = rng.randint(1920, 2015)
        properties.append({
            "property_id": pid,
            "landlord_id": lid,
            "neighborhood_id": nid,
            "absentee_owner": absentee,
            "year_built": year_built,
        })
        prop_to_landlord[pid] = lid
        prop_to_neighborhood[pid] = nid

    # --- Inspections ---
    inspections = []
    inspection_id_counter = 1
    prop_inspection_history = {}  # pid -> list of (inspection_id, date, outcome)

    for pid in property_ids:
        # Each property gets 1–4 inspections over 5 years
        n_insp = rng.randint(1, 4)
        for _ in range(n_insp):
            year = rng.choice(YEARS)
            start = date(year, 1, 1)
            end = date(year, 12, 31)
            insp_date = _random_date(rng, start, end)
            insp_id = f"I{inspection_id_counter:05d}"
            inspection_id_counter += 1
            outcome = rng.choices(
                INSPECTION_OUTCOMES, weights=[0.45, 0.40, 0.15], k=1
            )[0]
            inspector_id = f"INS{rng.randint(1, 30):02d}"
            inspections.append({
                "inspection_id": insp_id,
                "property_id": pid,
                "inspection_date": insp_date.isoformat(),
                "inspector_id": inspector_id,
                "outcome": outcome,
            })
            if pid not in prop_inspection_history:
                prop_inspection_history[pid] = []
            prop_inspection_history[pid].append((insp_id, insp_date, outcome))

    # Sort each property's inspections by date
    for pid in prop_inspection_history:
        prop_inspection_history[pid].sort(key=lambda x: x[1])

    # --- Violations ---
    # Track prior violation categories per property for is_repeat logic
    prop_prior_categories = {}

    violations = []
    violation_id_counter = 1

    # Ensure each enforcement tool appears at least 80 times with both resolved/unresolved
    tool_counts = {t: 0 for t in ENFORCEMENT_TOOLS}
    tool_has_resolved = {t: False for t in ENFORCEMENT_TOOLS}
    tool_has_unresolved = {t: False for t in ENFORCEMENT_TOOLS}

    window_end = date(YEARS[-1], 12, 31)

    def _make_violation(rng, pid, insp_id, insp_date, prop_to_landlord, prop_prior_categories, forced_tool=None):
        cat = rng.choice(VIOLATION_CATEGORIES)
        # is_repeat is assigned in a post-processing pass (see below) so that
        # every True label is backed by a strictly-earlier inspection.
        is_repeat = False

        if forced_tool is not None:
            tool = forced_tool
        else:
            # Weighted enforcement tool selection (not uniform)
            tool_weights = [0.40, 0.30, 0.20, 0.10]
            tool = rng.choices(ENFORCEMENT_TOOLS, weights=tool_weights, k=1)[0]

        viol_date = insp_date + timedelta(days=rng.randint(0, 14))
        # Keep violation_date inside the five-year window so "years of data"
        # derived from violation_date matches the generator's YEARS list.
        if viol_date > window_end:
            viol_date = window_end
        enforcement_date = viol_date + timedelta(days=rng.randint(7, 60))
        start_year = viol_date.year
        cap_date = date(min(start_year + 1, 2024), 12, 31)

        resolved = rng.random() < 0.55
        if resolved:
            max_days = 180
            res_days = rng.randint(10, max_days)
            resolution_date = enforcement_date + timedelta(days=res_days)
            if resolution_date > cap_date:
                resolution_date = cap_date
            resolution_outcome = "resolved"
            resolution_date_str = resolution_date.isoformat()
        else:
            resolution_date_str = ""
            resolution_outcome = "unresolved"

        return {
            "cat": cat,
            "is_repeat": is_repeat,
            "tool": tool,
            "viol_date": viol_date,
            "enforcement_date": enforcement_date,
            "resolution_date_str": resolution_date_str,
            "resolution_outcome": resolution_outcome,
        }

    # First pass: generate violations from inspections
    for pid, insp_list in prop_inspection_history.items():
        lid = prop_to_landlord[pid]
        if pid not in prop_prior_categories:
            prop_prior_categories[pid] = set()

        for insp_id, insp_date, outcome in insp_list:
            if outcome == "pass":
                continue
            # fail -> 1-4 violations, conditional_pass -> 1-2
            n_viols = rng.randint(1, 4) if outcome == "fail" else rng.randint(1, 2)
            for _ in range(n_viols):
                v = _make_violation(rng, pid, insp_id, insp_date, prop_to_landlord, prop_prior_categories)
                vid = f"V{violation_id_counter:06d}"
                violation_id_counter += 1
                violations.append({
                    "violation_id": vid,
                    "inspection_id": insp_id,
                    "property_id": pid,
                    "landlord_id": lid,
                    "violation_category": v["cat"],
                    "enforcement_tool": v["tool"],
                    "violation_date": v["viol_date"].isoformat(),
                    "enforcement_action_date": v["enforcement_date"].isoformat(),
                    "resolution_date": v["resolution_date_str"],
                    "resolution_outcome": v["resolution_outcome"],
                    "is_repeat": v["is_repeat"],
                })
                prop_prior_categories[pid].add(v["cat"])
                tool_counts[v["tool"]] += 1
                if v["resolution_date_str"]:
                    tool_has_resolved[v["tool"]] = True
                else:
                    tool_has_unresolved[v["tool"]] = True

    # Second pass: ensure each tool has >= 80 violations + both resolved/unresolved
    # Pick a diverse set of property/inspection combos for extra violations
    all_insp_items = []
    for pid, insp_list in prop_inspection_history.items():
        for insp_id, insp_date, outcome in insp_list:
            all_insp_items.append((pid, insp_id, insp_date))

    for tool in ENFORCEMENT_TOOLS:
        needed = max(0, 80 - tool_counts[tool])
        # Also ensure both resolved and unresolved
        if not tool_has_resolved[tool]:
            needed = max(needed, 1)
        if not tool_has_unresolved[tool]:
            needed = max(needed, 1)

        for i in range(needed + 2):  # +2 for resolved/unresolved guarantee
            pid, insp_id, insp_date = rng.choice(all_insp_items)
            lid = prop_to_landlord[pid]
            if pid not in prop_prior_categories:
                prop_prior_categories[pid] = set()

            cat = rng.choice(VIOLATION_CATEGORIES)
            # is_repeat assigned in post-processing pass below.
            is_repeat = False
            viol_date = insp_date + timedelta(days=rng.randint(0, 14))
            if viol_date > window_end:
                viol_date = window_end
            enforcement_date = viol_date + timedelta(days=rng.randint(7, 60))

            # Alternate resolved/unresolved for the first two extra
            if i == 0 and not tool_has_resolved[tool]:
                res_days = rng.randint(10, 180)
                resolution_date = enforcement_date + timedelta(days=res_days)
                resolution_date_str = resolution_date.isoformat()
                resolution_outcome = "resolved"
                tool_has_resolved[tool] = True
            elif i == 1 and not tool_has_unresolved[tool]:
                resolution_date_str = ""
                resolution_outcome = "unresolved"
                tool_has_unresolved[tool] = True
            else:
                resolved = rng.random() < 0.55
                if resolved:
                    res_days = rng.randint(10, 180)
                    resolution_date = enforcement_date + timedelta(days=res_days)
                    resolution_date_str = resolution_date.isoformat()
                    resolution_outcome = "resolved"
                    tool_has_resolved[tool] = True
                else:
                    resolution_date_str = ""
                    resolution_outcome = "unresolved"
                    tool_has_unresolved[tool] = True

            vid = f"V{violation_id_counter:06d}"
            violation_id_counter += 1
            violations.append({
                "violation_id": vid,
                "inspection_id": insp_id,
                "property_id": pid,
                "landlord_id": lid,
                "violation_category": cat,
                "enforcement_tool": tool,
                "violation_date": viol_date.isoformat(),
                "enforcement_action_date": enforcement_date.isoformat(),
                "resolution_date": resolution_date_str,
                "resolution_outcome": resolution_outcome,
                "is_repeat": is_repeat,
            })
            prop_prior_categories[pid].add(cat)
            tool_counts[tool] += 1

    # --- Post-process is_repeat ---
    # is_repeat must reflect "same property had the same violation_category in a
    # prior inspection" (strictly earlier inspection_date). Compute per
    # (property_id, violation_category) the earliest inspection_date observed,
    # then flag any violation whose inspection_date is strictly later.
    insp_date_by_id = {row["inspection_id"]: row["inspection_date"] for row in inspections}
    earliest_by_key = {}
    for v in violations:
        key = (v["property_id"], v["violation_category"])
        d = insp_date_by_id[v["inspection_id"]]
        prev = earliest_by_key.get(key)
        if prev is None or d < prev:
            earliest_by_key[key] = d
    for v in violations:
        key = (v["property_id"], v["violation_category"])
        d = insp_date_by_id[v["inspection_id"]]
        v["is_repeat"] = d > earliest_by_key[key]

    # --- Write CSV files ---
    def write_csv(filepath, fieldnames, rows):
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    write_csv(
        os.path.join(output_dir, "landlords.csv"),
        ["landlord_id", "landlord_name"],
        landlords,
    )
    write_csv(
        os.path.join(output_dir, "neighborhoods.csv"),
        ["neighborhood_id", "neighborhood_name", "year", "condition_score"],
        neighborhoods,
    )
    write_csv(
        os.path.join(output_dir, "properties.csv"),
        ["property_id", "landlord_id", "neighborhood_id", "absentee_owner", "year_built"],
        properties,
    )
    write_csv(
        os.path.join(output_dir, "inspections.csv"),
        ["inspection_id", "property_id", "inspection_date", "inspector_id", "outcome"],
        inspections,
    )
    write_csv(
        os.path.join(output_dir, "violations.csv"),
        [
            "violation_id", "inspection_id", "property_id", "landlord_id",
            "violation_category", "enforcement_tool", "violation_date",
            "enforcement_action_date", "resolution_date", "resolution_outcome", "is_repeat",
        ],
        violations,
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate synthetic housing enforcement dataset")
    parser.add_argument("--output-dir", default="data", help="Directory to write CSV files")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()
    generate_dataset(args.output_dir, args.seed)
    print(f"Dataset generated in {args.output_dir}/")
