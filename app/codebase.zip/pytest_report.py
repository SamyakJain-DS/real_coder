"""
pytest_report.py - Pytest HTML Report Generator CLI Tool

Runs pytest with JSON output, parses the results, and generates a single
self-contained HTML report file.
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile


# ---------------------------------------------------------------------------
# parse_pytest_json
# ---------------------------------------------------------------------------

def parse_pytest_json(json_path: str) -> dict:
    """
    Reads and parses the pytest JSON report file at *json_path*.

    Returns a dictionary with:
      - "summary": {"passed": int, "failed": int, "skipped": int, "duration": float}
      - "tests": list of dicts, each with:
            "nodeid"   : str
            "outcome"  : str
            "duration" : float
            "longrepr" : str   (empty string if absent)
            "stdout"   : str   (empty string if absent)
            "stderr"   : str   (empty string if absent)
            "reruns"   : list of dicts each with at least "outcome" str
                         (empty list if absent)

    Raises FileNotFoundError if the file does not exist.
    """
    if not os.path.exists(json_path):
        raise FileNotFoundError(f"JSON report file not found: {json_path}")

    with open(json_path, "r", encoding="utf-8") as fh:
        raw = json.load(fh)

    raw_summary = raw.get("summary", {})
    summary = {
        "passed":   int(raw_summary.get("passed",  0)),
        "failed":   int(raw_summary.get("failed",  0)),
        "skipped":  int(raw_summary.get("skipped", 0)),
        "duration": float(raw_summary.get("duration", raw.get("duration", 0.0))),
    }

    tests = []
    for t in raw.get("tests", []):
        # longrepr may be a string or a structured dict – normalise to str
        longrepr_raw = t.get("longrepr", "")
        if isinstance(longrepr_raw, dict):
            longrepr = longrepr_raw.get("reprcrash", {}).get("message", "") or str(longrepr_raw)
        elif longrepr_raw is None:
            longrepr = ""
        else:
            longrepr = str(longrepr_raw)

        # stdout / stderr live inside "call" in some report formats
        call_section = t.get("call", {}) or {}
        stdout = t.get("stdout", "") or call_section.get("stdout", "") or ""
        stderr = t.get("stderr", "") or call_section.get("stderr", "") or ""

        # reruns
        reruns_raw = t.get("reruns", [])
        if not isinstance(reruns_raw, list):
            reruns_raw = []
        reruns = [
            {"outcome": str(r.get("outcome", ""))}
            for r in reruns_raw
            if isinstance(r, dict)
        ]

        tests.append({
            "nodeid":   str(t.get("nodeid", "")),
            "outcome":  str(t.get("outcome", "")),
            "duration": float(t.get("duration", 0.0)),
            "longrepr": longrepr,
            "stdout":   stdout,
            "stderr":   stderr,
            "reruns":   reruns,
        })

    return {"summary": summary, "tests": tests}


# ---------------------------------------------------------------------------
# generate_html_report
# ---------------------------------------------------------------------------

def generate_html_report(
    results: dict,
    output_path: str,
    coverage: dict | None,
    previous: dict | None,
) -> None:
    """
    Generates a self-contained HTML report at *output_path*.

    Parameters
    ----------
    results  : dict returned by parse_pytest_json
    output_path : str – destination HTML file path
    coverage : dict | None – parsed coverage.json or None
    previous : dict | None – parsed previous run JSON (same format as results) or None
    """

    summary  = results["summary"]
    tests    = results["tests"]

    passed_count  = summary["passed"]
    failed_count  = summary["failed"]
    skipped_count = summary["skipped"]
    duration_secs = summary["duration"]

    # ---- Trend: newly failing tests ----------------------------------------
    newly_failing = []
    if previous is not None:
        prev_map = {t["nodeid"]: t["outcome"] for t in previous.get("tests", [])}
        for t in tests:
            if t["outcome"] == "failed":
                prev_outcome = prev_map.get(t["nodeid"])
                # newly failing: was passing/skipped before, or brand-new
                if prev_outcome in (None, "passed", "skipped"):
                    newly_failing.append(t["nodeid"])

    # ---- Duration chart (10 slowest) ----------------------------------------
    slowest = sorted(tests, key=lambda x: x["duration"], reverse=True)[:10]

    # ---- Helpers ------------------------------------------------------------
    def esc(text: str) -> str:
        """HTML-escape a string."""
        return (
            text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#39;")
        )

    def status_class(outcome: str) -> str:
        mapping = {"passed": "pass", "failed": "fail", "skipped": "skip"}
        return mapping.get(outcome.lower(), "other")

    # ---- Build HTML ---------------------------------------------------------
    lines = []
    a = lines.append  # shorthand

    a("<!DOCTYPE html>")
    a('<html lang="en">')
    a("<head>")
    a('<meta charset="UTF-8">')
    a('<meta name="viewport" content="width=device-width, initial-scale=1.0">')
    a("<title>Pytest Report</title>")
    a("<style>")
    a("""
/* ===== Reset / Base ===== */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    background: #0f1117;
    color: #e2e8f0;
    line-height: 1.6;
    padding: 2rem;
}
h1 { font-size: 1.8rem; font-weight: 700; margin-bottom: 1.5rem; color: #f8fafc; }
h2 { font-size: 1.2rem; font-weight: 600; margin-bottom: 1rem; color: #cbd5e1; letter-spacing: .04em; text-transform: uppercase; }
section { margin-bottom: 2.5rem; }

/* ===== Summary Dashboard ===== */
.dashboard {
    display: flex;
    gap: 1.25rem;
    flex-wrap: wrap;
    margin-bottom: 2rem;
}
.card {
    flex: 1 1 140px;
    padding: 1.25rem 1.5rem;
    border-radius: 12px;
    text-align: center;
    background: #1e2230;
    border: 1px solid #2d3349;
}
.card .label { font-size: .78rem; text-transform: uppercase; letter-spacing: .08em; color: #94a3b8; margin-bottom: .4rem; }
.card .value { font-size: 2.4rem; font-weight: 700; }
.card.pass .value  { color: #4ade80; }
.card.fail .value  { color: #f87171; }
.card.skip .value  { color: #facc15; }
.card.time .value  { color: #818cf8; font-size: 1.9rem; }

/* ===== Filter controls ===== */
.filter-bar { display: flex; gap: .75rem; margin-bottom: 1rem; flex-wrap: wrap; }
.filter-btn {
    padding: .4rem 1.1rem;
    border-radius: 999px;
    border: 2px solid transparent;
    cursor: pointer;
    font-size: .85rem;
    font-weight: 600;
    transition: opacity .15s, border-color .15s;
    background: #1e2230;
    color: #e2e8f0;
}
.filter-btn.all    { border-color: #94a3b8; }
.filter-btn.pass   { border-color: #4ade80; color: #4ade80; }
.filter-btn.fail   { border-color: #f87171; color: #f87171; }
.filter-btn.skip   { border-color: #facc15; color: #facc15; }
.filter-btn.active { opacity: 1; }
.filter-btn:not(.active) { opacity: .45; }

/* ===== Test List ===== */
.test-list { display: flex; flex-direction: column; gap: .45rem; }
.test-item {
    border-radius: 8px;
    overflow: hidden;
    background: #1e2230;
    border: 1px solid #2d3349;
}
.test-header {
    display: flex;
    align-items: center;
    gap: .75rem;
    padding: .65rem 1rem;
}
.badge {
    flex-shrink: 0;
    font-size: .7rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .06em;
    padding: .15rem .6rem;
    border-radius: 999px;
}
.badge.pass { background: #14532d; color: #4ade80; }
.badge.fail { background: #450a0a; color: #f87171; }
.badge.skip { background: #422006; color: #facc15; }
.test-nodeid { font-family: 'Courier New', monospace; font-size: .82rem; color: #94a3b8; word-break: break-all; flex: 1; }
.flaky-badge { flex-shrink: 0; font-size: .68rem; font-weight: 700; background: #3b1f6e; color: #c084fc; padding: .12rem .55rem; border-radius: 999px; }

/* Stripe by status */
.test-item.pass { border-left: 3px solid #4ade80; }
.test-item.fail { border-left: 3px solid #f87171; }
.test-item.skip { border-left: 3px solid #facc15; }

/* ===== Expandable details ===== */
.details-toggle {
    background: none; border: none; cursor: pointer;
    font-size: .78rem; color: #818cf8; padding: 0 .5rem;
    flex-shrink: 0;
}
.details-toggle:hover { color: #a5b4fc; }
.test-details {
    display: none;
    padding: .75rem 1rem 1rem;
    border-top: 1px solid #2d3349;
}
.test-details.open { display: block; }
.detail-label { font-size: .72rem; text-transform: uppercase; letter-spacing: .07em; color: #64748b; margin-bottom: .3rem; margin-top: .75rem; }
.detail-label:first-child { margin-top: 0; }
pre.detail-block {
    background: #0a0d14;
    border: 1px solid #1e2230;
    border-radius: 6px;
    padding: .75rem 1rem;
    font-size: .78rem;
    font-family: 'Courier New', monospace;
    color: #fca5a5;
    overflow-x: auto;
    white-space: pre-wrap;
    word-break: break-word;
}
pre.detail-block.stdout { color: #a5f3fc; }
pre.detail-block.stderr { color: #fde68a; }

/* ===== Duration Chart ===== */
.duration-table { width: 100%; border-collapse: collapse; }
.duration-table th, .duration-table td {
    padding: .55rem .9rem;
    text-align: left;
    font-size: .83rem;
    border-bottom: 1px solid #1e2230;
}
.duration-table th { color: #64748b; font-weight: 600; }
.duration-table td:first-child { font-family: 'Courier New', monospace; color: #94a3b8; word-break: break-all; }
.duration-table td:last-child { color: #818cf8; text-align: right; white-space: nowrap; }
.duration-table tr:last-child td { border-bottom: none; }
.bar-cell { width: 200px; }
.bar-outer { background: #1e2230; border-radius: 999px; height: 8px; overflow: hidden; }
.bar-inner { height: 8px; border-radius: 999px; background: linear-gradient(90deg, #818cf8, #c084fc); }

/* ===== Coverage ===== */
.cov-overall { font-size: 3rem; font-weight: 700; color: #4ade80; margin-bottom: 1rem; }
.cov-overall.mid { color: #facc15; }
.cov-overall.low { color: #f87171; }
.cov-table { width: 100%; border-collapse: collapse; }
.cov-table th, .cov-table td { padding: .5rem .9rem; text-align: left; font-size: .82rem; border-bottom: 1px solid #1e2230; }
.cov-table th { color: #64748b; font-weight: 600; }
.cov-table td:first-child { font-family: 'Courier New', monospace; color: #94a3b8; }
.cov-table td:last-child { text-align: right; font-weight: 600; }
.cov-high  { color: #4ade80; }
.cov-mid   { color: #facc15; }
.cov-low   { color: #f87171; }

/* ===== Trend ===== */
.trend-empty { color: #4ade80; font-size: .9rem; }
.trend-list { display: flex; flex-direction: column; gap: .4rem; }
.trend-item { background: #1e1015; border: 1px solid #450a0a; border-left: 3px solid #f87171; border-radius: 6px; padding: .55rem 1rem; font-family: 'Courier New', monospace; font-size: .8rem; color: #fca5a5; word-break: break-all; }

/* ===== Panel wrapper ===== */
.panel { background: #161b27; border: 1px solid #2d3349; border-radius: 12px; padding: 1.5rem; }
""")
    a("</style>")
    a("</head>")
    a("<body>")
    a("<h1>&#128202; Pytest Report</h1>")

    # ---- Summary dashboard --------------------------------------------------
    a('<section>')
    a('<div class="dashboard">')
    a(f'<div class="card pass"><div class="label">Passed</div><div class="value">{passed_count}</div></div>')
    a(f'<div class="card fail"><div class="label">Failed</div><div class="value">{failed_count}</div></div>')
    a(f'<div class="card skip"><div class="label">Skipped</div><div class="value">{skipped_count}</div></div>')
    a(f'<div class="card time"><div class="label">Duration</div><div class="value">{duration_secs:.2f}s</div></div>')
    a('</div>')
    a('</section>')

    # ---- Test list ----------------------------------------------------------
    a('<section class="panel">')
    a('<h2>Test Results</h2>')
    a('<div class="filter-bar">')
    a('<button class="filter-btn all active" onclick="filterTests(\'all\', this)">All</button>')
    a('<button class="filter-btn pass" onclick="filterTests(\'pass\', this)">Passed</button>')
    a('<button class="filter-btn fail" onclick="filterTests(\'fail\', this)">Failed</button>')
    a('<button class="filter-btn skip" onclick="filterTests(\'skip\', this)">Skipped</button>')
    a('</div>')
    a('<div class="test-list" id="test-list">')

    for idx, t in enumerate(tests):
        sc        = status_class(t["outcome"])
        node_esc  = esc(t["nodeid"])
        outcome_u = t["outcome"].upper()

        # Flakiness: reruns list has >=1 entry with outcome=="failed" AND final outcome=="passed"
        is_flaky = (
            t["outcome"] == "passed"
            and any(r["outcome"] == "failed" for r in t["reruns"])
        )

        has_details = bool(t["longrepr"] or t["stdout"] or t["stderr"])

        a(f'<div class="test-item {sc}" data-status="{sc}">')
        a(f'  <div class="test-header">')
        a(f'    <span class="badge {sc}">{outcome_u}</span>')
        a(f'    <span class="test-nodeid">{node_esc}</span>')
        if is_flaky:
            a(f'    <span class="flaky-badge">&#9889; Flaky</span>')
        if has_details:
            a(f'    <button class="details-toggle" onclick="toggleDetails(\'detail-{idx}\')">&#9660; details</button>')
        a(f'  </div>')  # end .test-header

        if has_details:
            a(f'  <div class="test-details" id="detail-{idx}">')
            if t["longrepr"]:
                a(f'    <div class="detail-label">Traceback</div>')
                a(f'    <pre class="detail-block">{esc(t["longrepr"])}</pre>')
            if t["stdout"]:
                a(f'    <div class="detail-label">Captured stdout</div>')
                a(f'    <pre class="detail-block stdout">{esc(t["stdout"])}</pre>')
            if t["stderr"]:
                a(f'    <div class="detail-label">Captured stderr</div>')
                a(f'    <pre class="detail-block stderr">{esc(t["stderr"])}</pre>')
            a(f'  </div>')  # end .test-details

        a(f'</div>')  # end .test-item

    a('</div>')  # end #test-list
    a('</section>')

    # ---- Duration chart -----------------------------------------------------
    a('<section class="panel">')
    a('<h2>&#9201; 10 Slowest Tests</h2>')
    if slowest:
        max_dur = slowest[0]["duration"] if slowest else 1.0
        a('<table class="duration-table">')
        a('<thead><tr><th>Test</th><th class="bar-cell">Relative</th><th>Duration (s)</th></tr></thead>')
        a('<tbody>')
        for t in slowest:
            pct = (t["duration"] / max_dur * 100) if max_dur > 0 else 0
            a('<tr>')
            a(f'  <td>{esc(t["nodeid"])}</td>')
            a(f'  <td class="bar-cell"><div class="bar-outer"><div class="bar-inner" style="width:{pct:.1f}%"></div></div></td>')
            a(f'  <td>{t["duration"]:.4f}s</td>')
            a('</tr>')
        a('</tbody>')
        a('</table>')
    else:
        a('<p style="color:#64748b;">No test data available.</p>')
    a('</section>')

    # ---- Coverage section (only when coverage provided) ---------------------
    if coverage is not None:
        totals = coverage.get("totals", {})
        overall_pct = float(totals.get("percent_covered", 0.0))
        if overall_pct >= 80:
            pct_cls = "cov-overall"
        elif overall_pct >= 50:
            pct_cls = "cov-overall mid"
        else:
            pct_cls = "cov-overall low"

        a('<section class="panel">')
        a('<h2>&#128196; Coverage Summary</h2>')
        a(f'<div class="{pct_cls}">{overall_pct:.1f}%</div>')
        a('<p style="color:#64748b;font-size:.8rem;margin-bottom:1rem;">Overall line coverage</p>')

        files = coverage.get("files", {})
        if files:
            a('<table class="cov-table">')
            a('<thead><tr><th>Module</th><th>Line Coverage</th></tr></thead>')
            a('<tbody>')
            for module_path, module_data in sorted(files.items()):
                mod_pct = float(module_data.get("summary", {}).get("percent_covered", 0.0))
                if mod_pct >= 80:
                    cls = "cov-high"
                elif mod_pct >= 50:
                    cls = "cov-mid"
                else:
                    cls = "cov-low"
                a('<tr>')
                a(f'  <td>{esc(module_path)}</td>')
                a(f'  <td class="{cls}">{mod_pct:.1f}%</td>')
                a('</tr>')
            a('</tbody>')
            a('</table>')
        a('</section>')

    # ---- Trend section (only when previous provided) ------------------------
    if previous is not None:
        a('<section class="panel">')
        a('<h2>&#128200; Trend &mdash; Newly Failing Tests</h2>')
        if newly_failing:
            a('<div class="trend-list">')
            for nid in newly_failing:
                a(f'  <div class="trend-item">{esc(nid)}</div>')
            a('</div>')
        else:
            a('<p class="trend-empty">&#10003; No newly failing tests compared to the previous run.</p>')
        a('</section>')

    # ---- JavaScript ---------------------------------------------------------
    a('<script>')
    a("""
function filterTests(status, btn) {
    // Update active button
    document.querySelectorAll('.filter-btn').forEach(function(b) {
        b.classList.remove('active');
    });
    btn.classList.add('active');

    // Show/hide test items
    document.querySelectorAll('.test-item').forEach(function(item) {
        if (status === 'all') {
            item.style.display = '';
        } else {
            item.style.display = (item.dataset.status === status) ? '' : 'none';
        }
    });
}

function toggleDetails(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.classList.toggle('open');
}
""")
    a('</script>')

    a("</body>")
    a("</html>")

    html_content = "\n".join(lines)

    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(html_content)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Pytest HTML Report Generator",
        prog="pytest_report.py",
    )
    parser.add_argument(
        "test_target",
        nargs="?",
        help="Path to a test file or directory passed to pytest. "
             "Required when --from-json is not provided.",
    )
    parser.add_argument(
        "--output",
        default="report.html",
        metavar="HTML_PATH",
        help="Output HTML file path (default: report.html)",
    )
    parser.add_argument(
        "--from-json",
        metavar="JSON_PATH",
        dest="from_json",
        help="Path to a pre-generated pytest JSON report. "
             "Skips pytest invocation when provided.",
    )
    parser.add_argument(
        "--previous",
        metavar="PREVIOUS_JSON_PATH",
        help="Path to a previous pytest JSON report for trend comparison.",
    )
    parser.add_argument(
        "--coverage",
        metavar="COVERAGE_JSON_PATH",
        help="Path to a coverage JSON file generated by 'coverage json'.",
    )
    def positive_int(value):
        ivalue = int(value)
        if ivalue <= 0:
            raise argparse.ArgumentTypeError(f"{value} is not a positive integer")
        return ivalue

    parser.add_argument(
        "--reruns",
        type=positive_int,
        metavar="N",
        help="Number of reruns to pass to pytest via --reruns <N>.",
    )

    args = parser.parse_args()

    # ---- Resolve the JSON report -------------------------------------------
    if args.from_json:
        # Use the pre-generated JSON report; skip pytest invocation
        json_report_path = args.from_json
        if not os.path.exists(json_report_path):
            print(
                f"Error: --from-json file not found: {json_report_path}",
                file=sys.stderr,
            )
            return 1
        save_previous = False  # only save when pytest was actually invoked
    else:
        # test_target is required when --from-json is absent
        if not args.test_target:
            print(
                "Error: 'test_target' argument is required when --from-json is not provided.",
                file=sys.stderr,
            )
            return 1

        # Create a temporary file for the JSON report
        tmp_fd, json_report_path = tempfile.mkstemp(suffix=".json", prefix="pytest_report_")
        os.close(tmp_fd)
        # Remove the empty temp file so pytest-json-report can create it fresh
        try:
            os.remove(json_report_path)
        except OSError:
            pass

        cmd = [
            sys.executable, "-m", "pytest",
            args.test_target,
            "--json-report",
            f"--json-report-file={json_report_path}",
        ]
        if args.reruns is not None:
            cmd += ["--reruns", str(args.reruns)]

        try:
            subprocess.run(cmd, check=False)
        except Exception as exc:
            print(f"Error: Failed to invoke pytest: {exc}", file=sys.stderr)
            return 1

        if not os.path.exists(json_report_path):
            print(
                "Error: pytest did not produce the expected JSON report file.",
                file=sys.stderr,
            )
            return 1

        save_previous = True

    # ---- Parse the current JSON report ------------------------------------
    try:
        results = parse_pytest_json(json_report_path)
    except FileNotFoundError:
        print(
            f"Error: JSON report file not found: {json_report_path}",
            file=sys.stderr,
        )
        return 1
    except json.JSONDecodeError as exc:
        print(
            f"Error: Malformed JSON in report file '{json_report_path}': {exc}",
            file=sys.stderr,
        )
        return 1

    # ---- Save current run to previous_run.json (only when pytest invoked) --
    if save_previous:
        try:
            shutil.copy2(json_report_path, "previous_run.json")
        except OSError as exc:
            # Non-fatal; warn but do not fail
            print(f"Warning: Could not save previous_run.json: {exc}", file=sys.stderr)

    # ---- Parse --previous --------------------------------------------------
    previous_results = None
    if args.previous:
        if not os.path.exists(args.previous):
            print(
                f"Error: --previous file not found: {args.previous}",
                file=sys.stderr,
            )
            return 1
        try:
            previous_results = parse_pytest_json(args.previous)
        except FileNotFoundError:
            print(
                f"Error: --previous file not found: {args.previous}",
                file=sys.stderr,
            )
            return 1
        except json.JSONDecodeError as exc:
            print(
                f"Error: Malformed JSON in --previous file '{args.previous}': {exc}",
                file=sys.stderr,
            )
            return 1

    # ---- Parse --coverage --------------------------------------------------
    coverage_data = None
    if args.coverage:
        if not os.path.exists(args.coverage):
            print(
                f"Error: --coverage file not found: {args.coverage}",
                file=sys.stderr,
            )
            return 1
        try:
            with open(args.coverage, "r", encoding="utf-8") as fh:
                coverage_data = json.load(fh)
        except json.JSONDecodeError as exc:
            print(
                f"Error: Malformed JSON in --coverage file '{args.coverage}': {exc}",
                file=sys.stderr,
            )
            return 1
        except OSError as exc:
            print(
                f"Error: Could not read --coverage file '{args.coverage}': {exc}",
                file=sys.stderr,
            )
            return 1

    # ---- Generate HTML report ----------------------------------------------
    generate_html_report(
        results=results,
        output_path=args.output,
        coverage=coverage_data,
        previous=previous_results,
    )

    print(f"Report written to: {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())