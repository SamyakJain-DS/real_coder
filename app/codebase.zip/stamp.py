"""Stamp Collection CLI – manage a personal philatelic stamp collection.

Provides commands to register stamps, filter the collection, record
Scott catalog values, and view the total collection value. All data
persists in a local ``stamps.json`` file.
"""

import json
import os
import sys

import click

STAMPS_FILE = "stamps.json"


def _load_data():
    """Load stamp data from stamps.json, creating the file if it does not exist."""
    if not os.path.exists(STAMPS_FILE):
        data = {"stamps": [], "next_id": 1}
        _save_data(data)
        return data
    with open(STAMPS_FILE, "r") as f:
        return json.load(f)


def _save_data(data):
    """Write stamp data back to stamps.json."""
    with open(STAMPS_FILE, "w") as f:
        json.dump(data, f, indent=2)


@click.group()
def stamp():
    """Manage a personal philatelic stamp collection."""


@stamp.command()
@click.argument("year", type=int)
@click.argument("country")
@click.argument("denomination")
@click.argument("description")
@click.argument("condition")
def add(year, country, denomination, description, condition):
    """Register a new stamp in the collection."""
    data = _load_data()
    stamp_id = data["next_id"]
    record = {
        "id": stamp_id,
        "year": year,
        "country": country,
        "denomination": denomination,
        "description": description,
        "condition": condition,
        "catalog_value": None,
    }
    data["stamps"].append(record)
    data["next_id"] = stamp_id + 1
    _save_data(data)
    click.echo(f"Added stamp {stamp_id}")


@stamp.command("list")
@click.argument("country", required=False, default=None)
@click.argument("year", type=int, required=False, default=None)
def list_stamps(country, year):
    """Display stamps filtered by country and/or year."""
    data = _load_data()
    for s in data["stamps"]:
        if country is not None and s["country"] != country:
            continue
        if year is not None and s["year"] != year:
            continue
        val = "N/A" if s["catalog_value"] is None else s["catalog_value"]
        click.echo(
            f"{s['id']} {s['year']} {s['country']} {s['denomination']} "
            f"{s['description']} {s['condition']} {val}"
        )


@stamp.command()
@click.argument("value", type=float)
def catalog(value):
    """Record the Scott catalog value for the most recently added stamp."""
    data = _load_data()
    if not data["stamps"]:
        click.echo("Error: no stamps in collection", err=True)
        sys.exit(1)
    highest = max(data["stamps"], key=lambda s: s["id"])
    highest["catalog_value"] = value
    _save_data(data)
    click.echo(f"Cataloged stamp {highest['id']} at {value}")


@stamp.command()
def value():
    """Print the total collection value."""
    data = _load_data()
    total = sum(
        s["catalog_value"] for s in data["stamps"]
        if s["catalog_value"] is not None
    )
    click.echo(f"{total:.2f}")
