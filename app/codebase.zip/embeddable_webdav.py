import abc
import dataclasses
import datetime
import email.utils
import enum
import io
import re
import threading
import typing
import urllib.parse
import uuid
import xml.etree.ElementTree as ET


# ---------------------------------------------------------------------------
# Module level constants
# ---------------------------------------------------------------------------

_DAV_NS = "DAV:"

_LIVE_PROPERTY_NAMES: tuple[str, ...] = (
    "creationdate",
    "displayname",
    "getcontentlength",
    "getcontenttype",
    "getetag",
    "getlastmodified",
    "lockdiscovery",
    "resourcetype",
    "supportedlock",
)
_LIVE_PROPERTY_SET: frozenset[str] = frozenset(_LIVE_PROPERTY_NAMES)

_DISPATCH_METHODS: tuple[str, ...] = (
    "OPTIONS", "GET", "HEAD", "PUT", "DELETE", "MKCOL",
    "COPY", "MOVE", "PROPFIND", "PROPPATCH", "LOCK", "UNLOCK",
)
_DISPATCH_SET: frozenset[str] = frozenset(_DISPATCH_METHODS)

_MUTATING_METHODS: frozenset[str] = frozenset({
    "PUT", "DELETE", "MKCOL", "COPY", "MOVE", "PROPPATCH",
})

_ALLOW_GLOBAL = (
    "OPTIONS, GET, HEAD, PUT, DELETE, MKCOL, COPY, MOVE, "
    "PROPFIND, PROPPATCH, LOCK, UNLOCK"
)
_ALLOW_ON_COLLECTION = (
    "OPTIONS, HEAD, PROPFIND, PROPPATCH, COPY, MOVE, DELETE, "
    "LOCK, UNLOCK"
)
_ALLOW_PUT = (
    "OPTIONS, GET, HEAD, PROPFIND, PROPPATCH, COPY, MOVE, DELETE, "
    "LOCK, UNLOCK"
)
_ALLOW_MKCOL = (
    "OPTIONS, GET, HEAD, PUT, PROPFIND, PROPPATCH, COPY, MOVE, DELETE, "
    "LOCK, UNLOCK"
)


# ---------------------------------------------------------------------------
# Public dataclass: ResourceInfo
# ---------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class ResourceInfo:
    """Frozen metadata record returned by :meth:`VirtualFileSystem.get_info`.

    Carries the seven fields the WebDAV server needs to compute the
    standard live properties (requirement 13) for a resource, plus the
    flag distinguishing a collection from a non-collection resource.
    """

    is_collection: bool
    content_length: int
    content_type: str
    etag: str
    created_at: datetime.datetime
    modified_at: datetime.datetime
    display_name: str


# ---------------------------------------------------------------------------
# Public ABC: VirtualFileSystem
# ---------------------------------------------------------------------------


class VirtualFileSystem(abc.ABC):
    """Typed virtual filesystem interface backing the WebDAV server.

    The host application supplies one concrete subclass instance to
    :meth:`WebDAVServer.__init__`. Every storage read and every storage
    mutation issued by the server flows through one of the methods
    defined on this class.

    Path conventions:

    * Every accepted path starts with one leading ``/``.
    * No path carries a trailing ``/`` beyond the literal root path
      ``"/"``.
    * Path components are separated by single ``/`` characters.
    * The parent path of ``/x`` is ``/``; the parent path of ``/a/b/c``
      is ``/a/b``.
    """

    @abc.abstractmethod
    def exists(self, path: str) -> bool:
        """Return ``True`` when one resource exists at ``path``."""

    @abc.abstractmethod
    def get_info(self, path: str) -> ResourceInfo:
        """Return one :class:`ResourceInfo` describing the resource at ``path``.

        Raises :class:`FileNotFoundError` when zero resources exist at
        ``path``.
        """

    @abc.abstractmethod
    def list_children(self, path: str) -> list[str]:
        """Return the immediate child names of the collection at ``path``.

        Names are ordered ascending by Unicode code point sequence.
        Raises :class:`FileNotFoundError` when zero resources exist at
        ``path`` and :class:`NotADirectoryError` when the resource at
        ``path`` is non-collection.
        """

    @abc.abstractmethod
    def read_bytes(self, path: str) -> bytes:
        """Return the byte content of the non-collection resource at ``path``.

        Raises :class:`FileNotFoundError` when zero resources exist at
        ``path`` and :class:`IsADirectoryError` when the resource at
        ``path`` is a collection.
        """

    @abc.abstractmethod
    def write_bytes(
        self, path: str, content: bytes, content_type: str
    ) -> None:
        """Create or replace the non-collection resource at ``path``.

        Raises :class:`IsADirectoryError` when the existing resource at
        ``path`` is a collection, :class:`FileNotFoundError` when the
        parent path is missing, and :class:`NotADirectoryError` when
        the parent resolves to a non-collection resource.
        """

    @abc.abstractmethod
    def create_collection(self, path: str) -> None:
        """Create one collection resource at ``path``.

        Raises :class:`FileExistsError` when a resource already exists,
        :class:`FileNotFoundError` when the parent path is missing, and
        :class:`NotADirectoryError` when the parent resolves to a
        non-collection resource.
        """

    @abc.abstractmethod
    def delete(self, path: str) -> None:
        """Remove the resource at ``path`` (recursively for collections).

        Raises :class:`FileNotFoundError` when zero resources exist at
        ``path``.
        """

    @abc.abstractmethod
    def copy(
        self, source: str, destination: str, depth_infinity: bool
    ) -> None:
        """Copy the resource at ``source`` to ``destination``.

        For a collection source: when ``depth_infinity`` is ``False`` an
        empty collection is created at ``destination``; when
        ``depth_infinity`` is ``True`` every descendant is recursively
        copied to the matching path under ``destination``.
        """

    @abc.abstractmethod
    def move(self, source: str, destination: str) -> None:
        """Move the resource at ``source`` (recursively) to ``destination``."""


# ---------------------------------------------------------------------------
# Public ABC: DeadPropertyBackend
# ---------------------------------------------------------------------------


class DeadPropertyBackend(abc.ABC):
    """Pluggable storage interface for custom (dead) WebDAV properties.

    The host application supplies one concrete subclass instance to
    :meth:`WebDAVServer.__init__`. The server reads and mutates every
    custom dead property through this backend exclusively.
    """

    @abc.abstractmethod
    def get_property(
        self, path: str, namespace: str, name: str
    ) -> str:
        """Return the XML-encoded value of one dead property.

        Raises :class:`KeyError` when the named dead property is absent
        for the resource at ``path``.
        """

    @abc.abstractmethod
    def set_property(
        self, path: str, namespace: str, name: str, xml_value: str
    ) -> None:
        """Store ``xml_value`` as the dead property identified by
        ``(namespace, name)`` for the resource at ``path``.

        Replaces the previous value when the property is already
        present.
        """

    @abc.abstractmethod
    def remove_property(
        self, path: str, namespace: str, name: str
    ) -> None:
        """Remove the dead property identified by ``(namespace, name)``.

        Raises :class:`KeyError` when the named dead property is absent
        for the resource at ``path``.
        """

    @abc.abstractmethod
    def list_properties(
        self, path: str
    ) -> list[tuple[str, str, str]]:
        """Return ``(namespace, name, xml_value)`` for every dead property.

        Tuples are ordered ascending by ``(namespace, name)`` Unicode
        code point sequence. Returns the empty list when zero dead
        properties are stored for ``path``.
        """

    @abc.abstractmethod
    def copy_properties(
        self, source: str, destination: str
    ) -> None:
        """Replace destination dead properties with a copy of source's."""

    @abc.abstractmethod
    def move_properties(
        self, source: str, destination: str
    ) -> None:
        """Move every dead property from ``source`` to ``destination``."""


# ---------------------------------------------------------------------------
# Internal lock record
# ---------------------------------------------------------------------------


class _LockScope(enum.Enum):
    """Allowed values for a lock record's scope field."""

    EXCLUSIVE = "exclusive"
    SHARED = "shared"


class _LockDepth(enum.Enum):
    """Allowed values for a lock record's depth field."""

    ZERO = "0"
    INFINITY = "infinity"


@dataclasses.dataclass
class _LockRecord:
    """One stored lock record (requirement 15).

    Fields:

    * ``scope`` -- ``"exclusive"`` or ``"shared"``.
    * ``depth`` -- ``"0"`` or ``"infinity"``.
    * ``timeout_seconds`` -- the resolved timeout in seconds.
    * ``owner_xml`` -- the verbatim XML inner content of ``{DAV:}owner``
      supplied at LOCK time.
    * ``token`` -- ``urn:uuid:<UUID4>``.
    * ``anchor_path`` -- the request path the lock was acquired against.
    * ``expires_at`` -- the timezone-aware UTC datetime at which the
      lock expires.
    """

    scope: str
    depth: str
    timeout_seconds: int
    owner_xml: str
    token: str
    anchor_path: str
    expires_at: datetime.datetime


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _utcnow() -> datetime.datetime:
    """Return the current UTC datetime (timezone-aware)."""

    return datetime.datetime.now(datetime.timezone.utc)


def _parent_path(path: str) -> typing.Optional[str]:
    """Return the parent path of ``path`` per the conventions in Req 1."""

    if path == "/":
        return None
    head = path.rsplit("/", 1)[0]
    return head if head else "/"


def _is_strict_descendant(child: str, ancestor: str) -> bool:
    """``True`` iff ``child`` is a strict descendant path of ``ancestor``."""

    if child == ancestor:
        return False
    if ancestor == "/":
        return child.startswith("/") and child != "/"
    return child.startswith(ancestor + "/")


def _join_paths(parent: str, name: str) -> str:
    """Return the canonical child path of ``parent`` named ``name``."""

    if parent == "/":
        return "/" + name
    return parent + "/" + name


def _xml_text_escape(s: str) -> str:
    """Escape a string for safe inclusion in XML element text."""

    return (
        s.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
    )


def _xml_attr_escape(s: str) -> str:
    """Escape a string for safe inclusion in an XML attribute value."""

    return _xml_text_escape(s).replace('"', "&quot;")


def _parse_clark_name(tag: str) -> tuple[str, str]:
    """Split an ElementTree tag in Clark notation into (namespace, name)."""

    if tag.startswith("{"):
        idx = tag.index("}")
        return tag[1:idx], tag[idx + 1:]
    return "", tag


def _serialize_inner_xml_verbatim(elem: ET.Element) -> str:
    """Return a verbatim serialisation of ``elem``'s inner content.

    Used by LOCK (requirements 13 and 15) when capturing the
    "verbatim XML inner content" of the ``{DAV:}owner`` element so the
    same content can be re-embedded inside ``{DAV:}lockdiscovery``
    responses without alteration.
    """

    parts: list[str] = []
    if elem.text:
        parts.append(elem.text)
    for child in elem:
        parts.append(ET.tostring(child, encoding="unicode"))
    return "".join(parts)


def _serialize_inner_xml_canonical(elem: ET.Element) -> str:
    """Return the canonical XML serialisation of ``elem``'s inner content.

    Used by PROPPATCH (requirement 14) when storing a dead property
    value through :meth:`DeadPropertyBackend.set_property`. The
    serialisation is produced through
    :func:`xml.etree.ElementTree.canonicalize` so the stored string is
    the W3C XML C14N canonical form of the element body: attributes are
    sorted, namespace declarations are normalised, empty elements are
    written with explicit start/end tag pairs, and special characters
    inside text and attribute values are escaped uniformly.
    """

    raw = ET.tostring(elem, encoding="unicode")
    canonical = ET.canonicalize(xml_data=raw)
    open_end = canonical.index(">") + 1
    close_start = canonical.rfind("</")
    return canonical[open_end:close_start]


# ---------------------------------------------------------------------------
# If-header parser (RFC 4918 section 10.4.2)
# ---------------------------------------------------------------------------


@dataclasses.dataclass
class _IfCondition:
    """One parsed condition inside a parenthesized list."""

    is_state_token: bool
    value: str
    negated: bool


@dataclasses.dataclass
class _IfList:
    """One parenthesized condition list bound to a path."""

    conditions: list[_IfCondition]
    bound_path: str


def _parse_if_header(value: str, default_path: str) -> list[_IfList]:
    """Parse the ``If`` request header into a list of bound condition lists.

    Implements both shapes defined by requirement 17:

    * the **no-tag** shape, where every parenthesized condition list is
      bound to ``default_path`` (the request path);
    * the **tagged** shape, where each ``<Coded-URL>`` introduces a
      tagged group whose subsequent parenthesized condition lists are
      bound to the path obtained by passing the URL to
      ``urllib.parse.urlsplit`` then ``urllib.parse.unquote``.
    """

    n = len(value)
    pos = 0
    lists: list[_IfList] = []
    current_path = default_path

    def _skip_ws() -> None:
        nonlocal pos
        while pos < n and value[pos] in " \t\r\n":
            pos += 1

    while True:
        _skip_ws()
        if pos >= n:
            break

        if value[pos] == "<":
            try:
                end = value.index(">", pos + 1)
            except ValueError:
                break
            uri = value[pos + 1:end]
            parts = urllib.parse.urlsplit(uri)
            current_path = urllib.parse.unquote(parts.path)
            pos = end + 1
            continue

        if value[pos] != "(":
            pos += 1
            continue

        pos += 1
        conditions: list[_IfCondition] = []
        while pos < n and value[pos] != ")":
            _skip_ws()
            if pos >= n or value[pos] == ")":
                break
            negated = False
            if value[pos:pos + 3].lower() == "not":
                negated = True
                pos += 3
                _skip_ws()
            if pos >= n:
                break
            if value[pos] == "<":
                try:
                    end = value.index(">", pos + 1)
                except ValueError:
                    break
                token = value[pos + 1:end]
                conditions.append(
                    _IfCondition(
                        is_state_token=True, value=token, negated=negated,
                    )
                )
                pos = end + 1
            elif value[pos] == "[":
                try:
                    end = value.index("]", pos + 1)
                except ValueError:
                    break
                etag = value[pos + 1:end]
                conditions.append(
                    _IfCondition(
                        is_state_token=False, value=etag, negated=negated,
                    )
                )
                pos = end + 1
            else:
                pos += 1
        if pos < n and value[pos] == ")":
            pos += 1
        lists.append(_IfList(conditions=conditions, bound_path=current_path))

    return lists


def _strong_etag_compare(a: str, b: str) -> bool:
    """Strong entity-tag comparison per RFC 9110 section 8.8.3.2.

    Strong comparison requires both tags to be strong (no leading
    ``W/``) and the opaque-tag bytes to be byte-for-byte identical.
    """

    if a.startswith("W/") or b.startswith("W/"):
        return False
    return a == b


# ---------------------------------------------------------------------------
# WebDAVServer
# ---------------------------------------------------------------------------


class WebDAVServer:
    """WSGI 1.0.1 (PEP 3333) WebDAV server (RFC 4918).

    Constructor signature::

        WebDAVServer(filesystem: VirtualFileSystem,
                     dead_property_backend: DeadPropertyBackend) -> None

    Instances are callable in the WSGI form::

        WebDAVServer.__call__(self, environ: dict,
                              start_response: typing.Callable
                              ) -> typing.Iterable[bytes]

    See the module docstring for an overview of the supported verbs and
    the architectural split between the virtual filesystem and the
    dead-property backend.
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(
        self,
        filesystem: VirtualFileSystem,
        dead_property_backend: DeadPropertyBackend,
    ) -> None:
        self._fs = filesystem
        self._dpb = dead_property_backend
        self._locks: dict[str, list[_LockRecord]] = {}
        self._locks_lock: threading.RLock = threading.RLock()

    # ------------------------------------------------------------------
    # WSGI entry point
    # ------------------------------------------------------------------

    def __call__(
        self,
        environ: dict,
        start_response: typing.Callable,
    ) -> typing.Iterable[bytes]:
        method = environ.get("REQUEST_METHOD", "")
        path = urllib.parse.unquote(environ.get("PATH_INFO", ""))

        if method not in _DISPATCH_SET:
            return self._respond_empty(
                start_response,
                "405 Method Not Allowed",
                extra_headers=[("Allow", _ALLOW_GLOBAL)],
            )

        if_value = environ.get("HTTP_IF")
        if_lists: list[_IfList] = []
        if_state_tokens: set[str] = set()
        if if_value is not None:
            if_lists = _parse_if_header(if_value, path)
            for lst in if_lists:
                for cond in lst.conditions:
                    if cond.is_state_token:
                        if_state_tokens.add(cond.value)

            if method in _MUTATING_METHODS:
                if not self._evaluate_if(if_lists):
                    return self._respond_empty(
                        start_response, "412 Precondition Failed",
                    )

        if method == "OPTIONS":
            return self._handle_options(start_response)
        if method == "GET":
            return self._handle_get(start_response, path, include_body=True)
        if method == "HEAD":
            return self._handle_get(start_response, path, include_body=False)
        if method == "PUT":
            return self._handle_put(
                environ, start_response, path, if_state_tokens,
            )
        if method == "DELETE":
            return self._handle_delete(
                start_response, path, if_state_tokens,
            )
        if method == "MKCOL":
            return self._handle_mkcol(
                environ, start_response, path, if_state_tokens,
            )
        if method == "COPY":
            return self._handle_copy(
                environ, start_response, path, if_state_tokens,
            )
        if method == "MOVE":
            return self._handle_move(
                environ, start_response, path, if_state_tokens,
            )
        if method == "PROPFIND":
            return self._handle_propfind(environ, start_response, path)
        if method == "PROPPATCH":
            return self._handle_proppatch(
                environ, start_response, path, if_state_tokens,
            )
        if method == "LOCK":
            return self._handle_lock(
                environ, start_response, path, if_state_tokens,
            )
        if method == "UNLOCK":
            return self._handle_unlock(environ, start_response, path)

        return self._respond_empty(
            start_response,
            "405 Method Not Allowed",
            extra_headers=[("Allow", _ALLOW_GLOBAL)],
        )

    # ==================================================================
    # Response helpers
    # ==================================================================

    @staticmethod
    def _respond_empty(
        start_response: typing.Callable,
        status: str,
        extra_headers: typing.Optional[list[tuple[str, str]]] = None,
    ) -> typing.Iterable[bytes]:
        """Return a no-body response carrying ``Content-Length: 0``."""

        headers: list[tuple[str, str]] = list(extra_headers or [])
        headers.append(("Content-Length", "0"))
        start_response(status, headers)
        return [b""]

    @staticmethod
    def _respond_with_body(
        start_response: typing.Callable,
        status: str,
        body: bytes,
        extra_headers: typing.Optional[list[tuple[str, str]]] = None,
    ) -> typing.Iterable[bytes]:
        """Return a response with ``body`` and computed ``Content-Length``."""

        headers: list[tuple[str, str]] = list(extra_headers or [])
        headers.append(("Content-Length", str(len(body))))
        start_response(status, headers)
        return [body]

    # ==================================================================
    # Lock store helpers
    # ==================================================================

    def _all_active_locks(self) -> list[_LockRecord]:
        """Return every active (non-expired) lock record across all paths."""

        now = _utcnow()
        out: list[_LockRecord] = []
        with self._locks_lock:
            for records in self._locks.values():
                for record in records:
                    if record.expires_at > now:
                        out.append(record)
        return out

    def _active_locks_at_anchor(self, anchor: str) -> list[_LockRecord]:
        """Return active lock records whose anchor equals ``anchor``."""

        now = _utcnow()
        with self._locks_lock:
            return [
                r for r in self._locks.get(anchor, ())
                if r.expires_at > now
            ]

    def _active_locks_locking_path(
        self, path: str,
    ) -> list[_LockRecord]:
        """Return active lock records that ``lock`` ``path`` per Req 18."""

        return [
            lock for lock in self._all_active_locks()
            if self._lock_locks_path(lock, path)
        ]

    @staticmethod
    def _lock_locks_path(lock: _LockRecord, path: str) -> bool:
        """``True`` when ``lock`` locks ``path`` per requirement 18.

        An active lock locks every path equal to its anchor. An active
        lock with depth infinity additionally locks every descendant of
        the anchor.
        """

        if lock.anchor_path == path:
            return True
        if lock.depth == _LockDepth.INFINITY.value:
            return _is_strict_descendant(path, lock.anchor_path)
        return False

    def _store_lock(self, record: _LockRecord) -> None:
        """Append a new lock record, indexed by anchor path."""

        with self._locks_lock:
            self._locks.setdefault(record.anchor_path, []).append(record)

    def _remove_lock_by_token(
        self, anchor_path: str, token: str,
    ) -> bool:
        """Remove a single active lock at ``anchor_path`` by ``token``.

        Returns ``True`` when a record was removed.
        """

        now = _utcnow()
        with self._locks_lock:
            records = self._locks.get(anchor_path)
            if not records:
                return False
            for i, record in enumerate(records):
                if record.token == token and record.expires_at > now:
                    records.pop(i)
                    if not records:
                        self._locks.pop(anchor_path, None)
                    return True
            return False

    def _remove_locks_anchored_at_or_under(self, root: str) -> None:
        """Remove every lock anchored at ``root`` or its descendants.

        Implements the lock cleanup mandated by DELETE (Req 8) and MOVE
        (Req 11). Both active and expired records under the affected
        sub-tree are dropped so subsequent requests do not see stale
        anchors.
        """

        with self._locks_lock:
            for anchor in list(self._locks):
                if (
                    anchor == root
                    or _is_strict_descendant(anchor, root)
                ):
                    del self._locks[anchor]

    # ==================================================================
    # If-header evaluation (Req 17)
    # ==================================================================

    def _evaluate_if(self, if_lists: list[_IfList]) -> bool:
        """Return the overall boolean of the parsed ``If`` header.

        ``True`` when at least one parenthesized condition list across
        the parsed value evaluates to ``True`` (OR semantics across
        lists; AND semantics inside each list).
        """

        if not if_lists:
            return False
        for lst in if_lists:
            ok = True
            for cond in lst.conditions:
                if not self._evaluate_condition(cond, lst.bound_path):
                    ok = False
                    break
            if ok and lst.conditions:
                return True
        return False

    def _evaluate_condition(
        self, cond: _IfCondition, bound_path: str,
    ) -> bool:
        """Evaluate one ``If`` condition against the bound path.

        Per requirement 17, the state-token production evaluates to
        ``True`` when one active lock locks the bound path together with
        carrying a lock token text equal to the Coded-URL text. "Locks
        the bound path" follows the requirement 18 definition: an active
        lock locks every path equal to its anchor and, when its depth is
        infinity, every descendant of its anchor. Entity-tag productions
        evaluate against the resource at the bound path using strong
        comparison per RFC 9110 section 8.8.3.2.
        """

        if cond.is_state_token:
            result = any(
                lock.token == cond.value
                and self._lock_locks_path(lock, bound_path)
                for lock in self._all_active_locks()
            )
        else:
            if not self._fs.exists(bound_path):
                result = False
            else:
                info = self._fs.get_info(bound_path)
                result = (
                    bool(info.etag)
                    and _strong_etag_compare(info.etag, cond.value)
                )
        return (not result) if cond.negated else result

    # ==================================================================
    # Lock conflict enforcement (Req 18)
    # ==================================================================

    def _check_locks_unblocked(
        self,
        affected_paths: typing.Iterable[str],
        if_state_tokens: set[str],
    ) -> bool:
        """Return ``True`` when no blocking lock blocks the request.

        A blocking lock is any active lock that locks one of the
        ``affected_paths``. The request proceeds when every blocking
        lock has its token in ``if_state_tokens``.
        """

        affected_set = set(affected_paths)
        if not affected_set:
            return True
        for lock in self._all_active_locks():
            if any(self._lock_locks_path(lock, p) for p in affected_set):
                if lock.token not in if_state_tokens:
                    return False
        return True

    def _enumerate_descendants(self, path: str) -> list[str]:
        """Return every descendant path of ``path`` in document order.

        Walks the virtual filesystem via repeated invocations of
        :meth:`VirtualFileSystem.list_children` rooted at ``path``.
        Returns the empty list when the resource does not exist or is
        non-collection.
        """

        if not self._fs.exists(path):
            return []
        info = self._fs.get_info(path)
        if not info.is_collection:
            return []
        out: list[str] = []
        stack = [path]
        while stack:
            current = stack.pop()
            try:
                children = self._fs.list_children(current)
            except (FileNotFoundError, NotADirectoryError):
                continue
            for name in children:
                child_path = _join_paths(current, name)
                out.append(child_path)
                if (
                    self._fs.exists(child_path)
                    and self._fs.get_info(child_path).is_collection
                ):
                    stack.append(child_path)
        return out

    # ==================================================================
    # OPTIONS (Req 5)
    # ==================================================================

    def _handle_options(
        self, start_response: typing.Callable,
    ) -> typing.Iterable[bytes]:
        return self._respond_empty(
            start_response,
            "200 OK",
            extra_headers=[
                ("DAV", "1, 2"),
                ("Allow", _ALLOW_GLOBAL),
            ],
        )

    # ==================================================================
    # GET / HEAD (Req 6)
    # ==================================================================

    def _handle_get(
        self,
        start_response: typing.Callable,
        path: str,
        include_body: bool,
    ) -> typing.Iterable[bytes]:
        if not self._fs.exists(path):
            return self._respond_empty(start_response, "404 Not Found")
        info = self._fs.get_info(path)
        if info.is_collection:
            return self._respond_empty(
                start_response,
                "405 Method Not Allowed",
                extra_headers=[("Allow", _ALLOW_ON_COLLECTION)],
            )
        body = self._fs.read_bytes(path) if include_body else b""
        last_modified = email.utils.format_datetime(
            info.modified_at, usegmt=True,
        )
        headers: list[tuple[str, str]] = [
            ("Content-Type", info.content_type),
            ("Content-Length", str(info.content_length)),
            ("ETag", info.etag),
            ("Last-Modified", last_modified),
        ]
        start_response("200 OK", headers)
        return [body]

    # ==================================================================
    # PUT (Req 7)
    # ==================================================================

    def _handle_put(
        self,
        environ: dict,
        start_response: typing.Callable,
        path: str,
        if_state_tokens: set[str],
    ) -> typing.Iterable[bytes]:
        if self._fs.exists(path) and self._fs.get_info(path).is_collection:
            return self._respond_empty(
                start_response,
                "405 Method Not Allowed",
                extra_headers=[("Allow", _ALLOW_PUT)],
            )
        parent = _parent_path(path)
        if parent is None or not self._fs.exists(parent):
            return self._respond_empty(start_response, "409 Conflict")
        if not self._fs.get_info(parent).is_collection:
            return self._respond_empty(start_response, "409 Conflict")

        if not self._check_locks_unblocked([path], if_state_tokens):
            return self._respond_empty(start_response, "423 Locked")

        body_bytes = self._read_request_body(environ)
        content_type = environ.get("CONTENT_TYPE", "")

        existed = self._fs.exists(path)
        self._fs.write_bytes(path, body_bytes, content_type)
        info = self._fs.get_info(path)
        status = "204 No Content" if existed else "201 Created"
        return self._respond_empty(
            start_response,
            status,
            extra_headers=[("ETag", info.etag)],
        )

    # ==================================================================
    # DELETE (Req 8)
    # ==================================================================

    def _handle_delete(
        self,
        start_response: typing.Callable,
        path: str,
        if_state_tokens: set[str],
    ) -> typing.Iterable[bytes]:
        if not self._fs.exists(path):
            return self._respond_empty(start_response, "404 Not Found")

        affected = [path] + self._enumerate_descendants(path)

        if not self._check_locks_unblocked(affected, if_state_tokens):
            return self._respond_empty(start_response, "423 Locked")

        self._remove_locks_anchored_at_or_under(path)

        for affected_path in affected:
            for ns, name, _value in self._dpb.list_properties(affected_path):
                try:
                    self._dpb.remove_property(affected_path, ns, name)
                except KeyError:
                    pass

        self._fs.delete(path)
        return self._respond_empty(start_response, "204 No Content")

    # ==================================================================
    # MKCOL (Req 9)
    # ==================================================================

    def _handle_mkcol(
        self,
        environ: dict,
        start_response: typing.Callable,
        path: str,
        if_state_tokens: set[str],
    ) -> typing.Iterable[bytes]:
        body_bytes = self._read_request_body(environ)
        if body_bytes:
            return self._respond_empty(
                start_response, "415 Unsupported Media Type",
            )
        if self._fs.exists(path):
            return self._respond_empty(
                start_response,
                "405 Method Not Allowed",
                extra_headers=[("Allow", _ALLOW_MKCOL)],
            )
        parent = _parent_path(path)
        if parent is None or not self._fs.exists(parent):
            return self._respond_empty(start_response, "409 Conflict")
        if not self._fs.get_info(parent).is_collection:
            return self._respond_empty(start_response, "409 Conflict")

        if not self._check_locks_unblocked([path], if_state_tokens):
            return self._respond_empty(start_response, "423 Locked")

        self._fs.create_collection(path)
        return self._respond_empty(start_response, "201 Created")

    # ==================================================================
    # COPY (Req 10)
    # ==================================================================

    def _handle_copy(
        self,
        environ: dict,
        start_response: typing.Callable,
        path: str,
        if_state_tokens: set[str],
    ) -> typing.Iterable[bytes]:
        destination_header = environ.get("HTTP_DESTINATION")
        if destination_header is None:
            return self._respond_empty(start_response, "400 Bad Request")
        if not self._fs.exists(path):
            return self._respond_empty(start_response, "404 Not Found")

        destination = self._resolve_destination(destination_header)

        dst_parent = _parent_path(destination)
        if dst_parent is None or not self._fs.exists(dst_parent):
            return self._respond_empty(start_response, "409 Conflict")
        if not self._fs.get_info(dst_parent).is_collection:
            return self._respond_empty(start_response, "409 Conflict")

        overwrite = self._resolve_overwrite(environ)
        depth_infinity = self._resolve_copy_depth(environ)

        dest_exists = self._fs.exists(destination)
        if dest_exists and not overwrite:
            return self._respond_empty(
                start_response, "412 Precondition Failed",
            )

        if dest_exists:
            affected = (
                [destination]
                + self._enumerate_descendants(destination)
            )
        else:
            affected = [destination]

        if not self._check_locks_unblocked(affected, if_state_tokens):
            return self._respond_empty(start_response, "423 Locked")

        pair_set = self._compute_pair_set(path, destination, depth_infinity)

        if dest_exists:
            for affected_path in (
                [destination] + self._enumerate_descendants(destination)
            ):
                for ns, name, _v in self._dpb.list_properties(affected_path):
                    try:
                        self._dpb.remove_property(affected_path, ns, name)
                    except KeyError:
                        pass
            self._fs.delete(destination)

        self._fs.copy(path, destination, depth_infinity)
        self._dpb.copy_properties(path, destination)
        for src_descendant, dst_descendant in pair_set:
            self._dpb.copy_properties(src_descendant, dst_descendant)

        status = "204 No Content" if dest_exists else "201 Created"
        return self._respond_empty(start_response, status)

    # ==================================================================
    # MOVE (Req 11)
    # ==================================================================

    def _handle_move(
        self,
        environ: dict,
        start_response: typing.Callable,
        path: str,
        if_state_tokens: set[str],
    ) -> typing.Iterable[bytes]:
        destination_header = environ.get("HTTP_DESTINATION")
        if destination_header is None:
            return self._respond_empty(start_response, "400 Bad Request")
        if not self._fs.exists(path):
            return self._respond_empty(start_response, "404 Not Found")

        destination = self._resolve_destination(destination_header)
        dst_parent = _parent_path(destination)
        if dst_parent is None or not self._fs.exists(dst_parent):
            return self._respond_empty(start_response, "409 Conflict")
        if not self._fs.get_info(dst_parent).is_collection:
            return self._respond_empty(start_response, "409 Conflict")

        overwrite = self._resolve_overwrite(environ)
        dest_exists = self._fs.exists(destination)
        if dest_exists and not overwrite:
            return self._respond_empty(
                start_response, "412 Precondition Failed",
            )

        affected = [path] + self._enumerate_descendants(path) + [destination]
        if dest_exists:
            affected += self._enumerate_descendants(destination)
        if not self._check_locks_unblocked(affected, if_state_tokens):
            return self._respond_empty(start_response, "423 Locked")

        pair_set = self._compute_pair_set(path, destination, True)

        self._remove_locks_anchored_at_or_under(path)

        if dest_exists:
            for affected_path in (
                [destination] + self._enumerate_descendants(destination)
            ):
                for ns, name, _v in self._dpb.list_properties(affected_path):
                    try:
                        self._dpb.remove_property(affected_path, ns, name)
                    except KeyError:
                        pass
            self._fs.delete(destination)

        self._fs.move(path, destination)
        self._dpb.move_properties(path, destination)
        for src_descendant, dst_descendant in pair_set:
            self._dpb.move_properties(src_descendant, dst_descendant)

        status = "204 No Content" if dest_exists else "201 Created"
        return self._respond_empty(start_response, status)

    # ==================================================================
    # PROPFIND (Req 12 + Req 13)
    # ==================================================================

    def _handle_propfind(
        self,
        environ: dict,
        start_response: typing.Callable,
        path: str,
    ) -> typing.Iterable[bytes]:
        if not self._fs.exists(path):
            return self._respond_empty(start_response, "404 Not Found")

        depth_mode = self._resolve_propfind_depth(environ)
        body_bytes = self._read_request_body(environ)
        production = self._parse_propfind_body(body_bytes)

        info = self._fs.get_info(path)
        response_set: list[str] = [path]
        if info.is_collection:
            if depth_mode == "1":
                response_set.extend(self._immediate_children(path))
            elif depth_mode == "infinity":
                response_set.extend(self._enumerate_descendants(path))

        body = self._build_propfind_response(response_set, production)
        return self._respond_with_body(
            start_response,
            "207 Multi-Status",
            body,
            extra_headers=[
                ("Content-Type", "application/xml; charset=utf-8"),
            ],
        )

    def _immediate_children(self, path: str) -> list[str]:
        try:
            names = self._fs.list_children(path)
        except (FileNotFoundError, NotADirectoryError):
            return []
        return [_join_paths(path, n) for n in names]

    def _parse_propfind_body(
        self, body_bytes: bytes,
    ) -> tuple[str, list[tuple[str, str]]]:
        """Classify the PROPFIND request body into one of three productions.

        Returns one of:

        * ``("allprop", [])``
        * ``("propname", [])``
        * ``("prop", [(namespace, name), ...])``
        """

        if not body_bytes or not body_bytes.strip():
            return ("allprop", [])
        try:
            root = ET.fromstring(body_bytes)
        except ET.ParseError:
            return ("allprop", [])
        for child in root:
            if child.tag == "{DAV:}allprop":
                return ("allprop", [])
            if child.tag == "{DAV:}propname":
                return ("propname", [])
            if child.tag == "{DAV:}prop":
                requested: list[tuple[str, str]] = []
                for prop_el in child:
                    ns, name = _parse_clark_name(prop_el.tag)
                    requested.append((ns, name))
                return ("prop", requested)
        return ("allprop", [])

    def _build_propfind_response(
        self,
        response_set: list[str],
        production: tuple[str, list[tuple[str, str]]],
    ) -> bytes:
        production_kind, requested_props = production
        parts: list[str] = [
            '<?xml version="1.0" encoding="utf-8"?>',
            '<D:multistatus xmlns:D="DAV:">',
        ]
        for resource_path in response_set:
            parts.append(
                self._build_propfind_resource(
                    resource_path, production_kind, requested_props,
                )
            )
        parts.append("</D:multistatus>")
        return "".join(parts).encode("utf-8")

    def _build_propfind_resource(
        self,
        resource_path: str,
        production_kind: str,
        requested_props: list[tuple[str, str]],
    ) -> str:
        info = self._fs.get_info(resource_path)
        href = urllib.parse.quote(resource_path)
        out = [
            "<D:response>",
            f"<D:href>{_xml_text_escape(href)}</D:href>",
        ]

        if production_kind == "allprop":
            success: list[str] = []
            for live_name in _LIVE_PROPERTY_NAMES:
                success.append(
                    self._build_live_property(live_name, info, resource_path)
                )
            for ns, name, xml_value in self._dpb.list_properties(
                resource_path,
            ):
                success.append(
                    self._build_property_element(ns, name, xml_value)
                )
            out.append(self._build_propstat(success, "HTTP/1.1 200 OK"))
        elif production_kind == "propname":
            success = []
            for live_name in _LIVE_PROPERTY_NAMES:
                success.append(f"<D:{live_name}/>")
            for ns, name, _value in self._dpb.list_properties(resource_path):
                success.append(self._build_property_element(ns, name, ""))
            out.append(self._build_propstat(success, "HTTP/1.1 200 OK"))
        else:
            success = []
            absent: list[str] = []
            for ns, name in requested_props:
                if ns == _DAV_NS and name in _LIVE_PROPERTY_SET:
                    success.append(
                        self._build_live_property(name, info, resource_path)
                    )
                else:
                    try:
                        xml_value = self._dpb.get_property(
                            resource_path, ns, name,
                        )
                    except KeyError:
                        absent.append(
                            self._build_property_element(ns, name, "")
                        )
                    else:
                        success.append(
                            self._build_property_element(ns, name, xml_value)
                        )
            if success:
                out.append(self._build_propstat(success, "HTTP/1.1 200 OK"))
            if absent:
                out.append(
                    self._build_propstat(absent, "HTTP/1.1 404 Not Found")
                )

        out.append("</D:response>")
        return "".join(out)

    @staticmethod
    def _build_propstat(props: list[str], status: str) -> str:
        return (
            "<D:propstat><D:prop>"
            + "".join(props)
            + f"</D:prop><D:status>{status}</D:status></D:propstat>"
        )

    def _build_live_property(
        self,
        name: str,
        info: ResourceInfo,
        resource_path: str,
    ) -> str:
        """Build the XML for one live property element per requirement 13."""

        if name == "creationdate":
            text = info.created_at.strftime("%Y-%m-%dT%H:%M:%SZ")
            return f"<D:creationdate>{_xml_text_escape(text)}</D:creationdate>"
        if name == "displayname":
            text = info.display_name
            return (
                "<D:displayname>"
                + _xml_text_escape(text)
                + "</D:displayname>"
            )
        if name == "getcontentlength":
            return (
                "<D:getcontentlength>"
                + str(info.content_length)
                + "</D:getcontentlength>"
            )
        if name == "getcontenttype":
            return (
                "<D:getcontenttype>"
                + _xml_text_escape(info.content_type)
                + "</D:getcontenttype>"
            )
        if name == "getetag":
            return (
                "<D:getetag>"
                + _xml_text_escape(info.etag)
                + "</D:getetag>"
            )
        if name == "getlastmodified":
            text = email.utils.format_datetime(info.modified_at, usegmt=True)
            return (
                "<D:getlastmodified>"
                + _xml_text_escape(text)
                + "</D:getlastmodified>"
            )
        if name == "resourcetype":
            if info.is_collection:
                return "<D:resourcetype><D:collection/></D:resourcetype>"
            return "<D:resourcetype/>"
        if name == "supportedlock":
            return (
                "<D:supportedlock>"
                "<D:lockentry>"
                "<D:lockscope><D:exclusive/></D:lockscope>"
                "<D:locktype><D:write/></D:locktype>"
                "</D:lockentry>"
                "<D:lockentry>"
                "<D:lockscope><D:shared/></D:lockscope>"
                "<D:locktype><D:write/></D:locktype>"
                "</D:lockentry>"
                "</D:supportedlock>"
            )
        if name == "lockdiscovery":
            return (
                "<D:lockdiscovery>"
                + self._build_lockdiscovery_inner(resource_path)
                + "</D:lockdiscovery>"
            )
        return f"<D:{name}/>"

    def _build_lockdiscovery_inner(self, resource_path: str) -> str:
        """Build the inner XML of ``<D:lockdiscovery>`` for ``resource_path``.

        Lists every active lock that locks ``resource_path`` per Req 18,
        i.e. locks anchored at the path together with depth-infinity
        locks anchored at any ancestor.
        """

        locks = sorted(
            self._active_locks_locking_path(resource_path),
            key=lambda lock: lock.token,
        )
        return "".join(self._build_activelock(lock) for lock in locks)

    def _build_activelock(self, lock: _LockRecord) -> str:
        """Build a single ``<D:activelock>`` XML fragment."""

        scope = (
            "<D:exclusive/>"
            if lock.scope == _LockScope.EXCLUSIVE.value
            else "<D:shared/>"
        )
        depth_text = "0" if lock.depth == _LockDepth.ZERO.value else "infinity"
        remaining = max(
            0,
            int((lock.expires_at - _utcnow()).total_seconds()),
        )
        timeout_text = f"Second-{remaining}"
        lock_root_href = urllib.parse.quote(lock.anchor_path)
        return (
            "<D:activelock>"
            "<D:locktype><D:write/></D:locktype>"
            f"<D:lockscope>{scope}</D:lockscope>"
            f"<D:depth>{depth_text}</D:depth>"
            f"<D:owner>{lock.owner_xml}</D:owner>"
            f"<D:timeout>{timeout_text}</D:timeout>"
            "<D:locktoken><D:href>"
            + _xml_text_escape(lock.token)
            + "</D:href></D:locktoken>"
            "<D:lockroot><D:href>"
            + _xml_text_escape(lock_root_href)
            + "</D:href></D:lockroot>"
            "</D:activelock>"
        )

    @staticmethod
    def _build_property_element(
        namespace: str, name: str, inner_xml: str,
    ) -> str:
        """Build an XML element carrying a property of arbitrary namespace.

        Properties in the ``DAV:`` namespace reuse the ``D`` prefix
        already declared on the multistatus root. Properties in any
        other namespace declare a locally scoped ``x`` prefix that
        cannot collide with the ``D`` prefix or with prefixes used
        inside the embedded ``inner_xml``.
        """

        if namespace == _DAV_NS:
            if inner_xml:
                return f"<D:{name}>{inner_xml}</D:{name}>"
            return f"<D:{name}/>"
        ns_attr = _xml_attr_escape(namespace)
        if inner_xml:
            return (
                f'<x:{name} xmlns:x="{ns_attr}">{inner_xml}</x:{name}>'
            )
        return f'<x:{name} xmlns:x="{ns_attr}"/>'

    # ==================================================================
    # PROPPATCH (Req 14)
    # ==================================================================

    def _handle_proppatch(
        self,
        environ: dict,
        start_response: typing.Callable,
        path: str,
        if_state_tokens: set[str],
    ) -> typing.Iterable[bytes]:
        if not self._fs.exists(path):
            return self._respond_empty(start_response, "404 Not Found")

        if not self._check_locks_unblocked([path], if_state_tokens):
            return self._respond_empty(start_response, "423 Locked")

        body_bytes = self._read_request_body(environ)
        instructions = self._parse_proppatch_body(body_bytes)

        live_rejected: list[tuple[str, str]] = []
        dead_targets: list[tuple[str, str, str, typing.Optional[str]]] = []
        for action, namespace, name, inner in instructions:
            is_live = (
                namespace == _DAV_NS and name in _LIVE_PROPERTY_SET
            )
            if is_live:
                live_rejected.append((namespace, name))
            else:
                dead_targets.append((action, namespace, name, inner))

        success: list[tuple[str, str]] = []
        dependency: list[tuple[str, str]] = []

        if live_rejected:
            for action, namespace, name, _inner in dead_targets:
                dependency.append((namespace, name))
        else:
            for action, namespace, name, inner in dead_targets:
                if action == "set":
                    self._dpb.set_property(path, namespace, name, inner or "")
                else:
                    try:
                        self._dpb.remove_property(path, namespace, name)
                    except KeyError:
                        pass
                success.append((namespace, name))

        body = self._build_proppatch_response(
            path, success, live_rejected, dependency,
        )
        return self._respond_with_body(
            start_response,
            "207 Multi-Status",
            body,
            extra_headers=[
                ("Content-Type", "application/xml; charset=utf-8"),
            ],
        )

    @staticmethod
    def _parse_proppatch_body(
        body_bytes: bytes,
    ) -> list[tuple[str, str, str, typing.Optional[str]]]:
        """Classify a PROPPATCH body into ordered (action, ns, name, inner).

        ``action`` is ``"set"`` or ``"remove"``. ``inner`` is the
        canonical XML serialisation of the inner content of each
        property element under a ``set`` instruction; it is ``None``
        for ``remove`` instructions.
        """

        if not body_bytes:
            return []
        try:
            root = ET.fromstring(body_bytes)
        except ET.ParseError:
            return []
        out: list[tuple[str, str, str, typing.Optional[str]]] = []
        for child in root:
            if child.tag == "{DAV:}set":
                prop = child.find("{DAV:}prop")
                if prop is None:
                    continue
                for prop_el in prop:
                    ns, name = _parse_clark_name(prop_el.tag)
                    out.append(
                        (
                            "set",
                            ns,
                            name,
                            _serialize_inner_xml_canonical(prop_el),
                        )
                    )
            elif child.tag == "{DAV:}remove":
                prop = child.find("{DAV:}prop")
                if prop is None:
                    continue
                for prop_el in prop:
                    ns, name = _parse_clark_name(prop_el.tag)
                    out.append(("remove", ns, name, None))
        return out

    def _build_proppatch_response(
        self,
        path: str,
        success: list[tuple[str, str]],
        rejected: list[tuple[str, str]],
        dependency: list[tuple[str, str]],
    ) -> bytes:
        href = urllib.parse.quote(path)
        out = [
            '<?xml version="1.0" encoding="utf-8"?>',
            '<D:multistatus xmlns:D="DAV:">',
            "<D:response>",
            f"<D:href>{_xml_text_escape(href)}</D:href>",
        ]
        if success:
            elements = [
                self._build_property_element(ns, name, "")
                for ns, name in success
            ]
            out.append(self._build_propstat(elements, "HTTP/1.1 200 OK"))
        if rejected:
            elements = [
                self._build_property_element(ns, name, "")
                for ns, name in rejected
            ]
            out.append(
                self._build_propstat(elements, "HTTP/1.1 403 Forbidden")
            )
        if dependency:
            elements = [
                self._build_property_element(ns, name, "")
                for ns, name in dependency
            ]
            out.append(
                self._build_propstat(
                    elements, "HTTP/1.1 424 Failed Dependency",
                )
            )
        out.append("</D:response>")
        out.append("</D:multistatus>")
        return "".join(out).encode("utf-8")

    # ==================================================================
    # LOCK (Req 15)
    # ==================================================================

    def _handle_lock(
        self,
        environ: dict,
        start_response: typing.Callable,
        path: str,
        if_state_tokens: set[str],
    ) -> typing.Iterable[bytes]:
        depth_mode = self._resolve_lock_depth(environ)
        timeout_seconds = self._resolve_timeout(environ)
        body_bytes = self._read_request_body(environ)

        if not body_bytes:
            return self._handle_lock_refresh(
                start_response, path, timeout_seconds, if_state_tokens,
            )
        return self._handle_lock_acquire(
            start_response, path, depth_mode, timeout_seconds, body_bytes,
        )

    def _handle_lock_refresh(
        self,
        start_response: typing.Callable,
        path: str,
        timeout_seconds: int,
        if_state_tokens: set[str],
    ) -> typing.Iterable[bytes]:
        active_at_path = self._active_locks_at_anchor(path)
        matching = [l for l in active_at_path if l.token in if_state_tokens]
        if not matching:
            return self._respond_empty(
                start_response, "412 Precondition Failed",
            )
        new_expiry = _utcnow() + datetime.timedelta(seconds=timeout_seconds)
        with self._locks_lock:
            for lock in matching:
                lock.expires_at = new_expiry
        body = self._build_lock_response_body(path)
        return self._respond_with_body(
            start_response,
            "200 OK",
            body,
            extra_headers=[
                ("Content-Type", "application/xml; charset=utf-8"),
            ],
        )

    def _handle_lock_acquire(
        self,
        start_response: typing.Callable,
        path: str,
        depth_mode: str,
        timeout_seconds: int,
        body_bytes: bytes,
    ) -> typing.Iterable[bytes]:
        try:
            root = ET.fromstring(body_bytes)
        except ET.ParseError:
            return self._respond_empty(start_response, "400 Bad Request")

        scope = self._extract_lock_scope(root)
        owner_xml = self._extract_lock_owner(root)

        active_locks = self._all_active_locks()

        def _conflicts(existing: _LockRecord, required_scope: str) -> bool:
            """Determine whether ``existing`` blocks a new lock at ``path``.

            Per requirement 15 conditions 1 and 2 the test is purely
            structural: any active lock of the relevant scope that locks
            the request path (anchor equals the request path or, when
            the existing lock has depth infinity, the request path is a
            descendant of the anchor) conflicts. Owner identity is not a
            factor in requirement 15.
            """

            if existing.scope != required_scope:
                return False
            return self._lock_locks_path(existing, path)

        if any(
            _conflicts(l, _LockScope.EXCLUSIVE.value) for l in active_locks
        ):
            return self._respond_empty(start_response, "423 Locked")
        if scope == _LockScope.EXCLUSIVE.value and any(
            _conflicts(l, _LockScope.SHARED.value) for l in active_locks
        ):
            return self._respond_empty(start_response, "423 Locked")
        if depth_mode == _LockDepth.INFINITY.value and self._fs.exists(path):
            info = self._fs.get_info(path)
            if info.is_collection:
                if any(
                    _is_strict_descendant(l.anchor_path, path)
                    for l in active_locks
                ):
                    return self._respond_empty(start_response, "423 Locked")

        if not self._fs.exists(path):
            self._fs.write_bytes(path, b"", "application/octet-stream")

        token = "urn:uuid:" + str(uuid.uuid4())
        record = _LockRecord(
            scope=scope,
            depth=depth_mode,
            timeout_seconds=timeout_seconds,
            owner_xml=owner_xml,
            token=token,
            anchor_path=path,
            expires_at=(
                _utcnow() + datetime.timedelta(seconds=timeout_seconds)
            ),
        )
        self._store_lock(record)

        body = self._build_lock_response_body(path)
        return self._respond_with_body(
            start_response,
            "200 OK",
            body,
            extra_headers=[
                ("Lock-Token", f"<{token}>"),
                ("Content-Type", "application/xml; charset=utf-8"),
            ],
        )

    @staticmethod
    def _extract_lock_scope(root: ET.Element) -> str:
        scope_el = root.find("{DAV:}lockscope")
        if scope_el is not None:
            for child in scope_el:
                ns, name = _parse_clark_name(child.tag)
                if ns == _DAV_NS and name == "exclusive":
                    return _LockScope.EXCLUSIVE.value
                if ns == _DAV_NS and name == "shared":
                    return _LockScope.SHARED.value
        return _LockScope.EXCLUSIVE.value

    @staticmethod
    def _extract_lock_owner(root: ET.Element) -> str:
        owner_el = root.find("{DAV:}owner")
        if owner_el is None:
            return ""
        return _serialize_inner_xml_verbatim(owner_el)

    def _build_lock_response_body(self, path: str) -> bytes:
        return (
            '<?xml version="1.0" encoding="utf-8"?>'
            '<D:prop xmlns:D="DAV:"><D:lockdiscovery>'
            + self._build_lockdiscovery_inner(path)
            + "</D:lockdiscovery></D:prop>"
        ).encode("utf-8")

    # ==================================================================
    # UNLOCK (Req 16)
    # ==================================================================

    def _handle_unlock(
        self,
        environ: dict,
        start_response: typing.Callable,
        path: str,
    ) -> typing.Iterable[bytes]:
        raw_token_header = environ.get("HTTP_LOCK_TOKEN")
        if raw_token_header is None:
            return self._respond_empty(start_response, "400 Bad Request")

        if not (
            len(raw_token_header) >= 2
            and raw_token_header.startswith("<")
            and raw_token_header.endswith(">")
        ):
            return self._respond_empty(start_response, "409 Conflict")
        token = raw_token_header[1:-1]
        if self._remove_lock_by_token(path, token):
            return self._respond_empty(start_response, "204 No Content")
        return self._respond_empty(start_response, "409 Conflict")

    # ==================================================================
    # Header helpers
    # ==================================================================

    @staticmethod
    def _read_request_body(environ: dict) -> bytes:
        try:
            length = int(environ.get("CONTENT_LENGTH") or 0)
        except (TypeError, ValueError):
            length = 0
        if length <= 0:
            return b""
        stream = environ.get("wsgi.input")
        if stream is None:
            return b""
        return stream.read(length) or b""

    @staticmethod
    def _resolve_destination(value: str) -> str:
        parts = urllib.parse.urlsplit(value)
        return urllib.parse.unquote(parts.path)

    @staticmethod
    def _resolve_overwrite(environ: dict) -> bool:
        raw = environ.get("HTTP_OVERWRITE")
        if raw is None:
            return True
        return raw == "T"

    @staticmethod
    def _resolve_copy_depth(environ: dict) -> bool:
        raw = environ.get("HTTP_DEPTH")
        if raw is None:
            return True
        if raw == "0":
            return False
        return True

    @staticmethod
    def _resolve_propfind_depth(environ: dict) -> str:
        raw = environ.get("HTTP_DEPTH")
        if raw is None:
            return "infinity"
        if raw == "0":
            return "0"
        if raw == "1":
            return "1"
        return "infinity"

    @staticmethod
    def _resolve_lock_depth(environ: dict) -> str:
        raw = environ.get("HTTP_DEPTH")
        if raw is None:
            return _LockDepth.INFINITY.value
        if raw == "0":
            return _LockDepth.ZERO.value
        return _LockDepth.INFINITY.value

    @staticmethod
    def _resolve_timeout(environ: dict) -> int:
        raw = environ.get("HTTP_TIMEOUT")
        if raw is None:
            return 600
        for piece in raw.split(","):
            token = piece.strip()
            if token == "Infinite":
                return 3600
            match = re.fullmatch(r"Second-(\d+)", token)
            if match:
                requested = int(match.group(1))
                return min(requested, 3600)
        return 600

    # ==================================================================
    # COPY/MOVE pair set
    # ==================================================================

    def _compute_pair_set(
        self,
        source: str,
        destination: str,
        depth_infinity: bool,
    ) -> list[tuple[str, str]]:
        """Compute the source-descendant pair set per Req 10 / Req 11.

        Returns one ``(source_descendant_path,
        destination_descendant_path)`` tuple per descendant of
        ``source``. The set is empty when the source resource is
        non-collection or when ``depth_infinity`` is ``False``.
        """

        if not depth_infinity:
            return []
        if not self._fs.exists(source):
            return []
        info = self._fs.get_info(source)
        if not info.is_collection:
            return []
        out: list[tuple[str, str]] = []
        for descendant in self._enumerate_descendants(source):
            if source == "/":
                rel = descendant[1:]
                dst = _join_paths(destination, rel) if rel else destination
            else:
                rel = descendant[len(source) + 1:]
                dst = (
                    _join_paths(destination, rel) if rel else destination
                )
            out.append((descendant, dst))
        return out


__all__ = [
    "DeadPropertyBackend",
    "ResourceInfo",
    "VirtualFileSystem",
    "WebDAVServer",
]