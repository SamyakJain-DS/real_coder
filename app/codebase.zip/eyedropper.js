export function getPixelColorAt(canvas, x, y) {
  const context = canvas.getContext("2d");
  const pixelX = Math.floor(x);
  const pixelY = Math.floor(y);
  const imageData = context.getImageData(pixelX, pixelY, 1, 1);
  return {
    r: imageData.data[0],
    g: imageData.data[1],
    b: imageData.data[2],
    a: imageData.data[3],
  };
}

export function findClosestColors(target, palette, count) {
  if (count < 0) {
    throw new RangeError("Invalid count");
  }
  if (count === 0) {
    return [];
  }

  const ranked = palette.map((entry, index) => {
    const dr = target.r - entry.r;
    const dg = target.g - entry.g;
    const db = target.b - entry.b;
    return {
      entry,
      index,
      distance: Math.sqrt(dr * dr + dg * dg + db * db),
    };
  });

  ranked.sort((a, b) => {
    if (a.distance !== b.distance) {
      return a.distance - b.distance;
    }
    return a.index - b.index;
  });

  const limit = Math.min(count, ranked.length);
  const result = [];
  for (let i = 0; i < limit; i++) {
    result.push(ranked[i].entry);
  }
  return result;
}
