"""
pipeline/migration_analyzer.py

Identifies peak migration week and season window for each obligate migrant
bat species using ISO calendar week numbers.
"""

import pandas as pd

OBLIGATE_MIGRANTS = [
    "Lasiurus borealis",
    "Lasiurus cinereus",
    "Lasionycteris noctivagans",
]


def identify_migration_timing(
    classifications_df: pd.DataFrame,
    weather_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Determine migration peak week and season boundaries for obligate migrants.

    Precipitation Filter
    --------------------
    All records for nights where ``precipitation > 0.0`` are excluded before
    any aggregation.

    Lunar Phase Filter
    ------------------
    After the precipitation filter, records for nights where
    ``lunar_phase > 0.5`` are additionally excluded.

    Weekly means are computed only over nights that pass both filters.

    Peak migration week  – ISO week with the highest mean ``classified_count``.
    Season start week    – Lowest ISO week where mean ≥ 10 % of peak mean.
    Season end week      – Highest ISO week where mean ≥ 10 % of peak mean.

    Parameters
    ----------
    classifications_df : pd.DataFrame
        Columns: [site_id, date, species, classified_count]
    weather_df : pd.DataFrame
        Columns: [date, temperature, wind_speed, precipitation, lunar_phase]

    Returns
    -------
    pd.DataFrame
        Columns: [species, peak_week, season_start_week, season_end_week]
        One row per obligate migrant species.
        Week values are ISO calendar week integers.
    """
    # ── 1. Precipitation filter ───────────────────────────────────────────────
    rainy_dates = weather_df.loc[weather_df["precipitation"] > 0.0, "date"].unique()
    filtered = classifications_df[~classifications_df["date"].isin(rainy_dates)].copy()

    # ── 2. Lunar phase filter ─────────────────────────────────────────────────
    high_lunar_dates = weather_df.loc[weather_df["lunar_phase"] > 0.5, "date"].unique()
    filtered = filtered[~filtered["date"].isin(high_lunar_dates)].copy()

    # ── 3. Keep only obligate migrant species ─────────────────────────────────
    filtered = filtered[filtered["species"].isin(OBLIGATE_MIGRANTS)].copy()

    # ── 4. Derive ISO calendar week from date (aggregated across all years) ───
    filtered["date"] = pd.to_datetime(filtered["date"])
    filtered["iso_week"] = filtered["date"].dt.isocalendar().week.astype(int)

    # ── 5. Compute per-species peak and season window ─────────────────────────
    rows = []
    for species in OBLIGATE_MIGRANTS:
        sp_data = filtered[filtered["species"] == species]

        # Mean classified_count per ISO week (across all years and all sites)
        weekly_mean = sp_data.groupby("iso_week")["classified_count"].mean()

        peak_mean = weekly_mean.max()
        threshold = 0.10 * peak_mean

        peak_week = int(weekly_mean.idxmax())

        active_weeks = weekly_mean[weekly_mean >= threshold].index
        season_start_week = int(active_weeks.min())
        season_end_week = int(active_weeks.max())

        rows.append(
            {
                "species": species,
                "peak_week": peak_week,
                "season_start_week": season_start_week,
                "season_end_week": season_end_week,
            }
        )

    return pd.DataFrame(rows)
