"""
pipeline/data_loader.py

Reads the four acoustic-monitoring CSV files from a local directory and
returns them as a tuple of pandas DataFrames.
"""

import os
import pandas as pd


def load_data(data_dir: str) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Read the four CSV files from *data_dir* and return them as a tuple.

    Parameters
    ----------
    data_dir : str
        Path to the directory that contains the four CSV files.

    Returns
    -------
    tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]
        (activity_df, classifications_df, habitat_df, weather_df)

        * activity_df        – columns: [site_id, date, nightly_count]
        * classifications_df – columns: [site_id, date, species, classified_count]
        * habitat_df         – columns: [site_id, habitat, region]
        * weather_df         – columns: [date, temperature, wind_speed,
                                          precipitation, lunar_phase]
    """
    activity_df = pd.read_csv(
        os.path.join(data_dir, "activity.csv"),
        dtype={"site_id": str, "date": str, "nightly_count": int},
    )

    classifications_df = pd.read_csv(
        os.path.join(data_dir, "classifications.csv"),
        dtype={"site_id": str, "date": str, "species": str, "classified_count": int},
    )

    habitat_df = pd.read_csv(
        os.path.join(data_dir, "habitat.csv"),
        dtype={"site_id": str, "habitat": str, "region": str},
    )

    weather_df = pd.read_csv(
        os.path.join(data_dir, "weather.csv"),
        dtype={
            "date": str,
            "temperature": float,
            "wind_speed": float,
            "precipitation": float,
            "lunar_phase": float,
        },
    )

    return activity_df, classifications_df, habitat_df, weather_df
