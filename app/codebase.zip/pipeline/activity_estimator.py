"""
pipeline/activity_estimator.py

Estimates per-species per-habitat per-region activity rates corrected for
per-site detector sensitivity and nights with precipitation.
"""

import pandas as pd


def estimate_activity_rates(
    activity_df: pd.DataFrame,
    classifications_df: pd.DataFrame,
    habitat_df: pd.DataFrame,
    weather_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Derive sensitivity-corrected mean nightly classification rates.

    Sensitivity Factor Derivation
    ------------------------------
    The per-site sensitivity factor is the ratio of that site's mean nightly
    ``nightly_count`` (averaged across all dates for that site) to the global
    mean nightly ``nightly_count`` (averaged across all sites and all dates).
    It is computed entirely from *activity_df*; no external file is used.

    Precipitation Filter
    --------------------
    All records for nights where ``precipitation > 0.0`` are excluded before
    any aggregation is performed.

    Parameters
    ----------
    activity_df : pd.DataFrame
        Raw nightly detection counts per site per night.
        Columns: [site_id, date, nightly_count]
    classifications_df : pd.DataFrame
        Per-species classified counts per site per night.
        Columns: [site_id, date, species, classified_count]
    habitat_df : pd.DataFrame
        Habitat category and region per site.
        Columns: [site_id, habitat, region]
    weather_df : pd.DataFrame
        Nightly environmental context.
        Columns: [date, temperature, wind_speed, precipitation, lunar_phase]

    Returns
    -------
    pd.DataFrame
        Columns: [species, habitat, region, corrected_mean_nightly_rate]
        One row per (species, habitat, region) combination.
    """
    # ── 1. Derive per-site sensitivity factors from activity_df ───────────────
    site_mean_count = activity_df.groupby("site_id")["nightly_count"].mean()
    global_mean_count = activity_df["nightly_count"].mean()
    sensitivity_factor = (site_mean_count / global_mean_count).rename("sensitivity_factor").reset_index()
    # sensitivity_factor columns: [site_id, sensitivity_factor]

    # ── 2. Apply precipitation filter to classifications_df ───────────────────
    rainy_dates = weather_df.loc[weather_df["precipitation"] > 0.0, "date"].unique()
    filtered_cls = classifications_df[~classifications_df["date"].isin(rainy_dates)].copy()

    # ── 3. Join sensitivity factor onto filtered classifications ──────────────
    filtered_cls = filtered_cls.merge(sensitivity_factor, on="site_id", how="left")

    # ── 4. Compute sensitivity-corrected classified count per row ─────────────
    filtered_cls["corrected_count"] = (
        filtered_cls["classified_count"] / filtered_cls["sensitivity_factor"]
    )

    # ── 5. Join habitat information (habitat + region) ────────────────────────
    filtered_cls = filtered_cls.merge(habitat_df, on="site_id", how="left")

    # ── 6. Group by species / habitat / region and compute mean ───────────────
    result = (
        filtered_cls
        .groupby(["species", "habitat", "region"], sort=False)["corrected_count"]
        .mean()
        .reset_index()
        .rename(columns={"corrected_count": "corrected_mean_nightly_rate"})
    )

    return result
