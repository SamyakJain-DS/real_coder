"""
pipeline/wns_modeler.py

Models the impact of white-nose syndrome (WNS) on susceptible cave-roosting
bat species by tracking year-over-year changes in mean nightly detection counts.
"""

import pandas as pd

SUSCEPTIBLE_SPECIES = [
    "Myotis lucifugus",
    "Myotis septentrionalis",
    "Perimyotis subflavus",
]


def model_wns_impact(
    classifications_df: pd.DataFrame,
    weather_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Compute year-over-year WNS impact for each susceptible cave-roosting species.

    Precipitation Filter
    --------------------
    All records for nights where ``precipitation > 0.0`` are excluded before
    any aggregation.

    Impact Classification (based on percent change in the final year)
    -----------------------------------------------------------------
    * ``"Severe"``   – percent change ≤ -50.0
    * ``"Moderate"`` – -50.0 < percent change ≤ -25.0
    * ``"None"``     – percent change > -25.0

    The ``impact_classification`` value is the same for every row belonging to
    the same species.

    Parameters
    ----------
    classifications_df : pd.DataFrame
        Columns: [site_id, date, species, classified_count]
    weather_df : pd.DataFrame
        Columns: [date, temperature, wind_speed, precipitation, lunar_phase]

    Returns
    -------
    pd.DataFrame
        Columns: [species, year, mean_nightly_count,
                  pct_change_from_year1, impact_classification]
        One row per (species, year) combination.
        ``year`` values are integers. ``impact_classification`` is the same
        for all rows of a given species.
    """
    # ── 1. Apply precipitation filter ─────────────────────────────────────────
    rainy_dates = weather_df.loc[weather_df["precipitation"] > 0.0, "date"].unique()
    filtered = classifications_df[~classifications_df["date"].isin(rainy_dates)].copy()

    # ── 2. Keep only WNS-susceptible species ──────────────────────────────────
    filtered = filtered[filtered["species"].isin(SUSCEPTIBLE_SPECIES)].copy()

    # ── 3. Extract calendar year from date ────────────────────────────────────
    filtered["date"] = pd.to_datetime(filtered["date"])
    filtered["year"] = filtered["date"].dt.year

    # ── 4. Build per-species results ──────────────────────────────────────────
    species_frames = []
    for species in SUSCEPTIBLE_SPECIES:
        sp_data = filtered[filtered["species"] == species]

        # Mean classified_count per calendar year
        yearly_mean = (
            sp_data.groupby("year")["classified_count"]
            .mean()
            .reset_index()
            .rename(columns={"classified_count": "mean_nightly_count"})
            .sort_values("year")
            .reset_index(drop=True)
        )
        yearly_mean["year"] = yearly_mean["year"].astype(int)

        # Percent change from year one
        mean_year1 = yearly_mean.loc[0, "mean_nightly_count"]
        yearly_mean["pct_change_from_year1"] = (
            (yearly_mean["mean_nightly_count"] - mean_year1) / mean_year1
        ) * 100.0
        # Year-one value is defined as exactly 0.0
        yearly_mean.loc[0, "pct_change_from_year1"] = 0.0

        # Impact classification based on final-year percent change
        final_pct = yearly_mean.iloc[-1]["pct_change_from_year1"]
        if final_pct <= -50.0:
            impact_classification = "Severe"
        elif final_pct <= -25.0:
            impact_classification = "Moderate"
        else:
            impact_classification = "None"

        yearly_mean["species"] = species
        yearly_mean["impact_classification"] = impact_classification

        species_frames.append(
            yearly_mean[
                [
                    "species",
                    "year",
                    "mean_nightly_count",
                    "pct_change_from_year1",
                    "impact_classification",
                ]
            ]
        )

    return pd.concat(species_frames, ignore_index=True)
