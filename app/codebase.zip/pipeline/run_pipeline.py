"""
pipeline/run_pipeline.py

CLI entry point for the bat conservation acoustic data pipeline.

Usage
-----
    python pipeline/run_pipeline.py data/

Reads the four CSV files from the supplied data directory, runs all analysis
steps in sequence, and writes the plain-text report to
``reports/wildlife_agency_report.txt``.
"""

import os
import sys

# Allow running as ``python pipeline/run_pipeline.py`` from the project root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pipeline.data_loader import load_data
from pipeline.activity_estimator import estimate_activity_rates
from pipeline.migration_analyzer import identify_migration_timing
from pipeline.wns_modeler import model_wns_impact
from pipeline.report_generator import generate_report

OUTPUT_PATH = os.path.join("reports", "wildlife_agency_report.txt")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python pipeline/run_pipeline.py <data_dir>", file=sys.stderr)
        sys.exit(1)

    data_dir = sys.argv[1]

    print(f"Loading data from '{data_dir}' …")
    activity_df, classifications_df, habitat_df, weather_df = load_data(data_dir)

    print("Estimating activity rates …")
    activity_rates = estimate_activity_rates(
        activity_df, classifications_df, habitat_df, weather_df
    )

    print("Identifying migration timing …")
    migration_timing = identify_migration_timing(classifications_df, weather_df)

    print("Modelling white-nose syndrome impact …")
    wns_impact = model_wns_impact(classifications_df, weather_df)

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)

    print(f"Writing report to '{OUTPUT_PATH}' …")
    generate_report(activity_rates, migration_timing, wns_impact, OUTPUT_PATH)

    print("Pipeline complete.")
