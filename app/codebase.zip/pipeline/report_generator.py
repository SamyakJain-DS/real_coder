"""
pipeline/report_generator.py

Writes the plain-text wildlife agency report from the three analysis results.

The report contains exactly four labeled sections in this order:
  1. Species Activity Summary
  2. Migration Timing Summary
  3. White-Nose Syndrome Impact Summary
  4. Per-Region Species Status
"""

import pandas as pd


def generate_report(
    activity_rates: pd.DataFrame,
    migration_timing: pd.DataFrame,
    wns_impact: pd.DataFrame,
    output_path: str,
) -> None:
    """
    Write a plain-text wildlife agency report to *output_path*.

    The file is created or overwritten. The four sections appear in the order
    defined in the module docstring.

    Parameters
    ----------
    activity_rates : pd.DataFrame
        Columns: [species, habitat, region, corrected_mean_nightly_rate]
    migration_timing : pd.DataFrame
        Columns: [species, peak_week, season_start_week, season_end_week]
    wns_impact : pd.DataFrame
        Columns: [species, year, mean_nightly_count,
                  pct_change_from_year1, impact_classification]
    output_path : str
        Destination file path (created or overwritten).

    Returns
    -------
    None
    """
    lines = []

    # ── Section 1: Species Activity Summary ───────────────────────────────────
    lines.append("Species Activity Summary")
    lines.append("=" * 60)
    for _, row in activity_rates.iterrows():
        lines.append(
            f"  Species: {row['species']} | "
            f"Habitat: {row['habitat']} | "
            f"Region: {row['region']} | "
            f"Corrected Mean Nightly Rate: {row['corrected_mean_nightly_rate']:.2f}"
        )
    lines.append("")

    # ── Section 2: Migration Timing Summary ───────────────────────────────────
    lines.append("Migration Timing Summary")
    lines.append("=" * 60)
    for _, row in migration_timing.iterrows():
        lines.append(f"  Species: {row['species']}")
        lines.append(f"    Peak Migration Week     : {row['peak_week']}")
        lines.append(f"    Season Start Week       : {row['season_start_week']}")
        lines.append(f"    Season End Week         : {row['season_end_week']}")
    lines.append("")

    # ── Section 3: White-Nose Syndrome Impact Summary ─────────────────────────
    lines.append("White-Nose Syndrome Impact Summary")
    lines.append("=" * 60)
    for _, row in wns_impact.iterrows():
        lines.append(
            f"  Species: {row['species']} | "
            f"Year: {int(row['year'])} | "
            f"Mean Nightly Count: {row['mean_nightly_count']:.2f} | "
            f"Pct Change from Year 1: {row['pct_change_from_year1']:.2f}% | "
            f"Impact: {row['impact_classification']}"
        )
    lines.append("")

    # ── Section 4: Per-Region Species Status ──────────────────────────────────
    lines.append("Per-Region Species Status")
    lines.append("=" * 60)
    for region in activity_rates["region"].unique():
        lines.append(f"  Region: {region}")
        region_df = activity_rates[activity_rates["region"] == region]
        for _, row in region_df.iterrows():
            lines.append(
                f"    Species: {row['species']} | "
                f"Habitat: {row['habitat']} | "
                f"Corrected Mean Nightly Rate: {row['corrected_mean_nightly_rate']:.2f}"
            )
        lines.append("")

    report_text = "\n".join(lines)

    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(report_text)
