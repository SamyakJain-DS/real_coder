from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Optional


VALID_PROCESSING_STATUSES: frozenset[str] = frozenset(
    {"unprocessed", "in_progress", "processed"}
)

INITIAL_PROCESSING_STATUS: str = "unprocessed"


@dataclass
class Collection:
    """A processed archival collection record.

    Carries the DACS-required descriptive fields (title, date_range,
    extent_linear_feet, abstract, scope_and_content,
    arrangement_scheme), a processing_status from the controlled
    vocabulary, an access_restriction description (or None when the
    collection is open for research), and the accession_id that links
    this collection back to its source accession record.
    """

    id: str
    accession_id: str
    title: str
    date_range: str
    extent_linear_feet: float
    abstract: str
    scope_and_content: str
    arrangement_scheme: str
    processing_status: str
    access_restriction: Optional[str]


class CollectionProcessor:
    """In-memory store of processed Collection records.

    Records are kept in a dict keyed by the generated unique identifier so
    that get_collection performs an O(1) lookup without scanning. Each
    CollectionProcessor instance owns its own storage; instances do
    not share state.
    """

    def __init__(self) -> None:
        self._collections_by_id: dict[str, Collection] = {}

    def process_collection(
        self,
        accession_id: str,
        arrangement_scheme: str,
        dacs_fields: dict,
    ) -> Collection:
        """Create, store, and return a new Collection.

        Generates a unique string identifier, sets the initial
        processing_status to "unprocessed", and populates DACS
        fields from the dacs_fields dictionary. When
        access_restriction is absent from dacs_fields it defaults
        to None (an open-for-research collection).
        """
        collection_id = str(uuid.uuid4())
        collection = Collection(
            id=collection_id,
            accession_id=accession_id,
            arrangement_scheme=arrangement_scheme,
            processing_status=INITIAL_PROCESSING_STATUS,
            title=dacs_fields["title"],
            date_range=dacs_fields["date_range"],
            extent_linear_feet=dacs_fields["extent_linear_feet"],
            abstract=dacs_fields["abstract"],
            scope_and_content=dacs_fields["scope_and_content"],
            access_restriction=dacs_fields.get("access_restriction", None),
        )
        self._collections_by_id[collection_id] = collection
        return collection

    def get_collection(self, collection_id: str) -> Collection:
        """Return the collection with the given identifier.

        Raises KeyError when no collection with that identifier exists.
        """
        if collection_id not in self._collections_by_id:
            raise KeyError(
                f"Collection '{collection_id}' is not present in the processor."
            )
        return self._collections_by_id[collection_id]

    def update_processing_status(
        self,
        collection_id: str,
        status: str,
    ) -> Collection:
        """Update the processing_status of an existing collection.

        Raises ValueError when status is not one of
        "unprocessed", "in_progress", or "processed".
        Raises KeyError when no collection with collection_id exists.
        Returns the updated Collection.
        """
        if status not in VALID_PROCESSING_STATUSES:
            raise ValueError(
                f"Invalid processing status '{status}'. "
                f"Must be one of: {sorted(VALID_PROCESSING_STATUSES)}."
            )
        if collection_id not in self._collections_by_id:
            raise KeyError(
                f"Collection '{collection_id}' is not present in the processor."
            )
        collection = self._collections_by_id[collection_id]
        collection.processing_status = status
        return collection
