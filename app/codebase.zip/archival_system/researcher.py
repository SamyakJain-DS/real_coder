from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Optional


@dataclass
class Researcher:
    """A registered reading-room researcher record."""

    id: str
    name: str
    contact_info: str
    affiliation: str


@dataclass
class Visit:
    """A single reading-room visit record.

    The visit_date is an ISO 8601 date string. The
    restriction_reason field is the collection's
    access_restriction description at the time of the visit, or
    None for unrestricted collections. The authorization_ref
    field is the authorization string that permitted access to a
    restricted collection (None for unrestricted collections),
    preserving the auditable link between the visit and the
    authorization record.
    """

    id: str
    researcher_id: str
    collection_id: str
    visit_date: str
    restriction_reason: Optional[str]
    authorization_ref: Optional[str] = None


class ReadingRoomCirculation:
    """In-memory store of Researcher and Visit records.

    Holds a reference to the supplied CollectionProcessor so that
    every call to record_visit resolves the collection's *current*
    access_restriction from the live collection store, rather than
    from a snapshot taken at construction time. Researchers and visits
    are kept in dicts keyed by their generated unique identifiers so
    lookup is O(1). Each instance owns its own storage; instances do
    not share state.
    """

    def __init__(self, collection_processor: "CollectionProcessor") -> None:  # noqa: F821
        self._collection_processor = collection_processor
        self._researchers_by_id: dict[str, Researcher] = {}
        self._visits_by_id: dict[str, Visit] = {}

    def register_researcher(
        self,
        name: str,
        contact_info: str,
        affiliation: str,
    ) -> Researcher:
        """Create, store, and return a new Researcher with a unique id."""
        researcher_id = str(uuid.uuid4())
        researcher = Researcher(
            id=researcher_id,
            name=name,
            contact_info=contact_info,
            affiliation=affiliation,
        )
        self._researchers_by_id[researcher_id] = researcher
        return researcher

    def record_visit(
        self,
        researcher_id: str,
        collection_id: str,
        visit_date: str,
        authorization_ref: Optional[str] = None,
    ) -> Visit:
        """Record and return a reading-room Visit.

        The validation order is intentionally sequential, with distinct
        error messages so callers can disambiguate the failure cause:

        1. Verify researcher_id references a registered researcher
           (KeyError whose message contains "researcher" otherwise).
        2. Resolve collection_id against the live
           CollectionProcessor to obtain the collection's current
           access_restriction (KeyError whose message contains
           "collection" when the collection is unknown).
        3. When the resolved collection is restricted (i.e. its
           access_restriction is not None), require a non-None
           authorization_ref (ValueError otherwise).
        """
        if researcher_id not in self._researchers_by_id:
            raise KeyError(
                f"Researcher '{researcher_id}' is not registered."
            )

        try:
            referenced_collection = self._collection_processor.get_collection(
                collection_id
            )
        except KeyError:
            raise KeyError(
                f"Collection '{collection_id}' is not present in the processor."
            ) from None

        current_access_restriction = referenced_collection.access_restriction
        if current_access_restriction is not None and authorization_ref is None:
            raise ValueError(
                f"Collection '{collection_id}' is restricted "
                f"({current_access_restriction!r}); a non-None "
                "authorization_ref is required to record a visit."
            )

        visit_id = str(uuid.uuid4())
        visit = Visit(
            id=visit_id,
            researcher_id=researcher_id,
            collection_id=collection_id,
            visit_date=visit_date,
            restriction_reason=current_access_restriction,
            authorization_ref=authorization_ref,
        )
        self._visits_by_id[visit_id] = visit
        return visit

    def get_visits_by_year(self, year: int) -> list[Visit]:
        """Return all visits whose ISO 8601 visit_date falls in year."""
        year_prefix = f"{year:04d}"
        return [
            visit
            for visit in self._visits_by_id.values()
            if visit.visit_date.startswith(year_prefix)
        ]
