from __future__ import annotations

import xml.etree.ElementTree as ET


OPEN_FOR_RESEARCH_TEXT: str = "Open for research"


def generate_ead(collection: "Collection") -> str:  # noqa: F821 - forward reference
    """Return an EAD 2002 XML string for the given Collection.

    Document structure (every node constructed with ET.Element /
    ET.SubElement):

        <ead>
            <eadheader>
                <eadid>{collection.id}</eadid>
                <filedesc>
                    <titlestmt>
                        <titleproper>{collection.title}</titleproper>
                    </titlestmt>
                </filedesc>
            </eadheader>
            <archdesc level="collection">
                <did>
                    <unittitle>{collection.title}</unittitle>
                    <unitdate>{collection.date_range}</unitdate>
                    <physdesc>{collection.extent_linear_feet}</physdesc>
                </did>
                <scopecontent>{collection.scope_and_content}</scopecontent>
                <accessrestrict>
                    {collection.access_restriction or "Open for research"}
                </accessrestrict>
            </archdesc>
        </ead>
    """
    ead_root = ET.Element("ead")

    ead_header = ET.SubElement(ead_root, "eadheader")
    ead_identifier = ET.SubElement(ead_header, "eadid")
    ead_identifier.text = collection.id
    file_description = ET.SubElement(ead_header, "filedesc")
    title_statement = ET.SubElement(file_description, "titlestmt")
    title_proper = ET.SubElement(title_statement, "titleproper")
    title_proper.text = collection.title

    archival_description = ET.SubElement(ead_root, "archdesc", level="collection")

    descriptive_identification = ET.SubElement(archival_description, "did")

    unit_title = ET.SubElement(descriptive_identification, "unittitle")
    unit_title.text = collection.title

    unit_date = ET.SubElement(descriptive_identification, "unitdate")
    unit_date.text = collection.date_range

    physical_description = ET.SubElement(descriptive_identification, "physdesc")
    physical_description.text = str(collection.extent_linear_feet)

    scope_content = ET.SubElement(archival_description, "scopecontent")
    scope_content.text = collection.scope_and_content

    access_restriction_element = ET.SubElement(archival_description, "accessrestrict")
    if collection.access_restriction is not None:
        access_restriction_element.text = collection.access_restriction
    else:
        access_restriction_element.text = OPEN_FOR_RESEARCH_TEXT

    return ET.tostring(ead_root, encoding="unicode")
