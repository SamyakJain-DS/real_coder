from __future__ import annotations

import uuid
from dataclasses import dataclass


VALID_JOB_STATUSES: frozenset[str] = frozenset({"queued", "in_progress", "complete"})

INITIAL_JOB_STATUS: str = "queued"


@dataclass
class DigitizationJob:
    """A single digitization job record.

    The status field follows the controlled vocabulary
    "queued" -> "in_progress" -> "complete". The
    preservation_standard is a free-form string identifying the
    target preservation specification (e.g. "FADGI 4-Star",
    "Archival TIFF").
    """

    id: str
    collection_id: str
    preservation_standard: str
    status: str


class DigitizationWorkflow:
    """In-memory store of DigitizationJob records.

    Holds a reference to the supplied CollectionProcessor so that
    every call to create_job validates the referenced
    collection_id against the live collection store. Jobs are kept
    in a dict keyed by the generated unique identifier so lookup is
    O(1). Each instance owns its own storage; instances do not share
    state.
    """

    def __init__(self, collection_processor: "CollectionProcessor") -> None:  # noqa: F821
        self._collection_processor = collection_processor
        self._jobs_by_id: dict[str, DigitizationJob] = {}

    def create_job(
        self,
        collection_id: str,
        preservation_standard: str,
    ) -> DigitizationJob:
        """Create, store, and return a new DigitizationJob.

        Verifies that collection_id references an existing collection
        in the bound CollectionProcessor (raising KeyError when
        it does not), assigns a unique string identifier, and sets the
        initial status to "queued".
        """
        try:
            self._collection_processor.get_collection(collection_id)
        except KeyError:
            raise KeyError(
                f"Cannot create digitization job: collection '{collection_id}' "
                "is not present in the processor."
            ) from None

        job_id = str(uuid.uuid4())
        job = DigitizationJob(
            id=job_id,
            collection_id=collection_id,
            preservation_standard=preservation_standard,
            status=INITIAL_JOB_STATUS,
        )
        self._jobs_by_id[job_id] = job
        return job

    def update_job_status(self, job_id: str, status: str) -> DigitizationJob:
        """Update and return the DigitizationJob with the new status.

        Raises ValueError when status is not one of "queued",
        "in_progress", or "complete". Raises KeyError when
        no job with job_id exists.
        """
        if status not in VALID_JOB_STATUSES:
            raise ValueError(
                f"Invalid digitization job status '{status}'. "
                f"Must be one of: {sorted(VALID_JOB_STATUSES)}."
            )
        if job_id not in self._jobs_by_id:
            raise KeyError(f"Digitization job '{job_id}' is not present.")
        job = self._jobs_by_id[job_id]
        job.status = status
        return job
