from __future__ import annotations


TRANSFER_ACCESSION_TYPE: str = "transfer"


def generate_legislative_report(
    accession_registry: "AccessionRegistry",  # noqa: F821 - forward reference
    circulation: "ReadingRoomCirculation",  # noqa: F821 - forward reference
    year: int,
) -> dict:
    """Return the legislative annual report dictionary for year.

    The returned dict has the keys:

    - "total_accessions" (int): count of accessions registered in year.
    - "total_linear_feet" (float): sum of linear_feet across those
      accessions (always a float, even when zero).
    - "total_visits" (int): count of reading-room visits whose
      visit_date falls in year.
    """
    accessions_in_year = accession_registry.list_accessions_by_year(year)
    visits_in_year = circulation.get_visits_by_year(year)
    total_linear_feet = sum(
        (accession.linear_feet for accession in accessions_in_year),
        start=0.0,
    )
    return {
        "total_accessions": len(accessions_in_year),
        "total_linear_feet": float(total_linear_feet),
        "total_visits": len(visits_in_year),
    }


def generate_transfer_schedule(
    accession_registry: "AccessionRegistry",  # noqa: F821 - forward reference
    agency_id: str,
) -> list[dict]:
    """Return the per-agency state-records transfer schedule.

    Walks every accession in accession_registry and emits one
    dictionary per "transfer"-type accession whose agency_id
    matches the parameter. Each dictionary contains the keys
    "accession_id", "title", "scheduled_transfer_date", and
    "actual_transfer_date". Returns an empty list when no matching
    transfer accessions exist.
    """
    transfer_schedule: list[dict] = []
    for accession in accession_registry.list_all_accessions():
        if (
            accession.accession_type == TRANSFER_ACCESSION_TYPE
            and accession.agency_id == agency_id
        ):
            transfer_schedule.append(
                {
                    "accession_id": accession.id,
                    "title": accession.title,
                    "scheduled_transfer_date": accession.scheduled_transfer_date,
                    "actual_transfer_date": accession.actual_transfer_date,
                }
            )
    return transfer_schedule
