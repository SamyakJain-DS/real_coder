from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Optional


VALID_ACCESSION_TYPES: frozenset[str] = frozenset({"donation", "purchase", "transfer"})

DONATION_REQUIRED_FIELDS: tuple[str, ...] = ("donor_id", "deed_of_gift_ref")

TRANSFER_REQUIRED_FIELDS: tuple[str, ...] = (
    "agency_id",
    "public_records_authority",
    "scheduled_transfer_date",
    "actual_transfer_date",
)


@dataclass
class Accession:
    """A single accession record.

    The accession_type discriminator must be one of "donation",
    "purchase", or "transfer". Donation accessions carry the
    donor_id and deed_of_gift_ref fields; state-agency transfer
    accessions carry the four agency-records fields. Purchase accessions
    carry no type-specific metadata.
    """

    id: str
    accession_type: str
    title: str
    linear_feet: float
    year: int
    donor_id: Optional[str] = None
    deed_of_gift_ref: Optional[str] = None
    agency_id: Optional[str] = None
    public_records_authority: Optional[str] = None
    scheduled_transfer_date: Optional[str] = None
    actual_transfer_date: Optional[str] = None


class AccessionRegistry:
    """In-memory registry of Accession records.

    Records are kept in a dict keyed by the generated unique identifier so
    that get_accession performs an O(1) lookup without scanning the
    whole registry. Each AccessionRegistry instance owns its own
    storage; instances do not share state.
    """

    def __init__(self) -> None:
        self._accessions_by_id: dict[str, Accession] = {}

    def register_accession(
        self,
        accession_type: str,
        title: str,
        linear_feet: float,
        year: int,
        **type_specific_fields,
    ) -> Accession:
        """Register a new accession and return the stored Accession.

        Generates a unique string identifier, validates type-specific
        required fields, and stores the record internally. Type-specific
        fields are forwarded to the Accession constructor via
        **type_specific_fields.

        Raises ValueError when accession_type is "donation" and
        either donor_id or deed_of_gift_ref is absent or None.
        Raises ValueError when accession_type is "transfer" and
        any of the four agency-records fields (agency_id,
        public_records_authority, scheduled_transfer_date,
        actual_transfer_date) is absent or None.
        """
        self._validate_type_specific_fields(accession_type, type_specific_fields)

        accession_id = str(uuid.uuid4())
        accession = Accession(
            id=accession_id,
            accession_type=accession_type,
            title=title,
            linear_feet=linear_feet,
            year=year,
            **type_specific_fields,
        )
        self._accessions_by_id[accession_id] = accession
        return accession

    def get_accession(self, accession_id: str) -> Accession:
        """Return the accession with the given identifier.

        Raises KeyError when no accession with that identifier exists.
        """
        if accession_id not in self._accessions_by_id:
            raise KeyError(f"Accession '{accession_id}' is not registered.")
        return self._accessions_by_id[accession_id]

    def list_accessions_by_year(self, year: int) -> list[Accession]:
        """Return all accessions whose year matches the given year."""
        return [
            accession
            for accession in self._accessions_by_id.values()
            if accession.year == year
        ]

    def list_all_accessions(self) -> list[Accession]:
        """Return every registered accession regardless of year or type."""
        return list(self._accessions_by_id.values())

    @staticmethod
    def _validate_type_specific_fields(
        accession_type: str,
        type_specific_fields: dict,
    ) -> None:
        """Enforce per-type required-field rules before construction."""
        if accession_type == "donation":
            missing_donation_fields = [
                field_name
                for field_name in DONATION_REQUIRED_FIELDS
                if field_name not in type_specific_fields
                or type_specific_fields[field_name] is None
            ]
            if missing_donation_fields:
                raise ValueError(
                    "Donation accession requires values for: "
                    f"{', '.join(missing_donation_fields)}."
                )
        elif accession_type == "transfer":
            missing_transfer_fields = [
                field_name
                for field_name in TRANSFER_REQUIRED_FIELDS
                if field_name not in type_specific_fields
                or type_specific_fields[field_name] is None
            ]
            if missing_transfer_fields:
                raise ValueError(
                    "State-agency transfer accession requires values for: "
                    f"{', '.join(missing_transfer_fields)}."
                )
