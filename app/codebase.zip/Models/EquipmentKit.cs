namespace WeddingStudio.Api.Models;

public class EquipmentKit
{
    public int Id { get; set; }
    public int SessionId { get; set; }
    public string KitName { get; set; } = string.Empty;
    public List<int> InventoryItemIds { get; set; } = new();
}
