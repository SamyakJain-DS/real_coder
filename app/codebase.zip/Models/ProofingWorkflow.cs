namespace WeddingStudio.Api.Models;

public class ProofingWorkflow
{
    public int Id { get; set; }
    public int BookingId { get; set; }
    public string ContractedDeliveryDate { get; set; } = string.Empty;
}
