namespace WeddingStudio.Api.Models;

public class ProofingRound
{
    public int Id { get; set; }
    public int ProofingWorkflowId { get; set; }
    public int RoundNumber { get; set; }
    public string SubmittedDate { get; set; } = string.Empty;
    public int ImagesSelected { get; set; }
    public string Notes { get; set; } = string.Empty;
}
