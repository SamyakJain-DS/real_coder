namespace WeddingStudio.Api.Models;

public class Session
{
    public int Id { get; set; }
    public int BookingId { get; set; }
    public string Location { get; set; } = string.Empty;
    public string ScheduledStartTime { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
}
