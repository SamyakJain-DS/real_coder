namespace WeddingStudio.Api.Models;

public class Booking
{
    public int Id { get; set; }
    public string Partner1Name { get; set; } = string.Empty;
    public string Partner2Name { get; set; } = string.Empty;
    public string VenueName { get; set; } = string.Empty;
    public string WeddingDate { get; set; } = string.Empty;
    public string PackageType { get; set; } = string.Empty;
    public List<string> Deliverables { get; set; } = new();
}
