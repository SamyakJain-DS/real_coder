import { loadImageFromFile } from "./imageLoader.js";
import { convertUnit } from "./dimensionManager.js";
import { drawGridOverlay } from "./gridOverlay.js";
import { computeTileRegions, buildPrintLayout } from "./printManager.js";
import { getPixelColorAt, findClosestColors } from "./eyedropper.js";
import { GLASS_COLORS } from "./glassColors.js";

const SUPPORTED_IMAGE_MIME_TYPES = new Set(["image/png", "image/jpeg"]);
const COLOR_SUGGESTION_COUNT = 3;
const DECIMAL_PLACES_FOR_UNIT_CONVERSION = 2;

let previousUnit = "inches";
let elements = null;

function collectElements() {
  const fileInput = document.getElementById("file-input");
  const realWidthInput = document.getElementById("real-width-input");
  const realHeightInput = document.getElementById("real-height-input");
  const unitSelect = document.getElementById("unit-select");
  const gridSizeInput = document.getElementById("grid-size-input");
  const orientationSelect = document.getElementById("orientation-select");
  const registrationToggle = document.getElementById("registration-toggle");
  const printButton = document.getElementById("print-button");
  const eyedropperButton = document.getElementById("eyedropper-button");
  const colorSuggestionOutput = document.getElementById("color-suggestion-output");
  const workspaceCanvas = document.getElementById("workspace-canvas");
  const gridOverlayCanvas = document.getElementById("grid-overlay-canvas");
  const printContainer = document.getElementById("print-container");

  return {
    fileInput,
    realWidthInput,
    realHeightInput,
    unitSelect,
    gridSizeInput,
    orientationSelect,
    registrationToggle,
    printButton,
    eyedropperButton,
    colorSuggestionOutput,
    workspaceCanvas,
    gridOverlayCanvas,
    printContainer,
  };
}

function triggerGridRedraw() {
  const realWidth = parseFloat(elements.realWidthInput.value);
  const realHeight = parseFloat(elements.realHeightInput.value);
  const cellSize = parseFloat(elements.gridSizeInput.value);
  drawGridOverlay(elements.gridOverlayCanvas, realWidth, realHeight, cellSize);
}

async function handleFileInputChange() {
  const file = elements.fileInput.files && elements.fileInput.files[0];
  if (!file) return;
  if (!SUPPORTED_IMAGE_MIME_TYPES.has(file.type)) {
    return;
  }
  try {
    const image = await loadImageFromFile(file, elements.workspaceCanvas);
    elements.gridOverlayCanvas.width = image.naturalWidth;
    elements.gridOverlayCanvas.height = image.naturalHeight;
    triggerGridRedraw();
  } catch {
    /* swallow load errors; user can retry with another file */
  }
}

function handleUnitChange() {
  const newUnit = elements.unitSelect.value;
  const dimensionInputs = [
    elements.realWidthInput,
    elements.realHeightInput,
    elements.gridSizeInput,
  ];
  for (const input of dimensionInputs) {
    const parsedValue = parseFloat(input.value);
    const convertedValue = convertUnit(parsedValue, previousUnit, newUnit);
    const roundedValue = parseFloat(
      convertedValue.toFixed(DECIMAL_PLACES_FOR_UNIT_CONVERSION),
    );
    input.value = String(roundedValue);
  }
  previousUnit = newUnit;
  triggerGridRedraw();
}

function handlePrintClick() {
  const realWidth = parseFloat(elements.realWidthInput.value);
  const realHeight = parseFloat(elements.realHeightInput.value);
  const unit = elements.unitSelect.value;
  const orientation = elements.orientationSelect.value;
  const includeMarks = elements.registrationToggle.checked;

  const realWidthInches = convertUnit(realWidth, unit, "inches");
  const realHeightInches = convertUnit(realHeight, unit, "inches");

  const tileRegions = computeTileRegions(
    elements.workspaceCanvas.width,
    elements.workspaceCanvas.height,
    realWidthInches,
    realHeightInches,
    orientation,
  );
  buildPrintLayout(
    elements.workspaceCanvas,
    tileRegions,
    includeMarks,
    orientation,
    elements.printContainer,
  );
  window.print();
}

function renderColorSuggestions(suggestions) {
  while (elements.colorSuggestionOutput.firstChild) {
    elements.colorSuggestionOutput.removeChild(
      elements.colorSuggestionOutput.firstChild,
    );
  }
  for (const entry of suggestions) {
    const swatch = document.createElement("div");
    swatch.className = "color-suggestion";
    swatch.setAttribute("style", `background-color: ${entry.hex};`);
    swatch.textContent = entry.name;
    elements.colorSuggestionOutput.appendChild(swatch);
  }
}

function exitEyedropperMode() {
  document.body.classList.remove("eyedropper-active");
  elements.workspaceCanvas.style.cursor = "default";
  elements.gridOverlayCanvas.style.cursor = "default";
}

function handleEyedropperSampleClick(event) {
  const x = event.offsetX;
  const y = event.offsetY;
  const sampled = getPixelColorAt(elements.workspaceCanvas, x, y);
  const suggestions = findClosestColors(
    { r: sampled.r, g: sampled.g, b: sampled.b },
    GLASS_COLORS,
    COLOR_SUGGESTION_COUNT,
  );
  renderColorSuggestions(suggestions);
  exitEyedropperMode();
}

function handleEyedropperButtonClick() {
  document.body.classList.add("eyedropper-active");
  elements.workspaceCanvas.style.cursor = "crosshair";
  elements.gridOverlayCanvas.style.cursor = "crosshair";
  elements.gridOverlayCanvas.addEventListener(
    "click",
    handleEyedropperSampleClick,
    { once: true },
  );
}

function registerFileInputListeners() {
  elements.fileInput.addEventListener("change", handleFileInputChange);
}

function registerRealWidthInputListeners() {
  elements.realWidthInput.addEventListener("input", triggerGridRedraw);
}

function registerRealHeightInputListeners() {
  elements.realHeightInput.addEventListener("input", triggerGridRedraw);
}

function registerGridSizeInputListeners() {
  elements.gridSizeInput.addEventListener("input", triggerGridRedraw);
}

function registerUnitSelectListeners() {
  elements.unitSelect.addEventListener("change", handleUnitChange);
}

function registerPrintButtonListeners() {
  elements.printButton.addEventListener("click", handlePrintClick);
}

function registerEyedropperButtonListeners() {
  elements.eyedropperButton.addEventListener(
    "click",
    handleEyedropperButtonClick,
  );
}

export function initializeApp() {
  elements = collectElements();
  previousUnit = elements.unitSelect.value;
  registerFileInputListeners();
  registerRealWidthInputListeners();
  registerRealHeightInputListeners();
  registerGridSizeInputListeners();
  registerUnitSelectListeners();
  registerPrintButtonListeners();
  registerEyedropperButtonListeners();
}

document.addEventListener("DOMContentLoaded", initializeApp);
