from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class ChangedFile:
    path: str
    status: str


_DIFF_HEADER_RE = re.compile(r"^diff --git a/.+ b/(.+)$")
_RENAME_TO_RE = re.compile(r"^rename to (.+)$")


def parse_diff(diff_text: str) -> list[ChangedFile]:
    if not diff_text:
        return []

    files: list[ChangedFile] = []
    lines = diff_text.split("\n")
    i = 0

    while i < len(lines):
        header_match = _DIFF_HEADER_RE.match(lines[i])
        if not header_match:
            i += 1
            continue

        file_path = header_match.group(1)
        status = "modified"
        i += 1

        while i < len(lines) and not _DIFF_HEADER_RE.match(lines[i]):
            line = lines[i]

            if "new file mode" in line:
                status = "added"
            elif "deleted file mode" in line:
                status = "deleted"
            elif "rename from" in line:
                status = "renamed"
            elif line.startswith("rename to "):
                rename_match = _RENAME_TO_RE.match(line)
                if rename_match:
                    file_path = rename_match.group(1)
            elif line.startswith("Binary files "):
                # Explicit handling of binary file diffs.
                # The canonical file path has already been extracted from the
                # `diff --git a/... b/...` header (or updated by `rename to`).
                # The status has already been set to "added" or "deleted" by
                # the `new file mode` / `deleted file mode` lines when those
                # are present; for a binary-modified file no mode line appears,
                # so status correctly remains "modified".
                pass

            i += 1

        files.append(ChangedFile(path=file_path, status=status))

    return files