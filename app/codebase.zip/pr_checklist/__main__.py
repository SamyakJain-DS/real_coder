import sys

from pr_checklist.cli import main

sys.exit(main(None))
