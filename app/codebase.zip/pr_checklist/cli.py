from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

from pr_checklist.checker import check_description
from pr_checklist.config import ConfigError, load_config
from pr_checklist.diff_parser import parse_diff
from pr_checklist.matcher import match_rules
from pr_checklist.renderer import render_markdown


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pr_checklist",
        description="PR Review Checklist CLI",
    )
    subparsers = parser.add_subparsers(dest="command")

    gen_parser = subparsers.add_parser("generate")
    gen_parser.add_argument("--config", required=True)
    gen_parser.add_argument("--diff", default=None)

    check_parser = subparsers.add_parser("check")
    check_parser.add_argument("--config", required=True)
    check_parser.add_argument("--diff", default=None)
    check_parser.add_argument("--description", required=True)

    return parser


def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help(sys.stderr)
        return 2

    config_path = Path(args.config)
    if not config_path.exists():
        sys.stderr.write(
            f"Error: Configuration file not found: {args.config}\n"
        )
        return 2

    if args.diff is not None:
        diff_path = Path(args.diff)
        if not diff_path.exists():
            sys.stderr.write(f"Error: Diff file not found: {args.diff}\n")
            return 2

    if args.command == "check":
        desc_path = Path(args.description)
        if not desc_path.exists():
            sys.stderr.write(
                f"Error: Description file not found: {args.description}\n"
            )
            return 2

    try:
        config = load_config(config_path)
    except yaml.YAMLError:
        sys.stderr.write("Error: Invalid YAML in configuration file.\n")
        return 2
    except ConfigError as e:
        sys.stderr.write(f"{e}\n")
        return 2

    if args.diff is not None:
        diff_text = Path(args.diff).read_text()
    else:
        diff_text = sys.stdin.read()

    changed_files = parse_diff(diff_text)
    triggered_rules = match_rules(changed_files, config)

    if args.command == "generate":
        markdown = render_markdown(triggered_rules)
        sys.stdout.write(markdown)
        return 0

    elif args.command == "check":
        description = Path(args.description).read_text()
        result = check_description(triggered_rules, description)

        if not triggered_rules:
            sys.stdout.write("PR Checklist: PASS - 0 items triggered.\n")
            return 0

        total = len(result.addressed) + len(result.missing)
        addressed_count = len(result.addressed)

        if result.passed:
            sys.stdout.write(
                f"PR Checklist: PASS - {total} of {total} items addressed.\n"
            )
            return 0
        else:
            sys.stdout.write(
                f"PR Checklist: FAIL - {addressed_count} of {total} items addressed.\n"
                f"Missing items:\n"
            )
            for triggered in triggered_rules:
                for item in triggered.rule.checklist:
                    if item.key in result.missing:
                        sys.stdout.write(
                            f"  - {item.text} (key: {item.key})\n"
                        )
            return 1

    return 0