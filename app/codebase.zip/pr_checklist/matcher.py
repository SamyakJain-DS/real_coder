from __future__ import annotations

import fnmatch
from dataclasses import dataclass

from pr_checklist.config import ChecklistConfig, Rule
from pr_checklist.diff_parser import ChangedFile


@dataclass(frozen=True)
class TriggeredRule:
    rule: Rule
    matched_files: list[str]


def _file_extension(path: str) -> str:
    # The spec says: "the last occurrence of '.' in the filename, including
    # the dot."  Split to get just the filename (last component), then find
    # the rightmost '.'.  This correctly handles dotfiles (.gitignore → '.gitignore')
    # and multi-dot names (archive.tar.gz → '.gz').
    filename = path.rsplit("/", 1)[-1]
    dot_idx = filename.rfind(".")
    if dot_idx == -1:
        return ""
    return filename[dot_idx:]


def _file_matches_rule(changed_file: ChangedFile, rule: Rule) -> bool:
    trigger = rule.trigger

    if trigger.extensions:
        file_ext = _file_extension(changed_file.path)
        for ext in trigger.extensions:
            if file_ext.lower() == ext.lower():
                return True

    if trigger.paths:
        for prefix in trigger.paths:
            if changed_file.path.startswith(prefix):
                return True

    if trigger.patterns:
        for pattern in trigger.patterns:
            if fnmatch.fnmatch(changed_file.path, pattern):
                return True

    return False


def _has_active_trigger(rule: Rule) -> bool:
    trigger = rule.trigger
    return bool(trigger.extensions or trigger.paths or trigger.patterns)


def match_rules(
    changed_files: list[ChangedFile], config: ChecklistConfig
) -> list[TriggeredRule]:
    triggered: list[TriggeredRule] = []

    for rule in config.rules:
        if not _has_active_trigger(rule):
            continue

        matched_paths: list[str] = []
        for changed_file in changed_files:
            if _file_matches_rule(changed_file, rule):
                matched_paths.append(changed_file.path)

        if matched_paths:
            matched_paths.sort()
            triggered.append(TriggeredRule(rule=rule, matched_files=matched_paths))

    return triggered