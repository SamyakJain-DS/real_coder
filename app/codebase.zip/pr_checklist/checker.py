from __future__ import annotations

import re
from dataclasses import dataclass

from pr_checklist.matcher import TriggeredRule


@dataclass(frozen=True)
class CheckResult:
    passed: bool
    addressed: list[str]
    missing: list[str]


def check_description(
    triggered_rules: list[TriggeredRule], description: str
) -> CheckResult:
    if not triggered_rules:
        return CheckResult(passed=True, addressed=[], missing=[])

    addressed: list[str] = []
    missing: list[str] = []
    desc_lines = description.split("\n")

    for triggered in triggered_rules:
        for item in triggered.rule.checklist:
            marker = f"<!-- checklist:{item.key} -->"
            found = False

            for line in desc_lines:
                # A line is a match only when it contains BOTH the exact marker
                # AND a checked checkbox on the same line.  We must not break
                # early on an unchecked occurrence: a later line may contain
                # the marker with [x].
                if marker in line and re.search(r"\[x\]", line, re.IGNORECASE):
                    found = True
                    break

            if found:
                addressed.append(item.key)
            else:
                missing.append(item.key)

    passed = len(missing) == 0
    return CheckResult(passed=passed, addressed=addressed, missing=missing)