from __future__ import annotations

import pathlib
from dataclasses import dataclass

import yaml


class ConfigError(Exception):
    """Exception class for configuration validation errors."""


@dataclass(frozen=True)
class ChecklistItem:
    key: str
    text: str


@dataclass(frozen=True)
class Trigger:
    extensions: list[str]
    paths: list[str]
    patterns: list[str]


@dataclass(frozen=True)
class Rule:
    id: str
    name: str
    trigger: Trigger
    checklist: list[ChecklistItem]


@dataclass(frozen=True)
class ChecklistConfig:
    rules: list[Rule]


_RULE_REQUIRED_FIELDS = ("id", "name", "trigger", "checklist")
_TRIGGER_REQUIRED_FIELDS = ("extensions", "paths", "patterns")
_CHECKLIST_ITEM_REQUIRED_FIELDS = ("key", "text")


def load_config(config_path: pathlib.Path) -> ChecklistConfig:
    with open(config_path) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict) or "rules" not in raw:
        raise ConfigError("Configuration missing required key: rules")

    raw_rules = raw["rules"]
    seen_rule_ids: set[str] = set()
    seen_item_keys: set[str] = set()
    rules: list[Rule] = []

    for i, raw_rule in enumerate(raw_rules):
        for field in _RULE_REQUIRED_FIELDS:
            if field not in raw_rule:
                raise ConfigError(
                    f"Rule at index {i} missing required field: {field}"
                )

        rule_id = raw_rule["id"]
        if rule_id in seen_rule_ids:
            raise ConfigError(f"Duplicate rule id: {rule_id}")
        seen_rule_ids.add(rule_id)

        raw_trigger = raw_rule["trigger"]
        for field in _TRIGGER_REQUIRED_FIELDS:
            if field not in raw_trigger:
                raise ConfigError(
                    f"Rule '{rule_id}' trigger missing required field: {field}"
                )

        trigger = Trigger(
            extensions=list(raw_trigger["extensions"]),
            paths=list(raw_trigger["paths"]),
            patterns=list(raw_trigger["patterns"]),
        )

        checklist_items: list[ChecklistItem] = []
        for j, raw_item in enumerate(raw_rule["checklist"]):
            for field in _CHECKLIST_ITEM_REQUIRED_FIELDS:
                if field not in raw_item:
                    raise ConfigError(
                        f"Rule '{rule_id}' checklist item at index {j} "
                        f"missing required field: {field}"
                    )
            item_key = raw_item["key"]
            if item_key in seen_item_keys:
                raise ConfigError(f"Duplicate checklist item key: {item_key}")
            seen_item_keys.add(item_key)
            checklist_items.append(
                ChecklistItem(key=item_key, text=raw_item["text"])
            )

        rules.append(
            Rule(
                id=rule_id,
                name=raw_rule["name"],
                trigger=trigger,
                checklist=checklist_items,
            )
        )

    return ChecklistConfig(rules=rules)