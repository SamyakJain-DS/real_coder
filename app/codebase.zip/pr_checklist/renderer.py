from __future__ import annotations

from pr_checklist.matcher import TriggeredRule


def render_markdown(triggered_rules: list[TriggeredRule]) -> str:
    parts: list[str] = []
    parts.append("## PR Checklist")
    parts.append("")

    if triggered_rules:
        for idx, triggered in enumerate(triggered_rules):
            rule = triggered.rule
            parts.append(f"### {rule.name}")

            file_list = ", ".join(f"`{f}`" for f in triggered.matched_files)
            parts.append(f"_Triggered by: {file_list}_")
            parts.append("")

            for item in rule.checklist:
                parts.append(
                    f"- [ ] {item.text} <!-- checklist:{item.key} -->"
                )

            if idx < len(triggered_rules) - 1:
                parts.append("")
    else:
        parts.append(
            "No checklist items were triggered by the changes in this PR."
        )

    return "\n".join(parts) + "\n"
