"""State Revenue Sales and Use Tax Administration Backend.

Implements the deterministic public workflows described in ``prompt.md``:
filer registration, return processing, audit selection / transitions,
collections, refund processing, and regulatory reporting.

Runtime is local-only; no outbound network access is performed.
"""

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal
from typing import Any


FILER_CATEGORIES: tuple[str, ...] = (
    "IN_STATE_RETAILER",
    "REMOTE_SELLER",
    "MARKETPLACE_FACILITATOR",
    "USE_TAX_FILER",
)

REFUND_CATEGORIES: tuple[str, ...] = (
    "OVERPAYMENT",
    "BAD_DEBT",
    "EXEMPTION_CORRECTION",
    "MARKETPLACE_ADJUSTMENT",
)

COLLECTION_STAGES: tuple[str, ...] = ("NOTICE", "PAYMENT_PLAN", "ENFORCEMENT")

AUDIT_STATUSES: tuple[str, ...] = ("SELECTED", "IN_EXAMINATION", "CLOSED")

REFUND_DECISIONS: tuple[str, ...] = ("OFFSET", "APPROVED")

AUDIT_ACTIONS: tuple[str, ...] = ("BEGIN_EXAM", "CLOSE_EXAM")

_AUDIT_TRANSITIONS: dict[str, tuple[str, str]] = {
    "BEGIN_EXAM": ("SELECTED", "IN_EXAMINATION"),
    "CLOSE_EXAM": ("IN_EXAMINATION", "CLOSED"),
}

_COLLECTION_ACTIONS: dict[str, str] = {
    "NOTICE": "SEND_NOTICE",
    "PAYMENT_PLAN": "OFFER_PAYMENT_PLAN",
    "ENFORCEMENT": "START_ENFORCEMENT",
}

_TWO_PLACES = Decimal("0.01")
_ZERO_2DP = Decimal("0.00")


def _require_fields(payload: Any, required: tuple[str, ...], context: str) -> None:
    """Raise ``ValueError`` listing any missing required fields."""

    if not isinstance(payload, dict):
        raise ValueError(
            f"{context}: expected dict input, got {type(payload).__name__}"
        )
    missing = [field for field in required if field not in payload]
    if missing:
        raise ValueError(
            f"{context}: missing required fields: {missing}"
        )


def _validate_enum(value: Any, allowed: tuple[str, ...], field_name: str) -> None:
    if value not in allowed:
        raise ValueError(
            f"invalid value for '{field_name}': {value!r}; "
            f"expected one of {list(allowed)}"
        )


def _to_decimal(value: Any, field_name: str) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, bool):
        raise ValueError(f"'{field_name}' must be a Decimal-compatible value")
    if isinstance(value, (int, str)):
        try:
            return Decimal(value)
        except Exception as exc:
            raise ValueError(
                f"'{field_name}' is not a valid Decimal: {value!r}"
            ) from exc
    raise ValueError(
        f"'{field_name}' must be a Decimal-compatible value, got {type(value).__name__}"
    )


def _quantize_2dp(value: Decimal) -> Decimal:
    """Quantize a Decimal to two fractional digits, ROUND_HALF_UP."""

    return value.quantize(_TWO_PLACES, rounding=ROUND_HALF_UP)


def _decimal_to_fixed_string(value: Decimal) -> str:
    """Render a Decimal as a fixed-point string preserving the input scale.

    The output excludes scientific or exponent notation and preserves
    trailing zeros that are present in the input ``Decimal``.
    """

    if not isinstance(value, Decimal):
        value = Decimal(value)
    sign, digits, exponent = value.as_tuple()
    if exponent == "n" or exponent == "N" or exponent == "F":
        return str(value)

    digits_str = "".join(str(d) for d in digits) or "0"
    sign_str = "-" if sign else ""

    if isinstance(exponent, int) and exponent >= 0:
        body = digits_str + ("0" * exponent)
        return sign_str + body

    frac_len = -int(exponent)
    if len(digits_str) <= frac_len:
        body = "0." + ("0" * (frac_len - len(digits_str))) + digits_str
    else:
        int_part = digits_str[:-frac_len]
        frac_part = digits_str[-frac_len:]
        body = int_part + "." + frac_part
    return sign_str + body


class TaxAdministrationPlatform:
    """Public backend service class for state revenue tax administration."""

    def __init__(self, rate_table: list[dict]) -> None:
        if not isinstance(rate_table, list):
            raise ValueError("rate_table must be a list of dict entries")

        normalized: list[dict] = []
        rate_lookup: dict[tuple[str, str], dict] = {}
        state_codes: set[str] = set()
        jurisdiction_keys: set[tuple[str, str]] = set()

        for index, entry in enumerate(rate_table):
            _require_fields(
                entry,
                (
                    "destination_state_code",
                    "destination_local_code",
                    "state_rate",
                    "local_rate",
                ),
                f"rate_table[{index}]",
            )
            state_code = entry["destination_state_code"]
            local_code = entry["destination_local_code"]
            state_rate = _to_decimal(
                entry["state_rate"], f"rate_table[{index}].state_rate"
            )
            local_rate = _to_decimal(
                entry["local_rate"], f"rate_table[{index}].local_rate"
            )

            normalized_entry = {
                "destination_state_code": state_code,
                "destination_local_code": local_code,
                "state_rate": state_rate,
                "local_rate": local_rate,
            }
            normalized.append(normalized_entry)
            key = (state_code, local_code)
            # Last-wins for duplicate keys.
            rate_lookup[key] = normalized_entry
            state_codes.add(state_code)
            jurisdiction_keys.add(key)

        self._rate_table: list[dict] = normalized
        self._rate_lookup: dict[tuple[str, str], dict] = rate_lookup
        self._distinct_state_codes: int = len(state_codes)
        self._distinct_jurisdiction_keys: int = len(jurisdiction_keys)

    # ------------------------------------------------------------------
    # Registration workflow
    # ------------------------------------------------------------------
    def register_filer(self, registration: dict) -> dict:
        required = (
            "filer_id",
            "filer_category",
            "annual_gross_sales_usd",
            "annual_transaction_count",
            "nexus_threshold_sales_usd",
            "nexus_threshold_transaction_count",
            "registration_date",
        )
        _require_fields(registration, required, "register_filer")

        filer_category = registration["filer_category"]
        _validate_enum(filer_category, FILER_CATEGORIES, "filer_category")

        annual_gross_sales = _to_decimal(
            registration["annual_gross_sales_usd"], "annual_gross_sales_usd"
        )
        nexus_threshold_sales = _to_decimal(
            registration["nexus_threshold_sales_usd"], "nexus_threshold_sales_usd"
        )
        annual_transaction_count = registration["annual_transaction_count"]
        nexus_threshold_transaction_count = registration[
            "nexus_threshold_transaction_count"
        ]
        if not isinstance(annual_transaction_count, int) or isinstance(
            annual_transaction_count, bool
        ):
            raise ValueError("'annual_transaction_count' must be an int")
        if not isinstance(nexus_threshold_transaction_count, int) or isinstance(
            nexus_threshold_transaction_count, bool
        ):
            raise ValueError("'nexus_threshold_transaction_count' must be an int")

        nexus_by_sales = annual_gross_sales >= nexus_threshold_sales
        nexus_by_transactions = (
            annual_transaction_count >= nexus_threshold_transaction_count
        )
        nexus_eligible = bool(nexus_by_sales or nexus_by_transactions)

        registration_status = "ACTIVE" if nexus_eligible else "PENDING_REVIEW"

        return {
            "filer_id": registration["filer_id"],
            "filer_category": filer_category,
            "nexus_eligible": nexus_eligible,
            "registration_status": registration_status,
            "effective_start_date": registration["registration_date"],
        }

    # ------------------------------------------------------------------
    # Return processing workflow
    # ------------------------------------------------------------------
    def process_return(self, tax_return: dict) -> dict:
        required = ("filer_id", "filer_category", "filing_period", "line_items")
        _require_fields(tax_return, required, "process_return")

        filer_category = tax_return["filer_category"]
        _validate_enum(filer_category, FILER_CATEGORIES, "filer_category")

        line_items = tax_return["line_items"]
        if not isinstance(line_items, list):
            raise ValueError("'line_items' must be a list")

        line_required = (
            "destination_state_code",
            "destination_local_code",
            "taxable_sales_usd",
            "exempt_sales_usd",
        )

        total_taxable = Decimal("0")
        total_exempt = Decimal("0")
        total_tax_due = Decimal("0")

        # key -> aggregated entry preserving first-seen order; we re-sort at end.
        aggregated: dict[tuple[str, str], dict] = {}

        for index, item in enumerate(line_items):
            _require_fields(item, line_required, f"process_return.line_items[{index}]")
            state_code = item["destination_state_code"]
            local_code = item["destination_local_code"]
            taxable = _to_decimal(
                item["taxable_sales_usd"],
                f"line_items[{index}].taxable_sales_usd",
            )
            exempt = _to_decimal(
                item["exempt_sales_usd"],
                f"line_items[{index}].exempt_sales_usd",
            )

            key = (state_code, local_code)
            rate_entry = self._rate_lookup.get(key)
            if rate_entry is None:
                raise ValueError(
                    f"jurisdiction rate not found for key {key}"
                )

            state_rate: Decimal = rate_entry["state_rate"]
            local_rate: Decimal = rate_entry["local_rate"]
            combined_rate = state_rate + local_rate
            line_tax_due = (taxable * combined_rate).quantize(
                _TWO_PLACES, rounding=ROUND_HALF_UP
            )

            total_taxable += taxable
            total_exempt += exempt
            total_tax_due += line_tax_due

            existing = aggregated.get(key)
            if existing is None:
                aggregated[key] = {
                    "destination_state_code": state_code,
                    "destination_local_code": local_code,
                    "state_rate": state_rate,
                    "local_rate": local_rate,
                    # FIX: quantize taxable_sales_usd to 2dp per currency format mandate
                    "taxable_sales_usd": _quantize_2dp(taxable),
                    "line_tax_due_usd": line_tax_due,
                }
            else:
                # FIX: quantize the running sum to 2dp per currency format mandate
                existing["taxable_sales_usd"] = _quantize_2dp(
                    existing["taxable_sales_usd"] + taxable
                )
                existing["line_tax_due_usd"] = (
                    existing["line_tax_due_usd"] + line_tax_due
                )

        breakdown_sorted = sorted(
            aggregated.values(),
            key=lambda e: (e["destination_state_code"], e["destination_local_code"]),
        )

        return {
            "filer_id": tax_return["filer_id"],
            "filer_category": filer_category,
            "filing_period": tax_return["filing_period"],
            "total_taxable_sales_usd": _quantize_2dp(total_taxable)
            if line_items
            else _ZERO_2DP,
            "total_exempt_sales_usd": _quantize_2dp(total_exempt)
            if line_items
            else _ZERO_2DP,
            "total_tax_due_usd": _quantize_2dp(total_tax_due)
            if line_items
            else _ZERO_2DP,
            "jurisdiction_breakdown": breakdown_sorted,
        }

    # ------------------------------------------------------------------
    # Audit workflow
    # ------------------------------------------------------------------
    def select_audit_cases(
        self, candidates: list[dict], target_case_count: int
    ) -> list[dict]:
        if not isinstance(target_case_count, int) or isinstance(
            target_case_count, bool
        ):
            raise ValueError("'target_case_count' must be an int")
        if target_case_count < 0:
            raise ValueError(
                "'target_case_count' must be greater than or equal to 0"
            )
        if not isinstance(candidates, list):
            raise ValueError("'candidates' must be a list")

        candidate_required = (
            "filer_id",
            "risk_score",
            "unpaid_liability_usd",
            "last_return_period",
        )
        normalized_candidates: list[dict] = []
        for index, candidate in enumerate(candidates):
            _require_fields(
                candidate, candidate_required, f"select_audit_cases.candidates[{index}]"
            )
            risk_score = _to_decimal(
                candidate["risk_score"], f"candidates[{index}].risk_score"
            )
            unpaid_liability = _to_decimal(
                candidate["unpaid_liability_usd"],
                f"candidates[{index}].unpaid_liability_usd",
            )
            normalized_candidates.append(
                {
                    "filer_id": candidate["filer_id"],
                    "risk_score": risk_score,
                    "unpaid_liability_usd": unpaid_liability,
                    "last_return_period": candidate["last_return_period"],
                }
            )

        ranked = sorted(
            normalized_candidates,
            key=lambda c: (-c["risk_score"], -c["unpaid_liability_usd"], c["filer_id"]),
        )

        selected_count = min(target_case_count, len(ranked))
        results: list[dict] = []
        for rank_index in range(selected_count):
            candidate = ranked[rank_index]
            risk_str = _decimal_to_fixed_string(candidate["risk_score"])
            liability_str = _decimal_to_fixed_string(candidate["unpaid_liability_usd"])
            results.append(
                {
                    "filer_id": candidate["filer_id"],
                    "rank": rank_index + 1,
                    "audit_status": "SELECTED",
                    "selection_reason": f"RISK={risk_str};LIABILITY={liability_str}",
                }
            )
        return results

    def transition_audit_case(self, audit_case: dict, action: str) -> dict:
        required = ("filer_id", "audit_status", "examiner_id", "findings_summary")
        _require_fields(audit_case, required, "transition_audit_case")

        if action not in AUDIT_ACTIONS:
            raise ValueError(
                f"invalid value for 'action': {action!r}; "
                f"expected one of {list(AUDIT_ACTIONS)}"
            )

        audit_status = audit_case["audit_status"]
        _validate_enum(audit_status, AUDIT_STATUSES, "audit_status")

        source_status, target_status = _AUDIT_TRANSITIONS[action]
        if audit_status != source_status:
            raise ValueError(
                f"invalid transition: action {action!r} requires audit_status "
                f"{source_status!r}, got {audit_status!r}"
            )

        return {
            "filer_id": audit_case["filer_id"],
            "previous_status": audit_status,
            "current_status": target_status,
            "examiner_id": audit_case["examiner_id"],
            "findings_summary": audit_case["findings_summary"],
        }

    # ------------------------------------------------------------------
    # Collections workflow
    # ------------------------------------------------------------------
    def build_collection_actions(self, liabilities: list[dict]) -> list[dict]:
        if not isinstance(liabilities, list):
            raise ValueError("'liabilities' must be a list")

        required = ("filer_id", "unpaid_liability_usd", "days_past_due")
        normalized: list[dict] = []
        for index, item in enumerate(liabilities):
            _require_fields(
                item, required, f"build_collection_actions.liabilities[{index}]"
            )
            days_past_due = item["days_past_due"]
            if not isinstance(days_past_due, int) or isinstance(days_past_due, bool):
                raise ValueError(
                    f"liabilities[{index}].days_past_due must be an int"
                )
            if days_past_due < 0:
                raise ValueError(
                    f"liabilities[{index}].days_past_due must be greater than or equal to 0"
                )
            unpaid = _to_decimal(
                item["unpaid_liability_usd"],
                f"liabilities[{index}].unpaid_liability_usd",
            )
            normalized.append(
                {
                    "filer_id": item["filer_id"],
                    "unpaid_liability_usd": unpaid,
                    "days_past_due": days_past_due,
                }
            )

        normalized.sort(
            key=lambda x: (-x["days_past_due"], -x["unpaid_liability_usd"], x["filer_id"])
        )

        results: list[dict] = []
        for item in normalized:
            days = item["days_past_due"]
            if days <= 30:
                stage = "NOTICE"
            elif days <= 90:
                stage = "PAYMENT_PLAN"
            else:
                stage = "ENFORCEMENT"
            results.append(
                {
                    "filer_id": item["filer_id"],
                    "collection_stage": stage,
                    "collection_action": _COLLECTION_ACTIONS[stage],
                    # FIX: quantize to 2dp per currency format mandate
                    "unpaid_liability_usd": _quantize_2dp(item["unpaid_liability_usd"]),
                    "days_past_due": days,
                }
            )
        return results

    # ------------------------------------------------------------------
    # Refund workflow
    # ------------------------------------------------------------------
    def process_refund_claim(self, claim: dict) -> dict:
        required = (
            "claim_id",
            "filer_id",
            "refund_category",
            "claim_amount_usd",
            "outstanding_liability_usd",
        )
        _require_fields(claim, required, "process_refund_claim")

        _validate_enum(
            claim["refund_category"], REFUND_CATEGORIES, "refund_category"
        )

        claim_amount = _to_decimal(claim["claim_amount_usd"], "claim_amount_usd")
        outstanding = _to_decimal(
            claim["outstanding_liability_usd"], "outstanding_liability_usd"
        )

        if outstanding >= claim_amount:
            decision = "OFFSET"
        else:
            decision = "APPROVED"

        payable = claim_amount - outstanding
        if payable < Decimal("0"):
            payable = Decimal("0")
        offset = claim_amount if claim_amount <= outstanding else outstanding

        return {
            "claim_id": claim["claim_id"],
            "filer_id": claim["filer_id"],
            "decision": decision,
            "payable_amount_usd": _quantize_2dp(payable),
            "offset_amount_usd": _quantize_2dp(offset),
        }

    # ------------------------------------------------------------------
    # Regulatory reporting workflow
    # ------------------------------------------------------------------
    def generate_regulatory_report(
        self,
        reporting_period: str,
        generated_at: str,
        processed_returns: list[dict],
        selected_audits: list[dict],
        collection_actions: list[dict],
        refund_decisions: list[dict],
    ) -> dict:
        if not isinstance(processed_returns, list):
            raise ValueError("'processed_returns' must be a list")
        if not isinstance(selected_audits, list):
            raise ValueError("'selected_audits' must be a list")
        if not isinstance(collection_actions, list):
            raise ValueError("'collection_actions' must be a list")
        if not isinstance(refund_decisions, list):
            raise ValueError("'refund_decisions' must be a list")

        filer_mix_counts = {category: 0 for category in FILER_CATEGORIES}
        total_tax_due = Decimal("0")
        for index, ret in enumerate(processed_returns):
            _require_fields(
                ret,
                ("filer_category", "total_tax_due_usd"),
                f"generate_regulatory_report.processed_returns[{index}]",
            )
            category = ret["filer_category"]
            _validate_enum(category, FILER_CATEGORIES, "filer_category")
            filer_mix_counts[category] += 1
            total_tax_due += _to_decimal(
                ret["total_tax_due_usd"],
                f"processed_returns[{index}].total_tax_due_usd",
            )

        status_counts = {status: 0 for status in AUDIT_STATUSES}
        for index, audit in enumerate(selected_audits):
            _require_fields(
                audit,
                ("audit_status",),
                f"generate_regulatory_report.selected_audits[{index}]",
            )
            audit_status = audit["audit_status"]
            _validate_enum(audit_status, AUDIT_STATUSES, "audit_status")
            status_counts[audit_status] += 1

        stage_counts = {stage: 0 for stage in COLLECTION_STAGES}
        total_unpaid_liability = Decimal("0")
        for index, action in enumerate(collection_actions):
            _require_fields(
                action,
                ("collection_stage", "unpaid_liability_usd"),
                f"generate_regulatory_report.collection_actions[{index}]",
            )
            stage = action["collection_stage"]
            if stage not in COLLECTION_STAGES:
                raise ValueError(
                    f"invalid value for 'collection_stage': {stage!r}; "
                    f"expected one of {list(COLLECTION_STAGES)}"
                )
            stage_counts[stage] += 1
            total_unpaid_liability += _to_decimal(
                action["unpaid_liability_usd"],
                f"collection_actions[{index}].unpaid_liability_usd",
            )

        decision_counts = {decision: 0 for decision in REFUND_DECISIONS}
        total_payable = Decimal("0")
        for index, refund in enumerate(refund_decisions):
            _require_fields(
                refund,
                ("decision", "payable_amount_usd"),
                f"generate_regulatory_report.refund_decisions[{index}]",
            )
            decision = refund["decision"]
            if decision not in REFUND_DECISIONS:
                raise ValueError(
                    f"invalid value for 'decision': {decision!r}; "
                    f"expected one of {list(REFUND_DECISIONS)}"
                )
            decision_counts[decision] += 1
            total_payable += _to_decimal(
                refund["payable_amount_usd"],
                f"refund_decisions[{index}].payable_amount_usd",
            )

        filing_summary = {
            "total_returns_processed": len(processed_returns),
            "filer_mix_counts": filer_mix_counts,
            "total_tax_due_usd": _quantize_2dp(total_tax_due),
        }
        collection_summary = {
            "total_unpaid_liability_usd": _quantize_2dp(total_unpaid_liability),
            "stage_counts": stage_counts,
        }
        audit_summary = {
            "selected_case_count": len(selected_audits),
            "status_counts": status_counts,
        }
        refund_summary = {
            "claim_count": len(refund_decisions),
            "decision_counts": decision_counts,
            "total_payable_amount_usd": _quantize_2dp(total_payable),
        }
        ssuta_summary = {
            "destination_sourcing_applied": True,
            "state_rate_coverage_count": self._distinct_state_codes,
            "local_rate_coverage_count": self._distinct_jurisdiction_keys,
        }
        legislative_auditor_summary = {
            "reporting_period": reporting_period,
            "generated_at": generated_at,
            "metrics_snapshot": {
                "returns_processed": len(processed_returns),
                "audits_selected": len(selected_audits),
                "collection_actions_count": len(collection_actions),
                "refund_decisions_count": len(refund_decisions),
                "total_tax_due_usd": _quantize_2dp(total_tax_due),
                "total_unpaid_liability_usd": _quantize_2dp(total_unpaid_liability),
                "total_payable_amount_usd": _quantize_2dp(total_payable),
            },
        }

        return {
            "reporting_period": reporting_period,
            "filing_summary": filing_summary,
            "collection_summary": collection_summary,
            "audit_summary": audit_summary,
            "refund_summary": refund_summary,
            "ssuta_summary": ssuta_summary,
            "legislative_auditor_summary": legislative_auditor_summary,
        }


__all__ = ["TaxAdministrationPlatform"]