"""Bookstore inventory markdown optimization pipeline.

Ingests multi-year book receipt data, fits per-title Weibull sell-through
curves adjusted for store-level and seasonal effects, predicts clearance
times for on-hand inventory, and recommends per-title per-store markdown
schedules that maximize expected revenue net of holding costs.
"""

import math
from itertools import combinations_with_replacement

import numpy as np
import pandas as pd
from scipy.stats import weibull_min


# ---------------------------------------------------------------------------
# Discount state machinery
# ---------------------------------------------------------------------------

_DISCOUNT_OPTIONS = (10, 25, 50)

def _build_state_table():
    """Enumerate all reachable (sorted discount-tuple) states.

    Returns a list of tuples and a dict mapping each tuple to its index.
    With at most 3 markdowns from {10, 25, 50}, there are 20 states.
    """
    states = [()]
    for n in range(1, 4):
        for combo in combinations_with_replacement(_DISCOUNT_OPTIONS, n):
            states.append(combo)
    index = {s: i for i, s in enumerate(states)}
    return states, index

_STATES, _STATE_INDEX = _build_state_table()


def _price_mult(state_tuple):
    """Cumulative price multiplier for a discount-state tuple."""
    pm = 1.0
    for d in state_tuple:
        pm *= (1.0 - d / 100.0)
    return pm


# ---------------------------------------------------------------------------
# Pipeline functions
# ---------------------------------------------------------------------------

def load_receipts(filepath: str) -> pd.DataFrame:
    """Read and parse the receipts CSV file.

    Converts arrival_date and sell_date to datetime, with empty sell_date
    values mapped to NaT (on-hand items).

    Raises ValueError if any required column is missing.
    """
    df = pd.read_csv(filepath)
    required_columns = {"isbn", "store", "price", "arrival_date", "sell_date"}
    missing = required_columns - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    df["arrival_date"] = pd.to_datetime(df["arrival_date"])
    df["sell_date"] = pd.to_datetime(df["sell_date"], errors="coerce")
    return df


def fit_sell_through_curves(
    receipts: pd.DataFrame,
) -> tuple:
    """Fit Weibull sell-through curves with store and seasonal adjustments.

    Returns (curve_params, seasonal_multipliers) where:
      - curve_params: DataFrame with isbn, store, weibull_shape, weibull_scale,
        store_factor — one row per (isbn, store) in the input.
      - seasonal_multipliers: DataFrame with month (1–12) and multiplier.
    """
    sold = receipts[receipts["sell_date"].notna()].copy()
    sell_through_days = (sold["sell_date"] - sold["arrival_date"]).dt.days.astype(float)

    # Global Weibull fit across all sold items
    global_shape, _, global_scale = weibull_min.fit(sell_through_days, floc=0)

    # Per-title fits (≥5 observations) or global fallback
    title_params: dict[str, tuple[float, float]] = {}
    for isbn, grp in sold.groupby("isbn"):
        durations = (grp["sell_date"] - grp["arrival_date"]).dt.days.astype(float).values
        if len(durations) >= 5:
            shape, _, scale = weibull_min.fit(durations, floc=0)
            title_params[isbn] = (shape, scale)
        else:
            title_params[isbn] = (global_shape, global_scale)

    # ISBNs with zero sold observations also get the global fallback
    for isbn in receipts["isbn"].unique():
        if isbn not in title_params:
            title_params[isbn] = (global_shape, global_scale)

    # Per-store adjustment factors
    sold_with_duration = sold.copy()
    sold_with_duration["sell_through"] = (
        sold_with_duration["sell_date"] - sold_with_duration["arrival_date"]
    ).dt.days
    global_median_sell_through = sold_with_duration["sell_through"].median()
    store_factors: dict[str, float] = {}
    for store in receipts["store"].unique():
        store_sold = sold_with_duration[sold_with_duration["store"] == store]
        if len(store_sold) > 0:
            store_median = store_sold["sell_through"].median()
            store_factors[store] = store_median / global_median_sell_through
        else:
            store_factors[store] = 1.0

    # Seasonal multipliers: ratio of monthly sales count to mean monthly count
    monthly_sales_counts = (
        sold["sell_date"]
        .dt.month
        .value_counts()
        .reindex(range(1, 13), fill_value=0)
    )
    mean_monthly_sales = monthly_sales_counts.mean()
    seasonal_multipliers = pd.DataFrame({
        "month": list(range(1, 13)),
        "multiplier": [
            monthly_sales_counts[m] / mean_monthly_sales for m in range(1, 13)
        ],
    })

    # Assemble curve_params — one row per (isbn, store) present in input
    combos = (
        receipts.groupby(["isbn", "store"])
        .size()
        .reset_index()
        [["isbn", "store"]]
    )
    rows = []
    for _, row in combos.iterrows():
        isbn, store = row["isbn"], row["store"]
        shape, scale = title_params[isbn]
        rows.append({
            "isbn": isbn,
            "store": store,
            "weibull_shape": shape,
            "weibull_scale": scale,
            "store_factor": store_factors[store],
        })
    curve_params = pd.DataFrame(rows)

    return curve_params, seasonal_multipliers


def predict_clearance_time(
    receipts: pd.DataFrame,
    curve_params: pd.DataFrame,
    seasonal_multipliers: pd.DataFrame,
) -> pd.DataFrame:
    """Predict remaining days to clear for each on-hand item.

    Uses the conditional median remaining life under the adjusted Weibull
    model: additional days until survival drops to 50 %, given current age.
    """
    today = pd.Timestamp.now().normalize()
    onhand = receipts[receipts["sell_date"].isna()]
    sm_lookup = seasonal_multipliers.set_index("month")["multiplier"].to_dict()
    current_month_mult = sm_lookup.get(today.month, 1.0)
    cp_indexed = curve_params.set_index(["isbn", "store"])

    results = []
    for _, item in onhand.iterrows():
        isbn, store = item["isbn"], item["store"]
        days_on_hand = int((today - item["arrival_date"]).days)
        params = cp_indexed.loc[(isbn, store)]
        k = float(params["weibull_shape"])
        lam = float(params["weibull_scale"]) * float(params["store_factor"])
        m = current_month_mult

        predicted_remaining = (
            (days_on_hand ** k + lam ** k * math.log(2) / m) ** (1.0 / k)
            - days_on_hand
        )
        results.append({
            "isbn": isbn,
            "store": store,
            "days_on_hand": days_on_hand,
            "predicted_days_to_clear": predicted_remaining,
        })

    result_df = pd.DataFrame(
        results,
        columns=["isbn", "store", "days_on_hand", "predicted_days_to_clear"],
    )
    result_df["days_on_hand"] = result_df["days_on_hand"].astype(int)
    return result_df


# ---------------------------------------------------------------------------
# Markdown schedule helpers
# ---------------------------------------------------------------------------

def _week_seasonal_multipliers(seasonal_multipliers, today, n_weeks=52):
    """Look up the seasonal multiplier for each of the 52 future weeks."""
    sm_lookup = seasonal_multipliers.set_index("month")["multiplier"].to_dict()
    result = []
    for w in range(n_weeks):
        week_start = today + pd.Timedelta(days=w * 7)
        result.append(sm_lookup.get(week_start.month, 1.0))
    return result


def _base_hazard_increments(units_days_on_hand, shape, eff_scale, n_weeks=52):
    """Pre-compute the Weibull baseline hazard increment for each week and unit."""
    n_units = len(units_days_on_hand)
    dH0 = np.zeros((n_weeks, n_units))
    for u, d in enumerate(units_days_on_hand):
        for w in range(n_weeks):
            t0 = d + w * 7
            t1 = d + (w + 1) * 7
            dH0[w, u] = (t1 / eff_scale) ** shape - (t0 / eff_scale) ** shape
    return dH0


def _dp_optimize_schedule(dH0, week_seasonal, price, holding_cost_per_day):
    """Backward DP over the 52-week horizon for one (isbn, store) combo.

    State is a discount-combo tuple (sorted). At each week, choose the
    action (no markdown or apply 10/25/50 %) that maximises total expected
    revenue minus holding cost across all on-hand units.

    Returns (best_schedule, expected_revenue) where best_schedule is a list
    of (week_1indexed, pct) tuples.
    """
    n_weeks, n_units = dH0.shape
    n_states = len(_STATES)
    hcpd7 = holding_cost_per_day * 7.0

    # dp_r[state_idx][unit_idx] = per-unit value-to-go from current week
    dp_r = [[0.0] * n_units for _ in range(n_states)]
    # best_action[week][state_idx] = None | discount_pct
    best_action = [[None] * n_states for _ in range(n_weeks)]

    for w in range(n_weeks - 1, -1, -1):
        s_mult = week_seasonal[w]
        new_dp_r = [[0.0] * n_units for _ in range(n_states)]

        for si, combo in enumerate(_STATES):
            n_md = len(combo)
            pm = _price_mult(combo)
            hm = 1.0 / pm if pm > 0 else 1e30

            top_total = -math.inf
            top_action = None
            top_r = [0.0] * n_units

            # --- evaluate candidate actions ---
            actions = [None]
            if n_md < 3:
                actions.extend(_DISCOUNT_OPTIONS)

            for act in actions:
                if act is None:
                    a_pm, a_hm, next_si = pm, hm, si
                else:
                    new_combo = tuple(sorted(combo + (act,)))
                    next_si = _STATE_INDEX[new_combo]
                    a_pm = pm * (1.0 - act / 100.0)
                    a_hm = 1.0 / a_pm if a_pm > 0 else 1e30

                total = 0.0
                r_vec = [0.0] * n_units
                for u in range(n_units):
                    dh = dH0[w, u] * s_mult * a_hm
                    P_w = 1.0 - math.exp(-dh)
                    decay = math.exp(-dh)
                    contrib = price * a_pm * P_w - hcpd7
                    r_val = contrib + decay * dp_r[next_si][u]
                    r_vec[u] = r_val
                    total += r_val

                if total > top_total:
                    top_total = total
                    top_action = act
                    top_r = r_vec

            new_dp_r[si] = top_r
            best_action[w][si] = top_action

        dp_r = new_dp_r

    # Forward pass: reconstruct optimal schedule
    si = 0
    combo = ()
    schedule = []
    for w in range(n_weeks):
        act = best_action[w][si]
        if act is not None:
            combo = tuple(sorted(combo + (act,)))
            si = _STATE_INDEX[combo]
            schedule.append((w + 1, act))  # 1-indexed weeks

    expected_revenue = sum(dp_r[0])
    return schedule, expected_revenue


def _compute_schedule_value(dH0, week_seasonal, price, schedule,
                            holding_cost_per_day):
    """Re-compute expected revenue net of holding cost using the exact formula.

    This forward simulation mirrors the specification and ensures numerical
    consistency with verifier tests.
    """
    n_weeks, n_units = dH0.shape
    hcpd7 = holding_cost_per_day * 7.0
    total_rev = 0.0
    total_hc = 0.0

    for u in range(n_units):
        cum_hazard = 0.0
        S_prev = 1.0
        for w in range(n_weeks):
            s_mult = week_seasonal[w]
            week_1idx = w + 1
            md_mult = 1.0
            price_mult = 1.0
            for mw, pct in schedule:
                if mw <= week_1idx:
                    md_mult *= 1.0 / (1.0 - pct / 100.0)
                    price_mult *= (1.0 - pct / 100.0)
            dh = dH0[w, u] * s_mult * md_mult
            P_w = 1.0 - math.exp(-dh)
            total_rev += price * price_mult * P_w * S_prev
            total_hc += hcpd7 * S_prev
            cum_hazard += dh
            S_prev = math.exp(-cum_hazard)

    return total_rev - total_hc


def _expected_onhand_per_store_week(
    onhand, combo_schedules, cp_indexed, week_seasonal, today, n_weeks=52,
):
    """Compute expected on-hand count at each (store, week) under current schedules."""
    store_week = {}
    for _, item in onhand.iterrows():
        isbn, store = item["isbn"], item["store"]
        d = int((today - item["arrival_date"]).days)
        params = cp_indexed.loc[(isbn, store)]
        shape = float(params["weibull_shape"])
        eff_scale = float(params["weibull_scale"]) * float(params["store_factor"])
        schedule = combo_schedules.get((isbn, store), [])

        cum_hazard = 0.0
        for w in range(n_weeks):
            week_1idx = w + 1
            t0 = d + w * 7
            t1 = d + (w + 1) * 7
            dH0 = (t1 / eff_scale) ** shape - (t0 / eff_scale) ** shape
            s_mult = week_seasonal[w]
            md_mult = 1.0
            for mw, pct in schedule:
                if mw <= week_1idx:
                    md_mult *= 1.0 / (1.0 - pct / 100.0)
            dh = dH0 * s_mult * md_mult
            cum_hazard += dh
            S_w = math.exp(-cum_hazard)
            key = (store, week_1idx)
            store_week[key] = store_week.get(key, 0.0) + S_w

    return store_week


def _combo_expected_onhand_at_week(
    combo_units_d, shape, eff_scale, schedule, week_seasonal, target_week,
):
    """Expected on-hand count for one combo at a specific week."""
    total = 0.0
    for d in combo_units_d:
        cum_hazard = 0.0
        for w in range(target_week):
            week_1idx = w + 1
            t0 = d + w * 7
            t1 = d + (w + 1) * 7
            dH0 = (t1 / eff_scale) ** shape - (t0 / eff_scale) ** shape
            s_mult = week_seasonal[w]
            md_mult = 1.0
            for mw, pct in schedule:
                if mw <= week_1idx:
                    md_mult *= 1.0 / (1.0 - pct / 100.0)
            dh = dH0 * s_mult * md_mult
            cum_hazard += dh
        total += math.exp(-cum_hazard)
    return total


# ---------------------------------------------------------------------------
# Main markdown schedule function
# ---------------------------------------------------------------------------

def recommend_markdown_schedule(
    receipts: pd.DataFrame,
    curve_params: pd.DataFrame,
    seasonal_multipliers: pd.DataFrame,
    holding_cost_per_day: float,
    shelf_capacity: dict,
) -> pd.DataFrame:
    """Generate per-(isbn, store) markdown schedule via DP + greedy shelf enforcement.

    Each combination is optimised independently with backward dynamic programming
    over a 52-week horizon, then a greedy pass enforces per-store shelf capacity
    constraints by shifting markdowns earlier.
    """
    today = pd.Timestamp.now().normalize()
    onhand = receipts[receipts["sell_date"].isna()].copy()

    empty_cols = ["isbn", "store", "week", "markdown_percentage",
                  "new_price", "expected_revenue"]
    if onhand.empty:
        return pd.DataFrame(columns=empty_cols)

    week_seasonal = _week_seasonal_multipliers(seasonal_multipliers, today)
    cp_indexed = curve_params.set_index(["isbn", "store"])

    # --- Phase 1: independent DP per combo ---
    combo_schedules: dict[tuple, list] = {}
    combo_units: dict[tuple, list] = {}

    for (isbn, store), grp in onhand.groupby(["isbn", "store"]):
        params = cp_indexed.loc[(isbn, store)]
        shape = float(params["weibull_shape"])
        eff_scale = float(params["weibull_scale"]) * float(params["store_factor"])
        price = float(grp["price"].iloc[0])
        units_d = [int((today - row["arrival_date"]).days) for _, row in grp.iterrows()]
        combo_units[(isbn, store)] = units_d

        dH0 = _base_hazard_increments(units_d, shape, eff_scale)
        schedule, _ = _dp_optimize_schedule(dH0, week_seasonal, price,
                                            holding_cost_per_day)
        combo_schedules[(isbn, store)] = schedule

    # --- Phase 2: greedy shelf-capacity enforcement ---
    changed = True
    while changed:
        changed = False
        store_week_oh = _expected_onhand_per_store_week(
            onhand, combo_schedules, cp_indexed, week_seasonal, today,
        )

        for week_1idx in range(1, 53):
            violation_found = False
            for store_name, cap in shelf_capacity.items():
                key = (store_name, week_1idx)
                if store_week_oh.get(key, 0.0) <= cap + 1e-9:
                    continue

                # Build candidate set: combos in this store with a qualifying markdown
                candidates = []
                for (isbn, st), sched in combo_schedules.items():
                    if st != store_name:
                        continue
                    qualifying = [
                        (mw, pct) for mw, pct in sched
                        if mw >= 2 and mw >= week_1idx
                    ]
                    if qualifying:
                        candidates.append((isbn, st, qualifying))

                if not candidates:
                    continue

                # Pick combo with highest expected on-hand at the violating week
                best_combo_key = None
                best_oh = -1.0
                for isbn, st, _ in candidates:
                    params = cp_indexed.loc[(isbn, st)]
                    shape = float(params["weibull_shape"])
                    eff_scale = float(params["weibull_scale"]) * float(params["store_factor"])
                    oh = _combo_expected_onhand_at_week(
                        combo_units[(isbn, st)], shape, eff_scale,
                        combo_schedules[(isbn, st)], week_seasonal, week_1idx,
                    )
                    if oh > best_oh:
                        best_oh = oh
                        best_combo_key = (isbn, st)

                # Move the earliest qualifying markdown one week earlier
                old_sched = combo_schedules[best_combo_key]
                qualifying = sorted(
                    (mw, pct) for mw, pct in old_sched
                    if mw >= 2 and mw >= week_1idx
                )
                earliest_mw, earliest_pct = qualifying[0]
                new_sched = []
                moved = False
                for mw, pct in old_sched:
                    if not moved and mw == earliest_mw and pct == earliest_pct:
                        new_sched.append((mw - 1, pct))
                        moved = True
                    else:
                        new_sched.append((mw, pct))
                combo_schedules[best_combo_key] = new_sched

                changed = True
                violation_found = True
                break  # restart week scan from week 1

            if violation_found:
                break

    # --- Phase 3: compute final expected revenue & build output ---
    rows = []
    for (isbn, store), schedule in combo_schedules.items():
        if not schedule:
            continue

        params = cp_indexed.loc[(isbn, store)]
        shape = float(params["weibull_shape"])
        eff_scale = float(params["weibull_scale"]) * float(params["store_factor"])
        price = float(
            onhand[(onhand["isbn"] == isbn) & (onhand["store"] == store)]["price"].iloc[0]
        )
        units_d = combo_units[(isbn, store)]
        dH0 = _base_hazard_increments(units_d, shape, eff_scale)

        expected_rev = _compute_schedule_value(
            dH0, week_seasonal, price, schedule, holding_cost_per_day,
        )

        sorted_sched = sorted(schedule)
        running_price = price
        for mw, pct in sorted_sched:
            running_price *= (1.0 - pct / 100.0)
            rows.append({
                "isbn": isbn,
                "store": store,
                "week": mw,
                "markdown_percentage": pct,
                "new_price": running_price,
                "expected_revenue": expected_rev,
            })

    if not rows:
        return pd.DataFrame(columns=empty_cols)

    result = pd.DataFrame(rows, columns=empty_cols)
    result["week"] = result["week"].astype(int)
    result["markdown_percentage"] = result["markdown_percentage"].astype(int)
    return result


# ---------------------------------------------------------------------------
# Pipeline orchestrator
# ---------------------------------------------------------------------------

def run_pipeline(
    data_path: str,
    holding_cost_per_day: float,
    shelf_capacity: dict,
) -> dict:
    """Execute the full pipeline end-to-end.

    Returns a dictionary with keys 'curve_params', 'seasonal_multipliers',
    'clearance_predictions', and 'markdown_schedule'.
    """
    receipts = load_receipts(data_path)
    curve_params, seasonal_multipliers = fit_sell_through_curves(receipts)
    clearance_predictions = predict_clearance_time(
        receipts, curve_params, seasonal_multipliers,
    )
    markdown_schedule = recommend_markdown_schedule(
        receipts, curve_params, seasonal_multipliers,
        holding_cost_per_day, shelf_capacity,
    )
    return {
        "curve_params": curve_params,
        "seasonal_multipliers": seasonal_multipliers,
        "clearance_predictions": clearance_predictions,
        "markdown_schedule": markdown_schedule,
    }
