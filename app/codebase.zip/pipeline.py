import os

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

# ---------------------------------------------------------------------------
# Constants shared across several functions
# ---------------------------------------------------------------------------

_DISCIPLINE_HOURS_COLS = [
    "developmental_therapy_hours",
    "speech_hours",
    "occupational_hours",
    "physical_hours",
    "social_work_hours",
]

_DISCIPLINE_SETTING_COLS = [
    "developmental_therapy_setting",
    "speech_setting",
    "occupational_setting",
    "physical_setting",
    "social_work_setting",
]

_DISCIPLINE_NAMES = [
    "developmental_therapy",
    "speech",
    "occupational",
    "physical",
    "social_work",
]

_REQUIRED_COLUMNS = [
    "child_id",
    "eligibility_pathway",
    "severity_at_intake",
    "developmental_therapy_hours",
    "speech_hours",
    "occupational_hours",
    "physical_hours",
    "social_work_hours",
    "developmental_therapy_setting",
    "speech_setting",
    "occupational_setting",
    "physical_setting",
    "social_work_setting",
    "provider_id",
    "c1_entry_score",
    "c1_exit_score",
    "c2_entry_score",
    "c2_exit_score",
    "c3_entry_score",
    "c3_exit_score",
    "transitioned_to_school_district",
    "transition_age_months",
    "enrollment_year",
    "functional_gain_score",
]


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _home_setting_rate(df: pd.DataFrame) -> float:
    """
    Proportion of (child, discipline) pairs where the discipline's weekly
    hours are > 0 and the corresponding setting column equals 'home', out of
    all (child, discipline) pairs where the discipline's weekly hours are > 0.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain _DISCIPLINE_HOURS_COLS and _DISCIPLINE_SETTING_COLS.

    Returns
    -------
    float
    """
    home_count = 0
    active_count = 0
    for hours_col, setting_col in zip(_DISCIPLINE_HOURS_COLS, _DISCIPLINE_SETTING_COLS):
        active_mask = df[hours_col] > 0
        active_count += active_mask.sum()
        home_count += (active_mask & (df[setting_col] == "home")).sum()
    return float(home_count / active_count) if active_count > 0 else 0.0


# ---------------------------------------------------------------------------
# 1. load_data
# ---------------------------------------------------------------------------

def load_data(filepath: str) -> pd.DataFrame:
    """
    Read the CSV at *filepath* and return a DataFrame containing all 24
    required columns.

    Parameters
    ----------
    filepath : str
        Path to the CSV file.

    Returns
    -------
    pd.DataFrame
        One row per child, all 24 required columns present.

    Raises
    ------
    FileNotFoundError
        When *filepath* does not exist.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Data file not found: {filepath}")

    df = pd.read_csv(filepath)
    return df


# ---------------------------------------------------------------------------
# 2. compute_eligibility_summary
# ---------------------------------------------------------------------------

def compute_eligibility_summary(df: pd.DataFrame) -> dict:
    """
    Count children by eligibility pathway.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    dict
        Keys ``developmental_delay`` and ``established_condition``, each
        mapping to the integer count of children in that pathway.  The two
        values sum to the total number of rows in *df*.
    """
    counts = df["eligibility_pathway"].value_counts()
    return {
        "developmental_delay": int(counts.get("developmental_delay", 0)),
        "established_condition": int(counts.get("established_condition", 0)),
    }


# ---------------------------------------------------------------------------
# 3. estimate_service_intensity
# ---------------------------------------------------------------------------

def estimate_service_intensity(df: pd.DataFrame) -> pd.DataFrame:
    """
    Assign each child to a severity quartile (1 = lowest, 4 = highest) using
    four equal-frequency bins of ``severity_at_intake``.  For each combination
    of (severity quartile, discipline) compute the mean weekly hours.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    pd.DataFrame
        Columns: ``severity_quartile`` (int, 1–4), ``discipline`` (str),
        ``mean_hours`` (float).  Exactly 20 rows (4 quartiles × 5 disciplines).
    """
    working = df.copy()

    # Equal-frequency (quantile-based) bins; labels 1..4
    working["severity_quartile"] = pd.qcut(
        working["severity_at_intake"],
        q=4,
        labels=[1, 2, 3, 4],
        duplicates="drop",
    ).astype(int)

    records = []
    for quartile in [1, 2, 3, 4]:
        subset = working[working["severity_quartile"] == quartile]
        for discipline, hours_col in zip(_DISCIPLINE_NAMES, _DISCIPLINE_HOURS_COLS):
            records.append(
                {
                    "severity_quartile": int(quartile),
                    "discipline": discipline,
                    "mean_hours": float(subset[hours_col].mean()),
                }
            )

    result = pd.DataFrame(records, columns=["severity_quartile", "discipline", "mean_hours"])
    return result


# ---------------------------------------------------------------------------
# 4. identify_provider_patterns
# ---------------------------------------------------------------------------

def identify_provider_patterns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Group children by ``provider_id`` and compute summary statistics.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    pd.DataFrame
        Columns: ``provider_id`` (str), ``mean_functional_gain`` (float),
        ``mean_severity_at_intake`` (float), ``child_count`` (int).
        One row per provider.  The sum of all ``child_count`` values equals
        the total number of rows in *df*.
    """
    grouped = (
        df.groupby("provider_id", as_index=False)
        .agg(
            mean_functional_gain=("functional_gain_score", "mean"),
            mean_severity_at_intake=("severity_at_intake", "mean"),
            child_count=("child_id", "count"),
        )
    )
    grouped["child_count"] = grouped["child_count"].astype(int)
    return grouped[["provider_id", "mean_functional_gain", "mean_severity_at_intake", "child_count"]]


# ---------------------------------------------------------------------------
# 5. compute_part_c_indicators
# ---------------------------------------------------------------------------

def compute_part_c_indicators(df: pd.DataFrame) -> dict:
    """
    Compute the six federal Part C performance indicators.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    dict
        Keys: ``c1_mean_gain``, ``c2_mean_gain``, ``c3_mean_gain``
        (mean exit minus entry scores), ``transition_rate`` (0.0–1.0),
        ``mean_transition_age_months`` (mean for transitioned children),
        ``home_setting_rate`` (0.0–1.0).
    """
    c1_mean_gain = float((df["c1_exit_score"] - df["c1_entry_score"]).mean())
    c2_mean_gain = float((df["c2_exit_score"] - df["c2_entry_score"]).mean())
    c3_mean_gain = float((df["c3_exit_score"] - df["c3_entry_score"]).mean())

    transition_rate = float(df["transitioned_to_school_district"].mean())

    transitioned_df = df[df["transitioned_to_school_district"]]
    mean_transition_age_months = float(transitioned_df["transition_age_months"].mean())

    home_rate = _home_setting_rate(df)

    return {
        "c1_mean_gain": c1_mean_gain,
        "c2_mean_gain": c2_mean_gain,
        "c3_mean_gain": c3_mean_gain,
        "transition_rate": transition_rate,
        "mean_transition_age_months": mean_transition_age_months,
        "home_setting_rate": home_rate,
    }


# ---------------------------------------------------------------------------
# 6. distinguish_quality_from_characteristics
# ---------------------------------------------------------------------------

def distinguish_quality_from_characteristics(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fit a linear regression of ``functional_gain_score`` on
    ``severity_at_intake`` and the five discipline hour columns, then compute
    the per-child residual (actual minus predicted).

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    pd.DataFrame
        Columns: ``child_id`` (str), ``provider_id`` (str),
        ``severity_at_intake`` (float), ``functional_gain_score`` (float),
        ``residual_gain`` (float).
        The sum of all ``residual_gain`` values equals zero (OLS property).
    """
    feature_cols = ["severity_at_intake"] + _DISCIPLINE_HOURS_COLS
    X = df[feature_cols].values
    y = df["functional_gain_score"].values

    model = LinearRegression()
    model.fit(X, y)

    predicted = model.predict(X)
    residual_gain = y - predicted

    result = pd.DataFrame(
        {
            "child_id": df["child_id"].values,
            "provider_id": df["provider_id"].values,
            "severity_at_intake": df["severity_at_intake"].values,
            "functional_gain_score": df["functional_gain_score"].values,
            "residual_gain": residual_gain,
        }
    )
    return result


# ---------------------------------------------------------------------------
# 7. rank_providers_adjusted
# ---------------------------------------------------------------------------

def rank_providers_adjusted(residuals_df: pd.DataFrame) -> pd.DataFrame:
    """
    Group rows by ``provider_id`` and compute mean residual gain and child
    count per provider.

    Parameters
    ----------
    residuals_df : pd.DataFrame
        The DataFrame returned by :func:`distinguish_quality_from_characteristics`.

    Returns
    -------
    pd.DataFrame
        Columns: ``provider_id`` (str), ``mean_residual_gain`` (float),
        ``child_count`` (int).  One row per provider.  The sum of all
        ``child_count`` values equals the total number of rows in
        *residuals_df*.
    """
    grouped = (
        residuals_df.groupby("provider_id", as_index=False)
        .agg(
            mean_residual_gain=("residual_gain", "mean"),
            child_count=("child_id", "count"),
        )
    )
    grouped["child_count"] = grouped["child_count"].astype(int)
    return grouped[["provider_id", "mean_residual_gain", "child_count"]]


# ---------------------------------------------------------------------------
# 8. compute_annual_trends
# ---------------------------------------------------------------------------

def compute_annual_trends(df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregate key metrics by ``enrollment_year``.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    pd.DataFrame
        Columns: ``enrollment_year`` (int), ``child_count`` (int),
        ``mean_functional_gain`` (float), ``transition_rate`` (float),
        ``home_setting_rate`` (float), ``c1_mean_gain`` (float),
        ``c2_mean_gain`` (float), ``c3_mean_gain`` (float).
        One row per distinct ``enrollment_year``.
    """
    records = []
    for year, group in df.groupby("enrollment_year"):
        records.append(
            {
                "enrollment_year": int(year),
                "child_count": int(len(group)),
                "mean_functional_gain": float(group["functional_gain_score"].mean()),
                "transition_rate": float(group["transitioned_to_school_district"].mean()),
                "home_setting_rate": _home_setting_rate(group),
                "c1_mean_gain": float(
                    (group["c1_exit_score"] - group["c1_entry_score"]).mean()
                ),
                "c2_mean_gain": float(
                    (group["c2_exit_score"] - group["c2_entry_score"]).mean()
                ),
                "c3_mean_gain": float(
                    (group["c3_exit_score"] - group["c3_entry_score"]).mean()
                ),
            }
        )

    result = pd.DataFrame(
        records,
        columns=[
            "enrollment_year",
            "child_count",
            "mean_functional_gain",
            "transition_rate",
            "home_setting_rate",
            "c1_mean_gain",
            "c2_mean_gain",
            "c3_mean_gain",
        ],
    )
    return result


# ---------------------------------------------------------------------------
# 9. estimate_discipline_outcomes
# ---------------------------------------------------------------------------

def estimate_discipline_outcomes(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fit a multivariate linear regression of ``functional_gain_score`` on the
    five discipline hour columns with ``severity_at_intake`` as a covariate.
    Return the partial regression coefficient for each discipline's hours.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    pd.DataFrame
        Columns: ``discipline`` (str), ``estimated_hours_coefficient`` (float).
        Exactly 5 rows (one per discipline).  Each coefficient represents the
        estimated change in ``functional_gain_score`` per additional weekly
        hour of that discipline after controlling for severity at intake.
    """
    feature_cols = _DISCIPLINE_HOURS_COLS + ["severity_at_intake"]
    X = df[feature_cols].values
    y = df["functional_gain_score"].values

    model = LinearRegression()
    model.fit(X, y)

    # Coefficients correspond to the order in feature_cols; the last one is
    # severity_at_intake (covariate), which we exclude from the output.
    n_disciplines = len(_DISCIPLINE_NAMES)
    discipline_coefficients = model.coef_[:n_disciplines]

    result = pd.DataFrame(
        {
            "discipline": _DISCIPLINE_NAMES,
            "estimated_hours_coefficient": discipline_coefficients.tolist(),
        }
    )
    return result