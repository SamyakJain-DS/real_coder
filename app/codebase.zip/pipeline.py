import os

import pandas as pd

from access_analyzer import identify_access_reduction_patterns
from equity_analyzer import attribute_health_equity_impact
from estimator import estimate_single_payment_amount
from reporter import generate_performance_report, generate_recommendation_packet


def run_pipeline(data_dir: str) -> dict:
    # -- Step 1: load all eight CSV files ------------------------------------
    cba_pricing         = pd.read_csv(os.path.join(data_dir, "cba_pricing.csv"))
    supplier_bids       = pd.read_csv(os.path.join(data_dir, "supplier_bids.csv"))
    claims              = pd.read_csv(os.path.join(data_dir, "claims.csv"))
    beneficiary_enrollment = pd.read_csv(os.path.join(data_dir, "beneficiary.csv"))
    cba_classifications = pd.read_csv(os.path.join(data_dir, "cba_classification.csv"))
    gap_fill_pricing    = pd.read_csv(os.path.join(data_dir, "gap_fill_pricing.csv"))
    lcd_data            = pd.read_csv(os.path.join(data_dir, "lcd_data.csv"))
    contractor_inquiries = pd.read_csv(os.path.join(data_dir, "contractor_inquiries.csv"))

    # -- Step 2: estimate single payment amounts ------------------------------
    spa_estimates = estimate_single_payment_amount(cba_pricing, supplier_bids)

    # -- Step 3: identify beneficiary access reduction patterns ---------------
    access_patterns = identify_access_reduction_patterns(claims, supplier_bids)

    # -- Step 4: attribute health equity impact -------------------------------
    equity_impacts = attribute_health_equity_impact(
        access_patterns, cba_classifications, beneficiary_enrollment
    )

    # -- Step 5: generate performance report ----------------------------------
    performance_report = generate_performance_report(
        spa_estimates,
        access_patterns,
        equity_impacts,
        lcd_data,
        contractor_inquiries,
    )

    # -- Step 6: generate recommendation packet -------------------------------
    recommendation_packet = generate_recommendation_packet(
        spa_estimates, access_patterns, gap_fill_pricing
    )

    # -- Step 7: assemble and return combined result dict ---------------------
    return {
        "single_payment_amounts": performance_report["single_payment_amounts"],
        "access_patterns":        performance_report["access_patterns"],
        "equity_impacts":         performance_report["equity_impacts"],
        "lcd_determinations":     performance_report["lcd_determinations"],
        "contractor_inquiries":   performance_report["contractor_inquiries"],
        "recommendations":        recommendation_packet,
    }


if __name__ == "__main__":
    run_pipeline("data/")