"""Menu Engineering Analysis Pipeline.

Reads a year of point-of-sale transaction data, classifies each menu item into
one of four quadrants based on seasonality-adjusted popularity and contribution
margin, detects items whose quadrant has shifted in the last 13 weeks, and
writes a plain-text menu redesign brief.
"""

import os

import pandas as pd


SUGGESTIONS = {
    "star": "Maintain prominence and protect margins",
    "plowhorse": "Reduce portion cost or reposition to increase margin",
    "puzzle": "Increase visibility and promotion to boost sales volume",
    "dog": "Consider removing or repositioning this item",
}


def load_pos_data(filepath):
    """Read the POS CSV and parse the date column as a pandas datetime."""
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"POS data file not found: {filepath}")
    df = pd.read_csv(filepath)
    df["date"] = pd.to_datetime(df["date"])
    return df


def _classify(adjusted_pop, contribution_margin, pop_median, margin_median):
    pop_high = adjusted_pop >= pop_median
    margin_high = contribution_margin >= margin_median
    if pop_high and margin_high:
        return "star"
    if pop_high and not margin_high:
        return "plowhorse"
    if not pop_high and margin_high:
        return "puzzle"
    return "dog"


def _seasonal_indices(df):
    months = df["date"].dt.month
    monthly_totals = df.groupby(months)["quantity"].sum()
    monthly_totals = monthly_totals.reindex(range(1, 13), fill_value=0)
    mean_total = monthly_totals.mean()
    return monthly_totals / mean_total


def _adjusted_popularity(df, seasonal_indices):
    months = df["date"].dt.month
    item_month = df.groupby([df["item"], months])["quantity"].sum().reset_index()
    item_month.columns = ["item", "month", "quantity"]
    item_month["adjusted"] = item_month["quantity"] / item_month["month"].map(
        seasonal_indices
    )
    return item_month.groupby("item")["adjusted"].sum()


def _contribution_margins(df):
    unit_cm = df["sell_price"] - df["food_cost"]
    row_cm = unit_cm * df["quantity"]
    return row_cm.groupby(df["item"]).sum()


def _classify_all(adjusted_pop, contribution_margin):
    pop_median = adjusted_pop.median()
    margin_median = contribution_margin.median()
    quadrants = {}
    for item in adjusted_pop.index:
        quadrants[item] = _classify(
            adjusted_pop.loc[item],
            contribution_margin.loc[item],
            pop_median,
            margin_median,
        )
    return quadrants


def _build_section(item, full_q, recent_q, shifted):
    status = "shifted" if shifted else "stable"
    suggestion = SUGGESTIONS[full_q]
    if shifted:
        suggestion = f"{suggestion} (recently shifted to {recent_q})"
    return (
        f"Item: {item}\n"
        f"Full-year quadrant: {full_q}\n"
        f"Last-13-weeks quadrant: {recent_q}\n"
        f"Status: {status}\n"
        f"Suggestion: {suggestion}"
    )


def run_pipeline(data_path, output_path):
    """Execute the full menu engineering pipeline end-to-end."""
    df = load_pos_data(data_path)

    seasonal_indices = _seasonal_indices(df)

    full_pop = _adjusted_popularity(df, seasonal_indices)
    full_cm = _contribution_margins(df)
    full_quadrants = _classify_all(full_pop, full_cm)

    max_date = df["date"].max()
    cutoff = max_date - pd.Timedelta(days=91)
    recent_df = df[df["date"] >= cutoff]

    recent_pop = _adjusted_popularity(recent_df, seasonal_indices)
    recent_cm = _contribution_margins(recent_df)
    recent_quadrants = _classify_all(recent_pop, recent_cm)

    sections = []
    for item in sorted(full_quadrants.keys()):
        full_q = full_quadrants[item]
        if item in recent_quadrants:
            recent_q = recent_quadrants[item]
            shifted = recent_q != full_q
        else:
            recent_q = full_q
            shifted = False
        sections.append(_build_section(item, full_q, recent_q, shifted))

    output_dir = os.path.dirname(output_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    with open(output_path, "w") as fh:
        fh.write("\n\n".join(sections))

    print(f"Brief written to {output_path}")


if __name__ == "__main__":
    run_pipeline("data/pos_data.csv", "output/menu_brief.txt")
