import argparse
import logging
import os
import re
from datetime import datetime
from typing import Optional, Union

import numpy as np
import pandas as pd

from jinja2 import Template
from sklearn.impute import SimpleImputer
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


# =============================================================================
# Data Loading and Validation
# =============================================================================


def load_and_validate(data_dir: str) -> dict[str, Union[pd.DataFrame, dict[str, int]]]:
    """Load all eight CSV files, validate, parse dates, coerce booleans."""
    validation_summary: dict[str, int] = {}

    file_configs = {
        "permits": {
            "filename": "permits.csv",
            "primary_key": "permit_id",
            "date_cols": ["issue_date", "warranty_start", "warranty_end"],
            "bool_cols": ["traffic_control_plan_adequate"],
        },
        "inspections": {
            "filename": "inspections.csv",
            "primary_key": "inspection_id",
            "date_cols": ["inspection_date"],
            "bool_cols": ["backfill_accepted", "base_course_accepted", "surface_restoration_accepted"],
        },
        "permittees": {
            "filename": "permittees.csv",
            "primary_key": "permittee_id",
            "date_cols": [],
            "bool_cols": [],
        },
        "street_segments": {
            "filename": "street_segments.csv",
            "primary_key": "segment_id",
            "date_cols": ["pavement_install_date", "overlay_date", "moratorium_start", "moratorium_end"],
            "bool_cols": [],
        },
        "settlement_failures": {
            "filename": "settlement_failures.csv",
            "primary_key": "failure_id",
            "date_cols": ["failure_date"],
            "bool_cols": [],
        },
        "fee_assessments": {
            "filename": "fee_assessments.csv",
            "primary_key": "assessment_id",
            "date_cols": ["date"],
            "bool_cols": [],
        },
        "bond_claims": {
            "filename": "bond_claims.csv",
            "primary_key": "claim_id",
            "date_cols": ["claim_date"],
            "bool_cols": ["resolved"],
        },
        "coordination_notices": {
            "filename": "coordination_notices.csv",
            "primary_key": "notice_id",
            "date_cols": ["notice_date", "project_start_date"],
            "bool_cols": [],
        },
    }

    datasets: dict[str, Union[pd.DataFrame, dict[str, int]]] = {}

    for name, config in file_configs.items():
        filepath = os.path.join(data_dir, config["filename"])
        df = pd.read_csv(filepath)
        initial_count = len(df)

        pk = config["primary_key"]
        df = df.dropna(subset=[pk])

        for col in config["date_cols"]:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors="coerce")

        for col in config["bool_cols"]:
            if col in df.columns:
                df[col] = df[col].map(
                    {"True": True, "False": False, True: True, False: False, 1: True, 0: False}
                )
                df[col] = df[col].astype(bool)

        dropped = initial_count - len(df)
        validation_summary[name] = dropped

        if dropped > 0:
            logger.info(f"Dataset '{name}': dropped {dropped} rows with null primary keys")

        datasets[name] = df

    datasets["validation_summary"] = validation_summary
    return datasets


# =============================================================================
# Feature Engineering
# =============================================================================


def engineer_features(datasets: dict[str, Union[pd.DataFrame, dict[str, int]]]) -> pd.DataFrame:
    """Compute all derived columns, aggregate permittee and segment features."""
    permits = datasets["permits"].copy()
    inspections = datasets["inspections"].copy()
    permittees = datasets["permittees"].copy()
    street_segments = datasets["street_segments"].copy()
    settlement_failures = datasets["settlement_failures"].copy()
    fee_assessments = datasets["fee_assessments"].copy()
    bond_claims = datasets["bond_claims"].copy()
    coordination_notices = datasets["coordination_notices"].copy()

    # -------------------------------------------------------------------------
    # Step 3: Permit-level derived columns
    # -------------------------------------------------------------------------

    permits = permits.merge(
        street_segments[["segment_id", "pavement_install_date", "overlay_date",
                         "moratorium_start", "moratorium_end"]],
        left_on="street_segment_id", right_on="segment_id", how="left"
    )

    # pavement_age_at_cut_days
    permits["pavement_age_at_cut_days"] = (
        permits["issue_date"] - permits["pavement_install_date"]
    ).dt.days

    # warranty_overlap: True when warranty_start <= issue_date <= warranty_end
    # False when either warranty date is null
    permits["warranty_overlap"] = (
        permits["warranty_start"].notna() &
        permits["warranty_end"].notna() &
        (permits["warranty_start"] <= permits["issue_date"]) &
        (permits["issue_date"] <= permits["warranty_end"])
    )

    # warranty_remaining_days: NaN when warranty_overlap is False or warranty_end is null
    permits["warranty_remaining_days"] = np.where(
        permits["warranty_overlap"] & permits["warranty_end"].notna(),
        (permits["warranty_end"] - permits["issue_date"]).dt.days,
        np.nan
    )

    # moratorium_violated: False when moratorium_start or moratorium_end is null
    permits["moratorium_violated"] = (
        permits["moratorium_start"].notna() &
        permits["moratorium_end"].notna() &
        (permits["issue_date"] >= permits["moratorium_start"]) &
        (permits["issue_date"] <= permits["moratorium_end"])
    )

    # has_overlay: True when non-null overlay_date is on or before issue_date
    permits["has_overlay"] = (
        permits["overlay_date"].notna() &
        (permits["overlay_date"] <= permits["issue_date"])
    )

    # days_since_overlay: NaN when has_overlay is False
    permits["days_since_overlay"] = np.where(
        permits["has_overlay"],
        (permits["issue_date"] - permits["overlay_date"]).dt.days,
        np.nan
    )

    # coordination_lead_days: join on BOTH permittee_id AND permit_id
    coord_merged = permits[["permit_id", "permittee_id"]].merge(
        coordination_notices[["permittee_id", "permit_id", "notice_date", "project_start_date"]],
        on=["permittee_id", "permit_id"],
        how="left"
    )
    coord_merged["coordination_lead_days"] = (
        coord_merged["project_start_date"] - coord_merged["notice_date"]
    ).dt.days
    coord_by_permit = (
        coord_merged.groupby("permit_id")["coordination_lead_days"].mean().reset_index()
    )
    permits = permits.merge(coord_by_permit, on="permit_id", how="left")

    # -------------------------------------------------------------------------
    # Step 4: Per-permittee craftsmanship features
    # -------------------------------------------------------------------------

    insp_with_permittee = inspections.merge(
        permits[["permit_id", "permittee_id"]], on="permit_id", how="left"
    )

    permittee_insp = insp_with_permittee.groupby("permittee_id").agg(
        craft_backfill_rate=("backfill_accepted", "mean"),
        craft_base_course_rate=("base_course_accepted", "mean"),
        craft_surface_rate=("surface_restoration_accepted", "mean"),
    ).reset_index()

    insp_with_permittee["all_accepted"] = (
        insp_with_permittee["backfill_accepted"] &
        insp_with_permittee["base_course_accepted"] &
        insp_with_permittee["surface_restoration_accepted"]
    )
    overall_pass = (
        insp_with_permittee.groupby("permittee_id")["all_accepted"].mean().reset_index()
    )
    overall_pass.columns = ["permittee_id", "craft_overall_pass_rate"]
    permittee_insp = permittee_insp.merge(overall_pass, on="permittee_id", how="left")

    fee_by_permittee = fee_assessments.groupby("permittee_id").agg(
        total_fees_assessed=("amount", "sum"),
        num_fee_permits=("permit_id", "nunique"),
    ).reset_index()
    fee_by_permittee["avg_fee_per_permit"] = (
        fee_by_permittee["total_fees_assessed"] / fee_by_permittee["num_fee_permits"]
    )

    bond_by_permittee = bond_claims.groupby("permittee_id").agg(
        total_bond_amount=("claim_amount", "sum"),
        bond_claim_count=("claim_id", "count"),
    ).reset_index()

    permits_per_permittee = (
        permits.groupby("permittee_id")["permit_id"].nunique().reset_index()
    )
    permits_per_permittee.columns = ["permittee_id", "permittee_permit_count"]

    permittee_features = permittee_insp.merge(
        fee_by_permittee[["permittee_id", "total_fees_assessed", "avg_fee_per_permit"]],
        on="permittee_id", how="left"
    )
    permittee_features = permittee_features.merge(bond_by_permittee, on="permittee_id", how="left")
    permittee_features = permittee_features.merge(permits_per_permittee, on="permittee_id", how="left")

    permittee_features["total_fees_assessed"] = permittee_features["total_fees_assessed"].astype(float).fillna(0.0)
    permittee_features["avg_fee_per_permit"] = permittee_features["avg_fee_per_permit"].astype(float).fillna(0.0)
    permittee_features["total_bond_amount"] = permittee_features["total_bond_amount"].astype(float).fillna(0.0)
    permittee_features["bond_claim_count"] = permittee_features["bond_claim_count"].astype(float).fillna(0).astype(int)

    safe_bond = permittee_features["total_bond_amount"].copy()
    safe_bond = safe_bond.where(safe_bond != 0.0, other=np.nan)
    # fee_to_bond_ratio: 0.0 when permittee has no bond claims
    permittee_features["fee_to_bond_ratio"] = (
        permittee_features["total_fees_assessed"] / safe_bond
    ).fillna(0.0)

    # bond_claim_rate: bond claims per permit for the permittee
    permittee_features["bond_claim_rate"] = (
        permittee_features["bond_claim_count"] / permittee_features["permittee_permit_count"]
    )

    # avg_coordination_lead_days: mean coordination lead time in days for the permittee
    coord_with_permittee = coordination_notices.copy()
    coord_with_permittee["lead_days"] = (
        coord_with_permittee["project_start_date"] - coord_with_permittee["notice_date"]
    ).dt.days
    avg_coord = (
        coord_with_permittee.groupby("permittee_id")["lead_days"].mean().reset_index()
    )
    avg_coord.columns = ["permittee_id", "avg_coordination_lead_days"]
    permittee_features = permittee_features.merge(avg_coord, on="permittee_id", how="left")

    permittee_feature_cols = [
        "permittee_id", "craft_backfill_rate", "craft_base_course_rate",
        "craft_surface_rate", "craft_overall_pass_rate", "total_fees_assessed",
        "avg_fee_per_permit", "fee_to_bond_ratio", "bond_claim_count",
        "bond_claim_rate", "avg_coordination_lead_days"
    ]
    permittee_features = permittee_features[permittee_feature_cols]

    # -------------------------------------------------------------------------
    # Step 5: Per-street-segment subgrade features with per-year temporal granularity
    # -------------------------------------------------------------------------

    permits["issue_year"] = permits["issue_date"].dt.year

    # Per-segment, per-year permit count
    seg_year_permits = (
        permits.groupby(["street_segment_id", "issue_year"]).size().reset_index(name="permit_count")
    )

    # Per-segment, per-year failure count — grouped by failure_date year
    failures_with_seg = settlement_failures.merge(
        permits[["permit_id", "street_segment_id"]], on="permit_id", how="left"
    )
    failures_with_seg["failure_year"] = failures_with_seg["failure_date"].dt.year
    seg_year_failures = (
        failures_with_seg.groupby(["street_segment_id", "failure_year"])
        .size().reset_index(name="failure_count")
    )
    seg_year_failures = seg_year_failures.rename(columns={"failure_year": "issue_year"})

    # Merge per-year tables (left on permit-years; fill missing failure years with 0)
    seg_year = seg_year_permits.merge(
        seg_year_failures, on=["street_segment_id", "issue_year"], how="left"
    )
    seg_year["failure_count"] = seg_year["failure_count"].astype(float).fillna(0).astype(int)
    seg_year["year_failure_rate"] = seg_year["failure_count"] / seg_year["permit_count"]

    # Overall aggregates
    seg_totals = seg_year.groupby("street_segment_id").agg(
        total_permits=("permit_count", "sum"),
    ).reset_index()
    seg_totals["cumulative_cut_density"] = seg_totals["total_permits"] / 1.0

    # segment_failure_rate: total failures on segment / total permits
    # Count ALL failures linked to permits on the segment (regardless of failure year)
    total_failures_per_seg = (
        failures_with_seg.groupby("street_segment_id").size().reset_index(name="total_failures")
    )
    seg_totals = seg_totals.merge(total_failures_per_seg, on="street_segment_id", how="left")
    seg_totals["total_failures"] = seg_totals["total_failures"].astype(float).fillna(0).astype(int)
    seg_totals["segment_failure_rate"] = np.where(
        seg_totals["total_permits"] > 0,
        seg_totals["total_failures"] / seg_totals["total_permits"],
        0.0
    )

    # Trend slopes: OLS slope of per-year value against year index 0..N-1
    # Compute both trend slopes in a single pass over segments (avoids groupby.apply overhead)
    slope_rows = []
    for seg_id, g in seg_year.groupby("street_segment_id"):
        if len(g) <= 1:
            cd_slope, fr_slope = 0.0, 0.0
        else:
            year_idx = g["issue_year"].values - g["issue_year"].values.min()
            cd_slope = float(np.polyfit(year_idx, g["permit_count"].values, 1)[0])
            fr_slope = float(np.polyfit(year_idx, g["year_failure_rate"].values, 1)[0])
        slope_rows.append({
            "street_segment_id": seg_id,
            "cut_density_trend_slope": cd_slope,
            "failure_rate_trend_slope": fr_slope,
        })
    _slopes = pd.DataFrame(slope_rows)
    cut_density_slopes = _slopes[["street_segment_id", "cut_density_trend_slope"]]
    failure_rate_slopes = _slopes[["street_segment_id", "failure_rate_trend_slope"]]

    most_recent_year = permits["issue_year"].max()

    recent_year_data = seg_year[seg_year["issue_year"] == most_recent_year].copy()
    recent_year_data["recent_year_cut_density"] = recent_year_data["permit_count"] / 1.0
    recent_year_data["recent_year_failure_rate"] = recent_year_data["year_failure_rate"]
    recent_year_features = recent_year_data[
        ["street_segment_id", "recent_year_cut_density", "recent_year_failure_rate"]
    ]

    avg_pav_age = (
        permits.groupby("street_segment_id")["pavement_age_at_cut_days"].mean().reset_index()
    )
    avg_pav_age.columns = ["street_segment_id", "avg_pavement_age_at_cut"]

    # recent_overlay_flag: True if segment received overlay within the most recent two years
    two_years_ago = most_recent_year - 2
    segment_overlay_info = street_segments[["segment_id", "overlay_date"]].copy()
    segment_overlay_info["recent_overlay_flag"] = (
        segment_overlay_info["overlay_date"].notna() &
        (segment_overlay_info["overlay_date"].dt.year >= two_years_ago)
    )
    segment_overlay_info = segment_overlay_info[["segment_id", "recent_overlay_flag"]]
    segment_overlay_info = segment_overlay_info.rename(columns={"segment_id": "street_segment_id"})

    segment_features = seg_totals[["street_segment_id", "cumulative_cut_density", "segment_failure_rate"]]
    segment_features = segment_features.merge(cut_density_slopes, on="street_segment_id", how="left")
    segment_features = segment_features.merge(failure_rate_slopes, on="street_segment_id", how="left")
    segment_features = segment_features.merge(recent_year_features, on="street_segment_id", how="left")
    segment_features = segment_features.merge(avg_pav_age, on="street_segment_id", how="left")
    segment_features = segment_features.merge(segment_overlay_info, on="street_segment_id", how="left")

    segment_features["recent_year_cut_density"] = segment_features["recent_year_cut_density"].astype(float).fillna(0.0)
    segment_features["recent_year_failure_rate"] = segment_features["recent_year_failure_rate"].astype(float).fillna(0.0)

    # -------------------------------------------------------------------------
    # Step 6: Merge all features into permit-level DataFrame
    # -------------------------------------------------------------------------

    feature_df = permits.merge(permittee_features, on="permittee_id", how="left")
    feature_df = feature_df.merge(segment_features, on="street_segment_id", how="left")

    # Merge permittee type for one-hot encoding
    feature_df = feature_df.merge(
        permittees[["permittee_id", "type"]].rename(columns={"type": "permittee_type"}),
        on="permittee_id", how="left"
    )

    # One-hot encode excavation_purpose, restoration_scope, permittee_type with drop='first'
    encoder = OneHotEncoder(sparse_output=False, drop="first", dtype=int)
    cat_cols = ["excavation_purpose", "restoration_scope", "permittee_type"]
    encoded = encoder.fit_transform(feature_df[cat_cols])
    encoded_col_names = encoder.get_feature_names_out(cat_cols)
    encoded_df = pd.DataFrame(encoded, columns=encoded_col_names, index=feature_df.index)
    feature_df = pd.concat([feature_df, encoded_df], axis=1)
    feature_df.drop(columns=cat_cols, inplace=True)

    # -------------------------------------------------------------------------
    # Step 7: Target label has_failure
    # -------------------------------------------------------------------------
    # 1 if at least one settlement failure within 730 days of issue_date
    failures_for_label = settlement_failures[["permit_id", "failure_date"]].merge(
        permits[["permit_id", "issue_date"]], on="permit_id", how="left"
    )
    failures_for_label["days_to_failure"] = (
        failures_for_label["failure_date"] - failures_for_label["issue_date"]
    ).dt.days
    failures_within_window = failures_for_label[
        (failures_for_label["days_to_failure"] >= 0) &
        (failures_for_label["days_to_failure"] <= 730)
    ]
    permits_with_failure = failures_within_window["permit_id"].unique()
    feature_df["has_failure"] = feature_df["permit_id"].isin(permits_with_failure).astype(int)

    feature_df.attrs["encoded_columns"] = list(encoded_col_names)
    return feature_df


# =============================================================================
# Model Training
# =============================================================================


def train_models(feature_df: pd.DataFrame) -> dict:
    """Train craftsmanship, subgrade-only, and combined risk models."""

    # -------------------------------------------------------------------------
    # Define feature column sets
    # -------------------------------------------------------------------------

    # 10 per-permittee craftsmanship features
    craftsmanship_features = [
        "craft_backfill_rate", "craft_base_course_rate", "craft_surface_rate",
        "craft_overall_pass_rate", "total_fees_assessed", "avg_fee_per_permit",
        "fee_to_bond_ratio", "bond_claim_count", "bond_claim_rate",
        "avg_coordination_lead_days"
    ]

    # 5 per-segment non-leaky subgrade features
    # segment_failure_rate, failure_rate_trend_slope, recent_year_failure_rate
    # are EXCLUDED from all models to prevent target leakage
    subgrade_features = [
        "cumulative_cut_density", "avg_pavement_age_at_cut", "recent_overlay_flag",
        "cut_density_trend_slope", "recent_year_cut_density"
    ]

    # 7 permit-level derived columns
    permit_derived = [
        "pavement_age_at_cut_days", "warranty_overlap", "warranty_remaining_days",
        "moratorium_violated", "has_overlay", "days_since_overlay", "coordination_lead_days"
    ]

    # One-hot encoded columns
    encoded_columns = feature_df.attrs.get("encoded_columns", [])
    if not encoded_columns:
        encoded_columns = [
            c for c in feature_df.columns
            if c.startswith("excavation_purpose_") or c.startswith("restoration_scope_")
            or c.startswith("permittee_type_")
        ]

    # Combined: craftsmanship + subgrade (non-leaky) + permit derived + boolean + OHE
    combined_features = (
        craftsmanship_features + subgrade_features + permit_derived
        + ["traffic_control_plan_adequate"] + encoded_columns
    )

    # Convert boolean columns to int for scikit-learn compatibility
    bool_cols = [
        "warranty_overlap", "moratorium_violated", "has_overlay",
        "traffic_control_plan_adequate", "recent_overlay_flag"
    ]
    feature_df = feature_df.copy()
    for col in bool_cols:
        if col in feature_df.columns:
            feature_df[col] = feature_df[col].astype(int)

    target = "has_failure"
    y = feature_df[target].values

    X_craft = feature_df[craftsmanship_features].copy()
    X_sub = feature_df[subgrade_features].copy()
    X_comb = feature_df[combined_features].copy()

    # 80/20 stratified split with fixed random seed of 42 for reproducibility
    X_craft_train, X_craft_eval, y_train, y_eval = train_test_split(
        X_craft, y, test_size=0.2, random_state=42, stratify=y
    )
    X_sub_train, X_sub_eval, _, _ = train_test_split(
        X_sub, y, test_size=0.2, random_state=42, stratify=y
    )
    X_comb_train, X_comb_eval, _, _ = train_test_split(
        X_comb, y, test_size=0.2, random_state=42, stratify=y
    )

    # -------------------------------------------------------------------------
    # Three scikit-learn Pipelines, each starting with constant imputation
    # NaN-as-meaningful-absence: days_since_overlay, coordination_lead_days,
    # avg_coordination_lead_days, warranty_remaining_days are NaN by design.
    # Sentinel -9999 lies outside the plausible domain of all affected features.
    # -------------------------------------------------------------------------

    craftsmanship_pipeline = Pipeline([
        # NaN-as-meaningful-absence sentinel: -9999 (constant imputation)
        ("imputer", SimpleImputer(strategy="constant", fill_value=-9999)),
        ("classifier", GaussianNB()),
    ])

    subgrade_pipeline = Pipeline([
        # NaN-as-meaningful-absence sentinel: -9999 (constant imputation)
        ("imputer", SimpleImputer(strategy="constant", fill_value=-9999)),
        ("classifier", GaussianNB()),
    ])

    combined_pipeline = Pipeline([
        # NaN-as-meaningful-absence sentinel: -9999 (constant imputation)
        ("imputer", SimpleImputer(strategy="constant", fill_value=-9999)),
        ("classifier", GaussianNB()),
    ])

    craftsmanship_pipeline.fit(X_craft_train, y_train)
    subgrade_pipeline.fit(X_sub_train, y_train)
    combined_pipeline.fit(X_comb_train, y_train)

    # Evaluate on the single 80/20 split
    craft_pred = craftsmanship_pipeline.predict(X_craft_eval)
    craft_proba = craftsmanship_pipeline.predict_proba(X_craft_eval)[:, 1]

    sub_pred = subgrade_pipeline.predict(X_sub_eval)
    sub_proba = subgrade_pipeline.predict_proba(X_sub_eval)[:, 1]

    comb_pred = combined_pipeline.predict(X_comb_eval)
    comb_proba = combined_pipeline.predict_proba(X_comb_eval)[:, 1]

    def _both_classes(y_true):
        return len(np.unique(y_true)) > 1

    craftsmanship_metrics = {
        "accuracy": accuracy_score(y_eval, craft_pred),
        "precision": precision_score(y_eval, craft_pred, zero_division=0),
        "recall": recall_score(y_eval, craft_pred, zero_division=0),
        "f1": f1_score(y_eval, craft_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_eval, craft_proba) if _both_classes(y_eval) else 0.0,
    }
    subgrade_metrics = {
        "accuracy": accuracy_score(y_eval, sub_pred),
        "precision": precision_score(y_eval, sub_pred, zero_division=0),
        "recall": recall_score(y_eval, sub_pred, zero_division=0),
        "f1": f1_score(y_eval, sub_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_eval, sub_proba) if _both_classes(y_eval) else 0.0,
    }
    combined_metrics = {
        "accuracy": accuracy_score(y_eval, comb_pred),
        "precision": precision_score(y_eval, comb_pred, zero_division=0),
        "recall": recall_score(y_eval, comb_pred, zero_division=0),
        "f1": f1_score(y_eval, comb_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_eval, comb_proba) if _both_classes(y_eval) else 0.0,
    }

    # Stratified 5-fold cross-validation with ROC-AUC scoring
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    craft_cv = cross_val_score(craftsmanship_pipeline, X_craft, y, cv=cv, scoring="roc_auc")
    sub_cv = cross_val_score(subgrade_pipeline, X_sub, y, cv=cv, scoring="roc_auc")
    comb_cv = cross_val_score(combined_pipeline, X_comb, y, cv=cv, scoring="roc_auc")

    craftsmanship_metrics["cv_roc_auc_mean"] = float(craft_cv.mean())
    subgrade_metrics["cv_roc_auc_mean"] = float(sub_cv.mean())
    combined_metrics["cv_roc_auc_mean"] = float(comb_cv.mean())

    # Pairwise ROC-AUC deltas
    delta_combined_vs_craft = combined_metrics["roc_auc"] - craftsmanship_metrics["roc_auc"]
    delta_combined_vs_subgrade = combined_metrics["roc_auc"] - subgrade_metrics["roc_auc"]
    delta_subgrade_vs_craft = subgrade_metrics["roc_auc"] - craftsmanship_metrics["roc_auc"]

    # Warn if Combined Model ROC-AUC is lower than either standalone model
    if delta_combined_vs_craft < 0:
        logger.warning(
            f"Combined Model ROC-AUC ({combined_metrics['roc_auc']:.4f}) is lower than "
            f"Craftsmanship Model ROC-AUC ({craftsmanship_metrics['roc_auc']:.4f}). "
            f"Delta (combined - craft): {delta_combined_vs_craft:.4f}. "
            f"Evaluation set size: {len(y_eval)}."
        )
    if delta_combined_vs_subgrade < 0:
        logger.warning(
            f"Combined Model ROC-AUC ({combined_metrics['roc_auc']:.4f}) is lower than "
            f"Subgrade-Only Model ROC-AUC ({subgrade_metrics['roc_auc']:.4f}). "
            f"Delta (combined - subgrade): {delta_combined_vs_subgrade:.4f}. "
            f"Evaluation set size: {len(y_eval)}."
        )

    # eval_predictions: evaluation set rows with all three prediction columns
    eval_indices = X_craft_eval.index
    eval_predictions = feature_df.loc[eval_indices].copy()
    eval_predictions["combined_predicted_risk"] = comb_proba
    eval_predictions["craftsmanship_predicted_risk"] = craft_proba
    eval_predictions["subgrade_predicted_risk"] = sub_proba

    # Full-history predictions for all permits (not restricted to eval set)
    comb_full = combined_pipeline.predict_proba(X_comb)[:, 1]
    craft_full = craftsmanship_pipeline.predict_proba(X_craft)[:, 1]
    sub_full = subgrade_pipeline.predict_proba(X_sub)[:, 1]

    full_predictions = feature_df.copy()
    full_predictions["combined_predicted_risk"] = comb_full
    full_predictions["craftsmanship_predicted_risk"] = craft_full
    full_predictions["subgrade_predicted_risk"] = sub_full

    return {
        "craftsmanship_model": craftsmanship_pipeline,
        "subgrade_model": subgrade_pipeline,
        "combined_model": combined_pipeline,
        "craftsmanship_metrics": craftsmanship_metrics,
        "subgrade_metrics": subgrade_metrics,
        "combined_metrics": combined_metrics,
        "roc_auc_delta_combined_vs_craft": delta_combined_vs_craft,
        "roc_auc_delta_combined_vs_subgrade": delta_combined_vs_subgrade,
        "roc_auc_delta_subgrade_vs_craft": delta_subgrade_vs_craft,
        "eval_predictions": eval_predictions,
        "feature_names": combined_features,
        "craftsmanship_feature_names": craftsmanship_features,
        "subgrade_feature_names": subgrade_features,
        "full_predictions": full_predictions,
    }


# =============================================================================
# Moratorium Violation Analysis
# =============================================================================


def analyze_moratorium_violations(
    feature_df: pd.DataFrame,
    datasets: dict[str, Union[pd.DataFrame, dict[str, int]]],
    quarter_start: Optional[pd.Timestamp] = None,
    quarter_end: Optional[pd.Timestamp] = None,
) -> pd.DataFrame:
    """Compute per-corridor moratorium violation statistics."""
    street_segments = datasets["street_segments"]

    df = feature_df.merge(
        street_segments[["segment_id", "corridor_name"]],
        left_on="street_segment_id", right_on="segment_id", how="left"
    )

    # Filter to permits whose issue_date falls within the quarter (if specified)
    if quarter_start is not None and quarter_end is not None:
        df = df[(df["issue_date"] >= quarter_start) & (df["issue_date"] <= quarter_end)]

    if df.empty:
        return pd.DataFrame(columns=[
            "corridor_name", "total_permits", "moratorium_violations",
            "violation_rate", "days_since_last_overlay", "critical_flag"
        ])

    corridor_stats = df.groupby("corridor_name").agg(
        total_permits=("permit_id", "count"),
        moratorium_violations=("moratorium_violated", "sum"),
    ).reset_index()

    corridor_stats["violation_rate"] = (
        corridor_stats["moratorium_violations"] / corridor_stats["total_permits"]
    )

    # days_since_last_overlay: median of days_since_overlay for has_overlay==True permits
    # NaN if no permits in the corridor have a valid overlay
    overlay_permits = df[df["has_overlay"] == True]  # noqa: E712
    if not overlay_permits.empty:
        median_overlay = (
            overlay_permits.groupby("corridor_name")["days_since_overlay"]
            .median().reset_index()
        )
        median_overlay.columns = ["corridor_name", "days_since_last_overlay"]
        corridor_stats = corridor_stats.merge(median_overlay, on="corridor_name", how="left")
    else:
        corridor_stats["days_since_last_overlay"] = np.nan

    # critical_flag: violation_rate > 0.10 AND days_since_last_overlay not NaN AND < 730
    corridor_stats["critical_flag"] = (
        (corridor_stats["violation_rate"] > 0.10) &
        corridor_stats["days_since_last_overlay"].notna() &
        (corridor_stats["days_since_last_overlay"] < 730)
    )

    corridor_stats = corridor_stats.sort_values("violation_rate", ascending=False).reset_index(drop=True)
    return corridor_stats


# =============================================================================
# Report Generation - Director Report
# =============================================================================

DIRECTOR_REPORT_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Public Works Director Quarterly Packet - {{ quarter }}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f9f9f9; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        h2 { color: #34495e; margin-top: 30px; }
        table { border-collapse: collapse; width: 100%; margin: 15px 0; background: white; }
        th { background: #3498db; color: white; padding: 12px 8px; text-align: left; }
        td { padding: 10px 8px; border-bottom: 1px solid #ddd; }
        tr:hover { background: #f5f5f5; }
        .timestamp { color: #7f8c8d; font-size: 0.9em; }
        .critical { color: #e74c3c; font-weight: bold; }
    </style>
</head>
<body>
    <h1>Public Works Director Quarterly Packet</h1>
    <p><strong>Quarter:</strong> {{ quarter }}</p>
    <p class="timestamp">Generated: {{ timestamp }}</p>

    <h2>Summary Statistics</h2>
    <table>
        <tr><th>Metric</th><th>This Quarter</th><th>Previous Quarter</th><th>Delta</th></tr>
        <tr><td>Total Permits Issued</td><td>{{ summary.total_permits }}</td><td>{{ summary.prev_permits }}</td><td>{{ summary.delta_permits }}</td></tr>
        <tr><td>Total Inspections</td><td>{{ summary.total_inspections }}</td><td>{{ summary.prev_inspections }}</td><td>{{ summary.delta_inspections }}</td></tr>
        <tr><td>Total Failures Recorded</td><td>{{ summary.total_failures }}</td><td>{{ summary.prev_failures }}</td><td>{{ summary.delta_failures }}</td></tr>
        <tr><td>Quarter Failure Rate</td><td>{{ summary.failure_rate }}</td><td>{{ summary.prev_failure_rate }}</td><td>{{ summary.delta_failure_rate }}</td></tr>
        <tr><td>Total Moratorium Violations</td><td>{{ summary.total_violations }}</td><td>{{ summary.prev_violations }}</td><td>{{ summary.delta_violations }}</td></tr>
    </table>

    <h2>Top-10 Highest-Risk Permittees (This Quarter)</h2>
    <table>
        <tr>
            <th>Rank</th><th>Permittee Name</th><th>Type</th><th>Craft Overall Pass Rate</th>
            <th>Combined Predicted Risk</th><th>Craft Predicted Risk</th>
            <th>Subgrade Predicted Risk</th><th>Non-Craft Risk Delta</th>
            <th>Bond Claim Count</th><th>Total Fees Assessed</th><th>Fee-to-Bond Ratio</th>
        </tr>
        {% for row in top_permittees %}
        <tr>
            <td>{{ loop.index }}</td>
            <td>{{ row.name }}</td>
            <td>{{ row.type }}</td>
            <td>{{ "%.3f"|format(row.craft_overall_pass_rate) }}</td>
            <td>{{ "%.4f"|format(row.combined_predicted_risk) }}</td>
            <td>{{ "%.4f"|format(row.craftsmanship_predicted_risk) }}</td>
            <td>{{ "%.4f"|format(row.subgrade_predicted_risk) }}</td>
            <td>{{ "%.4f"|format(row.non_craft_delta) }}</td>
            <td>{{ row.bond_claim_count }}</td>
            <td>${{ "%.2f"|format(row.total_fees_assessed) }}</td>
            <td>{{ "%.3f"|format(row.fee_to_bond_ratio) }}</td>
        </tr>
        {% endfor %}
    </table>

    <h2>Corridor Moratorium Violation Summary</h2>
    <table>
        <tr>
            <th>Corridor</th><th>Total Permits This Quarter</th><th>Violation Count</th>
            <th>Violation Rate</th><th>Critical Flag</th>
        </tr>
        {% for row in corridor_violations %}
        <tr>
            <td>{{ row.corridor_name }}</td>
            <td>{{ row.total_permits }}</td>
            <td>{{ row.moratorium_violations }}</td>
            <td>{{ "%.3f"|format(row.violation_rate) }}</td>
            <td>{% if row.critical_flag %}<span class="critical">Critical Overlay Coordination Failure</span>{% else %}&mdash;{% endif %}</td>
        </tr>
        {% endfor %}
    </table>

    <h2>Model Performance Comparison</h2>
    <table>
        <tr>
            <th>Metric</th>
            <th>Craftsmanship Model</th>
            <th>Subgrade-Only Model</th>
            <th>Combined Model</th>
        </tr>
        <tr><td>Accuracy</td><td>{{ "%.4f"|format(metrics.craft_accuracy) }}</td><td>{{ "%.4f"|format(metrics.sub_accuracy) }}</td><td>{{ "%.4f"|format(metrics.comb_accuracy) }}</td></tr>
        <tr><td>Precision</td><td>{{ "%.4f"|format(metrics.craft_precision) }}</td><td>{{ "%.4f"|format(metrics.sub_precision) }}</td><td>{{ "%.4f"|format(metrics.comb_precision) }}</td></tr>
        <tr><td>Recall</td><td>{{ "%.4f"|format(metrics.craft_recall) }}</td><td>{{ "%.4f"|format(metrics.sub_recall) }}</td><td>{{ "%.4f"|format(metrics.comb_recall) }}</td></tr>
        <tr><td>F1-Score</td><td>{{ "%.4f"|format(metrics.craft_f1) }}</td><td>{{ "%.4f"|format(metrics.sub_f1) }}</td><td>{{ "%.4f"|format(metrics.comb_f1) }}</td></tr>
        <tr><td>ROC-AUC (Single Split)</td><td>{{ "%.4f"|format(metrics.craft_roc_auc) }}</td><td>{{ "%.4f"|format(metrics.sub_roc_auc) }}</td><td>{{ "%.4f"|format(metrics.comb_roc_auc) }}</td></tr>
        <tr><td>CV Mean ROC-AUC</td><td>{{ "%.4f"|format(metrics.craft_cv_roc_auc) }}</td><td>{{ "%.4f"|format(metrics.sub_cv_roc_auc) }}</td><td>{{ "%.4f"|format(metrics.comb_cv_roc_auc) }}</td></tr>
        <tr><td>Delta: Combined vs Craftsmanship</td><td colspan="3">{{ "%.4f"|format(metrics.delta_comb_vs_craft) }}</td></tr>
        <tr><td>Delta: Combined vs Subgrade</td><td colspan="3">{{ "%.4f"|format(metrics.delta_comb_vs_sub) }}</td></tr>
        <tr><td>Delta: Subgrade vs Craftsmanship</td><td colspan="3">{{ "%.4f"|format(metrics.delta_sub_vs_craft) }}</td></tr>
    </table>
</body>
</html>
"""


def _get_prev_quarter_range(quarter: str):
    """Return (start, end) Timestamps for the immediately preceding calendar quarter."""
    match = re.fullmatch(r"Q([1-4])-(\d{4})", quarter)
    q_num = int(match.group(1))
    year = int(match.group(2))

    prev_q = q_num - 1 if q_num > 1 else 4
    prev_year = year if q_num > 1 else year - 1

    month_ranges = {
        1: ("01-01", "03-31"),
        2: ("04-01", "06-30"),
        3: ("07-01", "09-30"),
        4: ("10-01", "12-31"),
    }
    s, e = month_ranges[prev_q]
    return pd.Timestamp(f"{prev_year}-{s}"), pd.Timestamp(f"{prev_year}-{e}")


def generate_director_report(
    quarter: str,
    quarter_start: pd.Timestamp,
    quarter_end: pd.Timestamp,
    feature_df: pd.DataFrame,
    model_results: dict,
    corridor_quarter_df: pd.DataFrame,
    datasets: dict[str, Union[pd.DataFrame, dict[str, int]]],
    output_dir: str,
) -> str:
    """Generate the Public Works Director Quarterly Packet as HTML."""
    os.makedirs(output_dir, exist_ok=True)

    permittees = datasets["permittees"]
    inspections = datasets["inspections"]
    settlement_failures = datasets["settlement_failures"]

    # Full-history predictions (all historical permits, not only the eval set)
    full_predictions = model_results["full_predictions"]

    # --- Quarter-scoped summary statistics ---
    quarter_permits = feature_df[
        (feature_df["issue_date"] >= quarter_start) &
        (feature_df["issue_date"] <= quarter_end)
    ]
    quarter_inspections = inspections[
        (inspections["inspection_date"] >= quarter_start) &
        (inspections["inspection_date"] <= quarter_end)
    ]
    quarter_failures = settlement_failures[
        (settlement_failures["failure_date"] >= quarter_start) &
        (settlement_failures["failure_date"] <= quarter_end)
    ]

    total_permits = len(quarter_permits)
    total_inspections = len(quarter_inspections)
    total_failures = len(quarter_failures)
    failure_rate = total_failures / total_permits if total_permits > 0 else 0.0
    total_violations = int(quarter_permits["moratorium_violated"].sum()) if not quarter_permits.empty else 0

    # Previous quarter (immediately preceding calendar quarter)
    prev_qs, prev_qe = _get_prev_quarter_range(quarter)
    prev_permits_df = feature_df[
        (feature_df["issue_date"] >= prev_qs) & (feature_df["issue_date"] <= prev_qe)
    ]
    prev_insp_df = inspections[
        (inspections["inspection_date"] >= prev_qs) & (inspections["inspection_date"] <= prev_qe)
    ]
    prev_fail_df = settlement_failures[
        (settlement_failures["failure_date"] >= prev_qs) & (settlement_failures["failure_date"] <= prev_qe)
    ]

    if len(prev_permits_df) > 0:
        pp = len(prev_permits_df)
        pi = len(prev_insp_df)
        pf = len(prev_fail_df)
        pfr = pf / pp if pp > 0 else 0.0
        pv = int(prev_permits_df["moratorium_violated"].sum())
        prev_permits = pp
        prev_inspections = pi
        prev_failures = pf
        prev_failure_rate = f"{pfr:.3f}"
        prev_violations = pv
        delta_permits = f"{total_permits - pp:+d}"
        delta_inspections = f"{total_inspections - pi:+d}"
        delta_failures = f"{total_failures - pf:+d}"
        delta_failure_rate = f"{failure_rate - pfr:+.3f}"
        delta_violations = f"{total_violations - pv:+d}"
    else:
        prev_permits = prev_inspections = prev_failures = prev_violations = "N/A"
        prev_failure_rate = "N/A"
        delta_permits = delta_inspections = delta_failures = delta_violations = "N/A"
        delta_failure_rate = "N/A"

    summary = {
        "total_permits": total_permits,
        "total_inspections": total_inspections,
        "total_failures": total_failures,
        "failure_rate": f"{failure_rate:.3f}",
        "total_violations": total_violations,
        "prev_permits": prev_permits,
        "prev_inspections": prev_inspections,
        "prev_failures": prev_failures,
        "prev_failure_rate": prev_failure_rate,
        "prev_violations": prev_violations,
        "delta_permits": delta_permits,
        "delta_inspections": delta_inspections,
        "delta_failures": delta_failures,
        "delta_failure_rate": delta_failure_rate,
        "delta_violations": delta_violations,
    }

    # --- Top-10 highest-risk permittees (full-history predictions, scoped to quarter) ---
    quarter_preds = full_predictions[
        (full_predictions["issue_date"] >= quarter_start) &
        (full_predictions["issue_date"] <= quarter_end)
    ]

    if not quarter_preds.empty:
        permittee_risk = quarter_preds.groupby("permittee_id").agg(
            combined_predicted_risk=("combined_predicted_risk", "mean"),
            craftsmanship_predicted_risk=("craftsmanship_predicted_risk", "mean"),
            subgrade_predicted_risk=("subgrade_predicted_risk", "mean"),
            craft_overall_pass_rate=("craft_overall_pass_rate", "first"),
            bond_claim_count=("bond_claim_count", "first"),
            total_fees_assessed=("total_fees_assessed", "first"),
            fee_to_bond_ratio=("fee_to_bond_ratio", "first"),
        ).reset_index()
        permittee_risk["non_craft_delta"] = (
            permittee_risk["combined_predicted_risk"] - permittee_risk["craftsmanship_predicted_risk"]
        )
        permittee_risk = permittee_risk.merge(
            permittees[["permittee_id", "name", "type"]], on="permittee_id", how="left"
        )
        permittee_risk = (
            permittee_risk.sort_values("combined_predicted_risk", ascending=False).head(10)
        )
        top_permittees = permittee_risk.to_dict("records")
    else:
        top_permittees = []

    corridor_violations = corridor_quarter_df.to_dict("records")

    craft_m = model_results["craftsmanship_metrics"]
    sub_m = model_results["subgrade_metrics"]
    comb_m = model_results["combined_metrics"]
    metrics = {
        "craft_accuracy": craft_m["accuracy"],
        "craft_precision": craft_m["precision"],
        "craft_recall": craft_m["recall"],
        "craft_f1": craft_m["f1"],
        "craft_roc_auc": craft_m["roc_auc"],
        "craft_cv_roc_auc": craft_m["cv_roc_auc_mean"],
        "sub_accuracy": sub_m["accuracy"],
        "sub_precision": sub_m["precision"],
        "sub_recall": sub_m["recall"],
        "sub_f1": sub_m["f1"],
        "sub_roc_auc": sub_m["roc_auc"],
        "sub_cv_roc_auc": sub_m["cv_roc_auc_mean"],
        "comb_accuracy": comb_m["accuracy"],
        "comb_precision": comb_m["precision"],
        "comb_recall": comb_m["recall"],
        "comb_f1": comb_m["f1"],
        "comb_roc_auc": comb_m["roc_auc"],
        "comb_cv_roc_auc": comb_m["cv_roc_auc_mean"],
        "delta_comb_vs_craft": model_results["roc_auc_delta_combined_vs_craft"],
        "delta_comb_vs_sub": model_results["roc_auc_delta_combined_vs_subgrade"],
        "delta_sub_vs_craft": model_results["roc_auc_delta_subgrade_vs_craft"],
    }

    template = Template(DIRECTOR_REPORT_TEMPLATE)
    html_content = template.render(
        quarter=quarter,
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        summary=summary,
        top_permittees=top_permittees,
        corridor_violations=corridor_violations,
        metrics=metrics,
    )

    filepath = os.path.join(output_dir, f"director_report_{quarter}.html")
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html_content)

    return filepath


# =============================================================================
# Report Generation - Inspector Report
# =============================================================================

INSPECTOR_REPORT_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Inspector Surveillance Prioritization Packet</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f9f9f9; }
        h1 { color: #2c3e50; border-bottom: 3px solid #e74c3c; padding-bottom: 10px; }
        h2 { color: #34495e; margin-top: 30px; }
        h3 { color: #7f8c8d; margin-top: 20px; }
        table { border-collapse: collapse; width: 100%; margin: 15px 0; background: white; }
        th { background: #e74c3c; color: white; padding: 12px 8px; text-align: left; }
        td { padding: 10px 8px; border-bottom: 1px solid #ddd; }
        tr:hover { background: #f5f5f5; }
        .timestamp { color: #7f8c8d; font-size: 0.9em; }
        .inspector-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>Inspector Surveillance Prioritization Packet</h1>
    <p class="timestamp">Generated: {{ timestamp }}</p>

    <h2>Top-20 Highest-Risk Prospective Permits</h2>
    <table>
        <tr>
            <th>Rank</th><th>Permit ID</th><th>Permittee</th><th>Street Segment</th>
            <th>Combined Predicted Prob.</th><th>Craft Predicted Prob.</th>
            <th>Subgrade Predicted Prob.</th><th>Non-Craft Risk Delta</th>
            <th>Pavement Age (days)</th><th>Moratorium Violated</th><th>Craft Pass Rate</th>
        </tr>
        {% for row in top_20 %}
        <tr>
            <td>{{ loop.index }}</td>
            <td>{{ row.permit_id }}</td>
            <td>{{ row.permittee_name }}</td>
            <td>{{ row.street_segment }}</td>
            <td>{{ "%.4f"|format(row.combined_predicted_risk) }}</td>
            <td>{{ "%.4f"|format(row.craftsmanship_predicted_risk) }}</td>
            <td>{{ "%.4f"|format(row.subgrade_predicted_risk) }}</td>
            <td>{{ "%.4f"|format(row.non_craft_delta) }}</td>
            <td>{{ row.pavement_age_at_cut_days }}</td>
            <td>{{ "Yes" if row.moratorium_violated else "No" }}</td>
            <td>{{ "%.3f"|format(row.craft_overall_pass_rate) }}</td>
        </tr>
        {% endfor %}
    </table>

    <h2>Inspector Assignments (Round-Robin)</h2>
    {% for inspector in inspector_assignments %}
    <div class="inspector-section">
        <h3>Inspector {{ inspector.inspector_id }}</h3>
        <table>
            <tr>
                <th>Permit ID</th><th>Permittee</th><th>Street Segment</th>
                <th>Combined Predicted Prob.</th><th>Pavement Age (days)</th>
            </tr>
            {% for row in inspector.permits %}
            <tr>
                <td>{{ row.permit_id }}</td>
                <td>{{ row.permittee_name }}</td>
                <td>{{ row.street_segment }}</td>
                <td>{{ "%.4f"|format(row.combined_predicted_risk) }}</td>
                <td>{{ row.pavement_age_at_cut_days }}</td>
            </tr>
            {% endfor %}
        </table>
    </div>
    {% endfor %}

    <h2>Full Permit Priority List (has_failure == 0)</h2>
    <table>
        <tr>
            <th>Rank</th><th>Permit ID</th><th>Permittee</th><th>Street Segment</th>
            <th>Combined Predicted Prob.</th><th>Craft Predicted Prob.</th>
            <th>Subgrade Predicted Prob.</th><th>Non-Craft Risk Delta</th>
            <th>Pavement Age (days)</th><th>Moratorium Violated</th><th>Craft Pass Rate</th>
        </tr>
        {% for row in full_list %}
        <tr>
            <td>{{ loop.index }}</td>
            <td>{{ row.permit_id }}</td>
            <td>{{ row.permittee_name }}</td>
            <td>{{ row.street_segment }}</td>
            <td>{{ "%.4f"|format(row.combined_predicted_risk) }}</td>
            <td>{{ "%.4f"|format(row.craftsmanship_predicted_risk) }}</td>
            <td>{{ "%.4f"|format(row.subgrade_predicted_risk) }}</td>
            <td>{{ "%.4f"|format(row.non_craft_delta) }}</td>
            <td>{{ row.pavement_age_at_cut_days }}</td>
            <td>{{ "Yes" if row.moratorium_violated else "No" }}</td>
            <td>{{ "%.3f"|format(row.craft_overall_pass_rate) }}</td>
        </tr>
        {% endfor %}
    </table>
</body>
</html>
"""


def generate_inspector_report(
    feature_df: pd.DataFrame,
    model_results: dict,
    datasets: dict[str, Union[pd.DataFrame, dict[str, int]]],
    output_dir: str,
    num_inspectors: int = 4,
) -> str:
    """Generate the Inspector Surveillance Prioritization Packet as HTML."""
    os.makedirs(output_dir, exist_ok=True)

    permittees = datasets["permittees"]
    street_segments = datasets["street_segments"]

    # Full-history predictions for all permits (not restricted to eval set)
    full_predictions = model_results["full_predictions"]

    # Restrict to permits where has_failure == 0 (prospective surveillance targets)
    surveillance_df = full_predictions[full_predictions["has_failure"] == 0].copy()

    # Merge permittee name
    surveillance_df = surveillance_df.merge(
        permittees[["permittee_id", "name"]], on="permittee_id", how="left"
    )
    surveillance_df = surveillance_df.rename(columns={"name": "permittee_name"})

    # Merge street segment / corridor info
    surveillance_df = surveillance_df.merge(
        street_segments[["segment_id", "corridor_name"]],
        left_on="street_segment_id", right_on="segment_id", how="left"
    )
    surveillance_df["street_segment"] = (
        surveillance_df["street_segment_id"] + " ("
        + surveillance_df["corridor_name"].fillna("") + ")"
    )

    # Non-craftsmanship risk delta
    surveillance_df["non_craft_delta"] = (
        surveillance_df["combined_predicted_risk"] - surveillance_df["craftsmanship_predicted_risk"]
    )

    # Sort by Combined Model predicted failure probability descending
    surveillance_df = (
        surveillance_df.sort_values("combined_predicted_risk", ascending=False)
        .reset_index(drop=True)
    )

    surveillance_df["pavement_age_at_cut_days"] = (
        surveillance_df["pavement_age_at_cut_days"].fillna(0).astype(int)
    )

    # All 10 required columns for the priority list
    cols_for_report = [
        "permit_id", "permittee_name", "street_segment",
        "combined_predicted_risk", "craftsmanship_predicted_risk", "subgrade_predicted_risk",
        "non_craft_delta", "pavement_age_at_cut_days", "moratorium_violated",
        "craft_overall_pass_rate"
    ]

    full_list = surveillance_df[cols_for_report].to_dict("records")
    top_20 = full_list[:20]

    # Round-robin assignment of top-20 across num_inspectors inspectors
    inspector_assignments = []
    for i in range(num_inspectors):
        inspector_permits = [top_20[j] for j in range(i, len(top_20), num_inspectors)]
        inspector_assignments.append({
            "inspector_id": i + 1,
            "permits": inspector_permits,
        })

    template = Template(INSPECTOR_REPORT_TEMPLATE)
    html_content = template.render(
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        top_20=top_20,
        full_list=full_list,
        inspector_assignments=inspector_assignments,
    )

    filepath = os.path.join(output_dir, "inspector_report.html")
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html_content)

    return filepath


# =============================================================================
# CLI Entry Point
# =============================================================================


def main():
    """Parse CLI arguments and orchestrate the full pipeline."""
    parser = argparse.ArgumentParser(
        description="Municipal ROW Permit Compliance Analytics Pipeline"
    )
    parser.add_argument(
        "--quarter", required=True,
        help="Reporting quarter in Q<1-4>-YYYY format (e.g., Q1-2024)"
    )
    parser.add_argument(
        "--output-dir", required=True,
        help="Directory to write HTML reports"
    )
    parser.add_argument(
        "--data-dir", default="data/",
        help="Directory containing CSV data files (default: data/)"
    )
    args = parser.parse_args()

    # Validate quarter format: must be exactly Q<1-4>-YYYY
    quarter_str = args.quarter
    match = re.fullmatch(r"Q([1-4])-(\d{4})", quarter_str)
    if not match:
        parser.error(
            f"Invalid --quarter '{quarter_str}'. "
            "Expected format Q<1-4>-YYYY (e.g., Q1-2024, Q3-2019)."
        )

    q_num = int(match.group(1))
    year = int(match.group(2))

    quarter_ranges = {
        1: (f"{year}-01-01", f"{year}-03-31"),
        2: (f"{year}-04-01", f"{year}-06-30"),
        3: (f"{year}-07-01", f"{year}-09-30"),
        4: (f"{year}-10-01", f"{year}-12-31"),
    }
    quarter_start = pd.Timestamp(quarter_ranges[q_num][0])
    quarter_end = pd.Timestamp(quarter_ranges[q_num][1])

    logger.info(f"Running pipeline for {quarter_str} ({quarter_start.date()} to {quarter_end.date()})")

    datasets = load_and_validate(args.data_dir)
    feature_df = engineer_features(datasets)
    model_results = train_models(feature_df)
    corridor_quarter_df = analyze_moratorium_violations(
        feature_df, datasets, quarter_start, quarter_end
    )
    director_path = generate_director_report(
        quarter_str, quarter_start, quarter_end,
        feature_df, model_results, corridor_quarter_df,
        datasets, args.output_dir
    )
    inspector_path = generate_inspector_report(
        feature_df, model_results, datasets, args.output_dir
    )

    print(f"Reports generated successfully:")
    print(f"  Director Report: {director_path}")
    print(f"  Inspector Report: {inspector_path}")


if __name__ == "__main__":
    main()