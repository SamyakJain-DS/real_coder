import os

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# load_district_data
# ---------------------------------------------------------------------------

def load_district_data(data_dir: str) -> pd.DataFrame:
    """
    Read the six district-level CSV files from data_dir, pivot the expenditure
    data, compute aggregate expenditure columns, merge everything on
    (district_id, year), and return a single DataFrame with one row per
    (district_id, year).

    Parameters
    ----------
    data_dir : str
        Path to the directory that contains the six CSV files.

    Returns
    -------
    pd.DataFrame
        One row per (district_id, year) with all source columns plus the eight
        derived expenditure columns.

    Raises
    ------
    FileNotFoundError
        If any of the six required CSV files is absent from data_dir.
    """
    required = [
        "district_finance.csv",
        "district_expenditure.csv",
        "demographics.csv",
        "federal_grants.csv",
        "capital_debt.csv",
        "property_wealth.csv",
    ]
    for fname in required:
        fpath = os.path.join(data_dir, fname)
        if not os.path.isfile(fpath):
            raise FileNotFoundError(f"Required file not found: {fpath}")

    # --- read individual files ---
    finance = pd.read_csv(
        os.path.join(data_dir, "district_finance.csv"),
        dtype={"district_id": str},
    )
    expenditure = pd.read_csv(
        os.path.join(data_dir, "district_expenditure.csv"),
        dtype={"district_id": str, "function_code": str, "object_code": str},
    )
    demographics = pd.read_csv(
        os.path.join(data_dir, "demographics.csv"),
        dtype={"district_id": str},
    )
    federal_grants = pd.read_csv(
        os.path.join(data_dir, "federal_grants.csv"),
        dtype={"district_id": str},
    )
    capital_debt = pd.read_csv(
        os.path.join(data_dir, "capital_debt.csv"),
        dtype={"district_id": str},
    )
    property_wealth = pd.read_csv(
        os.path.join(data_dir, "property_wealth.csv"),
        dtype={"district_id": str},
    )

    # --- pivot district_expenditure ---
    func_map = {"1000": "instruction", "2000": "support"}
    obj_map  = {"100": "salaries", "200": "benefits", "300": "purchased_services"}

    expenditure["_col"] = (
        expenditure["function_code"].map(func_map)
        + "_"
        + expenditure["object_code"].map(obj_map)
        + "_ppupil"
    )

    exp_pivot = (
        expenditure
        .pivot_table(
            index=["district_id", "year"],
            columns="_col",
            values="ppupil_expenditure",
            aggfunc="first",
        )
        .reset_index()
    )
    exp_pivot.columns.name = None

    # Guarantee all six cross-classified columns are present
    six_cols = [
        "instruction_salaries_ppupil",
        "instruction_benefits_ppupil",
        "instruction_purchased_services_ppupil",
        "support_salaries_ppupil",
        "support_benefits_ppupil",
        "support_purchased_services_ppupil",
    ]
    for col in six_cols:
        if col not in exp_pivot.columns:
            exp_pivot[col] = np.nan

    # Function-level aggregate columns
    exp_pivot["instruction_ppupil"] = (
        exp_pivot["instruction_salaries_ppupil"]
        + exp_pivot["instruction_benefits_ppupil"]
        + exp_pivot["instruction_purchased_services_ppupil"]
    )
    exp_pivot["support_ppupil"] = (
        exp_pivot["support_salaries_ppupil"]
        + exp_pivot["support_benefits_ppupil"]
        + exp_pivot["support_purchased_services_ppupil"]
    )

    # --- merge all six sources ---
    df = finance.merge(exp_pivot,      on=["district_id", "year"], how="inner")
    df = df.merge(demographics,         on=["district_id", "year"], how="inner")
    df = df.merge(federal_grants,       on=["district_id", "year"], how="inner")
    df = df.merge(capital_debt,         on=["district_id", "year"], how="inner")
    df = df.merge(property_wealth,      on=["district_id", "year"], how="inner")

    return df


# ---------------------------------------------------------------------------
# load_school_data
# ---------------------------------------------------------------------------

def load_school_data(data_dir: str) -> pd.DataFrame:
    """
    Read school_resources.csv and school_demographics.csv from data_dir, merge
    on (district_id, school_id, year), and return a DataFrame with one row per
    (district_id, school_id, year).

    Parameters
    ----------
    data_dir : str
        Path to the directory that contains the two CSV files.

    Returns
    -------
    pd.DataFrame
        Columns: district_id, school_id, year, ppupil_expenditure,
        outcome_score, pct_poverty, pct_ell, pct_disability.

    Raises
    ------
    FileNotFoundError
        If either CSV file is absent from data_dir.
    """
    for fname in ["school_resources.csv", "school_demographics.csv"]:
        fpath = os.path.join(data_dir, fname)
        if not os.path.isfile(fpath):
            raise FileNotFoundError(f"Required file not found: {fpath}")

    resources = pd.read_csv(
        os.path.join(data_dir, "school_resources.csv"),
        dtype={"district_id": str, "school_id": str},
    )
    school_demo = pd.read_csv(
        os.path.join(data_dir, "school_demographics.csv"),
        dtype={"district_id": str, "school_id": str},
    )

    df = resources.merge(school_demo, on=["district_id", "school_id", "year"], how="inner")

    return df[[
        "district_id", "school_id", "year",
        "ppupil_expenditure", "outcome_score",
        "pct_poverty", "pct_ell", "pct_disability",
    ]]


# ---------------------------------------------------------------------------
# compute_equity_metrics
# ---------------------------------------------------------------------------

def compute_equity_metrics(df: pd.DataFrame, need_weights: dict) -> pd.DataFrame:
    """
    Add six equity metric columns to the district-level DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame returned by load_district_data.
    need_weights : dict
        Must contain keys: poverty_weight, ell_weight, disability_weight (all
        float).

    Returns
    -------
    pd.DataFrame
        Input DataFrame with six additional float columns:
        total_pprev, state_local_revenue, need_adjusted_enrollment,
        need_weighted_pprev, equity_cv, adequacy_gap.

    Raises
    ------
    KeyError
        If need_weights is missing any of the three required keys.
    """
    # KeyError is raised implicitly if a key is absent
    poverty_weight   = need_weights["poverty_weight"]
    ell_weight       = need_weights["ell_weight"]
    disability_weight = need_weights["disability_weight"]

    df = df.copy()

    df["total_pprev"] = df["state_foundation_pprev"] + df["local_tax_pprev"]
    df["state_local_revenue"] = df["total_pprev"] * df["enrollment"]
    df["need_adjusted_enrollment"] = df["enrollment"] * (
        1.0
        + poverty_weight   * df["pct_poverty"]
        + ell_weight       * df["pct_ell"]
        + disability_weight * df["pct_disability"]
    )
    df["need_weighted_pprev"] = df["state_local_revenue"] / df["need_adjusted_enrollment"]

    # Per-year statistics (sample std, ddof=1)
    grp = df.groupby("year")["need_weighted_pprev"]
    year_std    = grp.std(ddof=1)
    year_mean   = grp.mean()
    year_median = grp.median()

    year_stats = pd.DataFrame({
        "year":       year_mean.index,
        "equity_cv":  (year_std / year_mean).values,
        "_yr_median": year_median.values,
    })

    df = df.merge(year_stats, on="year", how="left")
    df["adequacy_gap"] = df["need_weighted_pprev"] - df["_yr_median"]
    df = df.drop(columns=["_yr_median"])

    return df


# ---------------------------------------------------------------------------
# decompose_fiscal_effects
# ---------------------------------------------------------------------------

def decompose_fiscal_effects(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add five fiscal decomposition columns to the district-level DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame returned by compute_equity_metrics.

    Returns
    -------
    pd.DataFrame
        Input DataFrame with five additional float columns:
        fiscal_capacity_index, fiscal_effort_index, capacity_predicted_rev,
        effort_residual, debt_burden_ppupil.
    """
    df = df.copy()

    # Per-year means for normalisation
    year_means = (
        df.groupby("year")
        .agg(
            _mean_avpp=("assessed_value_per_pupil", "mean"),
            _mean_mill=("mill_rate",                "mean"),
        )
        .reset_index()
    )

    df = df.merge(year_means, on="year", how="left")
    df["fiscal_capacity_index"] = df["assessed_value_per_pupil"] / df["_mean_avpp"]
    df["fiscal_effort_index"]   = df["mill_rate"]                / df["_mean_mill"]
    df = df.drop(columns=["_mean_avpp", "_mean_mill"])

    # OLS per year: regress total_pprev on fiscal_capacity_index with intercept
    def _ols_predict(grp: pd.DataFrame) -> pd.Series:
        X = np.column_stack([
            np.ones(len(grp)),
            grp["fiscal_capacity_index"].values,
        ])
        y = grp["total_pprev"].values
        coeffs, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
        return pd.Series(X @ coeffs, index=grp.index)

    df["capacity_predicted_rev"] = (
        df.groupby("year", group_keys=False).apply(_ols_predict)
    )
    df["effort_residual"]    = df["total_pprev"] - df["capacity_predicted_rev"]
    df["debt_burden_ppupil"] = df["bonded_indebtedness"] / df["enrollment"]

    return df


# ---------------------------------------------------------------------------
# identify_resource_outcome_patterns
# ---------------------------------------------------------------------------

def identify_resource_outcome_patterns(school_df: pd.DataFrame) -> pd.DataFrame:
    """
    Add need_adjusted_outcome_score, resource_outcome_correlation, and
    outcome_trajectory columns to the school-level DataFrame.

    Parameters
    ----------
    school_df : pd.DataFrame
        DataFrame returned by load_school_data.

    Returns
    -------
    pd.DataFrame
        Input DataFrame with three additional float columns.

    Notes
    -----
    * need_adjusted_outcome_score: OLS residual of outcome_score on
      [intercept, pct_poverty, pct_ell, pct_disability] per
      (district_id, school_id).  NaN when n < 5 or design matrix is
      rank-deficient.
    * resource_outcome_correlation: Pearson r between ppupil_expenditure and
      need_adjusted_outcome_score per pair.  NaN when fewer than 2 non-NaN
      need_adjusted_outcome_score values.
    * outcome_trajectory: OLS slope of need_adjusted_outcome_score on year per
      pair.  NaN when fewer than 2 non-NaN need_adjusted_outcome_score values.
    """
    df = school_df.copy()
    df["need_adjusted_outcome_score"] = np.nan
    df["resource_outcome_correlation"] = np.nan
    df["outcome_trajectory"]           = np.nan

    for (district_id, school_id), grp in df.groupby(["district_id", "school_id"]):
        idx = grp.index
        n   = len(grp)

        # ---- need_adjusted_outcome_score ----
        if n >= 5:
            X_demo = np.column_stack([
                np.ones(n),
                grp["pct_poverty"].values,
                grp["pct_ell"].values,
                grp["pct_disability"].values,
            ])
            y_outcome = grp["outcome_score"].values

            if np.linalg.matrix_rank(X_demo) == X_demo.shape[1]:
                coeffs, _, _, _ = np.linalg.lstsq(X_demo, y_outcome, rcond=None)
                residuals = y_outcome - X_demo @ coeffs
                df.loc[idx, "need_adjusted_outcome_score"] = residuals

        # ---- resource_outcome_correlation and outcome_trajectory ----
        naos      = df.loc[idx, "need_adjusted_outcome_score"]
        valid_idx = naos.index[naos.notna()]
        n_valid   = len(valid_idx)

        if n_valid >= 2:
            naos_valid = naos.loc[valid_idx].values
            exp_valid  = grp.loc[valid_idx, "ppupil_expenditure"].values
            year_valid = grp.loc[valid_idx, "year"].values.astype(float)

            # Pearson correlation between ppupil_expenditure and
            # need_adjusted_outcome_score
            corr = np.corrcoef(exp_valid, naos_valid)[0, 1]
            df.loc[idx, "resource_outcome_correlation"] = corr

            # OLS slope of need_adjusted_outcome_score on year (with intercept)
            X_traj  = np.column_stack([np.ones(n_valid), year_valid])
            c_traj, _, _, _ = np.linalg.lstsq(X_traj, naos_valid, rcond=None)
            slope = c_traj[1]
            df.loc[idx, "outcome_trajectory"] = slope

    return df


# ---------------------------------------------------------------------------
# generate_nces_ccd_submission
# ---------------------------------------------------------------------------

def generate_nces_ccd_submission(df: pd.DataFrame, output_path: str) -> None:
    """
    Write the NCES CCD fiscal submission CSV (one row per district_id × year,
    twenty columns) to output_path.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame returned by decompose_fiscal_effects.
    output_path : str
        Destination file path.

    Raises
    ------
    ValueError
        If output_path is an empty string.
    """
    if output_path == "":
        raise ValueError("output_path cannot be an empty string")

    out = pd.DataFrame(index=df.index)

    # Identity columns
    out["district_id"] = df["district_id"]
    out["year"]        = df["year"]

    # Revenue
    out["state_revenue"]       = df["state_foundation_pprev"] * df["enrollment"]
    out["local_revenue"]       = df["local_tax_pprev"]        * df["enrollment"]
    out["federal_revenue_approx"] = (
        df["title1_expenditure"]
        + df["idea_expenditure"]
        + df["title3_expenditure"]
    )
    out["total_revenue"] = (
        out["state_revenue"] + out["local_revenue"] + out["federal_revenue_approx"]
    )

    # Expenditure aggregates
    out["instruction_expenditure"]    = df["instruction_ppupil"] * df["enrollment"]
    out["support_services_expenditure"] = df["support_ppupil"]   * df["enrollment"]
    out["capital_outlay_expenditure"] = df["capital_expenditure"]
    out["total_expenditure"] = (
        out["instruction_expenditure"]
        + out["support_services_expenditure"]
        + out["capital_outlay_expenditure"]
    )

    # Detailed expenditure by object
    out["instruction_salaries"]           = df["instruction_salaries_ppupil"]           * df["enrollment"]
    out["instruction_benefits"]           = df["instruction_benefits_ppupil"]           * df["enrollment"]
    out["instruction_purchased_services"] = df["instruction_purchased_services_ppupil"] * df["enrollment"]
    out["support_salaries"]               = df["support_salaries_ppupil"]               * df["enrollment"]
    out["support_benefits"]               = df["support_benefits_ppupil"]               * df["enrollment"]
    out["support_purchased_services"]     = df["support_purchased_services_ppupil"]     * df["enrollment"]

    # Debt and federal grant pass-throughs (as-is)
    out["long_term_debt"]        = df["bonded_indebtedness"]
    out["title1_expenditure"]    = df["title1_expenditure"]
    out["idea_expenditure"]      = df["idea_expenditure"]
    out["title3_expenditure"]    = df["title3_expenditure"]

    out.to_csv(output_path, index=False)


# ---------------------------------------------------------------------------
# generate_legislative_report
# ---------------------------------------------------------------------------

def generate_legislative_report(
    df: pd.DataFrame,
    school_df: pd.DataFrame,
    output_path: str,
) -> None:
    """
    Write the state legislative school finance equity analysis CSV (one row per
    year, sixteen columns) to output_path.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame returned by decompose_fiscal_effects.
    school_df : pd.DataFrame
        DataFrame returned by identify_resource_outcome_patterns.
    output_path : str
        Destination file path.

    Raises
    ------
    ValueError
        If output_path is an empty string.
    """
    if output_path == "":
        raise ValueError("output_path cannot be an empty string")

    # School-level constants: one value per unique (district_id, school_id) pair
    school_pairs = school_df.drop_duplicates(subset=["district_id", "school_id"])

    mean_roc = school_pairs["resource_outcome_correlation"].mean()

    ot = school_pairs["outcome_trajectory"]
    pct_positive_traj = float((ot > 0).sum()) / float(len(ot))

    rows = []
    for year, grp in df.groupby("year"):
        total_pprev       = grp["total_pprev"]
        nwpprev           = grp["need_weighted_pprev"]
        fci               = grp["fiscal_capacity_index"]
        fei               = grp["fiscal_effort_index"]
        er                = grp["effort_residual"]
        adequacy_gap      = grp["adequacy_gap"]

        row = {
            "year":                   int(year),
            "num_districts":          int(grp["district_id"].nunique()),
            "mean_pprev":             float(total_pprev.mean()),
            "median_pprev":           float(total_pprev.median()),
            "cv_pprev":               float(total_pprev.std(ddof=1) / total_pprev.mean()),
            "mean_need_weighted_pprev":   float(nwpprev.mean()),
            "median_need_weighted_pprev": float(nwpprev.median()),
            # equity_cv is constant within each year; take the first value
            "cv_need_weighted_pprev":     float(grp["equity_cv"].iloc[0]),
            "mean_adequacy_gap":          float(adequacy_gap.mean()),
            "pct_districts_below_adequacy": float((adequacy_gap < 0).sum()) / float(len(adequacy_gap)),
            "cv_fiscal_capacity_index":   float(fci.std(ddof=1) / fci.mean()),
            "cv_fiscal_effort_index":     float(fei.std(ddof=1) / fei.mean()),
            "sd_effort_residual":         float(er.std(ddof=1)),
            "mean_debt_burden_ppupil":    float(grp["debt_burden_ppupil"].mean()),
            "mean_school_resource_outcome_correlation": float(mean_roc),
            "pct_schools_positive_outcome_trajectory":  float(pct_positive_traj),
        }
        rows.append(row)

    report = pd.DataFrame(rows)
    report.to_csv(output_path, index=False)
