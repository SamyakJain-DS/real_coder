import os
import sys
from typing import Dict

import pandas as pd
from sklearn.linear_model import LinearRegression


REQUIRED_FILES = {
    "vehicles": "vehicles.csv",
    "maintenance": "maintenance.csv",
    "utilization": "utilization.csv",
    "fuel": "fuel.csv",
}


def load_fleet_data(data_dir: str) -> Dict[str, pd.DataFrame]:
    """Read the four required CSV files from ``data_dir``.

    Raises ``FileNotFoundError`` if any of the required CSV files is missing.
    """
    for fname in REQUIRED_FILES.values():
        path = os.path.join(data_dir, fname)
        if not os.path.isfile(path):
            raise FileNotFoundError(
                f"Required CSV file not found: {path}"
            )

    data: Dict[str, pd.DataFrame] = {}
    for key, fname in REQUIRED_FILES.items():
        path = os.path.join(data_dir, fname)
        data[key] = pd.read_csv(path)

    str_cols = {
        "vehicles": ["vehicle_id", "vehicle_type", "make", "model"],
        "maintenance": [
            "vehicle_id", "work_order_id", "date",
            "maintenance_type", "operator_id",
        ],
        "utilization": ["vehicle_id", "date", "route", "season"],
        "fuel": ["vehicle_id", "date", "route", "season"],
    }
    for key, cols in str_cols.items():
        for col in cols:
            if col in data[key].columns:
                data[key][col] = data[key][col].astype(str)

    float_cols = {
        "maintenance": ["labor_cost", "parts_cost"],
        "utilization": ["miles_driven", "hours_operated"],
        "fuel": ["fuel_gallons", "miles_driven"],
    }
    for key, cols in float_cols.items():
        for col in cols:
            if col in data[key].columns:
                data[key][col] = data[key][col].astype(float)

    if "year" in data["vehicles"].columns:
        data["vehicles"]["year"] = data["vehicles"]["year"].astype(int)

    return data


def _min_max_normalize(series: pd.Series) -> pd.Series:
    """Min-max scale a numeric Series into [0, 1].

    When max equals min (degenerate case where every vehicle shares the same
    raw value for the metric), the normalized value is 0.0 for every row, per
    the prompt's specification.
    """
    s = series.astype(float)
    mn = s.min()
    mx = s.max()
    if mx == mn:
        return pd.Series(0.0, index=s.index, dtype=float)
    return (s - mn) / (mx - mn)


def compute_replacement_scores(
    vehicles_df: pd.DataFrame,
    maintenance_df: pd.DataFrame,
    utilization_df: pd.DataFrame,
) -> pd.DataFrame:
    """Compute per-vehicle replacement scores from duty-cycle wear metrics."""
    cost_per_record = (
        maintenance_df["labor_cost"].astype(float)
        + maintenance_df["parts_cost"].astype(float)
    )
    cost_df = (
        pd.DataFrame({
            "vehicle_id": maintenance_df["vehicle_id"].astype(str),
            "cost": cost_per_record,
        })
        .groupby("vehicle_id", as_index=False)["cost"]
        .sum()
        .rename(columns={"cost": "total_maintenance_cost"})
    )

    hours_df = (
        utilization_df.assign(
            vehicle_id=utilization_df["vehicle_id"].astype(str),
            hours_operated=utilization_df["hours_operated"].astype(float),
        )
        .groupby("vehicle_id", as_index=False)["hours_operated"]
        .sum()
        .rename(columns={"hours_operated": "cumulative_hours"})
    )

    df = vehicles_df[["vehicle_id", "year"]].copy()
    df["vehicle_id"] = df["vehicle_id"].astype(str)
    df["age_years"] = 2024 - df["year"].astype(int)
    df = df.merge(cost_df, on="vehicle_id", how="left")
    df = df.merge(hours_df, on="vehicle_id", how="left")
    df["total_maintenance_cost"] = df["total_maintenance_cost"].fillna(0.0).astype(float)
    df["cumulative_hours"] = df["cumulative_hours"].fillna(0.0).astype(float)
    df["age_years"] = df["age_years"].astype(float)

    norm_cost = _min_max_normalize(df["total_maintenance_cost"])
    norm_age = _min_max_normalize(df["age_years"])
    norm_hours = _min_max_normalize(df["cumulative_hours"])

    df["replacement_score"] = (norm_cost + norm_age + norm_hours).astype(float)
    threshold = df["replacement_score"].quantile(0.75)
    df["flagged"] = (df["replacement_score"] >= threshold).astype(bool)

    return df[["vehicle_id", "replacement_score", "flagged"]].reset_index(drop=True)


def _primary_operator(series: pd.Series) -> str:
    """Most-frequent operator_id with alphabetical tiebreak."""
    counts = series.value_counts()
    top = counts[counts == counts.max()].index.tolist()
    return sorted(top)[0]


def attribute_maintenance_costs(
    vehicles_df: pd.DataFrame,
    maintenance_df: pd.DataFrame,
) -> pd.DataFrame:
    """Attribute total maintenance cost growth to aging vs operator handling."""
    maint = maintenance_df.copy()
    maint["vehicle_id"] = maint["vehicle_id"].astype(str)
    maint["operator_id"] = maint["operator_id"].astype(str)
    maint["labor_cost"] = maint["labor_cost"].astype(float)
    maint["parts_cost"] = maint["parts_cost"].astype(float)

    maint["__total"] = maint["labor_cost"] + maint["parts_cost"]
    cost_df = (
        maint.groupby("vehicle_id", as_index=False)["__total"]
        .sum()
        .rename(columns={"__total": "total_maintenance_cost"})
    )

    primary = (
        maint.groupby("vehicle_id")["operator_id"]
        .apply(_primary_operator)
        .rename("primary_operator_id")
        .reset_index()
    )

    df = vehicles_df[["vehicle_id", "vehicle_type", "year"]].copy()
    df["vehicle_id"] = df["vehicle_id"].astype(str)
    df["vehicle_type"] = df["vehicle_type"].astype(str)
    df["age_years"] = (2024 - df["year"].astype(int)).astype(float)
    df = df.merge(cost_df, on="vehicle_id", how="left")
    df = df.merge(primary, on="vehicle_id", how="left")
    df["total_maintenance_cost"] = df["total_maintenance_cost"].fillna(0.0).astype(float)

    type_dummies = pd.get_dummies(df["vehicle_type"], prefix="vt", drop_first=True)
    op_dummies = pd.get_dummies(df["primary_operator_id"], prefix="op", drop_first=True)

    feature_blocks = [df[["age_years"]].astype(float)]
    if not type_dummies.empty and type_dummies.shape[1] > 0:
        feature_blocks.append(type_dummies.astype(float))
    if not op_dummies.empty and op_dummies.shape[1] > 0:
        feature_blocks.append(op_dummies.astype(float))
    X = pd.concat(feature_blocks, axis=1)
    y = df["total_maintenance_cost"].astype(float)

    model = LinearRegression()
    model.fit(X, y)

    coef_map = dict(zip(X.columns, model.coef_))
    age_coef = coef_map["age_years"]

    df["aging_cost"] = (age_coef * df["age_years"].astype(float)).astype(float)

    if op_dummies.shape[1] > 0:
        op_coef_series = pd.Series(
            {c: float(coef_map[c]) for c in op_dummies.columns}
        )
        df["operator_cost"] = (
            op_dummies.astype(float)
            .mul(op_coef_series, axis=1)
            .sum(axis=1)
            .astype(float)
        )
    else:
        df["operator_cost"] = pd.Series(0.0, index=df.index, dtype=float)

    return df[["vehicle_id", "vehicle_type", "aging_cost", "operator_cost"]].reset_index(drop=True)


def model_fuel_consumption(fuel_df: pd.DataFrame) -> pd.DataFrame:
    """Fit a linear model of fuel consumption_rate against route and season."""
    df = fuel_df.copy()
    df["route"] = df["route"].astype(str)
    df["season"] = df["season"].astype(str)
    df["fuel_gallons"] = df["fuel_gallons"].astype(float)
    df["miles_driven"] = df["miles_driven"].astype(float)
    df["consumption_rate"] = df["fuel_gallons"] / df["miles_driven"]

    encoded = pd.get_dummies(df[["route", "season"]], drop_first=False).astype(float)
    feature_cols = list(encoded.columns)
    X = encoded
    y = df["consumption_rate"].astype(float)

    model = LinearRegression()
    model.fit(X, y)

    unique_pairs = (
        df[["route", "season"]]
        .drop_duplicates()
        .reset_index(drop=True)
    )

    rows = []
    for _, pair in unique_pairs.iterrows():
        single = pd.DataFrame([{"route": pair["route"], "season": pair["season"]}])
        single_encoded = pd.get_dummies(
            single[["route", "season"]], drop_first=False
        ).astype(float)
        single_encoded = single_encoded.reindex(columns=feature_cols, fill_value=0.0)
        prediction = float(model.predict(single_encoded)[0])
        rows.append({
            "route": str(pair["route"]),
            "season": str(pair["season"]),
            "predicted_gallons_per_mile": prediction,
        })

    return pd.DataFrame(rows, columns=["route", "season", "predicted_gallons_per_mile"])


def generate_fleet_report(
    replacement_df: pd.DataFrame,
    attribution_df: pd.DataFrame,
    fuel_model_df: pd.DataFrame,
    output_path: str,
) -> None:
    """Write the three-section plain-text fleet planning report."""
    parent = os.path.dirname(output_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    lines = []

    lines.append("REPLACEMENT CANDIDATES")
    flagged = replacement_df[replacement_df["flagged"]].copy()
    flagged = flagged.sort_values(
        "replacement_score", ascending=False, kind="mergesort"
    )
    for _, row in flagged.iterrows():
        lines.append(f"{row['vehicle_id']}: {float(row['replacement_score']):.2f}")

    lines.append("MAINTENANCE COST ATTRIBUTION")
    agg = (
        attribution_df.groupby("vehicle_type", as_index=False)[["aging_cost", "operator_cost"]]
        .sum()
        .sort_values("vehicle_type", kind="mergesort")
    )
    for _, row in agg.iterrows():
        lines.append(
            f"{row['vehicle_type']} aging_cost: {float(row['aging_cost']):.2f} "
            f"operator_cost: {float(row['operator_cost']):.2f}"
        )

    lines.append("FUEL CONSUMPTION MODEL")
    fuel_sorted = fuel_model_df.copy().sort_values(
        ["route", "season"], kind="mergesort"
    )
    for _, row in fuel_sorted.iterrows():
        lines.append(
            f"{row['route']} {row['season']}: "
            f"{float(row['predicted_gallons_per_mile']):.4f}"
        )

    with open(output_path, "w") as fh:
        fh.write("\n".join(lines) + "\n")


def run_pipeline(data_dir: str, output_path: str) -> None:
    """Load data, run all three analyses, and write the report to ``output_path``."""
    data = load_fleet_data(data_dir)
    replacement_df = compute_replacement_scores(
        data["vehicles"], data["maintenance"], data["utilization"]
    )
    attribution_df = attribute_maintenance_costs(
        data["vehicles"], data["maintenance"]
    )
    fuel_model_df = model_fuel_consumption(data["fuel"])
    generate_fleet_report(
        replacement_df, attribution_df, fuel_model_df, output_path
    )


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.stderr.write(
            "Usage: python pipeline.py <data_dir> <output_path>\n"
        )
        sys.exit(1)
    run_pipeline(sys.argv[1], sys.argv[2])