import { useEffect, useMemo, useState } from 'react'
import { computeStats } from './lib/stats.js'
import { clearLibrary, loadLibrary, saveLibrary } from './lib/storage.js'

function PagesPerWeekChart({ rows }) {
  if (!rows || rows.length === 0) {
    return <p className="empty-hint">No activity data for chart yet.</p>
  }
  const maxPages = Math.max(...rows.map((r) => r.pages), 1)
  return (
    <div className="ppw-chart" role="img" aria-label="Pages read per week">
      {rows.map((row) => (
        <div key={row.weekStart} className="ppw-row">
          <span className="ppw-label">{row.weekStart}</span>
          <div className="ppw-track">
            <div
              className="ppw-fill"
              style={{ width: `${(row.pages / maxPages) * 100}%` }}
            />
          </div>
          <span className="ppw-value">{row.pages}</span>
        </div>
      ))}
    </div>
  )
}

function newId() {
  return globalThis.crypto?.randomUUID?.()
    ?? `id-${Date.now()}-${Math.random().toString(36).slice(2, 11)}`
}

function progressPct(currentPage, totalPages) {
  if (totalPages <= 0) return 0
  return Math.round((currentPage / totalPages) * 100)
}

export default function App() {
  const [books, setBooks] = useState([])
  const [activity, setActivity] = useState([])

  const [titleIn, setTitleIn] = useState('')
  const [authorIn, setAuthorIn] = useState('')
  const [pagesIn, setPagesIn] = useState('')

  const [errTitle, setErrTitle] = useState('')
  const [errAuthor, setErrAuthor] = useState('')
  const [errPages, setErrPages] = useState('')

  const [searchQuery, setSearchQuery] = useState('')
  const [filterAuthor, setFilterAuthor] = useState('')
  const [filterRating, setFilterRating] = useState('')
  const [filterYear, setFilterYear] = useState('')

  const [progressErr, setProgressErr] = useState({})
  const [progressDraft, setProgressDraft] = useState({})

  const [finishingId, setFinishingId] = useState(null)
  const [finishRating, setFinishRating] = useState('')
  const [finishReview, setFinishReview] = useState('')
  const [finishErrRating, setFinishErrRating] = useState('')
  const [finishErrReview, setFinishErrReview] = useState('')

  const [showResetConfirm, setShowResetConfirm] = useState(false)

  useEffect(() => {
    const lib = loadLibrary()
    setBooks(lib.books)
    setActivity(lib.activity)
  }, [])

  function persist(nextBooks, nextActivity) {
    saveLibrary({ books: nextBooks, activity: nextActivity })
    setBooks(nextBooks)
    setActivity(nextActivity)
  }

  const stats = useMemo(
    () => computeStats(books, activity, new Date()),
    [books, activity]
  )

  const authorOptions = useMemo(() => {
    const s = new Set(books.map((b) => b.author))
    return Array.from(s).sort((a, b) => a.localeCompare(b))
  }, [books])

  const yearOptions = useMemo(() => {
    const ys = new Set()
    for (const b of books) {
      if (b.status === 'finished' && b.finishedAt) {
        ys.add(new Date(b.finishedAt).getUTCFullYear())
      }
    }
    return Array.from(ys).sort((a, b) => b - a)
  }, [books])

  const filteredBooks = useMemo(() => {
    let list = books
    const q = searchQuery.trim().toLowerCase()
    if (q) {
      list = list.filter((b) => b.author.toLowerCase().includes(q))
    }
    if (filterAuthor) {
      list = list.filter((b) => b.author === filterAuthor)
    }
    if (filterRating) {
      const r = Number(filterRating)
      list = list.filter((b) => b.rating === r)
    }
    if (filterYear) {
      const yr = Number(filterYear)
      list = list.filter((b) => {
        if (!b.finishedAt) return false
        return new Date(b.finishedAt).getUTCFullYear() === yr
      })
    }
    return list
  }, [books, searchQuery, filterAuthor, filterRating, filterYear])

  const reading = useMemo(
    () => filteredBooks.filter((b) => b.status === 'currently_reading'),
    [filteredBooks]
  )
  const finished = useMemo(
    () => filteredBooks.filter((b) => b.status === 'finished'),
    [filteredBooks]
  )

  function submitAddBook(e) {
    e.preventDefault()
    setErrTitle('')
    setErrAuthor('')
    setErrPages('')

    const t = titleIn.trim()
    const a = authorIn.trim()
    const pRaw = pagesIn.trim()

    let bad = false
    if (!t) {
      setErrTitle('Title is required.')
      bad = true
    }
    if (!a) {
      setErrAuthor('Author is required.')
      bad = true
    }
    const p = parseInt(pRaw, 10)
    if (!/^\d+$/.test(pRaw) || p !== Number(pRaw) || p < 1) {
      setErrPages('Enter a positive integer for total pages.')
      bad = true
    }
    if (bad) return

    const book = {
      id: newId(),
      title: t,
      author: a,
      totalPages: p,
      currentPage: 0,
      status: 'currently_reading',
      rating: null,
      review: null,
      createdAt: new Date().toISOString(),
      finishedAt: null,
    }
    persist([...books, book], activity)
    setTitleIn('')
    setAuthorIn('')
    setPagesIn('')
  }

  function submitProgress(book, e) {
    e.preventDefault()
    const raw = progressDraft[book.id] ?? String(book.currentPage)
    setProgressErr((prev) => ({ ...prev, [book.id]: '' }))

    if (!/^\d+$/.test(raw.trim())) {
      setProgressErr((prev) => ({
        ...prev,
        [book.id]: 'Enter an integer between 0 and ' + book.totalPages + '.',
      }))
      return
    }
    const n = parseInt(raw, 10)
    if (n < 0 || n > book.totalPages) {
      setProgressErr((prev) => ({
        ...prev,
        [book.id]: 'Enter an integer between 0 and ' + book.totalPages + '.',
      }))
      return
    }

    if (n === book.currentPage) return

    if (n < book.currentPage) {
      const nextBooks = books.map((b) =>
        b.id === book.id ? { ...b, currentPage: n } : b
      )
      persist(nextBooks, activity)
      setProgressDraft((d) => ({ ...d, [book.id]: String(n) }))
      return
    }

    const pagesAdded = n - book.currentPage
    const timestamp = new Date().toISOString()
    const entry = {
      id: newId(),
      bookId: book.id,
      timestamp,
      pagesAdded,
    }
    const nextBooks = books.map((b) =>
      b.id === book.id ? { ...b, currentPage: n } : b
    )
    const nextActivity = [...activity, entry]
    persist(nextBooks, nextActivity)
    setProgressDraft((d) => ({ ...d, [book.id]: String(n) }))
  }

  function openFinish(book) {
    setFinishingId(book.id)
    setFinishRating('')
    setFinishReview('')
    setFinishErrRating('')
    setFinishErrReview('')
  }

  function submitFinish(book) {
    setFinishErrRating('')
    setFinishErrReview('')

    const rRaw = finishRating.trim()
    const rev = finishReview.trim()
    const r = parseInt(rRaw, 10)
    let bad = false
    if (!/^\d+$/.test(rRaw) || r < 1 || r > 5) {
      setFinishErrRating('Enter an integer from 1 through 5.')
      bad = true
    }
    if (!finishReview.trim()) {
      setFinishErrReview('Review is required.')
      bad = true
    }
    if (bad) return

    const finishedAt = new Date().toISOString()
    let nextActivity = [...activity]

    if (book.currentPage < book.totalPages) {
      const pagesAdded = book.totalPages - book.currentPage
      nextActivity = [
        ...nextActivity,
        {
          id: newId(),
          bookId: book.id,
          timestamp: finishedAt,
          pagesAdded,
        },
      ]
    }

    const nextBooks = books.map((b) =>
      b.id === book.id
        ? {
            ...b,
            status: 'finished',
            finishedAt,
            rating: r,
            review: rev,
            currentPage: b.totalPages,
          }
        : b
    )
    persist(nextBooks, nextActivity)
    setFinishingId(null)
    setFinishRating('')
    setFinishReview('')
  }

  function returnToReading(book) {
    const nextBooks = books.map((b) =>
      b.id === book.id
        ? {
            ...b,
            status: 'currently_reading',
            rating: null,
            review: null,
            finishedAt: null,
          }
        : b
    )
    persist(nextBooks, activity)
  }

  function confirmReset() {
    clearLibrary()
    setBooks([])
    setActivity([])
    setShowResetConfirm(false)
    setFinishingId(null)
  }

  return (
    <div className="app-root" data-layout-root>
      <header className="app-header">
        <h1>Reading Journal</h1>
        <p className="app-sub">
          Local-only tracker — progress, shelves, stats, and filters.
        </p>
      </header>

      <form
        data-testid="add-book-form"
        className="add-form"
        onSubmit={submitAddBook}
      >
        <div className="add-form-row">
          <div className="field-wrap">
            <label htmlFor="field-title">Title</label>
            <input
              id="field-title"
              data-testid="field-title"
              value={titleIn}
              onChange={(e) => setTitleIn(e.target.value)}
              autoComplete="off"
            />
            <span className="field-error">{errTitle}</span>
          </div>
          <div className="field-wrap">
            <label htmlFor="field-author">Author</label>
            <input
              id="field-author"
              data-testid="field-author"
              value={authorIn}
              onChange={(e) => setAuthorIn(e.target.value)}
              autoComplete="off"
            />
            <span className="field-error">{errAuthor}</span>
          </div>
          <div className="field-wrap">
            <label htmlFor="field-total-pages">Total pages</label>
            <input
              id="field-total-pages"
              data-testid="field-total-pages"
              value={pagesIn}
              onChange={(e) => setPagesIn(e.target.value)}
              inputMode="numeric"
              autoComplete="off"
            />
            <span className="field-error">{errPages}</span>
          </div>
          <button
            type="submit"
            data-testid="submit-add-book"
            className="btn btn-primary"
          >
            Add book
          </button>
        </div>
      </form>

      <div className="controls-bar">
        <div className="field-wrap">
          <label htmlFor="search-input">Search by author</label>
          <input
            id="search-input"
            data-testid="search-input"
            placeholder="Search by author"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="field-wrap">
          <label htmlFor="filter-author">Filter author</label>
          <select
            id="filter-author"
            data-testid="filter-author"
            value={filterAuthor}
            onChange={(e) => setFilterAuthor(e.target.value)}
          >
            <option value="">All authors</option>
            {authorOptions.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </div>
        <div className="field-wrap">
          <label htmlFor="filter-rating">Filter rating</label>
          <select
            id="filter-rating"
            data-testid="filter-rating"
            value={filterRating}
            onChange={(e) => setFilterRating(e.target.value)}
          >
            <option value="">All ratings</option>
            {[1, 2, 3, 4, 5].map((n) => (
              <option key={n} value={String(n)}>
                {n}
              </option>
            ))}
          </select>
        </div>
        <div className="field-wrap">
          <label htmlFor="filter-year">Filter year (finished)</label>
          <select
            id="filter-year"
            data-testid="filter-year"
            value={filterYear}
            onChange={(e) => setFilterYear(e.target.value)}
          >
            <option value="">All years</option>
            {yearOptions.map((y) => (
              <option key={y} value={String(y)}>
                {y}
              </option>
            ))}
          </select>
        </div>
      </div>

      <section className="stats-panel" aria-label="Statistics">
        <div className="stats-grid">
          <div className="stat-card">
            <div className="label">Books finished this year</div>
            <div
              className="value"
              data-testid="stats-books-finished-this-year"
            >
              {stats.booksFinishedThisYear}
            </div>
          </div>
          <div className="stat-card">
            <div className="label">Total pages (finished this year)</div>
            <div
              className="value"
              data-testid="stats-total-pages-this-year"
            >
              {stats.totalPagesFinishedThisYear}
            </div>
          </div>
          <div className="stat-card">
            <div className="label">Total pages (all finished)</div>
            <div className="value" data-testid="stats-total-pages-all">
              {stats.totalPagesFinished}
            </div>
          </div>
          <div className="stat-card">
            <div className="label">Avg length (finished this year)</div>
            <div
              className="value"
              data-testid="stats-average-length-this-year"
            >
              {stats.averageBookLengthFinishedThisYear}
            </div>
          </div>
        </div>
        <div data-testid="stats-pages-per-week-chart" className="chart-wrap">
          <PagesPerWeekChart rows={stats.pagesPerWeek} />
        </div>
      </section>

      <section className="shelf" data-shelf="current">
        <h2>Currently Reading</h2>
        <div
          className="book-list"
          data-testid="shelf-currently-reading"
        >
          {reading.length === 0 ? (
            <p className="empty-hint">No books on this shelf.</p>
          ) : (
            reading.map((book) => (
              <article
                key={book.id}
                className="book-card"
                data-testid={`book-card-${book.id}`}
              >
                <h3>{book.title}</h3>
                <div className="book-meta">{book.author}</div>
                <div className="progress-row">
                  <div
                    className="progress-track"
                    data-testid={`progress-bar-${book.id}`}
                  >
                    <div
                      className="progress-fill"
                      style={{
                        width: `${progressPct(book.currentPage, book.totalPages)}%`,
                      }}
                    />
                  </div>
                  <span
                    className="progress-pct"
                    data-testid={`progress-percent-${book.id}`}
                  >
                    {progressPct(book.currentPage, book.totalPages)}%
                  </span>
                </div>
                <form
                  className="inline-form"
                  onSubmit={(e) => submitProgress(book, e)}
                >
                  <label htmlFor={`up-${book.id}`} className="sr-only">
                    Update page
                  </label>
                  <input
                    id={`up-${book.id}`}
                    data-testid={`update-progress-input-${book.id}`}
                    value={
                      progressDraft[book.id] ?? String(book.currentPage)
                    }
                    onChange={(e) =>
                      setProgressDraft((d) => ({
                        ...d,
                        [book.id]: e.target.value,
                      }))
                    }
                    inputMode="numeric"
                  />
                  <button
                    type="submit"
                    data-testid={`update-progress-submit-${book.id}`}
                    className="btn btn-secondary"
                  >
                    Update
                  </button>
                  <span className="field-error">
                    {progressErr[book.id] ?? ''}
                  </span>
                </form>

                {finishingId !== book.id ? (
                  <button
                    type="button"
                    data-testid={`mark-finished-${book.id}`}
                    className="btn btn-ghost"
                    onClick={() => openFinish(book)}
                  >
                    Mark finished
                  </button>
                ) : (
                  <div className="finish-block">
                    <form
                      className="finish-row"
                      onSubmit={(e) => {
                        e.preventDefault()
                        submitFinish(book)
                      }}
                    >
                      <div className="field-wrap">
                        <label htmlFor={`fr-${book.id}`}>Rating (1–5)</label>
                        <input
                          id={`fr-${book.id}`}
                          data-testid={`finish-rating-${book.id}`}
                          value={finishRating}
                          onChange={(e) => setFinishRating(e.target.value)}
                          inputMode="numeric"
                        />
                        <span className="field-error">{finishErrRating}</span>
                      </div>
                      <div className="field-wrap">
                        <label htmlFor={`fv-${book.id}`}>Review</label>
                        <input
                          id={`fv-${book.id}`}
                          data-testid={`finish-review-${book.id}`}
                          value={finishReview}
                          onChange={(e) => setFinishReview(e.target.value)}
                        />
                        <span className="field-error">{finishErrReview}</span>
                      </div>
                      <button
                        type="submit"
                        data-testid={`finish-submit-${book.id}`}
                        className="btn btn-primary"
                      >
                        Finish book
                      </button>
                    </form>
                  </div>
                )}
              </article>
            ))
          )}
        </div>
      </section>

      <section className="shelf" data-shelf="finished">
        <h2>Finished</h2>
        <div className="book-list" data-testid="shelf-finished">
          {finished.length === 0 ? (
            <p className="empty-hint">No finished books on this shelf.</p>
          ) : (
            finished.map((book) => (
              <article
                key={book.id}
                className="book-card"
                data-testid={`book-card-${book.id}`}
              >
                <h3>{book.title}</h3>
                <div className="book-meta">
                  {book.author} · {book.totalPages} pages · rating{' '}
                  {book.rating}
                </div>
                <p>{book.review}</p>
                <button
                  type="button"
                  data-testid={`return-to-reading-${book.id}`}
                  className="btn btn-ghost"
                  onClick={() => returnToReading(book)}
                >
                  Return to reading
                </button>
              </article>
            ))
          )}
        </div>
      </section>

      <div className="reset-row">
        <button
          type="button"
          data-testid="reset-library"
          className="btn btn-danger"
          onClick={() => setShowResetConfirm(true)}
        >
          Reset all data
        </button>
        {showResetConfirm ? (
          <button
            type="button"
            data-testid="reset-confirm"
            className="btn btn-secondary"
            onClick={confirmReset}
          >
            Confirm reset
          </button>
        ) : null}
      </div>
    </div>
  )
}
